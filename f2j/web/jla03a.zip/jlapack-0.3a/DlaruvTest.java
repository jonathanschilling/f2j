import org.netlib.util.*;
import org.netlib.lapack.Dlaruv;

public class DlaruvTest {
  public static void main(String [] args) {
    int [] iseed = {1998, 1999, 2000, 2001};
    double []x = new double [10];
    int n = x.length;

    Dlaruv.dlaruv(iseed,0,n,x,0);

    System.out.println("Answer = ");
    for(int i = 0; i < x.length; i++)
      System.out.print(x[i] + " ");
    System.out.println();
  } 
}
