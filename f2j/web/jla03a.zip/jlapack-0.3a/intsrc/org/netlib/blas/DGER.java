/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.blas;
import java.lang.*;
import org.netlib.util.*;



public class DGER {


public static void DGER (int m,
int n,
double alpha,
double [] x,
int incx,
double [] y,
int incy,
double [][] a)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
Dger.dger( m, n, alpha,  x, 0, incx,  y, 0, incy,  _a_copy, 0, a.length);

MatConv.copyOneDintoTwoD(a,_a_copy);
}
}
