/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.blas;
import java.lang.*;
import org.netlib.util.*;



public class DTRMM {


public static void DTRMM (String side,
String uplo,
String transa,
String diag,
int m,
int n,
double alpha,
double [][] a,
double [][] b)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
Dtrmm.dtrmm( side, uplo, transa, diag, m, n, alpha,  _a_copy, 0, a.length,  _b_copy, 0, b.length);

MatConv.copyOneDintoTwoD(b,_b_copy);
}
}
