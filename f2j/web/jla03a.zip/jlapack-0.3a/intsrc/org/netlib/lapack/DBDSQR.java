/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DBDSQR {


public static void DBDSQR (String uplo,
int n,
int ncvt,
int nru,
int ncc,
double [] d,
double [] e,
double [][] vt,
double [][] u,
double [][] c,
double [] work,
intW info)  {

double [] _vt_copy = MatConv.doubleTwoDtoOneD(vt);
double [] _u_copy = MatConv.doubleTwoDtoOneD(u);
double [] _c_copy = MatConv.doubleTwoDtoOneD(c);
Dbdsqr.dbdsqr( uplo, n, ncvt, nru, ncc,  d, 0,  e, 0,  _vt_copy, 0, vt.length,  _u_copy, 0, u.length,  _c_copy, 0, c.length,  work, 0, info);

MatConv.copyOneDintoTwoD(vt,_vt_copy);
MatConv.copyOneDintoTwoD(u,_u_copy);
MatConv.copyOneDintoTwoD(c,_c_copy);
}
}
