/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGBBRD {


public static void DGBBRD (String vect,
int m,
int n,
int ncc,
int kl,
int ku,
double [][] ab,
double [] d,
double [] e,
double [][] q,
double [][] pt,
double [][] c,
double [] work,
intW info)  {

double [] _ab_copy = MatConv.doubleTwoDtoOneD(ab);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _pt_copy = MatConv.doubleTwoDtoOneD(pt);
double [] _c_copy = MatConv.doubleTwoDtoOneD(c);
Dgbbrd.dgbbrd( vect, m, n, ncc, kl, ku,  _ab_copy, 0, ab.length,  d, 0,  e, 0,  _q_copy, 0, q.length,  _pt_copy, 0, pt.length,  _c_copy, 0, c.length,  work, 0, info);

MatConv.copyOneDintoTwoD(ab,_ab_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(pt,_pt_copy);
MatConv.copyOneDintoTwoD(c,_c_copy);
}
}
