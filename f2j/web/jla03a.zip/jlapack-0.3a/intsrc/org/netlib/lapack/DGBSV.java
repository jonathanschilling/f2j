/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGBSV {


public static void DGBSV (int n,
int kl,
int ku,
int nrhs,
double [][] ab,
int [] ipiv,
double [][] b,
intW info)  {

double [] _ab_copy = MatConv.doubleTwoDtoOneD(ab);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
Dgbsv.dgbsv( n, kl, ku, nrhs,  _ab_copy, 0, ab.length,  ipiv, 0,  _b_copy, 0, b.length, info);

MatConv.copyOneDintoTwoD(ab,_ab_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
}
}
