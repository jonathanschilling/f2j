/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGEEV {


public static void DGEEV (String jobvl,
String jobvr,
int n,
double [][] a,
double [] wr,
double [] wi,
double [][] vl,
double [][] vr,
double [] work,
int lwork,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _vl_copy = MatConv.doubleTwoDtoOneD(vl);
double [] _vr_copy = MatConv.doubleTwoDtoOneD(vr);
Dgeev.dgeev( jobvl, jobvr, n,  _a_copy, 0, a.length,  wr, 0,  wi, 0,  _vl_copy, 0, vl.length,  _vr_copy, 0, vr.length,  work, 0, lwork, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(vl,_vl_copy);
MatConv.copyOneDintoTwoD(vr,_vr_copy);
}
}
