/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGEGS {


public static void DGEGS (String jobvsl,
String jobvsr,
int n,
double [][] a,
double [][] b,
double [] alphar,
double [] alphai,
double [] beta,
double [][] vsl,
double [][] vsr,
double [] work,
int lwork,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _vsl_copy = MatConv.doubleTwoDtoOneD(vsl);
double [] _vsr_copy = MatConv.doubleTwoDtoOneD(vsr);
Dgegs.dgegs( jobvsl, jobvsr, n,  _a_copy, 0, a.length,  _b_copy, 0, b.length,  alphar, 0,  alphai, 0,  beta, 0,  _vsl_copy, 0, vsl.length,  _vsr_copy, 0, vsr.length,  work, 0, lwork, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
MatConv.copyOneDintoTwoD(vsl,_vsl_copy);
MatConv.copyOneDintoTwoD(vsr,_vsr_copy);
}
}
