/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGGSVP {


public static void DGGSVP (String jobu,
String jobv,
String jobq,
int m,
int p,
int n,
double [][] a,
double [][] b,
double tola,
double tolb,
intW k,
intW l,
double [][] u,
double [][] v,
double [][] q,
int [] iwork,
double [] tau,
double [] work,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _u_copy = MatConv.doubleTwoDtoOneD(u);
double [] _v_copy = MatConv.doubleTwoDtoOneD(v);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
Dggsvp.dggsvp( jobu, jobv, jobq, m, p, n,  _a_copy, 0, a.length,  _b_copy, 0, b.length, tola, tolb, k, l,  _u_copy, 0, u.length,  _v_copy, 0, v.length,  _q_copy, 0, q.length,  iwork, 0,  tau, 0,  work, 0, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
MatConv.copyOneDintoTwoD(u,_u_copy);
MatConv.copyOneDintoTwoD(v,_v_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
}
}
