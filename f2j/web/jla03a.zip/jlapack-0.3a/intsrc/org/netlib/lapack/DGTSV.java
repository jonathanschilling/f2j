/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DGTSV {


public static void DGTSV (int n,
int nrhs,
double [] dl,
double [] d,
double [] du,
double [][] b,
intW info)  {

double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
Dgtsv.dgtsv( n, nrhs,  dl, 0,  d, 0,  du, 0,  _b_copy, 0, b.length, info);

MatConv.copyOneDintoTwoD(b,_b_copy);
}
}
