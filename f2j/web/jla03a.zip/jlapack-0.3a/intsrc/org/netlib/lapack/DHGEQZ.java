/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DHGEQZ {


public static void DHGEQZ (String job,
String compq,
String compz,
int n,
int ilo,
int ihi,
double [][] a,
double [][] b,
double [] alphar,
double [] alphai,
double [] beta,
double [][] q,
double [][] z,
double [] work,
int lwork,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _z_copy = MatConv.doubleTwoDtoOneD(z);
Dhgeqz.dhgeqz( job, compq, compz, n, ilo, ihi,  _a_copy, 0, a.length,  _b_copy, 0, b.length,  alphar, 0,  alphai, 0,  beta, 0,  _q_copy, 0, q.length,  _z_copy, 0, z.length,  work, 0, lwork, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(z,_z_copy);
}
}
