/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DHSEQR {


public static void DHSEQR (String job,
String compz,
int n,
int ilo,
int ihi,
double [][] h,
double [] wr,
double [] wi,
double [][] z,
double [] work,
int lwork,
intW info)  {

double [] _h_copy = MatConv.doubleTwoDtoOneD(h);
double [] _z_copy = MatConv.doubleTwoDtoOneD(z);
Dhseqr.dhseqr( job, compz, n, ilo, ihi,  _h_copy, 0, h.length,  wr, 0,  wi, 0,  _z_copy, 0, z.length,  work, 0, lwork, info);

MatConv.copyOneDintoTwoD(h,_h_copy);
MatConv.copyOneDintoTwoD(z,_z_copy);
}
}
