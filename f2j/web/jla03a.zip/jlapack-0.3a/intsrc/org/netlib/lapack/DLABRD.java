/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLABRD {


public static void DLABRD (int m,
int n,
int nb,
double [][] a,
double [] d,
double [] e,
double [] tauq,
double [] taup,
double [][] x,
double [][] y)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _x_copy = MatConv.doubleTwoDtoOneD(x);
double [] _y_copy = MatConv.doubleTwoDtoOneD(y);
Dlabrd.dlabrd( m, n, nb,  _a_copy, 0, a.length,  d, 0,  e, 0,  tauq, 0,  taup, 0,  _x_copy, 0, x.length,  _y_copy, 0, y.length);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(x,_x_copy);
MatConv.copyOneDintoTwoD(y,_y_copy);
}
}
