/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAED0 {


public static void DLAED0 (int icompq,
int qsiz,
int n,
double [] d,
double [] e,
double [][] q,
double [][] qstore,
double [] work,
int [] iwork,
intW info)  {

double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _qstore_copy = MatConv.doubleTwoDtoOneD(qstore);
Dlaed0.dlaed0( icompq, qsiz, n,  d, 0,  e, 0,  _q_copy, 0, q.length,  _qstore_copy, 0, qstore.length,  work, 0,  iwork, 0, info);

MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(qstore,_qstore_copy);
}
}
