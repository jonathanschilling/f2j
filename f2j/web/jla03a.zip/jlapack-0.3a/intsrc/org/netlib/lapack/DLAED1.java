/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAED1 {


public static void DLAED1 (int n,
double [] d,
double [][] q,
int [] indxq,
doubleW rho,
int cutpnt,
double [] work,
int [] iwork,
intW info)  {

double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
Dlaed1.dlaed1( n,  d, 0,  _q_copy, 0, q.length,  indxq, 0, rho, cutpnt,  work, 0,  iwork, 0, info);

MatConv.copyOneDintoTwoD(q,_q_copy);
}
}
