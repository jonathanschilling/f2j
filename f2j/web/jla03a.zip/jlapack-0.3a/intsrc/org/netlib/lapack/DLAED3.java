/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAED3 {


public static void DLAED3 (int k,
int kstart,
int kstop,
int n,
double [] d,
double [][] q,
double rho,
int cutpnt,
double [] dlamda,
double [][] q2,
int [] indxc,
int [] ctot,
double [] w,
double [][] s,
intW info)  {

double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _q2_copy = MatConv.doubleTwoDtoOneD(q2);
double [] _s_copy = MatConv.doubleTwoDtoOneD(s);
Dlaed3.dlaed3( k, kstart, kstop, n,  d, 0,  _q_copy, 0, q.length, rho, cutpnt,  dlamda, 0,  _q2_copy, 0, q2.length,  indxc, 0,  ctot, 0,  w, 0,  _s_copy, 0, s.length, info);

MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(s,_s_copy);
}
}
