/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAED8 {


public static void DLAED8 (int icompq,
intW k,
int n,
int qsiz,
double [] d,
double [][] q,
int [] indxq,
doubleW rho,
int cutpnt,
double [] z,
double [] dlamda,
double [][] q2,
double [] w,
int [] perm,
intW givptr,
int [][] givcol,
double [][] givnum,
int [] indxp,
int [] indx,
intW info)  {

double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _q2_copy = MatConv.doubleTwoDtoOneD(q2);
int [] _givcol_copy = MatConv.intTwoDtoOneD(givcol);
double [] _givnum_copy = MatConv.doubleTwoDtoOneD(givnum);
Dlaed8.dlaed8( icompq, k, n, qsiz,  d, 0,  _q_copy, 0, q.length,  indxq, 0, rho, cutpnt,  z, 0,  dlamda, 0,  _q2_copy, 0, q2.length,  w, 0,  perm, 0, givptr,  _givcol_copy, 0,  _givnum_copy, 0,  indxp, 0,  indx, 0, info);

MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(q2,_q2_copy);
MatConv.copyOneDintoTwoD(givcol,_givcol_copy);
MatConv.copyOneDintoTwoD(givnum,_givnum_copy);
}
}
