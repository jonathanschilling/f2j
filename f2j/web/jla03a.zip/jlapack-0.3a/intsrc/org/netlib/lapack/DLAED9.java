/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAED9 {


public static void DLAED9 (int k,
int kstart,
int kstop,
int n,
double [] d,
double [][] q,
double rho,
double [] dlamda,
double [] w,
double [][] s,
intW info)  {

double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
double [] _s_copy = MatConv.doubleTwoDtoOneD(s);
Dlaed9.dlaed9( k, kstart, kstop, n,  d, 0,  _q_copy, 0, q.length, rho,  dlamda, 0,  w, 0,  _s_copy, 0, s.length, info);

MatConv.copyOneDintoTwoD(q,_q_copy);
MatConv.copyOneDintoTwoD(s,_s_copy);
}
}
