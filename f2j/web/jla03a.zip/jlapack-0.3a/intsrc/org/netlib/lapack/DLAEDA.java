/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAEDA {


public static void DLAEDA (int n,
int tlvls,
int curlvl,
int curpbm,
int [] prmptr,
int [] perm,
int [] givptr,
int [][] givcol,
double [][] givnum,
double [] q,
int [] qptr,
double [] z,
double [] ztemp,
intW info)  {

int [] _givcol_copy = MatConv.intTwoDtoOneD(givcol);
double [] _givnum_copy = MatConv.doubleTwoDtoOneD(givnum);
Dlaeda.dlaeda( n, tlvls, curlvl, curpbm,  prmptr, 0,  perm, 0,  givptr, 0,  _givcol_copy, 0,  _givnum_copy, 0,  q, 0,  qptr, 0,  z, 0,  ztemp, 0, info);

}
}
