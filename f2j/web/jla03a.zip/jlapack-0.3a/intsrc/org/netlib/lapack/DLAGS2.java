/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAGS2 {


public static void DLAGS2 (boolean upper,
double a1,
double a2,
double a3,
double b1,
double b2,
double b3,
doubleW csu,
doubleW snu,
doubleW csv,
doubleW snv,
doubleW csq,
doubleW snq)  {

Dlags2.dlags2( upper, a1, a2, a3, b1, b2, b3, csu, snu, csv, snv, csq, snq);

}
}
