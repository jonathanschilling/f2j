/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLAHRD {


public static void DLAHRD (int n,
int k,
int nb,
double [][] a,
double [] tau,
double [][] t,
double [][] y)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _t_copy = MatConv.doubleTwoDtoOneD(t);
double [] _y_copy = MatConv.doubleTwoDtoOneD(y);
Dlahrd.dlahrd( n, k, nb,  _a_copy, 0, a.length,  tau, 0,  _t_copy, 0, t.length,  _y_copy, 0, y.length);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(t,_t_copy);
MatConv.copyOneDintoTwoD(y,_y_copy);
}
}
