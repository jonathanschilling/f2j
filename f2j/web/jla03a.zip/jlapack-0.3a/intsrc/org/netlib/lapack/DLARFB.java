/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLARFB {


public static void DLARFB (String side,
String trans,
String direct,
String storev,
int m,
int n,
int k,
double [][] v,
double [][] t,
double [][] c,
double [][] work)  {

double [] _v_copy = MatConv.doubleTwoDtoOneD(v);
double [] _t_copy = MatConv.doubleTwoDtoOneD(t);
double [] _c_copy = MatConv.doubleTwoDtoOneD(c);
double [] _work_copy = MatConv.doubleTwoDtoOneD(work);
Dlarfb.dlarfb( side, trans, direct, storev, m, n, k,  _v_copy, 0, v.length,  _t_copy, 0, t.length,  _c_copy, 0, c.length,  _work_copy, 0, work.length);

MatConv.copyOneDintoTwoD(c,_c_copy);
MatConv.copyOneDintoTwoD(work,_work_copy);
}
}
