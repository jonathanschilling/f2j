/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLARFX {


public static void DLARFX (String side,
int m,
int n,
double [] v,
double tau,
double [][] c,
double [] work)  {

double [] _c_copy = MatConv.doubleTwoDtoOneD(c);
Dlarfx.dlarfx( side, m, n,  v, 0, tau,  _c_copy, 0, c.length,  work, 0);

MatConv.copyOneDintoTwoD(c,_c_copy);
}
}
