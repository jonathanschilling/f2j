/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLATRD {


public static void DLATRD (String uplo,
int n,
int nb,
double [][] a,
double [] e,
double [] tau,
double [][] w)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _w_copy = MatConv.doubleTwoDtoOneD(w);
Dlatrd.dlatrd( uplo, n, nb,  _a_copy, 0, a.length,  e, 0,  tau, 0,  _w_copy, 0, w.length);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(w,_w_copy);
}
}
