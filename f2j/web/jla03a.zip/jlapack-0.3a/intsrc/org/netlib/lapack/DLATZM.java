/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DLATZM {


public static void DLATZM (String side,
int m,
int n,
double [] v,
int incv,
double tau,
double [][] c1,
double [][] c2,
double [] work)  {

double [] _c1_copy = MatConv.doubleTwoDtoOneD(c1);
double [] _c2_copy = MatConv.doubleTwoDtoOneD(c2);
Dlatzm.dlatzm( side, m, n,  v, 0, incv, tau,  _c1_copy, 0,  _c2_copy, 0, c2.length,  work, 0);

MatConv.copyOneDintoTwoD(c1,_c1_copy);
MatConv.copyOneDintoTwoD(c2,_c2_copy);
}
}
