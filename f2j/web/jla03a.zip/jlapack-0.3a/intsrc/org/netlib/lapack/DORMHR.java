/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DORMHR {


public static void DORMHR (String side,
String trans,
int m,
int n,
int ilo,
int ihi,
double [][] a,
double [] tau,
double [][] c,
double [] work,
int lwork,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _c_copy = MatConv.doubleTwoDtoOneD(c);
Dormhr.dormhr( side, trans, m, n, ilo, ihi,  _a_copy, 0, a.length,  tau, 0,  _c_copy, 0, c.length,  work, 0, lwork, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(c,_c_copy);
}
}
