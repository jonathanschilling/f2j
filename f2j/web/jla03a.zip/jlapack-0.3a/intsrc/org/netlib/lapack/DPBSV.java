/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DPBSV {


public static void DPBSV (String uplo,
int n,
int kd,
int nrhs,
double [][] ab,
double [][] b,
intW info)  {

double [] _ab_copy = MatConv.doubleTwoDtoOneD(ab);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
Dpbsv.dpbsv( uplo, n, kd, nrhs,  _ab_copy, 0, ab.length,  _b_copy, 0, b.length, info);

MatConv.copyOneDintoTwoD(ab,_ab_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
}
}
