/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DPOSVX {


public static void DPOSVX (String fact,
String uplo,
int n,
int nrhs,
double [][] a,
double [][] af,
StringW equed,
double [] s,
double [][] b,
double [][] x,
doubleW rcond,
double [] ferr,
double [] berr,
double [] work,
int [] iwork,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _af_copy = MatConv.doubleTwoDtoOneD(af);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _x_copy = MatConv.doubleTwoDtoOneD(x);
Dposvx.dposvx( fact, uplo, n, nrhs,  _a_copy, 0, a.length,  _af_copy, 0, af.length, equed,  s, 0,  _b_copy, 0, b.length,  _x_copy, 0, x.length, rcond,  ferr, 0,  berr, 0,  work, 0,  iwork, 0, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(af,_af_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
MatConv.copyOneDintoTwoD(x,_x_copy);
}
}
