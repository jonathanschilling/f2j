/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DSBTRD {


public static void DSBTRD (String vect,
String uplo,
int n,
int kd,
double [][] ab,
double [] d,
double [] e,
double [][] q,
double [] work,
intW info)  {

double [] _ab_copy = MatConv.doubleTwoDtoOneD(ab);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
Dsbtrd.dsbtrd( vect, uplo, n, kd,  _ab_copy, 0, ab.length,  d, 0,  e, 0,  _q_copy, 0, q.length,  work, 0, info);

MatConv.copyOneDintoTwoD(ab,_ab_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
}
}
