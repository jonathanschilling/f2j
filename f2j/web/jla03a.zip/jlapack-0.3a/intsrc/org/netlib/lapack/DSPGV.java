/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DSPGV {


public static void DSPGV (int itype,
String jobz,
String uplo,
int n,
double [] ap,
double [] bp,
double [] w,
double [][] z,
double [] work,
intW info)  {

double [] _z_copy = MatConv.doubleTwoDtoOneD(z);
Dspgv.dspgv( itype, jobz, uplo, n,  ap, 0,  bp, 0,  w, 0,  _z_copy, 0, z.length,  work, 0, info);

MatConv.copyOneDintoTwoD(z,_z_copy);
}
}
