/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DSYEVX {


public static void DSYEVX (String jobz,
String range,
String uplo,
int n,
double [][] a,
double vl,
double vu,
int il,
int iu,
double abstol,
intW m,
double [] w,
double [][] z,
double [] work,
int lwork,
int [] iwork,
int [] ifail,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _z_copy = MatConv.doubleTwoDtoOneD(z);
Dsyevx.dsyevx( jobz, range, uplo, n,  _a_copy, 0, a.length, vl, vu, il, iu, abstol, m,  w, 0,  _z_copy, 0, z.length,  work, 0, lwork,  iwork, 0,  ifail, 0, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(z,_z_copy);
}
}
