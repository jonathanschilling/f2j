/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DTBRFS {


public static void DTBRFS (String uplo,
String trans,
String diag,
int n,
int kd,
int nrhs,
double [][] ab,
double [][] b,
double [][] x,
double [] ferr,
double [] berr,
double [] work,
int [] iwork,
intW info)  {

double [] _ab_copy = MatConv.doubleTwoDtoOneD(ab);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _x_copy = MatConv.doubleTwoDtoOneD(x);
Dtbrfs.dtbrfs( uplo, trans, diag, n, kd, nrhs,  _ab_copy, 0, ab.length,  _b_copy, 0, b.length,  _x_copy, 0, x.length,  ferr, 0,  berr, 0,  work, 0,  iwork, 0, info);

}
}
