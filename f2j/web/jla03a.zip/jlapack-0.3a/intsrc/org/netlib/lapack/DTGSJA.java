/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DTGSJA {


public static void DTGSJA (String jobu,
String jobv,
String jobq,
int m,
int p,
int n,
int k,
int l,
double [][] a,
double [][] b,
double tola,
double tolb,
double [] alpha,
double [] beta,
double [][] u,
double [][] v,
double [][] q,
double [] work,
intW ncycle,
intW info)  {

double [] _a_copy = MatConv.doubleTwoDtoOneD(a);
double [] _b_copy = MatConv.doubleTwoDtoOneD(b);
double [] _u_copy = MatConv.doubleTwoDtoOneD(u);
double [] _v_copy = MatConv.doubleTwoDtoOneD(v);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
Dtgsja.dtgsja( jobu, jobv, jobq, m, p, n, k, l,  _a_copy, 0, a.length,  _b_copy, 0, b.length, tola, tolb,  alpha, 0,  beta, 0,  _u_copy, 0, u.length,  _v_copy, 0, v.length,  _q_copy, 0, q.length,  work, 0, ncycle, info);

MatConv.copyOneDintoTwoD(a,_a_copy);
MatConv.copyOneDintoTwoD(b,_b_copy);
MatConv.copyOneDintoTwoD(u,_u_copy);
MatConv.copyOneDintoTwoD(v,_v_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
}
}
