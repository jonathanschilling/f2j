/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class DTREXC {


public static void DTREXC (String compq,
int n,
double [][] t,
double [][] q,
intW ifst,
intW ilst,
double [] work,
intW info)  {

double [] _t_copy = MatConv.doubleTwoDtoOneD(t);
double [] _q_copy = MatConv.doubleTwoDtoOneD(q);
Dtrexc.dtrexc( compq, n,  _t_copy, 0, t.length,  _q_copy, 0, q.length, ifst, ilst,  work, 0, info);

MatConv.copyOneDintoTwoD(t,_t_copy);
MatConv.copyOneDintoTwoD(q,_q_copy);
}
}
