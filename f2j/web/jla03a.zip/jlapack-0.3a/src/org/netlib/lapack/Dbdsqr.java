/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dbdsqr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DBDSQR computes the singular value decomposition (SVD) of a real
// *  N-by-N (upper or lower) bidiagonal matrix B:  B = Q * S * P' (P'
// *  denotes the transpose of P), where S is a diagonal matrix with
// *  non-negative diagonal elements (the singular values of B), and Q
// *  and P are orthogonal matrices.
// *
// *  The routine computes S, and optionally computes U * Q, P' * VT,
// *  or Q' * C, for given real input matrices U, VT, and C.
// *
// *  See "Computing  Small Singular Values of Bidiagonal Matrices With
// *  Guaranteed High Relative Accuracy," by J. Demmel and W. Kahan,
// *  LAPACK Working Note #3 (or SIAM J. Sci. Statist. Comput. vol. 11,
// *  no. 5, pp. 873-912, Sept 1990) and
// *  "Accurate singular values and differential qd algorithms," by
// *  B. Parlett and V. Fernando, Technical Report CPAM-554, Mathematics
// *  Department, University of California at Berkeley, July 1992
// *  for a detailed description of the algorithm.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          = 'U':  B is upper bidiagonal;
// *          = 'L':  B is lower bidiagonal.
// *
// *  N       (input) INTEGER
// *          The order of the matrix B.  N >= 0.
// *
// *  NCVT    (input) INTEGER
// *          The number of columns of the matrix VT. NCVT >= 0.
// *
// *  NRU     (input) INTEGER
// *          The number of rows of the matrix U. NRU >= 0.
// *
// *  NCC     (input) INTEGER
// *          The number of columns of the matrix C. NCC >= 0.
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, the n diagonal elements of the bidiagonal matrix B.
// *          On exit, if INFO=0, the singular values of B in decreasing
// *          order.
// *
// *  E       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, the elements of E contain the
// *          offdiagonal elements of the bidiagonal matrix whose SVD
// *          is desired. On normal exit (INFO = 0), E is destroyed.
// *          If the algorithm does not converge (INFO > 0), D and E
// *          will contain the diagonal and superdiagonal elements of a
// *          bidiagonal matrix orthogonally equivalent to the one given
// *          as input. E(N) is used for workspace.
// *
// *  VT      (input/output) DOUBLE PRECISION array, dimension (LDVT, NCVT)
// *          On entry, an N-by-NCVT matrix VT.
// *          On exit, VT is overwritten by P' * VT.
// *          VT is not referenced if NCVT = 0.
// *
// *  LDVT    (input) INTEGER
// *          The leading dimension of the array VT.
// *          LDVT >= max(1,N) if NCVT > 0; LDVT >= 1 if NCVT = 0.
// *
// *  U       (input/output) DOUBLE PRECISION array, dimension (LDU, N)
// *          On entry, an NRU-by-N matrix U.
// *          On exit, U is overwritten by U * Q.
// *          U is not referenced if NRU = 0.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= max(1,NRU).
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC, NCC)
// *          On entry, an N-by-NCC matrix C.
// *          On exit, C is overwritten by Q' * C.
// *          C is not referenced if NCC = 0.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C.
// *          LDC >= max(1,N) if NCC > 0; LDC >=1 if NCC = 0.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *            2*N  if only singular values wanted (NCVT = NRU = NCC = 0)
// *            max( 1, 4*N-4 ) otherwise
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  If INFO = -i, the i-th argument had an illegal value
// *          > 0:  the algorithm did not converge; D and E contain the
// *                elements of a bidiagonal matrix which is orthogonally
// *                similar to the input matrix B;  if INFO = i, i
// *                elements of E have not converged to zero.
// *
// *  Internal Parameters
// *  ===================
// *
// *  TOLMUL  DOUBLE PRECISION, default = max(10,min(100,EPS**(-1/8)))
// *          TOLMUL controls the convergence criterion of the QR loop.
// *          If it is positive, TOLMUL*EPS is the desired relative
// *             precision in the computed singular values.
// *          If it is negative, abs(TOLMUL*EPS*sigma_max) is the
// *             desired absolute accuracy in the computed singular
// *             values (corresponds to relative accuracy
// *             abs(TOLMUL*EPS) in the largest singular value.
// *          abs(TOLMUL) should be between 1 and 1/EPS, and preferably
// *             between 10 (for fast convergence) and .1/EPS
// *             (for there to be some accuracy in the results).
// *          Default is to lose at either one eighth or 2 of the
// *             available decimal digits in each computed singular value
// *             (whichever is smaller).
// *
// *  MAXITR  INTEGER, default = 6
// *          MAXITR controls the maximum number of passes of the
// *          algorithm through its inner loop. The algorithms stops
// *          (and so fails to converge) if the number of passes
// *          through the inner loop exceeds MAXITR*N**2.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double negone= -1.0e0;
static double hndrth= 0.01e0;
static double ten= 10.0e0;
static double hndrd= 100.0e0;
static double meigth= -0.125e0;
static int maxitr= 6;
// *     ..
// *     .. Local Scalars ..
static boolean rotate= false;
static int i= 0;
static int idir= 0;
static int irot= 0;
static int Isub= 0;
static int iter= 0;
static int iuplo= 0;
static int j= 0;
static int ll= 0;
static int lll= 0;
static int m= 0;
static int maxit= 0;
static int nm1= 0;
static int nm12= 0;
static int nm13= 0;
static int oldll= 0;
static int oldm= 0;
static double abse= 0.0;
static double abss= 0.0;
static doubleW cosl= new doubleW(0.0);
static doubleW cosr= new doubleW(0.0);
static doubleW cs= new doubleW(0.0);
static double eps= 0.0;
static double f= 0.0;
static double g= 0.0;
static double h= 0.0;
static double mu= 0.0;
static doubleW oldcs= new doubleW(0.0);
static doubleW oldsn= new doubleW(0.0);
static doubleW r= new doubleW(0.0);
static doubleW shift= new doubleW(0.0);
static doubleW sigmn= new doubleW(0.0);
static doubleW sigmx= new doubleW(0.0);
static doubleW sinl= new doubleW(0.0);
static doubleW sinr= new doubleW(0.0);
static double sll= 0.0;
static double smax= 0.0;
static double smin= 0.0;
static double sminl= 0.0;
static double sminlo= 0.0;
static double sminoa= 0.0;
static doubleW sn= new doubleW(0.0);
static double thresh= 0.0;
static double tol= 0.0;
static double tolmul= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dbdsqr (String uplo,
int n,
int ncvt,
int nru,
int ncc,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] vt, int _vt_offset,
int ldvt,
double [] u, int _u_offset,
int ldu,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
iuplo = 0;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  
    iuplo = 1;
if ((uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  
    iuplo = 2;
if (iuplo == 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (ncvt < 0)  {
    info.val = -3;
}              // Close else if()
else if (nru < 0)  {
    info.val = -4;
}              // Close else if()
else if (ncc < 0)  {
    info.val = -5;
}              // Close else if()
else if ((ncvt == 0 && ldvt < 1) || (ncvt > 0 && ldvt < Math.max(1, n) ))  {
    info.val = -9;
}              // Close else if()
else if (ldu < Math.max(1, nru) )  {
    info.val = -11;
}              // Close else if()
else if ((ncc == 0 && Ldc < 1) || (ncc > 0 && Ldc < Math.max(1, n) ))  {
    info.val = -13;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DBDSQR",-info.val);
Dummy.go_to("Dbdsqr",999999);
}              // Close if()
if (n == 0)  
    Dummy.go_to("Dbdsqr",999999);
if (n == 1)  
    Dummy.go_to("Dbdsqr",150);
// *
// *     ROTATE is true if any singular vectors desired, false otherwise
// *
rotate = (ncvt > 0) || (nru > 0) || (ncc > 0);
// *
// *     If no singular vectors desired, use qd algorithm
// *
if (!rotate)  {
    Dlasq1.dlasq1(n,d,_d_offset,e,_e_offset,work,_work_offset,info);
Dummy.go_to("Dbdsqr",999999);
}              // Close if()
// *
nm1 = n-1;
nm12 = nm1+nm1;
nm13 = nm12+nm1;
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("Epsilon");
unfl = Dlamch.dlamch("Safe minimum");
// *
// *     If matrix lower bidiagonal, rotate to be upper bidiagonal
// *     by applying Givens rotations on the left
// *
if (iuplo == 2)  {
    {
forloop10:
for (i = 1; i <= n-1; i++) {
Dlartg.dlartg(d[(i)- 1+ _d_offset],e[(i)- 1+ _e_offset],cs,sn,r);
d[(i)- 1+ _d_offset] = r.val;
e[(i)- 1+ _e_offset] = sn.val*d[(i+1)- 1+ _d_offset];
d[(i+1)- 1+ _d_offset] = cs.val*d[(i+1)- 1+ _d_offset];
work[(i)- 1+ _work_offset] = cs.val;
work[(nm1+i)- 1+ _work_offset] = sn.val;
Dummy.label("Dbdsqr",10);
}              //  Close for() loop. 
}
// *
// *        Update singular vectors if desired
// *
if (nru > 0)  
    Dlasr.dlasr("R","V","F",nru,n,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,u,_u_offset,ldu);
if (ncc > 0)  
    Dlasr.dlasr("L","V","F",n,ncc,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,c,_c_offset,Ldc);
}              // Close if()
// *
// *     Compute singular values to relative accuracy TOL
// *     (By setting TOL to be negative, algorithm will compute
// *     singular values to absolute accuracy ABS(TOL)*norm(input matrix))
// *
tolmul = Math.max(ten, Math.min(hndrd, Math.pow(eps, meigth)) ) ;
tol = tolmul*eps;
// *
// *     Compute approximate maximum, minimum singular values
// *
smax = Math.abs(d[(n)- 1+ _d_offset]);
{
forloop20:
for (i = 1; i <= n-1; i++) {
smax = Math.max((smax) > (Math.abs(d[(i)- 1+ _d_offset])) ? (smax) : (Math.abs(d[(i)- 1+ _d_offset])), Math.abs(e[(i)- 1+ _e_offset]));
Dummy.label("Dbdsqr",20);
}              //  Close for() loop. 
}
sminl = zero;
if (tol >= zero)  {
    // *
// *        Relative accuracy desired
// *
sminoa = Math.abs(d[(1)- 1+ _d_offset]);
if (sminoa == zero)  
    Dummy.go_to("Dbdsqr",40);
mu = sminoa;
{
forloop30:
for (i = 2; i <= n; i++) {
mu = Math.abs(d[(i)- 1+ _d_offset])*(mu/(mu+Math.abs(e[(i-1)- 1+ _e_offset])));
sminoa = Math.min(sminoa, mu) ;
if (sminoa == zero)  
    Dummy.go_to("Dbdsqr",40);
Dummy.label("Dbdsqr",30);
}              //  Close for() loop. 
}
label40:
   Dummy.label("Dbdsqr",40);
sminoa = sminoa/Math.sqrt((double)(n));
thresh = Math.max(tol*sminoa, maxitr*n*n*unfl) ;
}              // Close if()
else  {
  // *
// *        Absolute accuracy desired
// *
thresh = Math.max(Math.abs(tol)*smax, maxitr*n*n*unfl) ;
}              //  Close else.
// *
// *     Prepare for main iteration loop for the singular values
// *     (MAXIT is the maximum number of passes through the inner
// *     loop permitted before nonconvergence signalled.)
// *
maxit = maxitr*n*n;
iter = 0;
oldll = -1;
oldm = -1;
// *
// *     M points to last element of unconverged part of matrix
// *
m = n;
// *
// *     Begin main iteration loop
// *
label50:
   Dummy.label("Dbdsqr",50);
// *
// *     Check for convergence or exceeding iteration count
// *
if (m <= 1)  
    Dummy.go_to("Dbdsqr",150);
if (iter > maxit)  
    Dummy.go_to("Dbdsqr",190);
// *
// *     Find diagonal block of matrix to work on
// *
if (tol < zero && Math.abs(d[(m)- 1+ _d_offset]) <= thresh)  
    d[(m)- 1+ _d_offset] = zero;
smax = Math.abs(d[(m)- 1+ _d_offset]);
smin = smax;
{
forloop60:
for (lll = 1; lll <= m; lll++) {
ll = m-lll;
if (ll == 0)  
    Dummy.go_to("Dbdsqr",80);
abss = Math.abs(d[(ll)- 1+ _d_offset]);
abse = Math.abs(e[(ll)- 1+ _e_offset]);
if (tol < zero && abss <= thresh)  
    d[(ll)- 1+ _d_offset] = zero;
if (abse <= thresh)  
    Dummy.go_to("Dbdsqr",70);
smin = Math.min(smin, abss) ;
smax = Math.max((smax) > (abss) ? (smax) : (abss), abse);
Dummy.label("Dbdsqr",60);
}              //  Close for() loop. 
}
label70:
   Dummy.label("Dbdsqr",70);
e[(ll)- 1+ _e_offset] = zero;
// *
// *     Matrix splits since E(LL) = 0
// *
if (ll == m-1)  {
    // *
// *        Convergence of bottom singular value, return to top of loop
// *
m = m-1;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
label80:
   Dummy.label("Dbdsqr",80);
ll = ll+1;
// *
// *     E(LL) through E(M-1) are nonzero, E(LL-1) is zero
// *
if (ll == m-1)  {
    // *
// *        2 by 2 block, handle separately
// *
Dlasv2.dlasv2(d[(m-1)- 1+ _d_offset],e[(m-1)- 1+ _e_offset],d[(m)- 1+ _d_offset],sigmn,sigmx,sinr,cosr,sinl,cosl);
d[(m-1)- 1+ _d_offset] = sigmx.val;
e[(m-1)- 1+ _e_offset] = zero;
d[(m)- 1+ _d_offset] = sigmn.val;
// *
// *        Compute singular vectors, if desired
// *
if (ncvt > 0)  
    Drot.drot(ncvt,vt,(m-1)- 1+(1- 1)*ldvt+ _vt_offset,ldvt,vt,(m)- 1+(1- 1)*ldvt+ _vt_offset,ldvt,cosr.val,sinr.val);
if (nru > 0)  
    Drot.drot(nru,u,(1)- 1+(m-1- 1)*ldu+ _u_offset,1,u,(1)- 1+(m- 1)*ldu+ _u_offset,1,cosl.val,sinl.val);
if (ncc > 0)  
    Drot.drot(ncc,c,(m-1)- 1+(1- 1)*Ldc+ _c_offset,Ldc,c,(m)- 1+(1- 1)*Ldc+ _c_offset,Ldc,cosl.val,sinl.val);
m = m-2;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
// *
// *     If working on new submatrix, choose shift direction
// *     (from larger end diagonal element towards smaller)
// *
if (ll > oldm || m < oldll)  {
    if (Math.abs(d[(ll)- 1+ _d_offset]) >= Math.abs(d[(m)- 1+ _d_offset]))  {
    // *
// *           Chase bulge from top (big end) to bottom (small end)
// *
idir = 1;
}              // Close if()
else  {
  // *
// *           Chase bulge from bottom (big end) to top (small end)
// *
idir = 2;
}              //  Close else.
}              // Close if()
// *
// *     Apply convergence tests
// *
if (idir == 1)  {
    // *
// *        Run convergence test in forward direction
// *        First apply standard test to bottom of matrix
// *
if (Math.abs(e[(m-1)- 1+ _e_offset]) <= Math.abs(tol)*Math.abs(d[(m)- 1+ _d_offset]) || (tol < zero && Math.abs(e[(m-1)- 1+ _e_offset]) <= thresh))  {
    e[(m-1)- 1+ _e_offset] = zero;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
// *
if (tol >= zero)  {
    // *
// *           If relative accuracy desired,
// *           apply convergence criterion forward
// *
mu = Math.abs(d[(ll)- 1+ _d_offset]);
sminl = mu;
{
forloop90:
for (lll = ll; lll <= m-1; lll++) {
if (Math.abs(e[(lll)- 1+ _e_offset]) <= tol*mu)  {
    e[(lll)- 1+ _e_offset] = zero;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
sminlo = sminl;
mu = Math.abs(d[(lll+1)- 1+ _d_offset])*(mu/(mu+Math.abs(e[(lll)- 1+ _e_offset])));
sminl = Math.min(sminl, mu) ;
Dummy.label("Dbdsqr",90);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
else  {
  // *
// *        Run convergence test in backward direction
// *        First apply standard test to top of matrix
// *
if (Math.abs(e[(ll)- 1+ _e_offset]) <= Math.abs(tol)*Math.abs(d[(ll)- 1+ _d_offset]) || (tol < zero && Math.abs(e[(ll)- 1+ _e_offset]) <= thresh))  {
    e[(ll)- 1+ _e_offset] = zero;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
// *
if (tol >= zero)  {
    // *
// *           If relative accuracy desired,
// *           apply convergence criterion backward
// *
mu = Math.abs(d[(m)- 1+ _d_offset]);
sminl = mu;
{
int _lll_inc = -1;
forloop100:
for (lll = m-1; lll >= ll; lll += _lll_inc) {
if (Math.abs(e[(lll)- 1+ _e_offset]) <= tol*mu)  {
    e[(lll)- 1+ _e_offset] = zero;
Dummy.go_to("Dbdsqr",50);
}              // Close if()
sminlo = sminl;
mu = Math.abs(d[(lll)- 1+ _d_offset])*(mu/(mu+Math.abs(e[(lll)- 1+ _e_offset])));
sminl = Math.min(sminl, mu) ;
Dummy.label("Dbdsqr",100);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
oldll = ll;
oldm = m;
// *
// *     Compute shift.  First, test if shifting would ruin relative
// *     accuracy, and if so set the shift to zero.
// *
if (tol >= zero && n*tol*(sminl/smax) <= Math.max(eps, hndrth*tol) )  {
    // *
// *        Use a zero shift to avoid loss of relative accuracy
// *
shift.val = zero;
}              // Close if()
else  {
  // *
// *        Compute the shift from 2-by-2 block at end of matrix
// *
if (idir == 1)  {
    sll = Math.abs(d[(ll)- 1+ _d_offset]);
Dlas2.dlas2(d[(m-1)- 1+ _d_offset],e[(m-1)- 1+ _e_offset],d[(m)- 1+ _d_offset],shift,r);
}              // Close if()
else  {
  sll = Math.abs(d[(m)- 1+ _d_offset]);
Dlas2.dlas2(d[(ll)- 1+ _d_offset],e[(ll)- 1+ _e_offset],d[(ll+1)- 1+ _d_offset],shift,r);
}              //  Close else.
// *
// *        Test if shift negligible, and if so set to zero
// *
if (sll > zero)  {
    if (Math.pow((shift.val/sll), 2) < eps)  
    shift.val = zero;
}              // Close if()
}              //  Close else.
// *
// *     Increment iteration count
// *
iter = iter+m-ll;
// *
// *     If SHIFT = 0, do simplified QR iteration
// *
if (shift.val == zero)  {
    if (idir == 1)  {
    // *
// *           Chase bulge from top to bottom
// *           Save cosines and sines for later singular vector updates
// *
cs.val = one;
oldcs.val = one;
Dlartg.dlartg(d[(ll)- 1+ _d_offset]*cs.val,e[(ll)- 1+ _e_offset],cs,sn,r);
dlartg_adapter(oldcs.val*r.val,d[(ll+1)- 1+ _d_offset]*sn.val,oldcs,oldsn,d,(ll)- 1+ _d_offset);
work[(1)- 1+ _work_offset] = cs.val;
work[(1+nm1)- 1+ _work_offset] = sn.val;
work[(1+nm12)- 1+ _work_offset] = oldcs.val;
work[(1+nm13)- 1+ _work_offset] = oldsn.val;
irot = 1;
{
forloop110:
for (i = ll+1; i <= m-1; i++) {
Dlartg.dlartg(d[(i)- 1+ _d_offset]*cs.val,e[(i)- 1+ _e_offset],cs,sn,r);
e[(i-1)- 1+ _e_offset] = oldsn.val*r.val;
dlartg_adapter(oldcs.val*r.val,d[(i+1)- 1+ _d_offset]*sn.val,oldcs,oldsn,d,(i)- 1+ _d_offset);
irot = irot+1;
work[(irot)- 1+ _work_offset] = cs.val;
work[(irot+nm1)- 1+ _work_offset] = sn.val;
work[(irot+nm12)- 1+ _work_offset] = oldcs.val;
work[(irot+nm13)- 1+ _work_offset] = oldsn.val;
Dummy.label("Dbdsqr",110);
}              //  Close for() loop. 
}
h = d[(m)- 1+ _d_offset]*cs.val;
d[(m)- 1+ _d_offset] = h*oldcs.val;
e[(m-1)- 1+ _e_offset] = h*oldsn.val;
// *
// *           Update singular vectors
// *
if (ncvt > 0)  
    Dlasr.dlasr("L","V","F",m-ll+1,ncvt,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,vt,(ll)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
if (nru > 0)  
    Dlasr.dlasr("R","V","F",nru,m-ll+1,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,u,(1)- 1+(ll- 1)*ldu+ _u_offset,ldu);
if (ncc > 0)  
    Dlasr.dlasr("L","V","F",m-ll+1,ncc,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,c,(ll)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
// *
// *           Test convergence
// *
if (Math.abs(e[(m-1)- 1+ _e_offset]) <= thresh)  
    e[(m-1)- 1+ _e_offset] = zero;
// *
}              // Close if()
else  {
  // *
// *           Chase bulge from bottom to top
// *           Save cosines and sines for later singular vector updates
// *
cs.val = one;
oldcs.val = one;
Dlartg.dlartg(d[(m)- 1+ _d_offset]*cs.val,e[(m-1)- 1+ _e_offset],cs,sn,r);
dlartg_adapter(oldcs.val*r.val,d[(m-1)- 1+ _d_offset]*sn.val,oldcs,oldsn,d,(m)- 1+ _d_offset);
work[(m-ll)- 1+ _work_offset] = cs.val;
work[(m-ll+nm1)- 1+ _work_offset] = -sn.val;
work[(m-ll+nm12)- 1+ _work_offset] = oldcs.val;
work[(m-ll+nm13)- 1+ _work_offset] = -oldsn.val;
irot = m-ll;
{
int _i_inc = -1;
forloop120:
for (i = m-1; i >= ll+1; i += _i_inc) {
Dlartg.dlartg(d[(i)- 1+ _d_offset]*cs.val,e[(i-1)- 1+ _e_offset],cs,sn,r);
e[(i)- 1+ _e_offset] = oldsn.val*r.val;
dlartg_adapter(oldcs.val*r.val,d[(i-1)- 1+ _d_offset]*sn.val,oldcs,oldsn,d,(i)- 1+ _d_offset);
irot = irot-1;
work[(irot)- 1+ _work_offset] = cs.val;
work[(irot+nm1)- 1+ _work_offset] = -sn.val;
work[(irot+nm12)- 1+ _work_offset] = oldcs.val;
work[(irot+nm13)- 1+ _work_offset] = -oldsn.val;
Dummy.label("Dbdsqr",120);
}              //  Close for() loop. 
}
h = d[(ll)- 1+ _d_offset]*cs.val;
d[(ll)- 1+ _d_offset] = h*oldcs.val;
e[(ll)- 1+ _e_offset] = h*oldsn.val;
// *
// *           Update singular vectors
// *
if (ncvt > 0)  
    Dlasr.dlasr("L","V","B",m-ll+1,ncvt,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,vt,(ll)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
if (nru > 0)  
    Dlasr.dlasr("R","V","B",nru,m-ll+1,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,u,(1)- 1+(ll- 1)*ldu+ _u_offset,ldu);
if (ncc > 0)  
    Dlasr.dlasr("L","V","B",m-ll+1,ncc,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,c,(ll)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
// *
// *           Test convergence
// *
if (Math.abs(e[(ll)- 1+ _e_offset]) <= thresh)  
    e[(ll)- 1+ _e_offset] = zero;
}              //  Close else.
}              // Close if()
else  {
  // *
// *        Use nonzero shift
// *
if (idir == 1)  {
    // *
// *           Chase bulge from top to bottom
// *           Save cosines and sines for later singular vector updates
// *
f = (Math.abs(d[(ll)- 1+ _d_offset])-shift.val)*(((d[(ll)- 1+ _d_offset]) >= 0 ? Math.abs(one) : -Math.abs(one))+shift.val/d[(ll)- 1+ _d_offset]);
g = e[(ll)- 1+ _e_offset];
Dlartg.dlartg(f,g,cosr,sinr,r);
f = cosr.val*d[(ll)- 1+ _d_offset]+sinr.val*e[(ll)- 1+ _e_offset];
e[(ll)- 1+ _e_offset] = cosr.val*e[(ll)- 1+ _e_offset]-sinr.val*d[(ll)- 1+ _d_offset];
g = sinr.val*d[(ll+1)- 1+ _d_offset];
d[(ll+1)- 1+ _d_offset] = cosr.val*d[(ll+1)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(ll)- 1+ _d_offset] = r.val;
f = cosl.val*e[(ll)- 1+ _e_offset]+sinl.val*d[(ll+1)- 1+ _d_offset];
d[(ll+1)- 1+ _d_offset] = cosl.val*d[(ll+1)- 1+ _d_offset]-sinl.val*e[(ll)- 1+ _e_offset];
g = sinl.val*e[(ll+1)- 1+ _e_offset];
e[(ll+1)- 1+ _e_offset] = cosl.val*e[(ll+1)- 1+ _e_offset];
work[(1)- 1+ _work_offset] = cosr.val;
work[(1+nm1)- 1+ _work_offset] = sinr.val;
work[(1+nm12)- 1+ _work_offset] = cosl.val;
work[(1+nm13)- 1+ _work_offset] = sinl.val;
irot = 1;
{
forloop130:
for (i = ll+1; i <= m-2; i++) {
Dlartg.dlartg(f,g,cosr,sinr,r);
e[(i-1)- 1+ _e_offset] = r.val;
f = cosr.val*d[(i)- 1+ _d_offset]+sinr.val*e[(i)- 1+ _e_offset];
e[(i)- 1+ _e_offset] = cosr.val*e[(i)- 1+ _e_offset]-sinr.val*d[(i)- 1+ _d_offset];
g = sinr.val*d[(i+1)- 1+ _d_offset];
d[(i+1)- 1+ _d_offset] = cosr.val*d[(i+1)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(i)- 1+ _d_offset] = r.val;
f = cosl.val*e[(i)- 1+ _e_offset]+sinl.val*d[(i+1)- 1+ _d_offset];
d[(i+1)- 1+ _d_offset] = cosl.val*d[(i+1)- 1+ _d_offset]-sinl.val*e[(i)- 1+ _e_offset];
g = sinl.val*e[(i+1)- 1+ _e_offset];
e[(i+1)- 1+ _e_offset] = cosl.val*e[(i+1)- 1+ _e_offset];
irot = irot+1;
work[(irot)- 1+ _work_offset] = cosr.val;
work[(irot+nm1)- 1+ _work_offset] = sinr.val;
work[(irot+nm12)- 1+ _work_offset] = cosl.val;
work[(irot+nm13)- 1+ _work_offset] = sinl.val;
Dummy.label("Dbdsqr",130);
}              //  Close for() loop. 
}
Dlartg.dlartg(f,g,cosr,sinr,r);
e[(m-2)- 1+ _e_offset] = r.val;
f = cosr.val*d[(m-1)- 1+ _d_offset]+sinr.val*e[(m-1)- 1+ _e_offset];
e[(m-1)- 1+ _e_offset] = cosr.val*e[(m-1)- 1+ _e_offset]-sinr.val*d[(m-1)- 1+ _d_offset];
g = sinr.val*d[(m)- 1+ _d_offset];
d[(m)- 1+ _d_offset] = cosr.val*d[(m)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(m-1)- 1+ _d_offset] = r.val;
f = cosl.val*e[(m-1)- 1+ _e_offset]+sinl.val*d[(m)- 1+ _d_offset];
d[(m)- 1+ _d_offset] = cosl.val*d[(m)- 1+ _d_offset]-sinl.val*e[(m-1)- 1+ _e_offset];
irot = irot+1;
work[(irot)- 1+ _work_offset] = cosr.val;
work[(irot+nm1)- 1+ _work_offset] = sinr.val;
work[(irot+nm12)- 1+ _work_offset] = cosl.val;
work[(irot+nm13)- 1+ _work_offset] = sinl.val;
e[(m-1)- 1+ _e_offset] = f;
// *
// *           Update singular vectors
// *
if (ncvt > 0)  
    Dlasr.dlasr("L","V","F",m-ll+1,ncvt,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,vt,(ll)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
if (nru > 0)  
    Dlasr.dlasr("R","V","F",nru,m-ll+1,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,u,(1)- 1+(ll- 1)*ldu+ _u_offset,ldu);
if (ncc > 0)  
    Dlasr.dlasr("L","V","F",m-ll+1,ncc,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,c,(ll)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
// *
// *           Test convergence
// *
if (Math.abs(e[(m-1)- 1+ _e_offset]) <= thresh)  
    e[(m-1)- 1+ _e_offset] = zero;
// *
}              // Close if()
else  {
  // *
// *           Chase bulge from bottom to top
// *           Save cosines and sines for later singular vector updates
// *
f = (Math.abs(d[(m)- 1+ _d_offset])-shift.val)*(((d[(m)- 1+ _d_offset]) >= 0 ? Math.abs(one) : -Math.abs(one))+shift.val/d[(m)- 1+ _d_offset]);
g = e[(m-1)- 1+ _e_offset];
Dlartg.dlartg(f,g,cosr,sinr,r);
f = cosr.val*d[(m)- 1+ _d_offset]+sinr.val*e[(m-1)- 1+ _e_offset];
e[(m-1)- 1+ _e_offset] = cosr.val*e[(m-1)- 1+ _e_offset]-sinr.val*d[(m)- 1+ _d_offset];
g = sinr.val*d[(m-1)- 1+ _d_offset];
d[(m-1)- 1+ _d_offset] = cosr.val*d[(m-1)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(m)- 1+ _d_offset] = r.val;
f = cosl.val*e[(m-1)- 1+ _e_offset]+sinl.val*d[(m-1)- 1+ _d_offset];
d[(m-1)- 1+ _d_offset] = cosl.val*d[(m-1)- 1+ _d_offset]-sinl.val*e[(m-1)- 1+ _e_offset];
g = sinl.val*e[(m-2)- 1+ _e_offset];
e[(m-2)- 1+ _e_offset] = cosl.val*e[(m-2)- 1+ _e_offset];
work[(m-ll)- 1+ _work_offset] = cosr.val;
work[(m-ll+nm1)- 1+ _work_offset] = -sinr.val;
work[(m-ll+nm12)- 1+ _work_offset] = cosl.val;
work[(m-ll+nm13)- 1+ _work_offset] = -sinl.val;
irot = m-ll;
{
int _i_inc = -1;
forloop140:
for (i = m-1; i >= ll+2; i += _i_inc) {
Dlartg.dlartg(f,g,cosr,sinr,r);
e[(i)- 1+ _e_offset] = r.val;
f = cosr.val*d[(i)- 1+ _d_offset]+sinr.val*e[(i-1)- 1+ _e_offset];
e[(i-1)- 1+ _e_offset] = cosr.val*e[(i-1)- 1+ _e_offset]-sinr.val*d[(i)- 1+ _d_offset];
g = sinr.val*d[(i-1)- 1+ _d_offset];
d[(i-1)- 1+ _d_offset] = cosr.val*d[(i-1)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(i)- 1+ _d_offset] = r.val;
f = cosl.val*e[(i-1)- 1+ _e_offset]+sinl.val*d[(i-1)- 1+ _d_offset];
d[(i-1)- 1+ _d_offset] = cosl.val*d[(i-1)- 1+ _d_offset]-sinl.val*e[(i-1)- 1+ _e_offset];
g = sinl.val*e[(i-2)- 1+ _e_offset];
e[(i-2)- 1+ _e_offset] = cosl.val*e[(i-2)- 1+ _e_offset];
irot = irot-1;
work[(irot)- 1+ _work_offset] = cosr.val;
work[(irot+nm1)- 1+ _work_offset] = -sinr.val;
work[(irot+nm12)- 1+ _work_offset] = cosl.val;
work[(irot+nm13)- 1+ _work_offset] = -sinl.val;
Dummy.label("Dbdsqr",140);
}              //  Close for() loop. 
}
Dlartg.dlartg(f,g,cosr,sinr,r);
e[(ll+1)- 1+ _e_offset] = r.val;
f = cosr.val*d[(ll+1)- 1+ _d_offset]+sinr.val*e[(ll)- 1+ _e_offset];
e[(ll)- 1+ _e_offset] = cosr.val*e[(ll)- 1+ _e_offset]-sinr.val*d[(ll+1)- 1+ _d_offset];
g = sinr.val*d[(ll)- 1+ _d_offset];
d[(ll)- 1+ _d_offset] = cosr.val*d[(ll)- 1+ _d_offset];
Dlartg.dlartg(f,g,cosl,sinl,r);
d[(ll+1)- 1+ _d_offset] = r.val;
f = cosl.val*e[(ll)- 1+ _e_offset]+sinl.val*d[(ll)- 1+ _d_offset];
d[(ll)- 1+ _d_offset] = cosl.val*d[(ll)- 1+ _d_offset]-sinl.val*e[(ll)- 1+ _e_offset];
irot = irot-1;
work[(irot)- 1+ _work_offset] = cosr.val;
work[(irot+nm1)- 1+ _work_offset] = -sinr.val;
work[(irot+nm12)- 1+ _work_offset] = cosl.val;
work[(irot+nm13)- 1+ _work_offset] = -sinl.val;
e[(ll)- 1+ _e_offset] = f;
// *
// *           Test convergence
// *
if (Math.abs(e[(ll)- 1+ _e_offset]) <= thresh)  
    e[(ll)- 1+ _e_offset] = zero;
// *
// *           Update singular vectors if desired
// *
if (ncvt > 0)  
    Dlasr.dlasr("L","V","B",m-ll+1,ncvt,work,(nm12+1)- 1+ _work_offset,work,(nm13+1)- 1+ _work_offset,vt,(ll)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
if (nru > 0)  
    Dlasr.dlasr("R","V","B",nru,m-ll+1,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,u,(1)- 1+(ll- 1)*ldu+ _u_offset,ldu);
if (ncc > 0)  
    Dlasr.dlasr("L","V","B",m-ll+1,ncc,work,(1)- 1+ _work_offset,work,(n)- 1+ _work_offset,c,(ll)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
}              //  Close else.
}              //  Close else.
// *
// *     QR iteration finished, go back and check convergence
// *
Dummy.go_to("Dbdsqr",50);
// *
// *     All singular values converged, so make them positive
// *
label150:
   Dummy.label("Dbdsqr",150);
{
forloop160:
for (i = 1; i <= n; i++) {
if (d[(i)- 1+ _d_offset] < zero)  {
    d[(i)- 1+ _d_offset] = -d[(i)- 1+ _d_offset];
// *
// *           Change sign of singular vectors, if desired
// *
if (ncvt > 0)  
    Dscal.dscal(ncvt,negone,vt,(i)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
}              // Close if()
Dummy.label("Dbdsqr",160);
}              //  Close for() loop. 
}
// *
// *     Sort the singular values into decreasing order (insertion sort on
// *     singular values, but only one transposition per singular vector)
// *
{
forloop180:
for (i = 1; i <= n-1; i++) {
// *
// *        Scan for smallest D(I)
// *
Isub = 1;
smin = d[(1)- 1+ _d_offset];
{
forloop170:
for (j = 2; j <= n+1-i; j++) {
if (d[(j)- 1+ _d_offset] <= smin)  {
    Isub = j;
smin = d[(j)- 1+ _d_offset];
}              // Close if()
Dummy.label("Dbdsqr",170);
}              //  Close for() loop. 
}
if (Isub != n+1-i)  {
    // *
// *           Swap singular values and vectors
// *
d[(Isub)- 1+ _d_offset] = d[(n+1-i)- 1+ _d_offset];
d[(n+1-i)- 1+ _d_offset] = smin;
if (ncvt > 0)  
    Dswap.dswap(ncvt,vt,(Isub)- 1+(1- 1)*ldvt+ _vt_offset,ldvt,vt,(n+1-i)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
if (nru > 0)  
    Dswap.dswap(nru,u,(1)- 1+(Isub- 1)*ldu+ _u_offset,1,u,(1)- 1+(n+1-i- 1)*ldu+ _u_offset,1);
if (ncc > 0)  
    Dswap.dswap(ncc,c,(Isub)- 1+(1- 1)*Ldc+ _c_offset,Ldc,c,(n+1-i)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
}              // Close if()
Dummy.label("Dbdsqr",180);
}              //  Close for() loop. 
}
Dummy.go_to("Dbdsqr",210);
// *
// *     Maximum number of iterations exceeded, failure to converge
// *
label190:
   Dummy.label("Dbdsqr",190);
info.val = 0;
{
forloop200:
for (i = 1; i <= n-1; i++) {
if (e[(i)- 1+ _e_offset] != zero)  
    info.val = info.val+1;
Dummy.label("Dbdsqr",200);
}              //  Close for() loop. 
}
label210:
   Dummy.label("Dbdsqr",210);
Dummy.go_to("Dbdsqr",999999);
// *
// *     End of DBDSQR
// *
Dummy.label("Dbdsqr",999999);
return;
   }
// adapter for dlartg
private static void dlartg_adapter(double arg0 ,double arg1 ,doubleW arg2 ,doubleW arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlartg.dlartg(arg0,arg1,arg2,arg3,_f2j_tmp4);

arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
