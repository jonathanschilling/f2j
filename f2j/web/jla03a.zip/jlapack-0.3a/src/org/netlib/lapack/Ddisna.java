/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Ddisna {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDISNA computes the reciprocal condition numbers for the eigenvectors
// *  of a real symmetric or complex Hermitian matrix or for the left or
// *  right singular vectors of a general m-by-n matrix. The reciprocal
// *  condition number is the 'gap' between the corresponding eigenvalue or
// *  singular value and the nearest other one.
// *
// *  The bound on the error, measured by angle in radians, in the I-th
// *  computed vector is given by
// *
// *         DLAMCH( 'E' ) * ( ANORM / SEP( I ) )
// *
// *  where ANORM = 2-norm(A) = max( abs( D(j) ) ).  SEP(I) is not allowed
// *  to be smaller than DLAMCH( 'E' )*ANORM in order to limit the size of
// *  the error bound.
// *
// *  DDISNA may also be used to compute error bounds for eigenvectors of
// *  the generalized symmetric definite eigenproblem.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          Specifies for which problem the reciprocal condition numbers
// *          should be computed:
// *          = 'E':  the eigenvectors of a symmetric/Hermitian matrix;
// *          = 'L':  the left singular vectors of a general matrix;
// *          = 'R':  the right singular vectors of a general matrix.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix. M >= 0.
// *
// *  N       (input) INTEGER
// *          If JOB = 'L' or 'R', the number of columns of the matrix,
// *          in which case N >= 0. Ignored if JOB = 'E'.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (M) if JOB = 'E'
// *                              dimension (min(M,N)) if JOB = 'L' or 'R'
// *          The eigenvalues (if JOB = 'E') or singular values (if JOB =
// *          'L' or 'R') of the matrix, in either increasing or decreasing
// *          order. If singular values, they must be non-negative.
// *
// *  SEP     (output) DOUBLE PRECISION array, dimension (M) if JOB = 'E'
// *                               dimension (min(M,N)) if JOB = 'L' or 'R'
// *          The reciprocal condition numbers of the vectors.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean decr= false;
static boolean eigen= false;
static boolean incr= false;
static boolean left= false;
static boolean right= false;
static boolean sing= false;
static int i= 0;
static int k= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double newgap= 0.0;
static double oldgap= 0.0;
static double safmin= 0.0;
static double thresh= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void ddisna (String job,
int m,
int n,
double [] d, int _d_offset,
double [] sep, int _sep_offset,
intW info)  {

info.val = 0;
eigen = (job.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0));
left = (job.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0));
right = (job.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0));
sing = left || right;
if (eigen)  {
    k = m;
}              // Close if()
else if (sing)  {
    k = (int)(Math.min(m, n) );
}              // Close else if()
if (!eigen && !sing)  {
    info.val = -1;
}              // Close if()
else if (m < 0)  {
    info.val = -2;
}              // Close else if()
else if (k < 0)  {
    info.val = -3;
}              // Close else if()
else  {
  incr = true;
decr = true;
{
forloop10:
for (i = 1; i <= k-1; i++) {
if (incr)  
    incr = incr && d[(i)- 1+ _d_offset] <= d[(i+1)- 1+ _d_offset];
if (decr)  
    decr = decr && d[(i)- 1+ _d_offset] >= d[(i+1)- 1+ _d_offset];
Dummy.label("Ddisna",10);
}              //  Close for() loop. 
}
if (sing && k > 0)  {
    if (incr)  
    incr = incr && zero <= d[(1)- 1+ _d_offset];
if (decr)  
    decr = decr && d[(k)- 1+ _d_offset] >= zero;
}              // Close if()
if (!(incr || decr))  
    info.val = -4;
}              //  Close else.
if (info.val != 0)  {
    Xerbla.xerbla("DDISNA",-info.val);
Dummy.go_to("Ddisna",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (k == 0)  
    Dummy.go_to("Ddisna",999999);
// *
// *     Compute reciprocal condition numbers
// *
if (k == 1)  {
    sep[(1)- 1+ _sep_offset] = Dlamch.dlamch("O");
}              // Close if()
else  {
  oldgap = Math.abs(d[(2)- 1+ _d_offset]-d[(1)- 1+ _d_offset]);
sep[(1)- 1+ _sep_offset] = oldgap;
{
forloop20:
for (i = 2; i <= k-1; i++) {
newgap = Math.abs(d[(i+1)- 1+ _d_offset]-d[(i)- 1+ _d_offset]);
sep[(i)- 1+ _sep_offset] = Math.min(oldgap, newgap) ;
oldgap = newgap;
Dummy.label("Ddisna",20);
}              //  Close for() loop. 
}
sep[(k)- 1+ _sep_offset] = oldgap;
}              //  Close else.
if (sing)  {
    if ((left && m > n) || (right && m < n))  {
    if (incr)  
    sep[(1)- 1+ _sep_offset] = Math.min(sep[(1)- 1+ _sep_offset], d[(1)- 1+ _d_offset]) ;
if (decr)  
    sep[(k)- 1+ _sep_offset] = Math.min(sep[(k)- 1+ _sep_offset], d[(k)- 1+ _d_offset]) ;
}              // Close if()
}              // Close if()
// *
// *     Ensure that reciprocal condition numbers are not less than
// *     threshold, in order to limit the size of the error bound
// *
eps = Dlamch.dlamch("E");
safmin = Dlamch.dlamch("S");
anorm = Math.max(Math.abs(d[(1)- 1+ _d_offset]), Math.abs(d[(k)- 1+ _d_offset])) ;
if (anorm == zero)  {
    thresh = eps;
}              // Close if()
else  {
  thresh = Math.max(eps*anorm, safmin) ;
}              //  Close else.
{
forloop30:
for (i = 1; i <= k; i++) {
sep[(i)- 1+ _sep_offset] = Math.max(sep[(i)- 1+ _sep_offset], thresh) ;
Dummy.label("Ddisna",30);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Ddisna",999999);
// *
// *     End of DDISNA
// *
Dummy.label("Ddisna",999999);
return;
   }
} // End class.
