/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbbrd {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBBRD reduces a real general m-by-n band matrix A to upper
// *  bidiagonal form B by an orthogonal transformation: Q' * A * P = B.
// *
// *  The routine computes B, and optionally forms Q or P', or computes
// *  Q'*C for a given matrix C.
// *
// *  Arguments
// *  =========
// *
// *  VECT    (input) CHARACTER*1
// *          Specifies whether or not the matrices Q and P' are to be
// *          formed.
// *          = 'N': do not form Q or P';
// *          = 'Q': form Q only;
// *          = 'P': form P' only;
// *          = 'B': form both.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  NCC     (input) INTEGER
// *          The number of columns of the matrix C.  NCC >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals of the matrix A. KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals of the matrix A. KU >= 0.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          On entry, the m-by-n band matrix A, stored in rows 1 to
// *          KL+KU+1. The j-th column of A is stored in the j-th column of
// *          the array AB as follows:
// *          AB(ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(m,j+kl).
// *          On exit, A is overwritten by values generated during the
// *          reduction.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array A. LDAB >= KL+KU+1.
// *
// *  D       (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The diagonal elements of the bidiagonal matrix B.
// *
// *  E       (output) DOUBLE PRECISION array, dimension (min(M,N)-1)
// *          The superdiagonal elements of the bidiagonal matrix B.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDQ,M)
// *          If VECT = 'Q' or 'B', the m-by-m orthogonal matrix Q.
// *          If VECT = 'N' or 'P', the array Q is not referenced.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.
// *          LDQ >= max(1,M) if VECT = 'Q' or 'B'; LDQ >= 1 otherwise.
// *
// *  PT      (output) DOUBLE PRECISION array, dimension (LDPT,N)
// *          If VECT = 'P' or 'B', the n-by-n orthogonal matrix P'.
// *          If VECT = 'N' or 'Q', the array PT is not referenced.
// *
// *  LDPT    (input) INTEGER
// *          The leading dimension of the array PT.
// *          LDPT >= max(1,N) if VECT = 'P' or 'B'; LDPT >= 1 otherwise.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC,NCC)
// *          On entry, an m-by-ncc matrix C.
// *          On exit, C is overwritten by Q'*C.
// *          C is not referenced if NCC = 0.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C.
// *          LDC >= max(1,M) if NCC > 0; LDC >= 1 if NCC = 0.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*max(M,N))
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean wantb= false;
static boolean wantc= false;
static boolean wantpt= false;
static boolean wantq= false;
static int i= 0;
static int inca= 0;
static int j= 0;
static int j1= 0;
static int j2= 0;
static int kb= 0;
static int kb1= 0;
static int kk= 0;
static int klm= 0;
static int klu1= 0;
static int kun= 0;
static int l= 0;
static int minmn= 0;
static int ml= 0;
static int ml0= 0;
static int mn= 0;
static int mu= 0;
static int mu0= 0;
static int nr= 0;
static int nrt= 0;
static doubleW ra= new doubleW(0.0);
static double rb= 0.0;
static doubleW rc= new doubleW(0.0);
static doubleW rs= new doubleW(0.0);
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dgbbrd (String vect,
int m,
int n,
int ncc,
int kl,
int ku,
double [] ab, int _ab_offset,
int ldab,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] q, int _q_offset,
int ldq,
double [] pt, int _pt_offset,
int ldpt,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset,
intW info)  {

wantb = (vect.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
wantq = (vect.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0)) || wantb;
wantpt = (vect.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) || wantb;
wantc = ncc > 0;
klu1 = kl+ku+1;
info.val = 0;
if (!wantq && !wantpt && !(vect.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (m < 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (ncc < 0)  {
    info.val = -4;
}              // Close else if()
else if (kl < 0)  {
    info.val = -5;
}              // Close else if()
else if (ku < 0)  {
    info.val = -6;
}              // Close else if()
else if (ldab < klu1)  {
    info.val = -8;
}              // Close else if()
else if (ldq < 1 || wantq && ldq < Math.max(1, m) )  {
    info.val = -12;
}              // Close else if()
else if (ldpt < 1 || wantpt && ldpt < Math.max(1, n) )  {
    info.val = -14;
}              // Close else if()
else if (Ldc < 1 || wantc && Ldc < Math.max(1, m) )  {
    info.val = -16;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBBRD",-info.val);
Dummy.go_to("Dgbbrd",999999);
}              // Close if()
// *
// *     Initialize Q and P' to the unit matrix, if needed
// *
if (wantq)  
    Dlaset.dlaset("Full",m,m,zero,one,q,_q_offset,ldq);
if (wantpt)  
    Dlaset.dlaset("Full",n,n,zero,one,pt,_pt_offset,ldpt);
// *
// *     Quick return if possible.
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dgbbrd",999999);
// *
minmn = (int)(Math.min(m, n) );
// *
if (kl+ku > 1)  {
    // *
// *        Reduce to upper bidiagonal form if KU > 0; if KU = 0, reduce
// *        first to lower bidiagonal form and then transform to upper
// *        bidiagonal
// *
if (ku > 0)  {
    ml0 = 1;
mu0 = 2;
}              // Close if()
else  {
  ml0 = 2;
mu0 = 1;
}              //  Close else.
// *
// *        Wherever possible, plane rotations are generated and applied in
// *        vector operations of length NR over the index set J1:J2:KLU1.
// *
// *        The sines of the plane rotations are stored in WORK(1:max(m,n))
// *        and the cosines in WORK(max(m,n)+1:2*max(m,n)).
// *
mn = (int)(Math.max(m, n) );
klm = (int)(Math.min(m-1, kl) );
kun = (int)(Math.min(n-1, ku) );
kb = klm+kun;
kb1 = kb+1;
inca = kb1*ldab;
nr = 0;
j1 = klm+2;
j2 = 1-kun;
// *
{
forloop90:
for (i = 1; i <= minmn; i++) {
// *
// *           Reduce i-th column and i-th row of matrix to bidiagonal form
// *
ml = klm+1;
mu = kun+1;
{
forloop80:
for (kk = 1; kk <= kb; kk++) {
j1 = j1+kb;
j2 = j2+kb;
// *
// *              generate plane rotations to annihilate nonzero elements
// *              which have been created below the band
// *
if (nr > 0)  
    Dlargv.dlargv(nr,ab,(klu1)- 1+(j1-klm-1- 1)*ldab+ _ab_offset,inca,work,(j1)- 1+ _work_offset,kb1,work,(mn+j1)- 1+ _work_offset,kb1);
// *
// *              apply plane rotations from the left
// *
{
forloop10:
for (l = 1; l <= kb; l++) {
if (j2-klm+l-1 > n)  {
    nrt = nr-1;
}              // Close if()
else  {
  nrt = nr;
}              //  Close else.
if (nrt > 0)  
    Dlartv.dlartv(nrt,ab,(klu1-l)- 1+(j1-klm+l-1- 1)*ldab+ _ab_offset,inca,ab,(klu1-l+1)- 1+(j1-klm+l-1- 1)*ldab+ _ab_offset,inca,work,(mn+j1)- 1+ _work_offset,work,(j1)- 1+ _work_offset,kb1);
Dummy.label("Dgbbrd",10);
}              //  Close for() loop. 
}
// *
if (ml > ml0)  {
    if (ml <= m-i+1)  {
    // *
// *                    generate plane rotation to annihilate a(i+ml-1,i)
// *                    within the band, and apply rotation from the left
// *
dlartg_adapter(ab[(ku+ml-1)- 1+(i- 1)*ldab+ _ab_offset],ab[(ku+ml)- 1+(i- 1)*ldab+ _ab_offset],work,(mn+i+ml-1)- 1+ _work_offset,work,(i+ml-1)- 1+ _work_offset,ra);
ab[(ku+ml-1)- 1+(i- 1)*ldab+ _ab_offset] = ra.val;
if (i < n)  
    Drot.drot((int) ( Math.min(ku+ml-2, n-i) ),ab,(ku+ml-2)- 1+(i+1- 1)*ldab+ _ab_offset,ldab-1,ab,(ku+ml-1)- 1+(i+1- 1)*ldab+ _ab_offset,ldab-1,work[(mn+i+ml-1)- 1+ _work_offset],work[(i+ml-1)- 1+ _work_offset]);
}              // Close if()
nr = nr+1;
j1 = j1-kb1;
}              // Close if()
// *
if (wantq)  {
    // *
// *                 accumulate product of plane rotations in Q
// *
{
int _j_inc = kb1;
forloop20:
for (j = j1; (_j_inc < 0) ? j >= j2 : j <= j2; j += _j_inc) {
Drot.drot(m,q,(1)- 1+(j-1- 1)*ldq+ _q_offset,1,q,(1)- 1+(j- 1)*ldq+ _q_offset,1,work[(mn+j)- 1+ _work_offset],work[(j)- 1+ _work_offset]);
Dummy.label("Dgbbrd",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (wantc)  {
    // *
// *                 apply plane rotations to C
// *
{
int _j_inc = kb1;
forloop30:
for (j = j1; (_j_inc < 0) ? j >= j2 : j <= j2; j += _j_inc) {
Drot.drot(ncc,c,(j-1)- 1+(1- 1)*Ldc+ _c_offset,Ldc,c,(j)- 1+(1- 1)*Ldc+ _c_offset,Ldc,work[(mn+j)- 1+ _work_offset],work[(j)- 1+ _work_offset]);
Dummy.label("Dgbbrd",30);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (j2+kun > n)  {
    // *
// *                 adjust J2 to keep within the bounds of the matrix
// *
nr = nr-1;
j2 = j2-kb1;
}              // Close if()
// *
{
int _j_inc = kb1;
forloop40:
for (j = j1; (_j_inc < 0) ? j >= j2 : j <= j2; j += _j_inc) {
// *
// *                 create nonzero element a(j-1,j+ku) above the band
// *                 and store it in WORK(n+1:2*n)
// *
work[(j+kun)- 1+ _work_offset] = work[(j)- 1+ _work_offset]*ab[(1)- 1+(j+kun- 1)*ldab+ _ab_offset];
ab[(1)- 1+(j+kun- 1)*ldab+ _ab_offset] = work[(mn+j)- 1+ _work_offset]*ab[(1)- 1+(j+kun- 1)*ldab+ _ab_offset];
Dummy.label("Dgbbrd",40);
}              //  Close for() loop. 
}
// *
// *              generate plane rotations to annihilate nonzero elements
// *              which have been generated above the band
// *
if (nr > 0)  
    Dlargv.dlargv(nr,ab,(1)- 1+(j1+kun-1- 1)*ldab+ _ab_offset,inca,work,(j1+kun)- 1+ _work_offset,kb1,work,(mn+j1+kun)- 1+ _work_offset,kb1);
// *
// *              apply plane rotations from the right
// *
{
forloop50:
for (l = 1; l <= kb; l++) {
if (j2+l-1 > m)  {
    nrt = nr-1;
}              // Close if()
else  {
  nrt = nr;
}              //  Close else.
if (nrt > 0)  
    Dlartv.dlartv(nrt,ab,(l+1)- 1+(j1+kun-1- 1)*ldab+ _ab_offset,inca,ab,(l)- 1+(j1+kun- 1)*ldab+ _ab_offset,inca,work,(mn+j1+kun)- 1+ _work_offset,work,(j1+kun)- 1+ _work_offset,kb1);
Dummy.label("Dgbbrd",50);
}              //  Close for() loop. 
}
// *
if (ml == ml0 && mu > mu0)  {
    if (mu <= n-i+1)  {
    // *
// *                    generate plane rotation to annihilate a(i,i+mu-1)
// *                    within the band, and apply rotation from the right
// *
dlartg_adapter(ab[(ku-mu+3)- 1+(i+mu-2- 1)*ldab+ _ab_offset],ab[(ku-mu+2)- 1+(i+mu-1- 1)*ldab+ _ab_offset],work,(mn+i+mu-1)- 1+ _work_offset,work,(i+mu-1)- 1+ _work_offset,ra);
ab[(ku-mu+3)- 1+(i+mu-2- 1)*ldab+ _ab_offset] = ra.val;
Drot.drot((int) ( Math.min(kl+mu-2, m-i) ),ab,(ku-mu+4)- 1+(i+mu-2- 1)*ldab+ _ab_offset,1,ab,(ku-mu+3)- 1+(i+mu-1- 1)*ldab+ _ab_offset,1,work[(mn+i+mu-1)- 1+ _work_offset],work[(i+mu-1)- 1+ _work_offset]);
}              // Close if()
nr = nr+1;
j1 = j1-kb1;
}              // Close if()
// *
if (wantpt)  {
    // *
// *                 accumulate product of plane rotations in P'
// *
{
int _j_inc = kb1;
forloop60:
for (j = j1; (_j_inc < 0) ? j >= j2 : j <= j2; j += _j_inc) {
Drot.drot(n,pt,(j+kun-1)- 1+(1- 1)*ldpt+ _pt_offset,ldpt,pt,(j+kun)- 1+(1- 1)*ldpt+ _pt_offset,ldpt,work[(mn+j+kun)- 1+ _work_offset],work[(j+kun)- 1+ _work_offset]);
Dummy.label("Dgbbrd",60);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (j2+kb > m)  {
    // *
// *                 adjust J2 to keep within the bounds of the matrix
// *
nr = nr-1;
j2 = j2-kb1;
}              // Close if()
// *
{
int _j_inc = kb1;
forloop70:
for (j = j1; (_j_inc < 0) ? j >= j2 : j <= j2; j += _j_inc) {
// *
// *                 create nonzero element a(j+kl+ku,j+ku-1) below the
// *                 band and store it in WORK(1:n)
// *
work[(j+kb)- 1+ _work_offset] = work[(j+kun)- 1+ _work_offset]*ab[(klu1)- 1+(j+kun- 1)*ldab+ _ab_offset];
ab[(klu1)- 1+(j+kun- 1)*ldab+ _ab_offset] = work[(mn+j+kun)- 1+ _work_offset]*ab[(klu1)- 1+(j+kun- 1)*ldab+ _ab_offset];
Dummy.label("Dgbbrd",70);
}              //  Close for() loop. 
}
// *
if (ml > ml0)  {
    ml = ml-1;
}              // Close if()
else  {
  mu = mu-1;
}              //  Close else.
Dummy.label("Dgbbrd",80);
}              //  Close for() loop. 
}
Dummy.label("Dgbbrd",90);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (ku == 0 && kl > 0)  {
    // *
// *        A has been reduced to lower bidiagonal form
// *
// *        Transform lower bidiagonal form to upper bidiagonal by applying
// *        plane rotations from the left, storing diagonal elements in D
// *        and off-diagonal elements in E
// *
{
forloop100:
for (i = 1; i <= Math.min(m-1, n) ; i++) {
Dlartg.dlartg(ab[(1)- 1+(i- 1)*ldab+ _ab_offset],ab[(2)- 1+(i- 1)*ldab+ _ab_offset],rc,rs,ra);
d[(i)- 1+ _d_offset] = ra.val;
if (i < n)  {
    e[(i)- 1+ _e_offset] = rs.val*ab[(1)- 1+(i+1- 1)*ldab+ _ab_offset];
ab[(1)- 1+(i+1- 1)*ldab+ _ab_offset] = rc.val*ab[(1)- 1+(i+1- 1)*ldab+ _ab_offset];
}              // Close if()
if (wantq)  
    Drot.drot(m,q,(1)- 1+(i- 1)*ldq+ _q_offset,1,q,(1)- 1+(i+1- 1)*ldq+ _q_offset,1,rc.val,rs.val);
if (wantc)  
    Drot.drot(ncc,c,(i)- 1+(1- 1)*Ldc+ _c_offset,Ldc,c,(i+1)- 1+(1- 1)*Ldc+ _c_offset,Ldc,rc.val,rs.val);
Dummy.label("Dgbbrd",100);
}              //  Close for() loop. 
}
if (m <= n)  
    d[(m)- 1+ _d_offset] = ab[(1)- 1+(m- 1)*ldab+ _ab_offset];
}              // Close if()
else if (ku > 0)  {
    // *
// *        A has been reduced to upper bidiagonal form
// *
if (m < n)  {
    // *
// *           Annihilate a(m,m+1) by applying plane rotations from the
// *           right, storing diagonal elements in D and off-diagonal
// *           elements in E
// *
rb = ab[(ku)- 1+(m+1- 1)*ldab+ _ab_offset];
{
int _i_inc = -1;
forloop110:
for (i = m; i >= 1; i += _i_inc) {
Dlartg.dlartg(ab[(ku+1)- 1+(i- 1)*ldab+ _ab_offset],rb,rc,rs,ra);
d[(i)- 1+ _d_offset] = ra.val;
if (i > 1)  {
    rb = -rs.val*ab[(ku)- 1+(i- 1)*ldab+ _ab_offset];
e[(i-1)- 1+ _e_offset] = rc.val*ab[(ku)- 1+(i- 1)*ldab+ _ab_offset];
}              // Close if()
if (wantpt)  
    Drot.drot(n,pt,(i)- 1+(1- 1)*ldpt+ _pt_offset,ldpt,pt,(m+1)- 1+(1- 1)*ldpt+ _pt_offset,ldpt,rc.val,rs.val);
Dummy.label("Dgbbrd",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Copy off-diagonal elements to E and diagonal elements to D
// *
{
forloop120:
for (i = 1; i <= minmn-1; i++) {
e[(i)- 1+ _e_offset] = ab[(ku)- 1+(i+1- 1)*ldab+ _ab_offset];
Dummy.label("Dgbbrd",120);
}              //  Close for() loop. 
}
{
forloop130:
for (i = 1; i <= minmn; i++) {
d[(i)- 1+ _d_offset] = ab[(ku+1)- 1+(i- 1)*ldab+ _ab_offset];
Dummy.label("Dgbbrd",130);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else  {
  // *
// *        A is diagonal. Set elements of E to zero and copy diagonal
// *        elements to D.
// *
{
forloop140:
for (i = 1; i <= minmn-1; i++) {
e[(i)- 1+ _e_offset] = zero;
Dummy.label("Dgbbrd",140);
}              //  Close for() loop. 
}
{
forloop150:
for (i = 1; i <= minmn; i++) {
d[(i)- 1+ _d_offset] = ab[(1)- 1+(i- 1)*ldab+ _ab_offset];
Dummy.label("Dgbbrd",150);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dgbbrd",999999);
// *
// *     End of DGBBRD
// *
Dummy.label("Dgbbrd",999999);
return;
   }
// adapter for dlartg
private static void dlartg_adapter(double arg0 ,double arg1 ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,doubleW arg4 )
{
doubleW _f2j_tmp2 = new doubleW(arg2[arg2_offset]);
doubleW _f2j_tmp3 = new doubleW(arg3[arg3_offset]);

Dlartg.dlartg(arg0,arg1,_f2j_tmp2,_f2j_tmp3,arg4);

arg2[arg2_offset] = _f2j_tmp2.val;
arg3[arg3_offset] = _f2j_tmp3.val;
}

} // End class.
