/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbcon {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBCON estimates the reciprocal of the condition number of a real
// *  general band matrix A, in either the 1-norm or the infinity-norm,
// *  using the LU factorization computed by DGBTRF.
// *
// *  An estimate is obtained for norm(inv(A)), and the reciprocal of the
// *  condition number is computed as
// *     RCOND = 1 / ( norm(A) * norm(inv(A)) ).
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies whether the 1-norm condition number or the
// *          infinity-norm condition number is required:
// *          = '1' or 'O':  1-norm;
// *          = 'I':         Infinity-norm.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          Details of the LU factorization of the band matrix A, as
// *          computed by DGBTRF.  U is stored as an upper triangular band
// *          matrix with KL+KU superdiagonals in rows 1 to KL+KU+1, and
// *          the multipliers used during the factorization are stored in
// *          rows KL+KU+2 to 2*KL+KU+1.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= 2*KL+KU+1.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= N, row i of the matrix was
// *          interchanged with row IPIV(i).
// *
// *  ANORM   (input) DOUBLE PRECISION
// *          If NORM = '1' or 'O', the 1-norm of the original matrix A.
// *          If NORM = 'I', the infinity-norm of the original matrix A.
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of the matrix A,
// *          computed as RCOND = 1/(norm(A) * norm(inv(A))).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean lnoti= false;
static boolean onenrm= false;
static String normin= new String(" ");
static int ix= 0;
static int j= 0;
static int jp= 0;
static intW kase= new intW(0);
static int kase1= 0;
static int kd= 0;
static int lm= 0;
static doubleW ainvnm= new doubleW(0.0);
static doubleW scale= new doubleW(0.0);
static double smlnum= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgbcon (String norm,
int n,
int kl,
int ku,
double [] ab, int _ab_offset,
int ldab,
int [] ipiv, int _ipiv_offset,
double anorm,
doubleW rcond,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
onenrm = norm.trim().equalsIgnoreCase("1".trim()) || (norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0));
if (!onenrm && !(norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0)  {
    info.val = -4;
}              // Close else if()
else if (ldab < 2*kl+ku+1)  {
    info.val = -6;
}              // Close else if()
else if (anorm < zero)  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBCON",-info.val);
Dummy.go_to("Dgbcon",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
rcond.val = zero;
if (n == 0)  {
    rcond.val = one;
Dummy.go_to("Dgbcon",999999);
}              // Close if()
else if (anorm == zero)  {
    Dummy.go_to("Dgbcon",999999);
}              // Close else if()
// *
smlnum = Dlamch.dlamch("Safe minimum");
// *
// *     Estimate the norm of inv(A).
// *
ainvnm.val = zero;
normin = "N";
if (onenrm)  {
    kase1 = 1;
}              // Close if()
else  {
  kase1 = 2;
}              //  Close else.
kd = kl+ku+1;
lnoti = kl > 0;
kase.val = 0;
label10:
   Dummy.label("Dgbcon",10);
Dlacon.dlacon(n,work,(n+1)- 1+ _work_offset,work,_work_offset,iwork,_iwork_offset,ainvnm,kase);
if (kase.val != 0)  {
    if (kase.val == kase1)  {
    // *
// *           Multiply by inv(L).
// *
if (lnoti)  {
    {
forloop20:
for (j = 1; j <= n-1; j++) {
lm = (int)(Math.min(kl, n-j) );
jp = ipiv[(j)- 1+ _ipiv_offset];
t = work[(jp)- 1+ _work_offset];
if (jp != j)  {
    work[(jp)- 1+ _work_offset] = work[(j)- 1+ _work_offset];
work[(j)- 1+ _work_offset] = t;
}              // Close if()
Daxpy.daxpy(lm,-t,ab,(kd+1)- 1+(j- 1)*ldab+ _ab_offset,1,work,(j+1)- 1+ _work_offset,1);
Dummy.label("Dgbcon",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *           Multiply by inv(U).
// *
Dlatbs.dlatbs("Upper","No transpose","Non-unit",normin,n,kl+ku,ab,_ab_offset,ldab,work,_work_offset,scale,work,(2*n+1)- 1+ _work_offset,info);
}              // Close if()
else  {
  // *
// *           Multiply by inv(U').
// *
Dlatbs.dlatbs("Upper","Transpose","Non-unit",normin,n,kl+ku,ab,_ab_offset,ldab,work,_work_offset,scale,work,(2*n+1)- 1+ _work_offset,info);
// *
// *           Multiply by inv(L').
// *
if (lnoti)  {
    {
int _j_inc = -1;
forloop30:
for (j = n-1; j >= 1; j += _j_inc) {
lm = (int)(Math.min(kl, n-j) );
work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]-Ddot.ddot(lm,ab,(kd+1)- 1+(j- 1)*ldab+ _ab_offset,1,work,(j+1)- 1+ _work_offset,1);
jp = ipiv[(j)- 1+ _ipiv_offset];
if (jp != j)  {
    t = work[(jp)- 1+ _work_offset];
work[(jp)- 1+ _work_offset] = work[(j)- 1+ _work_offset];
work[(j)- 1+ _work_offset] = t;
}              // Close if()
Dummy.label("Dgbcon",30);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
// *
// *        Divide X by 1/SCALE if doing so will not cause overflow.
// *
normin = "Y";
if (scale.val != one)  {
    ix = Idamax.idamax(n,work,_work_offset,1);
if (scale.val < Math.abs(work[(ix)- 1+ _work_offset])*smlnum || scale.val == zero)  
    Dummy.go_to("Dgbcon",40);
Drscl.drscl(n,scale.val,work,_work_offset,1);
}              // Close if()
Dummy.go_to("Dgbcon",10);
}              // Close if()
// *
// *     Compute the estimate of the reciprocal condition number.
// *
if (ainvnm.val != zero)  
    rcond.val = (one/ainvnm.val)/anorm;
// *
label40:
   Dummy.label("Dgbcon",40);
Dummy.go_to("Dgbcon",999999);
// *
// *     End of DGBCON
// *
Dummy.label("Dgbcon",999999);
return;
   }
} // End class.
