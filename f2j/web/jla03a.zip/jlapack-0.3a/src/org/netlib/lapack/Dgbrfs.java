/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbrfs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBRFS improves the computed solution to a system of linear
// *  equations when the coefficient matrix is banded, and provides
// *  error bounds and backward error estimates for the solution.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations:
// *          = 'N':  A * X = B     (No transpose)
// *          = 'T':  A**T * X = B  (Transpose)
// *          = 'C':  A**H * X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices B and X.  NRHS >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The original band matrix A, stored in rows 1 to KL+KU+1.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(n,j+kl).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KL+KU+1.
// *
// *  AFB     (input) DOUBLE PRECISION array, dimension (LDAFB,N)
// *          Details of the LU factorization of the band matrix A, as
// *          computed by DGBTRF.  U is stored as an upper triangular band
// *          matrix with KL+KU superdiagonals in rows 1 to KL+KU+1, and
// *          the multipliers used during the factorization are stored in
// *          rows KL+KU+2 to 2*KL+KU+1.
// *
// *  LDAFB   (input) INTEGER
// *          The leading dimension of the array AFB.  LDAFB >= 2*KL*KU+1.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DGBTRF; for 1<=i<=N, row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          On entry, the solution matrix X, as computed by DGBTRS.
// *          On exit, the improved solution matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  FERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bound for each solution vector
// *          X(j) (the j-th column of the solution matrix X).
// *          If XTRUE is the true solution corresponding to X(j), FERR(j)
// *          is an estimated upper bound for the magnitude of the largest
// *          element in (X(j) - XTRUE) divided by the magnitude of the
// *          largest element in X(j).  The estimate is as reliable as
// *          the estimate for RCOND, and is almost always a slight
// *          overestimate of the true error.
// *
// *  BERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector X(j) (i.e., the smallest relative change in
// *          any element of A or B that makes X(j) an exact solution).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  Internal Parameters
// *  ===================
// *
// *  ITMAX is the maximum number of steps of iterative refinement.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int itmax= 5;
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
static double three= 3.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static String transt= new String(" ");
static int count= 0;
static int i= 0;
static int j= 0;
static int k= 0;
static intW kase= new intW(0);
static int kk= 0;
static int nz= 0;
static double eps= 0.0;
static double lstres= 0.0;
static double s= 0.0;
static double safe1= 0.0;
static double safe2= 0.0;
static double safmin= 0.0;
static double xk= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgbrfs (String trans,
int n,
int kl,
int ku,
int nrhs,
double [] ab, int _ab_offset,
int ldab,
double [] afb, int _afb_offset,
int ldafb,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0)  {
    info.val = -4;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -5;
}              // Close else if()
else if (ldab < kl+ku+1)  {
    info.val = -7;
}              // Close else if()
else if (ldafb < 2*kl+ku+1)  {
    info.val = -9;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -12;
}              // Close else if()
else if (ldx < Math.max(1, n) )  {
    info.val = -14;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBRFS",-info.val);
Dummy.go_to("Dgbrfs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0)  {
    {
forloop10:
for (j = 1; j <= nrhs; j++) {
ferr[(j)- 1+ _ferr_offset] = zero;
berr[(j)- 1+ _berr_offset] = zero;
Dummy.label("Dgbrfs",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dgbrfs",999999);
}              // Close if()
// *
if (notran)  {
    transt = "T";
}              // Close if()
else  {
  transt = "N";
}              //  Close else.
// *
// *     NZ = maximum number of nonzero elements in each row of A, plus 1
// *
nz = (int)(Math.min(kl+ku+2, n+1) );
eps = Dlamch.dlamch("Epsilon");
safmin = Dlamch.dlamch("Safe minimum");
safe1 = nz*safmin;
safe2 = safe1/eps;
// *
// *     Do for each right hand side
// *
{
forloop140:
for (j = 1; j <= nrhs; j++) {
// *
count = 1;
lstres = three;
label20:
   Dummy.label("Dgbrfs",20);
// *
// *        Loop until stopping criterion is satisfied.
// *
// *        Compute residual R = B - op(A) * X,
// *        where op(A) = A, A**T, or A**H, depending on TRANS.
// *
Dcopy.dcopy(n,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,(n+1)- 1+ _work_offset,1);
Dgbmv.dgbmv(trans,n,n,kl,ku,-one,ab,_ab_offset,ldab,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,one,work,(n+1)- 1+ _work_offset,1);
// *
// *        Compute componentwise relative backward error from formula
// *
// *        max(i) ( abs(R(i)) / ( abs(op(A))*abs(X) + abs(B) )(i) )
// *
// *        where abs(Z) is the componentwise absolute value of the matrix
// *        or vector Z.  If the i-th component of the denominator is less
// *        than SAFE2, then SAFE1 is added to the i-th components of the
// *        numerator and denominator before dividing.
// *
{
forloop30:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = Math.abs(b[(i)- 1+(j- 1)*ldb+ _b_offset]);
Dummy.label("Dgbrfs",30);
}              //  Close for() loop. 
}
// *
// *        Compute abs(op(A))*abs(X) + abs(B).
// *
if (notran)  {
    {
forloop50:
for (k = 1; k <= n; k++) {
kk = ku+1-k;
xk = Math.abs(x[(k)- 1+(j- 1)*ldx+ _x_offset]);
{
forloop40:
for (i = (int)(Math.max(1, k-ku) ); i <= Math.min(n, k+kl) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ab[(kk+i)- 1+(k- 1)*ldab+ _ab_offset])*xk;
Dummy.label("Dgbrfs",40);
}              //  Close for() loop. 
}
Dummy.label("Dgbrfs",50);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop70:
for (k = 1; k <= n; k++) {
s = zero;
kk = ku+1-k;
{
forloop60:
for (i = (int)(Math.max(1, k-ku) ); i <= Math.min(n, k+kl) ; i++) {
s = s+Math.abs(ab[(kk+i)- 1+(k- 1)*ldab+ _ab_offset])*Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset]);
Dummy.label("Dgbrfs",60);
}              //  Close for() loop. 
}
work[(k)- 1+ _work_offset] = work[(k)- 1+ _work_offset]+s;
Dummy.label("Dgbrfs",70);
}              //  Close for() loop. 
}
}              //  Close else.
s = zero;
{
forloop80:
for (i = 1; i <= n; i++) {
if (work[(i)- 1+ _work_offset] > safe2)  {
    s = Math.max(s, Math.abs(work[(n+i)- 1+ _work_offset])/work[(i)- 1+ _work_offset]) ;
}              // Close if()
else  {
  s = Math.max(s, (Math.abs(work[(n+i)- 1+ _work_offset])+safe1)/(work[(i)- 1+ _work_offset]+safe1)) ;
}              //  Close else.
Dummy.label("Dgbrfs",80);
}              //  Close for() loop. 
}
berr[(j)- 1+ _berr_offset] = s;
// *
// *        Test stopping criterion. Continue iterating if
// *           1) The residual BERR(J) is larger than machine epsilon, and
// *           2) BERR(J) decreased by at least a factor of 2 during the
// *              last iteration, and
// *           3) At most ITMAX iterations tried.
// *
if (berr[(j)- 1+ _berr_offset] > eps && two*berr[(j)- 1+ _berr_offset] <= lstres && count <= itmax)  {
    // *
// *           Update solution and try again.
// *
Dgbtrs.dgbtrs(trans,n,kl,ku,1,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
Daxpy.daxpy(n,one,work,(n+1)- 1+ _work_offset,1,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
lstres = berr[(j)- 1+ _berr_offset];
count = count+1;
Dummy.go_to("Dgbrfs",20);
}              // Close if()
// *
// *        Bound error from formula
// *
// *        norm(X - XTRUE) / norm(X) .le. FERR =
// *        norm( abs(inv(op(A)))*
// *           ( abs(R) + NZ*EPS*( abs(op(A))*abs(X)+abs(B) ))) / norm(X)
// *
// *        where
// *          norm(Z) is the magnitude of the largest component of Z
// *          inv(op(A)) is the inverse of op(A)
// *          abs(Z) is the componentwise absolute value of the matrix or
// *             vector Z
// *          NZ is the maximum number of nonzeros in any row of A, plus 1
// *          EPS is machine epsilon
// *
// *        The i-th component of abs(R)+NZ*EPS*(abs(op(A))*abs(X)+abs(B))
// *        is incremented by SAFE1 if the i-th component of
// *        abs(op(A))*abs(X) + abs(B) is less than SAFE2.
// *
// *        Use DLACON to estimate the infinity-norm of the matrix
// *           inv(op(A)) * diag(W),
// *        where W = abs(R) + NZ*EPS*( abs(op(A))*abs(X)+abs(B) )))
// *
{
forloop90:
for (i = 1; i <= n; i++) {
if (work[(i)- 1+ _work_offset] > safe2)  {
    work[(i)- 1+ _work_offset] = Math.abs(work[(n+i)- 1+ _work_offset])+nz*eps*work[(i)- 1+ _work_offset];
}              // Close if()
else  {
  work[(i)- 1+ _work_offset] = Math.abs(work[(n+i)- 1+ _work_offset])+nz*eps*work[(i)- 1+ _work_offset]+safe1;
}              //  Close else.
Dummy.label("Dgbrfs",90);
}              //  Close for() loop. 
}
// *
kase.val = 0;
label100:
   Dummy.label("Dgbrfs",100);
dlacon_adapter(n,work,(2*n+1)- 1+ _work_offset,work,(n+1)- 1+ _work_offset,iwork,_iwork_offset,ferr,(j)- 1+ _ferr_offset,kase);
if (kase.val != 0)  {
    if (kase.val == 1)  {
    // *
// *              Multiply by diag(W)*inv(op(A)**T).
// *
Dgbtrs.dgbtrs(transt,n,kl,ku,1,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
{
forloop110:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = work[(n+i)- 1+ _work_offset]*work[(i)- 1+ _work_offset];
Dummy.label("Dgbrfs",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *              Multiply by inv(op(A))*diag(W).
// *
{
forloop120:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = work[(n+i)- 1+ _work_offset]*work[(i)- 1+ _work_offset];
Dummy.label("Dgbrfs",120);
}              //  Close for() loop. 
}
Dgbtrs.dgbtrs(trans,n,kl,ku,1,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
}              //  Close else.
Dummy.go_to("Dgbrfs",100);
}              // Close if()
// *
// *        Normalize error.
// *
lstres = zero;
{
forloop130:
for (i = 1; i <= n; i++) {
lstres = Math.max(lstres, Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset])) ;
Dummy.label("Dgbrfs",130);
}              //  Close for() loop. 
}
if (lstres != zero)  
    ferr[(j)- 1+ _ferr_offset] = ferr[(j)- 1+ _ferr_offset]/lstres;
// *
Dummy.label("Dgbrfs",140);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgbrfs",999999);
// *
// *     End of DGBRFS
// *
Dummy.label("Dgbrfs",999999);
return;
   }
// adapter for dlacon
private static void dlacon_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,intW arg5 )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlacon.dlacon(arg0,arg1, arg1_offset,arg2, arg2_offset,arg3, arg3_offset,_f2j_tmp4,arg5);

arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
