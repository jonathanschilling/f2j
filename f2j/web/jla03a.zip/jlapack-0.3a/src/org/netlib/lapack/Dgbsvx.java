/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbsvx {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBSVX uses the LU factorization to compute the solution to a real
// *  system of linear equations A * X = B, A**T * X = B, or A**H * X = B,
// *  where A is a band matrix of order N with KL subdiagonals and KU
// *  superdiagonals, and X and B are N-by-NRHS matrices.
// *
// *  Error bounds on the solution and a condition estimate are also
// *  provided.
// *
// *  Description
// *  ===========
// *
// *  The following steps are performed by this subroutine:
// *
// *  1. If FACT = 'E', real scaling factors are computed to equilibrate
// *     the system:
// *        TRANS = 'N':  diag(R)*A*diag(C)     *inv(diag(C))*X = diag(R)*B
// *        TRANS = 'T': (diag(R)*A*diag(C))**T *inv(diag(R))*X = diag(C)*B
// *        TRANS = 'C': (diag(R)*A*diag(C))**H *inv(diag(R))*X = diag(C)*B
// *     Whether or not the system will be equilibrated depends on the
// *     scaling of the matrix A, but if equilibration is used, A is
// *     overwritten by diag(R)*A*diag(C) and B by diag(R)*B (if TRANS='N')
// *     or diag(C)*B (if TRANS = 'T' or 'C').
// *
// *  2. If FACT = 'N' or 'E', the LU decomposition is used to factor the
// *     matrix A (after equilibration if FACT = 'E') as
// *        A = L * U,
// *     where L is a product of permutation and unit lower triangular
// *     matrices with KL subdiagonals, and U is upper triangular with
// *     KL+KU superdiagonals.
// *
// *  3. The factored form of A is used to estimate the condition number
// *     of the matrix A.  If the reciprocal of the condition number is
// *     less than machine precision, steps 4-6 are skipped.
// *
// *  4. The system of equations is solved for X using the factored form
// *     of A.
// *
// *  5. Iterative refinement is applied to improve the computed solution
// *     matrix and calculate error bounds and backward error estimates
// *     for it.
// *
// *  6. If equilibration was used, the matrix X is premultiplied by
// *     diag(C) (if TRANS = 'N') or diag(R) (if TRANS = 'T' or 'C') so
// *     that it solves the original system before equilibration.
// *
// *  Arguments
// *  =========
// *
// *  FACT    (input) CHARACTER*1
// *          Specifies whether or not the factored form of the matrix A is
// *          supplied on entry, and if not, whether the matrix A should be
// *          equilibrated before it is factored.
// *          = 'F':  On entry, AFB and IPIV contain the factored form of
// *                  A.  If EQUED is not 'N', the matrix A has been
// *                  equilibrated with scaling factors given by R and C.
// *                  AB, AFB, and IPIV are not modified.
// *          = 'N':  The matrix A will be copied to AFB and factored.
// *          = 'E':  The matrix A will be equilibrated if necessary, then
// *                  copied to AFB and factored.
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations.
// *          = 'N':  A * X = B     (No transpose)
// *          = 'T':  A**T * X = B  (Transpose)
// *          = 'C':  A**H * X = B  (Transpose)
// *
// *  N       (input) INTEGER
// *          The number of linear equations, i.e., the order of the
// *          matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices B and X.  NRHS >= 0.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          On entry, the matrix A in band storage, in rows 1 to KL+KU+1.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(KU+1+i-j,j) = A(i,j) for max(1,j-KU)<=i<=min(N,j+kl)
// *
// *          If FACT = 'F' and EQUED is not 'N', then A must have been
// *          equilibrated by the scaling factors in R and/or C.  AB is not
// *          modified if FACT = 'F' or 'N', or if FACT = 'E' and
// *          EQUED = 'N' on exit.
// *
// *          On exit, if EQUED .ne. 'N', A is scaled as follows:
// *          EQUED = 'R':  A := diag(R) * A
// *          EQUED = 'C':  A := A * diag(C)
// *          EQUED = 'B':  A := diag(R) * A * diag(C).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KL+KU+1.
// *
// *  AFB     (input or output) DOUBLE PRECISION array, dimension (LDAFB,N)
// *          If FACT = 'F', then AFB is an input argument and on entry
// *          contains details of the LU factorization of the band matrix
// *          A, as computed by DGBTRF.  U is stored as an upper triangular
// *          band matrix with KL+KU superdiagonals in rows 1 to KL+KU+1,
// *          and the multipliers used during the factorization are stored
// *          in rows KL+KU+2 to 2*KL+KU+1.  If EQUED .ne. 'N', then AFB is
// *          the factored form of the equilibrated matrix A.
// *
// *          If FACT = 'N', then AFB is an output argument and on exit
// *          returns details of the LU factorization of A.
// *
// *          If FACT = 'E', then AFB is an output argument and on exit
// *          returns details of the LU factorization of the equilibrated
// *          matrix A (see the description of AB for the form of the
// *          equilibrated matrix).
// *
// *  LDAFB   (input) INTEGER
// *          The leading dimension of the array AFB.  LDAFB >= 2*KL+KU+1.
// *
// *  IPIV    (input or output) INTEGER array, dimension (N)
// *          If FACT = 'F', then IPIV is an input argument and on entry
// *          contains the pivot indices from the factorization A = L*U
// *          as computed by DGBTRF; row i of the matrix was interchanged
// *          with row IPIV(i).
// *
// *          If FACT = 'N', then IPIV is an output argument and on exit
// *          contains the pivot indices from the factorization A = L*U
// *          of the original matrix A.
// *
// *          If FACT = 'E', then IPIV is an output argument and on exit
// *          contains the pivot indices from the factorization A = L*U
// *          of the equilibrated matrix A.
// *
// *  EQUED   (input or output) CHARACTER*1
// *          Specifies the form of equilibration that was done.
// *          = 'N':  No equilibration (always true if FACT = 'N').
// *          = 'R':  Row equilibration, i.e., A has been premultiplied by
// *                  diag(R).
// *          = 'C':  Column equilibration, i.e., A has been postmultiplied
// *                  by diag(C).
// *          = 'B':  Both row and column equilibration, i.e., A has been
// *                  replaced by diag(R) * A * diag(C).
// *          EQUED is an input argument if FACT = 'F'; otherwise, it is an
// *          output argument.
// *
// *  R       (input or output) DOUBLE PRECISION array, dimension (N)
// *          The row scale factors for A.  If EQUED = 'R' or 'B', A is
// *          multiplied on the left by diag(R); if EQUED = 'N' or 'C', R
// *          is not accessed.  R is an input argument if FACT = 'F';
// *          otherwise, R is an output argument.  If FACT = 'F' and
// *          EQUED = 'R' or 'B', each element of R must be positive.
// *
// *  C       (input or output) DOUBLE PRECISION array, dimension (N)
// *          The column scale factors for A.  If EQUED = 'C' or 'B', A is
// *          multiplied on the right by diag(C); if EQUED = 'N' or 'R', C
// *          is not accessed.  C is an input argument if FACT = 'F';
// *          otherwise, C is an output argument.  If FACT = 'F' and
// *          EQUED = 'C' or 'B', each element of C must be positive.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side matrix B.
// *          On exit,
// *          if EQUED = 'N', B is not modified;
// *          if TRANS = 'N' and EQUED = 'R' or 'B', B is overwritten by
// *          diag(R)*B;
// *          if TRANS = 'T' or 'C' and EQUED = 'C' or 'B', B is
// *          overwritten by diag(C)*B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (output) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          If INFO = 0, the N-by-NRHS solution matrix X to the original
// *          system of equations.  Note that A and B are modified on exit
// *          if EQUED .ne. 'N', and the solution to the equilibrated
// *          system is inv(diag(C))*X if TRANS = 'N' and EQUED = 'C' or
// *          'B', or inv(diag(R))*X if TRANS = 'T' or 'C' and EQUED = 'R'
// *          or 'B'.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The estimate of the reciprocal condition number of the matrix
// *          A after equilibration (if done).  If RCOND is less than the
// *          machine precision (in particular, if RCOND = 0), the matrix
// *          is singular to working precision.  This condition is
// *          indicated by a return code of INFO > 0, and the solution and
// *          error bounds are not computed.
// *
// *  FERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bound for each solution vector
// *          X(j) (the j-th column of the solution matrix X).
// *          If XTRUE is the true solution corresponding to X(j), FERR(j)
// *          is an estimated upper bound for the magnitude of the largest
// *          element in (X(j) - XTRUE) divided by the magnitude of the
// *          largest element in X(j).  The estimate is as reliable as
// *          the estimate for RCOND, and is almost always a slight
// *          overestimate of the true error.
// *
// *  BERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector X(j) (i.e., the smallest relative change in
// *          any element of A or B that makes X(j) an exact solution).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (3*N)
// *          On exit, WORK(1) contains the reciprocal pivot growth
// *          factor norm(A)/norm(U). The "max absolute element" norm is
// *          used. If WORK(1) is much less than 1, then the stability
// *          of the LU factorization of the (equilibrated) matrix A
// *          could be poor. This also means that the solution X, condition
// *          estimator RCOND, and forward error bound FERR could be
// *          unreliable. If factorization fails with 0<INFO<=N, then
// *          WORK(1) contains the reciprocal pivot growth factor for the
// *          leading INFO columns of A.
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, and i is
// *                <= N:  U(i,i) is exactly zero.  The factorization
// *                       has been completed, but the factor U is exactly
// *                       singular, so the solution and error bounds
// *                       could not be computed.
// *                = N+1: RCOND is less than machine precision.  The
// *                       factorization has been completed, but the
// *                       matrix A is singular to working precision, and
// *                       the solution and error bounds have not been
// *                       computed.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean colequ= false;
static boolean equil= false;
static boolean nofact= false;
static boolean notran= false;
static boolean rowequ= false;
static String norm= new String(" ");
static int i= 0;
static intW infequ= new intW(0);
static int j= 0;
static int j1= 0;
static int j2= 0;
static doubleW amax= new doubleW(0.0);
static double anorm= 0.0;
static double bignum= 0.0;
static doubleW colcnd= new doubleW(0.0);
static double rcmax= 0.0;
static double rcmin= 0.0;
static doubleW rowcnd= new doubleW(0.0);
static double rpvgrw= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgbsvx (String fact,
String trans,
int n,
int kl,
int ku,
int nrhs,
double [] ab, int _ab_offset,
int ldab,
double [] afb, int _afb_offset,
int ldafb,
int [] ipiv, int _ipiv_offset,
StringW equed,
double [] r, int _r_offset,
double [] c, int _c_offset,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
doubleW rcond,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
nofact = (fact.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
equil = (fact.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0));
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (nofact || equil)  {
    equed.val = "N";
rowequ = false;
colequ = false;
}              // Close if()
else  {
  rowequ = (equed.val.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)) || (equed.val.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
colequ = (equed.val.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)) || (equed.val.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
smlnum = Dlamch.dlamch("Safe minimum");
bignum = one/smlnum;
}              //  Close else.
// *
// *     Test the input parameters.
// *
if (!nofact && !equil && !(fact.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (kl < 0)  {
    info.val = -4;
}              // Close else if()
else if (ku < 0)  {
    info.val = -5;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -6;
}              // Close else if()
else if (ldab < kl+ku+1)  {
    info.val = -8;
}              // Close else if()
else if (ldafb < 2*kl+ku+1)  {
    info.val = -10;
}              // Close else if()
else if ((fact.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)) && !(rowequ || colequ || (equed.val.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -12;
}              // Close else if()
else  {
  if (rowequ)  {
    rcmin = bignum;
rcmax = zero;
{
forloop10:
for (j = 1; j <= n; j++) {
rcmin = Math.min(rcmin, r[(j)- 1+ _r_offset]) ;
rcmax = Math.max(rcmax, r[(j)- 1+ _r_offset]) ;
Dummy.label("Dgbsvx",10);
}              //  Close for() loop. 
}
if (rcmin <= zero)  {
    info.val = -13;
}              // Close if()
else if (n > 0)  {
    rowcnd.val = Math.max(rcmin, smlnum) /Math.min(rcmax, bignum) ;
}              // Close else if()
else  {
  rowcnd.val = one;
}              //  Close else.
}              // Close if()
if (colequ && info.val == 0)  {
    rcmin = bignum;
rcmax = zero;
{
forloop20:
for (j = 1; j <= n; j++) {
rcmin = Math.min(rcmin, c[(j)- 1+ _c_offset]) ;
rcmax = Math.max(rcmax, c[(j)- 1+ _c_offset]) ;
Dummy.label("Dgbsvx",20);
}              //  Close for() loop. 
}
if (rcmin <= zero)  {
    info.val = -14;
}              // Close if()
else if (n > 0)  {
    colcnd.val = Math.max(rcmin, smlnum) /Math.min(rcmax, bignum) ;
}              // Close else if()
else  {
  colcnd.val = one;
}              //  Close else.
}              // Close if()
if (info.val == 0)  {
    if (ldb < Math.max(1, n) )  {
    info.val = -16;
}              // Close if()
else if (ldx < Math.max(1, n) )  {
    info.val = -18;
}              // Close else if()
}              // Close if()
}              //  Close else.
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGBSVX",-info.val);
Dummy.go_to("Dgbsvx",999999);
}              // Close if()
// *
if (equil)  {
    // *
// *        Compute row and column scalings to equilibrate the matrix A.
// *
Dgbequ.dgbequ(n,n,kl,ku,ab,_ab_offset,ldab,r,_r_offset,c,_c_offset,rowcnd,colcnd,amax,infequ);
if (infequ.val == 0)  {
    // *
// *           Equilibrate the matrix.
// *
Dlaqgb.dlaqgb(n,n,kl,ku,ab,_ab_offset,ldab,r,_r_offset,c,_c_offset,rowcnd.val,colcnd.val,amax.val,equed);
rowequ = (equed.val.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)) || (equed.val.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
colequ = (equed.val.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)) || (equed.val.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
}              // Close if()
}              // Close if()
// *
// *     Scale the right hand side.
// *
if (notran)  {
    if (rowequ)  {
    {
forloop40:
for (j = 1; j <= nrhs; j++) {
{
forloop30:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = r[(i)- 1+ _r_offset]*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dgbsvx",30);
}              //  Close for() loop. 
}
Dummy.label("Dgbsvx",40);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else if (colequ)  {
    {
forloop60:
for (j = 1; j <= nrhs; j++) {
{
forloop50:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = c[(i)- 1+ _c_offset]*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dgbsvx",50);
}              //  Close for() loop. 
}
Dummy.label("Dgbsvx",60);
}              //  Close for() loop. 
}
}              // Close else if()
// *
if (nofact || equil)  {
    // *
// *        Compute the LU factorization of the band matrix A.
// *
{
forloop70:
for (j = 1; j <= n; j++) {
j1 = (int)(Math.max(j-ku, 1) );
j2 = (int)(Math.min(j+kl, n) );
Dcopy.dcopy(j2-j1+1,ab,(ku+1-j+j1)- 1+(j- 1)*ldab+ _ab_offset,1,afb,(kl+ku+1-j+j1)- 1+(j- 1)*ldafb+ _afb_offset,1);
Dummy.label("Dgbsvx",70);
}              //  Close for() loop. 
}
// *
Dgbtrf.dgbtrf(n,n,kl,ku,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,info);
// *
// *        Return if INFO is non-zero.
// *
if (info.val != 0)  {
    if (info.val > 0)  {
    // *
// *              Compute the reciprocal pivot growth factor of the
// *              leading rank-deficient INFO columns of A.
// *
anorm = zero;
{
forloop90:
for (j = 1; j <= info.val; j++) {
{
forloop80:
for (i = (int)(Math.max(ku+2-j, 1) ); i <= Math.min(n+ku+1-j, kl+ku+1) ; i++) {
anorm = Math.max(anorm, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dgbsvx",80);
}              //  Close for() loop. 
}
Dummy.label("Dgbsvx",90);
}              //  Close for() loop. 
}
rpvgrw = Dlantb.dlantb("M","U","N",info.val,(int) ( Math.min(info.val-1, kl+ku) ),afb,(int)((Math.max(1, kl+ku+2-info.val) )- 1+(1- 1)*ldafb+ _afb_offset),ldafb,work,_work_offset);
if (rpvgrw == zero)  {
    rpvgrw = one;
}              // Close if()
else  {
  rpvgrw = anorm/rpvgrw;
}              //  Close else.
work[(1)- 1+ _work_offset] = rpvgrw;
rcond.val = zero;
}              // Close if()
Dummy.go_to("Dgbsvx",999999);
}              // Close if()
}              // Close if()
// *
// *     Compute the norm of the matrix A and the
// *     reciprocal pivot growth factor RPVGRW.
// *
if (notran)  {
    norm = "1";
}              // Close if()
else  {
  norm = "I";
}              //  Close else.
anorm = Dlangb.dlangb(norm,n,kl,ku,ab,_ab_offset,ldab,work,_work_offset);
rpvgrw = Dlantb.dlantb("M","U","N",n,kl+ku,afb,_afb_offset,ldafb,work,_work_offset);
if (rpvgrw == zero)  {
    rpvgrw = one;
}              // Close if()
else  {
  rpvgrw = Dlangb.dlangb("M",n,kl,ku,ab,_ab_offset,ldab,work,_work_offset)/rpvgrw;
}              //  Close else.
// *
// *     Compute the reciprocal of the condition number of A.
// *
Dgbcon.dgbcon(norm,n,kl,ku,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,anorm,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *     Return if the matrix is singular to working precision.
// *
if (rcond.val < Dlamch.dlamch("Epsilon"))  {
    work[(1)- 1+ _work_offset] = rpvgrw;
info.val = n+1;
Dummy.go_to("Dgbsvx",999999);
}              // Close if()
// *
// *     Compute the solution matrix X.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,ldb,x,_x_offset,ldx);
Dgbtrs.dgbtrs(trans,n,kl,ku,nrhs,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,x,_x_offset,ldx,info);
// *
// *     Use iterative refinement to improve the computed solution and
// *     compute error bounds and backward error estimates for it.
// *
Dgbrfs.dgbrfs(trans,n,kl,ku,nrhs,ab,_ab_offset,ldab,afb,_afb_offset,ldafb,ipiv,_ipiv_offset,b,_b_offset,ldb,x,_x_offset,ldx,ferr,_ferr_offset,berr,_berr_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *     Transform the solution matrix X to a solution of the original
// *     system.
// *
if (notran)  {
    if (colequ)  {
    {
forloop110:
for (j = 1; j <= nrhs; j++) {
{
forloop100:
for (i = 1; i <= n; i++) {
x[(i)- 1+(j- 1)*ldx+ _x_offset] = c[(i)- 1+ _c_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dgbsvx",100);
}              //  Close for() loop. 
}
Dummy.label("Dgbsvx",110);
}              //  Close for() loop. 
}
{
forloop120:
for (j = 1; j <= nrhs; j++) {
ferr[(j)- 1+ _ferr_offset] = ferr[(j)- 1+ _ferr_offset]/colcnd.val;
Dummy.label("Dgbsvx",120);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else if (rowequ)  {
    {
forloop140:
for (j = 1; j <= nrhs; j++) {
{
forloop130:
for (i = 1; i <= n; i++) {
x[(i)- 1+(j- 1)*ldx+ _x_offset] = r[(i)- 1+ _r_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dgbsvx",130);
}              //  Close for() loop. 
}
Dummy.label("Dgbsvx",140);
}              //  Close for() loop. 
}
{
forloop150:
for (j = 1; j <= nrhs; j++) {
ferr[(j)- 1+ _ferr_offset] = ferr[(j)- 1+ _ferr_offset]/rowcnd.val;
Dummy.label("Dgbsvx",150);
}              //  Close for() loop. 
}
}              // Close else if()
// *
work[(1)- 1+ _work_offset] = rpvgrw;
Dummy.go_to("Dgbsvx",999999);
// *
// *     End of DGBSVX
// *
Dummy.label("Dgbsvx",999999);
return;
   }
} // End class.
