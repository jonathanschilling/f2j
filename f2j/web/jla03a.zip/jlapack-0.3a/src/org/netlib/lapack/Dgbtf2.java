/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbtf2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBTF2 computes an LU factorization of a real m-by-n band matrix A
// *  using partial pivoting with row interchanges.
// *
// *  This is the unblocked version of the algorithm, calling Level 2 BLAS.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          On entry, the matrix A in band storage, in rows KL+1 to
// *          2*KL+KU+1; rows 1 to KL of the array need not be set.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(kl+ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(m,j+kl)
// *
// *          On exit, details of the factorization: U is stored as an
// *          upper triangular band matrix with KL+KU superdiagonals in
// *          rows 1 to KL+KU+1, and the multipliers used during the
// *          factorization are stored in rows KL+KU+2 to 2*KL+KU+1.
// *          See below for further details.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= 2*KL+KU+1.
// *
// *  IPIV    (output) INTEGER array, dimension (min(M,N))
// *          The pivot indices; for 1 <= i <= min(M,N), row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *          > 0: if INFO = +i, U(i,i) is exactly zero. The factorization
// *               has been completed, but the factor U is exactly
// *               singular, and division by zero will occur if it is used
// *               to solve a system of equations.
// *
// *  Further Details
// *  ===============
// *
// *  The band storage scheme is illustrated by the following example, when
// *  M = N = 6, KL = 2, KU = 1:
// *
// *  On entry:                       On exit:
// *
// *      *    *    *    +    +    +       *    *    *   u14  u25  u36
// *      *    *    +    +    +    +       *    *   u13  u24  u35  u46
// *      *   a12  a23  a34  a45  a56      *   u12  u23  u34  u45  u56
// *     a11  a22  a33  a44  a55  a66     u11  u22  u33  u44  u55  u66
// *     a21  a32  a43  a54  a65   *      m21  m32  m43  m54  m65   *
// *     a31  a42  a53  a64   *    *      m31  m42  m53  m64   *    *
// *
// *  Array elements marked * are not used by the routine; elements marked
// *  + need not be set on entry, but are required by the routine to store
// *  elements of U, because of fill-in resulting from the row
// *  interchanges.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int jp= 0;
static int ju= 0;
static int km= 0;
static int kv= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     KV is the number of superdiagonals in the factor U, allowing for
// *     fill-in.
// *

public static void dgbtf2 (int m,
int n,
int kl,
int ku,
double [] ab, int _ab_offset,
int ldab,
int [] ipiv, int _ipiv_offset,
intW info)  {

kv = ku+kl;
// *
// *     Test the input parameters.
// *
info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0)  {
    info.val = -4;
}              // Close else if()
else if (ldab < kl+kv+1)  {
    info.val = -6;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBTF2",-info.val);
Dummy.go_to("Dgbtf2",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dgbtf2",999999);
// *
// *     Gaussian elimination with partial pivoting
// *
// *     Set fill-in elements in columns KU+2 to KV to zero.
// *
{
forloop20:
for (j = ku+2; j <= Math.min(kv, n) ; j++) {
{
forloop10:
for (i = kv-j+2; i <= kl; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dgbtf2",10);
}              //  Close for() loop. 
}
Dummy.label("Dgbtf2",20);
}              //  Close for() loop. 
}
// *
// *     JU is the index of the last column affected by the current stage
// *     of the factorization.
// *
ju = 1;
// *
{
forloop40:
for (j = 1; j <= Math.min(m, n) ; j++) {
// *
// *        Set fill-in elements in column J+KV to zero.
// *
if (j+kv <= n)  {
    {
forloop30:
for (i = 1; i <= kl; i++) {
ab[(i)- 1+(j+kv- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dgbtf2",30);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Find pivot and test for singularity. KM is the number of
// *        subdiagonal elements in the current column.
// *
km = (int)(Math.min(kl, m-j) );
jp = Idamax.idamax(km+1,ab,(kv+1)- 1+(j- 1)*ldab+ _ab_offset,1);
ipiv[(j)- 1+ _ipiv_offset] = jp+j-1;
if (ab[(kv+jp)- 1+(j- 1)*ldab+ _ab_offset] != zero)  {
    ju = (int)(Math.max(ju, Math.min(j+ku+jp-1, n) ) );
// *
// *           Apply interchange to columns J to JU.
// *
if (jp != 1)  
    Dswap.dswap(ju-j+1,ab,(kv+jp)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+1)- 1+(j- 1)*ldab+ _ab_offset,ldab-1);
// *
if (km > 0)  {
    // *
// *              Compute multipliers.
// *
Dscal.dscal(km,one/ab[(kv+1)- 1+(j- 1)*ldab+ _ab_offset],ab,(kv+2)- 1+(j- 1)*ldab+ _ab_offset,1);
// *
// *              Update trailing submatrix within the band.
// *
if (ju > j)  
    Dger.dger(km,ju-j,-one,ab,(kv+2)- 1+(j- 1)*ldab+ _ab_offset,1,ab,(kv)- 1+(j+1- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+1)- 1+(j+1- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
}              // Close if()
else  {
  // *
// *           If pivot is zero, set INFO to the index of the pivot
// *           unless a zero pivot has already been found.
// *
if (info.val == 0)  
    info.val = j;
}              //  Close else.
Dummy.label("Dgbtf2",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dgbtf2",999999);
// *
// *     End of DGBTF2
// *
Dummy.label("Dgbtf2",999999);
return;
   }
} // End class.
