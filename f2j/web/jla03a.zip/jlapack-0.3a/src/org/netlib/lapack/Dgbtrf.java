/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbtrf {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBTRF computes an LU factorization of a real m-by-n band matrix A
// *  using partial pivoting with row interchanges.
// *
// *  This is the blocked version of the algorithm, calling Level 3 BLAS.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          On entry, the matrix A in band storage, in rows KL+1 to
// *          2*KL+KU+1; rows 1 to KL of the array need not be set.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(kl+ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(m,j+kl)
// *
// *          On exit, details of the factorization: U is stored as an
// *          upper triangular band matrix with KL+KU superdiagonals in
// *          rows 1 to KL+KU+1, and the multipliers used during the
// *          factorization are stored in rows KL+KU+2 to 2*KL+KU+1.
// *          See below for further details.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= 2*KL+KU+1.
// *
// *  IPIV    (output) INTEGER array, dimension (min(M,N))
// *          The pivot indices; for 1 <= i <= min(M,N), row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *          > 0: if INFO = +i, U(i,i) is exactly zero. The factorization
// *               has been completed, but the factor U is exactly
// *               singular, and division by zero will occur if it is used
// *               to solve a system of equations.
// *
// *  Further Details
// *  ===============
// *
// *  The band storage scheme is illustrated by the following example, when
// *  M = N = 6, KL = 2, KU = 1:
// *
// *  On entry:                       On exit:
// *
// *      *    *    *    +    +    +       *    *    *   u14  u25  u36
// *      *    *    +    +    +    +       *    *   u13  u24  u35  u46
// *      *   a12  a23  a34  a45  a56      *   u12  u23  u34  u45  u56
// *     a11  a22  a33  a44  a55  a66     u11  u22  u33  u44  u55  u66
// *     a21  a32  a43  a54  a65   *      m21  m32  m43  m54  m65   *
// *     a31  a42  a53  a64   *    *      m31  m42  m53  m64   *    *
// *
// *  Array elements marked * are not used by the routine; elements marked
// *  + need not be set on entry, but are required by the routine to store
// *  elements of U because of fill-in resulting from the row interchanges.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int nbmax= 64;
static int ldwork= nbmax+1;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int i2= 0;
static int i3= 0;
static int ii= 0;
static int ip= 0;
static int j= 0;
static int j2= 0;
static int j3= 0;
static int jb= 0;
static int jj= 0;
static int jm= 0;
static int jp= 0;
static int ju= 0;
static int k2= 0;
static int km= 0;
static int kv= 0;
static int nb= 0;
static int nw= 0;
static double temp= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] work13= new double[(ldwork) * (nbmax)];
static double [] work31= new double[(ldwork) * (nbmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     KV is the number of superdiagonals in the factor U, allowing for
// *     fill-in
// *

public static void dgbtrf (int m,
int n,
int kl,
int ku,
double [] ab, int _ab_offset,
int ldab,
int [] ipiv, int _ipiv_offset,
intW info)  {

kv = ku+kl;
// *
// *     Test the input parameters.
// *
info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0)  {
    info.val = -4;
}              // Close else if()
else if (ldab < kl+kv+1)  {
    info.val = -6;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBTRF",-info.val);
Dummy.go_to("Dgbtrf",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dgbtrf",999999);
// *
// *     Determine the block size for this environment
// *
nb = Ilaenv.ilaenv(1,"DGBTRF"," ",m,n,kl,ku);
// *
// *     The block size must not exceed the limit set by the size of the
// *     local arrays WORK13 and WORK31.
// *
nb = (int)(Math.min(nb, nbmax) );
// *
if (nb <= 1 || nb > kl)  {
    // *
// *        Use unblocked code
// *
Dgbtf2.dgbtf2(m,n,kl,ku,ab,_ab_offset,ldab,ipiv,_ipiv_offset,info);
}              // Close if()
else  {
  // *
// *        Use blocked code
// *
// *        Zero the superdiagonal elements of the work array WORK13
// *
{
forloop20:
for (j = 1; j <= nb; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
work13[(i)- 1+(j- 1)*ldwork] = zero;
Dummy.label("Dgbtrf",10);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",20);
}              //  Close for() loop. 
}
// *
// *        Zero the subdiagonal elements of the work array WORK31
// *
{
forloop40:
for (j = 1; j <= nb; j++) {
{
forloop30:
for (i = j+1; i <= nb; i++) {
work31[(i)- 1+(j- 1)*ldwork] = zero;
Dummy.label("Dgbtrf",30);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",40);
}              //  Close for() loop. 
}
// *
// *        Gaussian elimination with partial pivoting
// *
// *        Set fill-in elements in columns KU+2 to KV to zero
// *
{
forloop60:
for (j = ku+2; j <= Math.min(kv, n) ; j++) {
{
forloop50:
for (i = kv-j+2; i <= kl; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dgbtrf",50);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",60);
}              //  Close for() loop. 
}
// *
// *        JU is the index of the last column affected by the current
// *        stage of the factorization
// *
ju = 1;
// *
{
int _j_inc = nb;
forloop180:
for (j = 1; (_j_inc < 0) ? j >= Math.min(m, n)  : j <= Math.min(m, n) ; j += _j_inc) {
jb = (int)(Math.min(nb, Math.min(m, n) -j+1) );
// *
// *           The active part of the matrix is partitioned
// *
// *              A11   A12   A13
// *              A21   A22   A23
// *              A31   A32   A33
// *
// *           Here A11, A21 and A31 denote the current block of JB columns
// *           which is about to be factorized. The number of rows in the
// *           partitioning are JB, I2, I3 respectively, and the numbers
// *           of columns are JB, J2, J3. The superdiagonal elements of A13
// *           and the subdiagonal elements of A31 lie outside the band.
// *
i2 = (int)(Math.min(kl-jb, m-j-jb+1) );
i3 = (int)(Math.min(jb, m-j-kl+1) );
// *
// *           J2 and J3 are computed after JU has been updated.
// *
// *           Factorize the current block of JB columns
// *
{
forloop80:
for (jj = j; jj <= j+jb-1; jj++) {
// *
// *              Set fill-in elements in column JJ+KV to zero
// *
if (jj+kv <= n)  {
    {
forloop70:
for (i = 1; i <= kl; i++) {
ab[(i)- 1+(jj+kv- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dgbtrf",70);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Find pivot and test for singularity. KM is the number of
// *              subdiagonal elements in the current column.
// *
km = (int)(Math.min(kl, m-jj) );
jp = Idamax.idamax(km+1,ab,(kv+1)- 1+(jj- 1)*ldab+ _ab_offset,1);
ipiv[(jj)- 1+ _ipiv_offset] = jp+jj-j;
if (ab[(kv+jp)- 1+(jj- 1)*ldab+ _ab_offset] != zero)  {
    ju = (int)(Math.max(ju, Math.min(jj+ku+jp-1, n) ) );
if (jp != 1)  {
    // *
// *                    Apply interchange to columns J to J+JB-1
// *
if (jp+jj-1 < j+kl)  {
    // *
Dswap.dswap(jb,ab,(kv+1+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+jp+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
else  {
  // *
// *                       The interchange affects columns J to JJ-1 of A31
// *                       which are stored in the work array WORK31
// *
Dswap.dswap(jj-j,ab,(kv+1+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,work31,(jp+jj-j-kl)- 1+(1- 1)*ldwork,ldwork);
Dswap.dswap(j+jb-jj,ab,(kv+1)- 1+(jj- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+jp)- 1+(jj- 1)*ldab+ _ab_offset,ldab-1);
}              //  Close else.
}              // Close if()
// *
// *                 Compute multipliers
// *
Dscal.dscal(km,one/ab[(kv+1)- 1+(jj- 1)*ldab+ _ab_offset],ab,(kv+2)- 1+(jj- 1)*ldab+ _ab_offset,1);
// *
// *                 Update trailing submatrix within the band and within
// *                 the current block. JM is the index of the last column
// *                 which needs to be updated.
// *
jm = (int)(Math.min(ju, j+jb-1) );
if (jm > jj)  
    Dger.dger(km,jm-jj,-one,ab,(kv+2)- 1+(jj- 1)*ldab+ _ab_offset,1,ab,(kv)- 1+(jj+1- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+1)- 1+(jj+1- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
else  {
  // *
// *                 If pivot is zero, set INFO to the index of the pivot
// *                 unless a zero pivot has already been found.
// *
if (info.val == 0)  
    info.val = jj;
}              //  Close else.
// *
// *              Copy current column of A31 into the work array WORK31
// *
nw = (int)(Math.min(jj-j+1, i3) );
if (nw > 0)  
    Dcopy.dcopy(nw,ab,(kv+kl+1-jj+j)- 1+(jj- 1)*ldab+ _ab_offset,1,work31,(1)- 1+(jj-j+1- 1)*ldwork,1);
Dummy.label("Dgbtrf",80);
}              //  Close for() loop. 
}
if (j+jb <= n)  {
    // *
// *              Apply the row interchanges to the other blocks.
// *
j2 = (int)(Math.min(ju-j+1, kv) -jb);
j3 = (int)(Math.max(0, ju-j-kv+1) );
// *
// *              Use DLASWP to apply the row interchanges to A12, A22, and
// *              A32.
// *
Dlaswp.dlaswp(j2,ab,(kv+1-jb)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1,1,jb,ipiv,(j)- 1+ _ipiv_offset,1);
// *
// *              Adjust the pivot indices.
// *
{
forloop90:
for (i = j; i <= j+jb-1; i++) {
ipiv[(i)- 1+ _ipiv_offset] = ipiv[(i)- 1+ _ipiv_offset]+j-1;
Dummy.label("Dgbtrf",90);
}              //  Close for() loop. 
}
// *
// *              Apply the row interchanges to A13, A23, and A33
// *              columnwise.
// *
k2 = j-1+jb+j2;
{
forloop110:
for (i = 1; i <= j3; i++) {
jj = k2+i;
{
forloop100:
for (ii = j+i-1; ii <= j+jb-1; ii++) {
ip = ipiv[(ii)- 1+ _ipiv_offset];
if (ip != ii)  {
    temp = ab[(kv+1+ii-jj)- 1+(jj- 1)*ldab+ _ab_offset];
ab[(kv+1+ii-jj)- 1+(jj- 1)*ldab+ _ab_offset] = ab[(kv+1+ip-jj)- 1+(jj- 1)*ldab+ _ab_offset];
ab[(kv+1+ip-jj)- 1+(jj- 1)*ldab+ _ab_offset] = temp;
}              // Close if()
Dummy.label("Dgbtrf",100);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",110);
}              //  Close for() loop. 
}
// *
// *              Update the relevant part of the trailing submatrix
// *
if (j2 > 0)  {
    // *
// *                 Update A12
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Unit",jb,j2,one,ab,(kv+1)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+1-jb)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1);
// *
if (i2 > 0)  {
    // *
// *                    Update A22
// *
Dgemm.dgemm("No transpose","No transpose",i2,j2,jb,-one,ab,(kv+1+jb)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+1-jb)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1,one,ab,(kv+1)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
// *
if (i3 > 0)  {
    // *
// *                    Update A32
// *
Dgemm.dgemm("No transpose","No transpose",i3,j2,jb,-one,work31,0,ldwork,ab,(kv+1-jb)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1,one,ab,(kv+kl+1-jb)- 1+(j+jb- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
}              // Close if()
// *
if (j3 > 0)  {
    // *
// *                 Copy the lower triangle of A13 into the work array
// *                 WORK13
// *
{
forloop130:
for (jj = 1; jj <= j3; jj++) {
{
forloop120:
for (ii = jj; ii <= jb; ii++) {
work13[(ii)- 1+(jj- 1)*ldwork] = ab[(ii-jj+1)- 1+(jj+j+kv-1- 1)*ldab+ _ab_offset];
Dummy.label("Dgbtrf",120);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",130);
}              //  Close for() loop. 
}
// *
// *                 Update A13 in the work array
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Unit",jb,j3,one,ab,(kv+1)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,work13,0,ldwork);
// *
if (i2 > 0)  {
    // *
// *                    Update A23
// *
Dgemm.dgemm("No transpose","No transpose",i2,j3,jb,-one,ab,(kv+1+jb)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,work13,0,ldwork,one,ab,(1+jb)- 1+(j+kv- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
// *
if (i3 > 0)  {
    // *
// *                    Update A33
// *
Dgemm.dgemm("No transpose","No transpose",i3,j3,jb,-one,work31,0,ldwork,work13,0,ldwork,one,ab,(1+kl)- 1+(j+kv- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
// *
// *                 Copy the lower triangle of A13 back into place
// *
{
forloop150:
for (jj = 1; jj <= j3; jj++) {
{
forloop140:
for (ii = jj; ii <= jb; ii++) {
ab[(ii-jj+1)- 1+(jj+j+kv-1- 1)*ldab+ _ab_offset] = work13[(ii)- 1+(jj- 1)*ldwork];
Dummy.label("Dgbtrf",140);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",150);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else  {
  // *
// *              Adjust the pivot indices.
// *
{
forloop160:
for (i = j; i <= j+jb-1; i++) {
ipiv[(i)- 1+ _ipiv_offset] = ipiv[(i)- 1+ _ipiv_offset]+j-1;
Dummy.label("Dgbtrf",160);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *           Partially undo the interchanges in the current block to
// *           restore the upper triangular form of A31 and copy the upper
// *           triangle of A31 back into place
// *
{
int _jj_inc = -1;
forloop170:
for (jj = j+jb-1; jj >= j; jj += _jj_inc) {
jp = ipiv[(jj)- 1+ _ipiv_offset]-jj+1;
if (jp != 1)  {
    // *
// *                 Apply interchange to columns J to JJ-1
// *
if (jp+jj-1 < j+kl)  {
    // *
// *                    The interchange does not affect A31
// *
Dswap.dswap(jj-j,ab,(kv+1+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kv+jp+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1);
}              // Close if()
else  {
  // *
// *                    The interchange does affect A31
// *
Dswap.dswap(jj-j,ab,(kv+1+jj-j)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,work31,(jp+jj-j-kl)- 1+(1- 1)*ldwork,ldwork);
}              //  Close else.
}              // Close if()
// *
// *              Copy the current column of A31 back into place
// *
nw = (int)(Math.min(i3, jj-j+1) );
if (nw > 0)  
    Dcopy.dcopy(nw,work31,(1)- 1+(jj-j+1- 1)*ldwork,1,ab,(kv+kl+1-jj+j)- 1+(jj- 1)*ldab+ _ab_offset,1);
Dummy.label("Dgbtrf",170);
}              //  Close for() loop. 
}
Dummy.label("Dgbtrf",180);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dummy.go_to("Dgbtrf",999999);
// *
// *     End of DGBTRF
// *
Dummy.label("Dgbtrf",999999);
return;
   }
} // End class.
