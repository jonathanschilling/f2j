/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgbtrs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBTRS solves a system of linear equations
// *     A * X = B  or  A' * X = B
// *  with a general band matrix A using the LU factorization computed
// *  by DGBTRF.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations.
// *          = 'N':  A * X = B  (No transpose)
// *          = 'T':  A'* X = B  (Transpose)
// *          = 'C':  A'* X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          Details of the LU factorization of the band matrix A, as
// *          computed by DGBTRF.  U is stored as an upper triangular band
// *          matrix with KL+KU superdiagonals in rows 1 to KL+KU+1, and
// *          the multipliers used during the factorization are stored in
// *          rows KL+KU+2 to 2*KL+KU+1.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= 2*KL+KU+1.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= N, row i of the matrix was
// *          interchanged with row IPIV(i).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side matrix B.
// *          On exit, the solution matrix X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean lnoti= false;
static boolean notran= false;
static int i= 0;
static int j= 0;
static int kd= 0;
static int l= 0;
static int lm= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgbtrs (String trans,
int n,
int kl,
int ku,
int nrhs,
double [] ab, int _ab_offset,
int ldab,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0)  {
    info.val = -4;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -5;
}              // Close else if()
else if (ldab < (2*kl+ku+1))  {
    info.val = -7;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -10;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGBTRS",-info.val);
Dummy.go_to("Dgbtrs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0)  
    Dummy.go_to("Dgbtrs",999999);
// *
kd = ku+kl+1;
lnoti = kl > 0;
// *
if (notran)  {
    // *
// *        Solve  A*X = B.
// *
// *        Solve L*X = B, overwriting B with X.
// *
// *        L is represented as a product of permutations and unit lower
// *        triangular matrices L = P(1) * L(1) * ... * P(n-1) * L(n-1),
// *        where each transformation L(i) is a rank-one modification of
// *        the identity matrix.
// *
if (lnoti)  {
    {
forloop10:
for (j = 1; j <= n-1; j++) {
lm = (int)(Math.min(kl, n-j) );
l = ipiv[(j)- 1+ _ipiv_offset];
if (l != j)  
    Dswap.dswap(nrhs,b,(l)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(j)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dger.dger(lm,nrhs,-one,ab,(kd+1)- 1+(j- 1)*ldab+ _ab_offset,1,b,(j)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(j+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dummy.label("Dgbtrs",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
{
forloop20:
for (i = 1; i <= nrhs; i++) {
// *
// *           Solve U*X = B, overwriting B with X.
// *
Dtbsv.dtbsv("Upper","No transpose","Non-unit",n,kl+ku,ab,_ab_offset,ldab,b,(1)- 1+(i- 1)*ldb+ _b_offset,1);
Dummy.label("Dgbtrs",20);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *        Solve A'*X = B.
// *
{
forloop30:
for (i = 1; i <= nrhs; i++) {
// *
// *           Solve U'*X = B, overwriting B with X.
// *
Dtbsv.dtbsv("Upper","Transpose","Non-unit",n,kl+ku,ab,_ab_offset,ldab,b,(1)- 1+(i- 1)*ldb+ _b_offset,1);
Dummy.label("Dgbtrs",30);
}              //  Close for() loop. 
}
// *
// *        Solve L'*X = B, overwriting B with X.
// *
if (lnoti)  {
    {
int _j_inc = -1;
forloop40:
for (j = n-1; j >= 1; j += _j_inc) {
lm = (int)(Math.min(kl, n-j) );
Dgemv.dgemv("Transpose",lm,nrhs,-one,b,(j+1)- 1+(1- 1)*ldb+ _b_offset,ldb,ab,(kd+1)- 1+(j- 1)*ldab+ _ab_offset,1,one,b,(j)- 1+(1- 1)*ldb+ _b_offset,ldb);
l = ipiv[(j)- 1+ _ipiv_offset];
if (l != j)  
    Dswap.dswap(nrhs,b,(l)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(j)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dummy.label("Dgbtrs",40);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
Dummy.go_to("Dgbtrs",999999);
// *
// *     End of DGBTRS
// *
Dummy.label("Dgbtrs",999999);
return;
   }
} // End class.
