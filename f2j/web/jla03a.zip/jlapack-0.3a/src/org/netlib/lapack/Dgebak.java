/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgebak {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEBAK forms the right or left eigenvectors of a real general matrix
// *  by backward transformation on the computed eigenvectors of the
// *  balanced matrix output by DGEBAL.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          Specifies the type of backward transformation required:
// *          = 'N', do nothing, return immediately;
// *          = 'P', do backward transformation for permutation only;
// *          = 'S', do backward transformation for scaling only;
// *          = 'B', do backward transformations for both permutation and
// *                 scaling.
// *          JOB must be the same as the argument JOB supplied to DGEBAL.
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'R':  V contains right eigenvectors;
// *          = 'L':  V contains left eigenvectors.
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrix V.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          The integers ILO and IHI determined by DGEBAL.
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  SCALE   (input) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutation and scaling factors, as returned
// *          by DGEBAL.
// *
// *  M       (input) INTEGER
// *          The number of columns of the matrix V.  M >= 0.
// *
// *  V       (input/output) DOUBLE PRECISION array, dimension (LDV,M)
// *          On entry, the matrix of right or left eigenvectors to be
// *          transformed, as returned by DHSEIN or DTREVC.
// *          On exit, V is overwritten by the transformed eigenvectors.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V. LDV >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean leftv= false;
static boolean rightv= false;
static int i= 0;
static int ii= 0;
static int k= 0;
static double s= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode and Test the input parameters
// *

public static void dgebak (String job,
String side,
int n,
int ilo,
int ihi,
double [] scale, int _scale_offset,
int m,
double [] v, int _v_offset,
int ldv,
intW info)  {

rightv = (side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0));
leftv = (side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0));
// *
info.val = 0;
if (!(job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!rightv && !leftv)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (ilo < 1 || ilo > Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (ihi < Math.min(ilo, n)  || ihi > n)  {
    info.val = -5;
}              // Close else if()
else if (m < 0)  {
    info.val = -7;
}              // Close else if()
else if (ldv < Math.max(1, n) )  {
    info.val = -9;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEBAK",-info.val);
Dummy.go_to("Dgebak",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dgebak",999999);
if (m == 0)  
    Dummy.go_to("Dgebak",999999);
if ((job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  
    Dummy.go_to("Dgebak",999999);
// *
if (ilo == ihi)  
    Dummy.go_to("Dgebak",30);
// *
// *     Backward balance
// *
if ((job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    // *
if (rightv)  {
    {
forloop10:
for (i = ilo; i <= ihi; i++) {
s = scale[(i)- 1+ _scale_offset];
Dscal.dscal(m,s,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dgebak",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (leftv)  {
    {
forloop20:
for (i = ilo; i <= ihi; i++) {
s = one/scale[(i)- 1+ _scale_offset];
Dscal.dscal(m,s,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dgebak",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
// *
// *     Backward permutation
// *
// *     For  I = ILO-1 step -1 until 1,
// *              IHI+1 step 1 until N do --
// *
label30:
   Dummy.label("Dgebak",30);
if ((job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) || (job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    if (rightv)  {
    {
forloop40:
for (ii = 1; ii <= n; ii++) {
i = ii;
if (i >= ilo && i <= ihi)  
    continue forloop40;
if (i < ilo)  
    i = ilo-ii;
k = (int)(scale[(i)- 1+ _scale_offset]);
if (k == i)  
    continue forloop40;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dgebak",40);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (leftv)  {
    {
forloop50:
for (ii = 1; ii <= n; ii++) {
i = ii;
if (i >= ilo && i <= ihi)  
    continue forloop50;
if (i < ilo)  
    i = ilo-ii;
k = (int)(scale[(i)- 1+ _scale_offset]);
if (k == i)  
    continue forloop50;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dgebak",50);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
Dummy.go_to("Dgebak",999999);
// *
// *     End of DGEBAK
// *
Dummy.label("Dgebak",999999);
return;
   }
} // End class.
