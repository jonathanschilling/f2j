/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgebal {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEBAL balances a general real matrix A.  This involves, first,
// *  permuting A by a similarity transformation to isolate eigenvalues
// *  in the first 1 to ILO-1 and last IHI+1 to N elements on the
// *  diagonal; and second, applying a diagonal similarity transformation
// *  to rows and columns ILO to IHI to make the rows and columns as
// *  close in norm as possible.  Both steps are optional.
// *
// *  Balancing may reduce the 1-norm of the matrix, and improve the
// *  accuracy of the computed eigenvalues and/or eigenvectors.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          Specifies the operations to be performed on A:
// *          = 'N':  none:  simply set ILO = 1, IHI = N, SCALE(I) = 1.0
// *                  for i = 1,...,N;
// *          = 'P':  permute only;
// *          = 'S':  scale only;
// *          = 'B':  both permute and scale.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the input matrix A.
// *          On exit,  A is overwritten by the balanced matrix.
// *          If JOB = 'N', A is not referenced.
// *          See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  ILO     (output) INTEGER
// *  IHI     (output) INTEGER
// *          ILO and IHI are set to integers such that on exit
// *          A(i,j) = 0 if i > j and j = 1,...,ILO-1 or I = IHI+1,...,N.
// *          If JOB = 'N' or 'S', ILO = 1 and IHI = N.
// *
// *  SCALE   (output) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutations and scaling factors applied to
// *          A.  If P(j) is the index of the row and column interchanged
// *          with row and column j and D(j) is the scaling factor
// *          applied to row and column j, then
// *          SCALE(j) = P(j)    for j = 1,...,ILO-1
// *                   = D(j)    for j = ILO,...,IHI
// *                   = P(j)    for j = IHI+1,...,N.
// *          The order in which the interchanges are made is N to IHI+1,
// *          then 1 to ILO-1.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  The permutations consist of row and column interchanges which put
// *  the matrix in the form
// *
// *             ( T1   X   Y  )
// *     P A P = (  0   B   Z  )
// *             (  0   0   T2 )
// *
// *  where T1 and T2 are upper triangular matrices whose eigenvalues lie
// *  along the diagonal.  The column indices ILO and IHI mark the starting
// *  and ending columns of the submatrix B. Balancing consists of applying
// *  a diagonal similarity transformation inv(D) * B * D to make the
// *  1-norms of each row of B and its corresponding column nearly equal.
// *  The output matrix is
// *
// *     ( T1     X*D          Y    )
// *     (  0  inv(D)*B*D  inv(D)*Z ).
// *     (  0      0           T2   )
// *
// *  Information about the permutations P and the diagonal matrix D is
// *  returned in the vector SCALE.
// *
// *  This subroutine is based on the EISPACK routine BALANC.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double sclfac= 1.0e+1;
static double factor= 0.95e+0;
// *     ..
// *     .. Local Scalars ..
static boolean noconv= false;
static int i= 0;
static int ica= 0;
static int iexc= 0;
static int ira= 0;
static int j= 0;
static int k= 0;
static int l= 0;
static int m= 0;
static double c= 0.0;
static double ca= 0.0;
static double f= 0.0;
static double g= 0.0;
static double r= 0.0;
static double ra= 0.0;
static double s= 0.0;
static double sfmax1= 0.0;
static double sfmax2= 0.0;
static double sfmin1= 0.0;
static double sfmin2= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dgebal (String job,
int n,
double [] a, int _a_offset,
int lda,
intW ilo,
intW ihi,
double [] scale, int _scale_offset,
intW info)  {

info.val = 0;
if (!(job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEBAL",-info.val);
Dummy.go_to("Dgebal",999999);
}              // Close if()
// *
k = 1;
l = n;
// *
if (n == 0)  
    Dummy.go_to("Dgebal",210);
// *
if ((job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    {
forloop10:
for (i = 1; i <= n; i++) {
scale[(i)- 1+ _scale_offset] = one;
Dummy.label("Dgebal",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dgebal",210);
}              // Close if()
// *
if ((job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  
    Dummy.go_to("Dgebal",120);
// *
// *     Permutation to isolate eigenvalues if possible
// *
Dummy.go_to("Dgebal",50);
// *
// *     Row and column exchange.
// *
label20:
   Dummy.label("Dgebal",20);
scale[(m)- 1+ _scale_offset] = (double)(j);
if (j == m)  
    Dummy.go_to("Dgebal",30);
// *
Dswap.dswap(l,a,(1)- 1+(j- 1)*lda+ _a_offset,1,a,(1)- 1+(m- 1)*lda+ _a_offset,1);
Dswap.dswap(n-k+1,a,(j)- 1+(k- 1)*lda+ _a_offset,lda,a,(m)- 1+(k- 1)*lda+ _a_offset,lda);
// *
label30:
   Dummy.label("Dgebal",30);
if (iexc == 1) 
  Dummy.go_to("Dgebal",40);
else if (iexc == 2) 
  Dummy.go_to("Dgebal",80);
// *
// *     Search for rows isolating an eigenvalue and push them down.
// *
label40:
   Dummy.label("Dgebal",40);
if (l == 1)  
    Dummy.go_to("Dgebal",210);
l = l-1;
// *
label50:
   Dummy.label("Dgebal",50);
{
int _j_inc = -1;
forloop70:
for (j = l; j >= 1; j += _j_inc) {
// *
{
forloop60:
for (i = 1; i <= l; i++) {
if (i == j)  
    continue forloop60;
if (a[(j)- 1+(i- 1)*lda+ _a_offset] != zero)  
    continue forloop70;
Dummy.label("Dgebal",60);
}              //  Close for() loop. 
}
// *
m = l;
iexc = 1;
Dummy.go_to("Dgebal",20);
Dummy.label("Dgebal",70);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgebal",90);
// *
// *     Search for columns isolating an eigenvalue and push them left.
// *
label80:
   Dummy.label("Dgebal",80);
k = k+1;
// *
label90:
   Dummy.label("Dgebal",90);
{
forloop110:
for (j = k; j <= l; j++) {
// *
{
forloop100:
for (i = k; i <= l; i++) {
if (i == j)  
    continue forloop100;
if (a[(i)- 1+(j- 1)*lda+ _a_offset] != zero)  
    continue forloop110;
Dummy.label("Dgebal",100);
}              //  Close for() loop. 
}
// *
m = k;
iexc = 2;
Dummy.go_to("Dgebal",20);
Dummy.label("Dgebal",110);
}              //  Close for() loop. 
}
// *
label120:
   Dummy.label("Dgebal",120);
{
forloop130:
for (i = k; i <= l; i++) {
scale[(i)- 1+ _scale_offset] = one;
Dummy.label("Dgebal",130);
}              //  Close for() loop. 
}
// *
if ((job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)))  
    Dummy.go_to("Dgebal",210);
// *
// *     Balance the submatrix in rows K to L.
// *
// *     Iterative loop for norm reduction
// *
sfmin1 = Dlamch.dlamch("S")/Dlamch.dlamch("P");
sfmax1 = one/sfmin1;
sfmin2 = sfmin1*sclfac;
sfmax2 = one/sfmin2;
label140:
   Dummy.label("Dgebal",140);
noconv = false;
// *
{
forloop200:
for (i = k; i <= l; i++) {
c = zero;
r = zero;
// *
{
forloop150:
for (j = k; j <= l; j++) {
if (j == i)  
    continue forloop150;
c = c+Math.abs(a[(j)- 1+(i- 1)*lda+ _a_offset]);
r = r+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dgebal",150);
}              //  Close for() loop. 
}
ica = Idamax.idamax(l,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
ca = Math.abs(a[(ica)- 1+(i- 1)*lda+ _a_offset]);
ira = Idamax.idamax(n-k+1,a,(i)- 1+(k- 1)*lda+ _a_offset,lda);
ra = Math.abs(a[(i)- 1+(ira+k-1- 1)*lda+ _a_offset]);
// *
// *        Guard against zero C or R due to underflow.
// *
if (c == zero || r == zero)  
    continue forloop200;
g = r/sclfac;
f = one;
s = c+r;
label160:
   Dummy.label("Dgebal",160);
if (c >= g || Math.max((f) > (c) ? (f) : (c), ca) >= sfmax2 || Math.min((r) < (g) ? (r) : (g), ra) <= sfmin2)  
    Dummy.go_to("Dgebal",170);
f = f*sclfac;
c = c*sclfac;
ca = ca*sclfac;
r = r/sclfac;
g = g/sclfac;
ra = ra/sclfac;
Dummy.go_to("Dgebal",160);
// *
label170:
   Dummy.label("Dgebal",170);
g = c/sclfac;
label180:
   Dummy.label("Dgebal",180);
if (g < r || Math.max(r, ra)  >= sfmax2 || Math.min(Math.min(Math.min(f, c), g), ca)  <= sfmin2)  
    Dummy.go_to("Dgebal",190);
f = f/sclfac;
c = c/sclfac;
g = g/sclfac;
ca = ca/sclfac;
r = r*sclfac;
ra = ra*sclfac;
Dummy.go_to("Dgebal",180);
// *
// *        Now balance.
// *
label190:
   Dummy.label("Dgebal",190);
if ((c+r) >= factor*s)  
    continue forloop200;
if (f < one && scale[(i)- 1+ _scale_offset] < one)  {
    if (f*scale[(i)- 1+ _scale_offset] <= sfmin1)  
    continue forloop200;
}              // Close if()
if (f > one && scale[(i)- 1+ _scale_offset] > one)  {
    if (scale[(i)- 1+ _scale_offset] >= sfmax1/f)  
    continue forloop200;
}              // Close if()
g = one/f;
scale[(i)- 1+ _scale_offset] = scale[(i)- 1+ _scale_offset]*f;
noconv = true;
// *
Dscal.dscal(n-k+1,g,a,(i)- 1+(k- 1)*lda+ _a_offset,lda);
Dscal.dscal(l,f,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
// *
Dummy.label("Dgebal",200);
}              //  Close for() loop. 
}
// *
if (noconv)  
    Dummy.go_to("Dgebal",140);
// *
label210:
   Dummy.label("Dgebal",210);
ilo.val = k;
ihi.val = l;
// *
Dummy.go_to("Dgebal",999999);
// *
// *     End of DGEBAL
// *
Dummy.label("Dgebal",999999);
return;
   }
} // End class.
