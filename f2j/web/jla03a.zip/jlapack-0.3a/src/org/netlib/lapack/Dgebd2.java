/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgebd2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEBD2 reduces a real general m by n matrix A to upper or lower
// *  bidiagonal form B by an orthogonal transformation: Q' * A * P = B.
// *
// *  If m >= n, B is upper bidiagonal; if m < n, B is lower bidiagonal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows in the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns in the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the m by n general matrix to be reduced.
// *          On exit,
// *          if m >= n, the diagonal and the first superdiagonal are
// *            overwritten with the upper bidiagonal matrix B; the
// *            elements below the diagonal, with the array TAUQ, represent
// *            the orthogonal matrix Q as a product of elementary
// *            reflectors, and the elements above the first superdiagonal,
// *            with the array TAUP, represent the orthogonal matrix P as
// *            a product of elementary reflectors;
// *          if m < n, the diagonal and the first subdiagonal are
// *            overwritten with the lower bidiagonal matrix B; the
// *            elements below the first subdiagonal, with the array TAUQ,
// *            represent the orthogonal matrix Q as a product of
// *            elementary reflectors, and the elements above the diagonal,
// *            with the array TAUP, represent the orthogonal matrix P as
// *            a product of elementary reflectors.
// *          See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  D       (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The diagonal elements of the bidiagonal matrix B:
// *          D(i) = A(i,i).
// *
// *  E       (output) DOUBLE PRECISION array, dimension (min(M,N)-1)
// *          The off-diagonal elements of the bidiagonal matrix B:
// *          if m >= n, E(i) = A(i,i+1) for i = 1,2,...,n-1;
// *          if m < n, E(i) = A(i+1,i) for i = 1,2,...,m-1.
// *
// *  TAUQ    (output) DOUBLE PRECISION array dimension (min(M,N))
// *          The scalar factors of the elementary reflectors which
// *          represent the orthogonal matrix Q. See Further Details.
// *
// *  TAUP    (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors which
// *          represent the orthogonal matrix P. See Further Details.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (max(M,N))
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit.
// *          < 0: if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  The matrices Q and P are represented as products of elementary
// *  reflectors:
// *
// *  If m >= n,
// *
// *     Q = H(1) H(2) . . . H(n)  and  P = G(1) G(2) . . . G(n-1)
// *
// *  Each H(i) and G(i) has the form:
// *
// *     H(i) = I - tauq * v * v'  and G(i) = I - taup * u * u'
// *
// *  where tauq and taup are real scalars, and v and u are real vectors;
// *  v(1:i-1) = 0, v(i) = 1, and v(i+1:m) is stored on exit in A(i+1:m,i);
// *  u(1:i) = 0, u(i+1) = 1, and u(i+2:n) is stored on exit in A(i,i+2:n);
// *  tauq is stored in TAUQ(i) and taup in TAUP(i).
// *
// *  If m < n,
// *
// *     Q = H(1) H(2) . . . H(m-1)  and  P = G(1) G(2) . . . G(m)
// *
// *  Each H(i) and G(i) has the form:
// *
// *     H(i) = I - tauq * v * v'  and G(i) = I - taup * u * u'
// *
// *  where tauq and taup are real scalars, and v and u are real vectors;
// *  v(1:i) = 0, v(i+1) = 1, and v(i+2:m) is stored on exit in A(i+2:m,i);
// *  u(1:i-1) = 0, u(i) = 1, and u(i+1:n) is stored on exit in A(i,i+1:n);
// *  tauq is stored in TAUQ(i) and taup in TAUP(i).
// *
// *  The contents of A on exit are illustrated by the following examples:
// *
// *  m = 6 and n = 5 (m > n):          m = 5 and n = 6 (m < n):
// *
// *    (  d   e   u1  u1  u1 )           (  d   u1  u1  u1  u1  u1 )
// *    (  v1  d   e   u2  u2 )           (  e   d   u2  u2  u2  u2 )
// *    (  v1  v2  d   e   u3 )           (  v1  e   d   u3  u3  u3 )
// *    (  v1  v2  v3  d   e  )           (  v1  v2  e   d   u4  u4 )
// *    (  v1  v2  v3  v4  d  )           (  v1  v2  v3  e   d   u5 )
// *    (  v1  v2  v3  v4  v5 )
// *
// *  where d and e denote diagonal and off-diagonal elements of B, vi
// *  denotes an element of the vector defining H(i), and ui an element of
// *  the vector defining G(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dgebd2 (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] tauq, int _tauq_offset,
double [] taup, int _taup_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val < 0)  {
    Xerbla.xerbla("DGEBD2",-info.val);
Dummy.go_to("Dgebd2",999999);
}              // Close if()
// *
if (m >= n)  {
    // *
// *        Reduce to upper bidiagonal form
// *
{
forloop10:
for (i = 1; i <= n; i++) {
// *
// *           Generate elementary reflector H(i) to annihilate A(i+1:m,i)
// *
dlarfg_adapter(m-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(i+1, m) )- 1+(i- 1)*lda+ _a_offset),1,tauq,(i)- 1+ _tauq_offset);
d[(i)- 1+ _d_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *           Apply H(i) to A(i:m,i+1:n) from the left
// *
Dlarf.dlarf("Left",m-i+1,n-i,a,(i)- 1+(i- 1)*lda+ _a_offset,1,tauq[(i)- 1+ _tauq_offset],a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,work,_work_offset);
a[(i)- 1+(i- 1)*lda+ _a_offset] = d[(i)- 1+ _d_offset];
// *
if (i < n)  {
    // *
// *              Generate elementary reflector G(i) to annihilate
// *              A(i,i+2:n)
// *
dlarfg_adapter(n-i,a,(i)- 1+(i+1- 1)*lda+ _a_offset,a,(i)- 1+(Math.min(i+2, n) - 1)*lda+ _a_offset,lda,taup,(i)- 1+ _taup_offset);
e[(i)- 1+ _e_offset] = a[(i)- 1+(i+1- 1)*lda+ _a_offset];
a[(i)- 1+(i+1- 1)*lda+ _a_offset] = one;
// *
// *              Apply G(i) to A(i+1:m,i+1:n) from the right
// *
Dlarf.dlarf("Right",m-i,n-i,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,taup[(i)- 1+ _taup_offset],a,(i+1)- 1+(i+1- 1)*lda+ _a_offset,lda,work,_work_offset);
a[(i)- 1+(i+1- 1)*lda+ _a_offset] = e[(i)- 1+ _e_offset];
}              // Close if()
else  {
  taup[(i)- 1+ _taup_offset] = zero;
}              //  Close else.
Dummy.label("Dgebd2",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Reduce to lower bidiagonal form
// *
{
forloop20:
for (i = 1; i <= m; i++) {
// *
// *           Generate elementary reflector G(i) to annihilate A(i,i+1:n)
// *
dlarfg_adapter(n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(i)- 1+(Math.min(i+1, n) - 1)*lda+ _a_offset,lda,taup,(i)- 1+ _taup_offset);
d[(i)- 1+ _d_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *           Apply G(i) to A(i+1:m,i:n) from the right
// *
Dlarf.dlarf("Right",m-i,n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,taup[(i)- 1+ _taup_offset],a,(int)((Math.min(i+1, m) )- 1+(i- 1)*lda+ _a_offset),lda,work,_work_offset);
a[(i)- 1+(i- 1)*lda+ _a_offset] = d[(i)- 1+ _d_offset];
// *
if (i < m)  {
    // *
// *              Generate elementary reflector H(i) to annihilate
// *              A(i+2:m,i)
// *
dlarfg_adapter(m-i,a,(i+1)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(i+2, m) )- 1+(i- 1)*lda+ _a_offset),1,tauq,(i)- 1+ _tauq_offset);
e[(i)- 1+ _e_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
a[(i+1)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Apply H(i) to A(i+1:m,i+1:n) from the left
// *
Dlarf.dlarf("Left",m-i,n-i,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,tauq[(i)- 1+ _tauq_offset],a,(i+1)- 1+(i+1- 1)*lda+ _a_offset,lda,work,_work_offset);
a[(i+1)- 1+(i- 1)*lda+ _a_offset] = e[(i)- 1+ _e_offset];
}              // Close if()
else  {
  tauq[(i)- 1+ _tauq_offset] = zero;
}              //  Close else.
Dummy.label("Dgebd2",20);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dgebd2",999999);
// *
// *     End of DGEBD2
// *
Dummy.label("Dgebd2",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
