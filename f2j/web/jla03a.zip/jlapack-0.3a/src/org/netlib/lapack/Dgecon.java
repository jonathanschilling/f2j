/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgecon {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGECON estimates the reciprocal of the condition number of a general
// *  real matrix A, in either the 1-norm or the infinity-norm, using
// *  the LU factorization computed by DGETRF.
// *
// *  An estimate is obtained for norm(inv(A)), and the reciprocal of the
// *  condition number is computed as
// *     RCOND = 1 / ( norm(A) * norm(inv(A)) ).
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies whether the 1-norm condition number or the
// *          infinity-norm condition number is required:
// *          = '1' or 'O':  1-norm;
// *          = 'I':         Infinity-norm.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The factors L and U from the factorization A = P*L*U
// *          as computed by DGETRF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  ANORM   (input) DOUBLE PRECISION
// *          If NORM = '1' or 'O', the 1-norm of the original matrix A.
// *          If NORM = 'I', the infinity-norm of the original matrix A.
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of the matrix A,
// *          computed as RCOND = 1/(norm(A) * norm(inv(A))).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (4*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean onenrm= false;
static String normin= new String(" ");
static int ix= 0;
static intW kase= new intW(0);
static int kase1= 0;
static doubleW ainvnm= new doubleW(0.0);
static double scale= 0.0;
static doubleW sl= new doubleW(0.0);
static double smlnum= 0.0;
static doubleW su= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgecon (String norm,
int n,
double [] a, int _a_offset,
int lda,
double anorm,
doubleW rcond,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
onenrm = norm.trim().equalsIgnoreCase("1".trim()) || (norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0));
if (!onenrm && !(norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (anorm < zero)  {
    info.val = -5;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGECON",-info.val);
Dummy.go_to("Dgecon",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
rcond.val = zero;
if (n == 0)  {
    rcond.val = one;
Dummy.go_to("Dgecon",999999);
}              // Close if()
else if (anorm == zero)  {
    Dummy.go_to("Dgecon",999999);
}              // Close else if()
// *
smlnum = Dlamch.dlamch("Safe minimum");
// *
// *     Estimate the norm of inv(A).
// *
ainvnm.val = zero;
normin = "N";
if (onenrm)  {
    kase1 = 1;
}              // Close if()
else  {
  kase1 = 2;
}              //  Close else.
kase.val = 0;
label10:
   Dummy.label("Dgecon",10);
Dlacon.dlacon(n,work,(n+1)- 1+ _work_offset,work,_work_offset,iwork,_iwork_offset,ainvnm,kase);
if (kase.val != 0)  {
    if (kase.val == kase1)  {
    // *
// *           Multiply by inv(L).
// *
Dlatrs.dlatrs("Lower","No transpose","Unit",normin,n,a,_a_offset,lda,work,_work_offset,sl,work,(2*n+1)- 1+ _work_offset,info);
// *
// *           Multiply by inv(U).
// *
Dlatrs.dlatrs("Upper","No transpose","Non-unit",normin,n,a,_a_offset,lda,work,_work_offset,su,work,(3*n+1)- 1+ _work_offset,info);
}              // Close if()
else  {
  // *
// *           Multiply by inv(U').
// *
Dlatrs.dlatrs("Upper","Transpose","Non-unit",normin,n,a,_a_offset,lda,work,_work_offset,su,work,(3*n+1)- 1+ _work_offset,info);
// *
// *           Multiply by inv(L').
// *
Dlatrs.dlatrs("Lower","Transpose","Unit",normin,n,a,_a_offset,lda,work,_work_offset,sl,work,(2*n+1)- 1+ _work_offset,info);
}              //  Close else.
// *
// *        Divide X by 1/(SL*SU) if doing so will not cause overflow.
// *
scale = sl.val*su.val;
normin = "Y";
if (scale != one)  {
    ix = Idamax.idamax(n,work,_work_offset,1);
if (scale < Math.abs(work[(ix)- 1+ _work_offset])*smlnum || scale == zero)  
    Dummy.go_to("Dgecon",20);
Drscl.drscl(n,scale,work,_work_offset,1);
}              // Close if()
Dummy.go_to("Dgecon",10);
}              // Close if()
// *
// *     Compute the estimate of the reciprocal condition number.
// *
if (ainvnm.val != zero)  
    rcond.val = (one/ainvnm.val)/anorm;
// *
label20:
   Dummy.label("Dgecon",20);
Dummy.go_to("Dgecon",999999);
// *
// *     End of DGECON
// *
Dummy.label("Dgecon",999999);
return;
   }
} // End class.
