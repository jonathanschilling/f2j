/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgeequ {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEEQU computes row and column scalings intended to equilibrate an
// *  M-by-N matrix A and reduce its condition number.  R returns the row
// *  scale factors and C the column scale factors, chosen to try to make
// *  the largest element in each row and column of the matrix B with
// *  elements B(i,j)=R(i)*A(i,j)*C(j) have absolute value 1.
// *
// *  R(i) and C(j) are restricted to be between SMLNUM = smallest safe
// *  number and BIGNUM = largest safe number.  Use of these scaling
// *  factors is not guaranteed to reduce the condition number of A but
// *  works well in practice.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix whose equilibration factors are
// *          to be computed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  R       (output) DOUBLE PRECISION array, dimension (M)
// *          If INFO = 0 or INFO > M, R contains the row scale factors
// *          for A.
// *
// *  C       (output) DOUBLE PRECISION array, dimension (N)
// *          If INFO = 0,  C contains the column scale factors for A.
// *
// *  ROWCND  (output) DOUBLE PRECISION
// *          If INFO = 0 or INFO > M, ROWCND contains the ratio of the
// *          smallest R(i) to the largest R(i).  If ROWCND >= 0.1 and
// *          AMAX is neither too large nor too small, it is not worth
// *          scaling by R.
// *
// *  COLCND  (output) DOUBLE PRECISION
// *          If INFO = 0, COLCND contains the ratio of the smallest
// *          C(i) to the largest C(i).  If COLCND >= 0.1, it is not
// *          worth scaling by C.
// *
// *  AMAX    (output) DOUBLE PRECISION
// *          Absolute value of largest matrix element.  If AMAX is very
// *          close to overflow or very close to underflow, the matrix
// *          should be scaled.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i,  and i is
// *                <= M:  the i-th row of A is exactly zero
// *                >  M:  the (i-M)-th column of A is exactly zero
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double bignum= 0.0;
static double rcmax= 0.0;
static double rcmin= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgeequ (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] r, int _r_offset,
double [] c, int _c_offset,
doubleW rowcnd,
doubleW colcnd,
doubleW amax,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEEQU",-info.val);
Dummy.go_to("Dgeequ",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  {
    rowcnd.val = one;
colcnd.val = one;
amax.val = zero;
Dummy.go_to("Dgeequ",999999);
}              // Close if()
// *
// *     Get machine constants.
// *
smlnum = Dlamch.dlamch("S");
bignum = one/smlnum;
// *
// *     Compute row scale factors.
// *
{
forloop10:
for (i = 1; i <= m; i++) {
r[(i)- 1+ _r_offset] = zero;
Dummy.label("Dgeequ",10);
}              //  Close for() loop. 
}
// *
// *     Find the maximum element in each row.
// *
{
forloop30:
for (j = 1; j <= n; j++) {
{
forloop20:
for (i = 1; i <= m; i++) {
r[(i)- 1+ _r_offset] = Math.max(r[(i)- 1+ _r_offset], Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dgeequ",20);
}              //  Close for() loop. 
}
Dummy.label("Dgeequ",30);
}              //  Close for() loop. 
}
// *
// *     Find the maximum and minimum scale factors.
// *
rcmin = bignum;
rcmax = zero;
{
forloop40:
for (i = 1; i <= m; i++) {
rcmax = Math.max(rcmax, r[(i)- 1+ _r_offset]) ;
rcmin = Math.min(rcmin, r[(i)- 1+ _r_offset]) ;
Dummy.label("Dgeequ",40);
}              //  Close for() loop. 
}
amax.val = rcmax;
// *
if (rcmin == zero)  {
    // *
// *        Find the first zero scale factor and return an error code.
// *
{
forloop50:
for (i = 1; i <= m; i++) {
if (r[(i)- 1+ _r_offset] == zero)  {
    info.val = i;
Dummy.go_to("Dgeequ",999999);
}              // Close if()
Dummy.label("Dgeequ",50);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Invert the scale factors.
// *
{
forloop60:
for (i = 1; i <= m; i++) {
r[(i)- 1+ _r_offset] = one/Math.min(Math.max(r[(i)- 1+ _r_offset], smlnum) , bignum) ;
Dummy.label("Dgeequ",60);
}              //  Close for() loop. 
}
// *
// *        Compute ROWCND = min(R(I)) / max(R(I))
// *
rowcnd.val = Math.max(rcmin, smlnum) /Math.min(rcmax, bignum) ;
}              //  Close else.
// *
// *     Compute column scale factors
// *
{
forloop70:
for (j = 1; j <= n; j++) {
c[(j)- 1+ _c_offset] = zero;
Dummy.label("Dgeequ",70);
}              //  Close for() loop. 
}
// *
// *     Find the maximum element in each column,
// *     assuming the row scaling computed above.
// *
{
forloop90:
for (j = 1; j <= n; j++) {
{
forloop80:
for (i = 1; i <= m; i++) {
c[(j)- 1+ _c_offset] = Math.max(c[(j)- 1+ _c_offset], Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])*r[(i)- 1+ _r_offset]) ;
Dummy.label("Dgeequ",80);
}              //  Close for() loop. 
}
Dummy.label("Dgeequ",90);
}              //  Close for() loop. 
}
// *
// *     Find the maximum and minimum scale factors.
// *
rcmin = bignum;
rcmax = zero;
{
forloop100:
for (j = 1; j <= n; j++) {
rcmin = Math.min(rcmin, c[(j)- 1+ _c_offset]) ;
rcmax = Math.max(rcmax, c[(j)- 1+ _c_offset]) ;
Dummy.label("Dgeequ",100);
}              //  Close for() loop. 
}
// *
if (rcmin == zero)  {
    // *
// *        Find the first zero scale factor and return an error code.
// *
{
forloop110:
for (j = 1; j <= n; j++) {
if (c[(j)- 1+ _c_offset] == zero)  {
    info.val = m+j;
Dummy.go_to("Dgeequ",999999);
}              // Close if()
Dummy.label("Dgeequ",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Invert the scale factors.
// *
{
forloop120:
for (j = 1; j <= n; j++) {
c[(j)- 1+ _c_offset] = one/Math.min(Math.max(c[(j)- 1+ _c_offset], smlnum) , bignum) ;
Dummy.label("Dgeequ",120);
}              //  Close for() loop. 
}
// *
// *        Compute COLCND = min(C(J)) / max(C(J))
// *
colcnd.val = Math.max(rcmin, smlnum) /Math.min(rcmax, bignum) ;
}              //  Close else.
// *
Dummy.go_to("Dgeequ",999999);
// *
// *     End of DGEEQU
// *
Dummy.label("Dgeequ",999999);
return;
   }
} // End class.
