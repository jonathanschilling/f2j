/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import java.lang.reflect.*;
import org.netlib.blas.*;


public class Dgeesx {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *     .. Function Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEESX computes for an N-by-N real nonsymmetric matrix A, the
// *  eigenvalues, the real Schur form T, and, optionally, the matrix of
// *  Schur vectors Z.  This gives the Schur factorization A = Z*T*(Z**T).
// *
// *  Optionally, it also orders the eigenvalues on the diagonal of the
// *  real Schur form so that selected eigenvalues are at the top left;
// *  computes a reciprocal condition number for the average of the
// *  selected eigenvalues (RCONDE); and computes a reciprocal condition
// *  number for the right invariant subspace corresponding to the
// *  selected eigenvalues (RCONDV).  The leading columns of Z form an
// *  orthonormal basis for this invariant subspace.
// *
// *  For further explanation of the reciprocal condition numbers RCONDE
// *  and RCONDV, see Section 4.10 of the LAPACK Users' Guide (where
// *  these quantities are called s and sep respectively).
// *
// *  A real matrix is in real Schur form if it is upper quasi-triangular
// *  with 1-by-1 and 2-by-2 blocks. 2-by-2 blocks will be standardized in
// *  the form
// *            [  a  b  ]
// *            [  c  a  ]
// *
// *  where b*c < 0. The eigenvalues of such a block are a +- sqrt(bc).
// *
// *  Arguments
// *  =========
// *
// *  JOBVS   (input) CHARACTER*1
// *          = 'N': Schur vectors are not computed;
// *          = 'V': Schur vectors are computed.
// *
// *  SORT    (input) CHARACTER*1
// *          Specifies whether or not to order the eigenvalues on the
// *          diagonal of the Schur form.
// *          = 'N': Eigenvalues are not ordered;
// *          = 'S': Eigenvalues are ordered (see SELECT).
// *
// *  SELECT  (input) LOGICAL FUNCTION of two DOUBLE PRECISION arguments
// *          SELECT must be declared EXTERNAL in the calling subroutine.
// *          If SORT = 'S', SELECT is used to select eigenvalues to sort
// *          to the top left of the Schur form.
// *          If SORT = 'N', SELECT is not referenced.
// *          An eigenvalue WR(j)+sqrt(-1)*WI(j) is selected if
// *          SELECT(WR(j),WI(j)) is true; i.e., if either one of a
// *          complex conjugate pair of eigenvalues is selected, then both
// *          are.  Note that a selected complex eigenvalue may no longer
// *          satisfy SELECT(WR(j),WI(j)) = .TRUE. after ordering, since
// *          ordering may change the value of complex eigenvalues
// *          (especially if the eigenvalue is ill-conditioned); in this
// *          case INFO may be set to N+3 (see INFO below).
// *
// *  SENSE   (input) CHARACTER*1
// *          Determines which reciprocal condition numbers are computed.
// *          = 'N': None are computed;
// *          = 'E': Computed for average of selected eigenvalues only;
// *          = 'V': Computed for selected right invariant subspace only;
// *          = 'B': Computed for both.
// *          If SENSE = 'E', 'V' or 'B', SORT must equal 'S'.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A. N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          On entry, the N-by-N matrix A.
// *          On exit, A is overwritten by its real Schur form T.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  SDIM    (output) INTEGER
// *          If SORT = 'N', SDIM = 0.
// *          If SORT = 'S', SDIM = number of eigenvalues (after sorting)
// *                         for which SELECT is true. (Complex conjugate
// *                         pairs for which SELECT is true for either
// *                         eigenvalue count as 2.)
// *
// *  WR      (output) DOUBLE PRECISION array, dimension (N)
// *  WI      (output) DOUBLE PRECISION array, dimension (N)
// *          WR and WI contain the real and imaginary parts, respectively,
// *          of the computed eigenvalues, in the same order that they
// *          appear on the diagonal of the output Schur form T.  Complex
// *          conjugate pairs of eigenvalues appear consecutively with the
// *          eigenvalue having the positive imaginary part first.
// *
// *  VS      (output) DOUBLE PRECISION array, dimension (LDVS,N)
// *          If JOBVS = 'V', VS contains the orthogonal matrix Z of Schur
// *          vectors.
// *          If JOBVS = 'N', VS is not referenced.
// *
// *  LDVS    (input) INTEGER
// *          The leading dimension of the array VS.  LDVS >= 1, and if
// *          JOBVS = 'V', LDVS >= N.
// *
// *  RCONDE  (output) DOUBLE PRECISION
// *          If SENSE = 'E' or 'B', RCONDE contains the reciprocal
// *          condition number for the average of the selected eigenvalues.
// *          Not referenced if SENSE = 'N' or 'V'.
// *
// *  RCONDV  (output) DOUBLE PRECISION
// *          If SENSE = 'V' or 'B', RCONDV contains the reciprocal
// *          condition number for the selected right invariant subspace.
// *          Not referenced if SENSE = 'N' or 'E'.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,3*N).
// *          Also, if SENSE = 'E' or 'V' or 'B',
// *          LWORK >= N+2*SDIM*(N-SDIM), where SDIM is the number of
// *          selected eigenvalues computed by this routine.  Note that
// *          N+2*SDIM*(N-SDIM) <= N+N*N/2.
// *          For good performance, LWORK must generally be larger.
// *
// *  IWORK   (workspace) INTEGER array, dimension (LIWORK)
// *          Not referenced if SENSE = 'N' or 'E'.
// *
// *  LIWORK  (input) INTEGER
// *          The dimension of the array IWORK.
// *          LIWORK >= 1; if SENSE = 'V' or 'B', LIWORK >= SDIM*(N-SDIM).
// *
// *  BWORK   (workspace) LOGICAL array, dimension (N)
// *          Not referenced if SORT = 'N'.
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value.
// *          > 0: if INFO = i, and i is
// *             <= N: the QR algorithm failed to compute all the
// *                   eigenvalues; elements 1:ILO-1 and i+1:N of WR and WI
// *                   contain those eigenvalues which have converged; if
// *                   JOBVS = 'V', VS contains the transformation which
// *                   reduces A to its partially converged Schur form.
// *             = N+1: the eigenvalues could not be reordered because some
// *                   eigenvalues were too close to separate (the problem
// *                   is very ill-conditioned);
// *             = N+2: after reordering, roundoff changed values of some
// *                   complex eigenvalues so that leading eigenvalues in
// *                   the Schur form no longer satisfy SELECT=.TRUE.  This
// *                   could also be caused by underflow due to scaling.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean cursl= false;
static boolean lastsl= false;
static boolean lst2sl= false;
static boolean scalea= false;
static boolean wantsb= false;
static boolean wantse= false;
static boolean wantsn= false;
static boolean wantst= false;
static boolean wantsv= false;
static boolean wantvs= false;
static int hswork= 0;
static int i= 0;
static int i1= 0;
static int i2= 0;
static int ibal= 0;
static intW icond= new intW(0);
static intW ierr= new intW(0);
static intW ieval= new intW(0);
static intW ihi= new intW(0);
static intW ilo= new intW(0);
static int inxt= 0;
static int ip= 0;
static int itau= 0;
static int iwrk= 0;
static int k= 0;
static int maxb= 0;
static int maxwrk= 0;
static int minwrk= 0;
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double cscale= 0.0;
static double eps= 0.0;
static doubleW smlnum= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] dum= new double[(1)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgeesx (String jobvs,
String sort,
Object select,
String sense,
int n,
double [] a, int _a_offset,
int lda,
intW sdim,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] vs, int _vs_offset,
int ldvs,
doubleW rconde,
doubleW rcondv,
double [] work, int _work_offset,
int lwork,
int [] iwork, int _iwork_offset,
int liwork,
boolean [] bwork, int _bwork_offset,
intW info)  {

  java.lang.reflect.Method _select_meth  = select.getClass().getDeclaredMethods()[0];
try {
info.val = 0;
wantvs = (jobvs.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
wantst = (sort.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0));
wantsn = (sense.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
wantse = (sense.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0));
wantsv = (sense.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
wantsb = (sense.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
if ((!wantvs) && (!(jobvs.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -1;
}              // Close if()
else if ((!wantst) && (!(sort.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -2;
}              // Close else if()
else if (!(wantsn || wantse || wantsv || wantsb) || (!wantst && !wantsn))  {
    info.val = -4;
}              // Close else if()
else if (n < 0)  {
    info.val = -5;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldvs < 1 || (wantvs && ldvs < n))  {
    info.val = -12;
}              // Close else if()
// *
// *     Compute workspace
// *      (Note: Comments in the code beginning "RWorkspace:" describe the
// *       minimal amount of real workspace needed at that point in the
// *       code, as well as the preferred amount for good performance.
// *       IWorkspace refers to integer workspace.
// *       NB refers to the optimal block size for the immediately
// *       following subroutine, as returned by ILAENV.
// *       HSWORK refers to the workspace preferred by DHSEQR, as
// *       calculated below. HSWORK is computed assuming ILO=1 and IHI=N,
// *       the worst case.
// *       If SENSE = 'E', 'V' or 'B', then the amount of workspace needed
// *       depends on SDIM, which is computed by the routine DTRSEN later
// *       in the code.)
// *
minwrk = 1;
if (info.val == 0 && lwork >= 1)  {
    maxwrk = 2*n+n*Ilaenv.ilaenv(1,"DGEHRD"," ",n,1,n,0);
minwrk = (int)(Math.max(1, 3*n) );
if (!wantvs)  {
    maxb = (int)(Math.max(Ilaenv.ilaenv(8,"DHSEQR","SN",n,1,n,-1), 2) );
k = (int)(Math.min((maxb) < (n) ? (maxb) : (n), Math.max(2, Ilaenv.ilaenv(4,"DHSEQR","SN",n,1,n,-1)) ));
hswork = (int)(Math.max(k*(k+2), 2*n) );
maxwrk = (int)(Math.max((maxwrk) > (n+hswork) ? (maxwrk) : (n+hswork), 1));
}              // Close if()
else  {
  maxwrk = (int)(Math.max(maxwrk, 2*n+(n-1)*Ilaenv.ilaenv(1,"DORGHR"," ",n,1,n,-1)) );
maxb = (int)(Math.max(Ilaenv.ilaenv(8,"DHSEQR","SV",n,1,n,-1), 2) );
k = (int)(Math.min((maxb) < (n) ? (maxb) : (n), Math.max(2, Ilaenv.ilaenv(4,"DHSEQR","SV",n,1,n,-1)) ));
hswork = (int)(Math.max(k*(k+2), 2*n) );
maxwrk = (int)(Math.max((maxwrk) > (n+hswork) ? (maxwrk) : (n+hswork), 1));
}              //  Close else.
work[(1)- 1+ _work_offset] = (double)(maxwrk);
}              // Close if()
if (lwork < minwrk)  {
    info.val = -16;
}              // Close if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEESX",-info.val);
Dummy.go_to("Dgeesx",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  {
    sdim.val = 0;
Dummy.go_to("Dgeesx",999999);
}              // Close if()
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
smlnum.val = Math.sqrt(smlnum.val)/eps;
bignum.val = one/smlnum.val;
// *
// *     Scale A if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",n,n,a,_a_offset,lda,dum,0);
scalea = false;
if (anrm > zero && anrm < smlnum.val)  {
    scalea = true;
cscale = smlnum.val;
}              // Close if()
else if (anrm > bignum.val)  {
    scalea = true;
cscale = bignum.val;
}              // Close else if()
if (scalea)  
    Dlascl.dlascl("G",0,0,anrm,cscale,n,n,a,_a_offset,lda,ierr);
// *
// *     Permute the matrix to make it more nearly triangular
// *     (RWorkspace: need N)
// *
ibal = 1;
Dgebal.dgebal("P",n,a,_a_offset,lda,ilo,ihi,work,(ibal)- 1+ _work_offset,ierr);
// *
// *     Reduce to upper Hessenberg form
// *     (RWorkspace: need 3*N, prefer 2*N+N*NB)
// *
itau = n+ibal;
iwrk = n+itau;
Dgehrd.dgehrd(n,ilo.val,ihi.val,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ierr);
// *
if (wantvs)  {
    // *
// *        Copy Householder vectors to VS
// *
Dlacpy.dlacpy("L",n,n,a,_a_offset,lda,vs,_vs_offset,ldvs);
// *
// *        Generate orthogonal matrix in VS
// *        (RWorkspace: need 3*N-1, prefer 2*N+(N-1)*NB)
// *
Dorghr.dorghr(n,ilo.val,ihi.val,vs,_vs_offset,ldvs,work,(itau)- 1+ _work_offset,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ierr);
}              // Close if()
// *
sdim.val = 0;
// *
// *     Perform QR iteration, accumulating Schur vectors in VS if desired
// *     (RWorkspace: need N+1, prefer N+HSWORK (see comments) )
// *
iwrk = itau;
Dhseqr.dhseqr("S",jobvs,n,ilo.val,ihi.val,a,_a_offset,lda,wr,_wr_offset,wi,_wi_offset,vs,_vs_offset,ldvs,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ieval);
if (ieval.val > 0)  
    info.val = ieval.val;
// *
// *     Sort eigenvalues if desired
// *
if (wantst && info.val == 0)  {
    if (scalea)  {
    Dlascl.dlascl("G",0,0,cscale,anrm,n,1,wr,_wr_offset,n,ierr);
Dlascl.dlascl("G",0,0,cscale,anrm,n,1,wi,_wi_offset,n,ierr);
}              // Close if()
{
forloop10:
for (i = 1; i <= n; i++) {
bwork[(i)- 1+ _bwork_offset] = select_methcall(_select_meth,wr[(i)- 1+ _wr_offset],wi[(i)- 1+ _wi_offset]);
Dummy.label("Dgeesx",10);
}              //  Close for() loop. 
}
// *
// *        Reorder eigenvalues, transform Schur vectors, and compute
// *        reciprocal condition numbers
// *        (RWorkspace: if SENSE is not 'N', need N+2*SDIM*(N-SDIM)
// *                     otherwise, need N )
// *        (IWorkspace: if SENSE is 'V' or 'B', need SDIM*(N-SDIM)
// *                     otherwise, need 0 )
// *
Dtrsen.dtrsen(sense,jobvs,bwork,_bwork_offset,n,a,_a_offset,lda,vs,_vs_offset,ldvs,wr,_wr_offset,wi,_wi_offset,sdim,rconde,rcondv,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,iwork,_iwork_offset,liwork,icond);
if (!wantsn)  
    maxwrk = (int)(Math.max(maxwrk, n+2*sdim.val*(n-sdim.val)) );
if (icond.val == -15)  {
    // *
// *           Not enough real workspace
// *
info.val = -16;
}              // Close if()
else if (icond.val == -17)  {
    // *
// *           Not enough integer workspace
// *
info.val = -18;
}              // Close else if()
else if (icond.val > 0)  {
    // *
// *           DTRSEN failed to reorder or to restore standard Schur form
// *
info.val = icond.val+n;
}              // Close else if()
}              // Close if()
// *
if (wantvs)  {
    // *
// *        Undo balancing
// *        (RWorkspace: need N)
// *
Dgebak.dgebak("P","R",n,ilo.val,ihi.val,work,(ibal)- 1+ _work_offset,n,vs,_vs_offset,ldvs,ierr);
}              // Close if()
// *
if (scalea)  {
    // *
// *        Undo scaling for the Schur form of A
// *
Dlascl.dlascl("H",0,0,cscale,anrm,n,n,a,_a_offset,lda,ierr);
Dcopy.dcopy(n,a,_a_offset,lda+1,wr,_wr_offset,1);
if ((wantsv || wantsb) && info.val == 0)  {
    dum[(1)- 1] = rcondv.val;
Dlascl.dlascl("G",0,0,cscale,anrm,1,1,dum,0,1,ierr);
rcondv.val = dum[(1)- 1];
}              // Close if()
if (cscale == smlnum.val)  {
    // *
// *           If scaling back towards underflow, adjust WI if an
// *           offdiagonal element of a 2-by-2 block in the Schur form
// *           underflows.
// *
if (ieval.val > 0)  {
    i1 = ieval.val+1;
i2 = ihi.val-1;
Dlascl.dlascl("G",0,0,cscale,anrm,ilo.val-1,1,wi,_wi_offset,n,ierr);
}              // Close if()
else if (wantst)  {
    i1 = 1;
i2 = n-1;
}              // Close else if()
else  {
  i1 = ilo.val;
i2 = ihi.val-1;
}              //  Close else.
inxt = i1-1;
{
forloop20:
for (i = i1; i <= i2; i++) {
if (i < inxt)  
    continue forloop20;
if (wi[(i)- 1+ _wi_offset] == zero)  {
    inxt = i+1;
}              // Close if()
else  {
  if (a[(i+1)- 1+(i- 1)*lda+ _a_offset] == zero)  {
    wi[(i)- 1+ _wi_offset] = zero;
wi[(i+1)- 1+ _wi_offset] = zero;
}              // Close if()
else if (a[(i+1)- 1+(i- 1)*lda+ _a_offset] != zero && a[(i)- 1+(i+1- 1)*lda+ _a_offset] == zero)  {
    wi[(i)- 1+ _wi_offset] = zero;
wi[(i+1)- 1+ _wi_offset] = zero;
if (i > 1)  
    Dswap.dswap(i-1,a,(1)- 1+(i- 1)*lda+ _a_offset,1,a,(1)- 1+(i+1- 1)*lda+ _a_offset,1);
if (n > i+1)  
    Dswap.dswap(n-i-1,a,(i)- 1+(i+2- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i+2- 1)*lda+ _a_offset,lda);
Dswap.dswap(n,vs,(1)- 1+(i- 1)*ldvs+ _vs_offset,1,vs,(1)- 1+(i+1- 1)*ldvs+ _vs_offset,1);
a[(i)- 1+(i+1- 1)*lda+ _a_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
a[(i+1)- 1+(i- 1)*lda+ _a_offset] = zero;
}              // Close else if()
inxt = i+2;
}              //  Close else.
Dummy.label("Dgeesx",20);
}              //  Close for() loop. 
}
}              // Close if()
Dlascl.dlascl("G",0,0,cscale,anrm,n-ieval.val,1,wi,(ieval.val+1)- 1+ _wi_offset,(int) ( Math.max(n-ieval.val, 1) ),ierr);
}              // Close if()
// *
if (wantst && info.val == 0)  {
    // *
// *        Check if reordering successful
// *
lastsl = true;
lst2sl = true;
sdim.val = 0;
ip = 0;
{
forloop30:
for (i = 1; i <= n; i++) {
cursl = select_methcall(_select_meth,wr[(i)- 1+ _wr_offset],wi[(i)- 1+ _wi_offset]);
if (wi[(i)- 1+ _wi_offset] == zero)  {
    if (cursl)  
    sdim.val = sdim.val+1;
ip = 0;
if (cursl && !lastsl)  
    info.val = n+2;
}              // Close if()
else  {
  if (ip == 1)  {
    // *
// *                 Last eigenvalue of conjugate pair
// *
cursl = cursl || lastsl;
lastsl = cursl;
if (cursl)  
    sdim.val = sdim.val+2;
ip = -1;
if (cursl && !lst2sl)  
    info.val = n+2;
}              // Close if()
else  {
  // *
// *                 First eigenvalue of conjugate pair
// *
ip = 1;
}              //  Close else.
}              //  Close else.
lst2sl = lastsl;
lastsl = cursl;
Dummy.label("Dgeesx",30);
}              //  Close for() loop. 
}
}              // Close if()
// *
work[(1)- 1+ _work_offset] = (double)(maxwrk);
Dummy.go_to("Dgeesx",999999);
// *
// *     End of DGEESX
// *
Dummy.label("Dgeesx",999999);
return;
} catch (java.lang.reflect.InvocationTargetException e) {
   System.err.println("Error calling method.  "+ e.getMessage());
} catch (java.lang.IllegalAccessException e2) {
   System.err.println("Error calling method.  "+ e2.getMessage());
}
   }
// reflective method invocation for select
private static boolean select_methcall( java.lang.reflect.Method _funcptr, double _arg0 , double _arg1 )
   throws java.lang.reflect.InvocationTargetException,
          java.lang.IllegalAccessException
{
Object [] _funcargs = new Object [2];
boolean _retval;
 _funcargs[0] = new Double(_arg0);
 _funcargs[1] = new Double(_arg1);
_retval = ( (Boolean) _funcptr.invoke(null,_funcargs)).booleanValue();
return _retval;
}
} // End class.
