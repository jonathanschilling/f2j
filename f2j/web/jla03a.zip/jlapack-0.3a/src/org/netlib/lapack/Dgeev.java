/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgeev {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEEV computes for an N-by-N real nonsymmetric matrix A, the
// *  eigenvalues and, optionally, the left and/or right eigenvectors.
// *
// *  The right eigenvector v(j) of A satisfies
// *                   A * v(j) = lambda(j) * v(j)
// *  where lambda(j) is its eigenvalue.
// *  The left eigenvector u(j) of A satisfies
// *                u(j)**H * A = lambda(j) * u(j)**H
// *  where u(j)**H denotes the conjugate transpose of u(j).
// *
// *  The computed eigenvectors are normalized to have Euclidean norm
// *  equal to 1 and largest component real.
// *
// *  Arguments
// *  =========
// *
// *  JOBVL   (input) CHARACTER*1
// *          = 'N': left eigenvectors of A are not computed;
// *          = 'V': left eigenvectors of A are computed.
// *
// *  JOBVR   (input) CHARACTER*1
// *          = 'N': right eigenvectors of A are not computed;
// *          = 'V': right eigenvectors of A are computed.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A. N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the N-by-N matrix A.
// *          On exit, A has been overwritten.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  WR      (output) DOUBLE PRECISION array, dimension (N)
// *  WI      (output) DOUBLE PRECISION array, dimension (N)
// *          WR and WI contain the real and imaginary parts,
// *          respectively, of the computed eigenvalues.  Complex
// *          conjugate pairs of eigenvalues appear consecutively
// *          with the eigenvalue having the positive imaginary part
// *          first.
// *
// *  VL      (output) DOUBLE PRECISION array, dimension (LDVL,N)
// *          If JOBVL = 'V', the left eigenvectors u(j) are stored one
// *          after another in the columns of VL, in the same order
// *          as their eigenvalues.
// *          If JOBVL = 'N', VL is not referenced.
// *          If the j-th eigenvalue is real, then u(j) = VL(:,j),
// *          the j-th column of VL.
// *          If the j-th and (j+1)-st eigenvalues form a complex
// *          conjugate pair, then u(j) = VL(:,j) + i*VL(:,j+1) and
// *          u(j+1) = VL(:,j) - i*VL(:,j+1).
// *
// *  LDVL    (input) INTEGER
// *          The leading dimension of the array VL.  LDVL >= 1; if
// *          JOBVL = 'V', LDVL >= N.
// *
// *  VR      (output) DOUBLE PRECISION array, dimension (LDVR,N)
// *          If JOBVR = 'V', the right eigenvectors v(j) are stored one
// *          after another in the columns of VR, in the same order
// *          as their eigenvalues.
// *          If JOBVR = 'N', VR is not referenced.
// *          If the j-th eigenvalue is real, then v(j) = VR(:,j),
// *          the j-th column of VR.
// *          If the j-th and (j+1)-st eigenvalues form a complex
// *          conjugate pair, then v(j) = VR(:,j) + i*VR(:,j+1) and
// *          v(j+1) = VR(:,j) - i*VR(:,j+1).
// *
// *  LDVR    (input) INTEGER
// *          The leading dimension of the array VR.  LDVR >= 1; if
// *          JOBVR = 'V', LDVR >= N.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,3*N), and
// *          if JOBVL = 'V' or JOBVR = 'V', LWORK >= 4*N.  For good
// *          performance, LWORK must generally be larger.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = i, the QR algorithm failed to compute all the
// *                eigenvalues, and no eigenvectors have been computed;
// *                elements i+1:N of WR and WI contain eigenvalues which
// *                have converged.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean scalea= false;
static boolean wantvl= false;
static boolean wantvr= false;
static String side= new String(" ");
static int hswork= 0;
static int i= 0;
static int ibal= 0;
static intW ierr= new intW(0);
static intW ihi= new intW(0);
static intW ilo= new intW(0);
static int itau= 0;
static int iwrk= 0;
static int k= 0;
static int maxb= 0;
static int maxwrk= 0;
static int minwrk= 0;
static intW nout= new intW(0);
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static doubleW cs= new doubleW(0.0);
static double cscale= 0.0;
static double eps= 0.0;
static doubleW r= new doubleW(0.0);
static double scl= 0.0;
static doubleW smlnum= new doubleW(0.0);
static doubleW sn= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static boolean [] select= new boolean[(1)];
static double [] dum= new double[(1)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgeev (String jobvl,
String jobvr,
int n,
double [] a, int _a_offset,
int lda,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] vl, int _vl_offset,
int ldvl,
double [] vr, int _vr_offset,
int ldvr,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
wantvl = (jobvl.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
wantvr = (jobvr.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
if ((!wantvl) && (!(jobvl.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -1;
}              // Close if()
else if ((!wantvr) && (!(jobvr.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (ldvl < 1 || (wantvl && ldvl < n))  {
    info.val = -9;
}              // Close else if()
else if (ldvr < 1 || (wantvr && ldvr < n))  {
    info.val = -11;
}              // Close else if()
// *
// *     Compute workspace
// *      (Note: Comments in the code beginning "Workspace:" describe the
// *       minimal amount of workspace needed at that point in the code,
// *       as well as the preferred amount for good performance.
// *       NB refers to the optimal block size for the immediately
// *       following subroutine, as returned by ILAENV.
// *       HSWORK refers to the workspace preferred by DHSEQR, as
// *       calculated below. HSWORK is computed assuming ILO=1 and IHI=N,
// *       the worst case.)
// *
minwrk = 1;
if (info.val == 0 && lwork >= 1)  {
    maxwrk = 2*n+n*Ilaenv.ilaenv(1,"DGEHRD"," ",n,1,n,0);
if ((!wantvl) && (!wantvr))  {
    minwrk = (int)(Math.max(1, 3*n) );
maxb = (int)(Math.max(Ilaenv.ilaenv(8,"DHSEQR","EN",n,1,n,-1), 2) );
k = (int)(Math.min((maxb) < (n) ? (maxb) : (n), Math.max(2, Ilaenv.ilaenv(4,"DHSEQR","EN",n,1,n,-1)) ));
hswork = (int)(Math.max(k*(k+2), 2*n) );
maxwrk = (int)(Math.max((maxwrk) > (n+1) ? (maxwrk) : (n+1), n+hswork));
}              // Close if()
else  {
  minwrk = (int)(Math.max(1, 4*n) );
maxwrk = (int)(Math.max(maxwrk, 2*n+(n-1)*Ilaenv.ilaenv(1,"DORGHR"," ",n,1,n,-1)) );
maxb = (int)(Math.max(Ilaenv.ilaenv(8,"DHSEQR","SV",n,1,n,-1), 2) );
k = (int)(Math.min((maxb) < (n) ? (maxb) : (n), Math.max(2, Ilaenv.ilaenv(4,"DHSEQR","SV",n,1,n,-1)) ));
hswork = (int)(Math.max(k*(k+2), 2*n) );
maxwrk = (int)(Math.max((maxwrk) > (n+1) ? (maxwrk) : (n+1), n+hswork));
maxwrk = (int)(Math.max(maxwrk, 4*n) );
}              //  Close else.
work[(1)- 1+ _work_offset] = (double)(maxwrk);
}              // Close if()
if (lwork < minwrk)  {
    info.val = -13;
}              // Close if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEEV ",-info.val);
Dummy.go_to("Dgeev",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dgeev",999999);
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
smlnum.val = Math.sqrt(smlnum.val)/eps;
bignum.val = one/smlnum.val;
// *
// *     Scale A if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",n,n,a,_a_offset,lda,dum,0);
scalea = false;
if (anrm > zero && anrm < smlnum.val)  {
    scalea = true;
cscale = smlnum.val;
}              // Close if()
else if (anrm > bignum.val)  {
    scalea = true;
cscale = bignum.val;
}              // Close else if()
if (scalea)  
    Dlascl.dlascl("G",0,0,anrm,cscale,n,n,a,_a_offset,lda,ierr);
// *
// *     Balance the matrix
// *     (Workspace: need N)
// *
ibal = 1;
Dgebal.dgebal("B",n,a,_a_offset,lda,ilo,ihi,work,(ibal)- 1+ _work_offset,ierr);
// *
// *     Reduce to upper Hessenberg form
// *     (Workspace: need 3*N, prefer 2*N+N*NB)
// *
itau = ibal+n;
iwrk = itau+n;
Dgehrd.dgehrd(n,ilo.val,ihi.val,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ierr);
// *
if (wantvl)  {
    // *
// *        Want left eigenvectors
// *        Copy Householder vectors to VL
// *
side = "L";
Dlacpy.dlacpy("L",n,n,a,_a_offset,lda,vl,_vl_offset,ldvl);
// *
// *        Generate orthogonal matrix in VL
// *        (Workspace: need 3*N-1, prefer 2*N+(N-1)*NB)
// *
Dorghr.dorghr(n,ilo.val,ihi.val,vl,_vl_offset,ldvl,work,(itau)- 1+ _work_offset,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ierr);
// *
// *        Perform QR iteration, accumulating Schur vectors in VL
// *        (Workspace: need N+1, prefer N+HSWORK (see comments) )
// *
iwrk = itau;
Dhseqr.dhseqr("S","V",n,ilo.val,ihi.val,a,_a_offset,lda,wr,_wr_offset,wi,_wi_offset,vl,_vl_offset,ldvl,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,info);
// *
if (wantvr)  {
    // *
// *           Want left and right eigenvectors
// *           Copy Schur vectors to VR
// *
side = "B";
Dlacpy.dlacpy("F",n,n,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr);
}              // Close if()
// *
}              // Close if()
else if (wantvr)  {
    // *
// *        Want right eigenvectors
// *        Copy Householder vectors to VR
// *
side = "R";
Dlacpy.dlacpy("L",n,n,a,_a_offset,lda,vr,_vr_offset,ldvr);
// *
// *        Generate orthogonal matrix in VR
// *        (Workspace: need 3*N-1, prefer 2*N+(N-1)*NB)
// *
Dorghr.dorghr(n,ilo.val,ihi.val,vr,_vr_offset,ldvr,work,(itau)- 1+ _work_offset,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,ierr);
// *
// *        Perform QR iteration, accumulating Schur vectors in VR
// *        (Workspace: need N+1, prefer N+HSWORK (see comments) )
// *
iwrk = itau;
Dhseqr.dhseqr("S","V",n,ilo.val,ihi.val,a,_a_offset,lda,wr,_wr_offset,wi,_wi_offset,vr,_vr_offset,ldvr,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,info);
// *
}              // Close else if()
else  {
  // *
// *        Compute eigenvalues only
// *        (Workspace: need N+1, prefer N+HSWORK (see comments) )
// *
iwrk = itau;
Dhseqr.dhseqr("E","N",n,ilo.val,ihi.val,a,_a_offset,lda,wr,_wr_offset,wi,_wi_offset,vr,_vr_offset,ldvr,work,(iwrk)- 1+ _work_offset,lwork-iwrk+1,info);
}              //  Close else.
// *
// *     If INFO > 0 from DHSEQR, then quit
// *
if (info.val > 0)  
    Dummy.go_to("Dgeev",50);
// *
if (wantvl || wantvr)  {
    // *
// *        Compute left and/or right eigenvectors
// *        (Workspace: need 4*N)
// *
Dtrevc.dtrevc(side,"B",select,0,n,a,_a_offset,lda,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,n,nout,work,(iwrk)- 1+ _work_offset,ierr);
}              // Close if()
// *
if (wantvl)  {
    // *
// *        Undo balancing of left eigenvectors
// *        (Workspace: need N)
// *
Dgebak.dgebak("B","L",n,ilo.val,ihi.val,work,(ibal)- 1+ _work_offset,n,vl,_vl_offset,ldvl,ierr);
// *
// *        Normalize left eigenvectors and make largest component real
// *
{
forloop20:
for (i = 1; i <= n; i++) {
if (wi[(i)- 1+ _wi_offset] == zero)  {
    scl = one/Dnrm2.dnrm2(n,vl,(1)- 1+(i- 1)*ldvl+ _vl_offset,1);
Dscal.dscal(n,scl,vl,(1)- 1+(i- 1)*ldvl+ _vl_offset,1);
}              // Close if()
else if (wi[(i)- 1+ _wi_offset] > zero)  {
    scl = one/Dlapy2.dlapy2(Dnrm2.dnrm2(n,vl,(1)- 1+(i- 1)*ldvl+ _vl_offset,1),Dnrm2.dnrm2(n,vl,(1)- 1+(i+1- 1)*ldvl+ _vl_offset,1));
Dscal.dscal(n,scl,vl,(1)- 1+(i- 1)*ldvl+ _vl_offset,1);
Dscal.dscal(n,scl,vl,(1)- 1+(i+1- 1)*ldvl+ _vl_offset,1);
{
forloop10:
for (k = 1; k <= n; k++) {
work[(iwrk+k-1)- 1+ _work_offset] = Math.pow(vl[(k)- 1+(i- 1)*ldvl+ _vl_offset], 2)+Math.pow(vl[(k)- 1+(i+1- 1)*ldvl+ _vl_offset], 2);
Dummy.label("Dgeev",10);
}              //  Close for() loop. 
}
k = Idamax.idamax(n,work,(iwrk)- 1+ _work_offset,1);
Dlartg.dlartg(vl[(k)- 1+(i- 1)*ldvl+ _vl_offset],vl[(k)- 1+(i+1- 1)*ldvl+ _vl_offset],cs,sn,r);
Drot.drot(n,vl,(1)- 1+(i- 1)*ldvl+ _vl_offset,1,vl,(1)- 1+(i+1- 1)*ldvl+ _vl_offset,1,cs.val,sn.val);
vl[(k)- 1+(i+1- 1)*ldvl+ _vl_offset] = zero;
}              // Close else if()
Dummy.label("Dgeev",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (wantvr)  {
    // *
// *        Undo balancing of right eigenvectors
// *        (Workspace: need N)
// *
Dgebak.dgebak("B","R",n,ilo.val,ihi.val,work,(ibal)- 1+ _work_offset,n,vr,_vr_offset,ldvr,ierr);
// *
// *        Normalize right eigenvectors and make largest component real
// *
{
forloop40:
for (i = 1; i <= n; i++) {
if (wi[(i)- 1+ _wi_offset] == zero)  {
    scl = one/Dnrm2.dnrm2(n,vr,(1)- 1+(i- 1)*ldvr+ _vr_offset,1);
Dscal.dscal(n,scl,vr,(1)- 1+(i- 1)*ldvr+ _vr_offset,1);
}              // Close if()
else if (wi[(i)- 1+ _wi_offset] > zero)  {
    scl = one/Dlapy2.dlapy2(Dnrm2.dnrm2(n,vr,(1)- 1+(i- 1)*ldvr+ _vr_offset,1),Dnrm2.dnrm2(n,vr,(1)- 1+(i+1- 1)*ldvr+ _vr_offset,1));
Dscal.dscal(n,scl,vr,(1)- 1+(i- 1)*ldvr+ _vr_offset,1);
Dscal.dscal(n,scl,vr,(1)- 1+(i+1- 1)*ldvr+ _vr_offset,1);
{
forloop30:
for (k = 1; k <= n; k++) {
work[(iwrk+k-1)- 1+ _work_offset] = Math.pow(vr[(k)- 1+(i- 1)*ldvr+ _vr_offset], 2)+Math.pow(vr[(k)- 1+(i+1- 1)*ldvr+ _vr_offset], 2);
Dummy.label("Dgeev",30);
}              //  Close for() loop. 
}
k = Idamax.idamax(n,work,(iwrk)- 1+ _work_offset,1);
Dlartg.dlartg(vr[(k)- 1+(i- 1)*ldvr+ _vr_offset],vr[(k)- 1+(i+1- 1)*ldvr+ _vr_offset],cs,sn,r);
Drot.drot(n,vr,(1)- 1+(i- 1)*ldvr+ _vr_offset,1,vr,(1)- 1+(i+1- 1)*ldvr+ _vr_offset,1,cs.val,sn.val);
vr[(k)- 1+(i+1- 1)*ldvr+ _vr_offset] = zero;
}              // Close else if()
Dummy.label("Dgeev",40);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Undo scaling if necessary
// *
label50:
   Dummy.label("Dgeev",50);
if (scalea)  {
    Dlascl.dlascl("G",0,0,cscale,anrm,n-info.val,1,wr,(info.val+1)- 1+ _wr_offset,(int) ( Math.max(n-info.val, 1) ),ierr);
Dlascl.dlascl("G",0,0,cscale,anrm,n-info.val,1,wi,(info.val+1)- 1+ _wi_offset,(int) ( Math.max(n-info.val, 1) ),ierr);
if (info.val > 0)  {
    Dlascl.dlascl("G",0,0,cscale,anrm,ilo.val-1,1,wr,_wr_offset,n,ierr);
Dlascl.dlascl("G",0,0,cscale,anrm,ilo.val-1,1,wi,_wi_offset,n,ierr);
}              // Close if()
}              // Close if()
// *
work[(1)- 1+ _work_offset] = (double)(maxwrk);
Dummy.go_to("Dgeev",999999);
// *
// *     End of DGEEV
// *
Dummy.label("Dgeev",999999);
return;
   }
} // End class.
