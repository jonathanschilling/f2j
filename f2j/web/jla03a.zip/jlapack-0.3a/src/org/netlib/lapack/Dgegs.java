/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgegs {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEGS computes for a pair of N-by-N real nonsymmetric matrices A, B:
// *  the generalized eigenvalues (alphar +/- alphai*i, beta), the real
// *  Schur form (A, B), and optionally left and/or right Schur vectors
// *  (VSL and VSR).
// *
// *  (If only the generalized eigenvalues are needed, use the driver DGEGV
// *  instead.)
// *
// *  A generalized eigenvalue for a pair of matrices (A,B) is, roughly
// *  speaking, a scalar w or a ratio  alpha/beta = w, such that  A - w*B
// *  is singular.  It is usually represented as the pair (alpha,beta),
// *  as there is a reasonable interpretation for beta=0, and even for
// *  both being zero.  A good beginning reference is the book, "Matrix
// *  Computations", by G. Golub & C. van Loan (Johns Hopkins U. Press)
// *
// *  The (generalized) Schur form of a pair of matrices is the result of
// *  multiplying both matrices on the left by one orthogonal matrix and
// *  both on the right by another orthogonal matrix, these two orthogonal
// *  matrices being chosen so as to bring the pair of matrices into
// *  (real) Schur form.
// *
// *  A pair of matrices A, B is in generalized real Schur form if B is
// *  upper triangular with non-negative diagonal and A is block upper
// *  triangular with 1-by-1 and 2-by-2 blocks.  1-by-1 blocks correspond
// *  to real generalized eigenvalues, while 2-by-2 blocks of A will be
// *  "standardized" by making the corresponding elements of B have the
// *  form:
// *          [  a  0  ]
// *          [  0  b  ]
// *
// *  and the pair of corresponding 2-by-2 blocks in A and B will
// *  have a complex conjugate pair of generalized eigenvalues.
// *
// *  The left and right Schur vectors are the columns of VSL and VSR,
// *  respectively, where VSL and VSR are the orthogonal matrices
// *  which reduce A and B to Schur form:
// *
// *  Schur form of (A,B) = ( (VSL)**T A (VSR), (VSL)**T B (VSR) )
// *
// *  Arguments
// *  =========
// *
// *  JOBVSL  (input) CHARACTER*1
// *          = 'N':  do not compute the left Schur vectors;
// *          = 'V':  compute the left Schur vectors.
// *
// *  JOBVSR  (input) CHARACTER*1
// *          = 'N':  do not compute the right Schur vectors;
// *          = 'V':  compute the right Schur vectors.
// *
// *  N       (input) INTEGER
// *          The order of the matrices A, B, VSL, and VSR.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          On entry, the first of the pair of matrices whose generalized
// *          eigenvalues and (optionally) Schur vectors are to be
// *          computed.
// *          On exit, the generalized Schur form of A.
// *          Note: to avoid overflow, the Frobenius norm of the matrix
// *          A should be less than the overflow threshold.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  LDA >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB, N)
// *          On entry, the second of the pair of matrices whose
// *          generalized eigenvalues and (optionally) Schur vectors are
// *          to be computed.
// *          On exit, the generalized Schur form of B.
// *          Note: to avoid overflow, the Frobenius norm of the matrix
// *          B should be less than the overflow threshold.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  LDB >= max(1,N).
// *
// *  ALPHAR  (output) DOUBLE PRECISION array, dimension (N)
// *  ALPHAI  (output) DOUBLE PRECISION array, dimension (N)
// *  BETA    (output) DOUBLE PRECISION array, dimension (N)
// *          On exit, (ALPHAR(j) + ALPHAI(j)*i)/BETA(j), j=1,...,N, will
// *          be the generalized eigenvalues.  ALPHAR(j) + ALPHAI(j)*i,
// *          j=1,...,N  and  BETA(j),j=1,...,N  are the diagonals of the
// *          complex Schur form (A,B) that would result if the 2-by-2
// *          diagonal blocks of the real Schur form of (A,B) were further
// *          reduced to triangular form using 2-by-2 complex unitary
// *          transformations.  If ALPHAI(j) is zero, then the j-th
// *          eigenvalue is real; if positive, then the j-th and (j+1)-st
// *          eigenvalues are a complex conjugate pair, with ALPHAI(j+1)
// *          negative.
// *
// *          Note: the quotients ALPHAR(j)/BETA(j) and ALPHAI(j)/BETA(j)
// *          may easily over- or underflow, and BETA(j) may even be zero.
// *          Thus, the user should avoid naively computing the ratio
// *          alpha/beta.  However, ALPHAR and ALPHAI will be always less
// *          than and usually comparable with norm(A) in magnitude, and
// *          BETA always less than and usually comparable with norm(B).
// *
// *  VSL     (output) DOUBLE PRECISION array, dimension (LDVSL,N)
// *          If JOBVSL = 'V', VSL will contain the left Schur vectors.
// *          (See "Purpose", above.)
// *          Not referenced if JOBVSL = 'N'.
// *
// *  LDVSL   (input) INTEGER
// *          The leading dimension of the matrix VSL. LDVSL >=1, and
// *          if JOBVSL = 'V', LDVSL >= N.
// *
// *  VSR     (output) DOUBLE PRECISION array, dimension (LDVSR,N)
// *          If JOBVSR = 'V', VSR will contain the right Schur vectors.
// *          (See "Purpose", above.)
// *          Not referenced if JOBVSR = 'N'.
// *
// *  LDVSR   (input) INTEGER
// *          The leading dimension of the matrix VSR. LDVSR >= 1, and
// *          if JOBVSR = 'V', LDVSR >= N.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,4*N).
// *          For good performance, LWORK must generally be larger.
// *          To compute the optimal value of LWORK, call ILAENV to get
// *          blocksizes (for DGEQRF, DORMQR, and DORGQR.)  Then compute:
// *          NB  -- MAX of the blocksizes for DGEQRF, DORMQR, and DORGQR
// *          The optimal LWORK is  2*N + N*(NB+1).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          = 1,...,N:
// *                The QZ iteration failed.  (A,B) are not in Schur
// *                form, but ALPHAR(j), ALPHAI(j), and BETA(j) should
// *                be correct for j=INFO+1,...,N.
// *          > N:  errors that usually indicate LAPACK problems:
// *                =N+1: error return from DGGBAL
// *                =N+2: error return from DGEQRF
// *                =N+3: error return from DORMQR
// *                =N+4: error return from DORGQR
// *                =N+5: error return from DGGHRD
// *                =N+6: error return from DHGEQZ (other than failed
// *                                                iteration)
// *                =N+7: error return from DGGBAK (computing VSL)
// *                =N+8: error return from DGGBAK (computing VSR)
// *                =N+9: error return from DLASCL (various places)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean ilascl= false;
static boolean ilbscl= false;
static boolean ilvsl= false;
static boolean ilvsr= false;
static int icols= 0;
static intW ihi= new intW(0);
static intW iinfo= new intW(0);
static int ijobvl= 0;
static int ijobvr= 0;
static int ileft= 0;
static intW ilo= new intW(0);
static int iright= 0;
static int irows= 0;
static int itau= 0;
static int iwork= 0;
static int lwkmin= 0;
static int lwkopt= 0;
static double anrm= 0.0;
static double anrmto= 0.0;
static double bignum= 0.0;
static double bnrm= 0.0;
static double bnrmto= 0.0;
static double eps= 0.0;
static double safmin= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode the input arguments
// *

public static void dgegs (String jobvsl,
String jobvsr,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] alphar, int _alphar_offset,
double [] alphai, int _alphai_offset,
double [] beta, int _beta_offset,
double [] vsl, int _vsl_offset,
int ldvsl,
double [] vsr, int _vsr_offset,
int ldvsr,
double [] work, int _work_offset,
int lwork,
intW info)  {

if ((jobvsl.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ijobvl = 1;
ilvsl = false;
}              // Close if()
else if ((jobvsl.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ijobvl = 2;
ilvsl = true;
}              // Close else if()
else  {
  ijobvl = -1;
ilvsl = false;
}              //  Close else.
// *
if ((jobvsr.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ijobvr = 1;
ilvsr = false;
}              // Close if()
else if ((jobvsr.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ijobvr = 2;
ilvsr = true;
}              // Close else if()
else  {
  ijobvr = -1;
ilvsr = false;
}              //  Close else.
// *
// *     Test the input arguments
// *
lwkmin = (int)(Math.max(4*n, 1) );
lwkopt = lwkmin;
info.val = 0;
if (ijobvl <= 0)  {
    info.val = -1;
}              // Close if()
else if (ijobvr <= 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldvsl < 1 || (ilvsl && ldvsl < n))  {
    info.val = -12;
}              // Close else if()
else if (ldvsr < 1 || (ilvsr && ldvsr < n))  {
    info.val = -14;
}              // Close else if()
else if (lwork < lwkmin)  {
    info.val = -16;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGEGS ",-info.val);
Dummy.go_to("Dgegs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
work[(1)- 1+ _work_offset] = (double)(lwkopt);
if (n == 0)  
    Dummy.go_to("Dgegs",999999);
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("E")*Dlamch.dlamch("B");
safmin = Dlamch.dlamch("S");
smlnum = n*safmin/eps;
bignum = one/smlnum;
// *
// *     Scale A if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",n,n,a,_a_offset,lda,work,_work_offset);
ilascl = false;
if (anrm > zero && anrm < smlnum)  {
    anrmto = smlnum;
ilascl = true;
}              // Close if()
else if (anrm > bignum)  {
    anrmto = bignum;
ilascl = true;
}              // Close else if()
// *
if (ilascl)  {
    Dlascl.dlascl("G",-1,-1,anrm,anrmto,n,n,a,_a_offset,lda,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
}              // Close if()
// *
// *     Scale B if max element outside range [SMLNUM,BIGNUM]
// *
bnrm = Dlange.dlange("M",n,n,b,_b_offset,ldb,work,_work_offset);
ilbscl = false;
if (bnrm > zero && bnrm < smlnum)  {
    bnrmto = smlnum;
ilbscl = true;
}              // Close if()
else if (bnrm > bignum)  {
    bnrmto = bignum;
ilbscl = true;
}              // Close else if()
// *
if (ilbscl)  {
    Dlascl.dlascl("G",-1,-1,bnrm,bnrmto,n,n,b,_b_offset,ldb,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
}              // Close if()
// *
// *     Permute the matrix to make it more nearly triangular
// *     Workspace layout:  (2*N words -- "work..." not actually used)
// *        left_permutation, right_permutation, work...
// *
ileft = 1;
iright = n+1;
iwork = iright+n;
Dggbal.dggbal("P",n,a,_a_offset,lda,b,_b_offset,ldb,ilo,ihi,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    info.val = n+1;
Dummy.go_to("Dgegs",10);
}              // Close if()
// *
// *     Reduce B to triangular form, and initialize VSL and/or VSR
// *     Workspace layout:  ("work..." must have at least N words)
// *        left_permutation, right_permutation, tau, work...
// *
irows = ihi.val+1-ilo.val;
icols = n+1-ilo.val;
itau = iwork;
iwork = itau+irows;
Dgeqrf.dgeqrf(irows,icols,b,(ilo.val)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+2;
Dummy.go_to("Dgegs",10);
}              // Close if()
// *
Dormqr.dormqr("L","T",irows,icols,irows,b,(ilo.val)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,work,(itau)- 1+ _work_offset,a,(ilo.val)- 1+(ilo.val- 1)*lda+ _a_offset,lda,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+3;
Dummy.go_to("Dgegs",10);
}              // Close if()
// *
if (ilvsl)  {
    Dlaset.dlaset("Full",n,n,zero,one,vsl,_vsl_offset,ldvsl);
Dlacpy.dlacpy("L",irows-1,irows-1,b,(ilo.val+1)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,vsl,(ilo.val+1)- 1+(ilo.val- 1)*ldvsl+ _vsl_offset,ldvsl);
Dorgqr.dorgqr(irows,irows,irows,vsl,(ilo.val)- 1+(ilo.val- 1)*ldvsl+ _vsl_offset,ldvsl,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+4;
Dummy.go_to("Dgegs",10);
}              // Close if()
}              // Close if()
// *
if (ilvsr)  
    Dlaset.dlaset("Full",n,n,zero,one,vsr,_vsr_offset,ldvsr);
// *
// *     Reduce to generalized Hessenberg form
// *
Dgghrd.dgghrd(jobvsl,jobvsr,n,ilo.val,ihi.val,a,_a_offset,lda,b,_b_offset,ldb,vsl,_vsl_offset,ldvsl,vsr,_vsr_offset,ldvsr,iinfo);
if (iinfo.val != 0)  {
    info.val = n+5;
Dummy.go_to("Dgegs",10);
}              // Close if()
// *
// *     Perform QZ algorithm, computing Schur vectors if desired
// *     Workspace layout:  ("work..." must have at least 1 word)
// *        left_permutation, right_permutation, work...
// *
iwork = itau;
Dhgeqz.dhgeqz("S",jobvsl,jobvsr,n,ilo.val,ihi.val,a,_a_offset,lda,b,_b_offset,ldb,alphar,_alphar_offset,alphai,_alphai_offset,beta,_beta_offset,vsl,_vsl_offset,ldvsl,vsr,_vsr_offset,ldvsr,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    if (iinfo.val > 0 && iinfo.val <= n)  {
    info.val = iinfo.val;
}              // Close if()
else if (iinfo.val > n && iinfo.val <= 2*n)  {
    info.val = iinfo.val-n;
}              // Close else if()
else  {
  info.val = n+6;
}              //  Close else.
Dummy.go_to("Dgegs",10);
}              // Close if()
// *
// *     Apply permutation to VSL and VSR
// *
if (ilvsl)  {
    Dggbak.dggbak("P","L",n,ilo.val,ihi.val,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,n,vsl,_vsl_offset,ldvsl,iinfo);
if (iinfo.val != 0)  {
    info.val = n+7;
Dummy.go_to("Dgegs",10);
}              // Close if()
}              // Close if()
if (ilvsr)  {
    Dggbak.dggbak("P","R",n,ilo.val,ihi.val,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,n,vsr,_vsr_offset,ldvsr,iinfo);
if (iinfo.val != 0)  {
    info.val = n+8;
Dummy.go_to("Dgegs",10);
}              // Close if()
}              // Close if()
// *
// *     Undo scaling
// *
if (ilascl)  {
    Dlascl.dlascl("H",-1,-1,anrmto,anrm,n,n,a,_a_offset,lda,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
Dlascl.dlascl("G",-1,-1,anrmto,anrm,n,1,alphar,_alphar_offset,n,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
Dlascl.dlascl("G",-1,-1,anrmto,anrm,n,1,alphai,_alphai_offset,n,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
}              // Close if()
// *
if (ilbscl)  {
    Dlascl.dlascl("U",-1,-1,bnrmto,bnrm,n,n,b,_b_offset,ldb,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
Dlascl.dlascl("G",-1,-1,bnrmto,bnrm,n,1,beta,_beta_offset,n,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegs",999999);
}              // Close if()
}              // Close if()
// *
label10:
   Dummy.label("Dgegs",10);
work[(1)- 1+ _work_offset] = (double)(lwkopt);
// *
Dummy.go_to("Dgegs",999999);
// *
// *     End of DGEGS
// *
Dummy.label("Dgegs",999999);
return;
   }
} // End class.
