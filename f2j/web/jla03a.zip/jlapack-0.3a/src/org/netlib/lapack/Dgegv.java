/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgegv {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEGV computes for a pair of n-by-n real nonsymmetric matrices A and
// *  B, the generalized eigenvalues (alphar +/- alphai*i, beta), and
// *  optionally, the left and/or right generalized eigenvectors (VL and
// *  VR).
// *
// *  A generalized eigenvalue for a pair of matrices (A,B) is, roughly
// *  speaking, a scalar w or a ratio  alpha/beta = w, such that  A - w*B
// *  is singular.  It is usually represented as the pair (alpha,beta),
// *  as there is a reasonable interpretation for beta=0, and even for
// *  both being zero.  A good beginning reference is the book, "Matrix
// *  Computations", by G. Golub & C. van Loan (Johns Hopkins U. Press)
// *
// *  A right generalized eigenvector corresponding to a generalized
// *  eigenvalue  w  for a pair of matrices (A,B) is a vector  r  such
// *  that  (A - w B) r = 0 .  A left generalized eigenvector is a vector
// *  l such that l**H * (A - w B) = 0, where l**H is the
// *  conjugate-transpose of l.
// *
// *  Note: this routine performs "full balancing" on A and B -- see
// *  "Further Details", below.
// *
// *  Arguments
// *  =========
// *
// *  JOBVL   (input) CHARACTER*1
// *          = 'N':  do not compute the left generalized eigenvectors;
// *          = 'V':  compute the left generalized eigenvectors.
// *
// *  JOBVR   (input) CHARACTER*1
// *          = 'N':  do not compute the right generalized eigenvectors;
// *          = 'V':  compute the right generalized eigenvectors.
// *
// *  N       (input) INTEGER
// *          The order of the matrices A, B, VL, and VR.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          On entry, the first of the pair of matrices whose
// *          generalized eigenvalues and (optionally) generalized
// *          eigenvectors are to be computed.
// *          On exit, the contents will have been destroyed.  (For a
// *          description of the contents of A on exit, see "Further
// *          Details", below.)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  LDA >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB, N)
// *          On entry, the second of the pair of matrices whose
// *          generalized eigenvalues and (optionally) generalized
// *          eigenvectors are to be computed.
// *          On exit, the contents will have been destroyed.  (For a
// *          description of the contents of B on exit, see "Further
// *          Details", below.)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  LDB >= max(1,N).
// *
// *  ALPHAR  (output) DOUBLE PRECISION array, dimension (N)
// *  ALPHAI  (output) DOUBLE PRECISION array, dimension (N)
// *  BETA    (output) DOUBLE PRECISION array, dimension (N)
// *          On exit, (ALPHAR(j) + ALPHAI(j)*i)/BETA(j), j=1,...,N, will
// *          be the generalized eigenvalues.  If ALPHAI(j) is zero, then
// *          the j-th eigenvalue is real; if positive, then the j-th and
// *          (j+1)-st eigenvalues are a complex conjugate pair, with
// *          ALPHAI(j+1) negative.
// *
// *          Note: the quotients ALPHAR(j)/BETA(j) and ALPHAI(j)/BETA(j)
// *          may easily over- or underflow, and BETA(j) may even be zero.
// *          Thus, the user should avoid naively computing the ratio
// *          alpha/beta.  However, ALPHAR and ALPHAI will be always less
// *          than and usually comparable with norm(A) in magnitude, and
// *          BETA always less than and usually comparable with norm(B).
// *
// *  VL      (output) DOUBLE PRECISION array, dimension (LDVL,N)
// *          If JOBVL = 'V', the left generalized eigenvectors.  (See
// *          "Purpose", above.)  Real eigenvectors take one column,
// *          complex take two columns, the first for the real part and
// *          the second for the imaginary part.  Complex eigenvectors
// *          correspond to an eigenvalue with positive imaginary part.
// *          Each eigenvector will be scaled so the largest component
// *          will have abs(real part) + abs(imag. part) = 1, *except*
// *          that for eigenvalues with alpha=beta=0, a zero vector will
// *          be returned as the corresponding eigenvector.
// *          Not referenced if JOBVL = 'N'.
// *
// *  LDVL    (input) INTEGER
// *          The leading dimension of the matrix VL. LDVL >= 1, and
// *          if JOBVL = 'V', LDVL >= N.
// *
// *  VR      (output) DOUBLE PRECISION array, dimension (LDVR,N)
// *          If JOBVL = 'V', the right generalized eigenvectors.  (See
// *          "Purpose", above.)  Real eigenvectors take one column,
// *          complex take two columns, the first for the real part and
// *          the second for the imaginary part.  Complex eigenvectors
// *          correspond to an eigenvalue with positive imaginary part.
// *          Each eigenvector will be scaled so the largest component
// *          will have abs(real part) + abs(imag. part) = 1, *except*
// *          that for eigenvalues with alpha=beta=0, a zero vector will
// *          be returned as the corresponding eigenvector.
// *          Not referenced if JOBVR = 'N'.
// *
// *  LDVR    (input) INTEGER
// *          The leading dimension of the matrix VR. LDVR >= 1, and
// *          if JOBVR = 'V', LDVR >= N.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,8*N).
// *          For good performance, LWORK must generally be larger.
// *          To compute the optimal value of LWORK, call ILAENV to get
// *          blocksizes (for DGEQRF, DORMQR, and DORGQR.)  Then compute:
// *          NB  -- MAX of the blocksizes for DGEQRF, DORMQR, and DORGQR;
// *          The optimal LWORK is:
// *              2*N + MAX( 6*N, N*(NB+1) ).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          = 1,...,N:
// *                The QZ iteration failed.  No eigenvectors have been
// *                calculated, but ALPHAR(j), ALPHAI(j), and BETA(j)
// *                should be correct for j=INFO+1,...,N.
// *          > N:  errors that usually indicate LAPACK problems:
// *                =N+1: error return from DGGBAL
// *                =N+2: error return from DGEQRF
// *                =N+3: error return from DORMQR
// *                =N+4: error return from DORGQR
// *                =N+5: error return from DGGHRD
// *                =N+6: error return from DHGEQZ (other than failed
// *                                                iteration)
// *                =N+7: error return from DTGEVC
// *                =N+8: error return from DGGBAK (computing VL)
// *                =N+9: error return from DGGBAK (computing VR)
// *                =N+10: error return from DLASCL (various calls)
// *
// *  Further Details
// *  ===============
// *
// *  Balancing
// *  ---------
// *
// *  This driver calls DGGBAL to both permute and scale rows and columns
// *  of A and B.  The permutations PL and PR are chosen so that PL*A*PR
// *  and PL*B*R will be upper triangular except for the diagonal blocks
// *  A(i:j,i:j) and B(i:j,i:j), with i and j as close together as
// *  possible.  The diagonal scaling matrices DL and DR are chosen so
// *  that the pair  DL*PL*A*PR*DR, DL*PL*B*PR*DR have elements close to
// *  one (except for the elements that start out zero.)
// *
// *  After the eigenvalues and eigenvectors of the balanced matrices
// *  have been computed, DGGBAK transforms the eigenvectors back to what
// *  they would have been (in perfect arithmetic) if they had not been
// *  balanced.
// *
// *  Contents of A and B on Exit
// *  -------- -- - --- - -- ----
// *
// *  If any eigenvectors are computed (either JOBVL='V' or JOBVR='V' or
// *  both), then on exit the arrays A and B will contain the real Schur
// *  form[*] of the "balanced" versions of A and B.  If no eigenvectors
// *  are computed, then only the diagonal blocks will be correct.
// *
// *  [*] See DHGEQZ, DGEGS, or read the book "Matrix Computations",
// *      by Golub & van Loan, pub. by Johns Hopkins U. Press.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean ilimit= false;
static boolean ilv= false;
static boolean ilvl= false;
static boolean ilvr= false;
static String chtemp= new String(" ");
static int icols= 0;
static intW ihi= new intW(0);
static intW iinfo= new intW(0);
static int ijobvl= 0;
static int ijobvr= 0;
static int ileft= 0;
static intW ilo= new intW(0);
static intW in= new intW(0);
static int iright= 0;
static int irows= 0;
static int itau= 0;
static int iwork= 0;
static int jc= 0;
static int jr= 0;
static int lwkmin= 0;
static int lwkopt= 0;
static double absai= 0.0;
static double absar= 0.0;
static double absb= 0.0;
static double anrm= 0.0;
static double anrm1= 0.0;
static double anrm2= 0.0;
static double bnrm= 0.0;
static double bnrm1= 0.0;
static double bnrm2= 0.0;
static double eps= 0.0;
static double onepls= 0.0;
static double safmax= 0.0;
static double safmin= 0.0;
static double salfai= 0.0;
static double salfar= 0.0;
static double sbeta= 0.0;
static double scale= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] ldumma= new boolean[(1)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode the input arguments
// *

public static void dgegv (String jobvl,
String jobvr,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] alphar, int _alphar_offset,
double [] alphai, int _alphai_offset,
double [] beta, int _beta_offset,
double [] vl, int _vl_offset,
int ldvl,
double [] vr, int _vr_offset,
int ldvr,
double [] work, int _work_offset,
int lwork,
intW info)  {

if ((jobvl.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ijobvl = 1;
ilvl = false;
}              // Close if()
else if ((jobvl.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ijobvl = 2;
ilvl = true;
}              // Close else if()
else  {
  ijobvl = -1;
ilvl = false;
}              //  Close else.
// *
if ((jobvr.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ijobvr = 1;
ilvr = false;
}              // Close if()
else if ((jobvr.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ijobvr = 2;
ilvr = true;
}              // Close else if()
else  {
  ijobvr = -1;
ilvr = false;
}              //  Close else.
ilv = ilvl || ilvr;
// *
// *     Test the input arguments
// *
lwkmin = (int)(Math.max(8*n, 1) );
lwkopt = lwkmin;
info.val = 0;
if (ijobvl <= 0)  {
    info.val = -1;
}              // Close if()
else if (ijobvr <= 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldvl < 1 || (ilvl && ldvl < n))  {
    info.val = -12;
}              // Close else if()
else if (ldvr < 1 || (ilvr && ldvr < n))  {
    info.val = -14;
}              // Close else if()
else if (lwork < lwkmin)  {
    info.val = -16;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGEGV ",-info.val);
Dummy.go_to("Dgegv",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
work[(1)- 1+ _work_offset] = (double)(lwkopt);
if (n == 0)  
    Dummy.go_to("Dgegv",999999);
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("E")*Dlamch.dlamch("B");
safmin = Dlamch.dlamch("S");
safmin = safmin+safmin;
safmax = one/safmin;
onepls = one+(4*eps);
// *
// *     Scale A
// *
anrm = Dlange.dlange("M",n,n,a,_a_offset,lda,work,_work_offset);
anrm1 = anrm;
anrm2 = one;
if (anrm < one)  {
    if (safmax*anrm < one)  {
    anrm1 = safmin;
anrm2 = safmax*anrm;
}              // Close if()
}              // Close if()
// *
if (anrm > zero)  {
    Dlascl.dlascl("G",-1,-1,anrm,one,n,n,a,_a_offset,lda,iinfo);
if (iinfo.val != 0)  {
    info.val = n+10;
Dummy.go_to("Dgegv",999999);
}              // Close if()
}              // Close if()
// *
// *     Scale B
// *
bnrm = Dlange.dlange("M",n,n,b,_b_offset,ldb,work,_work_offset);
bnrm1 = bnrm;
bnrm2 = one;
if (bnrm < one)  {
    if (safmax*bnrm < one)  {
    bnrm1 = safmin;
bnrm2 = safmax*bnrm;
}              // Close if()
}              // Close if()
// *
if (bnrm > zero)  {
    Dlascl.dlascl("G",-1,-1,bnrm,one,n,n,b,_b_offset,ldb,iinfo);
if (iinfo.val != 0)  {
    info.val = n+10;
Dummy.go_to("Dgegv",999999);
}              // Close if()
}              // Close if()
// *
// *     Permute the matrix to make it more nearly triangular
// *     Workspace layout:  (8*N words -- "work" requires 6*N words)
// *        left_permutation, right_permutation, work...
// *
ileft = 1;
iright = n+1;
iwork = iright+n;
Dggbal.dggbal("B",n,a,_a_offset,lda,b,_b_offset,ldb,ilo,ihi,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    info.val = n+1;
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
// *     Reduce B to triangular form, and initialize VL and/or VR
// *     Workspace layout:  ("work..." must have at least N words)
// *        left_permutation, right_permutation, tau, work...
// *
irows = ihi.val+1-ilo.val;
if (ilv)  {
    icols = n+1-ilo.val;
}              // Close if()
else  {
  icols = irows;
}              //  Close else.
itau = iwork;
iwork = itau+irows;
Dgeqrf.dgeqrf(irows,icols,b,(ilo.val)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+2;
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
Dormqr.dormqr("L","T",irows,icols,irows,b,(ilo.val)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,work,(itau)- 1+ _work_offset,a,(ilo.val)- 1+(ilo.val- 1)*lda+ _a_offset,lda,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+3;
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
if (ilvl)  {
    Dlaset.dlaset("Full",n,n,zero,one,vl,_vl_offset,ldvl);
Dlacpy.dlacpy("L",irows-1,irows-1,b,(ilo.val+1)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,vl,(ilo.val+1)- 1+(ilo.val- 1)*ldvl+ _vl_offset,ldvl);
Dorgqr.dorgqr(irows,irows,irows,vl,(ilo.val)- 1+(ilo.val- 1)*ldvl+ _vl_offset,ldvl,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    info.val = n+4;
Dummy.go_to("Dgegv",120);
}              // Close if()
}              // Close if()
// *
if (ilvr)  
    Dlaset.dlaset("Full",n,n,zero,one,vr,_vr_offset,ldvr);
// *
// *     Reduce to generalized Hessenberg form
// *
if (ilv)  {
    // *
// *        Eigenvectors requested -- work on whole matrix.
// *
Dgghrd.dgghrd(jobvl,jobvr,n,ilo.val,ihi.val,a,_a_offset,lda,b,_b_offset,ldb,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,iinfo);
}              // Close if()
else  {
  Dgghrd.dgghrd("N","N",irows,1,irows,a,(ilo.val)- 1+(ilo.val- 1)*lda+ _a_offset,lda,b,(ilo.val)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,iinfo);
}              //  Close else.
if (iinfo.val != 0)  {
    info.val = n+5;
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
// *     Perform QZ algorithm
// *     Workspace layout:  ("work..." must have at least 1 word)
// *        left_permutation, right_permutation, work...
// *
iwork = itau;
if (ilv)  {
    chtemp = "S";
}              // Close if()
else  {
  chtemp = "E";
}              //  Close else.
Dhgeqz.dhgeqz(chtemp,jobvl,jobvr,n,ilo.val,ihi.val,a,_a_offset,lda,b,_b_offset,ldb,alphar,_alphar_offset,alphai,_alphai_offset,beta,_beta_offset,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,work,(iwork)- 1+ _work_offset,lwork+1-iwork,iinfo);
if (iinfo.val >= 0)  
    lwkopt = (int)(Math.max(lwkopt, (int)(work[(iwork)- 1+ _work_offset])+iwork-1) );
if (iinfo.val != 0)  {
    if (iinfo.val > 0 && iinfo.val <= n)  {
    info.val = iinfo.val;
}              // Close if()
else if (iinfo.val > n && iinfo.val <= 2*n)  {
    info.val = iinfo.val-n;
}              // Close else if()
else  {
  info.val = n+6;
}              //  Close else.
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
if (ilv)  {
    // *
// *        Compute Eigenvectors  (DTGEVC requires 6*N words of workspace)
// *
if (ilvl)  {
    if (ilvr)  {
    chtemp = "B";
}              // Close if()
else  {
  chtemp = "L";
}              //  Close else.
}              // Close if()
else  {
  chtemp = "R";
}              //  Close else.
// *
Dtgevc.dtgevc(chtemp,"B",ldumma,0,n,a,_a_offset,lda,b,_b_offset,ldb,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,n,in,work,(iwork)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    info.val = n+7;
Dummy.go_to("Dgegv",120);
}              // Close if()
// *
// *        Undo balancing on VL and VR, rescale
// *
if (ilvl)  {
    Dggbak.dggbak("B","L",n,ilo.val,ihi.val,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,n,vl,_vl_offset,ldvl,iinfo);
if (iinfo.val != 0)  {
    info.val = n+8;
Dummy.go_to("Dgegv",120);
}              // Close if()
{
forloop50:
for (jc = 1; jc <= n; jc++) {
if (alphai[(jc)- 1+ _alphai_offset] < zero)  
    continue forloop50;
temp = zero;
if (alphai[(jc)- 1+ _alphai_offset] == zero)  {
    {
forloop10:
for (jr = 1; jr <= n; jr++) {
temp = Math.max(temp, Math.abs(vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset])) ;
Dummy.label("Dgegv",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop20:
for (jr = 1; jr <= n; jr++) {
temp = Math.max(temp, Math.abs(vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset])+Math.abs(vl[(jr)- 1+(jc+1- 1)*ldvl+ _vl_offset])) ;
Dummy.label("Dgegv",20);
}              //  Close for() loop. 
}
}              //  Close else.
if (temp < safmin)  
    continue forloop50;
temp = one/temp;
if (alphai[(jc)- 1+ _alphai_offset] == zero)  {
    {
forloop30:
for (jr = 1; jr <= n; jr++) {
vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset] = vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset]*temp;
Dummy.label("Dgegv",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (jr = 1; jr <= n; jr++) {
vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset] = vl[(jr)- 1+(jc- 1)*ldvl+ _vl_offset]*temp;
vl[(jr)- 1+(jc+1- 1)*ldvl+ _vl_offset] = vl[(jr)- 1+(jc+1- 1)*ldvl+ _vl_offset]*temp;
Dummy.label("Dgegv",40);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dgegv",50);
}              //  Close for() loop. 
}
}              // Close if()
if (ilvr)  {
    Dggbak.dggbak("B","R",n,ilo.val,ihi.val,work,(ileft)- 1+ _work_offset,work,(iright)- 1+ _work_offset,n,vr,_vr_offset,ldvr,iinfo);
if (iinfo.val != 0)  {
    info.val = n+9;
Dummy.go_to("Dgegv",120);
}              // Close if()
{
forloop100:
for (jc = 1; jc <= n; jc++) {
if (alphai[(jc)- 1+ _alphai_offset] < zero)  
    continue forloop100;
temp = zero;
if (alphai[(jc)- 1+ _alphai_offset] == zero)  {
    {
forloop60:
for (jr = 1; jr <= n; jr++) {
temp = Math.max(temp, Math.abs(vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset])) ;
Dummy.label("Dgegv",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop70:
for (jr = 1; jr <= n; jr++) {
temp = Math.max(temp, Math.abs(vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset])+Math.abs(vr[(jr)- 1+(jc+1- 1)*ldvr+ _vr_offset])) ;
Dummy.label("Dgegv",70);
}              //  Close for() loop. 
}
}              //  Close else.
if (temp < safmin)  
    continue forloop100;
temp = one/temp;
if (alphai[(jc)- 1+ _alphai_offset] == zero)  {
    {
forloop80:
for (jr = 1; jr <= n; jr++) {
vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset] = vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset]*temp;
Dummy.label("Dgegv",80);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop90:
for (jr = 1; jr <= n; jr++) {
vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset] = vr[(jr)- 1+(jc- 1)*ldvr+ _vr_offset]*temp;
vr[(jr)- 1+(jc+1- 1)*ldvr+ _vr_offset] = vr[(jr)- 1+(jc+1- 1)*ldvr+ _vr_offset]*temp;
Dummy.label("Dgegv",90);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dgegv",100);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        End of eigenvector calculation
// *
}              // Close if()
// *
// *     Undo scaling in alpha, beta
// *
// *     Note: this does not give the alpha and beta for the unscaled
// *     problem.
// *
// *     Un-scaling is limited to avoid underflow in alpha and beta
// *     if they are significant.
// *
{
forloop110:
for (jc = 1; jc <= n; jc++) {
absar = Math.abs(alphar[(jc)- 1+ _alphar_offset]);
absai = Math.abs(alphai[(jc)- 1+ _alphai_offset]);
absb = Math.abs(beta[(jc)- 1+ _beta_offset]);
salfar = anrm*alphar[(jc)- 1+ _alphar_offset];
salfai = anrm*alphai[(jc)- 1+ _alphai_offset];
sbeta = bnrm*beta[(jc)- 1+ _beta_offset];
ilimit = false;
scale = one;
// *
// *        Check for significant underflow in ALPHAI
// *
if (Math.abs(salfai) < safmin && absai >= Math.max((safmin) > (eps*absar) ? (safmin) : (eps*absar), eps*absb))  {
    ilimit = true;
scale = (onepls*safmin/anrm1)/Math.max(onepls*safmin, anrm2*absai) ;
// *
}              // Close if()
else if (salfai == zero)  {
    // *
// *           If insignificant underflow in ALPHAI, then make the
// *           conjugate eigenvalue real.
// *
if (alphai[(jc)- 1+ _alphai_offset] < zero && jc > 1)  {
    alphai[(jc-1)- 1+ _alphai_offset] = zero;
}              // Close if()
else if (alphai[(jc)- 1+ _alphai_offset] > zero && jc < n)  {
    alphai[(jc+1)- 1+ _alphai_offset] = zero;
}              // Close else if()
}              // Close else if()
// *
// *        Check for significant underflow in ALPHAR
// *
if (Math.abs(salfar) < safmin && absar >= Math.max((safmin) > (eps*absai) ? (safmin) : (eps*absai), eps*absb))  {
    ilimit = true;
scale = Math.max(scale, (onepls*safmin/anrm1)/Math.max(onepls*safmin, anrm2*absar) ) ;
}              // Close if()
// *
// *        Check for significant underflow in BETA
// *
if (Math.abs(sbeta) < safmin && absb >= Math.max((safmin) > (eps*absar) ? (safmin) : (eps*absar), eps*absai))  {
    ilimit = true;
scale = Math.max(scale, (onepls*safmin/bnrm1)/Math.max(onepls*safmin, bnrm2*absb) ) ;
}              // Close if()
// *
// *        Check for possible overflow when limiting scaling
// *
if (ilimit)  {
    temp = (scale*safmin)*Math.max((Math.abs(salfar)) > (Math.abs(salfai)) ? (Math.abs(salfar)) : (Math.abs(salfai)), Math.abs(sbeta));
if (temp > one)  
    scale = scale/temp;
if (scale < one)  
    ilimit = false;
}              // Close if()
// *
// *        Recompute un-scaled ALPHAR, ALPHAI, BETA if necessary.
// *
if (ilimit)  {
    salfar = (scale*alphar[(jc)- 1+ _alphar_offset])*anrm;
salfai = (scale*alphai[(jc)- 1+ _alphai_offset])*anrm;
sbeta = (scale*beta[(jc)- 1+ _beta_offset])*bnrm;
}              // Close if()
alphar[(jc)- 1+ _alphar_offset] = salfar;
alphai[(jc)- 1+ _alphai_offset] = salfai;
beta[(jc)- 1+ _beta_offset] = sbeta;
Dummy.label("Dgegv",110);
}              //  Close for() loop. 
}
// *
label120:
   Dummy.label("Dgegv",120);
work[(1)- 1+ _work_offset] = (double)(lwkopt);
// *
Dummy.go_to("Dgegv",999999);
// *
// *     End of DGEGV
// *
Dummy.label("Dgegv",999999);
return;
   }
} // End class.
