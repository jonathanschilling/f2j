/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgehrd {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEHRD reduces a real general matrix A to upper Hessenberg form H by
// *  an orthogonal similarity transformation:  Q' * A * Q = H .
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          It is assumed that A is already upper triangular in rows
// *          and columns 1:ILO-1 and IHI+1:N. ILO and IHI are normally
// *          set by a previous call to DGEBAL; otherwise they should be
// *          set to 1 and N respectively. See Further Details.
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the N-by-N general matrix to be reduced.
// *          On exit, the upper triangle and the first subdiagonal of A
// *          are overwritten with the upper Hessenberg matrix H, and the
// *          elements below the first subdiagonal, with the array TAU,
// *          represent the orthogonal matrix Q as a product of elementary
// *          reflectors. See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (N-1)
// *          The scalar factors of the elementary reflectors (see Further
// *          Details). Elements 1:ILO-1 and IHI:N-1 of TAU are set to
// *          zero.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK >= max(1,N).
// *          For optimum performance LWORK >= N*NB, where NB is the
// *          optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  The matrix Q is represented as a product of (ihi-ilo) elementary
// *  reflectors
// *
// *     Q = H(ilo) H(ilo+1) . . . H(ihi-1).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i) = 0, v(i+1) = 1 and v(ihi+1:n) = 0; v(i+2:ihi) is stored on
// *  exit in A(i+2:ihi,i), and tau in TAU(i).
// *
// *  The contents of A are illustrated by the following example, with
// *  n = 7, ilo = 2 and ihi = 6:
// *
// *  on entry,                        on exit,
// *
// *  ( a   a   a   a   a   a   a )    (  a   a   h   h   h   h   a )
// *  (     a   a   a   a   a   a )    (      a   h   h   h   h   a )
// *  (     a   a   a   a   a   a )    (      h   h   h   h   h   h )
// *  (     a   a   a   a   a   a )    (      v2  h   h   h   h   h )
// *  (     a   a   a   a   a   a )    (      v2  v3  h   h   h   h )
// *  (     a   a   a   a   a   a )    (      v2  v3  v4  h   h   h )
// *  (                         a )    (                          a )
// *
// *  where a denotes an element of the original matrix A, h denotes a
// *  modified element of the upper Hessenberg matrix H, and vi denotes an
// *  element of the vector defining H(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nbmax= 64;
static int ldt= nbmax+1;
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ib= 0;
static intW iinfo= new intW(0);
static int iws= 0;
static int ldwork= 0;
static int nb= 0;
static int nbmin= 0;
static int nh= 0;
static int nx= 0;
static double ei= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] t= new double[(ldt) * (nbmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dgehrd (int n,
int ilo,
int ihi,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (ilo < 1 || ilo > Math.max(1, n) )  {
    info.val = -2;
}              // Close else if()
else if (ihi < Math.min(ilo, n)  || ihi > n)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (lwork < Math.max(1, n) )  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEHRD",-info.val);
Dummy.go_to("Dgehrd",999999);
}              // Close if()
// *
// *     Set elements 1:ILO-1 and IHI:N-1 of TAU to zero
// *
{
forloop10:
for (i = 1; i <= ilo-1; i++) {
tau[(i)- 1+ _tau_offset] = zero;
Dummy.label("Dgehrd",10);
}              //  Close for() loop. 
}
{
forloop20:
for (i = (int)(Math.max(1, ihi) ); i <= n-1; i++) {
tau[(i)- 1+ _tau_offset] = zero;
Dummy.label("Dgehrd",20);
}              //  Close for() loop. 
}
// *
// *     Quick return if possible
// *
nh = ihi-ilo+1;
if (nh <= 1)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dgehrd",999999);
}              // Close if()
// *
// *     Determine the block size.
// *
nb = (int)(Math.min(nbmax, Ilaenv.ilaenv(1,"DGEHRD"," ",n,ilo,ihi,-1)) );
nbmin = 2;
iws = 1;
if (nb > 1 && nb < nh)  {
    // *
// *        Determine when to cross over from blocked to unblocked code
// *        (last block is always handled by unblocked code).
// *
nx = (int)(Math.max(nb, Ilaenv.ilaenv(3,"DGEHRD"," ",n,ilo,ihi,-1)) );
if (nx < nh)  {
    // *
// *           Determine if workspace is large enough for blocked code.
// *
iws = n*nb;
if (lwork < iws)  {
    // *
// *              Not enough workspace to use optimal NB:  determine the
// *              minimum value of NB, and reduce NB or force use of
// *              unblocked code.
// *
nbmin = (int)(Math.max(2, Ilaenv.ilaenv(2,"DGEHRD"," ",n,ilo,ihi,-1)) );
if (lwork >= n*nbmin)  {
    nb = lwork/n;
}              // Close if()
else  {
  nb = 1;
}              //  Close else.
}              // Close if()
}              // Close if()
}              // Close if()
ldwork = n;
// *
if (nb < nbmin || nb >= nh)  {
    // *
// *        Use unblocked code below
// *
i = ilo;
// *
}              // Close if()
else  {
  // *
// *        Use blocked code
// *
{
int _i_inc = nb;
forloop30:
for (i = ilo; (_i_inc < 0) ? i >= ihi-1-nx : i <= ihi-1-nx; i += _i_inc) {
ib = (int)(Math.min(nb, ihi-i) );
// *
// *           Reduce columns i:i+ib-1 to Hessenberg form, returning the
// *           matrices V and T of the block reflector H = I - V*T*V'
// *           which performs the reduction, and also the matrix Y = A*V*T
// *
Dlahrd.dlahrd(ihi,i,ib,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,t,0,ldt,work,_work_offset,ldwork);
// *
// *           Apply the block reflector H to A(1:ihi,i+ib:ihi) from the
// *           right, computing  A := A - Y * V'. V(i+ib,ib-1) must be set
// *           to 1.
// *
ei = a[(i+ib)- 1+(i+ib-1- 1)*lda+ _a_offset];
a[(i+ib)- 1+(i+ib-1- 1)*lda+ _a_offset] = one;
Dgemm.dgemm("No transpose","Transpose",ihi,ihi-i-ib+1,ib,-one,work,_work_offset,ldwork,a,(i+ib)- 1+(i- 1)*lda+ _a_offset,lda,one,a,(1)- 1+(i+ib- 1)*lda+ _a_offset,lda);
a[(i+ib)- 1+(i+ib-1- 1)*lda+ _a_offset] = ei;
// *
// *           Apply the block reflector H to A(i+1:ihi,i+ib:n) from the
// *           left
// *
Dlarfb.dlarfb("Left","Transpose","Forward","Columnwise",ihi-i,n-i-ib+1,ib,a,(i+1)- 1+(i- 1)*lda+ _a_offset,lda,t,0,ldt,a,(i+1)- 1+(i+ib- 1)*lda+ _a_offset,lda,work,_work_offset,ldwork);
Dummy.label("Dgehrd",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Use unblocked code to reduce the rest of the matrix
// *
Dgehd2.dgehd2(n,i,ihi,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,iinfo);
work[(1)- 1+ _work_offset] = (double)(iws);
// *
Dummy.go_to("Dgehrd",999999);
// *
// *     End of DGEHRD
// *
Dummy.label("Dgehrd",999999);
return;
   }
} // End class.
