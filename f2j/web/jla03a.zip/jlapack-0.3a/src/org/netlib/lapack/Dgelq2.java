/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgelq2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGELQ2 computes an LQ factorization of a real m by n matrix A:
// *  A = L * Q.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the m by n matrix A.
// *          On exit, the elements on and below the diagonal of the array
// *          contain the m by min(m,n) lower trapezoidal matrix L (L is
// *          lower triangular if m <= n); the elements above the diagonal,
// *          with the array TAU, represent the orthogonal matrix Q as a
// *          product of elementary reflectors (see Further Details).
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors (see Further
// *          Details).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  Further Details
// *  ===============
// *
// *  The matrix Q is represented as a product of elementary reflectors
// *
// *     Q = H(k) . . . H(2) H(1), where k = min(m,n).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i-1) = 0 and v(i) = 1; v(i+1:n) is stored on exit in A(i,i+1:n),
// *  and tau in TAU(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int k= 0;
static double aii= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgelq2 (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGELQ2",-info.val);
Dummy.go_to("Dgelq2",999999);
}              // Close if()
// *
k = (int)(Math.min(m, n) );
// *
{
forloop10:
for (i = 1; i <= k; i++) {
// *
// *        Generate elementary reflector H(i) to annihilate A(i,i+1:n)
// *
dlarfg_adapter(n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(i)- 1+(Math.min(i+1, n) - 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset);
if (i < m)  {
    // *
// *           Apply H(i) to A(i+1:m,i:n) from the right
// *
aii = a[(i)- 1+(i- 1)*lda+ _a_offset];
a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
Dlarf.dlarf("Right",m-i,n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,tau[(i)- 1+ _tau_offset],a,(i+1)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset);
a[(i)- 1+(i- 1)*lda+ _a_offset] = aii;
}              // Close if()
Dummy.label("Dgelq2",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dgelq2",999999);
// *
// *     End of DGELQ2
// *
Dummy.label("Dgelq2",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
