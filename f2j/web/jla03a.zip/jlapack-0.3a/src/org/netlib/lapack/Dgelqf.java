/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgelqf {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGELQF computes an LQ factorization of a real M-by-N matrix A:
// *  A = L * Q.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, the elements on and below the diagonal of the array
// *          contain the m-by-min(m,n) lower trapezoidal matrix L (L is
// *          lower triangular if m <= n); the elements above the diagonal,
// *          with the array TAU, represent the orthogonal matrix Q as a
// *          product of elementary reflectors (see Further Details).
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors (see Further
// *          Details).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,M).
// *          For optimum performance LWORK >= M*NB, where NB is the
// *          optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  Further Details
// *  ===============
// *
// *  The matrix Q is represented as a product of elementary reflectors
// *
// *     Q = H(k) . . . H(2) H(1), where k = min(m,n).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i-1) = 0 and v(i) = 1; v(i+1:n) is stored on exit in A(i,i+1:n),
// *  and tau in TAU(i).
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int ib= 0;
static intW iinfo= new intW(0);
static int iws= 0;
static int k= 0;
static int ldwork= 0;
static int nb= 0;
static int nbmin= 0;
static int nx= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgelqf (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
else if (lwork < Math.max(1, m) )  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGELQF",-info.val);
Dummy.go_to("Dgelqf",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
k = (int)(Math.min(m, n) );
if (k == 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dgelqf",999999);
}              // Close if()
// *
// *     Determine the block size.
// *
nb = Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
nbmin = 2;
nx = 0;
iws = m;
if (nb > 1 && nb < k)  {
    // *
// *        Determine when to cross over from blocked to unblocked code.
// *
nx = (int)(Math.max(0, Ilaenv.ilaenv(3,"DGELQF"," ",m,n,-1,-1)) );
if (nx < k)  {
    // *
// *           Determine if workspace is large enough for blocked code.
// *
ldwork = m;
iws = ldwork*nb;
if (lwork < iws)  {
    // *
// *              Not enough workspace to use optimal NB:  reduce NB and
// *              determine the minimum value of NB.
// *
nb = lwork/ldwork;
nbmin = (int)(Math.max(2, Ilaenv.ilaenv(2,"DGELQF"," ",m,n,-1,-1)) );
}              // Close if()
}              // Close if()
}              // Close if()
// *
if (nb >= nbmin && nb < k && nx < k)  {
    // *
// *        Use blocked code initially
// *
{
int _i_inc = nb;
forloop10:
for (i = 1; (_i_inc < 0) ? i >= k-nx : i <= k-nx; i += _i_inc) {
ib = (int)(Math.min(k-i+1, nb) );
// *
// *           Compute the LQ factorization of the current block
// *           A(i:i+ib-1,i:n)
// *
Dgelq2.dgelq2(ib,n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,work,_work_offset,iinfo);
if (i+ib <= m)  {
    // *
// *              Form the triangular factor of the block reflector
// *              H = H(i) H(i+1) . . . H(i+ib-1)
// *
Dlarft.dlarft("Forward","Rowwise",n-i+1,ib,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,work,_work_offset,ldwork);
// *
// *              Apply H to A(i+ib:m,i:n) from the right
// *
Dlarfb.dlarfb("Right","No transpose","Forward","Rowwise",m-i-ib+1,n-i+1,ib,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset,ldwork,a,(i+ib)- 1+(i- 1)*lda+ _a_offset,lda,work,(ib+1)- 1+ _work_offset,ldwork);
}              // Close if()
Dummy.label("Dgelqf",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  i = 1;
}              //  Close else.
// *
// *     Use unblocked code to factor the last or only block.
// *
if (i <= k)  
    Dgelq2.dgelq2(m-i+1,n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,work,_work_offset,iinfo);
// *
work[(1)- 1+ _work_offset] = (double)(iws);
Dummy.go_to("Dgelqf",999999);
// *
// *     End of DGELQF
// *
Dummy.label("Dgelqf",999999);
return;
   }
} // End class.
