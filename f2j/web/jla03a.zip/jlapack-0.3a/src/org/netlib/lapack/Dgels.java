/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgels {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGELS solves overdetermined or underdetermined real linear systems
// *  involving an M-by-N matrix A, or its transpose, using a QR or LQ
// *  factorization of A.  It is assumed that A has full rank.
// *
// *  The following options are provided:
// *
// *  1. If TRANS = 'N' and m >= n:  find the least squares solution of
// *     an overdetermined system, i.e., solve the least squares problem
// *                  minimize || B - A*X ||.
// *
// *  2. If TRANS = 'N' and m < n:  find the minimum norm solution of
// *     an underdetermined system A * X = B.
// *
// *  3. If TRANS = 'T' and m >= n:  find the minimum norm solution of
// *     an undetermined system A**T * X = B.
// *
// *  4. If TRANS = 'T' and m < n:  find the least squares solution of
// *     an overdetermined system, i.e., solve the least squares problem
// *                  minimize || B - A**T * X ||.
// *
// *  Several right hand side vectors b and solution vectors x can be
// *  handled in a single call; they are stored as the columns of the
// *  M-by-NRHS right hand side matrix B and the N-by-NRHS solution
// *  matrix X.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER
// *          = 'N': the linear system involves A;
// *          = 'T': the linear system involves A**T.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of
// *          columns of the matrices B and X. NRHS >=0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit,
// *            if M >= N, A is overwritten by details of its QR
// *                       factorization as returned by DGEQRF;
// *            if M <  N, A is overwritten by details of its LQ
// *                       factorization as returned by DGELQF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the matrix B of right hand side vectors, stored
// *          columnwise; B is M-by-NRHS if TRANS = 'N', or N-by-NRHS
// *          if TRANS = 'T'.
// *          On exit, B is overwritten by the solution vectors, stored
// *          columnwise:
// *          if TRANS = 'N' and m >= n, rows 1 to n of B contain the least
// *          squares solution vectors; the residual sum of squares for the
// *          solution in each column is given by the sum of squares of
// *          elements N+1 to M in that column;
// *          if TRANS = 'N' and m < n, rows 1 to N of B contain the
// *          minimum norm solution vectors;
// *          if TRANS = 'T' and m >= n, rows 1 to M of B contain the
// *          minimum norm solution vectors;
// *          if TRANS = 'T' and m < n, rows 1 to M of B contain the
// *          least squares solution vectors; the residual sum of squares
// *          for the solution in each column is given by the sum of
// *          squares of elements M+1 to N in that column.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= MAX(1,M,N).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *          LWORK >= min(M,N) + MAX(1,M,N,NRHS).
// *          For optimal performance,
// *          LWORK >= min(M,N) + MAX(1,M,N,NRHS) * NB
// *          where NB is the optimum block size.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean tpsd= false;
static int brow= 0;
static int i= 0;
static int iascl= 0;
static int ibscl= 0;
static int j= 0;
static int mn= 0;
static int nb= 0;
static int scllen= 0;
static int wsize= 0;
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double bnrm= 0.0;
static doubleW smlnum= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] rwork= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments.
// *

public static void dgels (String trans,
int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
mn = (int)(Math.min(m, n) );
if (!((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) || (trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0))))  {
    info.val = -1;
}              // Close if()
else if (m < 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -6;
}              // Close else if()
else if (ldb < Math.max((1) > (m) ? (1) : (m), n))  {
    info.val = -8;
}              // Close else if()
else if (lwork < Math.max(1, mn+Math.max((m) > (n) ? (m) : (n), nrhs)) )  {
    info.val = -10;
}              // Close else if()
// *
// *     Figure out optimal block size
// *
if (info.val == 0 || info.val == -10)  {
    // *
tpsd = true;
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  
    tpsd = false;
// *
if (m >= n)  {
    nb = Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
if (tpsd)  {
    nb = (int)(Math.max(nb, Ilaenv.ilaenv(1,"DORMQR","LN",m,nrhs,n,-1)) );
}              // Close if()
else  {
  nb = (int)(Math.max(nb, Ilaenv.ilaenv(1,"DORMQR","LT",m,nrhs,n,-1)) );
}              //  Close else.
}              // Close if()
else  {
  nb = Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
if (tpsd)  {
    nb = (int)(Math.max(nb, Ilaenv.ilaenv(1,"DORMLQ","LT",n,nrhs,m,-1)) );
}              // Close if()
else  {
  nb = (int)(Math.max(nb, Ilaenv.ilaenv(1,"DORMLQ","LN",n,nrhs,m,-1)) );
}              //  Close else.
}              //  Close else.
// *
wsize = (int)(mn+Math.max((m) > (n) ? (m) : (n), nrhs)*nb);
work[(1)- 1+ _work_offset] = (double)(wsize);
// *
}              // Close if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGELS ",-info.val);
Dummy.go_to("Dgels",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (Math.min((m) < (n) ? (m) : (n), nrhs) == 0)  {
    Dlaset.dlaset("Full",(int) ( Math.max(m, n) ),nrhs,zero,zero,b,_b_offset,ldb);
Dummy.go_to("Dgels",999999);
}              // Close if()
// *
// *     Get machine parameters
// *
smlnum.val = Dlamch.dlamch("S")/Dlamch.dlamch("P");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Scale A, B if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",m,n,a,_a_offset,lda,rwork,0);
iascl = 0;
if (anrm > zero && anrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,anrm,smlnum.val,m,n,a,_a_offset,lda,info);
iascl = 1;
}              // Close if()
else if (anrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,anrm,bignum.val,m,n,a,_a_offset,lda,info);
iascl = 2;
}              // Close else if()
else if (anrm == zero)  {
    // *
// *        Matrix all zero. Return zero solution.
// *
Dlaset.dlaset("F",(int) ( Math.max(m, n) ),nrhs,zero,zero,b,_b_offset,ldb);
Dummy.go_to("Dgels",50);
}              // Close else if()
// *
brow = m;
if (tpsd)  
    brow = n;
bnrm = Dlange.dlange("M",brow,nrhs,b,_b_offset,ldb,rwork,0);
ibscl = 0;
if (bnrm > zero && bnrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,bnrm,smlnum.val,brow,nrhs,b,_b_offset,ldb,info);
ibscl = 1;
}              // Close if()
else if (bnrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,bnrm,bignum.val,brow,nrhs,b,_b_offset,ldb,info);
ibscl = 2;
}              // Close else if()
// *
if (m >= n)  {
    // *
// *        compute QR factorization of A
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(1)- 1+ _work_offset,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *        workspace at least N, optimally N*NB
// *
if (!tpsd)  {
    // *
// *           Least-Squares Problem min || A * X - B ||
// *
// *           B(1:M,1:NRHS) := Q' * B(1:M,1:NRHS)
// *
Dormqr.dormqr("Left","Transpose",m,nrhs,n,a,_a_offset,lda,work,(1)- 1+ _work_offset,b,_b_offset,ldb,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *           workspace at least NRHS, optimally NRHS*NB
// *
// *           B(1:N,1:NRHS) := inv(R) * B(1:N,1:NRHS)
// *
Dtrsm.dtrsm("Left","Upper","No transpose","Non-unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
scllen = n;
// *
}              // Close if()
else  {
  // *
// *           Overdetermined system of equations A' * X = B
// *
// *           B(1:N,1:NRHS) := inv(R') * B(1:N,1:NRHS)
// *
Dtrsm.dtrsm("Left","Upper","Transpose","Non-unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
// *           B(N+1:M,1:NRHS) = ZERO
// *
{
forloop20:
for (j = 1; j <= nrhs; j++) {
{
forloop10:
for (i = n+1; i <= m; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dgels",10);
}              //  Close for() loop. 
}
Dummy.label("Dgels",20);
}              //  Close for() loop. 
}
// *
// *           B(1:M,1:NRHS) := Q(1:N,:) * B(1:N,1:NRHS)
// *
Dormqr.dormqr("Left","No transpose",m,nrhs,n,a,_a_offset,lda,work,(1)- 1+ _work_offset,b,_b_offset,ldb,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *           workspace at least NRHS, optimally NRHS*NB
// *
scllen = m;
// *
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *        Compute LQ factorization of A
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(1)- 1+ _work_offset,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *        workspace at least M, optimally M*NB.
// *
if (!tpsd)  {
    // *
// *           underdetermined system of equations A * X = B
// *
// *           B(1:M,1:NRHS) := inv(L) * B(1:M,1:NRHS)
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Non-unit",m,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
// *           B(M+1:N,1:NRHS) = 0
// *
{
forloop40:
for (j = 1; j <= nrhs; j++) {
{
forloop30:
for (i = m+1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dgels",30);
}              //  Close for() loop. 
}
Dummy.label("Dgels",40);
}              //  Close for() loop. 
}
// *
// *           B(1:N,1:NRHS) := Q(1:N,:)' * B(1:M,1:NRHS)
// *
Dormlq.dormlq("Left","Transpose",n,nrhs,m,a,_a_offset,lda,work,(1)- 1+ _work_offset,b,_b_offset,ldb,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *           workspace at least NRHS, optimally NRHS*NB
// *
scllen = n;
// *
}              // Close if()
else  {
  // *
// *           overdetermined system min || A' * X - B ||
// *
// *           B(1:N,1:NRHS) := Q * B(1:N,1:NRHS)
// *
Dormlq.dormlq("Left","No transpose",n,nrhs,m,a,_a_offset,lda,work,(1)- 1+ _work_offset,b,_b_offset,ldb,work,(mn+1)- 1+ _work_offset,lwork-mn,info);
// *
// *           workspace at least NRHS, optimally NRHS*NB
// *
// *           B(1:M,1:NRHS) := inv(L') * B(1:M,1:NRHS)
// *
Dtrsm.dtrsm("Left","Lower","Transpose","Non-unit",m,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
scllen = m;
// *
}              //  Close else.
// *
}              //  Close else.
// *
// *     Undo scaling
// *
if (iascl == 1)  {
    Dlascl.dlascl("G",0,0,anrm,smlnum.val,scllen,nrhs,b,_b_offset,ldb,info);
}              // Close if()
else if (iascl == 2)  {
    Dlascl.dlascl("G",0,0,anrm,bignum.val,scllen,nrhs,b,_b_offset,ldb,info);
}              // Close else if()
if (ibscl == 1)  {
    Dlascl.dlascl("G",0,0,smlnum.val,bnrm,scllen,nrhs,b,_b_offset,ldb,info);
}              // Close if()
else if (ibscl == 2)  {
    Dlascl.dlascl("G",0,0,bignum.val,bnrm,scllen,nrhs,b,_b_offset,ldb,info);
}              // Close else if()
// *
label50:
   Dummy.label("Dgels",50);
work[(1)- 1+ _work_offset] = (double)(wsize);
// *
Dummy.go_to("Dgels",999999);
// *
// *     End of DGELS
// *
Dummy.label("Dgels",999999);
return;
   }
} // End class.
