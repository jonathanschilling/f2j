/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgelss {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGELSS computes the minimum norm solution to a real linear least
// *  squares problem:
// *
// *  Minimize 2-norm(| b - A*x |).
// *
// *  using the singular value decomposition (SVD) of A. A is an M-by-N
// *  matrix which may be rank-deficient.
// *
// *  Several right hand side vectors b and solution vectors x can be
// *  handled in a single call; they are stored as the columns of the
// *  M-by-NRHS right hand side matrix B and the N-by-NRHS solution matrix
// *  X.
// *
// *  The effective rank of A is determined by treating as zero those
// *  singular values which are less than RCOND times the largest singular
// *  value.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A. N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices B and X. NRHS >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, the first min(m,n) rows of A are overwritten with
// *          its right singular vectors, stored rowwise.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the M-by-NRHS right hand side matrix B.
// *          On exit, B is overwritten by the N-by-NRHS solution
// *          matrix X.  If m >= n and RANK = n, the residual
// *          sum-of-squares for the solution in the i-th column is given
// *          by the sum of squares of elements n+1:m in that column.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,max(M,N)).
// *
// *  S       (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The singular values of A in decreasing order.
// *          The condition number of A in the 2-norm = S(1)/S(min(m,n)).
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          RCOND is used to determine the effective rank of A.
// *          Singular values S(i) <= RCOND*S(1) are treated as zero.
// *          If RCOND < 0, machine precision is used instead.
// *
// *  RANK    (output) INTEGER
// *          The effective rank of A, i.e., the number of singular values
// *          which are greater than RCOND*S(1).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= 1, and also:
// *          LWORK >= 3*min(M,N) + max( 2*min(M,N), max(M,N), NRHS )
// *          For good performance, LWORK should generally be larger.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  the algorithm for computing the SVD failed to converge;
// *                if INFO = i, i off-diagonal elements of an intermediate
// *                bidiagonal form did not converge to zero.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int bdspac= 0;
static int bl= 0;
static int chunk= 0;
static int i= 0;
static int iascl= 0;
static int ibscl= 0;
static int ie= 0;
static int il= 0;
static int itau= 0;
static int itaup= 0;
static int itauq= 0;
static int iwork= 0;
static int ldwork= 0;
static int maxmn= 0;
static int maxwrk= 0;
static int minmn= 0;
static int minwrk= 0;
static int mm= 0;
static int mnthr= 0;
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double bnrm= 0.0;
static double eps= 0.0;
static double sfmin= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double thr= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] vdum= new double[(1)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgelss (int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] s, int _s_offset,
double rcond,
intW rank,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
minmn = (int)(Math.min(m, n) );
maxmn = (int)(Math.max(m, n) );
mnthr = Ilaenv.ilaenv(6,"DGELSS"," ",m,n,nrhs,-1);
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, maxmn) )  {
    info.val = -7;
}              // Close else if()
// *
// *     Compute workspace
// *      (Note: Comments in the code beginning "Workspace:" describe the
// *       minimal amount of workspace needed at that point in the code,
// *       as well as the preferred amount for good performance.
// *       NB refers to the optimal block size for the immediately
// *       following subroutine, as returned by ILAENV.)
// *
minwrk = 1;
if (info.val == 0 && lwork >= 1)  {
    maxwrk = 0;
mm = m;
if (m >= n && m >= mnthr)  {
    // *
// *           Path 1a - overdetermined, with many more rows than columns
// *
mm = n;
maxwrk = (int)(Math.max(maxwrk, n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1)) );
maxwrk = (int)(Math.max(maxwrk, n+nrhs*Ilaenv.ilaenv(1,"DORMQR","LT",m,nrhs,n,-1)) );
}              // Close if()
if (m >= n)  {
    // *
// *           Path 1 - overdetermined or exactly determined
// *
// *           Compute workspace neede for DBDSQR
// *
bdspac = (int)(Math.max(1, 5*n-4) );
maxwrk = (int)(Math.max(maxwrk, 3*n+(mm+n)*Ilaenv.ilaenv(1,"DGEBRD"," ",mm,n,-1,-1)) );
maxwrk = (int)(Math.max(maxwrk, 3*n+nrhs*Ilaenv.ilaenv(1,"DORMBR","QLT",mm,nrhs,n,-1)) );
maxwrk = (int)(Math.max(maxwrk, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
maxwrk = (int)(Math.max(maxwrk, n*nrhs) );
minwrk = (int)(Math.max((3*n+mm) > (3*n+nrhs) ? (3*n+mm) : (3*n+nrhs), bdspac));
maxwrk = (int)(Math.max(minwrk, maxwrk) );
}              // Close if()
if (n > m)  {
    // *
// *           Compute workspace neede for DBDSQR
// *
bdspac = (int)(Math.max(1, 5*m-4) );
minwrk = (int)(Math.max((3*m+nrhs) > (3*m+n) ? (3*m+nrhs) : (3*m+n), bdspac));
if (n >= mnthr)  {
    // *
// *              Path 2a - underdetermined, with many more columns
// *              than rows
// *
maxwrk = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
maxwrk = (int)(Math.max(maxwrk, m*m+4*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
maxwrk = (int)(Math.max(maxwrk, m*m+4*m+nrhs*Ilaenv.ilaenv(1,"DORMBR","QLT",m,nrhs,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, m*m+4*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, m*m+m+bdspac) );
if (nrhs > 1)  {
    maxwrk = (int)(Math.max(maxwrk, m*m+m+m*nrhs) );
}              // Close if()
else  {
  maxwrk = (int)(Math.max(maxwrk, m*m+2*m) );
}              //  Close else.
maxwrk = (int)(Math.max(maxwrk, m+nrhs*Ilaenv.ilaenv(1,"DORMLQ","LT",n,nrhs,m,-1)) );
}              // Close if()
else  {
  // *
// *              Path 2 - underdetermined
// *
maxwrk = 3*m+(n+m)*Ilaenv.ilaenv(1,"DGEBRD"," ",m,n,-1,-1);
maxwrk = (int)(Math.max(maxwrk, 3*m+nrhs*Ilaenv.ilaenv(1,"DORMBR","QLT",m,nrhs,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","P",m,n,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
maxwrk = (int)(Math.max(maxwrk, n*nrhs) );
}              //  Close else.
}              // Close if()
maxwrk = (int)(Math.max(minwrk, maxwrk) );
work[(1)- 1+ _work_offset] = (double)(maxwrk);
}              // Close if()
// *
minwrk = (int)(Math.max(minwrk, 1) );
if (lwork < minwrk)  
    info.val = -12;
if (info.val != 0)  {
    Xerbla.xerbla("DGELSS",-info.val);
Dummy.go_to("Dgelss",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  {
    rank.val = 0;
Dummy.go_to("Dgelss",999999);
}              // Close if()
// *
// *     Get machine parameters
// *
eps = Dlamch.dlamch("P");
sfmin = Dlamch.dlamch("S");
smlnum.val = sfmin/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Scale A if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",m,n,a,_a_offset,lda,work,_work_offset);
iascl = 0;
if (anrm > zero && anrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,anrm,smlnum.val,m,n,a,_a_offset,lda,info);
iascl = 1;
}              // Close if()
else if (anrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,anrm,bignum.val,m,n,a,_a_offset,lda,info);
iascl = 2;
}              // Close else if()
else if (anrm == zero)  {
    // *
// *        Matrix all zero. Return zero solution.
// *
Dlaset.dlaset("F",(int) ( Math.max(m, n) ),nrhs,zero,zero,b,_b_offset,ldb);
Dlaset.dlaset("F",minmn,1,zero,zero,s,_s_offset,1);
rank.val = 0;
Dummy.go_to("Dgelss",70);
}              // Close else if()
// *
// *     Scale B if max element outside range [SMLNUM,BIGNUM]
// *
bnrm = Dlange.dlange("M",m,nrhs,b,_b_offset,ldb,work,_work_offset);
ibscl = 0;
if (bnrm > zero && bnrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,bnrm,smlnum.val,m,nrhs,b,_b_offset,ldb,info);
ibscl = 1;
}              // Close if()
else if (bnrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,bnrm,bignum.val,m,nrhs,b,_b_offset,ldb,info);
ibscl = 2;
}              // Close else if()
// *
// *     Overdetermined case
// *
if (m >= n)  {
    // *
// *        Path 1 - overdetermined or exactly determined
// *
mm = m;
if (m >= mnthr)  {
    // *
// *           Path 1a - overdetermined, with many more rows than columns
// *
mm = n;
itau = 1;
iwork = itau+n;
// *
// *           Compute A=Q*R
// *           (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *           Multiply B by transpose(Q)
// *           (Workspace: need N+NRHS, prefer N+NRHS*NB)
// *
Dormqr.dormqr("L","T",m,nrhs,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *           Zero out below R
// *
if (n > 1)  
    Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
}              // Close if()
// *
ie = 1;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *        Bidiagonalize R in A
// *        (Workspace: need 3*N+MM, prefer 3*N+(MM+N)*NB)
// *
Dgebrd.dgebrd(mm,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Multiply B by transpose of left bidiagonalizing vectors of R
// *        (Workspace: need 3*N+NRHS, prefer 3*N+NRHS*NB)
// *
Dormbr.dormbr("Q","L","T",mm,nrhs,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Generate right bidiagonalizing vectors of R in A
// *        (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
iwork = ie+n;
// *
// *        Perform bidiagonal QR iteration
// *          multiply B by transpose of left singular vectors
// *          compute right singular vectors in A
// *        (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,0,nrhs,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,vdum,0,1,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dgelss",70);
// *
// *        Multiply B by reciprocals of singular values
// *
thr = Math.max(rcond*s[(1)- 1+ _s_offset], sfmin) ;
if (rcond < zero)  
    thr = Math.max(eps*s[(1)- 1+ _s_offset], sfmin) ;
rank.val = 0;
{
forloop10:
for (i = 1; i <= n; i++) {
if (s[(i)- 1+ _s_offset] > thr)  {
    Drscl.drscl(nrhs,s[(i)- 1+ _s_offset],b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
rank.val = rank.val+1;
}              // Close if()
else  {
  Dlaset.dlaset("F",1,nrhs,zero,zero,b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              //  Close else.
Dummy.label("Dgelss",10);
}              //  Close for() loop. 
}
// *
// *        Multiply B by right singular vectors
// *        (Workspace: need N, prefer N*NRHS)
// *
if (lwork >= ldb*nrhs && nrhs > 1)  {
    Dgemm.dgemm("T","N",n,nrhs,n,one,a,_a_offset,lda,b,_b_offset,ldb,zero,work,_work_offset,ldb);
Dlacpy.dlacpy("G",n,nrhs,work,_work_offset,ldb,b,_b_offset,ldb);
}              // Close if()
else if (nrhs > 1)  {
    chunk = lwork/n;
{
int _i_inc = chunk;
forloop20:
for (i = 1; (_i_inc < 0) ? i >= nrhs : i <= nrhs; i += _i_inc) {
bl = (int)(Math.min(nrhs-i+1, chunk) );
Dgemm.dgemm("T","N",n,bl,n,one,a,_a_offset,lda,b,_b_offset,ldb,zero,work,_work_offset,n);
Dlacpy.dlacpy("G",n,bl,work,_work_offset,n,b,_b_offset,ldb);
Dummy.label("Dgelss",20);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  Dgemv.dgemv("T",n,n,one,a,_a_offset,lda,b,_b_offset,1,zero,work,_work_offset,1);
Dcopy.dcopy(n,work,_work_offset,1,b,_b_offset,1);
}              //  Close else.
// *
}              // Close if()
else if (n >= mnthr && lwork >= 4*m+m*m+Math.max(Math.max(Math.max(m, 2*m-4), nrhs), n-3*m) )  {
    // *
// *        Path 2a - underdetermined, with many more columns than rows
// *        and sufficient workspace for an efficient algorithm
// *
ldwork = m;
if (lwork >= Math.max(4*m+m*lda+Math.max(Math.max(Math.max(m, 2*m-4), nrhs), n-3*m) , m*lda+m+m*nrhs) )  
    ldwork = lda;
itau = 1;
iwork = m+1;
// *
// *        Compute A=L*Q
// *        (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
il = iwork;
// *
// *        Copy L to WORK(IL), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(il)- 1+ _work_offset,ldwork);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(il+ldwork)- 1+ _work_offset,ldwork);
ie = il+ldwork*m;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *        Bidiagonalize L in WORK(IL)
// *        (Workspace: need M*M+5*M, prefer M*M+4*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(il)- 1+ _work_offset,ldwork,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Multiply B by transpose of left bidiagonalizing vectors of L
// *        (Workspace: need M*M+4*M+NRHS, prefer M*M+4*M+NRHS*NB)
// *
Dormbr.dormbr("Q","L","T",m,nrhs,m,work,(il)- 1+ _work_offset,ldwork,work,(itauq)- 1+ _work_offset,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Generate right bidiagonalizing vectors of R in WORK(IL)
// *        (Workspace: need M*M+5*M-1, prefer M*M+4*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(il)- 1+ _work_offset,ldwork,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
iwork = ie+m;
// *
// *        Perform bidiagonal QR iteration,
// *           computing right singular vectors of L in WORK(IL) and
// *           multiplying B by transpose of left singular vectors
// *        (Workspace: need M*M+M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,0,nrhs,s,_s_offset,work,(ie)- 1+ _work_offset,work,(il)- 1+ _work_offset,ldwork,a,_a_offset,lda,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dgelss",70);
// *
// *        Multiply B by reciprocals of singular values
// *
thr = Math.max(rcond*s[(1)- 1+ _s_offset], sfmin) ;
if (rcond < zero)  
    thr = Math.max(eps*s[(1)- 1+ _s_offset], sfmin) ;
rank.val = 0;
{
forloop30:
for (i = 1; i <= m; i++) {
if (s[(i)- 1+ _s_offset] > thr)  {
    Drscl.drscl(nrhs,s[(i)- 1+ _s_offset],b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
rank.val = rank.val+1;
}              // Close if()
else  {
  Dlaset.dlaset("F",1,nrhs,zero,zero,b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              //  Close else.
Dummy.label("Dgelss",30);
}              //  Close for() loop. 
}
iwork = ie;
// *
// *        Multiply B by right singular vectors of L in WORK(IL)
// *        (Workspace: need M*M+2*M, prefer M*M+M+M*NRHS)
// *
if (lwork >= ldb*nrhs+iwork-1 && nrhs > 1)  {
    Dgemm.dgemm("T","N",m,nrhs,m,one,work,(il)- 1+ _work_offset,ldwork,b,_b_offset,ldb,zero,work,(iwork)- 1+ _work_offset,ldb);
Dlacpy.dlacpy("G",m,nrhs,work,(iwork)- 1+ _work_offset,ldb,b,_b_offset,ldb);
}              // Close if()
else if (nrhs > 1)  {
    chunk = (lwork-iwork+1)/m;
{
int _i_inc = chunk;
forloop40:
for (i = 1; (_i_inc < 0) ? i >= nrhs : i <= nrhs; i += _i_inc) {
bl = (int)(Math.min(nrhs-i+1, chunk) );
Dgemm.dgemm("T","N",m,bl,m,one,work,(il)- 1+ _work_offset,ldwork,b,(1)- 1+(i- 1)*ldb+ _b_offset,ldb,zero,work,(iwork)- 1+ _work_offset,n);
Dlacpy.dlacpy("G",m,bl,work,(iwork)- 1+ _work_offset,n,b,_b_offset,ldb);
Dummy.label("Dgelss",40);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  Dgemv.dgemv("T",m,m,one,work,(il)- 1+ _work_offset,ldwork,b,(1)- 1+(1- 1)*ldb+ _b_offset,1,zero,work,(iwork)- 1+ _work_offset,1);
Dcopy.dcopy(m,work,(iwork)- 1+ _work_offset,1,b,(1)- 1+(1- 1)*ldb+ _b_offset,1);
}              //  Close else.
// *
// *        Zero out below first M rows of B
// *
Dlaset.dlaset("F",n-m,nrhs,zero,zero,b,(m+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
iwork = itau+m;
// *
// *        Multiply transpose(Q) by B
// *        (Workspace: need M+NRHS, prefer M+NRHS*NB)
// *
Dormlq.dormlq("L","T",n,nrhs,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
}              // Close else if()
else  {
  // *
// *        Path 2 - remaining underdetermined cases
// *
ie = 1;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *        Bidiagonalize A
// *        (Workspace: need 3*M+N, prefer 3*M+(M+N)*NB)
// *
Dgebrd.dgebrd(m,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Multiply B by transpose of left bidiagonalizing vectors
// *        (Workspace: need 3*M+NRHS, prefer 3*M+NRHS*NB)
// *
Dormbr.dormbr("Q","L","T",m,nrhs,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
// *
// *        Generate right bidiagonalizing vectors in A
// *        (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("P",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,info);
iwork = ie+m;
// *
// *        Perform bidiagonal QR iteration,
// *           computing right singular vectors of A in A and
// *           multiplying B by transpose of left singular vectors
// *        (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("L",m,n,0,nrhs,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,vdum,0,1,b,_b_offset,ldb,work,(iwork)- 1+ _work_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dgelss",70);
// *
// *        Multiply B by reciprocals of singular values
// *
thr = Math.max(rcond*s[(1)- 1+ _s_offset], sfmin) ;
if (rcond < zero)  
    thr = Math.max(eps*s[(1)- 1+ _s_offset], sfmin) ;
rank.val = 0;
{
forloop50:
for (i = 1; i <= m; i++) {
if (s[(i)- 1+ _s_offset] > thr)  {
    Drscl.drscl(nrhs,s[(i)- 1+ _s_offset],b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
rank.val = rank.val+1;
}              // Close if()
else  {
  Dlaset.dlaset("F",1,nrhs,zero,zero,b,(i)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              //  Close else.
Dummy.label("Dgelss",50);
}              //  Close for() loop. 
}
// *
// *        Multiply B by right singular vectors of A
// *        (Workspace: need N, prefer N*NRHS)
// *
if (lwork >= ldb*nrhs && nrhs > 1)  {
    Dgemm.dgemm("T","N",n,nrhs,m,one,a,_a_offset,lda,b,_b_offset,ldb,zero,work,_work_offset,ldb);
Dlacpy.dlacpy("F",n,nrhs,work,_work_offset,ldb,b,_b_offset,ldb);
}              // Close if()
else if (nrhs > 1)  {
    chunk = lwork/n;
{
int _i_inc = chunk;
forloop60:
for (i = 1; (_i_inc < 0) ? i >= nrhs : i <= nrhs; i += _i_inc) {
bl = (int)(Math.min(nrhs-i+1, chunk) );
Dgemm.dgemm("T","N",n,bl,m,one,a,_a_offset,lda,b,(1)- 1+(i- 1)*ldb+ _b_offset,ldb,zero,work,_work_offset,n);
Dlacpy.dlacpy("F",n,bl,work,_work_offset,n,b,(1)- 1+(i- 1)*ldb+ _b_offset,ldb);
Dummy.label("Dgelss",60);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  Dgemv.dgemv("T",m,n,one,a,_a_offset,lda,b,_b_offset,1,zero,work,_work_offset,1);
Dcopy.dcopy(n,work,_work_offset,1,b,_b_offset,1);
}              //  Close else.
}              //  Close else.
// *
// *     Undo scaling
// *
if (iascl == 1)  {
    Dlascl.dlascl("G",0,0,anrm,smlnum.val,n,nrhs,b,_b_offset,ldb,info);
Dlascl.dlascl("G",0,0,smlnum.val,anrm,minmn,1,s,_s_offset,minmn,info);
}              // Close if()
else if (iascl == 2)  {
    Dlascl.dlascl("G",0,0,anrm,bignum.val,n,nrhs,b,_b_offset,ldb,info);
Dlascl.dlascl("G",0,0,bignum.val,anrm,minmn,1,s,_s_offset,minmn,info);
}              // Close else if()
if (ibscl == 1)  {
    Dlascl.dlascl("G",0,0,smlnum.val,bnrm,n,nrhs,b,_b_offset,ldb,info);
}              // Close if()
else if (ibscl == 2)  {
    Dlascl.dlascl("G",0,0,bignum.val,bnrm,n,nrhs,b,_b_offset,ldb,info);
}              // Close else if()
// *
label70:
   Dummy.label("Dgelss",70);
work[(1)- 1+ _work_offset] = (double)(maxwrk);
Dummy.go_to("Dgelss",999999);
// *
// *     End of DGELSS
// *
Dummy.label("Dgelss",999999);
return;
   }
} // End class.
