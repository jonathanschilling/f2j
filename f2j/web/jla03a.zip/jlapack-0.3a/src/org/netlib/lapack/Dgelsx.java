/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgelsx {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGELSX computes the minimum-norm solution to a real linear least
// *  squares problem:
// *      minimize || A * X - B ||
// *  using a complete orthogonal factorization of A.  A is an M-by-N
// *  matrix which may be rank-deficient.
// *
// *  Several right hand side vectors b and solution vectors x can be
// *  handled in a single call; they are stored as the columns of the
// *  M-by-NRHS right hand side matrix B and the N-by-NRHS solution
// *  matrix X.
// *
// *  The routine first computes a QR factorization with column pivoting:
// *      A * P = Q * [ R11 R12 ]
// *                  [  0  R22 ]
// *  with R11 defined as the largest leading submatrix whose estimated
// *  condition number is less than 1/RCOND.  The order of R11, RANK,
// *  is the effective rank of A.
// *
// *  Then, R22 is considered to be negligible, and R12 is annihilated
// *  by orthogonal transformations from the right, arriving at the
// *  complete orthogonal factorization:
// *     A * P = Q * [ T11 0 ] * Z
// *                 [  0  0 ]
// *  The minimum-norm solution is then
// *     X = P * Z' [ inv(T11)*Q1'*B ]
// *                [        0       ]
// *  where Q1 consists of the first RANK columns of Q.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of
// *          columns of matrices B and X. NRHS >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, A has been overwritten by details of its
// *          complete orthogonal factorization.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the M-by-NRHS right hand side matrix B.
// *          On exit, the N-by-NRHS solution matrix X.
// *          If m >= n and RANK = n, the residual sum-of-squares for
// *          the solution in the i-th column is given by the sum of
// *          squares of elements N+1:M in that column.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,M,N).
// *
// *  JPVT    (input/output) INTEGER array, dimension (N)
// *          On entry, if JPVT(i) .ne. 0, the i-th column of A is an
// *          initial column, otherwise it is a free column.  Before
// *          the QR factorization of A, all initial columns are
// *          permuted to the leading positions; only the remaining
// *          free columns are moved as a result of column pivoting
// *          during the factorization.
// *          On exit, if JPVT(i) = k, then the i-th column of A*P
// *          was the k-th column of A.
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          RCOND is used to determine the effective rank of A, which
// *          is defined as the order of the largest leading triangular
// *          submatrix R11 in the QR factorization with pivoting of A,
// *          whose estimated condition number < 1/RCOND.
// *
// *  RANK    (output) INTEGER
// *          The effective rank of A, i.e., the order of the submatrix
// *          R11.  This is the same as the order of the submatrix T11
// *          in the complete orthogonal factorization of A.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (max( min(M,N)+3*N, 2*min(M,N)+NRHS )),
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int imax= 1;
static int imin= 2;
static double zero= 0.0e0;
static double one= 1.0e0;
static double done= zero;
static double ntdone= one;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int iascl= 0;
static int ibscl= 0;
static int ismax= 0;
static int ismin= 0;
static int j= 0;
static int k= 0;
static int mn= 0;
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double bnrm= 0.0;
static doubleW c1= new doubleW(0.0);
static doubleW c2= new doubleW(0.0);
static doubleW s1= new doubleW(0.0);
static doubleW s2= new doubleW(0.0);
static double smax= 0.0;
static doubleW smaxpr= new doubleW(0.0);
static double smin= 0.0;
static doubleW sminpr= new doubleW(0.0);
static doubleW smlnum= new doubleW(0.0);
static double t1= 0.0;
static double t2= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgelsx (int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
int [] jpvt, int _jpvt_offset,
double rcond,
intW rank,
double [] work, int _work_offset,
intW info)  {

mn = (int)(Math.min(m, n) );
ismin = mn+1;
ismax = 2*mn+1;
// *
// *     Test the input arguments.
// *
info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max((1) > (m) ? (1) : (m), n))  {
    info.val = -7;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGELSX",-info.val);
Dummy.go_to("Dgelsx",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (Math.min((m) < (n) ? (m) : (n), nrhs) == 0)  {
    rank.val = 0;
Dummy.go_to("Dgelsx",999999);
}              // Close if()
// *
// *     Get machine parameters
// *
smlnum.val = Dlamch.dlamch("S")/Dlamch.dlamch("P");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Scale A, B if max elements outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",m,n,a,_a_offset,lda,work,_work_offset);
iascl = 0;
if (anrm > zero && anrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,anrm,smlnum.val,m,n,a,_a_offset,lda,info);
iascl = 1;
}              // Close if()
else if (anrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,anrm,bignum.val,m,n,a,_a_offset,lda,info);
iascl = 2;
}              // Close else if()
else if (anrm == zero)  {
    // *
// *        Matrix all zero. Return zero solution.
// *
Dlaset.dlaset("F",(int) ( Math.max(m, n) ),nrhs,zero,zero,b,_b_offset,ldb);
rank.val = 0;
Dummy.go_to("Dgelsx",100);
}              // Close else if()
// *
bnrm = Dlange.dlange("M",m,nrhs,b,_b_offset,ldb,work,_work_offset);
ibscl = 0;
if (bnrm > zero && bnrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,bnrm,smlnum.val,m,nrhs,b,_b_offset,ldb,info);
ibscl = 1;
}              // Close if()
else if (bnrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,bnrm,bignum.val,m,nrhs,b,_b_offset,ldb,info);
ibscl = 2;
}              // Close else if()
// *
// *     Compute QR factorization with column pivoting of A:
// *        A * P = Q * R
// *
Dgeqpf.dgeqpf(m,n,a,_a_offset,lda,jpvt,_jpvt_offset,work,(1)- 1+ _work_offset,work,(mn+1)- 1+ _work_offset,info);
// *
// *     workspace 3*N. Details of Householder rotations stored
// *     in WORK(1:MN).
// *
// *     Determine RANK using incremental condition estimation
// *
work[(ismin)- 1+ _work_offset] = one;
work[(ismax)- 1+ _work_offset] = one;
smax = Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset]);
smin = smax;
if (Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset]) == zero)  {
    rank.val = 0;
Dlaset.dlaset("F",(int) ( Math.max(m, n) ),nrhs,zero,zero,b,_b_offset,ldb);
Dummy.go_to("Dgelsx",100);
}              // Close if()
else  {
  rank.val = 1;
}              //  Close else.
// *
label10:
   Dummy.label("Dgelsx",10);
if (rank.val < mn)  {
    i = rank.val+1;
Dlaic1.dlaic1(imin,rank.val,work,(ismin)- 1+ _work_offset,smin,a,(1)- 1+(i- 1)*lda+ _a_offset,a[(i)- 1+(i- 1)*lda+ _a_offset],sminpr,s1,c1);
Dlaic1.dlaic1(imax,rank.val,work,(ismax)- 1+ _work_offset,smax,a,(1)- 1+(i- 1)*lda+ _a_offset,a[(i)- 1+(i- 1)*lda+ _a_offset],smaxpr,s2,c2);
// *
if (smaxpr.val*rcond <= sminpr.val)  {
    {
forloop20:
for (i = 1; i <= rank.val; i++) {
work[(ismin+i-1)- 1+ _work_offset] = s1.val*work[(ismin+i-1)- 1+ _work_offset];
work[(ismax+i-1)- 1+ _work_offset] = s2.val*work[(ismax+i-1)- 1+ _work_offset];
Dummy.label("Dgelsx",20);
}              //  Close for() loop. 
}
work[(ismin+rank.val)- 1+ _work_offset] = c1.val;
work[(ismax+rank.val)- 1+ _work_offset] = c2.val;
smin = sminpr.val;
smax = smaxpr.val;
rank.val = rank.val+1;
Dummy.go_to("Dgelsx",10);
}              // Close if()
}              // Close if()
// *
// *     Logically partition R = [ R11 R12 ]
// *                             [  0  R22 ]
// *     where R11 = R(1:RANK,1:RANK)
// *
// *     [R11,R12] = [ T11, 0 ] * Y
// *
if (rank.val < n)  
    Dtzrqf.dtzrqf(rank.val,n,a,_a_offset,lda,work,(mn+1)- 1+ _work_offset,info);
// *
// *     Details of Householder rotations stored in WORK(MN+1:2*MN)
// *
// *     B(1:M,1:NRHS) := Q' * B(1:M,1:NRHS)
// *
Dorm2r.dorm2r("Left","Transpose",m,nrhs,mn,a,_a_offset,lda,work,(1)- 1+ _work_offset,b,_b_offset,ldb,work,(2*mn+1)- 1+ _work_offset,info);
// *
// *     workspace NRHS
// *
// *     B(1:RANK,1:NRHS) := inv(T11) * B(1:RANK,1:NRHS)
// *
Dtrsm.dtrsm("Left","Upper","No transpose","Non-unit",rank.val,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
{
forloop40:
for (i = rank.val+1; i <= n; i++) {
{
forloop30:
for (j = 1; j <= nrhs; j++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dgelsx",30);
}              //  Close for() loop. 
}
Dummy.label("Dgelsx",40);
}              //  Close for() loop. 
}
// *
// *     B(1:N,1:NRHS) := Y' * B(1:N,1:NRHS)
// *
if (rank.val < n)  {
    {
forloop50:
for (i = 1; i <= rank.val; i++) {
Dlatzm.dlatzm("Left",n-rank.val+1,nrhs,a,(i)- 1+(rank.val+1- 1)*lda+ _a_offset,lda,work[(mn+i)- 1+ _work_offset],b,(i)- 1+(1- 1)*ldb+ _b_offset,b,(rank.val+1)- 1+(1- 1)*ldb+ _b_offset,ldb,work,(2*mn+1)- 1+ _work_offset);
Dummy.label("Dgelsx",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     workspace NRHS
// *
// *     B(1:N,1:NRHS) := P * B(1:N,1:NRHS)
// *
{
forloop90:
for (j = 1; j <= nrhs; j++) {
{
forloop60:
for (i = 1; i <= n; i++) {
work[(2*mn+i)- 1+ _work_offset] = ntdone;
Dummy.label("Dgelsx",60);
}              //  Close for() loop. 
}
{
forloop80:
for (i = 1; i <= n; i++) {
if (work[(2*mn+i)- 1+ _work_offset] == ntdone)  {
    if (jpvt[(i)- 1+ _jpvt_offset] != i)  {
    k = i;
t1 = b[(k)- 1+(j- 1)*ldb+ _b_offset];
t2 = b[(jpvt[(k)- 1+ _jpvt_offset])- 1+(j- 1)*ldb+ _b_offset];
label70:
   Dummy.label("Dgelsx",70);
b[(jpvt[(k)- 1+ _jpvt_offset])- 1+(j- 1)*ldb+ _b_offset] = t1;
work[(2*mn+k)- 1+ _work_offset] = done;
t1 = t2;
k = jpvt[(k)- 1+ _jpvt_offset];
t2 = b[(jpvt[(k)- 1+ _jpvt_offset])- 1+(j- 1)*ldb+ _b_offset];
if (jpvt[(k)- 1+ _jpvt_offset] != i)  
    Dummy.go_to("Dgelsx",70);
b[(i)- 1+(j- 1)*ldb+ _b_offset] = t1;
work[(2*mn+k)- 1+ _work_offset] = done;
}              // Close if()
}              // Close if()
Dummy.label("Dgelsx",80);
}              //  Close for() loop. 
}
Dummy.label("Dgelsx",90);
}              //  Close for() loop. 
}
// *
// *     Undo scaling
// *
if (iascl == 1)  {
    Dlascl.dlascl("G",0,0,anrm,smlnum.val,n,nrhs,b,_b_offset,ldb,info);
Dlascl.dlascl("U",0,0,smlnum.val,anrm,rank.val,rank.val,a,_a_offset,lda,info);
}              // Close if()
else if (iascl == 2)  {
    Dlascl.dlascl("G",0,0,anrm,bignum.val,n,nrhs,b,_b_offset,ldb,info);
Dlascl.dlascl("U",0,0,bignum.val,anrm,rank.val,rank.val,a,_a_offset,lda,info);
}              // Close else if()
if (ibscl == 1)  {
    Dlascl.dlascl("G",0,0,smlnum.val,bnrm,n,nrhs,b,_b_offset,ldb,info);
}              // Close if()
else if (ibscl == 2)  {
    Dlascl.dlascl("G",0,0,bignum.val,bnrm,n,nrhs,b,_b_offset,ldb,info);
}              // Close else if()
// *
label100:
   Dummy.label("Dgelsx",100);
// *
Dummy.go_to("Dgelsx",999999);
// *
// *     End of DGELSX
// *
Dummy.label("Dgelsx",999999);
return;
   }
} // End class.
