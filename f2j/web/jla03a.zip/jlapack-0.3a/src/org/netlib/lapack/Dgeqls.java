/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgeqls {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  Solve the least squares problem
// *      min || A*X - B ||
// *  using the QL factorization
// *      A = Q*L
// *  computed by DGEQLF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  M >= N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of B.  NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the QL factorization of the original matrix A as
// *          returned by DGEQLF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= M.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N)
// *          Details of the orthogonal matrix Q.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the m-by-nrhs right hand side matrix B.
// *          On exit, the n-by-nrhs solution matrix X, stored in rows
// *          m-n+1:m.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= M.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK must be at least NRHS,
// *          and should be at least NRHS*NB, where NB is the block size
// *          for this environment.
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments.
// *

public static void dgeqls (int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0 || n > m)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, m) )  {
    info.val = -8;
}              // Close else if()
else if (lwork < 1 || lwork < nrhs && m > 0 && n > 0)  {
    info.val = -10;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEQLS",-info.val);
Dummy.go_to("Dgeqls",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0 || m == 0)  
    Dummy.go_to("Dgeqls",999999);
// *
// *     B := Q' * B
// *
Dormql.dormql("Left","Transpose",m,nrhs,n,a,_a_offset,lda,tau,_tau_offset,b,_b_offset,ldb,work,_work_offset,lwork,info);
// *
// *     Solve L*X = B(m-n+1:m,:)
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Non-unit",n,nrhs,one,a,(m-n+1)- 1+(1- 1)*lda+ _a_offset,lda,b,(m-n+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
Dummy.go_to("Dgeqls",999999);
// *
// *     End of DGEQLS
// *
Dummy.label("Dgeqls",999999);
return;
   }
} // End class.
