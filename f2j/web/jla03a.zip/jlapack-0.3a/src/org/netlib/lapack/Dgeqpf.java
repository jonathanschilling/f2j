/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgeqpf {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGEQPF computes a QR factorization with column pivoting of a
// *  real M-by-N matrix A: A*P = Q*R.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A. N >= 0
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, the upper triangle of the array contains the
// *          min(M,N)-by-N upper triangular matrix R; the elements
// *          below the diagonal, together with the array TAU,
// *          represent the orthogonal matrix Q as a product of
// *          min(m,n) elementary reflectors.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,M).
// *
// *  JPVT    (input/output) INTEGER array, dimension (N)
// *          On entry, if JPVT(i) .ne. 0, the i-th column of A is permuted
// *          to the front of A*P (a leading column); if JPVT(i) = 0,
// *          the i-th column of A is a free column.
// *          On exit, if JPVT(i) = k, then the i-th column of A*P
// *          was the k-th column of A.
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  Further Details
// *  ===============
// *
// *  The matrix Q is represented as a product of elementary reflectors
// *
// *     Q = H(1) H(2) . . . H(n)
// *
// *  Each H(i) has the form
// *
// *     H = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in A(i+1:m,i).
// *
// *  The matrix P is represented in jpvt as follows: If
// *     jpvt(j) = i
// *  then the jth column of P is the ith canonical unit vector.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int itemp= 0;
static int j= 0;
static int ma= 0;
static int mn= 0;
static int pvt= 0;
static double aii= 0.0;
static double temp= 0.0;
static double temp2= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgeqpf (int m,
int n,
double [] a, int _a_offset,
int lda,
int [] jpvt, int _jpvt_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGEQPF",-info.val);
Dummy.go_to("Dgeqpf",999999);
}              // Close if()
// *
mn = (int)(Math.min(m, n) );
// *
// *     Move initial columns up front
// *
itemp = 1;
{
forloop10:
for (i = 1; i <= n; i++) {
if (jpvt[(i)- 1+ _jpvt_offset] != 0)  {
    if (i != itemp)  {
    Dswap.dswap(m,a,(1)- 1+(i- 1)*lda+ _a_offset,1,a,(1)- 1+(itemp- 1)*lda+ _a_offset,1);
jpvt[(i)- 1+ _jpvt_offset] = jpvt[(itemp)- 1+ _jpvt_offset];
jpvt[(itemp)- 1+ _jpvt_offset] = i;
}              // Close if()
else  {
  jpvt[(i)- 1+ _jpvt_offset] = i;
}              //  Close else.
itemp = itemp+1;
}              // Close if()
else  {
  jpvt[(i)- 1+ _jpvt_offset] = i;
}              //  Close else.
Dummy.label("Dgeqpf",10);
}              //  Close for() loop. 
}
itemp = itemp-1;
// *
// *     Compute the QR factorization and update remaining columns
// *
if (itemp > 0)  {
    ma = (int)(Math.min(itemp, m) );
Dgeqr2.dgeqr2(m,ma,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,info);
if (ma < n)  {
    Dorm2r.dorm2r("Left","Transpose",m,n-ma,ma,a,_a_offset,lda,tau,_tau_offset,a,(1)- 1+(ma+1- 1)*lda+ _a_offset,lda,work,_work_offset,info);
}              // Close if()
}              // Close if()
// *
if (itemp < mn)  {
    // *
// *        Initialize partial column norms. The first n elements of
// *        work store the exact column norms.
// *
{
forloop20:
for (i = itemp+1; i <= n; i++) {
work[(i)- 1+ _work_offset] = Dnrm2.dnrm2(m-itemp,a,(itemp+1)- 1+(i- 1)*lda+ _a_offset,1);
work[(n+i)- 1+ _work_offset] = work[(i)- 1+ _work_offset];
Dummy.label("Dgeqpf",20);
}              //  Close for() loop. 
}
// *
// *        Compute factorization
// *
{
forloop40:
for (i = itemp+1; i <= mn; i++) {
// *
// *           Determine ith pivot column and swap if necessary
// *
pvt = (i-1)+Idamax.idamax(n-i+1,work,(i)- 1+ _work_offset,1);
// *
if (pvt != i)  {
    Dswap.dswap(m,a,(1)- 1+(pvt- 1)*lda+ _a_offset,1,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
itemp = jpvt[(pvt)- 1+ _jpvt_offset];
jpvt[(pvt)- 1+ _jpvt_offset] = jpvt[(i)- 1+ _jpvt_offset];
jpvt[(i)- 1+ _jpvt_offset] = itemp;
work[(pvt)- 1+ _work_offset] = work[(i)- 1+ _work_offset];
work[(n+pvt)- 1+ _work_offset] = work[(n+i)- 1+ _work_offset];
}              // Close if()
// *
// *           Generate elementary reflector H(i)
// *
if (i < m)  {
    dlarfg_adapter(m-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,tau,(i)- 1+ _tau_offset);
}              // Close if()
else  {
  dlarfg_adapter(1,a,(m)- 1+(m- 1)*lda+ _a_offset,a,(m)- 1+(m- 1)*lda+ _a_offset,1,tau,(m)- 1+ _tau_offset);
}              //  Close else.
// *
if (i < n)  {
    // *
// *              Apply H(i) to A(i:m,i+1:n) from the left
// *
aii = a[(i)- 1+(i- 1)*lda+ _a_offset];
a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
Dlarf.dlarf("LEFT",m-i+1,n-i,a,(i)- 1+(i- 1)*lda+ _a_offset,1,tau[(i)- 1+ _tau_offset],a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,work,(2*n+1)- 1+ _work_offset);
a[(i)- 1+(i- 1)*lda+ _a_offset] = aii;
}              // Close if()
// *
// *           Update partial column norms
// *
{
forloop30:
for (j = i+1; j <= n; j++) {
if (work[(j)- 1+ _work_offset] != zero)  {
    temp = one-Math.pow((Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])/work[(j)- 1+ _work_offset]), 2);
temp = Math.max(temp, zero) ;
temp2 = one+0.05e0*temp*Math.pow((work[(j)- 1+ _work_offset]/work[(n+j)- 1+ _work_offset]), 2);
if (temp2 == one)  {
    if (m-i > 0)  {
    work[(j)- 1+ _work_offset] = Dnrm2.dnrm2(m-i,a,(i+1)- 1+(j- 1)*lda+ _a_offset,1);
work[(n+j)- 1+ _work_offset] = work[(j)- 1+ _work_offset];
}              // Close if()
else  {
  work[(j)- 1+ _work_offset] = zero;
work[(n+j)- 1+ _work_offset] = zero;
}              //  Close else.
}              // Close if()
else  {
  work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]*Math.sqrt(temp);
}              //  Close else.
}              // Close if()
Dummy.label("Dgeqpf",30);
}              //  Close for() loop. 
}
// *
Dummy.label("Dgeqpf",40);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dgeqpf",999999);
// *
// *     End of DGEQPF
// *
Dummy.label("Dgeqpf",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
