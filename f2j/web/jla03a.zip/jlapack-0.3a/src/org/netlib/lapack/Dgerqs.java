/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgerqs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  Compute a minimum-norm solution
// *      min || A*X - B ||
// *  using the RQ factorization
// *      A = R*Q
// *  computed by DGERQF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= M >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of B.  NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the RQ factorization of the original matrix A as
// *          returned by DGERQF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= M.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (M)
// *          Details of the orthogonal matrix Q.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side vectors for the linear system.
// *          On exit, the solution vectors X.  Each solution vector
// *          is contained in rows 1:N of a column of B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK must be at least NRHS,
// *          and should be at least NRHS*NB, where NB is the block size
// *          for this environment.
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgerqs (int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0 || m > n)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -8;
}              // Close else if()
else if (lwork < 1 || lwork < nrhs && m > 0 && n > 0)  {
    info.val = -10;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGERQS",-info.val);
Dummy.go_to("Dgerqs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0 || m == 0)  
    Dummy.go_to("Dgerqs",999999);
// *
// *     Solve R*X = B(n-m+1:n,:)
// *
Dtrsm.dtrsm("Left","Upper","No transpose","Non-unit",m,nrhs,one,a,(1)- 1+(n-m+1- 1)*lda+ _a_offset,lda,b,(n-m+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *     Set B(1:n-m,:) to zero
// *
Dlaset.dlaset("Full",n-m,nrhs,zero,zero,b,_b_offset,ldb);
// *
// *     B := Q' * B
// *
Dormrq.dormrq("Left","Transpose",n,nrhs,m,a,_a_offset,lda,tau,_tau_offset,b,_b_offset,ldb,work,_work_offset,lwork,info);
// *
Dummy.go_to("Dgerqs",999999);
// *
// *     End of DGERQS
// *
Dummy.label("Dgerqs",999999);
return;
   }
} // End class.
