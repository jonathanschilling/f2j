/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgesv {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGESV computes the solution to a real system of linear equations
// *     A * X = B,
// *  where A is an N-by-N matrix and X and B are N-by-NRHS matrices.
// *
// *  The LU decomposition with partial pivoting and row interchanges is
// *  used to factor A as
// *     A = P * L * U,
// *  where P is a permutation matrix, L is unit lower triangular, and U is
// *  upper triangular.  The factored form of A is then used to solve the
// *  system of equations A * X = B.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of linear equations, i.e., the order of the
// *          matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the N-by-N coefficient matrix A.
// *          On exit, the factors L and U from the factorization
// *          A = P*L*U; the unit diagonal elements of L are not stored.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  IPIV    (output) INTEGER array, dimension (N)
// *          The pivot indices that define the permutation matrix P;
// *          row i of the matrix was interchanged with row IPIV(i).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the N-by-NRHS matrix of right hand side matrix B.
// *          On exit, if INFO = 0, the N-by-NRHS solution matrix X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, U(i,i) is exactly zero.  The factorization
// *                has been completed, but the factor U is exactly
// *                singular, so the solution could not be computed.
// *
// *  =====================================================================
// *
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgesv (int n,
int nrhs,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (nrhs < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGESV ",-info.val);
Dummy.go_to("Dgesv",999999);
}              // Close if()
// *
// *     Compute the LU factorization of A.
// *
Dgetrf.dgetrf(n,n,a,_a_offset,lda,ipiv,_ipiv_offset,info);
if (info.val == 0)  {
    // *
// *        Solve the system A*X = B, overwriting B with X.
// *
Dgetrs.dgetrs("No transpose",n,nrhs,a,_a_offset,lda,ipiv,_ipiv_offset,b,_b_offset,ldb,info);
}              // Close if()
Dummy.go_to("Dgesv",999999);
// *
// *     End of DGESV
// *
Dummy.label("Dgesv",999999);
return;
   }
} // End class.
