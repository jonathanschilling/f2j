/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgesvd {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGESVD computes the singular value decomposition (SVD) of a real
// *  M-by-N matrix A, optionally computing the left and/or right singular
// *  vectors. The SVD is written
// *
// *       A = U * SIGMA * transpose(V)
// *
// *  where SIGMA is an M-by-N matrix which is zero except for its
// *  min(m,n) diagonal elements, U is an M-by-M orthogonal matrix, and
// *  V is an N-by-N orthogonal matrix.  The diagonal elements of SIGMA
// *  are the singular values of A; they are real and non-negative, and
// *  are returned in descending order.  The first min(m,n) columns of
// *  U and V are the left and right singular vectors of A.
// *
// *  Note that the routine returns V**T, not V.
// *
// *  Arguments
// *  =========
// *
// *  JOBU    (input) CHARACTER*1
// *          Specifies options for computing all or part of the matrix U:
// *          = 'A':  all M columns of U are returned in array U:
// *          = 'S':  the first min(m,n) columns of U (the left singular
// *                  vectors) are returned in the array U;
// *          = 'O':  the first min(m,n) columns of U (the left singular
// *                  vectors) are overwritten on the array A;
// *          = 'N':  no columns of U (no left singular vectors) are
// *                  computed.
// *
// *  JOBVT   (input) CHARACTER*1
// *          Specifies options for computing all or part of the matrix
// *          V**T:
// *          = 'A':  all N rows of V**T are returned in the array VT;
// *          = 'S':  the first min(m,n) rows of V**T (the right singular
// *                  vectors) are returned in the array VT;
// *          = 'O':  the first min(m,n) rows of V**T (the right singular
// *                  vectors) are overwritten on the array A;
// *          = 'N':  no rows of V**T (no right singular vectors) are
// *                  computed.
// *
// *          JOBVT and JOBU cannot both be 'O'.
// *
// *  M       (input) INTEGER
// *          The number of rows of the input matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the input matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit,
// *          if JOBU = 'O',  A is overwritten with the first min(m,n)
// *                          columns of U (the left singular vectors,
// *                          stored columnwise);
// *          if JOBVT = 'O', A is overwritten with the first min(m,n)
// *                          rows of V**T (the right singular vectors,
// *                          stored rowwise);
// *          if JOBU .ne. 'O' and JOBVT .ne. 'O', the contents of A
// *                          are destroyed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  S       (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The singular values of A, sorted so that S(i) >= S(i+1).
// *
// *  U       (output) DOUBLE PRECISION array, dimension (LDU,UCOL)
// *          (LDU,M) if JOBU = 'A' or (LDU,min(M,N)) if JOBU = 'S'.
// *          If JOBU = 'A', U contains the M-by-M orthogonal matrix U;
// *          if JOBU = 'S', U contains the first min(m,n) columns of U
// *          (the left singular vectors, stored columnwise);
// *          if JOBU = 'N' or 'O', U is not referenced.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= 1; if
// *          JOBU = 'S' or 'A', LDU >= M.
// *
// *  VT      (output) DOUBLE PRECISION array, dimension (LDVT,N)
// *          If JOBVT = 'A', VT contains the N-by-N orthogonal matrix
// *          V**T;
// *          if JOBVT = 'S', VT contains the first min(m,n) rows of
// *          V**T (the right singular vectors, stored rowwise);
// *          if JOBVT = 'N' or 'O', VT is not referenced.
// *
// *  LDVT    (input) INTEGER
// *          The leading dimension of the array VT.  LDVT >= 1; if
// *          JOBVT = 'A', LDVT >= N; if JOBVT = 'S', LDVT >= min(M,N).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK;
// *          if INFO > 0, WORK(2:MIN(M,N)) contains the unconverged
// *          superdiagonal elements of an upper bidiagonal matrix B
// *          whose diagonal is in S (not necessarily sorted). B
// *          satisfies A = U * B * VT, so it has the same singular values
// *          as A, and singular vectors related by U and VT.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= 1.
// *          LWORK >= MAX(3*MIN(M,N)+MAX(M,N),5*MIN(M,N)-4).
// *          For good performance, LWORK should generally be larger.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if DBDSQR did not converge, INFO specifies how many
// *                superdiagonals of an intermediate bidiagonal form B
// *                did not converge to zero. See the description of WORK
// *                above for details.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean wntua= false;
static boolean wntuas= false;
static boolean wntun= false;
static boolean wntuo= false;
static boolean wntus= false;
static boolean wntva= false;
static boolean wntvas= false;
static boolean wntvn= false;
static boolean wntvo= false;
static boolean wntvs= false;
static int bdspac= 0;
static int blk= 0;
static int chunk= 0;
static int i= 0;
static int ie= 0;
static intW ierr= new intW(0);
static int ir= 0;
static int iscl= 0;
static int itau= 0;
static int itaup= 0;
static int itauq= 0;
static int iu= 0;
static int iwork= 0;
static int ldwrkr= 0;
static int ldwrku= 0;
static int maxwrk= 0;
static int minmn= 0;
static int minwrk= 0;
static int mnthr= 0;
static int ncu= 0;
static int ncvt= 0;
static int nru= 0;
static int nrvt= 0;
static int wrkbl= 0;
static double anrm= 0.0;
static double bignum= 0.0;
static double eps= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] dum= new double[(1)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dgesvd (String jobu,
String jobvt,
int m,
int n,
double [] a, int _a_offset,
int lda,
double [] s, int _s_offset,
double [] u, int _u_offset,
int ldu,
double [] vt, int _vt_offset,
int ldvt,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
minmn = (int)(Math.min(m, n) );
mnthr = Ilaenv.ilaenv(6,"DGESVD",jobu+jobvt,m,n,0,0);
wntua = (jobu.toLowerCase().charAt(0) == "A".toLowerCase().charAt(0));
wntus = (jobu.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0));
wntuas = wntua || wntus;
wntuo = (jobu.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0));
wntun = (jobu.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
wntva = (jobvt.toLowerCase().charAt(0) == "A".toLowerCase().charAt(0));
wntvs = (jobvt.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0));
wntvas = wntva || wntvs;
wntvo = (jobvt.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0));
wntvn = (jobvt.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
minwrk = 1;
// *
if (!(wntua || wntus || wntuo || wntun))  {
    info.val = -1;
}              // Close if()
else if (!(wntva || wntvs || wntvo || wntvn) || (wntvo && wntuo))  {
    info.val = -2;
}              // Close else if()
else if (m < 0)  {
    info.val = -3;
}              // Close else if()
else if (n < 0)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -6;
}              // Close else if()
else if (ldu < 1 || (wntuas && ldu < m))  {
    info.val = -9;
}              // Close else if()
else if (ldvt < 1 || (wntva && ldvt < n) || (wntvs && ldvt < minmn))  {
    info.val = -11;
}              // Close else if()
// *
// *     Compute workspace
// *      (Note: Comments in the code beginning "Workspace:" describe the
// *       minimal amount of workspace needed at that point in the code,
// *       as well as the preferred amount for good performance.
// *       NB refers to the optimal block size for the immediately
// *       following subroutine, as returned by ILAENV.)
// *
if (info.val == 0 && lwork >= 1 && m > 0 && n > 0)  {
    if (m >= n)  {
    // *
// *           Compute space needed for DBDSQR
// *
bdspac = (int)(Math.max(3*n, 5*n-4) );
if (m >= mnthr)  {
    if (wntun)  {
    // *
// *                 Path 1 (M much larger than N, JOBU='N')
// *
maxwrk = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
maxwrk = (int)(Math.max(maxwrk, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
if (wntvo || wntvas)  
    maxwrk = (int)(Math.max(maxwrk, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
minwrk = (int)(Math.max(4*n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close if()
else if (wntuo && wntvn)  {
    // *
// *                 Path 2 (M much larger than N, JOBU='O', JOBVT='N')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+n*Ilaenv.ilaenv(1,"DORGQR"," ",m,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = (int)(Math.max(n*n+wrkbl, n*n+m*n+n) );
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntuo && wntvas)  {
    // *
// *                 Path 3 (M much larger than N, JOBU='O', JOBVT='S' or
// *                 'A')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+n*Ilaenv.ilaenv(1,"DORGQR"," ",m,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = (int)(Math.max(n*n+wrkbl, n*n+m*n+n) );
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntus && wntvn)  {
    // *
// *                 Path 4 (M much larger than N, JOBU='S', JOBVT='N')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+n*Ilaenv.ilaenv(1,"DORGQR"," ",m,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntus && wntvo)  {
    // *
// *                 Path 5 (M much larger than N, JOBU='S', JOBVT='O')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+n*Ilaenv.ilaenv(1,"DORGQR"," ",m,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = 2*n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntus && wntvas)  {
    // *
// *                 Path 6 (M much larger than N, JOBU='S', JOBVT='S' or
// *                 'A')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+n*Ilaenv.ilaenv(1,"DORGQR"," ",m,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntua && wntvn)  {
    // *
// *                 Path 7 (M much larger than N, JOBU='A', JOBVT='N')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+m*Ilaenv.ilaenv(1,"DORGQR"," ",m,m,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntua && wntvo)  {
    // *
// *                 Path 8 (M much larger than N, JOBU='A', JOBVT='O')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+m*Ilaenv.ilaenv(1,"DORGQR"," ",m,m,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = 2*n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntua && wntvas)  {
    // *
// *                 Path 9 (M much larger than N, JOBU='A', JOBVT='S' or
// *                 'A')
// *
wrkbl = n+n*Ilaenv.ilaenv(1,"DGEQRF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, n+m*Ilaenv.ilaenv(1,"DORGQR"," ",m,m,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+2*n*Ilaenv.ilaenv(1,"DGEBRD"," ",n,n,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = n*n+wrkbl;
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
}              // Close if()
else  {
  // *
// *              Path 10 (M at least N, but not much larger)
// *
maxwrk = 3*n+(m+n)*Ilaenv.ilaenv(1,"DGEBRD"," ",m,n,-1,-1);
if (wntus || wntuo)  
    maxwrk = (int)(Math.max(maxwrk, 3*n+n*Ilaenv.ilaenv(1,"DORGBR","Q",m,n,n,-1)) );
if (wntua)  
    maxwrk = (int)(Math.max(maxwrk, 3*n+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,n,-1)) );
if (!wntvn)  
    maxwrk = (int)(Math.max(maxwrk, 3*n+(n-1)*Ilaenv.ilaenv(1,"DORGBR","P",n,n,n,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
minwrk = (int)(Math.max(3*n+m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              //  Close else.
}              // Close if()
else  {
  // *
// *           Compute space needed for DBDSQR
// *
bdspac = (int)(Math.max(3*m, 5*m-4) );
if (n >= mnthr)  {
    if (wntvn)  {
    // *
// *                 Path 1t(N much larger than M, JOBVT='N')
// *
maxwrk = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
maxwrk = (int)(Math.max(maxwrk, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
if (wntuo || wntuas)  
    maxwrk = (int)(Math.max(maxwrk, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
minwrk = (int)(Math.max(4*m, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close if()
else if (wntvo && wntun)  {
    // *
// *                 Path 2t(N much larger than M, JOBU='N', JOBVT='O')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+m*Ilaenv.ilaenv(1,"DORGLQ"," ",m,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = (int)(Math.max(m*m+wrkbl, m*m+m*n+m) );
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntvo && wntuas)  {
    // *
// *                 Path 3t(N much larger than M, JOBU='S' or 'A',
// *                 JOBVT='O')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+m*Ilaenv.ilaenv(1,"DORGLQ"," ",m,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = (int)(Math.max(m*m+wrkbl, m*m+m*n+m) );
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntvs && wntun)  {
    // *
// *                 Path 4t(N much larger than M, JOBU='N', JOBVT='S')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+m*Ilaenv.ilaenv(1,"DORGLQ"," ",m,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntvs && wntuo)  {
    // *
// *                 Path 5t(N much larger than M, JOBU='O', JOBVT='S')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+m*Ilaenv.ilaenv(1,"DORGLQ"," ",m,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = 2*m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntvs && wntuas)  {
    // *
// *                 Path 6t(N much larger than M, JOBU='S' or 'A',
// *                 JOBVT='S')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+m*Ilaenv.ilaenv(1,"DORGLQ"," ",m,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntva && wntun)  {
    // *
// *                 Path 7t(N much larger than M, JOBU='N', JOBVT='A')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+n*Ilaenv.ilaenv(1,"DORGLQ"," ",n,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntva && wntuo)  {
    // *
// *                 Path 8t(N much larger than M, JOBU='O', JOBVT='A')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+n*Ilaenv.ilaenv(1,"DORGLQ"," ",n,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = 2*m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
else if (wntva && wntuas)  {
    // *
// *                 Path 9t(N much larger than M, JOBU='S' or 'A',
// *                 JOBVT='A')
// *
wrkbl = m+m*Ilaenv.ilaenv(1,"DGELQF"," ",m,n,-1,-1);
wrkbl = (int)(Math.max(wrkbl, m+n*Ilaenv.ilaenv(1,"DORGLQ"," ",n,n,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+2*m*Ilaenv.ilaenv(1,"DGEBRD"," ",m,m,-1,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","P",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
wrkbl = (int)(Math.max(wrkbl, bdspac) );
maxwrk = m*m+wrkbl;
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              // Close else if()
}              // Close if()
else  {
  // *
// *              Path 10t(N greater than M, but not much larger)
// *
maxwrk = 3*m+(m+n)*Ilaenv.ilaenv(1,"DGEBRD"," ",m,n,-1,-1);
if (wntvs || wntvo)  
    maxwrk = (int)(Math.max(maxwrk, 3*m+m*Ilaenv.ilaenv(1,"DORGBR","P",m,n,m,-1)) );
if (wntva)  
    maxwrk = (int)(Math.max(maxwrk, 3*m+n*Ilaenv.ilaenv(1,"DORGBR","P",n,n,m,-1)) );
if (!wntun)  
    maxwrk = (int)(Math.max(maxwrk, 3*m+(m-1)*Ilaenv.ilaenv(1,"DORGBR","Q",m,m,m,-1)) );
maxwrk = (int)(Math.max(maxwrk, bdspac) );
minwrk = (int)(Math.max(3*m+n, bdspac) );
maxwrk = (int)(Math.max(maxwrk, minwrk) );
}              //  Close else.
}              //  Close else.
work[(1)- 1+ _work_offset] = (double)(maxwrk);
}              // Close if()
// *
if (lwork < minwrk)  {
    info.val = -13;
}              // Close if()
if (info.val != 0)  {
    Xerbla.xerbla("DGESVD",-info.val);
Dummy.go_to("Dgesvd",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  {
    if (lwork >= 1)  
    work[(1)- 1+ _work_offset] = one;
Dummy.go_to("Dgesvd",999999);
}              // Close if()
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("P");
smlnum = Math.sqrt(Dlamch.dlamch("S"))/eps;
bignum = one/smlnum;
// *
// *     Scale A if max element outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",m,n,a,_a_offset,lda,dum,0);
iscl = 0;
if (anrm > zero && anrm < smlnum)  {
    iscl = 1;
Dlascl.dlascl("G",0,0,anrm,smlnum,m,n,a,_a_offset,lda,ierr);
}              // Close if()
else if (anrm > bignum)  {
    iscl = 1;
Dlascl.dlascl("G",0,0,anrm,bignum,m,n,a,_a_offset,lda,ierr);
}              // Close else if()
// *
if (m >= n)  {
    // *
// *        A has at least as many rows as columns. If A has sufficiently
// *        more rows than columns, first reduce using the QR
// *        decomposition (if sufficient workspace available)
// *
if (m >= mnthr)  {
    // *
if (wntun)  {
    // *
// *              Path 1 (M much larger than N, JOBU='N')
// *              No left singular vectors to be computed
// *
itau = 1;
iwork = itau+n;
// *
// *              Compute A=Q*R
// *              (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *              Zero out below R
// *
Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
ie = 1;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *              Bidiagonalize R in A
// *              (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ncvt = 0;
if (wntvo || wntvas)  {
    // *
// *                 If right singular vectors desired, generate P'.
// *                 (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ncvt = n;
}              // Close if()
iwork = ie+n;
// *
// *              Perform bidiagonal QR iteration, computing right
// *              singular vectors of A in A if desired
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,ncvt,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *              If right singular vectors desired in VT, copy them there
// *
if (wntvas)  
    Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
}              // Close if()
else if (wntuo && wntvn)  {
    // *
// *              Path 2 (M much larger than N, JOBU='O', JOBVT='N')
// *              N left singular vectors to be overwritten on A and
// *              no right singular vectors to be computed
// *
if (lwork >= n*n+Math.max(4*n, bdspac) )  {
    // *
// *                 Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= Math.max(wrkbl, lda*n+n) +lda*n)  {
    // *
// *                    WORK(IU) is LDA by N, WORK(IR) is LDA by N
// *
ldwrku = lda;
ldwrkr = lda;
}              // Close if()
else if (lwork >= Math.max(wrkbl, lda*n+n) +n*n)  {
    // *
// *                    WORK(IU) is LDA by N, WORK(IR) is N by N
// *
ldwrku = lda;
ldwrkr = n;
}              // Close else if()
else  {
  // *
// *                    WORK(IU) is LDWRKU by N, WORK(IR) is N by N
// *
ldwrku = (lwork-n*n-n)/n;
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                 Compute A=Q*R
// *                 (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy R to WORK(IR) and zero out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(ir+1)- 1+ _work_offset,ldwrkr);
// *
// *                 Generate Q in A
// *                 (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                 Bidiagonalize R in WORK(IR)
// *                 (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate left vectors bidiagonalizing R
// *                 (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of R in WORK(IR)
// *                 (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
iu = ie+n;
// *
// *                 Multiply Q in A by left singular vectors of R in
// *                 WORK(IR), storing result in WORK(IU) and copying to A
// *                 (Workspace: need N*N+2*N, prefer N*N+M*N+N)
// *
{
int _i_inc = ldwrku;
forloop10:
for (i = 1; (_i_inc < 0) ? i >= m : i <= m; i += _i_inc) {
chunk = (int)(Math.min(m-i+1, ldwrku) );
Dgemm.dgemm("N","N",chunk,n,n,one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr,zero,work,(iu)- 1+ _work_offset,ldwrku);
Dlacpy.dlacpy("F",chunk,n,work,(iu)- 1+ _work_offset,ldwrku,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
Dummy.label("Dgesvd",10);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *                 Insufficient workspace for a fast algorithm
// *
ie = 1;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                 Bidiagonalize A
// *                 (Workspace: need 3*N+M, prefer 3*N+(M+N)*NB)
// *
Dgebrd.dgebrd(m,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate left vectors bidiagonalizing A
// *                 (Workspace: need 4*N, prefer 3*N+N*NB)
// *
Dorgbr.dorgbr("Q",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of A in A
// *                 (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntuo && wntvas)  {
    // *
// *              Path 3 (M much larger than N, JOBU='O', JOBVT='S' or 'A')
// *              N left singular vectors to be overwritten on A and
// *              N right singular vectors to be computed in VT
// *
if (lwork >= n*n+Math.max(4*n, bdspac) )  {
    // *
// *                 Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= Math.max(wrkbl, lda*n+n) +lda*n)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is LDA by N
// *
ldwrku = lda;
ldwrkr = lda;
}              // Close if()
else if (lwork >= Math.max(wrkbl, lda*n+n) +n*n)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is N by N
// *
ldwrku = lda;
ldwrkr = n;
}              // Close else if()
else  {
  // *
// *                    WORK(IU) is LDWRKU by N and WORK(IR) is N by N
// *
ldwrku = (lwork-n*n-n)/n;
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                 Compute A=Q*R
// *                 (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy R to VT, zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
Dlaset.dlaset("L",n-1,n-1,zero,zero,vt,(2)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
// *
// *                 Generate Q in A
// *                 (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                 Bidiagonalize R in VT, copying result to WORK(IR)
// *                 (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,vt,_vt_offset,ldvt,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",n,n,vt,_vt_offset,ldvt,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                 Generate left vectors bidiagonalizing R in WORK(IR)
// *                 (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate right vectors bidiagonalizing R in VT
// *                 (Workspace: need N*N+4*N-1, prefer N*N+3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of R in WORK(IR) and computing right
// *                 singular vectors of R in VT
// *                 (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
iu = ie+n;
// *
// *                 Multiply Q in A by left singular vectors of R in
// *                 WORK(IR), storing result in WORK(IU) and copying to A
// *                 (Workspace: need N*N+2*N, prefer N*N+M*N+N)
// *
{
int _i_inc = ldwrku;
forloop20:
for (i = 1; (_i_inc < 0) ? i >= m : i <= m; i += _i_inc) {
chunk = (int)(Math.min(m-i+1, ldwrku) );
Dgemm.dgemm("N","N",chunk,n,n,one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr,zero,work,(iu)- 1+ _work_offset,ldwrku);
Dlacpy.dlacpy("F",chunk,n,work,(iu)- 1+ _work_offset,ldwrku,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
Dummy.label("Dgesvd",20);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *                 Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                 Compute A=Q*R
// *                 (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy R to VT, zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
Dlaset.dlaset("L",n-1,n-1,zero,zero,vt,(2)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
// *
// *                 Generate Q in A
// *                 (Workspace: need 2*N, prefer N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                 Bidiagonalize R in VT
// *                 (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,vt,_vt_offset,ldvt,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Multiply Q in A by left vectors bidiagonalizing R
// *                 (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,vt,_vt_offset,ldvt,work,(itauq)- 1+ _work_offset,a,_a_offset,lda,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate right vectors bidiagonalizing R in VT
// *                 (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of A in A and computing right
// *                 singular vectors of A in VT
// *                 (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntus)  {
    // *
if (wntvn)  {
    // *
// *                 Path 4 (M much larger than N, JOBU='S', JOBVT='N')
// *                 N left singular vectors to be computed in U and
// *                 no right singular vectors to be computed
// *
if (lwork >= n*n+Math.max(4*n, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= wrkbl+lda*n)  {
    // *
// *                       WORK(IR) is LDA by N
// *
ldwrkr = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IR) is N by N
// *
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to WORK(IR), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(ir+1)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate Q in A
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IR)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left vectors bidiagonalizing R in WORK(IR)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IR)
// *                    (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in A by left singular vectors of R in
// *                    WORK(IR), storing result in U
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr,zero,u,_u_offset,ldu);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Zero out below R in A
// *
Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize R in A
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left vectors bidiagonalizing R
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close if()
else if (wntvo)  {
    // *
// *                 Path 5 (M much larger than N, JOBU='S', JOBVT='O')
// *                 N left singular vectors to be computed in U and
// *                 N right singular vectors to be overwritten on A
// *
if (lwork >= 2*n*n+Math.max(4*n, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+2*lda*n)  {
    // *
// *                       WORK(IU) is LDA by N and WORK(IR) is LDA by N
// *
ldwrku = lda;
ir = iu+ldwrku*n;
ldwrkr = lda;
}              // Close if()
else if (lwork >= wrkbl+(lda+n)*n)  {
    // *
// *                       WORK(IU) is LDA by N and WORK(IR) is N by N
// *
ldwrku = lda;
ir = iu+ldwrku*n;
ldwrkr = n;
}              // Close else if()
else  {
  // *
// *                       WORK(IU) is N by N and WORK(IR) is N by N
// *
ldwrku = n;
ir = iu+ldwrku*n;
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R
// *                    (Workspace: need 2*N*N+2*N, prefer 2*N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to WORK(IU), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(iu+1)- 1+ _work_offset,ldwrku);
// *
// *                    Generate Q in A
// *                    (Workspace: need 2*N*N+2*N, prefer 2*N*N+N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IU), copying result to
// *                    WORK(IR)
// *                    (Workspace: need 2*N*N+4*N,
// *                                prefer 2*N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need 2*N*N+4*N, prefer 2*N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need 2*N*N+4*N-1,
// *                                prefer 2*N*N+3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IU) and computing
// *                    right singular vectors of R in WORK(IR)
// *                    (Workspace: need 2*N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,work,(iu)- 1+ _work_offset,ldwrku,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in A by left singular vectors of R in
// *                    WORK(IU), storing result in U
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku,zero,u,_u_offset,ldu);
// *
// *                    Copy right singular vectors of R to A
// *                    (Workspace: need N*N)
// *
Dlacpy.dlacpy("F",n,n,work,(ir)- 1+ _work_offset,ldwrkr,a,_a_offset,lda);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Zero out below R in A
// *
Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize R in A
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left vectors bidiagonalizing R
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right vectors bidiagonalizing R in A
// *                    (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in A
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntvas)  {
    // *
// *                 Path 6 (M much larger than N, JOBU='S', JOBVT='S'
// *                         or 'A')
// *                 N left singular vectors to be computed in U and
// *                 N right singular vectors to be computed in VT
// *
if (lwork >= n*n+Math.max(4*n, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+lda*n)  {
    // *
// *                       WORK(IU) is LDA by N
// *
ldwrku = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IU) is N by N
// *
ldwrku = n;
}              //  Close else.
itau = iu+ldwrku*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to WORK(IU), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(iu+1)- 1+ _work_offset,ldwrku);
// *
// *                    Generate Q in A
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IU), copying result to VT
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",n,n,work,(iu)- 1+ _work_offset,ldwrku,vt,_vt_offset,ldvt);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in VT
// *                    (Workspace: need N*N+4*N-1,
// *                                prefer N*N+3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IU) and computing
// *                    right singular vectors of R in VT
// *                    (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iu)- 1+ _work_offset,ldwrku,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in A by left singular vectors of R in
// *                    WORK(IU), storing result in U
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku,zero,u,_u_offset,ldu);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dorgqr.dorgqr(m,n,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to VT, zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
Dlaset.dlaset("L",n-1,n-1,zero,zero,vt,(2)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in VT
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,vt,_vt_offset,ldvt,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left bidiagonalizing vectors
// *                    in VT
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,vt,_vt_offset,ldvt,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in VT
// *                    (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
// *
}              // Close else if()
else if (wntua)  {
    // *
if (wntvn)  {
    // *
// *                 Path 7 (M much larger than N, JOBU='A', JOBVT='N')
// *                 M left singular vectors to be computed in U and
// *                 no right singular vectors to be computed
// *
if (lwork >= n*n+Math.max((n+m) > (4*n) ? (n+m) : (4*n), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= wrkbl+lda*n)  {
    // *
// *                       WORK(IR) is LDA by N
// *
ldwrkr = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IR) is N by N
// *
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Copy R to WORK(IR), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(ir+1)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate Q in U
// *                    (Workspace: need N*N+N+M, prefer N*N+N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IR)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IR)
// *                    (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in U by left singular vectors of R in
// *                    WORK(IR), storing result in A
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,u,_u_offset,ldu,work,(ir)- 1+ _work_offset,ldwrkr,zero,a,_a_offset,lda);
// *
// *                    Copy left singular vectors of A from A to U
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need N+M, prefer N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Zero out below R in A
// *
Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize R in A
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left bidiagonalizing vectors
// *                    in A
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,0,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close if()
else if (wntvo)  {
    // *
// *                 Path 8 (M much larger than N, JOBU='A', JOBVT='O')
// *                 M left singular vectors to be computed in U and
// *                 N right singular vectors to be overwritten on A
// *
if (lwork >= 2*n*n+Math.max((n+m) > (4*n) ? (n+m) : (4*n), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+2*lda*n)  {
    // *
// *                       WORK(IU) is LDA by N and WORK(IR) is LDA by N
// *
ldwrku = lda;
ir = iu+ldwrku*n;
ldwrkr = lda;
}              // Close if()
else if (lwork >= wrkbl+(lda+n)*n)  {
    // *
// *                       WORK(IU) is LDA by N and WORK(IR) is N by N
// *
ldwrku = lda;
ir = iu+ldwrku*n;
ldwrkr = n;
}              // Close else if()
else  {
  // *
// *                       WORK(IU) is N by N and WORK(IR) is N by N
// *
ldwrku = n;
ir = iu+ldwrku*n;
ldwrkr = n;
}              //  Close else.
itau = ir+ldwrkr*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N*N+2*N, prefer 2*N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need 2*N*N+N+M, prefer 2*N*N+N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to WORK(IU), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(iu+1)- 1+ _work_offset,ldwrku);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IU), copying result to
// *                    WORK(IR)
// *                    (Workspace: need 2*N*N+4*N,
// *                                prefer 2*N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need 2*N*N+4*N, prefer 2*N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need 2*N*N+4*N-1,
// *                                prefer 2*N*N+3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IU) and computing
// *                    right singular vectors of R in WORK(IR)
// *                    (Workspace: need 2*N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,work,(iu)- 1+ _work_offset,ldwrku,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in U by left singular vectors of R in
// *                    WORK(IU), storing result in A
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,u,_u_offset,ldu,work,(iu)- 1+ _work_offset,ldwrku,zero,a,_a_offset,lda);
// *
// *                    Copy left singular vectors of A from A to U
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Copy right singular vectors of R from WORK(IR) to A
// *
Dlacpy.dlacpy("F",n,n,work,(ir)- 1+ _work_offset,ldwrkr,a,_a_offset,lda);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need N+M, prefer N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Zero out below R in A
// *
Dlaset.dlaset("L",n-1,n-1,zero,zero,a,(2)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize R in A
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left bidiagonalizing vectors
// *                    in A
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in A
// *                    (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in A
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntvas)  {
    // *
// *                 Path 9 (M much larger than N, JOBU='A', JOBVT='S'
// *                         or 'A')
// *                 M left singular vectors to be computed in U and
// *                 N right singular vectors to be computed in VT
// *
if (lwork >= n*n+Math.max((n+m) > (4*n) ? (n+m) : (4*n), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+lda*n)  {
    // *
// *                       WORK(IU) is LDA by N
// *
ldwrku = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IU) is N by N
// *
ldwrku = n;
}              //  Close else.
itau = iu+ldwrku*n;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need N*N+2*N, prefer N*N+N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need N*N+N+M, prefer N*N+N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R to WORK(IU), zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("L",n-1,n-1,zero,zero,work,(iu+1)- 1+ _work_offset,ldwrku);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in WORK(IU), copying result to VT
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",n,n,work,(iu)- 1+ _work_offset,ldwrku,vt,_vt_offset,ldvt);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need N*N+4*N, prefer N*N+3*N+N*NB)
// *
Dorgbr.dorgbr("Q",n,n,n,work,(iu)- 1+ _work_offset,ldwrku,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in VT
// *                    (Workspace: need N*N+4*N-1,
// *                                prefer N*N+3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of R in WORK(IU) and computing
// *                    right singular vectors of R in VT
// *                    (Workspace: need N*N+BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,n,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iu)- 1+ _work_offset,ldwrku,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply Q in U by left singular vectors of R in
// *                    WORK(IU), storing result in A
// *                    (Workspace: need N*N)
// *
Dgemm.dgemm("N","N",m,n,n,one,u,_u_offset,ldu,work,(iu)- 1+ _work_offset,ldwrku,zero,a,_a_offset,lda);
// *
// *                    Copy left singular vectors of A from A to U
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+n;
// *
// *                    Compute A=Q*R, copying result to U
// *                    (Workspace: need 2*N, prefer N+N*NB)
// *
Dgeqrf.dgeqrf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
// *
// *                    Generate Q in U
// *                    (Workspace: need N+M, prefer N+M*NB)
// *
Dorgqr.dorgqr(m,m,n,u,_u_offset,ldu,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy R from A to VT, zeroing out below it
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
Dlaset.dlaset("L",n-1,n-1,zero,zero,vt,(2)- 1+(1- 1)*ldvt+ _vt_offset,ldvt);
ie = itau;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *                    Bidiagonalize R in VT
// *                    (Workspace: need 4*N, prefer 3*N+2*N*NB)
// *
Dgebrd.dgebrd(n,n,vt,_vt_offset,ldvt,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply Q in U by left bidiagonalizing vectors
// *                    in VT
// *                    (Workspace: need 3*N+M, prefer 3*N+M*NB)
// *
Dormbr.dormbr("Q","R","N",m,n,n,vt,_vt_offset,ldvt,work,(itauq)- 1+ _work_offset,u,_u_offset,ldu,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in VT
// *                    (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+n;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
// *
}              // Close else if()
// *
}              // Close if()
else  {
  // *
// *           M .LT. MNTHR
// *
// *           Path 10 (M at least N, but not much larger)
// *           Reduce to bidiagonal form without QR decomposition
// *
ie = 1;
itauq = ie+n;
itaup = itauq+n;
iwork = itaup+n;
// *
// *           Bidiagonalize A
// *           (Workspace: need 3*N+M, prefer 3*N+(M+N)*NB)
// *
Dgebrd.dgebrd(m,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
if (wntuas)  {
    // *
// *              If left singular vectors desired in U, copy result to U
// *              and generate left bidiagonalizing vectors in U
// *              (Workspace: need 3*N+NCU, prefer 3*N+NCU*NB)
// *
Dlacpy.dlacpy("L",m,n,a,_a_offset,lda,u,_u_offset,ldu);
if (wntus)  
    ncu = n;
if (wntua)  
    ncu = m;
Dorgbr.dorgbr("Q",m,ncu,n,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntvas)  {
    // *
// *              If right singular vectors desired in VT, copy result to
// *              VT and generate right bidiagonalizing vectors in VT
// *              (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
Dorgbr.dorgbr("P",n,n,n,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntuo)  {
    // *
// *              If left singular vectors desired in A, generate left
// *              bidiagonalizing vectors in A
// *              (Workspace: need 4*N, prefer 3*N+N*NB)
// *
Dorgbr.dorgbr("Q",m,n,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntvo)  {
    // *
// *              If right singular vectors desired in A, generate right
// *              bidiagonalizing vectors in A
// *              (Workspace: need 4*N-1, prefer 3*N+(N-1)*NB)
// *
Dorgbr.dorgbr("P",n,n,n,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
iwork = ie+n;
if (wntuas || wntuo)  
    nru = m;
if (wntun)  
    nru = 0;
if (wntvas || wntvo)  
    ncvt = n;
if (wntvn)  
    ncvt = 0;
if ((!wntuo) && (!wntvo))  {
    // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in U and computing right singular
// *              vectors in VT
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              // Close if()
else if ((!wntuo) && wntvo)  {
    // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in U and computing right singular
// *              vectors in A
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              // Close else if()
else  {
  // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in A and computing right singular
// *              vectors in VT
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",n,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              //  Close else.
// *
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *        A has more columns than rows. If A has sufficiently more
// *        columns than rows, first reduce using the LQ decomposition (if
// *        sufficient workspace available)
// *
if (n >= mnthr)  {
    // *
if (wntvn)  {
    // *
// *              Path 1t(N much larger than M, JOBVT='N')
// *              No right singular vectors to be computed
// *
itau = 1;
iwork = itau+m;
// *
// *              Compute A=L*Q
// *              (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *              Zero out above L
// *
Dlaset.dlaset("U",m-1,m-1,zero,zero,a,(1)- 1+(2- 1)*lda+ _a_offset,lda);
ie = 1;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *              Bidiagonalize L in A
// *              (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
if (wntuo || wntuas)  {
    // *
// *                 If left singular vectors desired, generate Q
// *                 (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
iwork = ie+m;
nru = 0;
if (wntuo || wntuas)  
    nru = m;
// *
// *              Perform bidiagonal QR iteration, computing left singular
// *              vectors of A in A if desired
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,0,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,dum,0,1,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *              If left singular vectors desired in U, copy them there
// *
if (wntuas)  
    Dlacpy.dlacpy("F",m,m,a,_a_offset,lda,u,_u_offset,ldu);
// *
}              // Close if()
else if (wntvo && wntun)  {
    // *
// *              Path 2t(N much larger than M, JOBU='N', JOBVT='O')
// *              M right singular vectors to be overwritten on A and
// *              no left singular vectors to be computed
// *
if (lwork >= m*m+Math.max(4*m, bdspac) )  {
    // *
// *                 Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= Math.max(wrkbl, lda*n+m) +lda*m)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is LDA by M
// *
ldwrku = lda;
chunk = n;
ldwrkr = lda;
}              // Close if()
else if (lwork >= Math.max(wrkbl, lda*n+m) +m*m)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is M by M
// *
ldwrku = lda;
chunk = n;
ldwrkr = m;
}              // Close else if()
else  {
  // *
// *                    WORK(IU) is M by CHUNK and WORK(IR) is M by M
// *
ldwrku = m;
chunk = (lwork-m*m-m)/m;
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                 Compute A=L*Q
// *                 (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy L to WORK(IR) and zero out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(ir+ldwrkr)- 1+ _work_offset,ldwrkr);
// *
// *                 Generate Q in A
// *                 (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                 Bidiagonalize L in WORK(IR)
// *                 (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate right vectors bidiagonalizing L
// *                 (Workspace: need M*M+4*M-1, prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                 Perform bidiagonal QR iteration, computing right
// *                 singular vectors of L in WORK(IR)
// *                 (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
iu = ie+m;
// *
// *                 Multiply right singular vectors of L in WORK(IR) by Q
// *                 in A, storing result in WORK(IU) and copying to A
// *                 (Workspace: need M*M+2*M, prefer M*M+M*N+M)
// *
{
int _i_inc = chunk;
forloop30:
for (i = 1; (_i_inc < 0) ? i >= n : i <= n; i += _i_inc) {
blk = (int)(Math.min(n-i+1, chunk) );
Dgemm.dgemm("N","N",m,blk,m,one,work,(ir)- 1+ _work_offset,ldwrkr,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,zero,work,(iu)- 1+ _work_offset,ldwrku);
Dlacpy.dlacpy("F",m,blk,work,(iu)- 1+ _work_offset,ldwrku,a,(1)- 1+(i- 1)*lda+ _a_offset,lda);
Dummy.label("Dgesvd",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *                 Insufficient workspace for a fast algorithm
// *
ie = 1;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                 Bidiagonalize A
// *                 (Workspace: need 3*M+N, prefer 3*M+(M+N)*NB)
// *
Dgebrd.dgebrd(m,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate right vectors bidiagonalizing A
// *                 (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("P",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                 Perform bidiagonal QR iteration, computing right
// *                 singular vectors of A in A
// *                 (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("L",m,n,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntvo && wntuas)  {
    // *
// *              Path 3t(N much larger than M, JOBU='S' or 'A', JOBVT='O')
// *              M right singular vectors to be overwritten on A and
// *              M left singular vectors to be computed in U
// *
if (lwork >= m*m+Math.max(4*m, bdspac) )  {
    // *
// *                 Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= Math.max(wrkbl, lda*n+m) +lda*m)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is LDA by M
// *
ldwrku = lda;
chunk = n;
ldwrkr = lda;
}              // Close if()
else if (lwork >= Math.max(wrkbl, lda*n+m) +m*m)  {
    // *
// *                    WORK(IU) is LDA by N and WORK(IR) is M by M
// *
ldwrku = lda;
chunk = n;
ldwrkr = m;
}              // Close else if()
else  {
  // *
// *                    WORK(IU) is M by CHUNK and WORK(IR) is M by M
// *
ldwrku = m;
chunk = (lwork-m*m-m)/m;
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                 Compute A=L*Q
// *                 (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy L to U, zeroing about above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,u,_u_offset,ldu);
Dlaset.dlaset("U",m-1,m-1,zero,zero,u,(1)- 1+(2- 1)*ldu+ _u_offset,ldu);
// *
// *                 Generate Q in A
// *                 (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                 Bidiagonalize L in U, copying result to WORK(IR)
// *                 (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,u,_u_offset,ldu,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,m,u,_u_offset,ldu,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                 Generate right vectors bidiagonalizing L in WORK(IR)
// *                 (Workspace: need M*M+4*M-1, prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate left vectors bidiagonalizing L in U
// *                 (Workspace: need M*M+4*M, prefer M*M+3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of L in U, and computing right
// *                 singular vectors of L in WORK(IR)
// *                 (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
iu = ie+m;
// *
// *                 Multiply right singular vectors of L in WORK(IR) by Q
// *                 in A, storing result in WORK(IU) and copying to A
// *                 (Workspace: need M*M+2*M, prefer M*M+M*N+M))
// *
{
int _i_inc = chunk;
forloop40:
for (i = 1; (_i_inc < 0) ? i >= n : i <= n; i += _i_inc) {
blk = (int)(Math.min(n-i+1, chunk) );
Dgemm.dgemm("N","N",m,blk,m,one,work,(ir)- 1+ _work_offset,ldwrkr,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,zero,work,(iu)- 1+ _work_offset,ldwrku);
Dlacpy.dlacpy("F",m,blk,work,(iu)- 1+ _work_offset,ldwrku,a,(1)- 1+(i- 1)*lda+ _a_offset,lda);
Dummy.label("Dgesvd",40);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *                 Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                 Compute A=L*Q
// *                 (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Copy L to U, zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,u,_u_offset,ldu);
Dlaset.dlaset("U",m-1,m-1,zero,zero,u,(1)- 1+(2- 1)*ldu+ _u_offset,ldu);
// *
// *                 Generate Q in A
// *                 (Workspace: need 2*M, prefer M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                 Bidiagonalize L in U
// *                 (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,u,_u_offset,ldu,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Multiply right vectors bidiagonalizing L by Q in A
// *                 (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,u,_u_offset,ldu,work,(itaup)- 1+ _work_offset,a,_a_offset,lda,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                 Generate left vectors bidiagonalizing L in U
// *                 (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                 Perform bidiagonal QR iteration, computing left
// *                 singular vectors of A in U and computing right
// *                 singular vectors of A in A
// *                 (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntvs)  {
    // *
if (wntun)  {
    // *
// *                 Path 4t(N much larger than M, JOBU='N', JOBVT='S')
// *                 M right singular vectors to be computed in VT and
// *                 no left singular vectors to be computed
// *
if (lwork >= m*m+Math.max(4*m, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= wrkbl+lda*m)  {
    // *
// *                       WORK(IR) is LDA by M
// *
ldwrkr = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IR) is M by M
// *
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to WORK(IR), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(ir+ldwrkr)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate Q in A
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IR)
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right vectors bidiagonalizing L in
// *                    WORK(IR)
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing right
// *                    singular vectors of L in WORK(IR)
// *                    (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IR) by
// *                    Q in A, storing result in VT
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(ir)- 1+ _work_offset,ldwrkr,a,_a_offset,lda,zero,vt,_vt_offset,ldvt);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy result to VT
// *
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dorglq.dorglq(m,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Zero out above L in A
// *
Dlaset.dlaset("U",m-1,m-1,zero,zero,a,(1)- 1+(2- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize L in A
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right vectors bidiagonalizing L by Q in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close if()
else if (wntuo)  {
    // *
// *                 Path 5t(N much larger than M, JOBU='O', JOBVT='S')
// *                 M right singular vectors to be computed in VT and
// *                 M left singular vectors to be overwritten on A
// *
if (lwork >= 2*m*m+Math.max(4*m, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+2*lda*m)  {
    // *
// *                       WORK(IU) is LDA by M and WORK(IR) is LDA by M
// *
ldwrku = lda;
ir = iu+ldwrku*m;
ldwrkr = lda;
}              // Close if()
else if (lwork >= wrkbl+(lda+m)*m)  {
    // *
// *                       WORK(IU) is LDA by M and WORK(IR) is M by M
// *
ldwrku = lda;
ir = iu+ldwrku*m;
ldwrkr = m;
}              // Close else if()
else  {
  // *
// *                       WORK(IU) is M by M and WORK(IR) is M by M
// *
ldwrku = m;
ir = iu+ldwrku*m;
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q
// *                    (Workspace: need 2*M*M+2*M, prefer 2*M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to WORK(IU), zeroing out below it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(iu+ldwrku)- 1+ _work_offset,ldwrku);
// *
// *                    Generate Q in A
// *                    (Workspace: need 2*M*M+2*M, prefer 2*M*M+M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IU), copying result to
// *                    WORK(IR)
// *                    (Workspace: need 2*M*M+4*M,
// *                                prefer 2*M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need 2*M*M+4*M-1,
// *                                prefer 2*M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need 2*M*M+4*M, prefer 2*M*M+3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of L in WORK(IR) and computing
// *                    right singular vectors of L in WORK(IU)
// *                    (Workspace: need 2*M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IU) by
// *                    Q in A, storing result in VT
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(iu)- 1+ _work_offset,ldwrku,a,_a_offset,lda,zero,vt,_vt_offset,ldvt);
// *
// *                    Copy left singular vectors of L to A
// *                    (Workspace: need M*M)
// *
Dlacpy.dlacpy("F",m,m,work,(ir)- 1+ _work_offset,ldwrkr,a,_a_offset,lda);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dorglq.dorglq(m,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Zero out above L in A
// *
Dlaset.dlaset("U",m-1,m-1,zero,zero,a,(1)- 1+(2- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize L in A
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right vectors bidiagonalizing L by Q in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors of L in A
// *                    (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, compute left
// *                    singular vectors of A in A and compute right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntuas)  {
    // *
// *                 Path 6t(N much larger than M, JOBU='S' or 'A',
// *                         JOBVT='S')
// *                 M right singular vectors to be computed in VT and
// *                 M left singular vectors to be computed in U
// *
if (lwork >= m*m+Math.max(4*m, bdspac) )  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+lda*m)  {
    // *
// *                       WORK(IU) is LDA by N
// *
ldwrku = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IU) is LDA by M
// *
ldwrku = m;
}              //  Close else.
itau = iu+ldwrku*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to WORK(IU), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(iu+ldwrku)- 1+ _work_offset,ldwrku);
// *
// *                    Generate Q in A
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dorglq.dorglq(m,n,m,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IU), copying result to U
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,m,work,(iu)- 1+ _work_offset,ldwrku,u,_u_offset,ldu);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need M*M+4*M-1,
// *                                prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in U
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of L in U and computing right
// *                    singular vectors of L in WORK(IU)
// *                    (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(iu)- 1+ _work_offset,ldwrku,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IU) by
// *                    Q in A, storing result in VT
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(iu)- 1+ _work_offset,ldwrku,a,_a_offset,lda,zero,vt,_vt_offset,ldvt);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dorglq.dorglq(m,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to U, zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,u,_u_offset,ldu);
Dlaset.dlaset("U",m-1,m-1,zero,zero,u,(1)- 1+(2- 1)*ldu+ _u_offset,ldu);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in U
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,u,_u_offset,ldu,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right bidiagonalizing vectors in U by Q
// *                    in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,u,_u_offset,ldu,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in U
// *                    (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
// *
}              // Close else if()
else if (wntva)  {
    // *
if (wntun)  {
    // *
// *                 Path 7t(N much larger than M, JOBU='N', JOBVT='A')
// *                 N right singular vectors to be computed in VT and
// *                 no left singular vectors to be computed
// *
if (lwork >= m*m+Math.max((n+m) > (4*m) ? (n+m) : (4*m), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
ir = 1;
if (lwork >= wrkbl+lda*m)  {
    // *
// *                       WORK(IR) is LDA by M
// *
ldwrkr = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IR) is M by M
// *
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Copy L to WORK(IR), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(ir)- 1+ _work_offset,ldwrkr);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(ir+ldwrkr)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate Q in VT
// *                    (Workspace: need M*M+M+N, prefer M*M+M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IR)
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(ir)- 1+ _work_offset,ldwrkr,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need M*M+4*M-1,
// *                                prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing right
// *                    singular vectors of L in WORK(IR)
// *                    (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IR) by
// *                    Q in VT, storing result in A
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(ir)- 1+ _work_offset,ldwrkr,vt,_vt_offset,ldvt,zero,a,_a_offset,lda);
// *
// *                    Copy right singular vectors of A from A to VT
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need M+N, prefer M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Zero out above L in A
// *
Dlaset.dlaset("U",m-1,m-1,zero,zero,a,(1)- 1+(2- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize L in A
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right bidiagonalizing vectors in A by Q
// *                    in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,0,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,dum,0,1,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close if()
else if (wntuo)  {
    // *
// *                 Path 8t(N much larger than M, JOBU='O', JOBVT='A')
// *                 N right singular vectors to be computed in VT and
// *                 M left singular vectors to be overwritten on A
// *
if (lwork >= 2*m*m+Math.max((n+m) > (4*m) ? (n+m) : (4*m), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+2*lda*m)  {
    // *
// *                       WORK(IU) is LDA by M and WORK(IR) is LDA by M
// *
ldwrku = lda;
ir = iu+ldwrku*m;
ldwrkr = lda;
}              // Close if()
else if (lwork >= wrkbl+(lda+m)*m)  {
    // *
// *                       WORK(IU) is LDA by M and WORK(IR) is M by M
// *
ldwrku = lda;
ir = iu+ldwrku*m;
ldwrkr = m;
}              // Close else if()
else  {
  // *
// *                       WORK(IU) is M by M and WORK(IR) is M by M
// *
ldwrku = m;
ir = iu+ldwrku*m;
ldwrkr = m;
}              //  Close else.
itau = ir+ldwrkr*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M*M+2*M, prefer 2*M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need 2*M*M+M+N, prefer 2*M*M+M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to WORK(IU), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(iu+ldwrku)- 1+ _work_offset,ldwrku);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IU), copying result to
// *                    WORK(IR)
// *                    (Workspace: need 2*M*M+4*M,
// *                                prefer 2*M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need 2*M*M+4*M-1,
// *                                prefer 2*M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in WORK(IR)
// *                    (Workspace: need 2*M*M+4*M, prefer 2*M*M+3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,work,(ir)- 1+ _work_offset,ldwrkr,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of L in WORK(IR) and computing
// *                    right singular vectors of L in WORK(IU)
// *                    (Workspace: need 2*M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(iu)- 1+ _work_offset,ldwrku,work,(ir)- 1+ _work_offset,ldwrkr,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IU) by
// *                    Q in VT, storing result in A
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(iu)- 1+ _work_offset,ldwrku,vt,_vt_offset,ldvt,zero,a,_a_offset,lda);
// *
// *                    Copy right singular vectors of A from A to VT
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Copy left singular vectors of A from WORK(IR) to A
// *
Dlacpy.dlacpy("F",m,m,work,(ir)- 1+ _work_offset,ldwrkr,a,_a_offset,lda);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need M+N, prefer M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Zero out above L in A
// *
Dlaset.dlaset("U",m-1,m-1,zero,zero,a,(1)- 1+(2- 1)*lda+ _a_offset,lda);
// *
// *                    Bidiagonalize L in A
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right bidiagonalizing vectors in A by Q
// *                    in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in A
// *                    (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in A and computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
else if (wntuas)  {
    // *
// *                 Path 9t(N much larger than M, JOBU='S' or 'A',
// *                         JOBVT='A')
// *                 N right singular vectors to be computed in VT and
// *                 M left singular vectors to be computed in U
// *
if (lwork >= m*m+Math.max((n+m) > (4*m) ? (n+m) : (4*m), bdspac))  {
    // *
// *                    Sufficient workspace for a fast algorithm
// *
iu = 1;
if (lwork >= wrkbl+lda*m)  {
    // *
// *                       WORK(IU) is LDA by M
// *
ldwrku = lda;
}              // Close if()
else  {
  // *
// *                       WORK(IU) is M by M
// *
ldwrku = m;
}              //  Close else.
itau = iu+ldwrku*m;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need M*M+2*M, prefer M*M+M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need M*M+M+N, prefer M*M+M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to WORK(IU), zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,work,(iu)- 1+ _work_offset,ldwrku);
Dlaset.dlaset("U",m-1,m-1,zero,zero,work,(iu+ldwrku)- 1+ _work_offset,ldwrku);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in WORK(IU), copying result to U
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,work,(iu)- 1+ _work_offset,ldwrku,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("L",m,m,work,(iu)- 1+ _work_offset,ldwrku,u,_u_offset,ldu);
// *
// *                    Generate right bidiagonalizing vectors in WORK(IU)
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("P",m,m,m,work,(iu)- 1+ _work_offset,ldwrku,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in U
// *                    (Workspace: need M*M+4*M, prefer M*M+3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of L in U and computing right
// *                    singular vectors of L in WORK(IU)
// *                    (Workspace: need M*M+BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,m,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,work,(iu)- 1+ _work_offset,ldwrku,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
// *                    Multiply right singular vectors of L in WORK(IU) by
// *                    Q in VT, storing result in A
// *                    (Workspace: need M*M)
// *
Dgemm.dgemm("N","N",m,n,m,one,work,(iu)- 1+ _work_offset,ldwrku,vt,_vt_offset,ldvt,zero,a,_a_offset,lda);
// *
// *                    Copy right singular vectors of A from A to VT
// *
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
}              // Close if()
else  {
  // *
// *                    Insufficient workspace for a fast algorithm
// *
itau = 1;
iwork = itau+m;
// *
// *                    Compute A=L*Q, copying result to VT
// *                    (Workspace: need 2*M, prefer M+M*NB)
// *
Dgelqf.dgelqf(m,n,a,_a_offset,lda,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
// *
// *                    Generate Q in VT
// *                    (Workspace: need M+N, prefer M+N*NB)
// *
Dorglq.dorglq(n,n,m,vt,_vt_offset,ldvt,work,(itau)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Copy L to U, zeroing out above it
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,u,_u_offset,ldu);
Dlaset.dlaset("U",m-1,m-1,zero,zero,u,(1)- 1+(2- 1)*ldu+ _u_offset,ldu);
ie = itau;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *                    Bidiagonalize L in U
// *                    (Workspace: need 4*M, prefer 3*M+2*M*NB)
// *
Dgebrd.dgebrd(m,m,u,_u_offset,ldu,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Multiply right bidiagonalizing vectors in U by Q
// *                    in VT
// *                    (Workspace: need 3*M+N, prefer 3*M+N*NB)
// *
Dormbr.dormbr("P","L","T",m,n,m,u,_u_offset,ldu,work,(itaup)- 1+ _work_offset,vt,_vt_offset,ldvt,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
// *
// *                    Generate left bidiagonalizing vectors in U
// *                    (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("Q",m,m,m,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
iwork = ie+m;
// *
// *                    Perform bidiagonal QR iteration, computing left
// *                    singular vectors of A in U and computing right
// *                    singular vectors of A in VT
// *                    (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("U",m,n,m,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
// *
}              //  Close else.
// *
}              // Close else if()
// *
}              // Close else if()
// *
}              // Close if()
else  {
  // *
// *           N .LT. MNTHR
// *
// *           Path 10t(N greater than M, but not much larger)
// *           Reduce to bidiagonal form without LQ decomposition
// *
ie = 1;
itauq = ie+m;
itaup = itauq+m;
iwork = itaup+m;
// *
// *           Bidiagonalize A
// *           (Workspace: need 3*M+N, prefer 3*M+(M+N)*NB)
// *
Dgebrd.dgebrd(m,n,a,_a_offset,lda,s,_s_offset,work,(ie)- 1+ _work_offset,work,(itauq)- 1+ _work_offset,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
if (wntuas)  {
    // *
// *              If left singular vectors desired in U, copy result to U
// *              and generate left bidiagonalizing vectors in U
// *              (Workspace: need 4*M-1, prefer 3*M+(M-1)*NB)
// *
Dlacpy.dlacpy("L",m,m,a,_a_offset,lda,u,_u_offset,ldu);
Dorgbr.dorgbr("Q",m,m,n,u,_u_offset,ldu,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntvas)  {
    // *
// *              If right singular vectors desired in VT, copy result to
// *              VT and generate right bidiagonalizing vectors in VT
// *              (Workspace: need 3*M+NRVT, prefer 3*M+NRVT*NB)
// *
Dlacpy.dlacpy("U",m,n,a,_a_offset,lda,vt,_vt_offset,ldvt);
if (wntva)  
    nrvt = n;
if (wntvs)  
    nrvt = m;
Dorgbr.dorgbr("P",nrvt,n,m,vt,_vt_offset,ldvt,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntuo)  {
    // *
// *              If left singular vectors desired in A, generate left
// *              bidiagonalizing vectors in A
// *              (Workspace: need 4*M-1, prefer 3*M+(M-1)*NB)
// *
Dorgbr.dorgbr("Q",m,m,n,a,_a_offset,lda,work,(itauq)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
if (wntvo)  {
    // *
// *              If right singular vectors desired in A, generate right
// *              bidiagonalizing vectors in A
// *              (Workspace: need 4*M, prefer 3*M+M*NB)
// *
Dorgbr.dorgbr("P",m,n,m,a,_a_offset,lda,work,(itaup)- 1+ _work_offset,work,(iwork)- 1+ _work_offset,lwork-iwork+1,ierr);
}              // Close if()
iwork = ie+m;
if (wntuas || wntuo)  
    nru = m;
if (wntun)  
    nru = 0;
if (wntvas || wntvo)  
    ncvt = n;
if (wntvn)  
    ncvt = 0;
if ((!wntuo) && (!wntvo))  {
    // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in U and computing right singular
// *              vectors in VT
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("L",m,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              // Close if()
else if ((!wntuo) && wntvo)  {
    // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in U and computing right singular
// *              vectors in A
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("L",m,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,a,_a_offset,lda,u,_u_offset,ldu,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              // Close else if()
else  {
  // *
// *              Perform bidiagonal QR iteration, if desired, computing
// *              left singular vectors in A and computing right singular
// *              vectors in VT
// *              (Workspace: need BDSPAC)
// *
Dbdsqr.dbdsqr("L",m,ncvt,nru,0,s,_s_offset,work,(ie)- 1+ _work_offset,vt,_vt_offset,ldvt,a,_a_offset,lda,dum,0,1,work,(iwork)- 1+ _work_offset,info);
}              //  Close else.
// *
}              //  Close else.
// *
}              //  Close else.
// *
// *     If DBDSQR failed to converge, copy unconverged superdiagonals
// *     to WORK( 2:MINMN )
// *
if (info.val != 0)  {
    if (ie > 2)  {
    {
forloop50:
for (i = 1; i <= minmn-1; i++) {
work[(i+1)- 1+ _work_offset] = work[(i+ie-1)- 1+ _work_offset];
Dummy.label("Dgesvd",50);
}              //  Close for() loop. 
}
}              // Close if()
if (ie < 2)  {
    {
int _i_inc = -1;
forloop60:
for (i = minmn-1; i >= 1; i += _i_inc) {
work[(i+1)- 1+ _work_offset] = work[(i+ie-1)- 1+ _work_offset];
Dummy.label("Dgesvd",60);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
// *     Undo scaling if necessary
// *
if (iscl == 1)  {
    if (anrm > bignum)  
    Dlascl.dlascl("G",0,0,bignum,anrm,minmn,1,s,_s_offset,minmn,ierr);
if (info.val != 0 && anrm > bignum)  
    Dlascl.dlascl("G",0,0,bignum,anrm,minmn-1,1,work,(2)- 1+ _work_offset,minmn,ierr);
if (anrm < smlnum)  
    Dlascl.dlascl("G",0,0,smlnum,anrm,minmn,1,s,_s_offset,minmn,ierr);
if (info.val != 0 && anrm < smlnum)  
    Dlascl.dlascl("G",0,0,smlnum,anrm,minmn-1,1,work,(2)- 1+ _work_offset,minmn,ierr);
}              // Close if()
// *
// *     Return optimal workspace in WORK(1)
// *
work[(1)- 1+ _work_offset] = (double)(maxwrk);
// *
Dummy.go_to("Dgesvd",999999);
// *
// *     End of DGESVD
// *
Dummy.label("Dgesvd",999999);
return;
   }
} // End class.
