/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgetf2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     June 30, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGETF2 computes an LU factorization of a general m-by-n matrix A
// *  using partial pivoting with row interchanges.
// *
// *  The factorization has the form
// *     A = P * L * U
// *  where P is a permutation matrix, L is lower triangular with unit
// *  diagonal elements (lower trapezoidal if m > n), and U is upper
// *  triangular (upper trapezoidal if m < n).
// *
// *  This is the right-looking Level 2 BLAS version of the algorithm.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the m by n matrix to be factored.
// *          On exit, the factors L and U from the factorization
// *          A = P*L*U; the unit diagonal elements of L are not stored.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  IPIV    (output) INTEGER array, dimension (min(M,N))
// *          The pivot indices; for 1 <= i <= min(M,N), row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *          > 0: if INFO = k, U(k,k) is exactly zero. The factorization
// *               has been completed, but the factor U is exactly
// *               singular, and division by zero will occur if it is used
// *               to solve a system of equations.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static int jp= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgetf2 (int m,
int n,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGETF2",-info.val);
Dummy.go_to("Dgetf2",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dgetf2",999999);
// *
{
forloop10:
for (j = 1; j <= Math.min(m, n) ; j++) {
// *
// *        Find pivot and test for singularity.
// *
jp = j-1+Idamax.idamax(m-j+1,a,(j)- 1+(j- 1)*lda+ _a_offset,1);
ipiv[(j)- 1+ _ipiv_offset] = jp;
if (a[(jp)- 1+(j- 1)*lda+ _a_offset] != zero)  {
    // *
// *           Apply the interchange to columns 1:N.
// *
if (jp != j)  
    Dswap.dswap(n,a,(j)- 1+(1- 1)*lda+ _a_offset,lda,a,(jp)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *           Compute elements J+1:M of J-th column.
// *
if (j < m)  
    Dscal.dscal(m-j,one/a[(j)- 1+(j- 1)*lda+ _a_offset],a,(j+1)- 1+(j- 1)*lda+ _a_offset,1);
// *
}              // Close if()
else if (info.val == 0)  {
    // *
info.val = j;
}              // Close else if()
// *
if (j < Math.min(m, n) )  {
    // *
// *           Update trailing submatrix.
// *
Dger.dger(m-j,n-j,-one,a,(j+1)- 1+(j- 1)*lda+ _a_offset,1,a,(j)- 1+(j+1- 1)*lda+ _a_offset,lda,a,(j+1)- 1+(j+1- 1)*lda+ _a_offset,lda);
}              // Close if()
Dummy.label("Dgetf2",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dgetf2",999999);
// *
// *     End of DGETF2
// *
Dummy.label("Dgetf2",999999);
return;
   }
} // End class.
