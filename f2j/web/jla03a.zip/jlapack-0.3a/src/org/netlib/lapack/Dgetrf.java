/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgetrf {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGETRF computes an LU factorization of a general M-by-N matrix A
// *  using partial pivoting with row interchanges.
// *
// *  The factorization has the form
// *     A = P * L * U
// *  where P is a permutation matrix, L is lower triangular with unit
// *  diagonal elements (lower trapezoidal if m > n), and U is upper
// *  triangular (upper trapezoidal if m < n).
// *
// *  This is the right-looking Level 3 BLAS version of the algorithm.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix to be factored.
// *          On exit, the factors L and U from the factorization
// *          A = P*L*U; the unit diagonal elements of L are not stored.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  IPIV    (output) INTEGER array, dimension (min(M,N))
// *          The pivot indices; for 1 <= i <= min(M,N), row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, U(i,i) is exactly zero. The factorization
// *                has been completed, but the factor U is exactly
// *                singular, and division by zero will occur if it is used
// *                to solve a system of equations.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW iinfo= new intW(0);
static int j= 0;
static int jb= 0;
static int nb= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgetrf (int m,
int n,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGETRF",-info.val);
Dummy.go_to("Dgetrf",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dgetrf",999999);
// *
// *     Determine the block size for this environment.
// *
nb = Ilaenv.ilaenv(1,"DGETRF"," ",m,n,-1,-1);
if (nb <= 1 || nb >= Math.min(m, n) )  {
    // *
// *        Use unblocked code.
// *
Dgetf2.dgetf2(m,n,a,_a_offset,lda,ipiv,_ipiv_offset,info);
}              // Close if()
else  {
  // *
// *        Use blocked code.
// *
{
int _j_inc = nb;
forloop20:
for (j = 1; (_j_inc < 0) ? j >= Math.min(m, n)  : j <= Math.min(m, n) ; j += _j_inc) {
jb = (int)(Math.min(Math.min(m, n) -j+1, nb) );
// *
// *           Factor diagonal and subdiagonal blocks and test for exact
// *           singularity.
// *
Dgetf2.dgetf2(m-j+1,jb,a,(j)- 1+(j- 1)*lda+ _a_offset,lda,ipiv,(j)- 1+ _ipiv_offset,iinfo);
// *
// *           Adjust INFO and the pivot indices.
// *
if (info.val == 0 && iinfo.val > 0)  
    info.val = iinfo.val+j-1;
{
forloop10:
for (i = j; i <= Math.min(m, j+jb-1) ; i++) {
ipiv[(i)- 1+ _ipiv_offset] = j-1+ipiv[(i)- 1+ _ipiv_offset];
Dummy.label("Dgetrf",10);
}              //  Close for() loop. 
}
// *
// *           Apply interchanges to columns 1:J-1.
// *
Dlaswp.dlaswp(j-1,a,_a_offset,lda,j,j+jb-1,ipiv,_ipiv_offset,1);
// *
if (j+jb <= n)  {
    // *
// *              Apply interchanges to columns J+JB:N.
// *
Dlaswp.dlaswp(n-j-jb+1,a,(1)- 1+(j+jb- 1)*lda+ _a_offset,lda,j,j+jb-1,ipiv,_ipiv_offset,1);
// *
// *              Compute block row of U.
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Unit",jb,n-j-jb+1,one,a,(j)- 1+(j- 1)*lda+ _a_offset,lda,a,(j)- 1+(j+jb- 1)*lda+ _a_offset,lda);
if (j+jb <= m)  {
    // *
// *                 Update trailing submatrix.
// *
Dgemm.dgemm("No transpose","No transpose",m-j-jb+1,n-j-jb+1,jb,-one,a,(j+jb)- 1+(j- 1)*lda+ _a_offset,lda,a,(j)- 1+(j+jb- 1)*lda+ _a_offset,lda,one,a,(j+jb)- 1+(j+jb- 1)*lda+ _a_offset,lda);
}              // Close if()
}              // Close if()
Dummy.label("Dgetrf",20);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dgetrf",999999);
// *
// *     End of DGETRF
// *
Dummy.label("Dgetrf",999999);
return;
   }
} // End class.
