/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgetri {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGETRI computes the inverse of a matrix using the LU factorization
// *  computed by DGETRF.
// *
// *  This method inverts U and then computes inv(A) by solving the system
// *  inv(A)*L = inv(U) for inv(A).
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the factors L and U from the factorization
// *          A = P*L*U as computed by DGETRF.
// *          On exit, if INFO = 0, the inverse of the original matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DGETRF; for 1<=i<=N, row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO=0, then WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,N).
// *          For optimal performance LWORK >= N*NB, where NB is
// *          the optimal blocksize returned by ILAENV.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, U(i,i) is exactly zero; the matrix is
// *                singular and its inverse could not be computed.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int iws= 0;
static int j= 0;
static int jb= 0;
static int jj= 0;
static int jp= 0;
static int ldwork= 0;
static int nb= 0;
static int nbmin= 0;
static int nn= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgetri (int n,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
work[(1)- 1+ _work_offset] = Math.max(n, 1) ;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (lda < Math.max(1, n) )  {
    info.val = -3;
}              // Close else if()
else if (lwork < Math.max(1, n) )  {
    info.val = -6;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGETRI",-info.val);
Dummy.go_to("Dgetri",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dgetri",999999);
// *
// *     Form inv(U).  If INFO > 0 from DTRTRI, then U is singular,
// *     and the inverse is not computed.
// *
Dtrtri.dtrtri("Upper","Non-unit",n,a,_a_offset,lda,info);
if (info.val > 0)  
    Dummy.go_to("Dgetri",999999);
// *
// *     Determine the block size for this environment.
// *
nb = Ilaenv.ilaenv(1,"DGETRI"," ",n,-1,-1,-1);
nbmin = 2;
ldwork = n;
if (nb > 1 && nb < n)  {
    iws = (int)(Math.max(ldwork*nb, 1) );
if (lwork < iws)  {
    nb = lwork/ldwork;
nbmin = (int)(Math.max(2, Ilaenv.ilaenv(2,"DGETRI"," ",n,-1,-1,-1)) );
}              // Close if()
}              // Close if()
else  {
  iws = n;
}              //  Close else.
// *
// *     Solve the equation inv(A)*L = inv(U) for inv(A).
// *
if (nb < nbmin || nb >= n)  {
    // *
// *        Use unblocked code.
// *
{
int _j_inc = -1;
forloop20:
for (j = n; j >= 1; j += _j_inc) {
// *
// *           Copy current column of L to WORK and replace with zeros.
// *
{
forloop10:
for (i = j+1; i <= n; i++) {
work[(i)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dgetri",10);
}              //  Close for() loop. 
}
// *
// *           Compute current column of inv(A).
// *
if (j < n)  
    Dgemv.dgemv("No transpose",n,n-j,-one,a,(1)- 1+(j+1- 1)*lda+ _a_offset,lda,work,(j+1)- 1+ _work_offset,1,one,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dgetri",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Use blocked code.
// *
nn = ((n-1)/nb)*nb+1;
{
int _j_inc = -nb;
forloop50:
for (j = nn; (_j_inc < 0) ? j >= 1 : j <= 1; j += _j_inc) {
jb = (int)(Math.min(nb, n-j+1) );
// *
// *           Copy current block column of L to WORK and replace with
// *           zeros.
// *
{
forloop40:
for (jj = j; jj <= j+jb-1; jj++) {
{
forloop30:
for (i = jj+1; i <= n; i++) {
work[(i+(jj-j)*ldwork)- 1+ _work_offset] = a[(i)- 1+(jj- 1)*lda+ _a_offset];
a[(i)- 1+(jj- 1)*lda+ _a_offset] = zero;
Dummy.label("Dgetri",30);
}              //  Close for() loop. 
}
Dummy.label("Dgetri",40);
}              //  Close for() loop. 
}
// *
// *           Compute current block column of inv(A).
// *
if (j+jb <= n)  
    Dgemm.dgemm("No transpose","No transpose",n,jb,n-j-jb+1,-one,a,(1)- 1+(j+jb- 1)*lda+ _a_offset,lda,work,(j+jb)- 1+ _work_offset,ldwork,one,a,(1)- 1+(j- 1)*lda+ _a_offset,lda);
Dtrsm.dtrsm("Right","Lower","No transpose","Unit",n,jb,one,work,(j)- 1+ _work_offset,ldwork,a,(1)- 1+(j- 1)*lda+ _a_offset,lda);
Dummy.label("Dgetri",50);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Apply column interchanges.
// *
{
int _j_inc = -1;
forloop60:
for (j = n-1; j >= 1; j += _j_inc) {
jp = ipiv[(j)- 1+ _ipiv_offset];
if (jp != j)  
    Dswap.dswap(n,a,(1)- 1+(j- 1)*lda+ _a_offset,1,a,(1)- 1+(jp- 1)*lda+ _a_offset,1);
Dummy.label("Dgetri",60);
}              //  Close for() loop. 
}
// *
work[(1)- 1+ _work_offset] = (double)(iws);
Dummy.go_to("Dgetri",999999);
// *
// *     End of DGETRI
// *
Dummy.label("Dgetri",999999);
return;
   }
} // End class.
