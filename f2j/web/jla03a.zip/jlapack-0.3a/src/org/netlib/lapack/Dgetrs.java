/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgetrs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGETRS solves a system of linear equations
// *     A * X = B  or  A' * X = B
// *  with a general N-by-N matrix A using the LU factorization computed
// *  by DGETRF.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations:
// *          = 'N':  A * X = B  (No transpose)
// *          = 'T':  A'* X = B  (Transpose)
// *          = 'C':  A'* X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The factors L and U from the factorization A = P*L*U
// *          as computed by DGETRF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DGETRF; for 1<=i<=N, row i of the
// *          matrix was interchanged with row IPIV(i).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side matrix B.
// *          On exit, the solution matrix X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgetrs (String trans,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGETRS",-info.val);
Dummy.go_to("Dgetrs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0)  
    Dummy.go_to("Dgetrs",999999);
// *
if (notran)  {
    // *
// *        Solve A * X = B.
// *
// *        Apply row interchanges to the right hand sides.
// *
Dlaswp.dlaswp(nrhs,b,_b_offset,ldb,1,n,ipiv,_ipiv_offset,1);
// *
// *        Solve L*X = B, overwriting B with X.
// *
Dtrsm.dtrsm("Left","Lower","No transpose","Unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
// *        Solve U*X = B, overwriting B with X.
// *
Dtrsm.dtrsm("Left","Upper","No transpose","Non-unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
}              // Close if()
else  {
  // *
// *        Solve A' * X = B.
// *
// *        Solve U'*X = B, overwriting B with X.
// *
Dtrsm.dtrsm("Left","Upper","Transpose","Non-unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
// *        Solve L'*X = B, overwriting B with X.
// *
Dtrsm.dtrsm("Left","Lower","Transpose","Unit",n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
// *        Apply row interchanges to the solution vectors.
// *
Dlaswp.dlaswp(nrhs,b,_b_offset,ldb,1,n,ipiv,_ipiv_offset,-1);
}              //  Close else.
// *
Dummy.go_to("Dgetrs",999999);
// *
// *     End of DGETRS
// *
Dummy.label("Dgetrs",999999);
return;
   }
} // End class.
