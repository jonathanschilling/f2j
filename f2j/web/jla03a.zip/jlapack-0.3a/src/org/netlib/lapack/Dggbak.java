/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dggbak {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGBAK forms the right or left eigenvectors of a real generalized
// *  eigenvalue problem A*x = lambda*B*x, by backward transformation on
// *  the computed eigenvectors of the balanced pair of matrices output by
// *  DGGBAL.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          Specifies the type of backward transformation required:
// *          = 'N':  do nothing, return immediately;
// *          = 'P':  do backward transformation for permutation only;
// *          = 'S':  do backward transformation for scaling only;
// *          = 'B':  do backward transformations for both permutation and
// *                  scaling.
// *          JOB must be the same as the argument JOB supplied to DGGBAL.
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'R':  V contains right eigenvectors;
// *          = 'L':  V contains left eigenvectors.
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrix V.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          The integers ILO and IHI determined by DGGBAL.
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  LSCALE  (input) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutations and/or scaling factors applied
// *          to the left side of A and B, as returned by DGGBAL.
// *
// *  RSCALE  (input) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutations and/or scaling factors applied
// *          to the right side of A and B, as returned by DGGBAL.
// *
// *  M       (input) INTEGER
// *          The number of columns of the matrix V.  M >= 0.
// *
// *  V       (input/output) DOUBLE PRECISION array, dimension (LDV,M)
// *          On entry, the matrix of right or left eigenvectors to be
// *          transformed, as returned by DTGEVC.
// *          On exit, V is overwritten by the transformed eigenvectors.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the matrix V. LDV >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  See R.C. Ward, Balancing the generalized eigenvalue problem,
// *                 SIAM J. Sci. Stat. Comp. 2 (1981), 141-152.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean leftv= false;
static boolean rightv= false;
static int i= 0;
static int k= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dggbak (String job,
String side,
int n,
int ilo,
int ihi,
double [] lscale, int _lscale_offset,
double [] rscale, int _rscale_offset,
int m,
double [] v, int _v_offset,
int ldv,
intW info)  {

rightv = (side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0));
leftv = (side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0));
// *
info.val = 0;
if (!(job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!rightv && !leftv)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (ilo < 1)  {
    info.val = -4;
}              // Close else if()
else if (ihi < ilo || ihi > Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (m < 0)  {
    info.val = -6;
}              // Close else if()
else if (ldv < Math.max(1, n) )  {
    info.val = -10;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGBAK",-info.val);
Dummy.go_to("Dggbak",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dggbak",999999);
if (m == 0)  
    Dummy.go_to("Dggbak",999999);
if ((job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  
    Dummy.go_to("Dggbak",999999);
// *
if (ilo == ihi)  
    Dummy.go_to("Dggbak",30);
// *
// *     Backward balance
// *
if ((job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    // *
// *        Backward transformation on right eigenvectors
// *
if (rightv)  {
    {
forloop10:
for (i = ilo; i <= ihi; i++) {
Dscal.dscal(m,rscale[(i)- 1+ _rscale_offset],v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Backward transformation on left eigenvectors
// *
if (leftv)  {
    {
forloop20:
for (i = ilo; i <= ihi; i++) {
Dscal.dscal(m,lscale[(i)- 1+ _lscale_offset],v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",20);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
// *     Backward permutation
// *
label30:
   Dummy.label("Dggbak",30);
if ((job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) || (job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    // *
// *        Backward permutation on right eigenvectors
// *
if (rightv)  {
    if (ilo == 1)  
    Dummy.go_to("Dggbak",50);
// *
{
int _i_inc = -1;
forloop40:
for (i = ilo-1; i >= 1; i += _i_inc) {
k = (int)(rscale[(i)- 1+ _rscale_offset]);
if (k == i)  
    continue forloop40;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",40);
}              //  Close for() loop. 
}
// *
label50:
   Dummy.label("Dggbak",50);
if (ihi == n)  
    Dummy.go_to("Dggbak",70);
{
forloop60:
for (i = ihi+1; i <= n; i++) {
k = (int)(rscale[(i)- 1+ _rscale_offset]);
if (k == i)  
    continue forloop60;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",60);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Backward permutation on left eigenvectors
// *
label70:
   Dummy.label("Dggbak",70);
if (leftv)  {
    if (ilo == 1)  
    Dummy.go_to("Dggbak",90);
{
int _i_inc = -1;
forloop80:
for (i = ilo-1; i >= 1; i += _i_inc) {
k = (int)(lscale[(i)- 1+ _lscale_offset]);
if (k == i)  
    continue forloop80;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",80);
}              //  Close for() loop. 
}
// *
label90:
   Dummy.label("Dggbak",90);
if (ihi == n)  
    Dummy.go_to("Dggbak",110);
{
forloop100:
for (i = ihi+1; i <= n; i++) {
k = (int)(lscale[(i)- 1+ _lscale_offset]);
if (k == i)  
    continue forloop100;
Dswap.dswap(m,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(k)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dummy.label("Dggbak",100);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
label110:
   Dummy.label("Dggbak",110);
// *
Dummy.go_to("Dggbak",999999);
// *
// *     End of DGGBAK
// *
Dummy.label("Dggbak",999999);
return;
   }
} // End class.
