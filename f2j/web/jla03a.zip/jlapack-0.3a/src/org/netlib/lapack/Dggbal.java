/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dggbal {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGBAL balances a pair of general real matrices (A,B).  This
// *  involves, first, permuting A and B by similarity transformations to
// *  isolate eigenvalues in the first 1 to ILO$-$1 and last IHI+1 to N
// *  elements on the diagonal; and second, applying a diagonal similarity
// *  transformation to rows and columns ILO to IHI to make the rows
// *  and columns as close in norm as possible. Both steps are optional.
// *
// *  Balancing may reduce the 1-norm of the matrices, and improve the
// *  accuracy of the computed eigenvalues and/or eigenvectors in the
// *  generalized eigenvalue problem A*x = lambda*B*x.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          Specifies the operations to be performed on A and B:
// *          = 'N':  none:  simply set ILO = 1, IHI = N, LSCALE(I) = 1.0
// *                  and RSCALE(I) = 1.0 for i = 1,...,N.
// *          = 'P':  permute only;
// *          = 'S':  scale only;
// *          = 'B':  both permute and scale.
// *
// *  N       (input) INTEGER
// *          The order of the matrices A and B.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the input matrix A.
// *          On exit,  A is overwritten by the balanced matrix.
// *          If JOB = 'N', A is not referenced.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,N)
// *          On entry, the input matrix B.
// *          On exit,  B is overwritten by the balanced matrix.
// *          If JOB = 'N', B is not referenced.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,N).
// *
// *  ILO     (output) INTEGER
// *  IHI     (output) INTEGER
// *          ILO and IHI are set to integers such that on exit
// *          A(i,j) = 0 and B(i,j) = 0 if i > j and
// *          j = 1,...,ILO-1 or i = IHI+1,...,N.
// *          If JOB = 'N' or 'S', ILO = 1 and IHI = N.
// *
// *  LSCALE  (output) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutations and scaling factors applied
// *          to the left side of A and B.  If P(j) is the index of the
// *          row interchanged with row j, and D(j)
// *          is the scaling factor applied to row j, then
// *            LSCALE(j) = P(j)    for J = 1,...,ILO-1
// *                      = D(j)    for J = ILO,...,IHI
// *                      = P(j)    for J = IHI+1,...,N.
// *          The order in which the interchanges are made is N to IHI+1,
// *          then 1 to ILO-1.
// *
// *  RSCALE  (output) DOUBLE PRECISION array, dimension (N)
// *          Details of the permutations and scaling factors applied
// *          to the right side of A and B.  If P(j) is the index of the
// *          column interchanged with column j, and D(j)
// *          is the scaling factor applied to column j, then
// *            LSCALE(j) = P(j)    for J = 1,...,ILO-1
// *                      = D(j)    for J = ILO,...,IHI
// *                      = P(j)    for J = IHI+1,...,N.
// *          The order in which the interchanges are made is N to IHI+1,
// *          then 1 to ILO-1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (6*N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  See R.C. WARD, Balancing the generalized eigenvalue problem,
// *                 SIAM J. Sci. Stat. Comp. 2 (1981), 141-152.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double half= 0.5e+0;
static double one= 1.0e+0;
static double three= 3.0e+0;
static double sclfac= 1.0e+1;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int icab= 0;
static int iflow= 0;
static int ip1= 0;
static int ir= 0;
static int irab= 0;
static int it= 0;
static int j= 0;
static int jc= 0;
static int jp1= 0;
static int k= 0;
static int kount= 0;
static int l= 0;
static int lcab= 0;
static int lm1= 0;
static int lrab= 0;
static int lsfmax= 0;
static int lsfmin= 0;
static int m= 0;
static int nr= 0;
static int nrp2= 0;
static double alpha= 0.0;
static double basl= 0.0;
static double beta= 0.0;
static double cab= 0.0;
static double cmax= 0.0;
static double coef= 0.0;
static double coef2= 0.0;
static double coef5= 0.0;
static double cor= 0.0;
static double ew= 0.0;
static double ewc= 0.0;
static double gamma= 0.0;
static double pgamma= 0.0;
static double rab= 0.0;
static double sfmax= 0.0;
static double sfmin= 0.0;
static double sum= 0.0;
static double t= 0.0;
static double ta= 0.0;
static double tb= 0.0;
static double tc= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dggbal (String job,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
intW ilo,
intW ihi,
double [] lscale, int _lscale_offset,
double [] rscale, int _rscale_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (!(job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) && !(job.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGBAL",-info.val);
Dummy.go_to("Dggbal",999999);
}              // Close if()
// *
k = 1;
l = n;
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dggbal",999999);
// *
if ((job.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ilo.val = 1;
ihi.val = n;
{
forloop10:
for (i = 1; i <= n; i++) {
lscale[(i)- 1+ _lscale_offset] = one;
rscale[(i)- 1+ _rscale_offset] = one;
Dummy.label("Dggbal",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dggbal",999999);
}              // Close if()
// *
if (k == l)  {
    ilo.val = 1;
ihi.val = 1;
lscale[(1)- 1+ _lscale_offset] = one;
rscale[(1)- 1+ _rscale_offset] = one;
Dummy.go_to("Dggbal",999999);
}              // Close if()
// *
if ((job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  
    Dummy.go_to("Dggbal",190);
// *
Dummy.go_to("Dggbal",30);
// *
// *     Permute the matrices A and B to isolate the eigenvalues.
// *
// *     Find row with one nonzero in columns 1 through L
// *
label20:
   Dummy.label("Dggbal",20);
l = lm1;
if (l != 1)  
    Dummy.go_to("Dggbal",30);
// *
rscale[(1)- 1+ _rscale_offset] = (double)(1);
lscale[(1)- 1+ _lscale_offset] = (double)(1);
Dummy.go_to("Dggbal",190);
// *
label30:
   Dummy.label("Dggbal",30);
lm1 = l-1;
{
int _i_inc = -1;
forloop80:
for (i = l; i >= 1; i += _i_inc) {
{
forloop40:
for (j = 1; j <= lm1; j++) {
jp1 = j+1;
if (a[(i)- 1+(j- 1)*lda+ _a_offset] != zero || b[(i)- 1+(j- 1)*ldb+ _b_offset] != zero)  
    Dummy.go_to("Dggbal",50);
Dummy.label("Dggbal",40);
}              //  Close for() loop. 
}
j = l;
Dummy.go_to("Dggbal",70);
// *
label50:
   Dummy.label("Dggbal",50);
{
forloop60:
for (j = jp1; j <= l; j++) {
if (a[(i)- 1+(j- 1)*lda+ _a_offset] != zero || b[(i)- 1+(j- 1)*ldb+ _b_offset] != zero)  
    continue forloop80;
Dummy.label("Dggbal",60);
}              //  Close for() loop. 
}
j = jp1-1;
// *
label70:
   Dummy.label("Dggbal",70);
m = l;
iflow = 1;
Dummy.go_to("Dggbal",160);
Dummy.label("Dggbal",80);
}              //  Close for() loop. 
}
Dummy.go_to("Dggbal",100);
// *
// *     Find column with one nonzero in rows K through N
// *
label90:
   Dummy.label("Dggbal",90);
k = k+1;
// *
label100:
   Dummy.label("Dggbal",100);
{
forloop150:
for (j = k; j <= l; j++) {
{
forloop110:
for (i = k; i <= lm1; i++) {
ip1 = i+1;
if (a[(i)- 1+(j- 1)*lda+ _a_offset] != zero || b[(i)- 1+(j- 1)*ldb+ _b_offset] != zero)  
    Dummy.go_to("Dggbal",120);
Dummy.label("Dggbal",110);
}              //  Close for() loop. 
}
i = l;
Dummy.go_to("Dggbal",140);
label120:
   Dummy.label("Dggbal",120);
{
forloop130:
for (i = ip1; i <= l; i++) {
if (a[(i)- 1+(j- 1)*lda+ _a_offset] != zero || b[(i)- 1+(j- 1)*ldb+ _b_offset] != zero)  
    continue forloop150;
Dummy.label("Dggbal",130);
}              //  Close for() loop. 
}
i = ip1-1;
label140:
   Dummy.label("Dggbal",140);
m = k;
iflow = 2;
Dummy.go_to("Dggbal",160);
Dummy.label("Dggbal",150);
}              //  Close for() loop. 
}
Dummy.go_to("Dggbal",190);
// *
// *     Permute rows M and I
// *
label160:
   Dummy.label("Dggbal",160);
lscale[(m)- 1+ _lscale_offset] = (double)(i);
if (i == m)  
    Dummy.go_to("Dggbal",170);
Dswap.dswap(n-k+1,a,(i)- 1+(k- 1)*lda+ _a_offset,lda,a,(m)- 1+(k- 1)*lda+ _a_offset,lda);
Dswap.dswap(n-k+1,b,(i)- 1+(k- 1)*ldb+ _b_offset,ldb,b,(m)- 1+(k- 1)*ldb+ _b_offset,ldb);
// *
// *     Permute columns M and J
// *
label170:
   Dummy.label("Dggbal",170);
rscale[(m)- 1+ _rscale_offset] = (double)(j);
if (j == m)  
    Dummy.go_to("Dggbal",180);
Dswap.dswap(l,a,(1)- 1+(j- 1)*lda+ _a_offset,1,a,(1)- 1+(m- 1)*lda+ _a_offset,1);
Dswap.dswap(l,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,b,(1)- 1+(m- 1)*ldb+ _b_offset,1);
// *
label180:
   Dummy.label("Dggbal",180);
if (iflow == 1) 
  Dummy.go_to("Dggbal",20);
else if (iflow == 2) 
  Dummy.go_to("Dggbal",90);
// *
label190:
   Dummy.label("Dggbal",190);
ilo.val = k;
ihi.val = l;
// *
if (ilo.val == ihi.val)  
    Dummy.go_to("Dggbal",999999);
// *
if ((job.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)))  
    Dummy.go_to("Dggbal",999999);
// *
// *     Balance the submatrix in rows ILO to IHI.
// *
nr = ihi.val-ilo.val+1;
{
forloop200:
for (i = ilo.val; i <= ihi.val; i++) {
rscale[(i)- 1+ _rscale_offset] = zero;
lscale[(i)- 1+ _lscale_offset] = zero;
// *
work[(i)- 1+ _work_offset] = zero;
work[(i+n)- 1+ _work_offset] = zero;
work[(i+2*n)- 1+ _work_offset] = zero;
work[(i+3*n)- 1+ _work_offset] = zero;
work[(i+4*n)- 1+ _work_offset] = zero;
work[(i+5*n)- 1+ _work_offset] = zero;
Dummy.label("Dggbal",200);
}              //  Close for() loop. 
}
// *
// *     Compute right side vector in resulting linear equations
// *
basl = (Math.log(sclfac) / 2.30258509);
{
forloop240:
for (i = ilo.val; i <= ihi.val; i++) {
{
forloop230:
for (j = ilo.val; j <= ihi.val; j++) {
tb = b[(i)- 1+(j- 1)*ldb+ _b_offset];
ta = a[(i)- 1+(j- 1)*lda+ _a_offset];
if (ta == zero)  
    Dummy.go_to("Dggbal",210);
ta = (Math.log(Math.abs(ta)) / 2.30258509)/basl;
label210:
   Dummy.label("Dggbal",210);
if (tb == zero)  
    Dummy.go_to("Dggbal",220);
tb = (Math.log(Math.abs(tb)) / 2.30258509)/basl;
label220:
   Dummy.label("Dggbal",220);
work[(i+4*n)- 1+ _work_offset] = work[(i+4*n)- 1+ _work_offset]-ta-tb;
work[(j+5*n)- 1+ _work_offset] = work[(j+5*n)- 1+ _work_offset]-ta-tb;
Dummy.label("Dggbal",230);
}              //  Close for() loop. 
}
Dummy.label("Dggbal",240);
}              //  Close for() loop. 
}
// *
coef = one/(double)(2*nr);
coef2 = coef*coef;
coef5 = half*coef2;
nrp2 = nr+2;
beta = zero;
it = 1;
// *
// *     Start generalized conjugate gradient iteration
// *
label250:
   Dummy.label("Dggbal",250);
// *
gamma = Ddot.ddot(nr,work,(ilo.val+4*n)- 1+ _work_offset,1,work,(ilo.val+4*n)- 1+ _work_offset,1)+Ddot.ddot(nr,work,(ilo.val+5*n)- 1+ _work_offset,1,work,(ilo.val+5*n)- 1+ _work_offset,1);
// *
ew = zero;
ewc = zero;
{
forloop260:
for (i = ilo.val; i <= ihi.val; i++) {
ew = ew+work[(i+4*n)- 1+ _work_offset];
ewc = ewc+work[(i+5*n)- 1+ _work_offset];
Dummy.label("Dggbal",260);
}              //  Close for() loop. 
}
// *
gamma = coef*gamma-coef2*(Math.pow(ew, 2)+Math.pow(ewc, 2))-coef5*Math.pow((ew-ewc), 2);
if (gamma == zero)  
    Dummy.go_to("Dggbal",350);
if (it != 1)  
    beta = gamma/pgamma;
t = coef5*(ewc-three*ew);
tc = coef5*(ew-three*ewc);
// *
Dscal.dscal(nr,beta,work,(ilo.val)- 1+ _work_offset,1);
Dscal.dscal(nr,beta,work,(ilo.val+n)- 1+ _work_offset,1);
// *
Daxpy.daxpy(nr,coef,work,(ilo.val+4*n)- 1+ _work_offset,1,work,(ilo.val+n)- 1+ _work_offset,1);
Daxpy.daxpy(nr,coef,work,(ilo.val+5*n)- 1+ _work_offset,1,work,(ilo.val)- 1+ _work_offset,1);
// *
{
forloop270:
for (i = ilo.val; i <= ihi.val; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+tc;
work[(i+n)- 1+ _work_offset] = work[(i+n)- 1+ _work_offset]+t;
Dummy.label("Dggbal",270);
}              //  Close for() loop. 
}
// *
// *     Apply matrix to vector
// *
{
forloop300:
for (i = ilo.val; i <= ihi.val; i++) {
kount = 0;
sum = zero;
{
forloop290:
for (j = ilo.val; j <= ihi.val; j++) {
if (a[(i)- 1+(j- 1)*lda+ _a_offset] == zero)  
    Dummy.go_to("Dggbal",280);
kount = kount+1;
sum = sum+work[(j)- 1+ _work_offset];
label280:
   Dummy.label("Dggbal",280);
if (b[(i)- 1+(j- 1)*ldb+ _b_offset] == zero)  
    continue forloop290;
kount = kount+1;
sum = sum+work[(j)- 1+ _work_offset];
Dummy.label("Dggbal",290);
}              //  Close for() loop. 
}
work[(i+2*n)- 1+ _work_offset] = (double)(kount)*work[(i+n)- 1+ _work_offset]+sum;
Dummy.label("Dggbal",300);
}              //  Close for() loop. 
}
// *
{
forloop330:
for (j = ilo.val; j <= ihi.val; j++) {
kount = 0;
sum = zero;
{
forloop320:
for (i = ilo.val; i <= ihi.val; i++) {
if (a[(i)- 1+(j- 1)*lda+ _a_offset] == zero)  
    Dummy.go_to("Dggbal",310);
kount = kount+1;
sum = sum+work[(i+n)- 1+ _work_offset];
label310:
   Dummy.label("Dggbal",310);
if (b[(i)- 1+(j- 1)*ldb+ _b_offset] == zero)  
    continue forloop320;
kount = kount+1;
sum = sum+work[(i+n)- 1+ _work_offset];
Dummy.label("Dggbal",320);
}              //  Close for() loop. 
}
work[(j+3*n)- 1+ _work_offset] = (double)(kount)*work[(j)- 1+ _work_offset]+sum;
Dummy.label("Dggbal",330);
}              //  Close for() loop. 
}
// *
sum = Ddot.ddot(nr,work,(ilo.val+n)- 1+ _work_offset,1,work,(ilo.val+2*n)- 1+ _work_offset,1)+Ddot.ddot(nr,work,(ilo.val)- 1+ _work_offset,1,work,(ilo.val+3*n)- 1+ _work_offset,1);
alpha = gamma/sum;
// *
// *     Determine correction to current iteration
// *
cmax = zero;
{
forloop340:
for (i = ilo.val; i <= ihi.val; i++) {
cor = alpha*work[(i+n)- 1+ _work_offset];
if (Math.abs(cor) > cmax)  
    cmax = Math.abs(cor);
lscale[(i)- 1+ _lscale_offset] = lscale[(i)- 1+ _lscale_offset]+cor;
cor = alpha*work[(i)- 1+ _work_offset];
if (Math.abs(cor) > cmax)  
    cmax = Math.abs(cor);
rscale[(i)- 1+ _rscale_offset] = rscale[(i)- 1+ _rscale_offset]+cor;
Dummy.label("Dggbal",340);
}              //  Close for() loop. 
}
if (cmax < half)  
    Dummy.go_to("Dggbal",350);
// *
Daxpy.daxpy(nr,-alpha,work,(ilo.val+2*n)- 1+ _work_offset,1,work,(ilo.val+4*n)- 1+ _work_offset,1);
Daxpy.daxpy(nr,-alpha,work,(ilo.val+3*n)- 1+ _work_offset,1,work,(ilo.val+5*n)- 1+ _work_offset,1);
// *
pgamma = gamma;
it = it+1;
if (it <= nrp2)  
    Dummy.go_to("Dggbal",250);
// *
// *     End generalized conjugate gradient iteration
// *
label350:
   Dummy.label("Dggbal",350);
sfmin = Dlamch.dlamch("S");
sfmax = one/sfmin;
lsfmin = (int)((Math.log(sfmin) / 2.30258509)/basl+one);
lsfmax = (int)((Math.log(sfmax) / 2.30258509)/basl);
{
forloop360:
for (i = ilo.val; i <= ihi.val; i++) {
irab = Idamax.idamax(n-ilo.val+1,a,(i)- 1+(ilo.val- 1)*lda+ _a_offset,lda);
rab = Math.abs(a[(i)- 1+(irab+ilo.val-1- 1)*lda+ _a_offset]);
irab = Idamax.idamax(n-ilo.val+1,b,(i)- 1+(ilo.val- 1)*ldb+ _b_offset,lda);
rab = Math.max(rab, Math.abs(b[(i)- 1+(irab+ilo.val-1- 1)*ldb+ _b_offset])) ;
lrab = (int)((Math.log(rab+sfmin) / 2.30258509)/basl+one);
ir = (int)(lscale[(i)- 1+ _lscale_offset]+((lscale[(i)- 1+ _lscale_offset]) >= 0 ? Math.abs(half) : -Math.abs(half)));
ir = (int)(Math.min((Math.max(ir, lsfmin) ) < (lsfmax) ? (Math.max(ir, lsfmin) ) : (lsfmax), lsfmax-lrab));
lscale[(i)- 1+ _lscale_offset] = Math.pow(sclfac, ir);
icab = Idamax.idamax(ihi.val,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
cab = Math.abs(a[(icab)- 1+(i- 1)*lda+ _a_offset]);
icab = Idamax.idamax(ihi.val,b,(1)- 1+(i- 1)*ldb+ _b_offset,1);
cab = Math.max(cab, Math.abs(b[(icab)- 1+(i- 1)*ldb+ _b_offset])) ;
lcab = (int)((Math.log(cab+sfmin) / 2.30258509)/basl+one);
jc = (int)(rscale[(i)- 1+ _rscale_offset]+((rscale[(i)- 1+ _rscale_offset]) >= 0 ? Math.abs(half) : -Math.abs(half)));
jc = (int)(Math.min((Math.max(jc, lsfmin) ) < (lsfmax) ? (Math.max(jc, lsfmin) ) : (lsfmax), lsfmax-lcab));
rscale[(i)- 1+ _rscale_offset] = Math.pow(sclfac, jc);
Dummy.label("Dggbal",360);
}              //  Close for() loop. 
}
// *
// *     Row scaling of matrices A and B
// *
{
forloop370:
for (i = ilo.val; i <= ihi.val; i++) {
Dscal.dscal(n-ilo.val+1,lscale[(i)- 1+ _lscale_offset],a,(i)- 1+(ilo.val- 1)*lda+ _a_offset,lda);
Dscal.dscal(n-ilo.val+1,lscale[(i)- 1+ _lscale_offset],b,(i)- 1+(ilo.val- 1)*ldb+ _b_offset,ldb);
Dummy.label("Dggbal",370);
}              //  Close for() loop. 
}
// *
// *     Column scaling of matrices A and B
// *
{
forloop380:
for (j = ilo.val; j <= ihi.val; j++) {
Dscal.dscal(ihi.val,rscale[(j)- 1+ _rscale_offset],a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dscal.dscal(ihi.val,rscale[(j)- 1+ _rscale_offset],b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dggbal",380);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dggbal",999999);
// *
// *     End of DGGBAL
// *
Dummy.label("Dggbal",999999);
return;
   }
} // End class.
