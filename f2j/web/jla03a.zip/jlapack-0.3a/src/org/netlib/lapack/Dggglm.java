/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dggglm {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     November 14, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGGLM solves a general Gauss-Markov linear model (GLM) problem:
// *
// *          minimize || y ||_2   subject to   d = A*x + B*y
// *              x
// *
// *  where A is an N-by-M matrix, B is an N-by-P matrix, and d is a
// *  given N-vector. It is assumed that M <= N <= M+P, and
// *
// *             rank(A) = M    and    rank( A B ) = N.
// *
// *  Under these assumptions, the constrained equation is always
// *  consistent, and there is a unique solution x and a minimal 2-norm
// *  solution y, which is obtained using a generalized QR factorization
// *  of A and B.
// *
// *  In particular, if matrix B is square nonsingular, then the problem
// *  GLM is equivalent to the following weighted linear least squares
// *  problem
// *
// *               minimize || inv(B)*(d-A*x) ||_2
// *                   x
// *
// *  where inv(B) denotes the inverse of B.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices A and B.  N >= 0.
// *
// *  M       (input) INTEGER
// *          The number of columns of the matrix A.  0 <= M <= N.
// *
// *  P       (input) INTEGER
// *          The number of columns of the matrix B.  P >= N-M.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,M)
// *          On entry, the N-by-M matrix A.
// *          On exit, A is destroyed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,P)
// *          On entry, the N-by-P matrix B.
// *          On exit, B is destroyed.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,N).
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, D is the left hand side of the GLM equation.
// *          On exit, D is destroyed.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (M)
// *  Y       (output) DOUBLE PRECISION array, dimension (P)
// *          On exit, X and Y are the solutions of the GLM problem.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= max(1,N+M+P).
// *          For optimum performance, LWORK >= M+min(N,P)+max(N,P)*NB,
// *          where NB is an upper bound for the optimal blocksizes for
// *          DGEQRF, SGERQF, DORMQR and SORMRQ.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  ===================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int lopt= 0;
static int np= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dggglm (int n,
int m,
int p,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] d, int _d_offset,
double [] x, int _x_offset,
double [] y, int _y_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
np = (int)(Math.min(n, p) );
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (m < 0 || m > n)  {
    info.val = -2;
}              // Close else if()
else if (p < 0 || p < n-m)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (lwork < Math.max(1, n+m+p) )  {
    info.val = -12;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGGLM",-info.val);
Dummy.go_to("Dggglm",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dggglm",999999);
// *
// *     Compute the GQR factorization of matrices A and B:
// *
// *            Q'*A = ( R11 ) M,    Q'*B*Z' = ( T11   T12 ) M
// *                   (  0  ) N-M             (  0    T22 ) N-M
// *                      M                     M+P-N  N-M
// *
// *     where R11 and T22 are upper triangular, and Q and Z are
// *     orthogonal.
// *
Dggqrf.dggqrf(n,m,p,a,_a_offset,lda,work,_work_offset,b,_b_offset,ldb,work,(m+1)- 1+ _work_offset,work,(m+np+1)- 1+ _work_offset,lwork-m-np,info);
lopt = (int)(work[(m+np+1)- 1+ _work_offset]);
// *
// *     Update left-hand-side vector d = Q'*d = ( d1 ) M
// *                                             ( d2 ) N-M
// *
Dormqr.dormqr("Left","Transpose",n,1,m,a,_a_offset,lda,work,_work_offset,d,_d_offset,(int) ( Math.max(1, n) ),work,(m+np+1)- 1+ _work_offset,lwork-m-np,info);
lopt = (int)(Math.max(lopt, (int)(work[(m+np+1)- 1+ _work_offset])) );
// *
// *     Solve T22*y2 = d2 for y2
// *
Dtrsv.dtrsv("Upper","No transpose","Non unit",n-m,b,(m+1)- 1+(m+p-n+1- 1)*ldb+ _b_offset,ldb,d,(m+1)- 1+ _d_offset,1);
Dcopy.dcopy(n-m,d,(m+1)- 1+ _d_offset,1,y,(m+p-n+1)- 1+ _y_offset,1);
// *
// *     Set y1 = 0
// *
{
forloop10:
for (i = 1; i <= m+p-n; i++) {
y[(i)- 1+ _y_offset] = zero;
Dummy.label("Dggglm",10);
}              //  Close for() loop. 
}
// *
// *     Update d1 = d1 - T12*y2
// *
Dgemv.dgemv("No transpose",m,n-m,-one,b,(1)- 1+(m+p-n+1- 1)*ldb+ _b_offset,ldb,y,(m+p-n+1)- 1+ _y_offset,1,one,d,_d_offset,1);
// *
// *     Solve triangular system: R11*x = d1
// *
Dtrsv.dtrsv("Upper","No Transpose","Non unit",m,a,_a_offset,lda,d,_d_offset,1);
// *
// *     Copy D to X
// *
Dcopy.dcopy(m,d,_d_offset,1,x,_x_offset,1);
// *
// *     Backward transformation y = Z'*y
// *
Dormrq.dormrq("Left","Transpose",p,1,np,b,(int)((Math.max(1, n-p+1) )- 1+(1- 1)*ldb+ _b_offset),ldb,work,(m+1)- 1+ _work_offset,y,_y_offset,(int) ( Math.max(1, p) ),work,(m+np+1)- 1+ _work_offset,lwork-m-np,info);
work[(1)- 1+ _work_offset] = m+np+Math.max(lopt, (int)(work[(m+np+1)- 1+ _work_offset])) ;
// *
Dummy.go_to("Dggglm",999999);
// *
// *     End of DGGGLM
// *
Dummy.label("Dggglm",999999);
return;
   }
} // End class.
