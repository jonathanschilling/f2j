/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgghrd {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGHRD reduces a pair of real matrices (A,B) to generalized upper
// *  Hessenberg form using orthogonal transformations, where A is a
// *  general matrix and B is upper triangular:  Q' * A * Z = H and
// *  Q' * B * Z = T, where H is upper Hessenberg, T is upper triangular,
// *  and Q and Z are orthogonal, and ' means transpose.
// *
// *  The orthogonal matrices Q and Z are determined as products of Givens
// *  rotations.  They may either be formed explicitly, or they may be
// *  postmultiplied into input matrices Q1 and Z1, so that
// *
// *       Q1 * A * Z1' = (Q1*Q) * H * (Z1*Z)'
// *       Q1 * B * Z1' = (Q1*Q) * T * (Z1*Z)'
// *
// *  Arguments
// *  =========
// *
// *  COMPQ   (input) CHARACTER*1
// *          = 'N': do not compute Q;
// *          = 'I': Q is initialized to the unit matrix, and the
// *                 orthogonal matrix Q is returned;
// *          = 'V': Q must contain an orthogonal matrix Q1 on entry,
// *                 and the product Q1*Q is returned.
// *
// *  COMPZ   (input) CHARACTER*1
// *          = 'N': do not compute Z;
// *          = 'I': Z is initialized to the unit matrix, and the
// *                 orthogonal matrix Z is returned;
// *          = 'V': Z must contain an orthogonal matrix Z1 on entry,
// *                 and the product Z1*Z is returned.
// *
// *  N       (input) INTEGER
// *          The order of the matrices A and B.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          It is assumed that A is already upper triangular in rows and
// *          columns 1:ILO-1 and IHI+1:N.  ILO and IHI are normally set
// *          by a previous call to DGGBAL; otherwise they should be set
// *          to 1 and N respectively.
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          On entry, the N-by-N general matrix to be reduced.
// *          On exit, the upper triangle and the first subdiagonal of A
// *          are overwritten with the upper Hessenberg matrix H, and the
// *          rest is set to zero.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB, N)
// *          On entry, the N-by-N upper triangular matrix B.
// *          On exit, the upper triangular matrix T = Q' B Z.  The
// *          elements below the diagonal are set to zero.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  Q       (input/output) DOUBLE PRECISION array, dimension (LDQ, N)
// *          If COMPQ='N':  Q is not referenced.
// *          If COMPQ='I':  on entry, Q need not be set, and on exit it
// *                         contains the orthogonal matrix Q, where Q'
// *                         is the product of the Givens transformations
// *                         which are applied to A and B on the left.
// *          If COMPQ='V':  on entry, Q must contain an orthogonal matrix
// *                         Q1, and on exit this is overwritten by Q1*Q.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.
// *          LDQ >= N if COMPQ='V' or 'I'; LDQ >= 1 otherwise.
// *
// *  Z       (input/output) DOUBLE PRECISION array, dimension (LDZ, N)
// *          If COMPZ='N':  Z is not referenced.
// *          If COMPZ='I':  on entry, Z need not be set, and on exit it
// *                         contains the orthogonal matrix Z, which is
// *                         the product of the Givens transformations
// *                         which are applied to A and B on the right.
// *          If COMPZ='V':  on entry, Z must contain an orthogonal matrix
// *                         Z1, and on exit this is overwritten by Z1*Z.
// *
// *  LDZ     (input) INTEGER
// *          The leading dimension of the array Z.
// *          LDZ >= N if COMPZ='V' or 'I'; LDZ >= 1 otherwise.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  Further Details
// *  ===============
// *
// *  This routine reduces A to Hessenberg and B to triangular form by
// *  an unblocked reduction, as described in _Matrix_Computations_,
// *  by Golub and Van Loan (Johns Hopkins Press.)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean ilq= false;
static boolean ilz= false;
static int icompq= 0;
static int icompz= 0;
static int jcol= 0;
static int jrow= 0;
static doubleW c= new doubleW(0.0);
static doubleW s= new doubleW(0.0);
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode COMPQ
// *

public static void dgghrd (String compq,
String compz,
int n,
int ilo,
int ihi,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] q, int _q_offset,
int ldq,
double [] z, int _z_offset,
int ldz,
intW info)  {

if ((compq.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ilq = false;
icompq = 1;
}              // Close if()
else if ((compq.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ilq = true;
icompq = 2;
}              // Close else if()
else if ((compq.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    ilq = true;
icompq = 3;
}              // Close else if()
else  {
  icompq = 0;
}              //  Close else.
// *
// *     Decode COMPZ
// *
if ((compz.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ilz = false;
icompz = 1;
}              // Close if()
else if ((compz.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ilz = true;
icompz = 2;
}              // Close else if()
else if ((compz.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    ilz = true;
icompz = 3;
}              // Close else if()
else  {
  icompz = 0;
}              //  Close else.
// *
// *     Test the input parameters.
// *
info.val = 0;
if (icompq <= 0)  {
    info.val = -1;
}              // Close if()
else if (icompz <= 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (ilo < 1)  {
    info.val = -4;
}              // Close else if()
else if (ihi > n || ihi < ilo-1)  {
    info.val = -5;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -9;
}              // Close else if()
else if ((ilq && ldq < n) || ldq < 1)  {
    info.val = -11;
}              // Close else if()
else if ((ilz && ldz < n) || ldz < 1)  {
    info.val = -13;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGHRD",-info.val);
Dummy.go_to("Dgghrd",999999);
}              // Close if()
// *
// *     Initialize Q and Z if desired.
// *
if (icompq == 3)  
    Dlaset.dlaset("Full",n,n,zero,one,q,_q_offset,ldq);
if (icompz == 3)  
    Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldz);
// *
// *     Quick return if possible
// *
if (n <= 1)  
    Dummy.go_to("Dgghrd",999999);
// *
// *     Zero out lower triangle of B
// *
{
forloop20:
for (jcol = 1; jcol <= n-1; jcol++) {
{
forloop10:
for (jrow = jcol+1; jrow <= n; jrow++) {
b[(jrow)- 1+(jcol- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dgghrd",10);
}              //  Close for() loop. 
}
Dummy.label("Dgghrd",20);
}              //  Close for() loop. 
}
// *
// *     Reduce A and B
// *
{
forloop40:
for (jcol = ilo; jcol <= ihi-2; jcol++) {
// *
{
int _jrow_inc = -1;
forloop30:
for (jrow = ihi; jrow >= jcol+2; jrow += _jrow_inc) {
// *
// *           Step 1: rotate rows JROW-1, JROW to kill A(JROW,JCOL)
// *
temp = a[(jrow-1)- 1+(jcol- 1)*lda+ _a_offset];
dlartg_adapter(temp,a[(jrow)- 1+(jcol- 1)*lda+ _a_offset],c,s,a,(jrow-1)- 1+(jcol- 1)*lda+ _a_offset);
a[(jrow)- 1+(jcol- 1)*lda+ _a_offset] = zero;
Drot.drot(n-jcol,a,(jrow-1)- 1+(jcol+1- 1)*lda+ _a_offset,lda,a,(jrow)- 1+(jcol+1- 1)*lda+ _a_offset,lda,c.val,s.val);
Drot.drot(n+2-jrow,b,(jrow-1)- 1+(jrow-1- 1)*ldb+ _b_offset,ldb,b,(jrow)- 1+(jrow-1- 1)*ldb+ _b_offset,ldb,c.val,s.val);
if (ilq)  
    Drot.drot(n,q,(1)- 1+(jrow-1- 1)*ldq+ _q_offset,1,q,(1)- 1+(jrow- 1)*ldq+ _q_offset,1,c.val,s.val);
// *
// *           Step 2: rotate columns JROW, JROW-1 to kill B(JROW,JROW-1)
// *
temp = b[(jrow)- 1+(jrow- 1)*ldb+ _b_offset];
dlartg_adapter(temp,b[(jrow)- 1+(jrow-1- 1)*ldb+ _b_offset],c,s,b,(jrow)- 1+(jrow- 1)*ldb+ _b_offset);
b[(jrow)- 1+(jrow-1- 1)*ldb+ _b_offset] = zero;
Drot.drot(ihi,a,(1)- 1+(jrow- 1)*lda+ _a_offset,1,a,(1)- 1+(jrow-1- 1)*lda+ _a_offset,1,c.val,s.val);
Drot.drot(jrow-1,b,(1)- 1+(jrow- 1)*ldb+ _b_offset,1,b,(1)- 1+(jrow-1- 1)*ldb+ _b_offset,1,c.val,s.val);
if (ilz)  
    Drot.drot(n,z,(1)- 1+(jrow- 1)*ldz+ _z_offset,1,z,(1)- 1+(jrow-1- 1)*ldz+ _z_offset,1,c.val,s.val);
Dummy.label("Dgghrd",30);
}              //  Close for() loop. 
}
Dummy.label("Dgghrd",40);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgghrd",999999);
// *
// *     End of DGGHRD
// *
Dummy.label("Dgghrd",999999);
return;
   }
// adapter for dlartg
private static void dlartg_adapter(double arg0 ,double arg1 ,doubleW arg2 ,doubleW arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlartg.dlartg(arg0,arg1,arg2,arg3,_f2j_tmp4);

arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
