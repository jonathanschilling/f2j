/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgglse {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGLSE solves the linear equality-constrained least squares (LSE)
// *  problem:
// *
// *          minimize || c - A*x ||_2   subject to   B*x = d
// *
// *  where A is an M-by-N matrix, B is a P-by-N matrix, c is a given
// *  M-vector, and d is a given P-vector. It is assumed that
// *  P <= N <= M+P, and
// *
// *           rank(B) = P and  rank( ( A ) ) = N.
// *                                ( ( B ) )
// *
// *  These conditions ensure that the LSE problem has a unique solution,
// *  which is obtained using a GRQ factorization of the matrices B and A.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B. N >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B. 0 <= P <= N <= M+P.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, A is destroyed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,N)
// *          On entry, the P-by-N matrix B.
// *          On exit, B is destroyed.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,P).
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (M)
// *          On entry, C contains the right hand side vector for the
// *          least squares part of the LSE problem.
// *          On exit, the residual sum of squares for the solution
// *          is given by the sum of squares of elements N-P+1 to M of
// *          vector C.
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (P)
// *          On entry, D contains the right hand side vector for the
// *          constrained equation.
// *          On exit, D is destroyed.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (N)
// *          On exit, X is the solution of the LSE problem.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= max(1,M+N+P).
// *          For optimum performance LWORK >= P+min(M,N)+max(M,N)*NB,
// *          where NB is an upper bound for the optimal blocksizes for
// *          DGEQRF, SGERQF, DORMQR and SORMRQ.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int lopt= 0;
static int mn= 0;
static int nr= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dgglse (int m,
int n,
int p,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] c, int _c_offset,
double [] d, int _d_offset,
double [] x, int _x_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
mn = (int)(Math.min(m, n) );
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (p < 0 || p > n || p < n-m)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (ldb < Math.max(1, p) )  {
    info.val = -7;
}              // Close else if()
else if (lwork < Math.max(1, m+n+p) )  {
    info.val = -12;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGLSE",-info.val);
Dummy.go_to("Dgglse",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dgglse",999999);
// *
// *     Compute the GRQ factorization of matrices B and A:
// *
// *            B*Q' = (  0  T12 ) P   Z'*A*Q' = ( R11 R12 ) N-P
// *                     N-P  P                  (  0  R22 ) M+P-N
// *                                               N-P  P
// *
// *     where T12 and R11 are upper triangular, and Q and Z are
// *     orthogonal.
// *
Dggrqf.dggrqf(p,m,n,b,_b_offset,ldb,work,_work_offset,a,_a_offset,lda,work,(p+1)- 1+ _work_offset,work,(p+mn+1)- 1+ _work_offset,lwork-p-mn,info);
lopt = (int)(work[(p+mn+1)- 1+ _work_offset]);
// *
// *     Update c = Z'*c = ( c1 ) N-P
// *                       ( c2 ) M+P-N
// *
Dormqr.dormqr("Left","Transpose",m,1,mn,a,_a_offset,lda,work,(p+1)- 1+ _work_offset,c,_c_offset,(int) ( Math.max(1, m) ),work,(p+mn+1)- 1+ _work_offset,lwork-p-mn,info);
lopt = (int)(Math.max(lopt, (int)(work[(p+mn+1)- 1+ _work_offset])) );
// *
// *     Solve T12*x2 = d for x2
// *
Dtrsv.dtrsv("Upper","No transpose","Non unit",p,b,(1)- 1+(n-p+1- 1)*ldb+ _b_offset,ldb,d,_d_offset,1);
// *
// *     Update c1
// *
Dgemv.dgemv("No transpose",n-p,p,-one,a,(1)- 1+(n-p+1- 1)*lda+ _a_offset,lda,d,_d_offset,1,one,c,_c_offset,1);
// *
// *     Sovle R11*x1 = c1 for x1
// *
Dtrsv.dtrsv("Upper","No transpose","Non unit",n-p,a,_a_offset,lda,c,_c_offset,1);
// *
// *     Put the solutions in X
// *
Dcopy.dcopy(n-p,c,_c_offset,1,x,_x_offset,1);
Dcopy.dcopy(p,d,_d_offset,1,x,(n-p+1)- 1+ _x_offset,1);
// *
// *     Compute the residual vector:
// *
if (m < n)  {
    nr = m+p-n;
Dgemv.dgemv("No transpose",nr,n-m,-one,a,(n-p+1)- 1+(m+1- 1)*lda+ _a_offset,lda,d,(nr+1)- 1+ _d_offset,1,one,c,(n-p+1)- 1+ _c_offset,1);
}              // Close if()
else  {
  nr = p;
}              //  Close else.
Dtrmv.dtrmv("Upper","No transpose","Non unit",nr,a,(n-p+1)- 1+(n-p+1- 1)*lda+ _a_offset,lda,d,_d_offset,1);
Daxpy.daxpy(nr,-one,d,_d_offset,1,c,(n-p+1)- 1+ _c_offset,1);
// *
// *     Backward transformation x = Q'*x
// *
Dormrq.dormrq("Left","Transpose",n,1,p,b,_b_offset,ldb,work,(1)- 1+ _work_offset,x,_x_offset,n,work,(p+mn+1)- 1+ _work_offset,lwork-p-mn,info);
work[(1)- 1+ _work_offset] = p+mn+Math.max(lopt, (int)(work[(p+mn+1)- 1+ _work_offset])) ;
// *
Dummy.go_to("Dgglse",999999);
// *
// *     End of DGGLSE
// *
Dummy.label("Dgglse",999999);
return;
   }
} // End class.
