/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dggsvd {

// *
// *  -- LAPACK driver routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGSVD computes the generalized singular value decomposition (GSVD)
// *  of an M-by-N real matrix A and P-by-N real matrix B:
// *
// *      U'*A*Q = D1*( 0 R ),    V'*B*Q = D2*( 0 R )
// *
// *  where U, V and Q are orthogonal matrices, and Z' is the transpose
// *  of Z.  Let K+L = the effective numerical rank of the matrix (A',B')',
// *  then R is a K+L-by-K+L nonsingular upper triangular matrix, D1 and
// *  D2 are M-by-(K+L) and P-by-(K+L) "diagonal" matrices and of the
// *  following structures, respectively:
// *
// *  If M-K-L >= 0,
// *
// *                      K  L
// *         D1 =     K ( I  0 )
// *                  L ( 0  C )
// *              M-K-L ( 0  0 )
// *
// *                    K  L
// *         D2 =   L ( 0  S )
// *              P-L ( 0  0 )
// *
// *                  N-K-L  K    L
// *    ( 0 R ) = K (  0   R11  R12 )
// *              L (  0    0   R22 )
// *
// *  where
// *
// *    C = diag( ALPHA(K+1), ... , ALPHA(K+L) ),
// *    S = diag( BETA(K+1),  ... , BETA(K+L) ),
// *    C**2 + S**2 = I.
// *
// *    R is stored in A(1:K+L,N-K-L+1:N) on exit.
// *
// *  If M-K-L < 0,
// *
// *                    K M-K K+L-M
// *         D1 =   K ( I  0    0   )
// *              M-K ( 0  C    0   )
// *
// *                      K M-K K+L-M
// *         D2 =   M-K ( 0  S    0  )
// *              K+L-M ( 0  0    I  )
// *                P-L ( 0  0    0  )
// *
// *                     N-K-L  K   M-K  K+L-M
// *    ( 0 R ) =     K ( 0    R11  R12  R13  )
// *                M-K ( 0     0   R22  R23  )
// *              K+L-M ( 0     0    0   R33  )
// *
// *  where
// *
// *    C = diag( ALPHA(K+1), ... , ALPHA(M) ),
// *    S = diag( BETA(K+1),  ... , BETA(M) ),
// *    C**2 + S**2 = I.
// *
// *    (R11 R12 R13 ) is stored in A(1:M, N-K-L+1:N), and R33 is stored
// *    ( 0  R22 R23 )
// *    in B(M-K+1:L,N+M-K-L+1:N) on exit.
// *
// *  The routine computes C, S, R, and optionally the orthogonal
// *  transformation matrices U, V and Q.
// *
// *  In particular, if B is an N-by-N nonsingular matrix, then the GSVD of
// *  A and B implicitly gives the SVD of A*inv(B):
// *                       A*inv(B) = U*(D1*inv(D2))*V'.
// *  If ( A',B')' has orthonormal columns, then the GSVD of A and B is
// *  also equal to the CS decomposition of A and B. Furthermore, the GSVD
// *  can be used to derive the solution of the eigenvalue problem:
// *                       A'*A x = lambda* B'*B x.
// *  In some literature, the GSVD of A and B is presented in the form
// *                   U'*A*X = ( 0 D1 ),   V'*B*X = ( 0 D2 )
// *  where U and V are orthogonal and X is nonsingular, D1 and D2 are
// *  ``diagonal''.  The former GSVD form can be converted to the latter
// *  form by taking the nonsingular matrix X as
// *
// *                       X = Q*( I   0    )
// *                             ( 0 inv(R) ).
// *
// *  Arguments
// *  =========
// *
// *  JOBU    (input) CHARACTER*1
// *          = 'U':  Orthogonal matrix U is computed;
// *          = 'N':  U is not computed.
// *
// *  JOBV    (input) CHARACTER*1
// *          = 'V':  Orthogonal matrix V is computed;
// *          = 'N':  V is not computed.
// *
// *  JOBQ    (input) CHARACTER*1
// *          = 'Q':  Orthogonal matrix Q is computed;
// *          = 'N':  Q is not computed.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.  N >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B.  P >= 0.
// *
// *  K       (output) INTEGER
// *  L       (output) INTEGER
// *          On exit, K and L specify the dimension of the subblocks
// *          described in the Purpose section.
// *          K + L = effective numerical rank of (A',B')'.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, A contains the triangular matrix R, or part of R.
// *          See Purpose for details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,N)
// *          On entry, the P-by-N matrix B.
// *          On exit, B contains the triangular matrix R if M-K-L < 0.
// *          See Purpose for details.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDA >= max(1,P).
// *
// *  ALPHA   (output) DOUBLE PRECISION array, dimension (N)
// *  BETA    (output) DOUBLE PRECISION array, dimension (N)
// *          On exit, ALPHA and BETA contain the generalized singular
// *          value pairs of A and B;
// *            ALPHA(1:K) = 1,
// *            BETA(1:K)  = 0,
// *          and if M-K-L >= 0,
// *            ALPHA(K+1:K+L) = C,
// *            BETA(K+1:K+L)  = S,
// *          or if M-K-L < 0,
// *            ALPHA(K+1:M)=C, ALPHA(M+1:K+L)=0
// *            BETA(K+1:M) =S, BETA(M+1:K+L) =1
// *          and
// *            ALPHA(K+L+1:N) = 0
// *            BETA(K+L+1:N)  = 0
// *
// *  U       (output) DOUBLE PRECISION array, dimension (LDU,M)
// *          If JOBU = 'U', U contains the M-by-M orthogonal matrix U.
// *          If JOBU = 'N', U is not referenced.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U. LDU >= max(1,M) if
// *          JOBU = 'U'; LDU >= 1 otherwise.
// *
// *  V       (output) DOUBLE PRECISION array, dimension (LDV,P)
// *          If JOBV = 'V', V contains the P-by-P orthogonal matrix V.
// *          If JOBV = 'N', V is not referenced.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V. LDV >= max(1,P) if
// *          JOBV = 'V'; LDV >= 1 otherwise.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDQ,N)
// *          If JOBQ = 'Q', Q contains the N-by-N orthogonal matrix Q.
// *          If JOBQ = 'N', Q is not referenced.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q. LDQ >= max(1,N) if
// *          JOBQ = 'Q'; LDQ >= 1 otherwise.
// *
// *  WORK    (workspace) DOUBLE PRECISION array,
// *                      dimension (max(3*N,M,P)+N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output)INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = 1, the Jacobi-type procedure failed to
// *                converge.  For further details, see subroutine DTGSJA.
// *
// *  Internal Parameters
// *  ===================
// *
// *  TOLA    DOUBLE PRECISION
// *  TOLB    DOUBLE PRECISION
// *          TOLA and TOLB are the thresholds to determine the effective
// *          rank of (A',B')'. Generally, they are set to
// *                   TOLA = MAX(M,N)*norm(A)*MAZHEPS,
// *                   TOLB = MAX(P,N)*norm(B)*MAZHEPS.
// *          The size of TOLA and TOLB may affect the size of backward
// *          errors of the decomposition.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean wantq= false;
static boolean wantu= false;
static boolean wantv= false;
static intW ncycle= new intW(0);
static double anorm= 0.0;
static double bnorm= 0.0;
static double tola= 0.0;
static double tolb= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dggsvd (String jobu,
String jobv,
String jobq,
int m,
int n,
int p,
intW k,
intW l,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] alpha, int _alpha_offset,
double [] beta, int _beta_offset,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
int ldv,
double [] q, int _q_offset,
int ldq,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

wantu = (jobu.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
wantv = (jobv.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
wantq = (jobq.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0));
// *
info.val = 0;
if (!(wantu || (jobu.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -1;
}              // Close if()
else if (!(wantv || (jobv.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -2;
}              // Close else if()
else if (!(wantq || (jobq.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -3;
}              // Close else if()
else if (m < 0)  {
    info.val = -4;
}              // Close else if()
else if (n < 0)  {
    info.val = -5;
}              // Close else if()
else if (p < 0)  {
    info.val = -6;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -10;
}              // Close else if()
else if (ldb < Math.max(1, p) )  {
    info.val = -12;
}              // Close else if()
else if (ldu < 1 || (wantu && ldu < m))  {
    info.val = -16;
}              // Close else if()
else if (ldv < 1 || (wantv && ldv < p))  {
    info.val = -18;
}              // Close else if()
else if (ldq < 1 || (wantq && ldq < n))  {
    info.val = -20;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGSVD",-info.val);
Dummy.go_to("Dggsvd",999999);
}              // Close if()
// *
// *     Compute the Frobenius norm of matrices A and B
// *
anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,work,_work_offset);
bnorm = Dlange.dlange("1",p,n,b,_b_offset,ldb,work,_work_offset);
// *
// *     Get machine precision and set up threshold for determining
// *     the effective numerical rank of the matrices A and B.
// *
ulp = Dlamch.dlamch("Precision");
unfl = Dlamch.dlamch("Safe Minimum");
tola = Math.max(m, n) *Math.max(anorm, unfl) *ulp;
tolb = Math.max(p, n) *Math.max(bnorm, unfl) *ulp;
// *
// *     Preprocessing
// *
Dggsvp.dggsvp(jobu,jobv,jobq,m,p,n,a,_a_offset,lda,b,_b_offset,ldb,tola,tolb,k,l,u,_u_offset,ldu,v,_v_offset,ldv,q,_q_offset,ldq,iwork,_iwork_offset,work,_work_offset,work,(n+1)- 1+ _work_offset,info);
// *
// *     Compute the GSVD of two upper "triangular" matrices
// *
Dtgsja.dtgsja(jobu,jobv,jobq,m,p,n,k.val,l.val,a,_a_offset,lda,b,_b_offset,ldb,tola,tolb,alpha,_alpha_offset,beta,_beta_offset,u,_u_offset,ldu,v,_v_offset,ldv,q,_q_offset,ldq,work,_work_offset,ncycle,info);
// *
Dummy.go_to("Dggsvd",999999);
// *
// *     End of DGGSVD
// *
Dummy.label("Dggsvd",999999);
return;
   }
} // End class.
