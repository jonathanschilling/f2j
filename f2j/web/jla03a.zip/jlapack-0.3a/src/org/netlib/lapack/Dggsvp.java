/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dggsvp {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGGSVP computes orthogonal matrices U, V and Q such that
// *
// *                   N-K-L  K    L
// *   U'*A*Q =     K ( 0    A12  A13 )  if M-K-L >= 0;
// *                L ( 0     0   A23 )
// *            M-K-L ( 0     0    0  )
// *
// *                   N-K-L  K    L
// *          =     K ( 0    A12  A13 )  if M-K-L < 0;
// *              M-K ( 0     0   A23 )
// *
// *                 N-K-L  K    L
// *   V'*B*Q =   L ( 0     0   B13 )
// *            P-L ( 0     0    0  )
// *
// *  where the K-by-K matrix A12 and L-by-L matrix B13 are nonsingular
// *  upper triangular; A23 is L-by-L upper triangular if M-K-L >= 0,
// *  otherwise A23 is (M-K)-by-L upper trapezoidal.  K+L = the effective
// *  numerical rank of the (M+P)-by-N matrix (A',B')'.  Z' denotes the
// *  transpose of Z.
// *
// *  This decomposition is the preprocessing step for computing the
// *  Generalized Singular Value Decomposition (GSVD), see subroutine
// *  DGGSVD.
// *
// *  Arguments
// *  =========
// *
// *  JOBU    (input) CHARACTER*1
// *          = 'U':  Orthogonal matrix U is computed;
// *          = 'N':  U is not computed.
// *
// *  JOBV    (input) CHARACTER*1
// *          = 'V':  Orthogonal matrix V is computed;
// *          = 'N':  V is not computed.
// *
// *  JOBQ    (input) CHARACTER*1
// *          = 'Q':  Orthogonal matrix Q is computed;
// *          = 'N':  Q is not computed.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B.  P >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M-by-N matrix A.
// *          On exit, A contains the triangular (or trapezoidal) matrix
// *          described in the Purpose section.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,N)
// *          On entry, the P-by-N matrix B.
// *          On exit, B contains the triangular matrix described in
// *          the Purpose section.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B. LDB >= max(1,P).
// *
// *  TOLA    (input) DOUBLE PRECISION
// *  TOLB    (input) DOUBLE PRECISION
// *          TOLA and TOLB are the thresholds to determine the effective
// *          numerical rank of matrix B and a subblock of A. Generally,
// *          they are set to
// *             TOLA = MAX(M,N)*norm(A)*MAZHEPS,
// *             TOLB = MAX(P,N)*norm(B)*MAZHEPS.
// *          The size of TOLA and TOLB may affect the size of backward
// *          errors of the decomposition.
// *
// *  K       (output) INTEGER
// *  L       (output) INTEGER
// *          On exit, K and L specify the dimension of the subblocks
// *          described in Purpose.
// *          K + L = effective numerical rank of (A',B')'.
// *
// *  U       (output) DOUBLE PRECISION array, dimension (LDU,M)
// *          If JOBU = 'U', U contains the orthogonal matrix U.
// *          If JOBU = 'N', U is not referenced.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U. LDU >= max(1,M) if
// *          JOBU = 'U'; LDU >= 1 otherwise.
// *
// *  V       (output) DOUBLE PRECISION array, dimension (LDV,M)
// *          If JOBV = 'V', V contains the orthogonal matrix V.
// *          If JOBV = 'N', V is not referenced.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V. LDV >= max(1,P) if
// *          JOBV = 'V'; LDV >= 1 otherwise.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDQ,N)
// *          If JOBQ = 'Q', Q contains the orthogonal matrix Q.
// *          If JOBQ = 'N', Q is not referenced.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q. LDQ >= max(1,N) if
// *          JOBQ = 'Q'; LDQ >= 1 otherwise.
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  TAU     (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (max(3*N,M,P))
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *
// *  Further Details
// *  ===============
// *
// *  The subroutine uses LAPACK subroutine DGEQPF for the QR factorization
// *  with column pivoting to detect the effective numerical rank of the
// *  a matrix. It may be replaced by a better rank determination strategy.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean forwrd= false;
static boolean wantq= false;
static boolean wantu= false;
static boolean wantv= false;
static int i= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters
// *

public static void dggsvp (String jobu,
String jobv,
String jobq,
int m,
int p,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double tola,
double tolb,
intW k,
intW l,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
int ldv,
double [] q, int _q_offset,
int ldq,
int [] iwork, int _iwork_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
intW info)  {

wantu = (jobu.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
wantv = (jobv.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0));
wantq = (jobq.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0));
forwrd = true;
// *
info.val = 0;
if (!(wantu || (jobu.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -1;
}              // Close if()
else if (!(wantv || (jobv.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -2;
}              // Close else if()
else if (!(wantq || (jobq.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -3;
}              // Close else if()
else if (m < 0)  {
    info.val = -4;
}              // Close else if()
else if (p < 0)  {
    info.val = -5;
}              // Close else if()
else if (n < 0)  {
    info.val = -6;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -8;
}              // Close else if()
else if (ldb < Math.max(1, p) )  {
    info.val = -10;
}              // Close else if()
else if (ldu < 1 || (wantu && ldu < m))  {
    info.val = -16;
}              // Close else if()
else if (ldv < 1 || (wantv && ldv < p))  {
    info.val = -18;
}              // Close else if()
else if (ldq < 1 || (wantq && ldq < n))  {
    info.val = -20;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGGSVP",-info.val);
Dummy.go_to("Dggsvp",999999);
}              // Close if()
// *
// *     QR with column pivoting of B: B*P = V*( S11 S12 )
// *                                           (  0   0  )
// *
{
forloop10:
for (i = 1; i <= n; i++) {
iwork[(i)- 1+ _iwork_offset] = 0;
Dummy.label("Dggsvp",10);
}              //  Close for() loop. 
}
Dgeqpf.dgeqpf(p,n,b,_b_offset,ldb,iwork,_iwork_offset,tau,_tau_offset,work,_work_offset,info);
// *
// *     Update A := A*P
// *
Dlapmt.dlapmt(forwrd,m,n,a,_a_offset,lda,iwork,_iwork_offset);
// *
// *     Determine the effective rank of matrix B.
// *
l.val = 0;
{
forloop20:
for (i = 1; i <= Math.min(p, n) ; i++) {
if (Math.abs(b[(i)- 1+(i- 1)*ldb+ _b_offset]) > tolb)  
    l.val = l.val+1;
Dummy.label("Dggsvp",20);
}              //  Close for() loop. 
}
// *
if (wantv)  {
    // *
// *        Copy the details of V, and form V.
// *
Dlaset.dlaset("Full",p,p,zero,zero,v,_v_offset,ldv);
if (p > 1)  
    Dlacpy.dlacpy("Lower",p-1,n,b,(2)- 1+(1- 1)*ldb+ _b_offset,ldb,v,(2)- 1+(1- 1)*ldv+ _v_offset,ldv);
Dorg2r.dorg2r(p,p,(int) ( Math.min(p, n) ),v,_v_offset,ldv,tau,_tau_offset,work,_work_offset,info);
}              // Close if()
// *
// *     Clean up B
// *
{
forloop40:
for (j = 1; j <= l.val-1; j++) {
{
forloop30:
for (i = j+1; i <= l.val; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dggsvp",30);
}              //  Close for() loop. 
}
Dummy.label("Dggsvp",40);
}              //  Close for() loop. 
}
if (p > l.val)  
    Dlaset.dlaset("Full",p-l.val,n,zero,zero,b,(l.val+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
if (wantq)  {
    // *
// *        Set Q = I and Update Q := Q*P
// *
Dlaset.dlaset("Full",n,n,zero,one,q,_q_offset,ldq);
Dlapmt.dlapmt(forwrd,n,n,q,_q_offset,ldq,iwork,_iwork_offset);
}              // Close if()
// *
if (p >= l.val && n != l.val)  {
    // *
// *        RQ factorization of (S11 S12): ( S11 S12 ) = ( 0 S12 )*Z
// *
Dgerq2.dgerq2(l.val,n,b,_b_offset,ldb,tau,_tau_offset,work,_work_offset,info);
// *
// *        Update A := A*Z'
// *
Dormr2.dormr2("Right","Transpose",m,n,l.val,b,_b_offset,ldb,tau,_tau_offset,a,_a_offset,lda,work,_work_offset,info);
// *
if (wantq)  {
    // *
// *           Update Q := Q*Z'
// *
Dormr2.dormr2("Right","Transpose",n,n,l.val,b,_b_offset,ldb,tau,_tau_offset,q,_q_offset,ldq,work,_work_offset,info);
}              // Close if()
// *
// *        Clean up B
// *
Dlaset.dlaset("Full",l.val,n-l.val,zero,zero,b,_b_offset,ldb);
{
forloop60:
for (j = n-l.val+1; j <= n; j++) {
{
forloop50:
for (i = j-n+l.val+1; i <= l.val; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dggsvp",50);
}              //  Close for() loop. 
}
Dummy.label("Dggsvp",60);
}              //  Close for() loop. 
}
// *
}              // Close if()
// *
// *     Let              N-L     L
// *                A = ( A11    A12 ) M,
// *
// *     then the following does the complete QR decomposition of A11:
// *
// *              A11 = U*(  0  T12 )*P1'
// *                      (  0   0  )
// *
{
forloop70:
for (i = 1; i <= n-l.val; i++) {
iwork[(i)- 1+ _iwork_offset] = 0;
Dummy.label("Dggsvp",70);
}              //  Close for() loop. 
}
Dgeqpf.dgeqpf(m,n-l.val,a,_a_offset,lda,iwork,_iwork_offset,tau,_tau_offset,work,_work_offset,info);
// *
// *     Determine the effective rank of A11
// *
k.val = 0;
{
forloop80:
for (i = 1; i <= Math.min(m, n-l.val) ; i++) {
if (Math.abs(a[(i)- 1+(i- 1)*lda+ _a_offset]) > tola)  
    k.val = k.val+1;
Dummy.label("Dggsvp",80);
}              //  Close for() loop. 
}
// *
// *     Update A12 := U'*A12, where A12 = A( 1:M, N-L+1:N )
// *
Dorm2r.dorm2r("Left","Transpose",m,l.val,(int) ( Math.min(m, n-l.val) ),a,_a_offset,lda,tau,_tau_offset,a,(1)- 1+(n-l.val+1- 1)*lda+ _a_offset,lda,work,_work_offset,info);
// *
if (wantu)  {
    // *
// *        Copy the details of U, and form U
// *
Dlaset.dlaset("Full",m,m,zero,zero,u,_u_offset,ldu);
if (m > 1)  
    Dlacpy.dlacpy("Lower",m-1,n-l.val,a,(2)- 1+(1- 1)*lda+ _a_offset,lda,u,(2)- 1+(1- 1)*ldu+ _u_offset,ldu);
Dorg2r.dorg2r(m,m,(int) ( Math.min(m, n-l.val) ),u,_u_offset,ldu,tau,_tau_offset,work,_work_offset,info);
}              // Close if()
// *
if (wantq)  {
    // *
// *        Update Q( 1:N, 1:N-L )  = Q( 1:N, 1:N-L )*P1
// *
Dlapmt.dlapmt(forwrd,n,n-l.val,q,_q_offset,ldq,iwork,_iwork_offset);
}              // Close if()
// *
// *     Clean up A: set the strictly lower triangular part of
// *     A(1:K, 1:K) = 0, and A( K+1:M, 1:N-L ) = 0.
// *
{
forloop100:
for (j = 1; j <= k.val-1; j++) {
{
forloop90:
for (i = j+1; i <= k.val; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dggsvp",90);
}              //  Close for() loop. 
}
Dummy.label("Dggsvp",100);
}              //  Close for() loop. 
}
if (m > k.val)  
    Dlaset.dlaset("Full",m-k.val,n-l.val,zero,zero,a,(k.val+1)- 1+(1- 1)*lda+ _a_offset,lda);
// *
if (n-l.val > k.val)  {
    // *
// *        RQ factorization of ( T11 T12 ) = ( 0 T12 )*Z1
// *
Dgerq2.dgerq2(k.val,n-l.val,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,info);
// *
if (wantq)  {
    // *
// *           Update Q( 1:N,1:N-L ) = Q( 1:N,1:N-L )*Z1'
// *
Dormr2.dormr2("Right","Transpose",n,n-l.val,k.val,a,_a_offset,lda,tau,_tau_offset,q,_q_offset,ldq,work,_work_offset,info);
}              // Close if()
// *
// *        Clean up A
// *
Dlaset.dlaset("Full",k.val,n-l.val-k.val,zero,zero,a,_a_offset,lda);
{
forloop120:
for (j = n-l.val-k.val+1; j <= n-l.val; j++) {
{
forloop110:
for (i = j-n+l.val+k.val+1; i <= k.val; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dggsvp",110);
}              //  Close for() loop. 
}
Dummy.label("Dggsvp",120);
}              //  Close for() loop. 
}
// *
}              // Close if()
// *
if (m > k.val)  {
    // *
// *        QR factorization of A( K+1:M,N-L+1:N )
// *
Dgeqr2.dgeqr2(m-k.val,l.val,a,(k.val+1)- 1+(n-l.val+1- 1)*lda+ _a_offset,lda,tau,_tau_offset,work,_work_offset,info);
// *
if (wantu)  {
    // *
// *           Update U(:,K+1:M) := U(:,K+1:M)*U1
// *
Dorm2r.dorm2r("Right","No transpose",m,m-k.val,(int) ( Math.min(m-k.val, l.val) ),a,(k.val+1)- 1+(n-l.val+1- 1)*lda+ _a_offset,lda,tau,_tau_offset,u,(1)- 1+(k.val+1- 1)*ldu+ _u_offset,ldu,work,_work_offset,info);
}              // Close if()
// *
// *        Clean up
// *
{
forloop140:
for (j = n-l.val+1; j <= n; j++) {
{
forloop130:
for (i = j-n+k.val+l.val+1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dggsvp",130);
}              //  Close for() loop. 
}
Dummy.label("Dggsvp",140);
}              //  Close for() loop. 
}
// *
}              // Close if()
// *
Dummy.go_to("Dggsvp",999999);
// *
// *     End of DGGSVP
// *
Dummy.label("Dggsvp",999999);
return;
   }
} // End class.
