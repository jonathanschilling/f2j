/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgtcon {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTCON estimates the reciprocal of the condition number of a real
// *  tridiagonal matrix A using the LU factorization as computed by
// *  DGTTRF.
// *
// *  An estimate is obtained for norm(inv(A)), and the reciprocal of the
// *  condition number is computed as RCOND = 1 / (ANORM * norm(inv(A))).
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies whether the 1-norm condition number or the
// *          infinity-norm condition number is required:
// *          = '1' or 'O':  1-norm;
// *          = 'I':         Infinity-norm.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) multipliers that define the matrix L from the
// *          LU factorization of A as computed by DGTTRF.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the upper triangular matrix U from
// *          the LU factorization of A.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) elements of the first superdiagonal of U.
// *
// *  DU2     (input) DOUBLE PRECISION array, dimension (N-2)
// *          The (n-2) elements of the second superdiagonal of U.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= n, row i of the matrix was
// *          interchanged with row IPIV(i).  IPIV(i) will always be either
// *          i or i+1; IPIV(i) = i indicates a row interchange was not
// *          required.
// *
// *  ANORM   (input) DOUBLE PRECISION
// *          If NORM = '1' or 'O', the 1-norm of the original matrix A.
// *          If NORM = 'I', the infinity-norm of the original matrix A.
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of the matrix A,
// *          computed as RCOND = 1/(ANORM * AINVNM), where AINVNM is an
// *          estimate of the 1-norm of inv(A) computed in this routine.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean onenrm= false;
static int i= 0;
static intW kase= new intW(0);
static int kase1= 0;
static doubleW ainvnm= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments.
// *

public static void dgtcon (String norm,
int n,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
double anorm,
doubleW rcond,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
onenrm = norm.trim().equalsIgnoreCase("1".trim()) || (norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0));
if (!onenrm && !(norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (anorm < zero)  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGTCON",-info.val);
Dummy.go_to("Dgtcon",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
rcond.val = zero;
if (n == 0)  {
    rcond.val = one;
Dummy.go_to("Dgtcon",999999);
}              // Close if()
else if (anorm == zero)  {
    Dummy.go_to("Dgtcon",999999);
}              // Close else if()
// *
// *     Check that D(1:N) is non-zero.
// *
{
forloop10:
for (i = 1; i <= n; i++) {
if (d[(i)- 1+ _d_offset] == zero)  
    Dummy.go_to("Dgtcon",999999);
Dummy.label("Dgtcon",10);
}              //  Close for() loop. 
}
// *
ainvnm.val = zero;
if (onenrm)  {
    kase1 = 1;
}              // Close if()
else  {
  kase1 = 2;
}              //  Close else.
kase.val = 0;
label20:
   Dummy.label("Dgtcon",20);
Dlacon.dlacon(n,work,(n+1)- 1+ _work_offset,work,_work_offset,iwork,_iwork_offset,ainvnm,kase);
if (kase.val != 0)  {
    if (kase.val == kase1)  {
    // *
// *           Multiply by inv(U)*inv(L).
// *
Dgttrs.dgttrs("No transpose",n,1,dl,_dl_offset,d,_d_offset,du,_du_offset,du2,_du2_offset,ipiv,_ipiv_offset,work,_work_offset,n,info);
}              // Close if()
else  {
  // *
// *           Multiply by inv(L')*inv(U').
// *
Dgttrs.dgttrs("Transpose",n,1,dl,_dl_offset,d,_d_offset,du,_du_offset,du2,_du2_offset,ipiv,_ipiv_offset,work,_work_offset,n,info);
}              //  Close else.
Dummy.go_to("Dgtcon",20);
}              // Close if()
// *
// *     Compute the estimate of the reciprocal condition number.
// *
if (ainvnm.val != zero)  
    rcond.val = (one/ainvnm.val)/anorm;
// *
Dummy.go_to("Dgtcon",999999);
// *
// *     End of DGTCON
// *
Dummy.label("Dgtcon",999999);
return;
   }
} // End class.
