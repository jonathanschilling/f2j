/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgtrfs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTRFS improves the computed solution to a system of linear
// *  equations when the coefficient matrix is tridiagonal, and provides
// *  error bounds and backward error estimates for the solution.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations:
// *          = 'N':  A * X = B     (No transpose)
// *          = 'T':  A**T * X = B  (Transpose)
// *          = 'C':  A**H * X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal elements of A.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal elements of A.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) superdiagonal elements of A.
// *
// *  DLF     (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) multipliers that define the matrix L from the
// *          LU factorization of A as computed by DGTTRF.
// *
// *  DF      (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the upper triangular matrix U from
// *          the LU factorization of A.
// *
// *  DUF     (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) elements of the first superdiagonal of U.
// *
// *  DU2     (input) DOUBLE PRECISION array, dimension (N-2)
// *          The (n-2) elements of the second superdiagonal of U.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= n, row i of the matrix was
// *          interchanged with row IPIV(i).  IPIV(i) will always be either
// *          i or i+1; IPIV(i) = i indicates a row interchange was not
// *          required.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          On entry, the solution matrix X, as computed by DGTTRS.
// *          On exit, the improved solution matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  FERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bound for each solution vector
// *          X(j) (the j-th column of the solution matrix X).
// *          If XTRUE is the true solution corresponding to X(j), FERR(j)
// *          is an estimated upper bound for the magnitude of the largest
// *          element in (X(j) - XTRUE) divided by the magnitude of the
// *          largest element in X(j).  The estimate is as reliable as
// *          the estimate for RCOND, and is almost always a slight
// *          overestimate of the true error.
// *
// *  BERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector X(j) (i.e., the smallest relative change in
// *          any element of A or B that makes X(j) an exact solution).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  Internal Parameters
// *  ===================
// *
// *  ITMAX is the maximum number of steps of iterative refinement.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int itmax= 5;
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
static double three= 3.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static String transn= new String(" ");
static String transt= new String(" ");
static int count= 0;
static int i= 0;
static int j= 0;
static intW kase= new intW(0);
static int nz= 0;
static double eps= 0.0;
static double lstres= 0.0;
static double s= 0.0;
static double safe1= 0.0;
static double safe2= 0.0;
static double safmin= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dgtrfs (String trans,
int n,
int nrhs,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] dlf, int _dlf_offset,
double [] df, int _df_offset,
double [] duf, int _duf_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -13;
}              // Close else if()
else if (ldx < Math.max(1, n) )  {
    info.val = -15;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGTRFS",-info.val);
Dummy.go_to("Dgtrfs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0)  {
    {
forloop10:
for (j = 1; j <= nrhs; j++) {
ferr[(j)- 1+ _ferr_offset] = zero;
berr[(j)- 1+ _berr_offset] = zero;
Dummy.label("Dgtrfs",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dgtrfs",999999);
}              // Close if()
// *
if (notran)  {
    transn = "N";
transt = "T";
}              // Close if()
else  {
  transn = "T";
transt = "N";
}              //  Close else.
// *
// *     NZ = maximum number of nonzero elements in each row of A, plus 1
// *
nz = 4;
eps = Dlamch.dlamch("Epsilon");
safmin = Dlamch.dlamch("Safe minimum");
safe1 = nz*safmin;
safe2 = safe1/eps;
// *
// *     Do for each right hand side
// *
{
forloop110:
for (j = 1; j <= nrhs; j++) {
// *
count = 1;
lstres = three;
label20:
   Dummy.label("Dgtrfs",20);
// *
// *        Loop until stopping criterion is satisfied.
// *
// *        Compute residual R = B - op(A) * X,
// *        where op(A) = A, A**T, or A**H, depending on TRANS.
// *
Dcopy.dcopy(n,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,(n+1)- 1+ _work_offset,1);
Dlagtm.dlagtm(trans,n,1,-one,dl,_dl_offset,d,_d_offset,du,_du_offset,x,(1)- 1+(j- 1)*ldx+ _x_offset,ldx,one,work,(n+1)- 1+ _work_offset,n);
// *
// *        Compute abs(op(A))*abs(x) + abs(b) for use in the backward
// *        error bound.
// *
if (notran)  {
    if (n == 1)  {
    work[(1)- 1+ _work_offset] = Math.abs(b[(1)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  work[(1)- 1+ _work_offset] = Math.abs(b[(1)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(du[(1)- 1+ _du_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset]);
{
forloop30:
for (i = 2; i <= n-1; i++) {
work[(i)- 1+ _work_offset] = Math.abs(b[(i)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(dl[(i-1)- 1+ _dl_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(du[(i)- 1+ _du_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset]);
Dummy.label("Dgtrfs",30);
}              //  Close for() loop. 
}
work[(n)- 1+ _work_offset] = Math.abs(b[(n)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(dl[(n-1)- 1+ _dl_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset]);
}              //  Close else.
}              // Close if()
else  {
  if (n == 1)  {
    work[(1)- 1+ _work_offset] = Math.abs(b[(1)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  work[(1)- 1+ _work_offset] = Math.abs(b[(1)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(dl[(1)- 1+ _dl_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset]);
{
forloop40:
for (i = 2; i <= n-1; i++) {
work[(i)- 1+ _work_offset] = Math.abs(b[(i)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(du[(i-1)- 1+ _du_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(dl[(i)- 1+ _dl_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset]);
Dummy.label("Dgtrfs",40);
}              //  Close for() loop. 
}
work[(n)- 1+ _work_offset] = Math.abs(b[(n)- 1+(j- 1)*ldb+ _b_offset])+Math.abs(du[(n-1)- 1+ _du_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset])+Math.abs(d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset]);
}              //  Close else.
}              //  Close else.
// *
// *        Compute componentwise relative backward error from formula
// *
// *        max(i) ( abs(R(i)) / ( abs(op(A))*abs(X) + abs(B) )(i) )
// *
// *        where abs(Z) is the componentwise absolute value of the matrix
// *        or vector Z.  If the i-th component of the denominator is less
// *        than SAFE2, then SAFE1 is added to the i-th components of the
// *        numerator and denominator before dividing.
// *
s = zero;
{
forloop50:
for (i = 1; i <= n; i++) {
if (work[(i)- 1+ _work_offset] > safe2)  {
    s = Math.max(s, Math.abs(work[(n+i)- 1+ _work_offset])/work[(i)- 1+ _work_offset]) ;
}              // Close if()
else  {
  s = Math.max(s, (Math.abs(work[(n+i)- 1+ _work_offset])+safe1)/(work[(i)- 1+ _work_offset]+safe1)) ;
}              //  Close else.
Dummy.label("Dgtrfs",50);
}              //  Close for() loop. 
}
berr[(j)- 1+ _berr_offset] = s;
// *
// *        Test stopping criterion. Continue iterating if
// *           1) The residual BERR(J) is larger than machine epsilon, and
// *           2) BERR(J) decreased by at least a factor of 2 during the
// *              last iteration, and
// *           3) At most ITMAX iterations tried.
// *
if (berr[(j)- 1+ _berr_offset] > eps && two*berr[(j)- 1+ _berr_offset] <= lstres && count <= itmax)  {
    // *
// *           Update solution and try again.
// *
Dgttrs.dgttrs(trans,n,1,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
Daxpy.daxpy(n,one,work,(n+1)- 1+ _work_offset,1,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
lstres = berr[(j)- 1+ _berr_offset];
count = count+1;
Dummy.go_to("Dgtrfs",20);
}              // Close if()
// *
// *        Bound error from formula
// *
// *        norm(X - XTRUE) / norm(X) .le. FERR =
// *        norm( abs(inv(op(A)))*
// *           ( abs(R) + NZ*EPS*( abs(op(A))*abs(X)+abs(B) ))) / norm(X)
// *
// *        where
// *          norm(Z) is the magnitude of the largest component of Z
// *          inv(op(A)) is the inverse of op(A)
// *          abs(Z) is the componentwise absolute value of the matrix or
// *             vector Z
// *          NZ is the maximum number of nonzeros in any row of A, plus 1
// *          EPS is machine epsilon
// *
// *        The i-th component of abs(R)+NZ*EPS*(abs(op(A))*abs(X)+abs(B))
// *        is incremented by SAFE1 if the i-th component of
// *        abs(op(A))*abs(X) + abs(B) is less than SAFE2.
// *
// *        Use DLACON to estimate the infinity-norm of the matrix
// *           inv(op(A)) * diag(W),
// *        where W = abs(R) + NZ*EPS*( abs(op(A))*abs(X)+abs(B) )))
// *
{
forloop60:
for (i = 1; i <= n; i++) {
if (work[(i)- 1+ _work_offset] > safe2)  {
    work[(i)- 1+ _work_offset] = Math.abs(work[(n+i)- 1+ _work_offset])+nz*eps*work[(i)- 1+ _work_offset];
}              // Close if()
else  {
  work[(i)- 1+ _work_offset] = Math.abs(work[(n+i)- 1+ _work_offset])+nz*eps*work[(i)- 1+ _work_offset]+safe1;
}              //  Close else.
Dummy.label("Dgtrfs",60);
}              //  Close for() loop. 
}
// *
kase.val = 0;
label70:
   Dummy.label("Dgtrfs",70);
dlacon_adapter(n,work,(2*n+1)- 1+ _work_offset,work,(n+1)- 1+ _work_offset,iwork,_iwork_offset,ferr,(j)- 1+ _ferr_offset,kase);
if (kase.val != 0)  {
    if (kase.val == 1)  {
    // *
// *              Multiply by diag(W)*inv(op(A)**T).
// *
Dgttrs.dgttrs(transt,n,1,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
{
forloop80:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]*work[(n+i)- 1+ _work_offset];
Dummy.label("Dgtrfs",80);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *              Multiply by inv(op(A))*diag(W).
// *
{
forloop90:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]*work[(n+i)- 1+ _work_offset];
Dummy.label("Dgtrfs",90);
}              //  Close for() loop. 
}
Dgttrs.dgttrs(transn,n,1,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,work,(n+1)- 1+ _work_offset,n,info);
}              //  Close else.
Dummy.go_to("Dgtrfs",70);
}              // Close if()
// *
// *        Normalize error.
// *
lstres = zero;
{
forloop100:
for (i = 1; i <= n; i++) {
lstres = Math.max(lstres, Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset])) ;
Dummy.label("Dgtrfs",100);
}              //  Close for() loop. 
}
if (lstres != zero)  
    ferr[(j)- 1+ _ferr_offset] = ferr[(j)- 1+ _ferr_offset]/lstres;
// *
Dummy.label("Dgtrfs",110);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgtrfs",999999);
// *
// *     End of DGTRFS
// *
Dummy.label("Dgtrfs",999999);
return;
   }
// adapter for dlacon
private static void dlacon_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,intW arg5 )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlacon.dlacon(arg0,arg1, arg1_offset,arg2, arg2_offset,arg3, arg3_offset,_f2j_tmp4,arg5);

arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
