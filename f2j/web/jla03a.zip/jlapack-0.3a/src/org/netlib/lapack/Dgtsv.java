/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgtsv {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTSV  solves the equation
// *
// *     A*X = B,
// *
// *  where A is an N-by-N tridiagonal matrix, by Gaussian elimination with
// *  partial pivoting.
// *
// *  Note that the equation  A'*X = B  may be solved by interchanging the
// *  order of the arguments DU and DL.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  DL      (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, DL must contain the (n-1) subdiagonal elements of
// *          A.
// *          On exit, DL is overwritten by the (n-2) elements of the
// *          second superdiagonal of the upper triangular matrix U from
// *          the LU factorization of A, in DL(1), ..., DL(n-2).
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, D must contain the diagonal elements of A.
// *          On exit, D is overwritten by the n diagonal elements of U.
// *
// *  DU      (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, DU must contain the (n-1) superdiagonal elements
// *          of A.
// *          On exit, DU is overwritten by the (n-1) elements of the first
// *          superdiagonal of U.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the N-by-NRHS right hand side matrix B.
// *          On exit, if INFO = 0, the N-by-NRHS solution matrix X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, U(i,i) is exactly zero, and the solution
// *                has not been computed.  The factorization has not been
// *                completed unless i = N.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static int k= 0;
static double mult= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgtsv (int n,
int nrhs,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (nrhs < 0)  {
    info.val = -2;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGTSV ",-info.val);
Dummy.go_to("Dgtsv",999999);
}              // Close if()
// *
if (n == 0)  
    Dummy.go_to("Dgtsv",999999);
// *
{
forloop30:
for (k = 1; k <= n-1; k++) {
if (dl[(k)- 1+ _dl_offset] == zero)  {
    // *
// *           Subdiagonal is zero, no elimination is required.
// *
if (d[(k)- 1+ _d_offset] == zero)  {
    // *
// *              Diagonal is zero: set INFO = K and return; a unique
// *              solution can not be found.
// *
info.val = k;
Dummy.go_to("Dgtsv",999999);
}              // Close if()
}              // Close if()
else if (Math.abs(d[(k)- 1+ _d_offset]) >= Math.abs(dl[(k)- 1+ _dl_offset]))  {
    // *
// *           No row interchange required
// *
mult = dl[(k)- 1+ _dl_offset]/d[(k)- 1+ _d_offset];
d[(k+1)- 1+ _d_offset] = d[(k+1)- 1+ _d_offset]-mult*du[(k)- 1+ _du_offset];
{
forloop10:
for (j = 1; j <= nrhs; j++) {
b[(k+1)- 1+(j- 1)*ldb+ _b_offset] = b[(k+1)- 1+(j- 1)*ldb+ _b_offset]-mult*b[(k)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dgtsv",10);
}              //  Close for() loop. 
}
if (k < (n-1))  
    dl[(k)- 1+ _dl_offset] = zero;
}              // Close else if()
else  {
  // *
// *           Interchange rows K and K+1
// *
mult = d[(k)- 1+ _d_offset]/dl[(k)- 1+ _dl_offset];
d[(k)- 1+ _d_offset] = dl[(k)- 1+ _dl_offset];
temp = d[(k+1)- 1+ _d_offset];
d[(k+1)- 1+ _d_offset] = du[(k)- 1+ _du_offset]-mult*temp;
if (k < (n-1))  {
    dl[(k)- 1+ _dl_offset] = du[(k+1)- 1+ _du_offset];
du[(k+1)- 1+ _du_offset] = -mult*dl[(k)- 1+ _dl_offset];
}              // Close if()
du[(k)- 1+ _du_offset] = temp;
{
forloop20:
for (j = 1; j <= nrhs; j++) {
temp = b[(k)- 1+(j- 1)*ldb+ _b_offset];
b[(k)- 1+(j- 1)*ldb+ _b_offset] = b[(k+1)- 1+(j- 1)*ldb+ _b_offset];
b[(k+1)- 1+(j- 1)*ldb+ _b_offset] = temp-mult*b[(k+1)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dgtsv",20);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dgtsv",30);
}              //  Close for() loop. 
}
if (d[(n)- 1+ _d_offset] == zero)  {
    info.val = n;
Dummy.go_to("Dgtsv",999999);
}              // Close if()
// *
// *     Back solve with the matrix U from the factorization.
// *
{
forloop50:
for (j = 1; j <= nrhs; j++) {
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]/d[(n)- 1+ _d_offset];
if (n > 1)  
    b[(n-1)- 1+(j- 1)*ldb+ _b_offset] = (b[(n-1)- 1+(j- 1)*ldb+ _b_offset]-du[(n-1)- 1+ _du_offset]*b[(n)- 1+(j- 1)*ldb+ _b_offset])/d[(n-1)- 1+ _d_offset];
{
int _k_inc = -1;
forloop40:
for (k = n-2; k >= 1; k += _k_inc) {
b[(k)- 1+(j- 1)*ldb+ _b_offset] = (b[(k)- 1+(j- 1)*ldb+ _b_offset]-du[(k)- 1+ _du_offset]*b[(k+1)- 1+(j- 1)*ldb+ _b_offset]-dl[(k)- 1+ _dl_offset]*b[(k+2)- 1+(j- 1)*ldb+ _b_offset])/d[(k)- 1+ _d_offset];
Dummy.label("Dgtsv",40);
}              //  Close for() loop. 
}
Dummy.label("Dgtsv",50);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgtsv",999999);
// *
// *     End of DGTSV
// *
Dummy.label("Dgtsv",999999);
return;
   }
} // End class.
