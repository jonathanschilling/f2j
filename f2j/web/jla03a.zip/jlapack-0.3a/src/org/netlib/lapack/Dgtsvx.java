/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dgtsvx {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTSVX uses the LU factorization to compute the solution to a real
// *  system of linear equations A * X = B or A**T * X = B,
// *  where A is a tridiagonal matrix of order N and X and B are N-by-NRHS
// *  matrices.
// *
// *  Error bounds on the solution and a condition estimate are also
// *  provided.
// *
// *  Description
// *  ===========
// *
// *  The following steps are performed:
// *
// *  1. If FACT = 'N', the LU decomposition is used to factor the matrix A
// *     as A = L * U, where L is a product of permutation and unit lower
// *     bidiagonal matrices and U is upper triangular with nonzeros in
// *     only the main diagonal and first two superdiagonals.
// *
// *  2. The factored form of A is used to estimate the condition number
// *     of the matrix A.  If the reciprocal of the condition number is
// *     less than machine precision, steps 3 and 4 are skipped.
// *
// *  3. The system of equations is solved for X using the factored form
// *     of A.
// *
// *  4. Iterative refinement is applied to improve the computed solution
// *     matrix and calculate error bounds and backward error estimates
// *     for it.
// *
// *  Arguments
// *  =========
// *
// *  FACT    (input) CHARACTER*1
// *          Specifies whether or not the factored form of A has been
// *          supplied on entry.
// *          = 'F':  DLF, DF, DUF, DU2, and IPIV contain the factored
// *                  form of A; DL, D, DU, DLF, DF, DUF, DU2 and IPIV
// *                  will not be modified.
// *          = 'N':  The matrix will be copied to DLF, DF, and DUF
// *                  and factored.
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations:
// *          = 'N':  A * X = B     (No transpose)
// *          = 'T':  A**T * X = B  (Transpose)
// *          = 'C':  A**H * X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal elements of A.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of A.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) superdiagonal elements of A.
// *
// *  DLF     (input or output) DOUBLE PRECISION array, dimension (N-1)
// *          If FACT = 'F', then DLF is an input argument and on entry
// *          contains the (n-1) multipliers that define the matrix L from
// *          the LU factorization of A as computed by DGTTRF.
// *
// *          If FACT = 'N', then DLF is an output argument and on exit
// *          contains the (n-1) multipliers that define the matrix L from
// *          the LU factorization of A.
// *
// *  DF      (input or output) DOUBLE PRECISION array, dimension (N)
// *          If FACT = 'F', then DF is an input argument and on entry
// *          contains the n diagonal elements of the upper triangular
// *          matrix U from the LU factorization of A.
// *
// *          If FACT = 'N', then DF is an output argument and on exit
// *          contains the n diagonal elements of the upper triangular
// *          matrix U from the LU factorization of A.
// *
// *  DUF     (input or output) DOUBLE PRECISION array, dimension (N-1)
// *          If FACT = 'F', then DUF is an input argument and on entry
// *          contains the (n-1) elements of the first superdiagonal of U.
// *
// *          If FACT = 'N', then DUF is an output argument and on exit
// *          contains the (n-1) elements of the first superdiagonal of U.
// *
// *  DU2     (input or output) DOUBLE PRECISION array, dimension (N-2)
// *          If FACT = 'F', then DU2 is an input argument and on entry
// *          contains the (n-2) elements of the second superdiagonal of
// *          U.
// *
// *          If FACT = 'N', then DU2 is an output argument and on exit
// *          contains the (n-2) elements of the second superdiagonal of
// *          U.
// *
// *  IPIV    (input or output) INTEGER array, dimension (N)
// *          If FACT = 'F', then IPIV is an input argument and on entry
// *          contains the pivot indices from the LU factorization of A as
// *          computed by DGTTRF.
// *
// *          If FACT = 'N', then IPIV is an output argument and on exit
// *          contains the pivot indices from the LU factorization of A;
// *          row i of the matrix was interchanged with row IPIV(i).
// *          IPIV(i) will always be either i or i+1; IPIV(i) = i indicates
// *          a row interchange was not required.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The N-by-NRHS right hand side matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (output) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          If INFO = 0, the N-by-NRHS solution matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The estimate of the reciprocal condition number of the matrix
// *          A.  If RCOND is less than the machine precision (in
// *          particular, if RCOND = 0), the matrix is singular to working
// *          precision.  This condition is indicated by a return code of
// *          INFO > 0, and the solution and error bounds are not computed.
// *
// *  FERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bound for each solution vector
// *          X(j) (the j-th column of the solution matrix X).
// *          If XTRUE is the true solution corresponding to X(j), FERR(j)
// *          is an estimated upper bound for the magnitude of the largest
// *          element in (X(j) - XTRUE) divided by the magnitude of the
// *          largest element in X(j).  The estimate is as reliable as
// *          the estimate for RCOND, and is almost always a slight
// *          overestimate of the true error.
// *
// *  BERR    (output) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector X(j) (i.e., the smallest relative change in
// *          any element of A or B that makes X(j) an exact solution).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, and i is
// *                <= N:  U(i,i) is exactly zero.  The factorization
// *                       has not been completed unless i = N, but the
// *                       factor U is exactly singular, so the solution
// *                       and error bounds could not be computed.
// *               = N+1:  RCOND is less than machine precision.  The
// *                       factorization has been completed, but the
// *                       matrix is singular to working precision, and
// *                       the solution and error bounds have not been
// *                       computed.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean nofact= false;
static boolean notran= false;
static String norm= new String(" ");
static double anorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgtsvx (String fact,
String trans,
int n,
int nrhs,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] dlf, int _dlf_offset,
double [] df, int _df_offset,
double [] duf, int _duf_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
doubleW rcond,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
nofact = (fact.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!nofact && !(fact.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -4;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -14;
}              // Close else if()
else if (ldx < Math.max(1, n) )  {
    info.val = -16;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGTSVX",-info.val);
Dummy.go_to("Dgtsvx",999999);
}              // Close if()
// *
if (nofact)  {
    // *
// *        Compute the LU factorization of A.
// *
Dcopy.dcopy(n,d,_d_offset,1,df,_df_offset,1);
if (n > 1)  {
    Dcopy.dcopy(n-1,dl,_dl_offset,1,dlf,_dlf_offset,1);
Dcopy.dcopy(n-1,du,_du_offset,1,duf,_duf_offset,1);
}              // Close if()
Dgttrf.dgttrf(n,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,info);
// *
// *        Return if INFO is non-zero.
// *
if (info.val != 0)  {
    if (info.val > 0)  
    rcond.val = zero;
Dummy.go_to("Dgtsvx",999999);
}              // Close if()
}              // Close if()
// *
// *     Compute the norm of the matrix A.
// *
if (notran)  {
    norm = "1";
}              // Close if()
else  {
  norm = "I";
}              //  Close else.
anorm = Dlangt.dlangt(norm,n,dl,_dl_offset,d,_d_offset,du,_du_offset);
// *
// *     Compute the reciprocal of the condition number of A.
// *
Dgtcon.dgtcon(norm,n,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,anorm,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *     Return if the matrix is singular to working precision.
// *
if (rcond.val < Dlamch.dlamch("Epsilon"))  {
    info.val = n+1;
Dummy.go_to("Dgtsvx",999999);
}              // Close if()
// *
// *     Compute the solution vectors X.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,ldb,x,_x_offset,ldx);
Dgttrs.dgttrs(trans,n,nrhs,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,x,_x_offset,ldx,info);
// *
// *     Use iterative refinement to improve the computed solutions and
// *     compute error bounds and backward error estimates for them.
// *
Dgtrfs.dgtrfs(trans,n,nrhs,dl,_dl_offset,d,_d_offset,du,_du_offset,dlf,_dlf_offset,df,_df_offset,duf,_duf_offset,du2,_du2_offset,ipiv,_ipiv_offset,b,_b_offset,ldb,x,_x_offset,ldx,ferr,_ferr_offset,berr,_berr_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
Dummy.go_to("Dgtsvx",999999);
// *
// *     End of DGTSVX
// *
Dummy.label("Dgtsvx",999999);
return;
   }
} // End class.
