/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgttrf {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTTRF computes an LU factorization of a real tridiagonal matrix A
// *  using elimination with partial pivoting and row interchanges.
// *
// *  The factorization has the form
// *     A = L * U
// *  where L is a product of permutation and unit lower bidiagonal
// *  matrices and U is upper triangular with nonzeros in only the main
// *  diagonal and first two superdiagonals.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  DL      (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, DL must contain the (n-1) subdiagonal elements of
// *          A.
// *          On exit, DL is overwritten by the (n-1) multipliers that
// *          define the matrix L from the LU factorization of A.
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, D must contain the diagonal elements of A.
// *          On exit, D is overwritten by the n diagonal elements of the
// *          upper triangular matrix U from the LU factorization of A.
// *
// *  DU      (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, DU must contain the (n-1) superdiagonal elements
// *          of A.
// *          On exit, DU is overwritten by the (n-1) elements of the first
// *          superdiagonal of U.
// *
// *  DU2     (output) DOUBLE PRECISION array, dimension (N-2)
// *          On exit, DU2 is overwritten by the (n-2) elements of the
// *          second superdiagonal of U.
// *
// *  IPIV    (output) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= n, row i of the matrix was
// *          interchanged with row IPIV(i).  IPIV(i) will always be either
// *          i or i+1; IPIV(i) = i indicates a row interchange was not
// *          required.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, U(i,i) is exactly zero. The factorization
// *                has been completed, but the factor U is exactly
// *                singular, and division by zero will occur if it is used
// *                to solve a system of equations.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static double fact= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Executable Statements ..
// *

public static void dgttrf (int n,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
Xerbla.xerbla("DGTTRF",-info.val);
Dummy.go_to("Dgttrf",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dgttrf",999999);
// *
// *     Initialize IPIV(i) = i
// *
{
forloop10:
for (i = 1; i <= n; i++) {
ipiv[(i)- 1+ _ipiv_offset] = i;
Dummy.label("Dgttrf",10);
}              //  Close for() loop. 
}
// *
{
forloop20:
for (i = 1; i <= n-1; i++) {
if (dl[(i)- 1+ _dl_offset] == zero)  {
    // *
// *           Subdiagonal is zero, no elimination is required.
// *
if (d[(i)- 1+ _d_offset] == zero && info.val == 0)  
    info.val = i;
if (i < n-1)  
    du2[(i)- 1+ _du2_offset] = zero;
}              // Close if()
else if (Math.abs(d[(i)- 1+ _d_offset]) >= Math.abs(dl[(i)- 1+ _dl_offset]))  {
    // *
// *           No row interchange required, eliminate DL(I)
// *
fact = dl[(i)- 1+ _dl_offset]/d[(i)- 1+ _d_offset];
dl[(i)- 1+ _dl_offset] = fact;
d[(i+1)- 1+ _d_offset] = d[(i+1)- 1+ _d_offset]-fact*du[(i)- 1+ _du_offset];
if (i < n-1)  
    du2[(i)- 1+ _du2_offset] = zero;
}              // Close else if()
else  {
  // *
// *           Interchange rows I and I+1, eliminate DL(I)
// *
fact = d[(i)- 1+ _d_offset]/dl[(i)- 1+ _dl_offset];
d[(i)- 1+ _d_offset] = dl[(i)- 1+ _dl_offset];
dl[(i)- 1+ _dl_offset] = fact;
temp = du[(i)- 1+ _du_offset];
du[(i)- 1+ _du_offset] = d[(i+1)- 1+ _d_offset];
d[(i+1)- 1+ _d_offset] = temp-fact*d[(i+1)- 1+ _d_offset];
if (i < n-1)  {
    du2[(i)- 1+ _du2_offset] = du[(i+1)- 1+ _du_offset];
du[(i+1)- 1+ _du_offset] = -fact*du[(i+1)- 1+ _du_offset];
}              // Close if()
ipiv[(i)- 1+ _ipiv_offset] = ipiv[(i)- 1+ _ipiv_offset]+1;
}              //  Close else.
Dummy.label("Dgttrf",20);
}              //  Close for() loop. 
}
if (d[(n)- 1+ _d_offset] == zero && info.val == 0)  {
    info.val = n;
Dummy.go_to("Dgttrf",999999);
}              // Close if()
// *
Dummy.go_to("Dgttrf",999999);
// *
// *     End of DGTTRF
// *
Dummy.label("Dgttrf",999999);
return;
   }
} // End class.
