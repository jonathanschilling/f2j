/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dgttrs {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTTRS solves one of the systems of equations
// *     A*X = B  or  A'*X = B,
// *  with a tridiagonal matrix A using the LU factorization computed
// *  by DGTTRF.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER
// *          Specifies the form of the system of equations:
// *          = 'N':  A * X = B  (No transpose)
// *          = 'T':  A'* X = B  (Transpose)
// *          = 'C':  A'* X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrix B.  NRHS >= 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) multipliers that define the matrix L from the
// *          LU factorization of A.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the upper triangular matrix U from
// *          the LU factorization of A.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) elements of the first superdiagonal of U.
// *
// *  DU2     (input) DOUBLE PRECISION array, dimension (N-2)
// *          The (n-2) elements of the second superdiagonal of U.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= n, row i of the matrix was
// *          interchanged with row IPIV(i).  IPIV(i) will always be either
// *          i or i+1; IPIV(i) = i indicates a row interchange was not
// *          required.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side matrix B.
// *          On exit, B is overwritten by the solution matrix X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean notran= false;
static int i= 0;
static int j= 0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgttrs (String trans,
int n,
int nrhs,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -3;
}              // Close else if()
else if (ldb < Math.max(n, 1) )  {
    info.val = -10;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DGTTRS",-info.val);
Dummy.go_to("Dgttrs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || nrhs == 0)  
    Dummy.go_to("Dgttrs",999999);
// *
if (notran)  {
    // *
// *        Solve A*X = B using the LU factorization of A,
// *        overwriting each right hand side vector with its solution.
// *
{
forloop30:
for (j = 1; j <= nrhs; j++) {
// *
// *           Solve L*x = b.
// *
{
forloop10:
for (i = 1; i <= n-1; i++) {
if (ipiv[(i)- 1+ _ipiv_offset] == i)  {
    b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i+1)- 1+(j- 1)*ldb+ _b_offset]-dl[(i)- 1+ _dl_offset]*b[(i)- 1+(j- 1)*ldb+ _b_offset];
}              // Close if()
else  {
  temp = b[(i)- 1+(j- 1)*ldb+ _b_offset];
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i+1)- 1+(j- 1)*ldb+ _b_offset];
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = temp-dl[(i)- 1+ _dl_offset]*b[(i)- 1+(j- 1)*ldb+ _b_offset];
}              //  Close else.
Dummy.label("Dgttrs",10);
}              //  Close for() loop. 
}
// *
// *           Solve U*x = b.
// *
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]/d[(n)- 1+ _d_offset];
if (n > 1)  
    b[(n-1)- 1+(j- 1)*ldb+ _b_offset] = (b[(n-1)- 1+(j- 1)*ldb+ _b_offset]-du[(n-1)- 1+ _du_offset]*b[(n)- 1+(j- 1)*ldb+ _b_offset])/d[(n-1)- 1+ _d_offset];
{
int _i_inc = -1;
forloop20:
for (i = n-2; i >= 1; i += _i_inc) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = (b[(i)- 1+(j- 1)*ldb+ _b_offset]-du[(i)- 1+ _du_offset]*b[(i+1)- 1+(j- 1)*ldb+ _b_offset]-du2[(i)- 1+ _du2_offset]*b[(i+2)- 1+(j- 1)*ldb+ _b_offset])/d[(i)- 1+ _d_offset];
Dummy.label("Dgttrs",20);
}              //  Close for() loop. 
}
Dummy.label("Dgttrs",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Solve A' * X = B.
// *
{
forloop60:
for (j = 1; j <= nrhs; j++) {
// *
// *           Solve U'*x = b.
// *
b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]/d[(1)- 1+ _d_offset];
if (n > 1)  
    b[(2)- 1+(j- 1)*ldb+ _b_offset] = (b[(2)- 1+(j- 1)*ldb+ _b_offset]-du[(1)- 1+ _du_offset]*b[(1)- 1+(j- 1)*ldb+ _b_offset])/d[(2)- 1+ _d_offset];
{
forloop40:
for (i = 3; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = (b[(i)- 1+(j- 1)*ldb+ _b_offset]-du[(i-1)- 1+ _du_offset]*b[(i-1)- 1+(j- 1)*ldb+ _b_offset]-du2[(i-2)- 1+ _du2_offset]*b[(i-2)- 1+(j- 1)*ldb+ _b_offset])/d[(i)- 1+ _d_offset];
Dummy.label("Dgttrs",40);
}              //  Close for() loop. 
}
// *
// *           Solve L'*x = b.
// *
{
int _i_inc = -1;
forloop50:
for (i = n-1; i >= 1; i += _i_inc) {
if (ipiv[(i)- 1+ _ipiv_offset] == i)  {
    b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-dl[(i)- 1+ _dl_offset]*b[(i+1)- 1+(j- 1)*ldb+ _b_offset];
}              // Close if()
else  {
  temp = b[(i+1)- 1+(j- 1)*ldb+ _b_offset];
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-dl[(i)- 1+ _dl_offset]*temp;
b[(i)- 1+(j- 1)*ldb+ _b_offset] = temp;
}              //  Close else.
Dummy.label("Dgttrs",50);
}              //  Close for() loop. 
}
Dummy.label("Dgttrs",60);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     End of DGTTRS
// *
Dummy.label("Dgttrs",999999);
return;
   }
} // End class.
