/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dhgeqz {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DHGEQZ implements a single-/double-shift version of the QZ method for
// *  finding the generalized eigenvalues
// *
// *  w(j)=(ALPHAR(j) + i*ALPHAI(j))/BETAR(j)   of the equation
// *
// *       det( A - w(i) B ) = 0
// *
// *  In addition, the pair A,B may be reduced to generalized Schur form:
// *  B is upper triangular, and A is block upper triangular, where the
// *  diagonal blocks are either 1-by-1 or 2-by-2, the 2-by-2 blocks having
// *  complex generalized eigenvalues (see the description of the argument
// *  JOB.)
// *
// *  If JOB='S', then the pair (A,B) is simultaneously reduced to Schur
// *  form by applying one orthogonal tranformation (usually called Q) on
// *  the left and another (usually called Z) on the right.  The 2-by-2
// *  upper-triangular diagonal blocks of B corresponding to 2-by-2 blocks
// *  of A will be reduced to positive diagonal matrices.  (I.e.,
// *  if A(j+1,j) is non-zero, then B(j+1,j)=B(j,j+1)=0 and B(j,j) and
// *  B(j+1,j+1) will be positive.)
// *
// *  If JOB='E', then at each iteration, the same transformations
// *  are computed, but they are only applied to those parts of A and B
// *  which are needed to compute ALPHAR, ALPHAI, and BETAR.
// *
// *  If JOB='S' and COMPQ and COMPZ are 'V' or 'I', then the orthogonal
// *  transformations used to reduce (A,B) are accumulated into the arrays
// *  Q and Z s.t.:
// *
// *       Q(in) A(in) Z(in)* = Q(out) A(out) Z(out)*
// *       Q(in) B(in) Z(in)* = Q(out) B(out) Z(out)*
// *
// *  Ref: C.B. Moler & G.W. Stewart, "An Algorithm for Generalized Matrix
// *       Eigenvalue Problems", SIAM J. Numer. Anal., 10(1973),
// *       pp. 241--256.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER*1
// *          = 'E': compute only ALPHAR, ALPHAI, and BETA.  A and B will
// *                 not necessarily be put into generalized Schur form.
// *          = 'S': put A and B into generalized Schur form, as well
// *                 as computing ALPHAR, ALPHAI, and BETA.
// *
// *  COMPQ   (input) CHARACTER*1
// *          = 'N': do not modify Q.
// *          = 'V': multiply the array Q on the right by the transpose of
// *                 the orthogonal tranformation that is applied to the
// *                 left side of A and B to reduce them to Schur form.
// *          = 'I': like COMPQ='V', except that Q will be initialized to
// *                 the identity first.
// *
// *  COMPZ   (input) CHARACTER*1
// *          = 'N': do not modify Z.
// *          = 'V': multiply the array Z on the right by the orthogonal
// *                 tranformation that is applied to the right side of
// *                 A and B to reduce them to Schur form.
// *          = 'I': like COMPZ='V', except that Z will be initialized to
// *                 the identity first.
// *
// *  N       (input) INTEGER
// *          The order of the matrices A, B, Q, and Z.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          It is assumed that A is already upper triangular in rows and
// *          columns 1:ILO-1 and IHI+1:N.
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          On entry, the N-by-N upper Hessenberg matrix A.  Elements
// *          below the subdiagonal must be zero.
// *          If JOB='S', then on exit A and B will have been
// *             simultaneously reduced to generalized Schur form.
// *          If JOB='E', then on exit A will have been destroyed.
// *             The diagonal blocks will be correct, but the off-diagonal
// *             portion will be meaningless.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max( 1, N ).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB, N)
// *          On entry, the N-by-N upper triangular matrix B.  Elements
// *          below the diagonal must be zero.  2-by-2 blocks in B
// *          corresponding to 2-by-2 blocks in A will be reduced to
// *          positive diagonal form.  (I.e., if A(j+1,j) is non-zero,
// *          then B(j+1,j)=B(j,j+1)=0 and B(j,j) and B(j+1,j+1) will be
// *          positive.)
// *          If JOB='S', then on exit A and B will have been
// *             simultaneously reduced to Schur form.
// *          If JOB='E', then on exit B will have been destroyed.
// *             Elements corresponding to diagonal blocks of A will be
// *             correct, but the off-diagonal portion will be meaningless.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max( 1, N ).
// *
// *  ALPHAR  (output) DOUBLE PRECISION array, dimension (N)
// *          ALPHAR(1:N) will be set to real parts of the diagonal
// *          elements of A that would result from reducing A and B to
// *          Schur form and then further reducing them both to triangular
// *          form using unitary transformations s.t. the diagonal of B
// *          was non-negative real.  Thus, if A(j,j) is in a 1-by-1 block
// *          (i.e., A(j+1,j)=A(j,j+1)=0), then ALPHAR(j)=A(j,j).
// *          Note that the (real or complex) values
// *          (ALPHAR(j) + i*ALPHAI(j))/BETA(j), j=1,...,N, are the
// *          generalized eigenvalues of the matrix pencil A - wB.
// *
// *  ALPHAI  (output) DOUBLE PRECISION array, dimension (N)
// *          ALPHAI(1:N) will be set to imaginary parts of the diagonal
// *          elements of A that would result from reducing A and B to
// *          Schur form and then further reducing them both to triangular
// *          form using unitary transformations s.t. the diagonal of B
// *          was non-negative real.  Thus, if A(j,j) is in a 1-by-1 block
// *          (i.e., A(j+1,j)=A(j,j+1)=0), then ALPHAR(j)=0.
// *          Note that the (real or complex) values
// *          (ALPHAR(j) + i*ALPHAI(j))/BETA(j), j=1,...,N, are the
// *          generalized eigenvalues of the matrix pencil A - wB.
// *
// *  BETA    (output) DOUBLE PRECISION array, dimension (N)
// *          BETA(1:N) will be set to the (real) diagonal elements of B
// *          that would result from reducing A and B to Schur form and
// *          then further reducing them both to triangular form using
// *          unitary transformations s.t. the diagonal of B was
// *          non-negative real.  Thus, if A(j,j) is in a 1-by-1 block
// *          (i.e., A(j+1,j)=A(j,j+1)=0), then BETA(j)=B(j,j).
// *          Note that the (real or complex) values
// *          (ALPHAR(j) + i*ALPHAI(j))/BETA(j), j=1,...,N, are the
// *          generalized eigenvalues of the matrix pencil A - wB.
// *          (Note that BETA(1:N) will always be non-negative, and no
// *          BETAI is necessary.)
// *
// *  Q       (input/output) DOUBLE PRECISION array, dimension (LDQ, N)
// *          If COMPQ='N', then Q will not be referenced.
// *          If COMPQ='V' or 'I', then the transpose of the orthogonal
// *             transformations which are applied to A and B on the left
// *             will be applied to the array Q on the right.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= 1.
// *          If COMPQ='V' or 'I', then LDQ >= N.
// *
// *  Z       (input/output) DOUBLE PRECISION array, dimension (LDZ, N)
// *          If COMPZ='N', then Z will not be referenced.
// *          If COMPZ='V' or 'I', then the orthogonal transformations
// *             which are applied to A and B on the right will be applied
// *             to the array Z on the right.
// *
// *  LDZ     (input) INTEGER
// *          The leading dimension of the array Z.  LDZ >= 1.
// *          If COMPZ='V' or 'I', then LDZ >= N.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO >= 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.  LWORK >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *          = 1,...,N: the QZ iteration did not converge.  (A,B) is not
// *                     in Schur form, but ALPHAR(i), ALPHAI(i), and
// *                     BETA(i), i=INFO+1,...,N should be correct.
// *          = N+1,...,2*N: the shift calculation failed.  (A,B) is not
// *                     in Schur form, but ALPHAR(i), ALPHAI(i), and
// *                     BETA(i), i=INFO-N+1,...,N should be correct.
// *          > 2*N:     various "impossible" errors.
// *
// *  Further Details
// *  ===============
// *
// *  Iteration counters:
// *
// *  JITER  -- counts iterations.
// *  IITER  -- counts iterations run since ILAST was last
// *            changed.  This is therefore reset only when a 1-by-1 or
// *            2-by-2 block deflates off the bottom.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
// *    $                     SAFETY = 1.0E+0 )
static double half= 0.5e+0;
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double safety= 1.0e+2;
// *     ..
// *     .. Local Scalars ..
static boolean ilazr2= false;
static boolean ilazro= false;
static boolean ilpivt= false;
static boolean ilq= false;
static boolean ilschr= false;
static boolean ilz= false;
static int icompq= 0;
static int icompz= 0;
static int ifirst= 0;
static int ifrstm= 0;
static int iiter= 0;
static int ilast= 0;
static int ilastm= 0;
static int in= 0;
static int ischur= 0;
static int istart= 0;
static int j= 0;
static int jc= 0;
static int jch= 0;
static int jiter= 0;
static int jr= 0;
static int maxit= 0;
static double a11= 0.0;
static double a12= 0.0;
static double a1i= 0.0;
static double a1r= 0.0;
static double a21= 0.0;
static double a22= 0.0;
static double a2i= 0.0;
static double a2r= 0.0;
static double ad11= 0.0;
static double ad11l= 0.0;
static double ad12= 0.0;
static double ad12l= 0.0;
static double ad21= 0.0;
static double ad21l= 0.0;
static double ad22= 0.0;
static double ad22l= 0.0;
static double ad32l= 0.0;
static double an= 0.0;
static double anorm= 0.0;
static double ascale= 0.0;
static double atol= 0.0;
static doubleW b11= new doubleW(0.0);
static double b1a= 0.0;
static double b1i= 0.0;
static double b1r= 0.0;
static doubleW b22= new doubleW(0.0);
static double b2a= 0.0;
static double b2i= 0.0;
static double b2r= 0.0;
static double bn= 0.0;
static double bnorm= 0.0;
static double bscale= 0.0;
static double btol= 0.0;
static doubleW c= new doubleW(0.0);
static double c11i= 0.0;
static double c11r= 0.0;
static double c12= 0.0;
static double c21= 0.0;
static double c22i= 0.0;
static double c22r= 0.0;
static doubleW cl= new doubleW(0.0);
static double cq= 0.0;
static doubleW cr= new doubleW(0.0);
static double cz= 0.0;
static double eshift= 0.0;
static doubleW s= new doubleW(0.0);
static doubleW s1= new doubleW(0.0);
static double s1inv= 0.0;
static doubleW s2= new doubleW(0.0);
static double safmax= 0.0;
static double safmin= 0.0;
static double scale= 0.0;
static doubleW sl= new doubleW(0.0);
static double sqi= 0.0;
static double sqr= 0.0;
static doubleW sr= new doubleW(0.0);
static double szi= 0.0;
static double szr= 0.0;
static double t= 0.0;
static doubleW tau= new doubleW(0.0);
static doubleW temp= new doubleW(0.0);
static doubleW temp2= new doubleW(0.0);
static double tempi= 0.0;
static doubleW tempr= new doubleW(0.0);
static double u1= 0.0;
static double u12= 0.0;
static double u12l= 0.0;
static double u2= 0.0;
static double ulp= 0.0;
static double vs= 0.0;
static double w11= 0.0;
static double w12= 0.0;
static double w21= 0.0;
static double w22= 0.0;
static double wabs= 0.0;
static doubleW wi= new doubleW(0.0);
static doubleW wr= new doubleW(0.0);
static doubleW wr2= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] v= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode JOB, COMPQ, COMPZ
// *

public static void dhgeqz (String job,
String compq,
String compz,
int n,
int ilo,
int ihi,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] alphar, int _alphar_offset,
double [] alphai, int _alphai_offset,
double [] beta, int _beta_offset,
double [] q, int _q_offset,
int ldq,
double [] z, int _z_offset,
int ldz,
double [] work, int _work_offset,
int lwork,
intW info)  {

if ((job.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0)))  {
    ilschr = false;
ischur = 1;
}              // Close if()
else if ((job.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    ilschr = true;
ischur = 2;
}              // Close else if()
else  {
  ischur = 0;
}              //  Close else.
// *
if ((compq.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ilq = false;
icompq = 1;
}              // Close if()
else if ((compq.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ilq = true;
icompq = 2;
}              // Close else if()
else if ((compq.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    ilq = true;
icompq = 3;
}              // Close else if()
else  {
  icompq = 0;
}              //  Close else.
// *
if ((compz.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ilz = false;
icompz = 1;
}              // Close if()
else if ((compz.toLowerCase().charAt(0) == "V".toLowerCase().charAt(0)))  {
    ilz = true;
icompz = 2;
}              // Close else if()
else if ((compz.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    ilz = true;
icompz = 3;
}              // Close else if()
else  {
  icompz = 0;
}              //  Close else.
// *
// *     Check Argument Values
// *
info.val = 0;
if (ischur == 0)  {
    info.val = -1;
}              // Close if()
else if (icompq == 0)  {
    info.val = -2;
}              // Close else if()
else if (icompz == 0)  {
    info.val = -3;
}              // Close else if()
else if (n < 0)  {
    info.val = -4;
}              // Close else if()
else if (ilo < 1)  {
    info.val = -5;
}              // Close else if()
else if (ihi > n || ihi < ilo-1)  {
    info.val = -6;
}              // Close else if()
else if (lda < n)  {
    info.val = -8;
}              // Close else if()
else if (ldb < n)  {
    info.val = -10;
}              // Close else if()
else if (ldq < 1 || (ilq && ldq < n))  {
    info.val = -15;
}              // Close else if()
else if (ldz < 1 || (ilz && ldz < n))  {
    info.val = -17;
}              // Close else if()
else if (lwork < Math.max(1, n) )  {
    info.val = -19;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DHGEQZ",-info.val);
Dummy.go_to("Dhgeqz",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n <= 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dhgeqz",999999);
}              // Close if()
// *
// *     Initialize Q and Z
// *
if (icompq == 3)  
    Dlaset.dlaset("Full",n,n,zero,one,q,_q_offset,ldq);
if (icompz == 3)  
    Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldz);
// *
// *     Machine Constants
// *
in = ihi+1-ilo;
safmin = Dlamch.dlamch("S");
safmax = one/safmin;
ulp = Dlamch.dlamch("E")*Dlamch.dlamch("B");
anorm = Dlanhs.dlanhs("F",in,a,(ilo)- 1+(ilo- 1)*lda+ _a_offset,lda,work,_work_offset);
bnorm = Dlanhs.dlanhs("F",in,b,(ilo)- 1+(ilo- 1)*ldb+ _b_offset,ldb,work,_work_offset);
atol = Math.max(safmin, ulp*anorm) ;
btol = Math.max(safmin, ulp*bnorm) ;
ascale = one/Math.max(safmin, anorm) ;
bscale = one/Math.max(safmin, bnorm) ;
// *
// *     Set Eigenvalues IHI+1:N
// *
{
forloop30:
for (j = ihi+1; j <= n; j++) {
if (b[(j)- 1+(j- 1)*ldb+ _b_offset] < zero)  {
    if (ilschr)  {
    {
forloop10:
for (jr = 1; jr <= j; jr++) {
a[(jr)- 1+(j- 1)*lda+ _a_offset] = -a[(jr)- 1+(j- 1)*lda+ _a_offset];
b[(jr)- 1+(j- 1)*ldb+ _b_offset] = -b[(jr)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  a[(j)- 1+(j- 1)*lda+ _a_offset] = -a[(j)- 1+(j- 1)*lda+ _a_offset];
b[(j)- 1+(j- 1)*ldb+ _b_offset] = -b[(j)- 1+(j- 1)*ldb+ _b_offset];
}              //  Close else.
if (ilz)  {
    {
forloop20:
for (jr = 1; jr <= n; jr++) {
z[(jr)- 1+(j- 1)*ldz+ _z_offset] = -z[(jr)- 1+(j- 1)*ldz+ _z_offset];
Dummy.label("Dhgeqz",20);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
alphar[(j)- 1+ _alphar_offset] = a[(j)- 1+(j- 1)*lda+ _a_offset];
alphai[(j)- 1+ _alphai_offset] = zero;
beta[(j)- 1+ _beta_offset] = b[(j)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",30);
}              //  Close for() loop. 
}
// *
// *     If IHI < ILO, skip QZ steps
// *
if (ihi < ilo)  
    Dummy.go_to("Dhgeqz",380);
// *
// *     MAIN QZ ITERATION LOOP
// *
// *     Initialize dynamic indices
// *
// *     Eigenvalues ILAST+1:N have been found.
// *        Column operations modify rows IFRSTM:whatever.
// *        Row operations modify columns whatever:ILASTM.
// *
// *     If only eigenvalues are being computed, then
// *        IFRSTM is the row of the last splitting row above row ILAST;
// *        this is always at least ILO.
// *     IITER counts iterations since the last eigenvalue was found,
// *        to tell when to use an extraordinary shift.
// *     MAXIT is the maximum number of QZ sweeps allowed.
// *
ilast = ihi;
if (ilschr)  {
    ifrstm = 1;
ilastm = n;
}              // Close if()
else  {
  ifrstm = ilo;
ilastm = ihi;
}              //  Close else.
iiter = 0;
eshift = zero;
maxit = 30*(ihi-ilo+1);
// *
{
forloop360:
for (jiter = 1; jiter <= maxit; jiter++) {
// *
// *        Split the matrix if possible.
// *
// *        Two tests:
// *           1: A(j,j-1)=0  or  j=ILO
// *           2: B(j,j)=0
// *
if (ilast == ilo)  {
    // *
// *           Special case: j=ILAST
// *
Dummy.go_to("Dhgeqz",80);
}              // Close if()
else  {
  if (Math.abs(a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset]) <= atol)  {
    a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset] = zero;
Dummy.go_to("Dhgeqz",80);
}              // Close if()
}              //  Close else.
// *
if (Math.abs(b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset]) <= btol)  {
    b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset] = zero;
Dummy.go_to("Dhgeqz",70);
}              // Close if()
// *
// *        General case: j<ILAST
// *
{
int _j_inc = -1;
forloop60:
for (j = ilast-1; j >= ilo; j += _j_inc) {
// *
// *           Test 1: for A(j,j-1)=0 or j=ILO
// *
if (j == ilo)  {
    ilazro = true;
}              // Close if()
else  {
  if (Math.abs(a[(j)- 1+(j-1- 1)*lda+ _a_offset]) <= atol)  {
    a[(j)- 1+(j-1- 1)*lda+ _a_offset] = zero;
ilazro = true;
}              // Close if()
else  {
  ilazro = false;
}              //  Close else.
}              //  Close else.
// *
// *           Test 2: for B(j,j)=0
// *
if (Math.abs(b[(j)- 1+(j- 1)*ldb+ _b_offset]) < btol)  {
    b[(j)- 1+(j- 1)*ldb+ _b_offset] = zero;
// *
// *              Test 1a: Check for 2 consecutive small subdiagonals in A
// *
ilazr2 = false;
if (!ilazro)  {
    temp.val = Math.abs(a[(j)- 1+(j-1- 1)*lda+ _a_offset]);
temp2.val = Math.abs(a[(j)- 1+(j- 1)*lda+ _a_offset]);
tempr.val = Math.max(temp.val, temp2.val) ;
if (tempr.val < one && tempr.val != zero)  {
    temp.val = temp.val/tempr.val;
temp2.val = temp2.val/tempr.val;
}              // Close if()
if (temp.val*(ascale*Math.abs(a[(j+1)- 1+(j- 1)*lda+ _a_offset])) <= temp2.val*(ascale*atol))  
    ilazr2 = true;
}              // Close if()
// *
// *              If both tests pass (1 & 2), i.e., the leading diagonal
// *              element of B in the block is zero, split a 1x1 block off
// *              at the top. (I.e., at the J-th row/column) The leading
// *              diagonal element of the remainder can also be zero, so
// *              this may have to be done repeatedly.
// *
if (ilazro || ilazr2)  {
    {
forloop40:
for (jch = j; jch <= ilast-1; jch++) {
temp.val = a[(jch)- 1+(jch- 1)*lda+ _a_offset];
dlartg_adapter(temp.val,a[(jch+1)- 1+(jch- 1)*lda+ _a_offset],c,s,a,(jch)- 1+(jch- 1)*lda+ _a_offset);
a[(jch+1)- 1+(jch- 1)*lda+ _a_offset] = zero;
Drot.drot(ilastm-jch,a,(jch)- 1+(jch+1- 1)*lda+ _a_offset,lda,a,(jch+1)- 1+(jch+1- 1)*lda+ _a_offset,lda,c.val,s.val);
Drot.drot(ilastm-jch,b,(jch)- 1+(jch+1- 1)*ldb+ _b_offset,ldb,b,(jch+1)- 1+(jch+1- 1)*ldb+ _b_offset,ldb,c.val,s.val);
if (ilq)  
    Drot.drot(n,q,(1)- 1+(jch- 1)*ldq+ _q_offset,1,q,(1)- 1+(jch+1- 1)*ldq+ _q_offset,1,c.val,s.val);
if (ilazr2)  
    a[(jch)- 1+(jch-1- 1)*lda+ _a_offset] = a[(jch)- 1+(jch-1- 1)*lda+ _a_offset]*c.val;
ilazr2 = false;
if (Math.abs(b[(jch+1)- 1+(jch+1- 1)*ldb+ _b_offset]) >= btol)  {
    if (jch+1 >= ilast)  {
    Dummy.go_to("Dhgeqz",80);
}              // Close if()
else  {
  ifirst = jch+1;
Dummy.go_to("Dhgeqz",110);
}              //  Close else.
}              // Close if()
b[(jch+1)- 1+(jch+1- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dhgeqz",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dhgeqz",70);
}              // Close if()
else  {
  // *
// *                 Only test 2 passed -- chase the zero to B(ILAST,ILAST)
// *                 Then process as in the case B(ILAST,ILAST)=0
// *
{
forloop50:
for (jch = j; jch <= ilast-1; jch++) {
temp.val = b[(jch)- 1+(jch+1- 1)*ldb+ _b_offset];
dlartg_adapter(temp.val,b[(jch+1)- 1+(jch+1- 1)*ldb+ _b_offset],c,s,b,(jch)- 1+(jch+1- 1)*ldb+ _b_offset);
b[(jch+1)- 1+(jch+1- 1)*ldb+ _b_offset] = zero;
if (jch < ilastm-1)  
    Drot.drot(ilastm-jch-1,b,(jch)- 1+(jch+2- 1)*ldb+ _b_offset,ldb,b,(jch+1)- 1+(jch+2- 1)*ldb+ _b_offset,ldb,c.val,s.val);
Drot.drot(ilastm-jch+2,a,(jch)- 1+(jch-1- 1)*lda+ _a_offset,lda,a,(jch+1)- 1+(jch-1- 1)*lda+ _a_offset,lda,c.val,s.val);
if (ilq)  
    Drot.drot(n,q,(1)- 1+(jch- 1)*ldq+ _q_offset,1,q,(1)- 1+(jch+1- 1)*ldq+ _q_offset,1,c.val,s.val);
temp.val = a[(jch+1)- 1+(jch- 1)*lda+ _a_offset];
dlartg_adapter(temp.val,a[(jch+1)- 1+(jch-1- 1)*lda+ _a_offset],c,s,a,(jch+1)- 1+(jch- 1)*lda+ _a_offset);
a[(jch+1)- 1+(jch-1- 1)*lda+ _a_offset] = zero;
Drot.drot(jch+1-ifrstm,a,(ifrstm)- 1+(jch- 1)*lda+ _a_offset,1,a,(ifrstm)- 1+(jch-1- 1)*lda+ _a_offset,1,c.val,s.val);
Drot.drot(jch-ifrstm,b,(ifrstm)- 1+(jch- 1)*ldb+ _b_offset,1,b,(ifrstm)- 1+(jch-1- 1)*ldb+ _b_offset,1,c.val,s.val);
if (ilz)  
    Drot.drot(n,z,(1)- 1+(jch- 1)*ldz+ _z_offset,1,z,(1)- 1+(jch-1- 1)*ldz+ _z_offset,1,c.val,s.val);
Dummy.label("Dhgeqz",50);
}              //  Close for() loop. 
}
Dummy.go_to("Dhgeqz",70);
}              //  Close else.
}              // Close if()
else if (ilazro)  {
    // *
// *              Only test 1 passed -- work on J:ILAST
// *
ifirst = j;
Dummy.go_to("Dhgeqz",110);
}              // Close else if()
// *
// *           Neither test passed -- try next J
// *
Dummy.label("Dhgeqz",60);
}              //  Close for() loop. 
}
// *
// *        (Drop-through is "impossible")
// *
info.val = n+1;
Dummy.go_to("Dhgeqz",420);
// *
// *        B(ILAST,ILAST)=0 -- clear A(ILAST,ILAST-1) to split off a
// *        1x1 block.
// *
label70:
   Dummy.label("Dhgeqz",70);
temp.val = a[(ilast)- 1+(ilast- 1)*lda+ _a_offset];
dlartg_adapter(temp.val,a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset],c,s,a,(ilast)- 1+(ilast- 1)*lda+ _a_offset);
a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset] = zero;
Drot.drot(ilast-ifrstm,a,(ifrstm)- 1+(ilast- 1)*lda+ _a_offset,1,a,(ifrstm)- 1+(ilast-1- 1)*lda+ _a_offset,1,c.val,s.val);
Drot.drot(ilast-ifrstm,b,(ifrstm)- 1+(ilast- 1)*ldb+ _b_offset,1,b,(ifrstm)- 1+(ilast-1- 1)*ldb+ _b_offset,1,c.val,s.val);
if (ilz)  
    Drot.drot(n,z,(1)- 1+(ilast- 1)*ldz+ _z_offset,1,z,(1)- 1+(ilast-1- 1)*ldz+ _z_offset,1,c.val,s.val);
// *
// *        A(ILAST,ILAST-1)=0 -- Standardize B, set ALPHAR, ALPHAI,
// *                              and BETA
// *
label80:
   Dummy.label("Dhgeqz",80);
if (b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset] < zero)  {
    if (ilschr)  {
    {
forloop90:
for (j = ifrstm; j <= ilast; j++) {
a[(j)- 1+(ilast- 1)*lda+ _a_offset] = -a[(j)- 1+(ilast- 1)*lda+ _a_offset];
b[(j)- 1+(ilast- 1)*ldb+ _b_offset] = -b[(j)- 1+(ilast- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",90);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  a[(ilast)- 1+(ilast- 1)*lda+ _a_offset] = -a[(ilast)- 1+(ilast- 1)*lda+ _a_offset];
b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset] = -b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset];
}              //  Close else.
if (ilz)  {
    {
forloop100:
for (j = 1; j <= n; j++) {
z[(j)- 1+(ilast- 1)*ldz+ _z_offset] = -z[(j)- 1+(ilast- 1)*ldz+ _z_offset];
Dummy.label("Dhgeqz",100);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
alphar[(ilast)- 1+ _alphar_offset] = a[(ilast)- 1+(ilast- 1)*lda+ _a_offset];
alphai[(ilast)- 1+ _alphai_offset] = zero;
beta[(ilast)- 1+ _beta_offset] = b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset];
// *
// *        Go to next block -- exit if finished.
// *
ilast = ilast-1;
if (ilast < ilo)  
    Dummy.go_to("Dhgeqz",380);
// *
// *        Reset counters
// *
iiter = 0;
eshift = zero;
if (!ilschr)  {
    ilastm = ilast;
if (ifrstm > ilast)  
    ifrstm = ilo;
}              // Close if()
Dummy.go_to("Dhgeqz",350);
// *
// *        QZ step
// *
// *        This iteration only involves rows/columns IFIRST:ILAST. We
// *        assume IFIRST < ILAST, and that the diagonal of B is non-zero.
// *
label110:
   Dummy.label("Dhgeqz",110);
iiter = iiter+1;
if (!ilschr)  {
    ifrstm = ifirst;
}              // Close if()
// *
// *        Compute single shifts.
// *
// *        At this point, IFIRST < ILAST, and the diagonal elements of
// *        B(IFIRST:ILAST,IFIRST,ILAST) are larger than BTOL (in
// *        magnitude)
// *
if ((iiter/10)*10 == iiter)  {
    // *
// *           Exceptional shift.  Chosen for no particularly good reason.
// *           (Single shift only.)
// *
if (((double)(maxit)*safmin)*Math.abs(a[(ilast-1)- 1+(ilast- 1)*lda+ _a_offset]) < Math.abs(b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset]))  {
    eshift = eshift+a[(ilast-1)- 1+(ilast- 1)*lda+ _a_offset]/b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset];
}              // Close if()
else  {
  eshift = eshift+one/(safmin*(double)(maxit));
}              //  Close else.
s1.val = one;
wr.val = eshift;
// *
}              // Close if()
else  {
  // *
// *           Shifts based on the generalized eigenvalues of the
// *           bottom-right 2x2 block of A and B. The first eigenvalue
// *           returned by DLAG2 is the Wilkinson shift (AEP p.512),
// *
Dlag2.dlag2(a,(ilast-1)- 1+(ilast-1- 1)*lda+ _a_offset,lda,b,(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset,ldb,safmin*safety,s1,s2,wr,wr2,wi);
// *
temp.val = Math.max(s1.val, safmin*Math.max((one) > (Math.abs(wr.val)) ? (one) : (Math.abs(wr.val)), Math.abs(wi.val))) ;
if (wi.val != zero)  
    Dummy.go_to("Dhgeqz",200);
}              //  Close else.
// *
// *        Fiddle with shift to avoid overflow
// *
temp.val = Math.min(ascale, one) *(half*safmax);
if (s1.val > temp.val)  {
    scale = temp.val/s1.val;
}              // Close if()
else  {
  scale = one;
}              //  Close else.
// *
temp.val = Math.min(bscale, one) *(half*safmax);
if (Math.abs(wr.val) > temp.val)  
    scale = Math.min(scale, temp.val/Math.abs(wr.val)) ;
s1.val = scale*s1.val;
wr.val = scale*wr.val;
// *
// *        Now check for two consecutive small subdiagonals.
// *
{
int _j_inc = -1;
forloop120:
for (j = ilast-1; j >= ifirst+1; j += _j_inc) {
istart = j;
temp.val = Math.abs(s1.val*a[(j)- 1+(j-1- 1)*lda+ _a_offset]);
temp2.val = Math.abs(s1.val*a[(j)- 1+(j- 1)*lda+ _a_offset]-wr.val*b[(j)- 1+(j- 1)*ldb+ _b_offset]);
tempr.val = Math.max(temp.val, temp2.val) ;
if (tempr.val < one && tempr.val != zero)  {
    temp.val = temp.val/tempr.val;
temp2.val = temp2.val/tempr.val;
}              // Close if()
if (Math.abs((ascale*a[(j+1)- 1+(j- 1)*lda+ _a_offset])*temp.val) <= (ascale*atol)*temp2.val)  
    Dummy.go_to("Dhgeqz",130);
Dummy.label("Dhgeqz",120);
}              //  Close for() loop. 
}
// *
istart = ifirst;
label130:
   Dummy.label("Dhgeqz",130);
// *
// *        Do an implicit single-shift QZ sweep.
// *
// *        Initial Q
// *
temp.val = s1.val*a[(istart)- 1+(istart- 1)*lda+ _a_offset]-wr.val*b[(istart)- 1+(istart- 1)*ldb+ _b_offset];
temp2.val = s1.val*a[(istart+1)- 1+(istart- 1)*lda+ _a_offset];
Dlartg.dlartg(temp.val,temp2.val,c,s,tempr);
// *
// *        Sweep
// *
{
forloop190:
for (j = istart; j <= ilast-1; j++) {
if (j > istart)  {
    temp.val = a[(j)- 1+(j-1- 1)*lda+ _a_offset];
dlartg_adapter(temp.val,a[(j+1)- 1+(j-1- 1)*lda+ _a_offset],c,s,a,(j)- 1+(j-1- 1)*lda+ _a_offset);
a[(j+1)- 1+(j-1- 1)*lda+ _a_offset] = zero;
}              // Close if()
// *
{
forloop140:
for (jc = j; jc <= ilastm; jc++) {
temp.val = c.val*a[(j)- 1+(jc- 1)*lda+ _a_offset]+s.val*a[(j+1)- 1+(jc- 1)*lda+ _a_offset];
a[(j+1)- 1+(jc- 1)*lda+ _a_offset] = -s.val*a[(j)- 1+(jc- 1)*lda+ _a_offset]+c.val*a[(j+1)- 1+(jc- 1)*lda+ _a_offset];
a[(j)- 1+(jc- 1)*lda+ _a_offset] = temp.val;
temp2.val = c.val*b[(j)- 1+(jc- 1)*ldb+ _b_offset]+s.val*b[(j+1)- 1+(jc- 1)*ldb+ _b_offset];
b[(j+1)- 1+(jc- 1)*ldb+ _b_offset] = -s.val*b[(j)- 1+(jc- 1)*ldb+ _b_offset]+c.val*b[(j+1)- 1+(jc- 1)*ldb+ _b_offset];
b[(j)- 1+(jc- 1)*ldb+ _b_offset] = temp2.val;
Dummy.label("Dhgeqz",140);
}              //  Close for() loop. 
}
if (ilq)  {
    {
forloop150:
for (jr = 1; jr <= n; jr++) {
temp.val = c.val*q[(jr)- 1+(j- 1)*ldq+ _q_offset]+s.val*q[(jr)- 1+(j+1- 1)*ldq+ _q_offset];
q[(jr)- 1+(j+1- 1)*ldq+ _q_offset] = -s.val*q[(jr)- 1+(j- 1)*ldq+ _q_offset]+c.val*q[(jr)- 1+(j+1- 1)*ldq+ _q_offset];
q[(jr)- 1+(j- 1)*ldq+ _q_offset] = temp.val;
Dummy.label("Dhgeqz",150);
}              //  Close for() loop. 
}
}              // Close if()
// *
temp.val = b[(j+1)- 1+(j+1- 1)*ldb+ _b_offset];
dlartg_adapter(temp.val,b[(j+1)- 1+(j- 1)*ldb+ _b_offset],c,s,b,(j+1)- 1+(j+1- 1)*ldb+ _b_offset);
b[(j+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
// *
{
forloop160:
for (jr = ifrstm; jr <= Math.min(j+2, ilast) ; jr++) {
temp.val = c.val*a[(jr)- 1+(j+1- 1)*lda+ _a_offset]+s.val*a[(jr)- 1+(j- 1)*lda+ _a_offset];
a[(jr)- 1+(j- 1)*lda+ _a_offset] = -s.val*a[(jr)- 1+(j+1- 1)*lda+ _a_offset]+c.val*a[(jr)- 1+(j- 1)*lda+ _a_offset];
a[(jr)- 1+(j+1- 1)*lda+ _a_offset] = temp.val;
Dummy.label("Dhgeqz",160);
}              //  Close for() loop. 
}
{
forloop170:
for (jr = ifrstm; jr <= j; jr++) {
temp.val = c.val*b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]+s.val*b[(jr)- 1+(j- 1)*ldb+ _b_offset];
b[(jr)- 1+(j- 1)*ldb+ _b_offset] = -s.val*b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]+c.val*b[(jr)- 1+(j- 1)*ldb+ _b_offset];
b[(jr)- 1+(j+1- 1)*ldb+ _b_offset] = temp.val;
Dummy.label("Dhgeqz",170);
}              //  Close for() loop. 
}
if (ilz)  {
    {
forloop180:
for (jr = 1; jr <= n; jr++) {
temp.val = c.val*z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]+s.val*z[(jr)- 1+(j- 1)*ldz+ _z_offset];
z[(jr)- 1+(j- 1)*ldz+ _z_offset] = -s.val*z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]+c.val*z[(jr)- 1+(j- 1)*ldz+ _z_offset];
z[(jr)- 1+(j+1- 1)*ldz+ _z_offset] = temp.val;
Dummy.label("Dhgeqz",180);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.label("Dhgeqz",190);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dhgeqz",350);
// *
// *        Use Francis double-shift
// *
// *        Note: the Francis double-shift should work with real shifts,
// *              but only if the block is at least 3x3.
// *              This code may break if this point is reached with
// *              a 2x2 block with real eigenvalues.
// *
label200:
   Dummy.label("Dhgeqz",200);
if (ifirst+1 == ilast)  {
    // *
// *           Special case -- 2x2 block with complex eigenvectors
// *
// *           Step 1: Standardize, that is, rotate so that
// *
// *                       ( B11  0  )
// *                   B = (         )  with B11 non-negative.
// *                       (  0  B22 )
// *
Dlasv2.dlasv2(b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset],b[(ilast-1)- 1+(ilast- 1)*ldb+ _b_offset],b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset],b22,b11,sr,cr,sl,cl);
// *
if (b11.val < zero)  {
    cr.val = -cr.val;
sr.val = -sr.val;
b11.val = -b11.val;
b22.val = -b22.val;
}              // Close if()
// *
Drot.drot(ilastm+1-ifirst,a,(ilast-1)- 1+(ilast-1- 1)*lda+ _a_offset,lda,a,(ilast)- 1+(ilast-1- 1)*lda+ _a_offset,lda,cl.val,sl.val);
Drot.drot(ilast+1-ifrstm,a,(ifrstm)- 1+(ilast-1- 1)*lda+ _a_offset,1,a,(ifrstm)- 1+(ilast- 1)*lda+ _a_offset,1,cr.val,sr.val);
// *
if (ilast < ilastm)  
    Drot.drot(ilastm-ilast,b,(ilast-1)- 1+(ilast+1- 1)*ldb+ _b_offset,ldb,b,(ilast)- 1+(ilast+1- 1)*ldb+ _b_offset,lda,cl.val,sl.val);
if (ifrstm < ilast-1)  
    Drot.drot(ifirst-ifrstm,b,(ifrstm)- 1+(ilast-1- 1)*ldb+ _b_offset,1,b,(ifrstm)- 1+(ilast- 1)*ldb+ _b_offset,1,cr.val,sr.val);
// *
if (ilq)  
    Drot.drot(n,q,(1)- 1+(ilast-1- 1)*ldq+ _q_offset,1,q,(1)- 1+(ilast- 1)*ldq+ _q_offset,1,cl.val,sl.val);
if (ilz)  
    Drot.drot(n,z,(1)- 1+(ilast-1- 1)*ldz+ _z_offset,1,z,(1)- 1+(ilast- 1)*ldz+ _z_offset,1,cr.val,sr.val);
// *
b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset] = b11.val;
b[(ilast-1)- 1+(ilast- 1)*ldb+ _b_offset] = zero;
b[(ilast)- 1+(ilast-1- 1)*ldb+ _b_offset] = zero;
b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset] = b22.val;
// *
// *           If B22 is negative, negate column ILAST
// *
if (b22.val < zero)  {
    {
forloop210:
for (j = ifrstm; j <= ilast; j++) {
a[(j)- 1+(ilast- 1)*lda+ _a_offset] = -a[(j)- 1+(ilast- 1)*lda+ _a_offset];
b[(j)- 1+(ilast- 1)*ldb+ _b_offset] = -b[(j)- 1+(ilast- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",210);
}              //  Close for() loop. 
}
// *
if (ilz)  {
    {
forloop220:
for (j = 1; j <= n; j++) {
z[(j)- 1+(ilast- 1)*ldz+ _z_offset] = -z[(j)- 1+(ilast- 1)*ldz+ _z_offset];
Dummy.label("Dhgeqz",220);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
// *           Step 2: Compute ALPHAR, ALPHAI, and BETA (see refs.)
// *
// *           Recompute shift
// *
Dlag2.dlag2(a,(ilast-1)- 1+(ilast-1- 1)*lda+ _a_offset,lda,b,(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset,ldb,safmin*safety,s1,temp,wr,temp2,wi);
// *
// *           If standardization has perturbed the shift onto real line,
// *           do another (real single-shift) QR step.
// *
if (wi.val == zero)  
    Dummy.go_to("Dhgeqz",350);
s1inv = one/s1.val;
// *
// *           Do EISPACK (QZVAL) computation of alpha and beta
// *
a11 = a[(ilast-1)- 1+(ilast-1- 1)*lda+ _a_offset];
a21 = a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset];
a12 = a[(ilast-1)- 1+(ilast- 1)*lda+ _a_offset];
a22 = a[(ilast)- 1+(ilast- 1)*lda+ _a_offset];
// *
// *           Compute complex Givens rotation on right
// *           (Assume some element of C = (sA - wB) > unfl )
// *                            __
// *           (sA - wB) ( CZ   -SZ )
// *                     ( SZ    CZ )
// *
c11r = s1.val*a11-wr.val*b11.val;
c11i = -wi.val*b11.val;
c12 = s1.val*a12;
c21 = s1.val*a21;
c22r = s1.val*a22-wr.val*b22.val;
c22i = -wi.val*b22.val;
// *
if (Math.abs(c11r)+Math.abs(c11i)+Math.abs(c12) > Math.abs(c21)+Math.abs(c22r)+Math.abs(c22i))  {
    t = Dlapy3.dlapy3(c12,c11r,c11i);
cz = c12/t;
szr = -c11r/t;
szi = -c11i/t;
}              // Close if()
else  {
  cz = Dlapy2.dlapy2(c22r,c22i);
if (cz <= safmin)  {
    cz = zero;
szr = one;
szi = zero;
}              // Close if()
else  {
  tempr.val = c22r/cz;
tempi = c22i/cz;
t = Dlapy2.dlapy2(cz,c21);
cz = cz/t;
szr = -c21*tempr.val/t;
szi = c21*tempi/t;
}              //  Close else.
}              //  Close else.
// *
// *           Compute Givens rotation on left
// *
// *           (  CQ   SQ )
// *           (  __      )  A or B
// *           ( -SQ   CQ )
// *
an = Math.abs(a11)+Math.abs(a12)+Math.abs(a21)+Math.abs(a22);
bn = Math.abs(b11.val)+Math.abs(b22.val);
wabs = Math.abs(wr.val)+Math.abs(wi.val);
if (s1.val*an > wabs*bn)  {
    cq = cz*b11.val;
sqr = szr*b22.val;
sqi = -szi*b22.val;
}              // Close if()
else  {
  a1r = cz*a11+szr*a12;
a1i = szi*a12;
a2r = cz*a21+szr*a22;
a2i = szi*a22;
cq = Dlapy2.dlapy2(a1r,a1i);
if (cq <= safmin)  {
    cq = zero;
sqr = one;
sqi = zero;
}              // Close if()
else  {
  tempr.val = a1r/cq;
tempi = a1i/cq;
sqr = tempr.val*a2r+tempi*a2i;
sqi = tempi*a2r-tempr.val*a2i;
}              //  Close else.
}              //  Close else.
t = Dlapy3.dlapy3(cq,sqr,sqi);
cq = cq/t;
sqr = sqr/t;
sqi = sqi/t;
// *
// *           Compute diagonal elements of QBZ
// *
tempr.val = sqr*szr-sqi*szi;
tempi = sqr*szi+sqi*szr;
b1r = cq*cz*b11.val+tempr.val*b22.val;
b1i = tempi*b22.val;
b1a = Dlapy2.dlapy2(b1r,b1i);
b2r = cq*cz*b22.val+tempr.val*b11.val;
b2i = -tempi*b11.val;
b2a = Dlapy2.dlapy2(b2r,b2i);
// *
// *           Normalize so beta > 0, and Im( alpha1 ) > 0
// *
beta[(ilast-1)- 1+ _beta_offset] = b1a;
beta[(ilast)- 1+ _beta_offset] = b2a;
alphar[(ilast-1)- 1+ _alphar_offset] = (wr.val*b1a)*s1inv;
alphai[(ilast-1)- 1+ _alphai_offset] = (wi.val*b1a)*s1inv;
alphar[(ilast)- 1+ _alphar_offset] = (wr.val*b2a)*s1inv;
alphai[(ilast)- 1+ _alphai_offset] = -(wi.val*b2a)*s1inv;
// *
// *           Step 3: Go to next block -- exit if finished.
// *
ilast = ifirst-1;
if (ilast < ilo)  
    Dummy.go_to("Dhgeqz",380);
// *
// *           Reset counters
// *
iiter = 0;
eshift = zero;
if (!ilschr)  {
    ilastm = ilast;
if (ifrstm > ilast)  
    ifrstm = ilo;
}              // Close if()
Dummy.go_to("Dhgeqz",350);
}              // Close if()
else  {
  // *
// *           Usual case: 3x3 or larger block, using Francis implicit
// *                       double-shift
// *
// *                                    2
// *           Eigenvalue equation is  w  - c w + d = 0,
// *
// *                                         -1 2        -1
// *           so compute 1st column of  (A B  )  - c A B   + d
// *           using the formula in QZIT (from EISPACK)
// *
// *           We assume that the block is at least 3x3
// *
ad11 = (ascale*a[(ilast-1)- 1+(ilast-1- 1)*lda+ _a_offset])/(bscale*b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset]);
ad21 = (ascale*a[(ilast)- 1+(ilast-1- 1)*lda+ _a_offset])/(bscale*b[(ilast-1)- 1+(ilast-1- 1)*ldb+ _b_offset]);
ad12 = (ascale*a[(ilast-1)- 1+(ilast- 1)*lda+ _a_offset])/(bscale*b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset]);
ad22 = (ascale*a[(ilast)- 1+(ilast- 1)*lda+ _a_offset])/(bscale*b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset]);
u12 = b[(ilast-1)- 1+(ilast- 1)*ldb+ _b_offset]/b[(ilast)- 1+(ilast- 1)*ldb+ _b_offset];
ad11l = (ascale*a[(ifirst)- 1+(ifirst- 1)*lda+ _a_offset])/(bscale*b[(ifirst)- 1+(ifirst- 1)*ldb+ _b_offset]);
ad21l = (ascale*a[(ifirst+1)- 1+(ifirst- 1)*lda+ _a_offset])/(bscale*b[(ifirst)- 1+(ifirst- 1)*ldb+ _b_offset]);
ad12l = (ascale*a[(ifirst)- 1+(ifirst+1- 1)*lda+ _a_offset])/(bscale*b[(ifirst+1)- 1+(ifirst+1- 1)*ldb+ _b_offset]);
ad22l = (ascale*a[(ifirst+1)- 1+(ifirst+1- 1)*lda+ _a_offset])/(bscale*b[(ifirst+1)- 1+(ifirst+1- 1)*ldb+ _b_offset]);
ad32l = (ascale*a[(ifirst+2)- 1+(ifirst+1- 1)*lda+ _a_offset])/(bscale*b[(ifirst+1)- 1+(ifirst+1- 1)*ldb+ _b_offset]);
u12l = b[(ifirst)- 1+(ifirst+1- 1)*ldb+ _b_offset]/b[(ifirst+1)- 1+(ifirst+1- 1)*ldb+ _b_offset];
// *
v[(1)- 1] = (ad11-ad11l)*(ad22-ad11l)-ad12*ad21+ad21*u12*ad11l+(ad12l-ad11l*u12l)*ad21l;
v[(2)- 1] = ((ad22l-ad11l)-ad21l*u12l-(ad11-ad11l)-(ad22-ad11l)+ad21*u12)*ad21l;
v[(3)- 1] = ad32l*ad21l;
// *
istart = ifirst;
// *
dlarfg_adapter(3,v,(1)- 1,v,(2)- 1,1,tau);
v[(1)- 1] = one;
// *
// *           Sweep
// *
{
forloop290:
for (j = istart; j <= ilast-2; j++) {
// *
// *              All but last elements: use 3x3 Householder transforms.
// *
// *              Zero (j-1)st column of A
// *
if (j > istart)  {
    v[(1)- 1] = a[(j)- 1+(j-1- 1)*lda+ _a_offset];
v[(2)- 1] = a[(j+1)- 1+(j-1- 1)*lda+ _a_offset];
v[(3)- 1] = a[(j+2)- 1+(j-1- 1)*lda+ _a_offset];
// *
dlarfg_adapter(3,a,(j)- 1+(j-1- 1)*lda+ _a_offset,v,(2)- 1,1,tau);
v[(1)- 1] = one;
a[(j+1)- 1+(j-1- 1)*lda+ _a_offset] = zero;
a[(j+2)- 1+(j-1- 1)*lda+ _a_offset] = zero;
}              // Close if()
// *
{
forloop230:
for (jc = j; jc <= ilastm; jc++) {
temp.val = tau.val*(a[(j)- 1+(jc- 1)*lda+ _a_offset]+v[(2)- 1]*a[(j+1)- 1+(jc- 1)*lda+ _a_offset]+v[(3)- 1]*a[(j+2)- 1+(jc- 1)*lda+ _a_offset]);
a[(j)- 1+(jc- 1)*lda+ _a_offset] = a[(j)- 1+(jc- 1)*lda+ _a_offset]-temp.val;
a[(j+1)- 1+(jc- 1)*lda+ _a_offset] = a[(j+1)- 1+(jc- 1)*lda+ _a_offset]-temp.val*v[(2)- 1];
a[(j+2)- 1+(jc- 1)*lda+ _a_offset] = a[(j+2)- 1+(jc- 1)*lda+ _a_offset]-temp.val*v[(3)- 1];
temp2.val = tau.val*(b[(j)- 1+(jc- 1)*ldb+ _b_offset]+v[(2)- 1]*b[(j+1)- 1+(jc- 1)*ldb+ _b_offset]+v[(3)- 1]*b[(j+2)- 1+(jc- 1)*ldb+ _b_offset]);
b[(j)- 1+(jc- 1)*ldb+ _b_offset] = b[(j)- 1+(jc- 1)*ldb+ _b_offset]-temp2.val;
b[(j+1)- 1+(jc- 1)*ldb+ _b_offset] = b[(j+1)- 1+(jc- 1)*ldb+ _b_offset]-temp2.val*v[(2)- 1];
b[(j+2)- 1+(jc- 1)*ldb+ _b_offset] = b[(j+2)- 1+(jc- 1)*ldb+ _b_offset]-temp2.val*v[(3)- 1];
Dummy.label("Dhgeqz",230);
}              //  Close for() loop. 
}
if (ilq)  {
    {
forloop240:
for (jr = 1; jr <= n; jr++) {
temp.val = tau.val*(q[(jr)- 1+(j- 1)*ldq+ _q_offset]+v[(2)- 1]*q[(jr)- 1+(j+1- 1)*ldq+ _q_offset]+v[(3)- 1]*q[(jr)- 1+(j+2- 1)*ldq+ _q_offset]);
q[(jr)- 1+(j- 1)*ldq+ _q_offset] = q[(jr)- 1+(j- 1)*ldq+ _q_offset]-temp.val;
q[(jr)- 1+(j+1- 1)*ldq+ _q_offset] = q[(jr)- 1+(j+1- 1)*ldq+ _q_offset]-temp.val*v[(2)- 1];
q[(jr)- 1+(j+2- 1)*ldq+ _q_offset] = q[(jr)- 1+(j+2- 1)*ldq+ _q_offset]-temp.val*v[(3)- 1];
Dummy.label("Dhgeqz",240);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Zero j-th column of B (see DLAGBC for details)
// *
// *              Swap rows to pivot
// *
ilpivt = false;
temp.val = Math.max(Math.abs(b[(j+1)- 1+(j+1- 1)*ldb+ _b_offset]), Math.abs(b[(j+1)- 1+(j+2- 1)*ldb+ _b_offset])) ;
temp2.val = Math.max(Math.abs(b[(j+2)- 1+(j+1- 1)*ldb+ _b_offset]), Math.abs(b[(j+2)- 1+(j+2- 1)*ldb+ _b_offset])) ;
if (Math.max(temp.val, temp2.val)  < safmin)  {
    scale = zero;
u1 = one;
u2 = zero;
Dummy.go_to("Dhgeqz",250);
}              // Close if()
else if (temp.val >= temp2.val)  {
    w11 = b[(j+1)- 1+(j+1- 1)*ldb+ _b_offset];
w21 = b[(j+2)- 1+(j+1- 1)*ldb+ _b_offset];
w12 = b[(j+1)- 1+(j+2- 1)*ldb+ _b_offset];
w22 = b[(j+2)- 1+(j+2- 1)*ldb+ _b_offset];
u1 = b[(j+1)- 1+(j- 1)*ldb+ _b_offset];
u2 = b[(j+2)- 1+(j- 1)*ldb+ _b_offset];
}              // Close else if()
else  {
  w21 = b[(j+1)- 1+(j+1- 1)*ldb+ _b_offset];
w11 = b[(j+2)- 1+(j+1- 1)*ldb+ _b_offset];
w22 = b[(j+1)- 1+(j+2- 1)*ldb+ _b_offset];
w12 = b[(j+2)- 1+(j+2- 1)*ldb+ _b_offset];
u2 = b[(j+1)- 1+(j- 1)*ldb+ _b_offset];
u1 = b[(j+2)- 1+(j- 1)*ldb+ _b_offset];
}              //  Close else.
// *
// *              Swap columns if nec.
// *
if (Math.abs(w12) > Math.abs(w11))  {
    ilpivt = true;
temp.val = w12;
temp2.val = w22;
w12 = w11;
w22 = w21;
w11 = temp.val;
w21 = temp2.val;
}              // Close if()
// *
// *              LU-factor
// *
temp.val = w21/w11;
u2 = u2-temp.val*u1;
w22 = w22-temp.val*w12;
w21 = zero;
// *
// *              Compute SCALE
// *
scale = one;
if (Math.abs(w22) < safmin)  {
    scale = zero;
u2 = one;
u1 = -w12/w11;
Dummy.go_to("Dhgeqz",250);
}              // Close if()
if (Math.abs(w22) < Math.abs(u2))  
    scale = Math.abs(w22/u2);
if (Math.abs(w11) < Math.abs(u1))  
    scale = Math.min(scale, Math.abs(w11/u1)) ;
// *
// *              Solve
// *
u2 = (scale*u2)/w22;
u1 = (scale*u1-w12*u2)/w11;
// *
label250:
   Dummy.label("Dhgeqz",250);
if (ilpivt)  {
    temp.val = u2;
u2 = u1;
u1 = temp.val;
}              // Close if()
// *
// *              Compute Householder Vector
// *
t = Math.sqrt(Math.pow(scale, 2)+Math.pow(u1, 2)+Math.pow(u2, 2));
tau.val = one+scale/t;
vs = -one/(scale+t);
v[(1)- 1] = one;
v[(2)- 1] = vs*u1;
v[(3)- 1] = vs*u2;
// *
// *              Apply transformations from the right.
// *
{
forloop260:
for (jr = ifrstm; jr <= Math.min(j+3, ilast) ; jr++) {
temp.val = tau.val*(a[(jr)- 1+(j- 1)*lda+ _a_offset]+v[(2)- 1]*a[(jr)- 1+(j+1- 1)*lda+ _a_offset]+v[(3)- 1]*a[(jr)- 1+(j+2- 1)*lda+ _a_offset]);
a[(jr)- 1+(j- 1)*lda+ _a_offset] = a[(jr)- 1+(j- 1)*lda+ _a_offset]-temp.val;
a[(jr)- 1+(j+1- 1)*lda+ _a_offset] = a[(jr)- 1+(j+1- 1)*lda+ _a_offset]-temp.val*v[(2)- 1];
a[(jr)- 1+(j+2- 1)*lda+ _a_offset] = a[(jr)- 1+(j+2- 1)*lda+ _a_offset]-temp.val*v[(3)- 1];
Dummy.label("Dhgeqz",260);
}              //  Close for() loop. 
}
{
forloop270:
for (jr = ifrstm; jr <= j+2; jr++) {
temp.val = tau.val*(b[(jr)- 1+(j- 1)*ldb+ _b_offset]+v[(2)- 1]*b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]+v[(3)- 1]*b[(jr)- 1+(j+2- 1)*ldb+ _b_offset]);
b[(jr)- 1+(j- 1)*ldb+ _b_offset] = b[(jr)- 1+(j- 1)*ldb+ _b_offset]-temp.val;
b[(jr)- 1+(j+1- 1)*ldb+ _b_offset] = b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]-temp.val*v[(2)- 1];
b[(jr)- 1+(j+2- 1)*ldb+ _b_offset] = b[(jr)- 1+(j+2- 1)*ldb+ _b_offset]-temp.val*v[(3)- 1];
Dummy.label("Dhgeqz",270);
}              //  Close for() loop. 
}
if (ilz)  {
    {
forloop280:
for (jr = 1; jr <= n; jr++) {
temp.val = tau.val*(z[(jr)- 1+(j- 1)*ldz+ _z_offset]+v[(2)- 1]*z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]+v[(3)- 1]*z[(jr)- 1+(j+2- 1)*ldz+ _z_offset]);
z[(jr)- 1+(j- 1)*ldz+ _z_offset] = z[(jr)- 1+(j- 1)*ldz+ _z_offset]-temp.val;
z[(jr)- 1+(j+1- 1)*ldz+ _z_offset] = z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]-temp.val*v[(2)- 1];
z[(jr)- 1+(j+2- 1)*ldz+ _z_offset] = z[(jr)- 1+(j+2- 1)*ldz+ _z_offset]-temp.val*v[(3)- 1];
Dummy.label("Dhgeqz",280);
}              //  Close for() loop. 
}
}              // Close if()
b[(j+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
b[(j+2)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dhgeqz",290);
}              //  Close for() loop. 
}
// *
// *           Last elements: Use Givens rotations
// *
// *           Rotations from the left
// *
j = ilast-1;
temp.val = a[(j)- 1+(j-1- 1)*lda+ _a_offset];
dlartg_adapter(temp.val,a[(j+1)- 1+(j-1- 1)*lda+ _a_offset],c,s,a,(j)- 1+(j-1- 1)*lda+ _a_offset);
a[(j+1)- 1+(j-1- 1)*lda+ _a_offset] = zero;
// *
{
forloop300:
for (jc = j; jc <= ilastm; jc++) {
temp.val = c.val*a[(j)- 1+(jc- 1)*lda+ _a_offset]+s.val*a[(j+1)- 1+(jc- 1)*lda+ _a_offset];
a[(j+1)- 1+(jc- 1)*lda+ _a_offset] = -s.val*a[(j)- 1+(jc- 1)*lda+ _a_offset]+c.val*a[(j+1)- 1+(jc- 1)*lda+ _a_offset];
a[(j)- 1+(jc- 1)*lda+ _a_offset] = temp.val;
temp2.val = c.val*b[(j)- 1+(jc- 1)*ldb+ _b_offset]+s.val*b[(j+1)- 1+(jc- 1)*ldb+ _b_offset];
b[(j+1)- 1+(jc- 1)*ldb+ _b_offset] = -s.val*b[(j)- 1+(jc- 1)*ldb+ _b_offset]+c.val*b[(j+1)- 1+(jc- 1)*ldb+ _b_offset];
b[(j)- 1+(jc- 1)*ldb+ _b_offset] = temp2.val;
Dummy.label("Dhgeqz",300);
}              //  Close for() loop. 
}
if (ilq)  {
    {
forloop310:
for (jr = 1; jr <= n; jr++) {
temp.val = c.val*q[(jr)- 1+(j- 1)*ldq+ _q_offset]+s.val*q[(jr)- 1+(j+1- 1)*ldq+ _q_offset];
q[(jr)- 1+(j+1- 1)*ldq+ _q_offset] = -s.val*q[(jr)- 1+(j- 1)*ldq+ _q_offset]+c.val*q[(jr)- 1+(j+1- 1)*ldq+ _q_offset];
q[(jr)- 1+(j- 1)*ldq+ _q_offset] = temp.val;
Dummy.label("Dhgeqz",310);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *           Rotations from the right.
// *
temp.val = b[(j+1)- 1+(j+1- 1)*ldb+ _b_offset];
dlartg_adapter(temp.val,b[(j+1)- 1+(j- 1)*ldb+ _b_offset],c,s,b,(j+1)- 1+(j+1- 1)*ldb+ _b_offset);
b[(j+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
// *
{
forloop320:
for (jr = ifrstm; jr <= ilast; jr++) {
temp.val = c.val*a[(jr)- 1+(j+1- 1)*lda+ _a_offset]+s.val*a[(jr)- 1+(j- 1)*lda+ _a_offset];
a[(jr)- 1+(j- 1)*lda+ _a_offset] = -s.val*a[(jr)- 1+(j+1- 1)*lda+ _a_offset]+c.val*a[(jr)- 1+(j- 1)*lda+ _a_offset];
a[(jr)- 1+(j+1- 1)*lda+ _a_offset] = temp.val;
Dummy.label("Dhgeqz",320);
}              //  Close for() loop. 
}
{
forloop330:
for (jr = ifrstm; jr <= ilast-1; jr++) {
temp.val = c.val*b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]+s.val*b[(jr)- 1+(j- 1)*ldb+ _b_offset];
b[(jr)- 1+(j- 1)*ldb+ _b_offset] = -s.val*b[(jr)- 1+(j+1- 1)*ldb+ _b_offset]+c.val*b[(jr)- 1+(j- 1)*ldb+ _b_offset];
b[(jr)- 1+(j+1- 1)*ldb+ _b_offset] = temp.val;
Dummy.label("Dhgeqz",330);
}              //  Close for() loop. 
}
if (ilz)  {
    {
forloop340:
for (jr = 1; jr <= n; jr++) {
temp.val = c.val*z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]+s.val*z[(jr)- 1+(j- 1)*ldz+ _z_offset];
z[(jr)- 1+(j- 1)*ldz+ _z_offset] = -s.val*z[(jr)- 1+(j+1- 1)*ldz+ _z_offset]+c.val*z[(jr)- 1+(j- 1)*ldz+ _z_offset];
z[(jr)- 1+(j+1- 1)*ldz+ _z_offset] = temp.val;
Dummy.label("Dhgeqz",340);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *           End of Double-Shift code
// *
}              //  Close else.
// *
Dummy.go_to("Dhgeqz",350);
// *
// *        End of iteration loop
// *
label350:
   Dummy.label("Dhgeqz",350);
Dummy.label("Dhgeqz",360);
}              //  Close for() loop. 
}
// *
// *     Drop-through = non-convergence
// *
label370:
   Dummy.label("Dhgeqz",370);
info.val = ilast;
Dummy.go_to("Dhgeqz",420);
// *
// *     Successful completion of all QZ steps
// *
label380:
   Dummy.label("Dhgeqz",380);
// *
// *     Set Eigenvalues 1:ILO-1
// *
{
forloop410:
for (j = 1; j <= ilo-1; j++) {
if (b[(j)- 1+(j- 1)*ldb+ _b_offset] < zero)  {
    if (ilschr)  {
    {
forloop390:
for (jr = 1; jr <= j; jr++) {
a[(jr)- 1+(j- 1)*lda+ _a_offset] = -a[(jr)- 1+(j- 1)*lda+ _a_offset];
b[(jr)- 1+(j- 1)*ldb+ _b_offset] = -b[(jr)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",390);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  a[(j)- 1+(j- 1)*lda+ _a_offset] = -a[(j)- 1+(j- 1)*lda+ _a_offset];
b[(j)- 1+(j- 1)*ldb+ _b_offset] = -b[(j)- 1+(j- 1)*ldb+ _b_offset];
}              //  Close else.
if (ilz)  {
    {
forloop400:
for (jr = 1; jr <= n; jr++) {
z[(jr)- 1+(j- 1)*ldz+ _z_offset] = -z[(jr)- 1+(j- 1)*ldz+ _z_offset];
Dummy.label("Dhgeqz",400);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
alphar[(j)- 1+ _alphar_offset] = a[(j)- 1+(j- 1)*lda+ _a_offset];
alphai[(j)- 1+ _alphai_offset] = zero;
beta[(j)- 1+ _beta_offset] = b[(j)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dhgeqz",410);
}              //  Close for() loop. 
}
// *
// *     Normal Termination
// *
info.val = 0;
// *
// *     Exit (other than argument error) -- return optimal workspace size
// *
label420:
   Dummy.label("Dhgeqz",420);
work[(1)- 1+ _work_offset] = (double)(n);
Dummy.go_to("Dhgeqz",999999);
// *
// *     End of DHGEQZ
// *
Dummy.label("Dhgeqz",999999);
return;
   }
// adapter for dlartg
private static void dlartg_adapter(double arg0 ,double arg1 ,doubleW arg2 ,doubleW arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlartg.dlartg(arg0,arg1,arg2,arg3,_f2j_tmp4);

arg4[arg4_offset] = _f2j_tmp4.val;
}

// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,doubleW arg4 )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,arg4);

arg1[arg1_offset] = _f2j_tmp1.val;
}

} // End class.
