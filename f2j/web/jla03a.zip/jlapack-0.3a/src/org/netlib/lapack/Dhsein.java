/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dhsein {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DHSEIN uses inverse iteration to find specified right and/or left
// *  eigenvectors of a real upper Hessenberg matrix H.
// *
// *  The right eigenvector x and the left eigenvector y of the matrix H
// *  corresponding to an eigenvalue w are defined by:
// *
// *               H * x = w * x,     y**h * H = w * y**h
// *
// *  where y**h denotes the conjugate transpose of the vector y.
// *
// *  Arguments
// *  =========
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'R': compute right eigenvectors only;
// *          = 'L': compute left eigenvectors only;
// *          = 'B': compute both right and left eigenvectors.
// *
// *  EIGSRC  (input) CHARACTER*1
// *          Specifies the source of eigenvalues supplied in (WR,WI):
// *          = 'Q': the eigenvalues were found using DHSEQR; thus, if
// *                 H has zero subdiagonal elements, and so is
// *                 block-triangular, then the j-th eigenvalue can be
// *                 assumed to be an eigenvalue of the block containing
// *                 the j-th row/column.  This property allows DHSEIN to
// *                 perform inverse iteration on just one diagonal block.
// *          = 'N': no assumptions are made on the correspondence
// *                 between eigenvalues and diagonal blocks.  In this
// *                 case, DHSEIN must always perform inverse iteration
// *                 using the whole matrix H.
// *
// *  INITV   (input) CHARACTER*1
// *          = 'N': no initial vectors are supplied;
// *          = 'U': user-supplied initial vectors are stored in the arrays
// *                 VL and/or VR.
// *
// *  SELECT  (input/output) LOGICAL array, dimension (N)
// *          Specifies the eigenvectors to be computed. To select the
// *          real eigenvector corresponding to a real eigenvalue WR(j),
// *          SELECT(j) must be set to .TRUE.. To select the complex
// *          eigenvector corresponding to a complex eigenvalue
// *          (WR(j),WI(j)), with complex conjugate (WR(j+1),WI(j+1)),
// *          either SELECT(j) or SELECT(j+1) or both must be set to
// *          .TRUE.; then on exit SELECT(j) is .TRUE. and SELECT(j+1) is
// *          .FALSE..
// *
// *  N       (input) INTEGER
// *          The order of the matrix H.  N >= 0.
// *
// *  H       (input) DOUBLE PRECISION array, dimension (LDH,N)
// *          The upper Hessenberg matrix H.
// *
// *  LDH     (input) INTEGER
// *          The leading dimension of the array H.  LDH >= max(1,N).
// *
// *  WR      (input/output) DOUBLE PRECISION array, dimension (N)
// *  WI      (input) DOUBLE PRECISION array, dimension (N)
// *          On entry, the real and imaginary parts of the eigenvalues of
// *          H; a complex conjugate pair of eigenvalues must be stored in
// *          consecutive elements of WR and WI.
// *          On exit, WR may have been altered since close eigenvalues
// *          are perturbed slightly in searching for independent
// *          eigenvectors.
// *
// *  VL      (input/output) DOUBLE PRECISION array, dimension (LDVL,MM)
// *          On entry, if INITV = 'U' and SIDE = 'L' or 'B', VL must
// *          contain starting vectors for the inverse iteration for the
// *          left eigenvectors; the starting vector for each eigenvector
// *          must be in the same column(s) in which the eigenvector will
// *          be stored.
// *          On exit, if SIDE = 'L' or 'B', the left eigenvectors
// *          specified by SELECT will be stored consecutively in the
// *          columns of VL, in the same order as their eigenvalues. A
// *          complex eigenvector corresponding to a complex eigenvalue is
// *          stored in two consecutive columns, the first holding the real
// *          part and the second the imaginary part.
// *          If SIDE = 'R', VL is not referenced.
// *
// *  LDVL    (input) INTEGER
// *          The leading dimension of the array VL.
// *          LDVL >= max(1,N) if SIDE = 'L' or 'B'; LDVL >= 1 otherwise.
// *
// *  VR      (input/output) DOUBLE PRECISION array, dimension (LDVR,MM)
// *          On entry, if INITV = 'U' and SIDE = 'R' or 'B', VR must
// *          contain starting vectors for the inverse iteration for the
// *          right eigenvectors; the starting vector for each eigenvector
// *          must be in the same column(s) in which the eigenvector will
// *          be stored.
// *          On exit, if SIDE = 'R' or 'B', the right eigenvectors
// *          specified by SELECT will be stored consecutively in the
// *          columns of VR, in the same order as their eigenvalues. A
// *          complex eigenvector corresponding to a complex eigenvalue is
// *          stored in two consecutive columns, the first holding the real
// *          part and the second the imaginary part.
// *          If SIDE = 'L', VR is not referenced.
// *
// *  LDVR    (input) INTEGER
// *          The leading dimension of the array VR.
// *          LDVR >= max(1,N) if SIDE = 'R' or 'B'; LDVR >= 1 otherwise.
// *
// *  MM      (input) INTEGER
// *          The number of columns in the arrays VL and/or VR. MM >= M.
// *
// *  M       (output) INTEGER
// *          The number of columns in the arrays VL and/or VR required to
// *          store the eigenvectors; each selected real eigenvector
// *          occupies one column and each selected complex eigenvector
// *          occupies two columns.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension ((N+2)*N)
// *
// *  IFAILL  (output) INTEGER array, dimension (MM)
// *          If SIDE = 'L' or 'B', IFAILL(i) = j > 0 if the left
// *          eigenvector in the i-th column of VL (corresponding to the
// *          eigenvalue w(j)) failed to converge; IFAILL(i) = 0 if the
// *          eigenvector converged satisfactorily. If the i-th and (i+1)th
// *          columns of VL hold a complex eigenvector, then IFAILL(i) and
// *          IFAILL(i+1) are set to the same value.
// *          If SIDE = 'R', IFAILL is not referenced.
// *
// *  IFAILR  (output) INTEGER array, dimension (MM)
// *          If SIDE = 'R' or 'B', IFAILR(i) = j > 0 if the right
// *          eigenvector in the i-th column of VR (corresponding to the
// *          eigenvalue w(j)) failed to converge; IFAILR(i) = 0 if the
// *          eigenvector converged satisfactorily. If the i-th and (i+1)th
// *          columns of VR hold a complex eigenvector, then IFAILR(i) and
// *          IFAILR(i+1) are set to the same value.
// *          If SIDE = 'L', IFAILR is not referenced.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, i is the number of eigenvectors which
// *                failed to converge; see IFAILL and IFAILR for further
// *                details.
// *
// *  Further Details
// *  ===============
// *
// *  Each eigenvector is normalized so that the element of largest
// *  magnitude has magnitude 1; here the magnitude of a complex number
// *  (x,y) is taken to be |x|+|y|.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean bothv= false;
static boolean fromqr= false;
static boolean leftv= false;
static boolean noinit= false;
static boolean pair= false;
static boolean rightv= false;
static int i= 0;
static intW iinfo= new intW(0);
static int k= 0;
static int kl= 0;
static int kln= 0;
static int kr= 0;
static int ksi= 0;
static int ksr= 0;
static int ldwork= 0;
static double bignum= 0.0;
static double eps3= 0.0;
static double hnorm= 0.0;
static double smlnum= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double wki= 0.0;
static double wkr= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode and test the input parameters.
// *

public static void dhsein (String side,
String eigsrc,
String initv,
boolean [] select, int _select_offset,
int n,
double [] h, int _h_offset,
int ldh,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] vl, int _vl_offset,
int ldvl,
double [] vr, int _vr_offset,
int ldvr,
int mm,
intW m,
double [] work, int _work_offset,
int [] ifaill, int _ifaill_offset,
int [] ifailr, int _ifailr_offset,
intW info)  {

bothv = (side.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
rightv = (side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)) || bothv;
leftv = (side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)) || bothv;
// *
fromqr = (eigsrc.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0));
// *
noinit = (initv.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
// *
// *     Set M to the number of columns required to store the selected
// *     eigenvectors, and standardize the array SELECT.
// *
m.val = 0;
pair = false;
{
forloop10:
for (k = 1; k <= n; k++) {
if (pair)  {
    pair = false;
select[(k)- 1+ _select_offset] = false;
}              // Close if()
else  {
  if (wi[(k)- 1+ _wi_offset] == zero)  {
    if (select[(k)- 1+ _select_offset])  
    m.val = m.val+1;
}              // Close if()
else  {
  pair = true;
if (select[(k)- 1+ _select_offset] || select[(k+1)- 1+ _select_offset])  {
    select[(k)- 1+ _select_offset] = true;
m.val = m.val+2;
}              // Close if()
}              //  Close else.
}              //  Close else.
Dummy.label("Dhsein",10);
}              //  Close for() loop. 
}
// *
info.val = 0;
if (!rightv && !leftv)  {
    info.val = -1;
}              // Close if()
else if (!fromqr && !(eigsrc.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (!noinit && !(initv.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    info.val = -3;
}              // Close else if()
else if (n < 0)  {
    info.val = -5;
}              // Close else if()
else if (ldh < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldvl < 1 || (leftv && ldvl < n))  {
    info.val = -11;
}              // Close else if()
else if (ldvr < 1 || (rightv && ldvr < n))  {
    info.val = -13;
}              // Close else if()
else if (mm < m.val)  {
    info.val = -14;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DHSEIN",-info.val);
Dummy.go_to("Dhsein",999999);
}              // Close if()
// *
// *     Quick return if possible.
// *
if (n == 0)  
    Dummy.go_to("Dhsein",999999);
// *
// *     Set machine-dependent constants.
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Precision");
smlnum = unfl*(n/ulp);
bignum = (one-ulp)/smlnum;
// *
ldwork = n+1;
// *
kl = 1;
kln = 0;
if (fromqr)  {
    kr = 0;
}              // Close if()
else  {
  kr = n;
}              //  Close else.
ksr = 1;
// *
{
forloop120:
for (k = 1; k <= n; k++) {
if (select[(k)- 1+ _select_offset])  {
    // *
// *           Compute eigenvector(s) corresponding to W(K).
// *
if (fromqr)  {
    // *
// *              If affiliation of eigenvalues is known, check whether
// *              the matrix splits.
// *
// *              Determine KL and KR such that 1 <= KL <= K <= KR <= N
// *              and H(KL,KL-1) and H(KR+1,KR) are zero (or KL = 1 or
// *              KR = N).
// *
// *              Then inverse iteration can be performed with the
// *              submatrix H(KL:N,KL:N) for a left eigenvector, and with
// *              the submatrix H(1:KR,1:KR) for a right eigenvector.
// *
{
int _i_inc = -1;
forloop20:
for (i = k; i >= kl+1; i += _i_inc) {
if (h[(i)- 1+(i-1- 1)*ldh+ _h_offset] == zero)  
    Dummy.go_to("Dhsein",30);
Dummy.label("Dhsein",20);
}              //  Close for() loop. 
}
label30:
   Dummy.label("Dhsein",30);
kl = i;
if (k > kr)  {
    {
forloop40:
for (i = k; i <= n-1; i++) {
if (h[(i+1)- 1+(i- 1)*ldh+ _h_offset] == zero)  
    Dummy.go_to("Dhsein",50);
Dummy.label("Dhsein",40);
}              //  Close for() loop. 
}
label50:
   Dummy.label("Dhsein",50);
kr = i;
}              // Close if()
}              // Close if()
// *
if (kl != kln)  {
    kln = kl;
// *
// *              Compute infinity-norm of submatrix H(KL:KR,KL:KR) if it
// *              has not ben computed before.
// *
hnorm = Dlanhs.dlanhs("I",kr-kl+1,h,(kl)- 1+(kl- 1)*ldh+ _h_offset,ldh,work,_work_offset);
if (hnorm > zero)  {
    eps3 = hnorm*ulp;
}              // Close if()
else  {
  eps3 = smlnum;
}              //  Close else.
}              // Close if()
// *
// *           Perturb eigenvalue if it is close to any previous
// *           selected eigenvalues affiliated to the submatrix
// *           H(KL:KR,KL:KR). Close roots are modified by EPS3.
// *
wkr = wr[(k)- 1+ _wr_offset];
wki = wi[(k)- 1+ _wi_offset];
label60:
   Dummy.label("Dhsein",60);
{
int _i_inc = -1;
forloop70:
for (i = k-1; i >= kl; i += _i_inc) {
if (select[(i)- 1+ _select_offset] && Math.abs(wr[(i)- 1+ _wr_offset]-wkr)+Math.abs(wi[(i)- 1+ _wi_offset]-wki) < eps3)  {
    wkr = wkr+eps3;
Dummy.go_to("Dhsein",60);
}              // Close if()
Dummy.label("Dhsein",70);
}              //  Close for() loop. 
}
wr[(k)- 1+ _wr_offset] = wkr;
// *
pair = wki != zero;
if (pair)  {
    ksi = ksr+1;
}              // Close if()
else  {
  ksi = ksr;
}              //  Close else.
if (leftv)  {
    // *
// *              Compute left eigenvector.
// *
Dlaein.dlaein(false,noinit,n-kl+1,h,(kl)- 1+(kl- 1)*ldh+ _h_offset,ldh,wkr,wki,vl,(kl)- 1+(ksr- 1)*ldvl+ _vl_offset,vl,(kl)- 1+(ksi- 1)*ldvl+ _vl_offset,work,_work_offset,ldwork,work,(n*n+n+1)- 1+ _work_offset,eps3,smlnum,bignum,iinfo);
if (iinfo.val > 0)  {
    if (pair)  {
    info.val = info.val+2;
}              // Close if()
else  {
  info.val = info.val+1;
}              //  Close else.
ifaill[(ksr)- 1+ _ifaill_offset] = k;
ifaill[(ksi)- 1+ _ifaill_offset] = k;
}              // Close if()
else  {
  ifaill[(ksr)- 1+ _ifaill_offset] = 0;
ifaill[(ksi)- 1+ _ifaill_offset] = 0;
}              //  Close else.
{
forloop80:
for (i = 1; i <= kl-1; i++) {
vl[(i)- 1+(ksr- 1)*ldvl+ _vl_offset] = zero;
Dummy.label("Dhsein",80);
}              //  Close for() loop. 
}
if (pair)  {
    {
forloop90:
for (i = 1; i <= kl-1; i++) {
vl[(i)- 1+(ksi- 1)*ldvl+ _vl_offset] = zero;
Dummy.label("Dhsein",90);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
if (rightv)  {
    // *
// *              Compute right eigenvector.
// *
Dlaein.dlaein(true,noinit,kr,h,_h_offset,ldh,wkr,wki,vr,(1)- 1+(ksr- 1)*ldvr+ _vr_offset,vr,(1)- 1+(ksi- 1)*ldvr+ _vr_offset,work,_work_offset,ldwork,work,(n*n+n+1)- 1+ _work_offset,eps3,smlnum,bignum,iinfo);
if (iinfo.val > 0)  {
    if (pair)  {
    info.val = info.val+2;
}              // Close if()
else  {
  info.val = info.val+1;
}              //  Close else.
ifailr[(ksr)- 1+ _ifailr_offset] = k;
ifailr[(ksi)- 1+ _ifailr_offset] = k;
}              // Close if()
else  {
  ifailr[(ksr)- 1+ _ifailr_offset] = 0;
ifailr[(ksi)- 1+ _ifailr_offset] = 0;
}              //  Close else.
{
forloop100:
for (i = kr+1; i <= n; i++) {
vr[(i)- 1+(ksr- 1)*ldvr+ _vr_offset] = zero;
Dummy.label("Dhsein",100);
}              //  Close for() loop. 
}
if (pair)  {
    {
forloop110:
for (i = kr+1; i <= n; i++) {
vr[(i)- 1+(ksi- 1)*ldvr+ _vr_offset] = zero;
Dummy.label("Dhsein",110);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
if (pair)  {
    ksr = ksr+2;
}              // Close if()
else  {
  ksr = ksr+1;
}              //  Close else.
}              // Close if()
Dummy.label("Dhsein",120);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dhsein",999999);
// *
// *     End of DHSEIN
// *
Dummy.label("Dhsein",999999);
return;
   }
} // End class.
