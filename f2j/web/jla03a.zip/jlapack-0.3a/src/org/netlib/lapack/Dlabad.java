/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlabad {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLABAD takes as input the values computed by SLAMCH for underflow and
// *  overflow, and returns the square root of each of these values if the
// *  log of LARGE is sufficiently large.  This subroutine is intended to
// *  identify machines with a large exponent range, such as the Crays, and
// *  redefine the underflow and overflow limits to be the square roots of
// *  the values computed by DLAMCH.  This subroutine is needed because
// *  DLAMCH does not compensate for poor arithmetic in the upper half of
// *  the exponent range, as is found on a Cray.
// *
// *  Arguments
// *  =========
// *
// *  SMALL   (input/output) DOUBLE PRECISION
// *          On entry, the underflow threshold as computed by DLAMCH.
// *          On exit, if LOG10(LARGE) is sufficiently large, the square
// *          root of SMALL, otherwise unchanged.
// *
// *  LARGE   (input/output) DOUBLE PRECISION
// *          On entry, the overflow threshold as computed by DLAMCH.
// *          On exit, if LOG10(LARGE) is sufficiently large, the square
// *          root of LARGE, otherwise unchanged.
// *
// *  =====================================================================
// *
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     If it looks like we're on a Cray, take the square root of
// *     SMALL and LARGE to avoid overflow and underflow problems.
// *

public static void dlabad (doubleW small,
doubleW large)  {

if ((Math.log(large.val) / 2.30258509) > 2000.e0)  {
    small.val = Math.sqrt(small.val);
large.val = Math.sqrt(large.val);
}              // Close if()
// *
Dummy.go_to("Dlabad",999999);
// *
// *     End of DLABAD
// *
Dummy.label("Dlabad",999999);
return;
   }
} // End class.
