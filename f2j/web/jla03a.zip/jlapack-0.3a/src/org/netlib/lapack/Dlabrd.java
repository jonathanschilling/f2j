/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlabrd {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLABRD reduces the first NB rows and columns of a real general
// *  m by n matrix A to upper or lower bidiagonal form by an orthogonal
// *  transformation Q' * A * P, and returns the matrices X and Y which
// *  are needed to apply the transformation to the unreduced part of A.
// *
// *  If m >= n, A is reduced to upper bidiagonal form; if m < n, to lower
// *  bidiagonal form.
// *
// *  This is an auxiliary routine called by DGEBRD
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows in the matrix A.
// *
// *  N       (input) INTEGER
// *          The number of columns in the matrix A.
// *
// *  NB      (input) INTEGER
// *          The number of leading rows and columns of A to be reduced.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the m by n general matrix to be reduced.
// *          On exit, the first NB rows and columns of the matrix are
// *          overwritten; the rest of the array is unchanged.
// *          If m >= n, elements on and below the diagonal in the first NB
// *            columns, with the array TAUQ, represent the orthogonal
// *            matrix Q as a product of elementary reflectors; and
// *            elements above the diagonal in the first NB rows, with the
// *            array TAUP, represent the orthogonal matrix P as a product
// *            of elementary reflectors.
// *          If m < n, elements below the diagonal in the first NB
// *            columns, with the array TAUQ, represent the orthogonal
// *            matrix Q as a product of elementary reflectors, and
// *            elements on and above the diagonal in the first NB rows,
// *            with the array TAUP, represent the orthogonal matrix P as
// *            a product of elementary reflectors.
// *          See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  D       (output) DOUBLE PRECISION array, dimension (NB)
// *          The diagonal elements of the first NB rows and columns of
// *          the reduced matrix.  D(i) = A(i,i).
// *
// *  E       (output) DOUBLE PRECISION array, dimension (NB)
// *          The off-diagonal elements of the first NB rows and columns of
// *          the reduced matrix.
// *
// *  TAUQ    (output) DOUBLE PRECISION array dimension (NB)
// *          The scalar factors of the elementary reflectors which
// *          represent the orthogonal matrix Q. See Further Details.
// *
// *  TAUP    (output) DOUBLE PRECISION array, dimension (NB)
// *          The scalar factors of the elementary reflectors which
// *          represent the orthogonal matrix P. See Further Details.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (LDX,NB)
// *          The m-by-nb matrix X required to update the unreduced part
// *          of A.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X. LDX >= M.
// *
// *  Y       (output) DOUBLE PRECISION array, dimension (LDY,NB)
// *          The n-by-nb matrix Y required to update the unreduced part
// *          of A.
// *
// *  LDY     (output) INTEGER
// *          The leading dimension of the array Y. LDY >= N.
// *
// *  Further Details
// *  ===============
// *
// *  The matrices Q and P are represented as products of elementary
// *  reflectors:
// *
// *     Q = H(1) H(2) . . . H(nb)  and  P = G(1) G(2) . . . G(nb)
// *
// *  Each H(i) and G(i) has the form:
// *
// *     H(i) = I - tauq * v * v'  and G(i) = I - taup * u * u'
// *
// *  where tauq and taup are real scalars, and v and u are real vectors.
// *
// *  If m >= n, v(1:i-1) = 0, v(i) = 1, and v(i:m) is stored on exit in
// *  A(i:m,i); u(1:i) = 0, u(i+1) = 1, and u(i+1:n) is stored on exit in
// *  A(i,i+1:n); tauq is stored in TAUQ(i) and taup in TAUP(i).
// *
// *  If m < n, v(1:i) = 0, v(i+1) = 1, and v(i+1:m) is stored on exit in
// *  A(i+2:m,i); u(1:i-1) = 0, u(i) = 1, and u(i:n) is stored on exit in
// *  A(i,i+1:n); tauq is stored in TAUQ(i) and taup in TAUP(i).
// *
// *  The elements of the vectors v and u together form the m-by-nb matrix
// *  V and the nb-by-n matrix U' which are needed, with X and Y, to apply
// *  the transformation to the unreduced part of the matrix, using a block
// *  update of the form:  A := A - V*Y' - X*U'.
// *
// *  The contents of A on exit are illustrated by the following examples
// *  with nb = 2:
// *
// *  m = 6 and n = 5 (m > n):          m = 5 and n = 6 (m < n):
// *
// *    (  1   1   u1  u1  u1 )           (  1   u1  u1  u1  u1  u1 )
// *    (  v1  1   1   u2  u2 )           (  1   1   u2  u2  u2  u2 )
// *    (  v1  v2  a   a   a  )           (  v1  1   a   a   a   a  )
// *    (  v1  v2  a   a   a  )           (  v1  v2  a   a   a   a  )
// *    (  v1  v2  a   a   a  )           (  v1  v2  a   a   a   a  )
// *    (  v1  v2  a   a   a  )
// *
// *  where a denotes an element of the original matrix which is unchanged,
// *  vi denotes an element of the vector defining H(i), and ui an element
// *  of the vector defining G(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlabrd (int m,
int n,
int nb,
double [] a, int _a_offset,
int lda,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] tauq, int _tauq_offset,
double [] taup, int _taup_offset,
double [] x, int _x_offset,
int ldx,
double [] y, int _y_offset,
int ldy)  {

if (m <= 0 || n <= 0)  
    Dummy.go_to("Dlabrd",999999);
// *
if (m >= n)  {
    // *
// *        Reduce to upper bidiagonal form
// *
{
forloop10:
for (i = 1; i <= nb; i++) {
// *
// *           Update A(i:m,i)
// *
Dgemv.dgemv("No transpose",m-i+1,i-1,-one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,y,(i)- 1+(1- 1)*ldy+ _y_offset,ldy,one,a,(i)- 1+(i- 1)*lda+ _a_offset,1);
Dgemv.dgemv("No transpose",m-i+1,i-1,-one,x,(i)- 1+(1- 1)*ldx+ _x_offset,ldx,a,(1)- 1+(i- 1)*lda+ _a_offset,1,one,a,(i)- 1+(i- 1)*lda+ _a_offset,1);
// *
// *           Generate reflection Q(i) to annihilate A(i+1:m,i)
// *
dlarfg_adapter(m-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(i+1, m) )- 1+(i- 1)*lda+ _a_offset),1,tauq,(i)- 1+ _tauq_offset);
d[(i)- 1+ _d_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
if (i < n)  {
    a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Compute Y(i+1:n,i)
// *
Dgemv.dgemv("Transpose",m-i+1,n-i,one,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",m-i+1,i-1,one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,a,(i)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("No transpose",n-i,i-1,-one,y,(i+1)- 1+(1- 1)*ldy+ _y_offset,ldy,y,(1)- 1+(i- 1)*ldy+ _y_offset,1,one,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",m-i+1,i-1,one,x,(i)- 1+(1- 1)*ldx+ _x_offset,ldx,a,(i)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",i-1,n-i,-one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,y,(1)- 1+(i- 1)*ldy+ _y_offset,1,one,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dscal.dscal(n-i,tauq[(i)- 1+ _tauq_offset],y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
// *
// *              Update A(i,i+1:n)
// *
Dgemv.dgemv("No transpose",n-i,i,-one,y,(i+1)- 1+(1- 1)*ldy+ _y_offset,ldy,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda);
Dgemv.dgemv("Transpose",i-1,n-i,-one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,x,(i)- 1+(1- 1)*ldx+ _x_offset,ldx,one,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda);
// *
// *              Generate reflection P(i) to annihilate A(i,i+2:n)
// *
dlarfg_adapter(n-i,a,(i)- 1+(i+1- 1)*lda+ _a_offset,a,(i)- 1+(Math.min(i+2, n) - 1)*lda+ _a_offset,lda,taup,(i)- 1+ _taup_offset);
e[(i)- 1+ _e_offset] = a[(i)- 1+(i+1- 1)*lda+ _a_offset];
a[(i)- 1+(i+1- 1)*lda+ _a_offset] = one;
// *
// *              Compute X(i+1:m,i)
// *
Dgemv.dgemv("No transpose",m-i,n-i,one,a,(i+1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,zero,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("Transpose",n-i,i,one,y,(i+1)- 1+(1- 1)*ldy+ _y_offset,ldy,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,zero,x,(1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",m-i,i,-one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,x,(1)- 1+(i- 1)*ldx+ _x_offset,1,one,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",i-1,n-i,one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,zero,x,(1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",m-i,i-1,-one,x,(i+1)- 1+(1- 1)*ldx+ _x_offset,ldx,x,(1)- 1+(i- 1)*ldx+ _x_offset,1,one,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dscal.dscal(m-i,taup[(i)- 1+ _taup_offset],x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
}              // Close if()
Dummy.label("Dlabrd",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Reduce to lower bidiagonal form
// *
{
forloop20:
for (i = 1; i <= nb; i++) {
// *
// *           Update A(i,i:n)
// *
Dgemv.dgemv("No transpose",n-i+1,i-1,-one,y,(i)- 1+(1- 1)*ldy+ _y_offset,ldy,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
Dgemv.dgemv("Transpose",i-1,n-i+1,-one,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,x,(i)- 1+(1- 1)*ldx+ _x_offset,ldx,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
// *
// *           Generate reflection P(i) to annihilate A(i,i+1:n)
// *
dlarfg_adapter(n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,a,(i)- 1+(Math.min(i+1, n) - 1)*lda+ _a_offset,lda,taup,(i)- 1+ _taup_offset);
d[(i)- 1+ _d_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
if (i < m)  {
    a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Compute X(i+1:m,i)
// *
Dgemv.dgemv("No transpose",m-i,n-i+1,one,a,(i+1)- 1+(i- 1)*lda+ _a_offset,lda,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,zero,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("Transpose",n-i+1,i-1,one,y,(i)- 1+(1- 1)*ldy+ _y_offset,ldy,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,zero,x,(1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",m-i,i-1,-one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,x,(1)- 1+(i- 1)*ldx+ _x_offset,1,one,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",i-1,n-i+1,one,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,zero,x,(1)- 1+(i- 1)*ldx+ _x_offset,1);
Dgemv.dgemv("No transpose",m-i,i-1,-one,x,(i+1)- 1+(1- 1)*ldx+ _x_offset,ldx,x,(1)- 1+(i- 1)*ldx+ _x_offset,1,one,x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
Dscal.dscal(m-i,taup[(i)- 1+ _taup_offset],x,(i+1)- 1+(i- 1)*ldx+ _x_offset,1);
// *
// *              Update A(i+1:m,i)
// *
Dgemv.dgemv("No transpose",m-i,i-1,-one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,y,(i)- 1+(1- 1)*ldy+ _y_offset,ldy,one,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1);
Dgemv.dgemv("No transpose",m-i,i,-one,x,(i+1)- 1+(1- 1)*ldx+ _x_offset,ldx,a,(1)- 1+(i- 1)*lda+ _a_offset,1,one,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1);
// *
// *              Generate reflection Q(i) to annihilate A(i+2:m,i)
// *
dlarfg_adapter(m-i,a,(i+1)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(i+2, m) )- 1+(i- 1)*lda+ _a_offset),1,tauq,(i)- 1+ _tauq_offset);
e[(i)- 1+ _e_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
a[(i+1)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Compute Y(i+1:n,i)
// *
Dgemv.dgemv("Transpose",m-i,n-i,one,a,(i+1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",m-i,i-1,one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("No transpose",n-i,i-1,-one,y,(i+1)- 1+(1- 1)*ldy+ _y_offset,ldy,y,(1)- 1+(i- 1)*ldy+ _y_offset,1,one,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",m-i,i,one,x,(i+1)- 1+(1- 1)*ldx+ _x_offset,ldx,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",i,n-i,-one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,y,(1)- 1+(i- 1)*ldy+ _y_offset,1,one,y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
Dscal.dscal(n-i,tauq[(i)- 1+ _tauq_offset],y,(i+1)- 1+(i- 1)*ldy+ _y_offset,1);
}              // Close if()
Dummy.label("Dlabrd",20);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dlabrd",999999);
// *
// *     End of DLABRD
// *
Dummy.label("Dlabrd",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
