/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlacon {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLACON estimates the 1-norm of a square, real matrix A.
// *  Reverse communication is used for evaluating matrix-vector products.
// *
// *  Arguments
// *  =========
// *
// *  N      (input) INTEGER
// *         The order of the matrix.  N >= 1.
// *
// *  V      (workspace) DOUBLE PRECISION array, dimension (N)
// *         On the final return, V = A*W,  where  EST = norm(V)/norm(W)
// *         (W is not returned).
// *
// *  X      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On an intermediate return, X should be overwritten by
// *               A * X,   if KASE=1,
// *               A' * X,  if KASE=2,
// *         and DLACON must be re-called with all the other parameters
// *         unchanged.
// *
// *  ISGN   (workspace) INTEGER array, dimension (N)
// *
// *  EST    (output) DOUBLE PRECISION
// *         An estimate (a lower bound) for norm(A).
// *
// *  KASE   (input/output) INTEGER
// *         On the initial call to DLACON, KASE should be 0.
// *         On an intermediate return, KASE will be 1 or 2, indicating
// *         whether X should be overwritten by A * X  or A' * X.
// *         On the final return from DLACON, KASE will again be 0.
// *
// *  Further Details
// *  ======= =======
// *
// *  Contributed by Nick Higham, University of Manchester.
// *  Originally named SONEST, dated March 16, 1988.
// *
// *  Reference: N.J. Higham, "FORTRAN codes for estimating the one-norm of
// *  a real or complex matrix, with applications to condition estimation",
// *  ACM Trans. Math. Soft., vol. 14, no. 4, pp. 381-396, December 1988.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int itmax= 5;
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int iter= 0;
static int j= 0;
static int jlast= 0;
static int jump= 0;
static double altsgn= 0.0;
static double estold= 0.0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlacon (int n,
double [] v, int _v_offset,
double [] x, int _x_offset,
int [] isgn, int _isgn_offset,
doubleW est,
intW kase)  {

if (kase.val == 0)  {
    {
forloop10:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = one/(double)(n);
Dummy.label("Dlacon",10);
}              //  Close for() loop. 
}
kase.val = 1;
jump = 1;
Dummy.go_to("Dlacon",999999);
}              // Close if()
// *
if (jump == 1) 
  Dummy.go_to("Dlacon",20);
else if (jump == 2) 
  Dummy.go_to("Dlacon",40);
else if (jump == 3) 
  Dummy.go_to("Dlacon",70);
else if (jump == 4) 
  Dummy.go_to("Dlacon",110);
else if (jump == 5) 
  Dummy.go_to("Dlacon",140);
// *
// *     ................ ENTRY   (JUMP = 1)
// *     FIRST ITERATION.  X HAS BEEN OVERWRITTEN BY A*X.
// *
label20:
   Dummy.label("Dlacon",20);
if (n == 1)  {
    v[(1)- 1+ _v_offset] = x[(1)- 1+ _x_offset];
est.val = Math.abs(v[(1)- 1+ _v_offset]);
// *        ... QUIT
Dummy.go_to("Dlacon",150);
}              // Close if()
est.val = Dasum.dasum(n,x,_x_offset,1);
// *
{
forloop30:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = ((x[(i)- 1+ _x_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
isgn[(i)- 1+ _isgn_offset] = (int)((x[(i)- 1+ _x_offset]) >= 0 ? (x[(i)- 1+ _x_offset]) + .5 : (x[(i)- 1+ _x_offset]) - .5);
Dummy.label("Dlacon",30);
}              //  Close for() loop. 
}
kase.val = 2;
jump = 2;
Dummy.go_to("Dlacon",999999);
// *
// *     ................ ENTRY   (JUMP = 2)
// *     FIRST ITERATION.  X HAS BEEN OVERWRITTEN BY TRANDPOSE(A)*X.
// *
label40:
   Dummy.label("Dlacon",40);
j = Idamax.idamax(n,x,_x_offset,1);
iter = 2;
// *
// *     MAIN LOOP - ITERATIONS 2,3,...,ITMAX.
// *
label50:
   Dummy.label("Dlacon",50);
{
forloop60:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = zero;
Dummy.label("Dlacon",60);
}              //  Close for() loop. 
}
x[(j)- 1+ _x_offset] = one;
kase.val = 1;
jump = 3;
Dummy.go_to("Dlacon",999999);
// *
// *     ................ ENTRY   (JUMP = 3)
// *     X HAS BEEN OVERWRITTEN BY A*X.
// *
label70:
   Dummy.label("Dlacon",70);
Dcopy.dcopy(n,x,_x_offset,1,v,_v_offset,1);
estold = est.val;
est.val = Dasum.dasum(n,v,_v_offset,1);
{
forloop80:
for (i = 1; i <= n; i++) {
if ((int)((((x[(i)- 1+ _x_offset]) >= 0 ? Math.abs(one) : -Math.abs(one))) >= 0 ? (((x[(i)- 1+ _x_offset]) >= 0 ? Math.abs(one) : -Math.abs(one))) + .5 : (((x[(i)- 1+ _x_offset]) >= 0 ? Math.abs(one) : -Math.abs(one))) - .5) != isgn[(i)- 1+ _isgn_offset])  
    Dummy.go_to("Dlacon",90);
Dummy.label("Dlacon",80);
}              //  Close for() loop. 
}
// *     REPEATED SIGN VECTOR DETECTED, HENCE ALGORITHM HAS CONVERGED.
Dummy.go_to("Dlacon",120);
// *
label90:
   Dummy.label("Dlacon",90);
// *     TEST FOR CYCLING.
if (est.val <= estold)  
    Dummy.go_to("Dlacon",120);
// *
{
forloop100:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = ((x[(i)- 1+ _x_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
isgn[(i)- 1+ _isgn_offset] = (int)((x[(i)- 1+ _x_offset]) >= 0 ? (x[(i)- 1+ _x_offset]) + .5 : (x[(i)- 1+ _x_offset]) - .5);
Dummy.label("Dlacon",100);
}              //  Close for() loop. 
}
kase.val = 2;
jump = 4;
Dummy.go_to("Dlacon",999999);
// *
// *     ................ ENTRY   (JUMP = 4)
// *     X HAS BEEN OVERWRITTEN BY TRANDPOSE(A)*X.
// *
label110:
   Dummy.label("Dlacon",110);
jlast = j;
j = Idamax.idamax(n,x,_x_offset,1);
if ((x[(jlast)- 1+ _x_offset] != Math.abs(x[(j)- 1+ _x_offset])) && (iter < itmax))  {
    iter = iter+1;
Dummy.go_to("Dlacon",50);
}              // Close if()
// *
// *     ITERATION COMPLETE.  FINAL STAGE.
// *
label120:
   Dummy.label("Dlacon",120);
altsgn = one;
{
forloop130:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = altsgn*(one+(double)(i-1)/(double)(n-1));
altsgn = -altsgn;
Dummy.label("Dlacon",130);
}              //  Close for() loop. 
}
kase.val = 1;
jump = 5;
Dummy.go_to("Dlacon",999999);
// *
// *     ................ ENTRY   (JUMP = 5)
// *     X HAS BEEN OVERWRITTEN BY A*X.
// *
label140:
   Dummy.label("Dlacon",140);
temp = two*(Dasum.dasum(n,x,_x_offset,1)/(double)(3*n));
if (temp > est.val)  {
    Dcopy.dcopy(n,x,_x_offset,1,v,_v_offset,1);
est.val = temp;
}              // Close if()
// *
label150:
   Dummy.label("Dlacon",150);
kase.val = 0;
Dummy.go_to("Dlacon",999999);
// *
// *     End of DLACON
// *
Dummy.label("Dlacon",999999);
return;
   }
} // End class.
