/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlacpy {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLACPY copies all or part of a two-dimensional matrix A to another
// *  matrix B.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies the part of the matrix A to be copied to B.
// *          = 'U':      Upper triangular part
// *          = 'L':      Lower triangular part
// *          Otherwise:  All of the matrix A
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m by n matrix A.  If UPLO = 'U', only the upper triangle
// *          or trapezoid is accessed; if UPLO = 'L', only the lower
// *          triangle or trapezoid is accessed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  B       (output) DOUBLE PRECISION array, dimension (LDB,N)
// *          On exit, B = A in the locations specified by UPLO.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,M).
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlacpy (String uplo,
int m,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb)  {

if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= Math.min(j, m) ; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlacpy",10);
}              //  Close for() loop. 
}
Dummy.label("Dlacpy",20);
}              //  Close for() loop. 
}
}              // Close if()
else if ((uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = j; i <= m; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlacpy",30);
}              //  Close for() loop. 
}
Dummy.label("Dlacpy",40);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = 1; i <= m; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlacpy",50);
}              //  Close for() loop. 
}
Dummy.label("Dlacpy",60);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dlacpy",999999);
// *
// *     End of DLACPY
// *
Dummy.label("Dlacpy",999999);
return;
   }
} // End class.
