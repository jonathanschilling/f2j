/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dladiv {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLADIV performs complex division in  real arithmetic
// *
// *                        a + i*b
// *             p + i*q = ---------
// *                        c + i*d
// *
// *  The algorithm is due to Robert L. Smith and can be found
// *  in D. Knuth, The art of Computer Programming, Vol.2, p.195
// *
// *  Arguments
// *  =========
// *
// *  A       (input) DOUBLE PRECISION
// *  B       (input) DOUBLE PRECISION
// *  C       (input) DOUBLE PRECISION
// *  D       (input) DOUBLE PRECISION
// *          The scalars a, b, c, and d in the above expression.
// *
// *  P       (output) DOUBLE PRECISION
// *  Q       (output) DOUBLE PRECISION
// *          The scalars p and q in the above expression.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static double e= 0.0;
static double f= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dladiv (double a,
double b,
double c,
double d,
doubleW p,
doubleW q)  {

if (Math.abs(d) < Math.abs(c))  {
    e = d/c;
f = c+d*e;
p.val = (a+b*e)/f;
q.val = (b-a*e)/f;
}              // Close if()
else  {
  e = c/d;
f = d+c*e;
p.val = (b+a*e)/f;
q.val = (-a+b*e)/f;
}              //  Close else.
// *
Dummy.go_to("Dladiv",999999);
// *
// *     End of DLADIV
// *
Dummy.label("Dladiv",999999);
return;
   }
} // End class.
