/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaebz {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAEBZ contains the iteration loops which compute and use the
// *  function N(w), which is the count of eigenvalues of a symmetric
// *  tridiagonal matrix T less than or equal to its argument  w.  It
// *  performs a choice of two types of loops:
// *
// *  IJOB=1, followed by
// *  IJOB=2: It takes as input a list of intervals and returns a list of
// *          sufficiently small intervals whose union contains the same
// *          eigenvalues as the union of the original intervals.
// *          The input intervals are (AB(j,1),AB(j,2)], j=1,...,MINP.
// *          The output interval (AB(j,1),AB(j,2)] will contain
// *          eigenvalues NAB(j,1)+1,...,NAB(j,2), where 1 <= j <= MOUT.
// *
// *  IJOB=3: It performs a binary search in each input interval
// *          (AB(j,1),AB(j,2)] for a point  w(j)  such that
// *          N(w(j))=NVAL(j), and uses  C(j)  as the starting point of
// *          the search.  If such a w(j) is found, then on output
// *          AB(j,1)=AB(j,2)=w.  If no such w(j) is found, then on output
// *          (AB(j,1),AB(j,2)] will be a small interval containing the
// *          point where N(w) jumps through NVAL(j), unless that point
// *          lies outside the initial interval.
// *
// *  Note that the intervals are in all cases half-open intervals,
// *  i.e., of the form  (a,b] , which includes  b  but not  a .
// *
// *  To avoid underflow, the matrix should be scaled so that its largest
// *  element is no greater than  overflow**(1/2) * underflow**(1/4)
// *  in absolute value.  To assure the most accurate computation
// *  of small eigenvalues, the matrix should be scaled to be
// *  not much smaller than that, either.
// *
// *  See W. Kahan "Accurate Eigenvalues of a Symmetric Tridiagonal
// *  Matrix", Report CS41, Computer Science Dept., Stanford
// *  University, July 21, 1966
// *
// *  Note: the arguments are, in general, *not* checked for unreasonable
// *  values.
// *
// *  Arguments
// *  =========
// *
// *  IJOB    (input) INTEGER
// *          Specifies what is to be done:
// *          = 1:  Compute NAB for the initial intervals.
// *          = 2:  Perform bisection iteration to find eigenvalues of T.
// *          = 3:  Perform bisection iteration to invert N(w), i.e.,
// *                to find a point which has a specified number of
// *                eigenvalues of T to its left.
// *          Other values will cause DLAEBZ to return with INFO=-1.
// *
// *  NITMAX  (input) INTEGER
// *          The maximum number of "levels" of bisection to be
// *          performed, i.e., an interval of width W will not be made
// *          smaller than 2^(-NITMAX) * W.  If not all intervals
// *          have converged after NITMAX iterations, then INFO is set
// *          to the number of non-converged intervals.
// *
// *  N       (input) INTEGER
// *          The dimension n of the tridiagonal matrix T.  It must be at
// *          least 1.
// *
// *  MMAX    (input) INTEGER
// *          The maximum number of intervals.  If more than MMAX intervals
// *          are generated, then DLAEBZ will quit with INFO=MMAX+1.
// *
// *  MINP    (input) INTEGER
// *          The initial number of intervals.  It may not be greater than
// *          MMAX.
// *
// *  NBMIN   (input) INTEGER
// *          The smallest number of intervals that should be processed
// *          using a vector loop.  If zero, then only the scalar loop
// *          will be used.
// *
// *  ABSTOL  (input) DOUBLE PRECISION
// *          The minimum (absolute) width of an interval.  When an
// *          interval is narrower than ABSTOL, or than RELTOL times the
// *          larger (in magnitude) endpoint, then it is considered to be
// *          sufficiently small, i.e., converged.  This must be at least
// *          zero.
// *
// *  RELTOL  (input) DOUBLE PRECISION
// *          The minimum relative width of an interval.  When an interval
// *          is narrower than ABSTOL, or than RELTOL times the larger (in
// *          magnitude) endpoint, then it is considered to be
// *          sufficiently small, i.e., converged.  Note: this should
// *          always be at least radix*machine epsilon.
// *
// *  PIVMIN  (input) DOUBLE PRECISION
// *          The minimum absolute value of a "pivot" in the Sturm
// *          sequence loop.  This *must* be at least  max |e(j)**2| *
// *          safe_min  and at least safe_min, where safe_min is at least
// *          the smallest number that can divide one without overflow.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal elements of the tridiagonal matrix T.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N)
// *          The offdiagonal elements of the tridiagonal matrix T in
// *          positions 1 through N-1.  E(N) is arbitrary.
// *
// *  E2      (input) DOUBLE PRECISION array, dimension (N)
// *          The squares of the offdiagonal elements of the tridiagonal
// *          matrix T.  E2(N) is ignored.
// *
// *  NVAL    (input/output) INTEGER array, dimension (MINP)
// *          If IJOB=1 or 2, not referenced.
// *          If IJOB=3, the desired values of N(w).  The elements of NVAL
// *          will be reordered to correspond with the intervals in AB.
// *          Thus, NVAL(j) on output will not, in general be the same as
// *          NVAL(j) on input, but it will correspond with the interval
// *          (AB(j,1),AB(j,2)] on output.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (MMAX,2)
// *          The endpoints of the intervals.  AB(j,1) is  a(j), the left
// *          endpoint of the j-th interval, and AB(j,2) is b(j), the
// *          right endpoint of the j-th interval.  The input intervals
// *          will, in general, be modified, split, and reordered by the
// *          calculation.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (MMAX)
// *          If IJOB=1, ignored.
// *          If IJOB=2, workspace.
// *          If IJOB=3, then on input C(j) should be initialized to the
// *          first search point in the binary search.
// *
// *  MOUT    (output) INTEGER
// *          If IJOB=1, the number of eigenvalues in the intervals.
// *          If IJOB=2 or 3, the number of intervals output.
// *          If IJOB=3, MOUT will equal MINP.
// *
// *  NAB     (input/output) INTEGER array, dimension (MMAX,2)
// *          If IJOB=1, then on output NAB(i,j) will be set to N(AB(i,j)).
// *          If IJOB=2, then on input, NAB(i,j) should be set.  It must
// *             satisfy the condition:
// *             N(AB(i,1)) <= NAB(i,1) <= NAB(i,2) <= N(AB(i,2)),
// *             which means that in interval i only eigenvalues
// *             NAB(i,1)+1,...,NAB(i,2) will be considered.  Usually,
// *             NAB(i,j)=N(AB(i,j)), from a previous call to DLAEBZ with
// *             IJOB=1.
// *             On output, NAB(i,j) will contain
// *             max(na(k),min(nb(k),N(AB(i,j)))), where k is the index of
// *             the input interval that the output interval
// *             (AB(j,1),AB(j,2)] came from, and na(k) and nb(k) are the
// *             the input values of NAB(k,1) and NAB(k,2).
// *          If IJOB=3, then on output, NAB(i,j) contains N(AB(i,j)),
// *             unless N(w) > NVAL(i) for all search points  w , in which
// *             case NAB(i,1) will not be modified, i.e., the output
// *             value will be the same as the input value (modulo
// *             reorderings -- see NVAL and AB), or unless N(w) < NVAL(i)
// *             for all search points  w , in which case NAB(i,2) will
// *             not be modified.  Normally, NAB should be set to some
// *             distinctive value(s) before DLAEBZ is called.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (MMAX)
// *          Workspace.
// *
// *  IWORK   (workspace) INTEGER array, dimension (MMAX)
// *          Workspace.
// *
// *  INFO    (output) INTEGER
// *          = 0:       All intervals converged.
// *          = 1--MMAX: The last INFO intervals did not converge.
// *          = MMAX+1:  More than MMAX intervals were generated.
// *
// *  Further Details
// *  ===============
// *
// *      This routine is intended to be called only by other LAPACK
// *  routines, thus the interface is less user-friendly.  It is intended
// *  for two purposes:
// *
// *  (a) finding eigenvalues.  In this case, DLAEBZ should have one or
// *      more initial intervals set up in AB, and DLAEBZ should be called
// *      with IJOB=1.  This sets up NAB, and also counts the eigenvalues.
// *      Intervals with no eigenvalues would usually be thrown out at
// *      this point.  Also, if not all the eigenvalues in an interval i
// *      are desired, NAB(i,1) can be increased or NAB(i,2) decreased.
// *      For example, set NAB(i,1)=NAB(i,2)-1 to get the largest
// *      eigenvalue.  DLAEBZ is then called with IJOB=2 and MMAX
// *      no smaller than the value of MOUT returned by the call with
// *      IJOB=1.  After this (IJOB=2) call, eigenvalues NAB(i,1)+1
// *      through NAB(i,2) are approximately AB(i,1) (or AB(i,2)) to the
// *      tolerance specified by ABSTOL and RELTOL.
// *
// *  (b) finding an interval (a',b'] containing eigenvalues w(f),...,w(l).
// *      In this case, start with a Gershgorin interval  (a,b).  Set up
// *      AB to contain 2 search intervals, both initially (a,b).  One
// *      NVAL element should contain  f-1  and the other should contain  l
// *      , while C should contain a and b, resp.  NAB(i,1) should be -1
// *      and NAB(i,2) should be N+1, to flag an error if the desired
// *      interval does not lie in (a,b).  DLAEBZ is then called with
// *      IJOB=3.  On exit, if w(f-1) < w(f), then one of the intervals --
// *      j -- will have AB(j,1)=AB(j,2) and NAB(j,1)=NAB(j,2)=f-1, while
// *      if, to the specified tolerance, w(f-k)=...=w(f+r), k > 0 and r
// *      >= 0, then the interval will have  N(AB(j,1))=NAB(j,1)=f-k and
// *      N(AB(j,2))=NAB(j,2)=f+r.  The cases w(l) < w(l+1) and
// *      w(l-r)=...=w(l+k) are handled similarly.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double two= 2.0e0;
static double half= 1.0e0/two;
// *     ..
// *     .. Local Scalars ..
static int itmp1= 0;
static int itmp2= 0;
static int j= 0;
static int ji= 0;
static int jit= 0;
static int jp= 0;
static int kf= 0;
static int kfnew= 0;
static int kl= 0;
static int klnew= 0;
static double tmp1= 0.0;
static double tmp2= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for Errors
// *

public static void dlaebz (int ijob,
int nitmax,
int n,
int mmax,
int minp,
int nbmin,
double abstol,
double reltol,
double pivmin,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] e2, int _e2_offset,
int [] nval, int _nval_offset,
double [] ab, int _ab_offset,
double [] c, int _c_offset,
intW mout,
int [] nab, int _nab_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
if (ijob < 1 || ijob > 3)  {
    info.val = -1;
Dummy.go_to("Dlaebz",999999);
}              // Close if()
// *
// *     Initialize NAB
// *
if (ijob == 1)  {
    // *
// *        Compute the number of eigenvalues in the initial intervals.
// *
mout.val = 0;
{
forloop30:
for (ji = 1; ji <= minp; ji++) {
{
forloop20:
for (jp = 1; jp <= 2; jp++) {
tmp1 = d[(1)- 1+ _d_offset]-ab[(ji)- 1+(jp- 1)*mmax+ _ab_offset];
if (Math.abs(tmp1) < pivmin)  
    tmp1 = -pivmin;
nab[(ji)- 1+(jp- 1)*mmax+ _nab_offset] = 0;
if (tmp1 <= zero)  
    nab[(ji)- 1+(jp- 1)*mmax+ _nab_offset] = 1;
// *
{
forloop10:
for (j = 2; j <= n; j++) {
tmp1 = d[(j)- 1+ _d_offset]-e2[(j-1)- 1+ _e2_offset]/tmp1-ab[(ji)- 1+(jp- 1)*mmax+ _ab_offset];
if (Math.abs(tmp1) < pivmin)  
    tmp1 = -pivmin;
if (tmp1 <= zero)  
    nab[(ji)- 1+(jp- 1)*mmax+ _nab_offset] = nab[(ji)- 1+(jp- 1)*mmax+ _nab_offset]+1;
Dummy.label("Dlaebz",10);
}              //  Close for() loop. 
}
Dummy.label("Dlaebz",20);
}              //  Close for() loop. 
}
mout.val = mout.val+nab[(ji)- 1+(2- 1)*mmax+ _nab_offset]-nab[(ji)- 1+(1- 1)*mmax+ _nab_offset];
Dummy.label("Dlaebz",30);
}              //  Close for() loop. 
}
Dummy.go_to("Dlaebz",999999);
}              // Close if()
// *
// *     Initialize for loop
// *
// *     KF and KL have the following meaning:
// *        Intervals 1,...,KF-1 have converged.
// *        Intervals KF,...,KL  still need to be refined.
// *
kf = 1;
kl = minp;
// *
// *     If IJOB=2, initialize C.
// *     If IJOB=3, use the user-supplied starting point.
// *
if (ijob == 2)  {
    {
forloop40:
for (ji = 1; ji <= minp; ji++) {
c[(ji)- 1+ _c_offset] = half*(ab[(ji)- 1+(1- 1)*mmax+ _ab_offset]+ab[(ji)- 1+(2- 1)*mmax+ _ab_offset]);
Dummy.label("Dlaebz",40);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Iteration loop
// *
{
forloop130:
for (jit = 1; jit <= nitmax; jit++) {
// *
// *        Loop over intervals
// *
if (kl-kf+1 >= nbmin && nbmin > 0)  {
    // *
// *           Begin of Parallel Version of the loop
// *
{
forloop60:
for (ji = kf; ji <= kl; ji++) {
// *
// *              Compute N(c), the number of eigenvalues less than c
// *
work[(ji)- 1+ _work_offset] = d[(1)- 1+ _d_offset]-c[(ji)- 1+ _c_offset];
iwork[(ji)- 1+ _iwork_offset] = 0;
if (work[(ji)- 1+ _work_offset] <= pivmin)  {
    iwork[(ji)- 1+ _iwork_offset] = 1;
work[(ji)- 1+ _work_offset] = Math.min(work[(ji)- 1+ _work_offset], -pivmin) ;
}              // Close if()
// *
{
forloop50:
for (j = 2; j <= n; j++) {
work[(ji)- 1+ _work_offset] = d[(j)- 1+ _d_offset]-e2[(j-1)- 1+ _e2_offset]/work[(ji)- 1+ _work_offset]-c[(ji)- 1+ _c_offset];
if (work[(ji)- 1+ _work_offset] <= pivmin)  {
    iwork[(ji)- 1+ _iwork_offset] = iwork[(ji)- 1+ _iwork_offset]+1;
work[(ji)- 1+ _work_offset] = Math.min(work[(ji)- 1+ _work_offset], -pivmin) ;
}              // Close if()
Dummy.label("Dlaebz",50);
}              //  Close for() loop. 
}
Dummy.label("Dlaebz",60);
}              //  Close for() loop. 
}
// *
if (ijob <= 2)  {
    // *
// *              IJOB=2: Choose all intervals containing eigenvalues.
// *
klnew = kl;
{
forloop70:
for (ji = kf; ji <= kl; ji++) {
// *
// *                 Insure that N(w) is monotone
// *
iwork[(ji)- 1+ _iwork_offset] = (int)(Math.min(nab[(ji)- 1+(2- 1)*mmax+ _nab_offset], Math.max(nab[(ji)- 1+(1- 1)*mmax+ _nab_offset], iwork[(ji)- 1+ _iwork_offset]) ) );
// *
// *                 Update the Queue -- add intervals if both halves
// *                 contain eigenvalues.
// *
if (iwork[(ji)- 1+ _iwork_offset] == nab[(ji)- 1+(2- 1)*mmax+ _nab_offset])  {
    // *
// *                    No eigenvalue in the upper interval:
// *                    just use the lower interval.
// *
ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
// *
}              // Close if()
else if (iwork[(ji)- 1+ _iwork_offset] == nab[(ji)- 1+(1- 1)*mmax+ _nab_offset])  {
    // *
// *                    No eigenvalue in the lower interval:
// *                    just use the upper interval.
// *
ab[(ji)- 1+(1- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
}              // Close else if()
else  {
  klnew = klnew+1;
if (klnew <= mmax)  {
    // *
// *                       Eigenvalue in both intervals -- add upper to
// *                       queue.
// *
ab[(klnew)- 1+(2- 1)*mmax+ _ab_offset] = ab[(ji)- 1+(2- 1)*mmax+ _ab_offset];
nab[(klnew)- 1+(2- 1)*mmax+ _nab_offset] = nab[(ji)- 1+(2- 1)*mmax+ _nab_offset];
ab[(klnew)- 1+(1- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
nab[(klnew)- 1+(1- 1)*mmax+ _nab_offset] = iwork[(ji)- 1+ _iwork_offset];
ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
nab[(ji)- 1+(2- 1)*mmax+ _nab_offset] = iwork[(ji)- 1+ _iwork_offset];
}              // Close if()
else  {
  info.val = mmax+1;
}              //  Close else.
}              //  Close else.
Dummy.label("Dlaebz",70);
}              //  Close for() loop. 
}
if (info.val != 0)  
    Dummy.go_to("Dlaebz",999999);
kl = klnew;
}              // Close if()
else  {
  // *
// *              IJOB=3: Binary search.  Keep only the interval containing
// *                      w   s.t. N(w) = NVAL
// *
{
forloop80:
for (ji = kf; ji <= kl; ji++) {
if (iwork[(ji)- 1+ _iwork_offset] <= nval[(ji)- 1+ _nval_offset])  {
    ab[(ji)- 1+(1- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
nab[(ji)- 1+(1- 1)*mmax+ _nab_offset] = iwork[(ji)- 1+ _iwork_offset];
}              // Close if()
if (iwork[(ji)- 1+ _iwork_offset] >= nval[(ji)- 1+ _nval_offset])  {
    ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = c[(ji)- 1+ _c_offset];
nab[(ji)- 1+(2- 1)*mmax+ _nab_offset] = iwork[(ji)- 1+ _iwork_offset];
}              // Close if()
Dummy.label("Dlaebz",80);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *           End of Parallel Version of the loop
// *
// *           Begin of Serial Version of the loop
// *
klnew = kl;
{
forloop100:
for (ji = kf; ji <= kl; ji++) {
// *
// *              Compute N(w), the number of eigenvalues less than w
// *
tmp1 = c[(ji)- 1+ _c_offset];
tmp2 = d[(1)- 1+ _d_offset]-tmp1;
itmp1 = 0;
if (tmp2 <= pivmin)  {
    itmp1 = 1;
tmp2 = Math.min(tmp2, -pivmin) ;
}              // Close if()
// *
// *              A series of compiler directives to defeat vectorization
// *              for the next loop
// *
// *$PL$ CMCHAR=' '
// CDIR$          NEXTSCALAR
// C$DIR          SCALAR
// CDIR$          NEXT SCALAR
// CVD$L          NOVECTOR
// CDEC$          NOVECTOR
// CVD$           NOVECTOR
// *VDIR          NOVECTOR
// *VOCL          LOOP,SCALAR
// CIBM           PREFER SCALAR
// *$PL$ CMCHAR='*'
// *
{
forloop90:
for (j = 2; j <= n; j++) {
tmp2 = d[(j)- 1+ _d_offset]-e2[(j-1)- 1+ _e2_offset]/tmp2-tmp1;
if (tmp2 <= pivmin)  {
    itmp1 = itmp1+1;
tmp2 = Math.min(tmp2, -pivmin) ;
}              // Close if()
Dummy.label("Dlaebz",90);
}              //  Close for() loop. 
}
// *
if (ijob <= 2)  {
    // *
// *                 IJOB=2: Choose all intervals containing eigenvalues.
// *
// *                 Insure that N(w) is monotone
// *
itmp1 = (int)(Math.min(nab[(ji)- 1+(2- 1)*mmax+ _nab_offset], Math.max(nab[(ji)- 1+(1- 1)*mmax+ _nab_offset], itmp1) ) );
// *
// *                 Update the Queue -- add intervals if both halves
// *                 contain eigenvalues.
// *
if (itmp1 == nab[(ji)- 1+(2- 1)*mmax+ _nab_offset])  {
    // *
// *                    No eigenvalue in the upper interval:
// *                    just use the lower interval.
// *
ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = tmp1;
// *
}              // Close if()
else if (itmp1 == nab[(ji)- 1+(1- 1)*mmax+ _nab_offset])  {
    // *
// *                    No eigenvalue in the lower interval:
// *                    just use the upper interval.
// *
ab[(ji)- 1+(1- 1)*mmax+ _ab_offset] = tmp1;
}              // Close else if()
else if (klnew < mmax)  {
    // *
// *                    Eigenvalue in both intervals -- add upper to queue.
// *
klnew = klnew+1;
ab[(klnew)- 1+(2- 1)*mmax+ _ab_offset] = ab[(ji)- 1+(2- 1)*mmax+ _ab_offset];
nab[(klnew)- 1+(2- 1)*mmax+ _nab_offset] = nab[(ji)- 1+(2- 1)*mmax+ _nab_offset];
ab[(klnew)- 1+(1- 1)*mmax+ _ab_offset] = tmp1;
nab[(klnew)- 1+(1- 1)*mmax+ _nab_offset] = itmp1;
ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = tmp1;
nab[(ji)- 1+(2- 1)*mmax+ _nab_offset] = itmp1;
}              // Close else if()
else  {
  info.val = mmax+1;
Dummy.go_to("Dlaebz",999999);
}              //  Close else.
}              // Close if()
else  {
  // *
// *                 IJOB=3: Binary search.  Keep only the interval
// *                         containing  w  s.t. N(w) = NVAL
// *
if (itmp1 <= nval[(ji)- 1+ _nval_offset])  {
    ab[(ji)- 1+(1- 1)*mmax+ _ab_offset] = tmp1;
nab[(ji)- 1+(1- 1)*mmax+ _nab_offset] = itmp1;
}              // Close if()
if (itmp1 >= nval[(ji)- 1+ _nval_offset])  {
    ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = tmp1;
nab[(ji)- 1+(2- 1)*mmax+ _nab_offset] = itmp1;
}              // Close if()
}              //  Close else.
Dummy.label("Dlaebz",100);
}              //  Close for() loop. 
}
kl = klnew;
// *
// *           End of Serial Version of the loop
// *
}              //  Close else.
// *
// *        Check for convergence
// *
kfnew = kf;
{
forloop110:
for (ji = kf; ji <= kl; ji++) {
tmp1 = Math.abs(ab[(ji)- 1+(2- 1)*mmax+ _ab_offset]-ab[(ji)- 1+(1- 1)*mmax+ _ab_offset]);
tmp2 = Math.max(Math.abs(ab[(ji)- 1+(2- 1)*mmax+ _ab_offset]), Math.abs(ab[(ji)- 1+(1- 1)*mmax+ _ab_offset])) ;
if (tmp1 < Math.max((abstol) > (pivmin) ? (abstol) : (pivmin), reltol*tmp2) || nab[(ji)- 1+(1- 1)*mmax+ _nab_offset] >= nab[(ji)- 1+(2- 1)*mmax+ _nab_offset])  {
    // *
// *              Converged -- Swap with position KFNEW,
// *                           then increment KFNEW
// *
if (ji > kfnew)  {
    tmp1 = ab[(ji)- 1+(1- 1)*mmax+ _ab_offset];
tmp2 = ab[(ji)- 1+(2- 1)*mmax+ _ab_offset];
itmp1 = nab[(ji)- 1+(1- 1)*mmax+ _nab_offset];
itmp2 = nab[(ji)- 1+(2- 1)*mmax+ _nab_offset];
ab[(ji)- 1+(1- 1)*mmax+ _ab_offset] = ab[(kfnew)- 1+(1- 1)*mmax+ _ab_offset];
ab[(ji)- 1+(2- 1)*mmax+ _ab_offset] = ab[(kfnew)- 1+(2- 1)*mmax+ _ab_offset];
nab[(ji)- 1+(1- 1)*mmax+ _nab_offset] = nab[(kfnew)- 1+(1- 1)*mmax+ _nab_offset];
nab[(ji)- 1+(2- 1)*mmax+ _nab_offset] = nab[(kfnew)- 1+(2- 1)*mmax+ _nab_offset];
ab[(kfnew)- 1+(1- 1)*mmax+ _ab_offset] = tmp1;
ab[(kfnew)- 1+(2- 1)*mmax+ _ab_offset] = tmp2;
nab[(kfnew)- 1+(1- 1)*mmax+ _nab_offset] = itmp1;
nab[(kfnew)- 1+(2- 1)*mmax+ _nab_offset] = itmp2;
if (ijob == 3)  {
    itmp1 = nval[(ji)- 1+ _nval_offset];
nval[(ji)- 1+ _nval_offset] = nval[(kfnew)- 1+ _nval_offset];
nval[(kfnew)- 1+ _nval_offset] = itmp1;
}              // Close if()
}              // Close if()
kfnew = kfnew+1;
}              // Close if()
Dummy.label("Dlaebz",110);
}              //  Close for() loop. 
}
kf = kfnew;
// *
// *        Choose Midpoints
// *
{
forloop120:
for (ji = kf; ji <= kl; ji++) {
c[(ji)- 1+ _c_offset] = half*(ab[(ji)- 1+(1- 1)*mmax+ _ab_offset]+ab[(ji)- 1+(2- 1)*mmax+ _ab_offset]);
Dummy.label("Dlaebz",120);
}              //  Close for() loop. 
}
// *
// *        If no more intervals to refine, quit.
// *
if (kf > kl)  
    Dummy.go_to("Dlaebz",140);
Dummy.label("Dlaebz",130);
}              //  Close for() loop. 
}
// *
// *     Converged
// *
label140:
   Dummy.label("Dlaebz",140);
info.val = (int)(Math.max(kl+1-kf, 0) );
mout.val = kl;
// *
Dummy.go_to("Dlaebz",999999);
// *
// *     End of DLAEBZ
// *
Dummy.label("Dlaebz",999999);
return;
   }
} // End class.
