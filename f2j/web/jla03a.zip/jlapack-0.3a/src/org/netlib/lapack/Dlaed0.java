/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed0 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED0 computes all eigenvalues and corresponding eigenvectors of a
// *  symmetric tridiagonal matrix using the divide and conquer method.
// *
// *  Arguments
// *  =========
// *
// *  ICOMPQ  (input) INTEGER
// *          = 0:  Compute eigenvalues only.
// *          = 1:  Compute eigenvectors of original dense symmetric matrix
// *                also.  On entry, Q contains the orthogonal matrix used
// *                to reduce the original matrix to tridiagonal form.
// *          = 2:  Compute eigenvalues and eigenvectors of tridiagonal
// *                matrix.
// *
// *  QSIZ   (input) INTEGER
// *         The dimension of the orthogonal matrix used to reduce
// *         the full matrix to tridiagonal form.  QSIZ >= N if ICOMPQ = 1.
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  D      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On entry, the main diagonal of the tridiagonal matrix.
// *         On exit, its eigenvalues.
// *
// *  E      (input) DOUBLE PRECISION array, dimension (N-1)
// *         The off-diagonal elements of the tridiagonal matrix.
// *         On exit, E has been destroyed.
// *
// *  Q      (input/output) DOUBLE PRECISION array, dimension (LDQ, N)
// *         On entry, Q must contain an N-by-N orthogonal matrix.
// *         If ICOMPQ = 0    Q is not referenced.
// *         If ICOMPQ = 1    On entry, Q is a subset of the columns of the
// *                          orthogonal matrix used to reduce the full
// *                          matrix to tridiagonal form corresponding to
// *                          the subset of the full matrix which is being
// *                          decomposed at this time.
// *         If ICOMPQ = 2    On entry, Q will be the identity matrix.
// *                          On exit, Q contains the eigenvectors of the
// *                          tridiagonal matrix.
// *
// *  LDQ    (input) INTEGER
// *         The leading dimension of the array Q.  If eigenvectors are
// *         desired, then  LDQ >= max(1,N).  In any case,  LDQ >= 1.
// *
// *  QSTORE (workspace) DOUBLE PRECISION array, dimension (LDQS, N)
// *         Referenced only when ICOMPQ = 1.  Used to store parts of
// *         the eigenvector matrix when the updating matrix multiplies
// *         take place.
// *
// *  LDQS   (input) INTEGER
// *         The leading dimension of the array QSTORE.  If ICOMPQ = 1,
// *         then  LDQS >= max(1,N).  In any case,  LDQS >= 1.
// *
// *  WORK   (workspace) DOUBLE PRECISION array,
// *                                dimension (1 + 3*N + 2*N*lg N + 2*N**2)
// *                        ( lg( N ) = smallest integer k
// *                                    such that 2^k >= N )
// *
// *  IWORK  (workspace) INTEGER array,
// *         If ICOMPQ = 0 or 1, the dimension of IWORK must be at least
// *                        6 + 6*N + 5*N*lg N.
// *                        ( lg( N ) = smallest integer k
// *                                    such that 2^k >= N )
// *         If ICOMPQ = 2, the dimension of IWORK must be at least
// *                        2 + 5*N.
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  The algorithm failed to compute an eigenvalue while
// *                working on the submatrix lying in rows and columns
// *                INFO/(N+1) through mod(INFO,N+1).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int smlsiz= 25;
static double zero= 0.e0;
static double one= 1.e0;
static double two= 2.e0;
// *     ..
// *     .. Local Scalars ..
static int curlvl= 0;
static int curprb= 0;
static int curr= 0;
static int i= 0;
static int igivcl= 0;
static int igivnm= 0;
static int igivpt= 0;
static int indxq= 0;
static int iperm= 0;
static int iprmpt= 0;
static int iq= 0;
static int iqptr= 0;
static int iwrem= 0;
static int j= 0;
static int k= 0;
static int lgn= 0;
static int matsiz= 0;
static int msd2= 0;
static int smm1= 0;
static int spm1= 0;
static int spm2= 0;
static int submat= 0;
static int subpbs= 0;
static int tlvls= 0;
static double temp= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed0 (int icompq,
int qsiz,
int n,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] q, int _q_offset,
int ldq,
double [] qstore, int _qstore_offset,
int ldqs,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
// *
if (icompq < 0 || icompq > 2)  {
    info.val = -1;
}              // Close if()
else if ((icompq == 1) && (qsiz < Math.max(0, n) ))  {
    info.val = -2;
}              // Close else if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (ldq < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldqs < Math.max(1, n) )  {
    info.val = -9;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED0",-info.val);
Dummy.go_to("Dlaed0",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaed0",999999);
// *
// *     Determine the size and placement of the submatrices, and save in
// *     the leading elements of IWORK.
// *
iwork[(1)- 1+ _iwork_offset] = n;
subpbs = 1;
tlvls = 0;
label10:
   Dummy.label("Dlaed0",10);
while (iwork[(subpbs)- 1+ _iwork_offset] > smlsiz)  {
    {
int _j_inc = -1;
forloop20:
for (j = subpbs; j >= 1; j += _j_inc) {
iwork[(2*j)- 1+ _iwork_offset] = (iwork[(j)- 1+ _iwork_offset]+1)/2;
iwork[(2*j-1)- 1+ _iwork_offset] = iwork[(j)- 1+ _iwork_offset]/2;
Dummy.label("Dlaed0",20);
}              //  Close for() loop. 
}
tlvls = tlvls+1;
subpbs = 2*subpbs;
// goto 10 (end while)
}              // Close if()
{
forloop30:
for (j = 2; j <= subpbs; j++) {
iwork[(j)- 1+ _iwork_offset] = iwork[(j)- 1+ _iwork_offset]+iwork[(j-1)- 1+ _iwork_offset];
Dummy.label("Dlaed0",30);
}              //  Close for() loop. 
}
// *
// *     Divide the matrix into SUBPBS submatrices of size at most SMLSIZ+1
// *     using rank-1 modifications (cuts).
// *
spm1 = subpbs-1;
{
forloop40:
for (i = 1; i <= spm1; i++) {
submat = iwork[(i)- 1+ _iwork_offset]+1;
smm1 = submat-1;
d[(smm1)- 1+ _d_offset] = d[(smm1)- 1+ _d_offset]-Math.abs(e[(smm1)- 1+ _e_offset]);
d[(submat)- 1+ _d_offset] = d[(submat)- 1+ _d_offset]-Math.abs(e[(smm1)- 1+ _e_offset]);
Dummy.label("Dlaed0",40);
}              //  Close for() loop. 
}
// *
indxq = 4*n+3;
if (icompq != 2)  {
    // *
// *        Set up workspaces for eigenvalues only/accumulate new vectors
// *        routine
// *
temp = Math.log((double)(n))/Math.log(two);
lgn = (int)(temp);
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
iprmpt = indxq+n+1;
iperm = iprmpt+n*lgn;
iqptr = iperm+n*lgn;
igivpt = iqptr+n+2;
igivcl = igivpt+n*lgn;
// *
igivnm = 1;
iq = igivnm+2*n*lgn;
iwrem = (int)(iq+Math.pow(n, 2)+1);
// *
// *        Initialize pointers
// *
{
forloop50:
for (i = 0; i <= subpbs; i++) {
iwork[(iprmpt+i)- 1+ _iwork_offset] = 1;
iwork[(igivpt+i)- 1+ _iwork_offset] = 1;
Dummy.label("Dlaed0",50);
}              //  Close for() loop. 
}
iwork[(iqptr)- 1+ _iwork_offset] = 1;
}              // Close if()
// *
// *     Solve each submatrix eigenproblem at the bottom of the divide and
// *     conquer tree.
// *
curr = 0;
{
forloop70:
for (i = 0; i <= spm1; i++) {
if (i == 0)  {
    submat = 1;
matsiz = iwork[(1)- 1+ _iwork_offset];
}              // Close if()
else  {
  submat = iwork[(i)- 1+ _iwork_offset]+1;
matsiz = iwork[(i+1)- 1+ _iwork_offset]-iwork[(i)- 1+ _iwork_offset];
}              //  Close else.
if (icompq == 2)  {
    Dsteqr.dsteqr("I",matsiz,d,(submat)- 1+ _d_offset,e,(submat)- 1+ _e_offset,q,(submat)- 1+(submat- 1)*ldq+ _q_offset,ldq,work,_work_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed0",130);
}              // Close if()
else  {
  Dsteqr.dsteqr("I",matsiz,d,(submat)- 1+ _d_offset,e,(submat)- 1+ _e_offset,work,(iq-1+iwork[(iqptr+curr)- 1+ _iwork_offset])- 1+ _work_offset,matsiz,work,_work_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed0",130);
if (icompq == 1)  {
    Dgemm.dgemm("N","N",qsiz,matsiz,matsiz,one,q,(1)- 1+(submat- 1)*ldq+ _q_offset,ldq,work,(iq-1+iwork[(iqptr+curr)- 1+ _iwork_offset])- 1+ _work_offset,matsiz,zero,qstore,(1)- 1+(submat- 1)*ldqs+ _qstore_offset,ldqs);
}              // Close if()
iwork[(iqptr+curr+1)- 1+ _iwork_offset] = (int)(iwork[(iqptr+curr)- 1+ _iwork_offset]+Math.pow(matsiz, 2));
curr = curr+1;
}              //  Close else.
k = 1;
{
forloop60:
for (j = submat; j <= iwork[(i+1)- 1+ _iwork_offset]; j++) {
iwork[(indxq+j)- 1+ _iwork_offset] = k;
k = k+1;
Dummy.label("Dlaed0",60);
}              //  Close for() loop. 
}
Dummy.label("Dlaed0",70);
}              //  Close for() loop. 
}
// *
// *     Successively merge eigensystems of adjacent submatrices
// *     into eigensystem for the corresponding larger matrix.
// *
// *     while ( SUBPBS > 1 )
// *
curlvl = 1;
label80:
   Dummy.label("Dlaed0",80);
while (subpbs > 1)  {
    spm2 = subpbs-2;
{
int _i_inc = 2;
forloop90:
for (i = 0; i <= spm2; i += _i_inc) {
if (i == 0)  {
    submat = 1;
matsiz = iwork[(2)- 1+ _iwork_offset];
msd2 = iwork[(1)- 1+ _iwork_offset];
curprb = 0;
}              // Close if()
else  {
  submat = iwork[(i)- 1+ _iwork_offset]+1;
matsiz = iwork[(i+2)- 1+ _iwork_offset]-iwork[(i)- 1+ _iwork_offset];
msd2 = matsiz/2;
curprb = curprb+1;
}              //  Close else.
// *
// *     Merge lower order eigensystems (of size MSD2 and MATSIZ - MSD2)
// *     into an eigensystem of size MATSIZ.
// *     DLAED1 is used only for the full eigensystem of a tridiagonal
// *     matrix.
// *     DLAED7 handles the cases in which eigenvalues only or eigenvalues
// *     and eigenvectors of a full symmetric matrix (which was reduced to
// *     tridiagonal form) are desired.
// *
if (icompq == 2)  {
    dlaed1_adapter(matsiz,d,(submat)- 1+ _d_offset,q,(submat)- 1+(submat- 1)*ldq+ _q_offset,ldq,iwork,(indxq+submat)- 1+ _iwork_offset,e,(submat+msd2-1)- 1+ _e_offset,msd2,work,_work_offset,iwork,(subpbs+1)- 1+ _iwork_offset,info);
}              // Close if()
else  {
  dlaed7_adapter(icompq,matsiz,qsiz,tlvls,curlvl,curprb,d,(submat)- 1+ _d_offset,qstore,(1)- 1+(submat- 1)*ldqs+ _qstore_offset,ldqs,iwork,(indxq+submat)- 1+ _iwork_offset,e,(submat+msd2-1)- 1+ _e_offset,msd2,work,(iq)- 1+ _work_offset,iwork,(iqptr)- 1+ _iwork_offset,iwork,(iprmpt)- 1+ _iwork_offset,iwork,(iperm)- 1+ _iwork_offset,iwork,(igivpt)- 1+ _iwork_offset,iwork,(igivcl)- 1+ _iwork_offset,work,(igivnm)- 1+ _work_offset,work,(iwrem)- 1+ _work_offset,iwork,(subpbs+1)- 1+ _iwork_offset,info);
}              //  Close else.
if (info.val != 0)  
    Dummy.go_to("Dlaed0",130);
iwork[(i/2+1)- 1+ _iwork_offset] = iwork[(i+2)- 1+ _iwork_offset];
Dummy.label("Dlaed0",90);
}              //  Close for() loop. 
}
subpbs = subpbs/2;
curlvl = curlvl+1;
// goto 80 (end while)
}              // Close if()
// *
// *     end while
// *
// *     Re-merge the eigenvalues/vectors which were deflated at the final
// *     merge step.
// *
if (icompq == 1)  {
    {
forloop100:
for (i = 1; i <= n; i++) {
j = iwork[(indxq+i)- 1+ _iwork_offset];
work[(i)- 1+ _work_offset] = d[(j)- 1+ _d_offset];
Dcopy.dcopy(qsiz,qstore,(1)- 1+(j- 1)*ldqs+ _qstore_offset,1,q,(1)- 1+(i- 1)*ldq+ _q_offset,1);
Dummy.label("Dlaed0",100);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,work,_work_offset,1,d,_d_offset,1);
}              // Close if()
else if (icompq == 2)  {
    {
forloop110:
for (i = 1; i <= n; i++) {
j = iwork[(indxq+i)- 1+ _iwork_offset];
work[(i)- 1+ _work_offset] = d[(j)- 1+ _d_offset];
Dcopy.dcopy(n,q,(1)- 1+(j- 1)*ldq+ _q_offset,1,work,(n*i+1)- 1+ _work_offset,1);
Dummy.label("Dlaed0",110);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,work,_work_offset,1,d,_d_offset,1);
Dlacpy.dlacpy("A",n,n,work,(n+1)- 1+ _work_offset,n,q,_q_offset,ldq);
}              // Close else if()
else  {
  {
forloop120:
for (i = 1; i <= n; i++) {
j = iwork[(indxq+i)- 1+ _iwork_offset];
work[(i)- 1+ _work_offset] = d[(j)- 1+ _d_offset];
Dummy.label("Dlaed0",120);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,work,_work_offset,1,d,_d_offset,1);
}              //  Close else.
Dummy.go_to("Dlaed0",140);
// *
label130:
   Dummy.label("Dlaed0",130);
info.val = submat*(n+1)+submat+matsiz-1;
// *
label140:
   Dummy.label("Dlaed0",140);
Dummy.go_to("Dlaed0",999999);
// *
// *     End of DLAED0
// *
Dummy.label("Dlaed0",999999);
return;
   }
// adapter for dlaed1
private static void dlaed1_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,int [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,int [] arg8 , int arg8_offset ,intW arg9 )
{
doubleW _f2j_tmp5 = new doubleW(arg5[arg5_offset]);

Dlaed1.dlaed1(arg0,arg1, arg1_offset,arg2, arg2_offset,arg3,arg4, arg4_offset,_f2j_tmp5,arg6,arg7, arg7_offset,arg8, arg8_offset,arg9);

arg5[arg5_offset] = _f2j_tmp5.val;
}

// adapter for dlaed7
private static void dlaed7_adapter(int arg0 ,int arg1 ,int arg2 ,int arg3 ,int arg4 ,int arg5 ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset ,int arg8 ,int [] arg9 , int arg9_offset ,double [] arg10 , int arg10_offset ,int arg11 ,double [] arg12 , int arg12_offset ,int [] arg13 , int arg13_offset ,int [] arg14 , int arg14_offset ,int [] arg15 , int arg15_offset ,int [] arg16 , int arg16_offset ,int [] arg17 , int arg17_offset ,double [] arg18 , int arg18_offset ,double [] arg19 , int arg19_offset ,int [] arg20 , int arg20_offset ,intW arg21 )
{
doubleW _f2j_tmp10 = new doubleW(arg10[arg10_offset]);

Dlaed7.dlaed7(arg0,arg1,arg2,arg3,arg4,arg5,arg6, arg6_offset,arg7, arg7_offset,arg8,arg9, arg9_offset,_f2j_tmp10,arg11,arg12, arg12_offset,arg13, arg13_offset,arg14, arg14_offset,arg15, arg15_offset,arg16, arg16_offset,arg17, arg17_offset,arg18, arg18_offset,arg19, arg19_offset,arg20, arg20_offset,arg21);

arg10[arg10_offset] = _f2j_tmp10.val;
}

} // End class.
