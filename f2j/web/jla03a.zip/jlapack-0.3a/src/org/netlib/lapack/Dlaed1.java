/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed1 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED1 computes the updated eigensystem of a diagonal
// *  matrix after modification by a rank-one symmetric matrix.  This
// *  routine is used only for the eigenproblem which requires all
// *  eigenvalues and eigenvectors of a tridiagonal matrix.  DLAED7 handles
// *  the case in which eigenvalues only or eigenvalues and eigenvectors
// *  of a full symmetric matrix (which was reduced to tridiagonal form)
// *  are desired.
// *
// *    T = Q(in) ( D(in) + RHO * Z*Z' ) Q'(in) = Q(out) * D(out) * Q'(out)
// *
// *     where Z = Q'u, u is a vector of length N with ones in the
// *     CUTPNT and CUTPNT + 1 th elements and zeros elsewhere.
// *
// *     The eigenvectors of the original matrix are stored in Q, and the
// *     eigenvalues are in D.  The algorithm consists of three stages:
// *
// *        The first stage consists of deflating the size of the problem
// *        when there are multiple eigenvalues or if there is a zero in
// *        the Z vector.  For each such occurence the dimension of the
// *        secular equation problem is reduced by one.  This stage is
// *        performed by the routine DLAED2.
// *
// *        The second stage consists of calculating the updated
// *        eigenvalues. This is done by finding the roots of the secular
// *        equation via the routine DLAED4 (as called by SLAED3).
// *        This routine also calculates the eigenvectors of the current
// *        problem.
// *
// *        The final stage consists of computing the updated eigenvectors
// *        directly using the updated eigenvalues.  The eigenvectors for
// *        the current problem are multiplied with the eigenvectors from
// *        the overall problem.
// *
// *  Arguments
// *  =========
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  D      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On entry, the eigenvalues of the rank-1-perturbed matrix.
// *         On exit, the eigenvalues of the repaired matrix.
// *
// *  Q      (input/output) DOUBLE PRECISION array, dimension (LDQ,N)
// *         On entry, the eigenvectors of the rank-1-perturbed matrix.
// *         On exit, the eigenvectors of the repaired tridiagonal matrix.
// *
// *  LDQ    (input) INTEGER
// *         The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  INDXQ  (input/output) INTEGER array, dimension (N)
// *         On entry, the permutation which separately sorts the two
// *         subproblems in D into ascending order.
// *         On exit, the permutation which will reintegrate the
// *         subproblems back into sorted order,
// *         i.e. D( INDXQ( I = 1, N ) ) will be in ascending order.
// *
// *  RHO    (input) DOUBLE PRECISION
// *         The subdiagonal entry used to create the rank-1 modification.
// *
// *  CUTPNT (input) INTEGER
// *         The location of the last eigenvalue in the leading sub-matrix.
// *         min(1,N) <= CUTPNT <= N.
// *
// *  WORK   (workspace) DOUBLE PRECISION array, dimension (3*N+2*N**2)
// *
// *  IWORK  (workspace) INTEGER array, dimension (4*N)
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = 1, an eigenvalue did not converge
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int coltyp= 0;
static int i= 0;
static int idlmda= 0;
static int indx= 0;
static int indxc= 0;
static int indxp= 0;
static int iq2= 0;
static int is= 0;
static int iw= 0;
static int iz= 0;
static intW k= new intW(0);
static int ldq2= 0;
static int n1= 0;
static int n2= 0;
static int zpp1= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed1 (int n,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
int [] indxq, int _indxq_offset,
doubleW rho,
int cutpnt,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
// *
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (ldq < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (Math.min(1, n)  > cutpnt || n < cutpnt)  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED1",-info.val);
Dummy.go_to("Dlaed1",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaed1",999999);
// *
// *     The following values are for bookkeeping purposes only.  They are
// *     integer pointers which indicate the portion of the workspace
// *     used by a particular array in DLAED2 and SLAED3.
// *
ldq2 = n;
// *
iz = 1;
idlmda = iz+n;
iw = idlmda+n;
iq2 = iw+n;
is = iq2+n*ldq2;
// *
indx = 1;
indxc = indx+n;
coltyp = indxc+n;
indxp = coltyp+n;
// *
// *
// *     Form the z-vector which consists of the last row of Q_1 and the
// *     first row of Q_2.
// *
Dcopy.dcopy(cutpnt,q,(cutpnt)- 1+(1- 1)*ldq+ _q_offset,ldq,work,(iz)- 1+ _work_offset,1);
zpp1 = cutpnt+1;
Dcopy.dcopy(n-cutpnt,q,(zpp1)- 1+(zpp1- 1)*ldq+ _q_offset,ldq,work,(iz+cutpnt)- 1+ _work_offset,1);
// *
// *     Deflate eigenvalues.
// *
Dlaed2.dlaed2(k,n,d,_d_offset,q,_q_offset,ldq,indxq,_indxq_offset,rho,cutpnt,work,(iz)- 1+ _work_offset,work,(idlmda)- 1+ _work_offset,work,(iq2)- 1+ _work_offset,ldq2,iwork,(indxc)- 1+ _iwork_offset,work,(iw)- 1+ _work_offset,iwork,(indxp)- 1+ _iwork_offset,iwork,(indx)- 1+ _iwork_offset,iwork,(coltyp)- 1+ _iwork_offset,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed1",20);
// *
// *     Solve Secular Equation.
// *
if (k.val != 0)  {
    Dlaed3.dlaed3(k.val,1,k.val,n,d,_d_offset,q,_q_offset,ldq,rho.val,cutpnt,work,(idlmda)- 1+ _work_offset,work,(iq2)- 1+ _work_offset,ldq2,iwork,(indxc)- 1+ _iwork_offset,iwork,(coltyp)- 1+ _iwork_offset,work,(iw)- 1+ _work_offset,work,(is)- 1+ _work_offset,k.val,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed1",20);
// *
// *     Prepare the INDXQ sorting permutation.
// *
n1 = k.val;
n2 = n-k.val;
Dlamrg.dlamrg(n1,n2,d,_d_offset,1,-1,indxq,_indxq_offset);
}              // Close if()
else  {
  {
forloop10:
for (i = 1; i <= n; i++) {
indxq[(i)- 1+ _indxq_offset] = i;
Dummy.label("Dlaed1",10);
}              //  Close for() loop. 
}
}              //  Close else.
// *
label20:
   Dummy.label("Dlaed1",20);
Dummy.go_to("Dlaed1",999999);
// *
// *     End of DLAED1
// *
Dummy.label("Dlaed1",999999);
return;
   }
} // End class.
