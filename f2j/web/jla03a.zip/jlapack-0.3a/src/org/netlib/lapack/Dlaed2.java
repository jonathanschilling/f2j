/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED2 merges the two sets of eigenvalues together into a single
// *  sorted set.  Then it tries to deflate the size of the problem.
// *  There are two ways in which deflation can occur:  when two or more
// *  eigenvalues are close together or if there is a tiny entry in the
// *  Z vector.  For each such occurrence the order of the related secular
// *  equation problem is reduced by one.
// *
// *  Arguments
// *  =========
// *
// *  K      (output) INTEGER
// *         The number of non-deflated eigenvalues, and the order of the
// *         related secular equation. 0 <= K <=N.
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  D      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On entry, D contains the eigenvalues of the two submatrices to
// *         be combined.
// *         On exit, D contains the trailing (N-K) updated eigenvalues
// *         (those which were deflated) sorted into increasing order.
// *
// *  Q      (input/output) DOUBLE PRECISION array, dimension (LDQ, N)
// *         On entry, Q contains the eigenvectors of two submatrices in
// *         the two square blocks with corners at (1,1), (CUTPNT,CUTPNT)
// *         and (CUTPNT+1, CUTPNT+1), (N,N).
// *         On exit, Q contains the trailing (N-K) updated eigenvectors
// *         (those which were deflated) in its last N-K columns.
// *
// *  LDQ    (input) INTEGER
// *         The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  INDXQ  (input/output) INTEGER array, dimension (N)
// *         The permutation which separately sorts the two sub-problems
// *         in D into ascending order.  Note that elements in the second
// *         half of this permutation must first have CUTPNT added to their
// *         values. Destroyed on exit.
// *
// *  RHO    (input/output) DOUBLE PRECISION
// *         On entry, the off-diagonal element associated with the rank-1
// *         cut which originally split the two submatrices which are now
// *         being recombined.
// *         On exit, RHO has been modified to the value required by
// *         DLAED3.
// *
// *  CUTPNT (input) INTEGER
// *         The location of the last eigenvalue in the leading sub-matrix.
// *         min(1,N) <= CUTPNT <= N.
// *
// *  Z      (input) DOUBLE PRECISION array, dimension (N)
// *         On entry, Z contains the updating vector (the last
// *         row of the first sub-eigenvector matrix and the first row of
// *         the second sub-eigenvector matrix).
// *         On exit, the contents of Z have been destroyed by the updating
// *         process.
// *
// *  DLAMDA (output) DOUBLE PRECISION array, dimension (N)
// *         A copy of the first K eigenvalues which will be used by
// *         DLAED3 to form the secular equation.
// *
// *  Q2     (output) DOUBLE PRECISION array, dimension (LDQ2, N)
// *         A copy of the first K eigenvectors which will be used by
// *         DLAED3 in a matrix multiply (DGEMM) to solve for the new
// *         eigenvectors.   Q2 is arranged into three blocks.  The
// *         first block contains non-zero elements only at and above
// *         CUTPNT, the second contains non-zero elements only below
// *         CUTPNT, and the third is dense.
// *
// *  LDQ2   (input) INTEGER
// *         The leading dimension of the array Q2.  LDQ2 >= max(1,N).
// *
// *  INDXC  (output) INTEGER array, dimension (N)
// *         The permutation used to arrange the columns of the deflated
// *         Q matrix into three groups:  the first group contains non-zero
// *         elements only at and above CUTPNT, the second contains
// *         non-zero elements only below CUTPNT, and the third is dense.
// *
// *  W      (output) DOUBLE PRECISION array, dimension (N)
// *         The first k values of the final deflation-altered z-vector
// *         which will be passed to DLAED3.
// *
// *  INDXP  (workspace) INTEGER array, dimension (N)
// *         The permutation used to place deflated values of D at the end
// *         of the array.  INDXP(1:K) points to the nondeflated D-values
// *         and INDXP(K+1:N) points to the deflated eigenvalues.
// *
// *  INDX   (workspace) INTEGER array, dimension (N)
// *         The permutation used to sort the contents of D into ascending
// *         order.
// *
// *  COLTYP (workspace/output) INTEGER array, dimension (N)
// *         During execution, a label which will indicate which of the
// *         following types a column in the Q2 matrix is:
// *         1 : non-zero in the upper half only;
// *         2 : non-zero in the lower half only;
// *         3 : dense;
// *         4 : deflated.
// *         On exit, COLTYP(i) is the number of columns of type i,
// *         for i=1 to 4 only.
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double mone= -1.0e0;
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double eight= 8.0e0;
// *     ..
// *     .. Local Arrays ..
static int [] ctot= new int[(4)];
static int [] psm= new int[(4)];
// *     ..
// *     .. Local Scalars ..
static int ct= 0;
static int i= 0;
static int imax= 0;
static int j= 0;
static int jlam= 0;
static int jmax= 0;
static int jp= 0;
static int k2= 0;
static int n1= 0;
static int n1p1= 0;
static int n2= 0;
static double c= 0.0;
static double eps= 0.0;
static double s= 0.0;
static double t= 0.0;
static double tau= 0.0;
static double tol= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed2 (intW k,
int n,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
int [] indxq, int _indxq_offset,
doubleW rho,
int cutpnt,
double [] z, int _z_offset,
double [] dlamda, int _dlamda_offset,
double [] q2, int _q2_offset,
int ldq2,
int [] indxc, int _indxc_offset,
double [] w, int _w_offset,
int [] indxp, int _indxp_offset,
int [] indx, int _indx_offset,
int [] coltyp, int _coltyp_offset,
intW info)  {

info.val = 0;
// *
if (n < 0)  {
    info.val = -2;
}              // Close if()
else if (ldq < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (Math.min(1, n)  > cutpnt || n < cutpnt)  {
    info.val = -8;
}              // Close else if()
else if (ldq2 < Math.max(1, n) )  {
    info.val = -12;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED2",-info.val);
Dummy.go_to("Dlaed2",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaed2",999999);
// *
n1 = cutpnt;
n2 = n-n1;
n1p1 = n1+1;
// *
if (rho.val < zero)  {
    Dscal.dscal(n2,mone,z,(n1p1)- 1+ _z_offset,1);
}              // Close if()
// *
// *     Normalize z so that norm(z) = 1.  Since z is the concatenation of
// *     two normalized vectors, norm2(z) = sqrt(2).
// *
t = one/Math.sqrt(two);
{
forloop10:
for (j = 1; j <= n; j++) {
indx[(j)- 1+ _indx_offset] = j;
Dummy.label("Dlaed2",10);
}              //  Close for() loop. 
}
Dscal.dscal(n,t,z,_z_offset,1);
// *
// *     RHO = ABS( norm(z)**2 * RHO )
// *
rho.val = Math.abs(two*rho.val);
// *
{
forloop20:
for (i = 1; i <= cutpnt; i++) {
coltyp[(i)- 1+ _coltyp_offset] = 1;
Dummy.label("Dlaed2",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = cutpnt+1; i <= n; i++) {
coltyp[(i)- 1+ _coltyp_offset] = 2;
Dummy.label("Dlaed2",30);
}              //  Close for() loop. 
}
// *
// *     Sort the eigenvalues into increasing order
// *
{
forloop40:
for (i = cutpnt+1; i <= n; i++) {
indxq[(i)- 1+ _indxq_offset] = indxq[(i)- 1+ _indxq_offset]+cutpnt;
Dummy.label("Dlaed2",40);
}              //  Close for() loop. 
}
// *
// *     re-integrate the deflated parts from the last pass
// *
{
forloop50:
for (i = 1; i <= n; i++) {
dlamda[(i)- 1+ _dlamda_offset] = d[(indxq[(i)- 1+ _indxq_offset])- 1+ _d_offset];
w[(i)- 1+ _w_offset] = z[(indxq[(i)- 1+ _indxq_offset])- 1+ _z_offset];
indxc[(i)- 1+ _indxc_offset] = coltyp[(indxq[(i)- 1+ _indxq_offset])- 1+ _coltyp_offset];
Dummy.label("Dlaed2",50);
}              //  Close for() loop. 
}
Dlamrg.dlamrg(n1,n2,dlamda,_dlamda_offset,1,1,indx,_indx_offset);
{
forloop60:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = dlamda[(indx[(i)- 1+ _indx_offset])- 1+ _dlamda_offset];
z[(i)- 1+ _z_offset] = w[(indx[(i)- 1+ _indx_offset])- 1+ _w_offset];
coltyp[(i)- 1+ _coltyp_offset] = indxc[(indx[(i)- 1+ _indx_offset])- 1+ _indxc_offset];
Dummy.label("Dlaed2",60);
}              //  Close for() loop. 
}
// *
// *     Calculate the allowable deflation tolerance
// *
imax = Idamax.idamax(n,z,_z_offset,1);
jmax = Idamax.idamax(n,d,_d_offset,1);
eps = Dlamch.dlamch("Epsilon");
tol = eight*eps*Math.max(Math.abs(d[(jmax)- 1+ _d_offset]), Math.abs(z[(imax)- 1+ _z_offset])) ;
// *
// *     If the rank-1 modifier is small enough, no more needs to be done
// *     except to reorganize Q so that its columns correspond with the
// *     elements in D.
// *
if (rho.val*Math.abs(z[(imax)- 1+ _z_offset]) <= tol)  {
    k.val = 0;
{
forloop70:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(n,q,(1)- 1+(indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,q2,(1)- 1+(j- 1)*ldq2+ _q2_offset,1);
Dummy.label("Dlaed2",70);
}              //  Close for() loop. 
}
Dlacpy.dlacpy("A",n,n,q2,_q2_offset,ldq2,q,_q_offset,ldq);
Dummy.go_to("Dlaed2",180);
}              // Close if()
// *
// *     If there are multiple eigenvalues then the problem deflates.  Here
// *     the number of equal eigenvalues are found.  As each equal
// *     eigenvalue is found, an elementary reflector is computed to rotate
// *     the corresponding eigensubspace so that the corresponding
// *     components of Z are zero in this new basis.
// *
k.val = 0;
k2 = n+1;
{
forloop80:
for (j = 1; j <= n; j++) {
if (rho.val*Math.abs(z[(j)- 1+ _z_offset]) <= tol)  {
    // *
// *           Deflate due to small z component.
// *
k2 = k2-1;
indxp[(k2)- 1+ _indxp_offset] = j;
coltyp[(j)- 1+ _coltyp_offset] = 4;
if (j == n)  
    Dummy.go_to("Dlaed2",120);
}              // Close if()
else  {
  jlam = j;
Dummy.go_to("Dlaed2",90);
}              //  Close else.
Dummy.label("Dlaed2",80);
}              //  Close for() loop. 
}
label90:
   Dummy.label("Dlaed2",90);
j = j+1;
if (j > n)  
    Dummy.go_to("Dlaed2",110);
if (rho.val*Math.abs(z[(j)- 1+ _z_offset]) <= tol)  {
    // *
// *        Deflate due to small z component.
// *
k2 = k2-1;
indxp[(k2)- 1+ _indxp_offset] = j;
coltyp[(j)- 1+ _coltyp_offset] = 4;
}              // Close if()
else  {
  // *
// *        Check if eigenvalues are close enough to allow deflation.
// *
s = z[(jlam)- 1+ _z_offset];
c = z[(j)- 1+ _z_offset];
// *
// *        Find sqrt(a**2+b**2) without overflow or
// *        destructive underflow.
// *
tau = Dlapy2.dlapy2(c,s);
t = d[(j)- 1+ _d_offset]-d[(jlam)- 1+ _d_offset];
c = c/tau;
s = -s/tau;
if (Math.abs(t*c*s) <= tol)  {
    // *
// *           Deflation is possible.
// *
z[(j)- 1+ _z_offset] = tau;
z[(jlam)- 1+ _z_offset] = zero;
if (coltyp[(j)- 1+ _coltyp_offset] != coltyp[(jlam)- 1+ _coltyp_offset])  
    coltyp[(j)- 1+ _coltyp_offset] = 3;
coltyp[(jlam)- 1+ _coltyp_offset] = 4;
Drot.drot(n,q,(1)- 1+(indxq[(indx[(jlam)- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,q,(1)- 1+(indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,c,s);
t = d[(jlam)- 1+ _d_offset]*Math.pow(c, 2)+d[(j)- 1+ _d_offset]*Math.pow(s, 2);
d[(j)- 1+ _d_offset] = d[(jlam)- 1+ _d_offset]*Math.pow(s, 2)+d[(j)- 1+ _d_offset]*Math.pow(c, 2);
d[(jlam)- 1+ _d_offset] = t;
k2 = k2-1;
i = 1;
label100:
   Dummy.label("Dlaed2",100);
if (k2+i <= n)  {
    if (d[(jlam)- 1+ _d_offset] < d[(indxp[(k2+i)- 1+ _indxp_offset])- 1+ _d_offset])  {
    indxp[(k2+i-1)- 1+ _indxp_offset] = indxp[(k2+i)- 1+ _indxp_offset];
indxp[(k2+i)- 1+ _indxp_offset] = jlam;
i = i+1;
Dummy.go_to("Dlaed2",100);
}              // Close if()
else  {
  indxp[(k2+i-1)- 1+ _indxp_offset] = jlam;
}              //  Close else.
}              // Close if()
else  {
  indxp[(k2+i-1)- 1+ _indxp_offset] = jlam;
}              //  Close else.
jlam = j;
}              // Close if()
else  {
  k.val = k.val+1;
w[(k.val)- 1+ _w_offset] = z[(jlam)- 1+ _z_offset];
dlamda[(k.val)- 1+ _dlamda_offset] = d[(jlam)- 1+ _d_offset];
indxp[(k.val)- 1+ _indxp_offset] = jlam;
jlam = j;
}              //  Close else.
}              //  Close else.
Dummy.go_to("Dlaed2",90);
label110:
   Dummy.label("Dlaed2",110);
// *
// *     Record the last eigenvalue.
// *
k.val = k.val+1;
w[(k.val)- 1+ _w_offset] = z[(jlam)- 1+ _z_offset];
dlamda[(k.val)- 1+ _dlamda_offset] = d[(jlam)- 1+ _d_offset];
indxp[(k.val)- 1+ _indxp_offset] = jlam;
// *
label120:
   Dummy.label("Dlaed2",120);
// *
// *     Count up the total number of the various types of columns, then
// *     form a permutation which positions the four column types into
// *     four uniform groups (although one or more of these groups may be
// *     empty).
// *
{
forloop130:
for (j = 1; j <= 4; j++) {
ctot[(j)- 1] = 0;
Dummy.label("Dlaed2",130);
}              //  Close for() loop. 
}
{
forloop140:
for (j = 1; j <= n; j++) {
ct = coltyp[(j)- 1+ _coltyp_offset];
ctot[(ct)- 1] = ctot[(ct)- 1]+1;
Dummy.label("Dlaed2",140);
}              //  Close for() loop. 
}
// *
// *     PSM(*) = Position in SubMatrix (of types 1 through 4)
// *
psm[(1)- 1] = 1;
psm[(2)- 1] = 1+ctot[(1)- 1];
psm[(3)- 1] = psm[(2)- 1]+ctot[(2)- 1];
psm[(4)- 1] = psm[(3)- 1]+ctot[(3)- 1];
// *
// *     Fill out the INDXC array so that the permutation which it induces
// *     will place all type-1 columns first, all type-2 columns next,
// *     then all type-3's, and finally all type-4's.
// *
{
forloop150:
for (j = 1; j <= n; j++) {
jp = indxp[(j)- 1+ _indxp_offset];
ct = coltyp[(jp)- 1+ _coltyp_offset];
indxc[(psm[(ct)- 1])- 1+ _indxc_offset] = j;
psm[(ct)- 1] = psm[(ct)- 1]+1;
Dummy.label("Dlaed2",150);
}              //  Close for() loop. 
}
// *
// *     Sort the eigenvalues and corresponding eigenvectors into DLAMDA
// *     and Q2 respectively.  The eigenvalues/vectors which were not
// *     deflated go into the first K slots of DLAMDA and Q2 respectively,
// *     while those which were deflated go into the last N - K slots.
// *
{
forloop160:
for (j = 1; j <= n; j++) {
jp = indxp[(j)- 1+ _indxp_offset];
dlamda[(j)- 1+ _dlamda_offset] = d[(jp)- 1+ _d_offset];
Dcopy.dcopy(n,q,(1)- 1+(indxq[(indx[(indxp[(indxc[(j)- 1+ _indxc_offset])- 1+ _indxp_offset])- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,q2,(1)- 1+(j- 1)*ldq2+ _q2_offset,1);
Dummy.label("Dlaed2",160);
}              //  Close for() loop. 
}
// *
// *     The deflated eigenvalues and their corresponding vectors go back
// *     into the last N - K slots of D and Q respectively.
// *
Dcopy.dcopy(n-k.val,dlamda,(k.val+1)- 1+ _dlamda_offset,1,d,(k.val+1)- 1+ _d_offset,1);
Dlacpy.dlacpy("A",n,n-k.val,q2,(1)- 1+(k.val+1- 1)*ldq2+ _q2_offset,ldq2,q,(1)- 1+(k.val+1- 1)*ldq+ _q_offset,ldq);
// *
// *     Copy CTOT into COLTYP for referencing in DLAED3.
// *
{
forloop170:
for (j = 1; j <= 4; j++) {
coltyp[(j)- 1+ _coltyp_offset] = ctot[(j)- 1];
Dummy.label("Dlaed2",170);
}              //  Close for() loop. 
}
// *
label180:
   Dummy.label("Dlaed2",180);
Dummy.go_to("Dlaed2",999999);
// *
// *     End of DLAED2
// *
Dummy.label("Dlaed2",999999);
return;
   }
} // End class.
