/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed3 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED3 finds the roots of the secular equation, as defined by the
// *  values in D, W, and RHO, between KSTART and KSTOP.  It makes the
// *  appropriate calls to DLAED4 and then updates the eigenvectors by
// *  multiplying the matrix of eigenvectors of the pair of eigensystems
// *  being combined by the matrix of eigenvectors of the K-by-K system
// *  which is solved here.
// *
// *  This code makes very mild assumptions about floating point
// *  arithmetic. It will work on machines with a guard digit in
// *  add/subtract, or on those binary machines without guard digits
// *  which subtract like the Cray X-MP, Cray Y-MP, Cray C-90, or Cray-2.
// *  It could conceivably fail on hexadecimal or decimal machines
// *  without guard digits, but we know of none.
// *
// *  Arguments
// *  =========
// *
// *  K       (input) INTEGER
// *          The number of terms in the rational function to be solved by
// *          DLAED4.  K >= 0.
// *
// *  KSTART  (input) INTEGER
// *  KSTOP   (input) INTEGER
// *          The updated eigenvalues Lambda(I), KSTART <= I <= KSTOP
// *          are to be computed.  1 <= KSTART <= KSTOP <= K.
// *
// *  N       (input) INTEGER
// *          The number of rows and columns in the Q matrix.
// *          N >= K (deflation may result in N>K).
// *
// *  D       (output) DOUBLE PRECISION array, dimension (N)
// *          D(I) contains the updated eigenvalues for
// *          KSTART <= I <= KSTOP.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDQ,N)
// *          Initially the first K columns are used as workspace.
// *          On output the columns KSTART to KSTOP contain
// *          the updated eigenvectors.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  RHO     (input) DOUBLE PRECISION
// *          The value of the parameter in the rank one update equation.
// *          RHO >= 0 required.
// *
// *  CUTPNT  (input) INTEGER
// *          The location of the last eigenvalue in the leading submatrix.
// *          min(1,N) <= CUTPNT <= N.
// *
// *  DLAMDA  (input/output) DOUBLE PRECISION array, dimension (K)
// *          The first K elements of this array contain the old roots
// *          of the deflated updating problem.  These are the poles
// *          of the secular equation. May be changed on output by
// *          having lowest order bit set to zero on Cray X-MP, Cray Y-MP,
// *          Cray-2, or Cray C-90, as described above.
// *
// *  Q2      (input) DOUBLE PRECISION array, dimension (LDQ2, N)
// *          The first K columns of this matrix contain the non-deflated
// *          eigenvectors for the split problem.
// *
// *  LDQ2    (input) INTEGER
// *          The leading dimension of the array Q2.  LDQ2 >= max(1,N).
// *
// *  INDXC   (input) INTEGER array, dimension (N)
// *          The permutation used to arrange the columns of the deflated
// *          Q matrix into three groups:  the first group contains
// *          non-zero elements only at and above CUTPNT, the second
// *          contains non-zero elements only below CUTPNT, and the third
// *          is dense.  The rows of the eigenvectors found by DLAED4
// *          must be likewise permuted before the matrix multiply can take
// *          place.
// *
// *  CTOT    (input) INTEGER array, dimension (4)
// *          A count of the total number of the various types of columns
// *          in Q, as described in INDXC.  The fourth column type is any
// *          column which has been deflated.
// *
// *  W       (input/output) DOUBLE PRECISION array, dimension (K)
// *          The first K elements of this array contain the components
// *          of the deflation-adjusted updating vector. Destroyed on
// *          output.
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension (LDS, K)
// *          Will contain the eigenvectors of the repaired matrix which
// *          will be multiplied by the previously accumulated eigenvectors
// *          to update the system.
// *
// *  LDS     (input) INTEGER
// *          The leading dimension of S.  LDS >= max(1,K).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = 1, an eigenvalue did not converge
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int jc= 0;
static int ktemp= 0;
static int parts= 0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed3 (int k,
int kstart,
int kstop,
int n,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
double rho,
int cutpnt,
double [] dlamda, int _dlamda_offset,
double [] q2, int _q2_offset,
int ldq2,
int [] indxc, int _indxc_offset,
int [] ctot, int _ctot_offset,
double [] w, int _w_offset,
double [] s, int _s_offset,
int lds,
intW info)  {

info.val = 0;
// *
if (k < 0)  {
    info.val = -1;
}              // Close if()
else if (kstart < 1 || kstart > Math.max(1, k) )  {
    info.val = -2;
}              // Close else if()
else if (Math.max(1, kstop)  < kstart || kstop > Math.max(1, k) )  {
    info.val = -3;
}              // Close else if()
else if (n < k)  {
    info.val = -4;
}              // Close else if()
else if (ldq < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (ldq2 < Math.max(1, n) )  {
    info.val = -12;
}              // Close else if()
else if (lds < Math.max(1, k) )  {
    info.val = -17;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED3",-info.val);
Dummy.go_to("Dlaed3",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (k == 0)  
    Dummy.go_to("Dlaed3",999999);
// *
// *     Modify values DLAMDA(i) to make sure all DLAMDA(i)-DLAMDA(j) can
// *     be computed with high relative accuracy (barring over/underflow).
// *     This is a problem on machines without a guard digit in
// *     add/subtract (Cray XMP, Cray YMP, Cray C 90 and Cray 2).
// *     The following code replaces DLAMDA(I) by 2*DLAMDA(I)-DLAMDA(I),
// *     which on any of these machines zeros out the bottommost
// *     bit of DLAMDA(I) if it is 1; this makes the subsequent
// *     subtractions DLAMDA(I)-DLAMDA(J) unproblematic when cancellation
// *     occurs. On binary machines with a guard digit (almost all
// *     machines) it does not change DLAMDA(I) at all. On hexadecimal
// *     and decimal machines with a guard digit, it slightly
// *     changes the bottommost bits of DLAMDA(I). It does not account
// *     for hexadecimal or decimal machines without guard digits
// *     (we know of none). We use a subroutine call to compute
// *     2*DLAMBDA(I) to prevent optimizing compilers from eliminating
// *     this code.
// *
{
forloop10:
for (i = 1; i <= n; i++) {
dlamda[(i)- 1+ _dlamda_offset] = Dlamc3.dlamc3(dlamda[(i)- 1+ _dlamda_offset],dlamda[(i)- 1+ _dlamda_offset])-dlamda[(i)- 1+ _dlamda_offset];
Dummy.label("Dlaed3",10);
}              //  Close for() loop. 
}
// *
ktemp = kstop-kstart+1;
{
forloop20:
for (j = kstart; j <= kstop; j++) {
dlaed4_adapter(k,j,dlamda,_dlamda_offset,w,_w_offset,q,(1)- 1+(j- 1)*ldq+ _q_offset,rho,d,(j)- 1+ _d_offset,info);
// *
// *        If the zero finder fails, the computation is terminated.
// *
if (info.val != 0)  
    Dummy.go_to("Dlaed3",130);
Dummy.label("Dlaed3",20);
}              //  Close for() loop. 
}
// *
if (k == 1 || k == 2)  {
    {
forloop40:
for (i = 1; i <= k; i++) {
{
forloop30:
for (j = 1; j <= k; j++) {
jc = indxc[(j)- 1+ _indxc_offset];
s[(j)- 1+(i- 1)*lds+ _s_offset] = q[(jc)- 1+(i- 1)*ldq+ _q_offset];
Dummy.label("Dlaed3",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaed3",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dlaed3",120);
}              // Close if()
// *
// *     Compute updated W.
// *
Dcopy.dcopy(k,w,_w_offset,1,s,_s_offset,1);
// *
// *     Initialize W(I) = Q(I,I)
// *
Dcopy.dcopy(k,q,_q_offset,ldq+1,w,_w_offset,1);
{
forloop70:
for (j = 1; j <= k; j++) {
{
forloop50:
for (i = 1; i <= j-1; i++) {
w[(i)- 1+ _w_offset] = w[(i)- 1+ _w_offset]*(q[(i)- 1+(j- 1)*ldq+ _q_offset]/(dlamda[(i)- 1+ _dlamda_offset]-dlamda[(j)- 1+ _dlamda_offset]));
Dummy.label("Dlaed3",50);
}              //  Close for() loop. 
}
{
forloop60:
for (i = j+1; i <= k; i++) {
w[(i)- 1+ _w_offset] = w[(i)- 1+ _w_offset]*(q[(i)- 1+(j- 1)*ldq+ _q_offset]/(dlamda[(i)- 1+ _dlamda_offset]-dlamda[(j)- 1+ _dlamda_offset]));
Dummy.label("Dlaed3",60);
}              //  Close for() loop. 
}
Dummy.label("Dlaed3",70);
}              //  Close for() loop. 
}
{
forloop80:
for (i = 1; i <= k; i++) {
w[(i)- 1+ _w_offset] = ((s[(i)- 1+(1- 1)*lds+ _s_offset]) >= 0 ? Math.abs(Math.sqrt(-w[(i)- 1+ _w_offset])) : -Math.abs(Math.sqrt(-w[(i)- 1+ _w_offset])));
Dummy.label("Dlaed3",80);
}              //  Close for() loop. 
}
// *
// *     Compute eigenvectors of the modified rank-1 modification.
// *
{
forloop110:
for (j = 1; j <= k; j++) {
{
forloop90:
for (i = 1; i <= k; i++) {
q[(i)- 1+(j- 1)*ldq+ _q_offset] = w[(i)- 1+ _w_offset]/q[(i)- 1+(j- 1)*ldq+ _q_offset];
Dummy.label("Dlaed3",90);
}              //  Close for() loop. 
}
temp = Dnrm2.dnrm2(k,q,(1)- 1+(j- 1)*ldq+ _q_offset,1);
{
forloop100:
for (i = 1; i <= k; i++) {
jc = indxc[(i)- 1+ _indxc_offset];
s[(i)- 1+(j- 1)*lds+ _s_offset] = q[(jc)- 1+(j- 1)*ldq+ _q_offset]/temp;
Dummy.label("Dlaed3",100);
}              //  Close for() loop. 
}
Dummy.label("Dlaed3",110);
}              //  Close for() loop. 
}
// *
// *     Compute the updated eigenvectors.
// *
label120:
   Dummy.label("Dlaed3",120);
// *
parts = 0;
if (ctot[(1)- 1+ _ctot_offset] > 0)  {
    parts = parts+1;
Dgemm.dgemm("N","N",cutpnt,ktemp,ctot[(1)- 1+ _ctot_offset],one,q2,(1)- 1+(1- 1)*ldq2+ _q2_offset,ldq2,s,(1)- 1+(kstart- 1)*lds+ _s_offset,lds,zero,q,(1)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
}              // Close if()
if (ctot[(2)- 1+ _ctot_offset] > 0)  {
    parts = parts+2;
Dgemm.dgemm("N","N",n-cutpnt,ktemp,ctot[(2)- 1+ _ctot_offset],one,q2,(1+cutpnt)- 1+(1+ctot[(1)- 1+ _ctot_offset]- 1)*ldq2+ _q2_offset,ldq2,s,(1+ctot[(1)- 1+ _ctot_offset])- 1+(kstart- 1)*lds+ _s_offset,lds,zero,q,(1+cutpnt)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
}              // Close if()
if (parts == 1)  
    Dlaset.dlaset("A",n-cutpnt,ktemp,zero,zero,q,(1+cutpnt)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
if (parts == 2)  
    Dlaset.dlaset("A",cutpnt,ktemp,zero,zero,q,(1)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
if (ctot[(3)- 1+ _ctot_offset] > 0)  {
    if (parts > 0)  {
    Dgemm.dgemm("N","N",n,ktemp,ctot[(3)- 1+ _ctot_offset],one,q2,(1)- 1+(1+ctot[(1)- 1+ _ctot_offset]+ctot[(2)- 1+ _ctot_offset]- 1)*ldq2+ _q2_offset,ldq2,s,(1+ctot[(1)- 1+ _ctot_offset]+ctot[(2)- 1+ _ctot_offset])- 1+(kstart- 1)*lds+ _s_offset,lds,one,q,(1)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
}              // Close if()
else  {
  Dgemm.dgemm("N","N",n,ktemp,ctot[(3)- 1+ _ctot_offset],one,q2,(1)- 1+(1+ctot[(1)- 1+ _ctot_offset]+ctot[(2)- 1+ _ctot_offset]- 1)*ldq2+ _q2_offset,ldq2,s,(1+ctot[(1)- 1+ _ctot_offset]+ctot[(2)- 1+ _ctot_offset])- 1+(kstart- 1)*lds+ _s_offset,lds,zero,q,(1)- 1+(kstart- 1)*ldq+ _q_offset,ldq);
}              //  Close else.
}              // Close if()
// *
label130:
   Dummy.label("Dlaed3",130);
Dummy.go_to("Dlaed3",999999);
// *
// *     End of DLAED3
// *
Dummy.label("Dlaed3",999999);
return;
   }
// adapter for dlaed4
private static void dlaed4_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double arg5 ,double [] arg6 , int arg6_offset ,intW arg7 )
{
doubleW _f2j_tmp6 = new doubleW(arg6[arg6_offset]);

Dlaed4.dlaed4(arg0,arg1,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5,_f2j_tmp6,arg7);

arg6[arg6_offset] = _f2j_tmp6.val;
}

} // End class.
