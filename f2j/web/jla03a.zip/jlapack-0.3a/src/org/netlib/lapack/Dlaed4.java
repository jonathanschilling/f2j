/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaed4 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  This subroutine computes the I-th updated eigenvalue of a symmetric
// *  rank-one modification to a diagonal matrix whose elements are
// *  given in the array d, and that
// *
// *             D(i) < D(j)  for  i < j
// *
// *  and that RHO > 0.  This is arranged by the calling routine, and is
// *  no loss in generality.  The rank-one modified system is thus
// *
// *             diag( D )  +  RHO *  Z * Z_transpose.
// *
// *  where we assume the Euclidean norm of Z is 1.
// *
// *  The method consists of approximating the rational functions in the
// *  secular equation by simpler interpolating rational functions.
// *
// *  Arguments
// *  =========
// *
// *  N      (input) INTEGER
// *         The length of all arrays.
// *
// *  I      (input) INTEGER
// *         The index of the eigenvalue to be computed.  1 <= I <= N.
// *
// *  D      (input) DOUBLE PRECISION array, dimension (N)
// *         The original eigenvalues.  It is assumed that they are in
// *         order, D(I) < D(J)  for I < J.
// *
// *  Z      (input) DOUBLE PRECISION array, dimension (N)
// *         The components of the updating vector.
// *
// *  DELTA  (output) DOUBLE PRECISION array, dimension (N)
// *         If N .ne. 1, DELTA contains (D(j) - lambda_I) in its  j-th
// *         component.  If N = 1, then DELTA(1) = 1.  The vector DELTA
// *         contains the information necessary to construct the
// *         eigenvectors.
// *
// *  RHO    (input) DOUBLE PRECISION
// *         The scalar in the symmetric updating formula.
// *
// *  DLAM   (output) DOUBLE PRECISION
// *         The computed lambda_I, the I-th updated eigenvalue.
// *
// *  INFO   (output) INTEGER
// *         = 0:  successful exit
// *         > 0:  if INFO = 1, the updating process failed.
// *
// *  Internal Parameters
// *  ===================
// *
// *  Logical variable ORGATI (origin-at-i?) is used for distinguishing
// *  whether D(i) or D(i+1) is treated as the origin.
// *
// *            ORGATI = .true.    origin at i
// *            ORGATI = .false.   origin at i+1
// *
// *   Logical variable SWTCH3 (switch-for-3-poles?) is for noting
// *   if we are working with THREE poles!
// *
// *   MAXIT is the maximum number of iterations allowed for each
// *   eigenvalue.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int maxit= 20;
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double three= 3.0e0;
static double four= 4.0e0;
static double eight= 8.0e0;
static double ten= 10.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean orgati= false;
static boolean swtch= false;
static boolean swtch3= false;
static int ii= 0;
static int iim1= 0;
static int iip1= 0;
static int ip1= 0;
static int iter= 0;
static int j= 0;
static int niter= 0;
static double a= 0.0;
static double b= 0.0;
static double c= 0.0;
static double del= 0.0;
static double dphi= 0.0;
static double dpsi= 0.0;
static double dw= 0.0;
static double eps= 0.0;
static double erretm= 0.0;
static doubleW eta= new doubleW(0.0);
static double phi= 0.0;
static double prew= 0.0;
static double psi= 0.0;
static double rhoinv= 0.0;
static double tau= 0.0;
static double temp= 0.0;
static double temp1= 0.0;
static double w= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] zz= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Since this routine is called in an inner loop, we do no argument
// *     checking.
// *
// *     Quick return for N=1 and 2.
// *

public static void dlaed4 (int n,
int i,
double [] d, int _d_offset,
double [] z, int _z_offset,
double [] delta, int _delta_offset,
double rho,
doubleW dlam,
intW info)  {

info.val = 0;
if (n == 1)  {
    // *
// *         Presumably, I=1 upon entry
// *
dlam.val = d[(1)- 1+ _d_offset]+rho*z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset];
delta[(1)- 1+ _delta_offset] = one;
Dummy.go_to("Dlaed4",999999);
}              // Close if()
if (n == 2)  {
    Dlaed5.dlaed5(i,d,_d_offset,z,_z_offset,delta,_delta_offset,rho,dlam);
Dummy.go_to("Dlaed4",999999);
}              // Close if()
// *
// *     Compute machine epsilon
// *
eps = Dlamch.dlamch("Epsilon");
rhoinv = one/rho;
// *
// *     The case I = N
// *
if (i == n)  {
    // *
// *        Initialize some basic variables
// *
ii = n-1;
niter = 1;
// *
// *        Calculate initial guess
// *
temp = rho/two;
// *
// *        If ||Z||_2 is not one, then TEMP should be set to
// *        RHO * ||Z||_2^2 / TWO
// *
{
forloop10:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = (d[(j)- 1+ _d_offset]-d[(i)- 1+ _d_offset])-temp;
Dummy.label("Dlaed4",10);
}              //  Close for() loop. 
}
// *
psi = zero;
{
forloop20:
for (j = 1; j <= n-2; j++) {
psi = psi+z[(j)- 1+ _z_offset]*z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
Dummy.label("Dlaed4",20);
}              //  Close for() loop. 
}
// *
c = rhoinv+psi;
w = c+z[(ii)- 1+ _z_offset]*z[(ii)- 1+ _z_offset]/delta[(ii)- 1+ _delta_offset]+z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset]/delta[(n)- 1+ _delta_offset];
// *
if (w <= zero)  {
    temp = z[(n-1)- 1+ _z_offset]*z[(n-1)- 1+ _z_offset]/(d[(n)- 1+ _d_offset]-d[(n-1)- 1+ _d_offset]+rho)+z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset]/rho;
if (c <= temp)  {
    tau = rho;
}              // Close if()
else  {
  del = d[(n)- 1+ _d_offset]-d[(n-1)- 1+ _d_offset];
a = -c*del+z[(n-1)- 1+ _z_offset]*z[(n-1)- 1+ _z_offset]+z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset];
b = z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset]*del;
if (a < zero)  {
    tau = two*b/(Math.sqrt(a*a+four*b*c)-a);
}              // Close if()
else  {
  tau = (a+Math.sqrt(a*a+four*b*c))/(two*c);
}              //  Close else.
}              //  Close else.
// *
// *           It can be proved that
// *               D(N)+RHO/2 <= LAMBDA(N) < D(N)+TAU <= D(N)+RHO
// *
}              // Close if()
else  {
  del = d[(n)- 1+ _d_offset]-d[(n-1)- 1+ _d_offset];
a = -c*del+z[(n-1)- 1+ _z_offset]*z[(n-1)- 1+ _z_offset]+z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset];
b = z[(n)- 1+ _z_offset]*z[(n)- 1+ _z_offset]*del;
if (a < zero)  {
    tau = two*b/(Math.sqrt(a*a+four*b*c)-a);
}              // Close if()
else  {
  tau = (a+Math.sqrt(a*a+four*b*c))/(two*c);
}              //  Close else.
// *
// *           It can be proved that
// *               D(N) < D(N)+TAU < LAMBDA(N) < D(N)+RHO/2
// *
}              //  Close else.
// *
{
forloop30:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = (d[(j)- 1+ _d_offset]-d[(i)- 1+ _d_offset])-tau;
Dummy.label("Dlaed4",30);
}              //  Close for() loop. 
}
// *
// *        Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop40:
for (j = 1; j <= ii; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",40);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *        Evaluate PHI and the derivative DPHI
// *
temp = z[(n)- 1+ _z_offset]/delta[(n)- 1+ _delta_offset];
phi = z[(n)- 1+ _z_offset]*temp;
dphi = temp*temp;
erretm = eight*(-phi-psi)+erretm-phi+rhoinv+Math.abs(tau)*(dpsi+dphi);
// *
w = rhoinv+phi+psi;
// *
// *        Test for convergence
// *
if (Math.abs(w) <= eps*erretm)  {
    dlam.val = d[(i)- 1+ _d_offset]+tau;
Dummy.go_to("Dlaed4",250);
}              // Close if()
// *
// *        Calculate the new step
// *
niter = niter+1;
c = w-delta[(n-1)- 1+ _delta_offset]*dpsi-delta[(n)- 1+ _delta_offset]*dphi;
a = (delta[(n-1)- 1+ _delta_offset]+delta[(n)- 1+ _delta_offset])*w-delta[(n-1)- 1+ _delta_offset]*delta[(n)- 1+ _delta_offset]*(dpsi+dphi);
b = delta[(n-1)- 1+ _delta_offset]*delta[(n)- 1+ _delta_offset]*w;
if (c < zero)  
    c = Math.abs(c);
if (c == zero)  {
    // *          ETA = B/A
eta.val = rho-tau;
}              // Close if()
else if (a >= zero)  {
    eta.val = (a+Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close else if()
else  {
  eta.val = two*b/(a-Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
// *
// *        Note, eta should be positive if w is negative, and
// *        eta should be negative otherwise. However,
// *        if for some reason caused by roundoff, eta*w > 0,
// *        we simply use one Newton step instead. This way
// *        will guarantee eta*w < 0.
// *
if (w*eta.val > zero)  
    eta.val = -w/(dpsi+dphi);
temp = tau+eta.val;
if (temp > rho)  
    eta.val = rho-tau;
{
forloop50:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = delta[(j)- 1+ _delta_offset]-eta.val;
Dummy.label("Dlaed4",50);
}              //  Close for() loop. 
}
// *
tau = tau+eta.val;
// *
// *        Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop60:
for (j = 1; j <= ii; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",60);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *        Evaluate PHI and the derivative DPHI
// *
temp = z[(n)- 1+ _z_offset]/delta[(n)- 1+ _delta_offset];
phi = z[(n)- 1+ _z_offset]*temp;
dphi = temp*temp;
erretm = eight*(-phi-psi)+erretm-phi+rhoinv+Math.abs(tau)*(dpsi+dphi);
// *
w = rhoinv+phi+psi;
// *
// *        Main loop to update the values of the array   DELTA
// *
iter = niter+1;
// *
{
forloop90:
for (niter = iter; niter <= maxit; niter++) {
// *
// *           Test for convergence
// *
if (Math.abs(w) <= eps*erretm)  {
    dlam.val = d[(i)- 1+ _d_offset]+tau;
Dummy.go_to("Dlaed4",250);
}              // Close if()
// *
// *           Calculate the new step
// *
c = w-delta[(n-1)- 1+ _delta_offset]*dpsi-delta[(n)- 1+ _delta_offset]*dphi;
a = (delta[(n-1)- 1+ _delta_offset]+delta[(n)- 1+ _delta_offset])*w-delta[(n-1)- 1+ _delta_offset]*delta[(n)- 1+ _delta_offset]*(dpsi+dphi);
b = delta[(n-1)- 1+ _delta_offset]*delta[(n)- 1+ _delta_offset]*w;
if (a >= zero)  {
    eta.val = (a+Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close if()
else  {
  eta.val = two*b/(a-Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
// *
// *           Note, eta should be positive if w is negative, and
// *           eta should be negative otherwise. However,
// *           if for some reason caused by roundoff, eta*w > 0,
// *           we simply use one Newton step instead. This way
// *           will guarantee eta*w < 0.
// *
if (w*eta.val > zero)  
    eta.val = -w/(dpsi+dphi);
temp = tau+eta.val;
if (temp <= zero)  
    eta.val = eta.val/two;
{
forloop70:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = delta[(j)- 1+ _delta_offset]-eta.val;
Dummy.label("Dlaed4",70);
}              //  Close for() loop. 
}
// *
tau = tau+eta.val;
// *
// *           Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop80:
for (j = 1; j <= ii; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",80);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *           Evaluate PHI and the derivative DPHI
// *
temp = z[(n)- 1+ _z_offset]/delta[(n)- 1+ _delta_offset];
phi = z[(n)- 1+ _z_offset]*temp;
dphi = temp*temp;
erretm = eight*(-phi-psi)+erretm-phi+rhoinv+Math.abs(tau)*(dpsi+dphi);
// *
w = rhoinv+phi+psi;
Dummy.label("Dlaed4",90);
}              //  Close for() loop. 
}
// *
// *        Return with INFO = 1, NITER = MAXIT and not converged
// *
info.val = 1;
dlam.val = d[(i)- 1+ _d_offset]+tau;
Dummy.go_to("Dlaed4",250);
// *
// *        End for the case I = N
// *
}              // Close if()
else  {
  // *
// *        The case for I < N
// *
niter = 1;
ip1 = i+1;
// *
// *        Calculate initial guess
// *
temp = (d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset])/two;
{
forloop100:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = (d[(j)- 1+ _d_offset]-d[(i)- 1+ _d_offset])-temp;
Dummy.label("Dlaed4",100);
}              //  Close for() loop. 
}
// *
psi = zero;
{
forloop110:
for (j = 1; j <= i-1; j++) {
psi = psi+z[(j)- 1+ _z_offset]*z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
Dummy.label("Dlaed4",110);
}              //  Close for() loop. 
}
// *
phi = zero;
{
int _j_inc = -1;
forloop120:
for (j = n; j >= i+2; j += _j_inc) {
phi = phi+z[(j)- 1+ _z_offset]*z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
Dummy.label("Dlaed4",120);
}              //  Close for() loop. 
}
c = rhoinv+psi+phi;
w = c+z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]/delta[(i)- 1+ _delta_offset]+z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset]/delta[(ip1)- 1+ _delta_offset];
// *
if (w > zero)  {
    // *
// *           d(i)< the ith eigenvalue < (d(i)+d(i+1))/2
// *
// *           We choose d(i) as origin.
// *
orgati = true;
del = d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset];
a = c*del+z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]+z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset];
b = z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]*del;
if (a > zero)  {
    tau = two*b/(a+Math.sqrt(Math.abs(a*a-four*b*c)));
}              // Close if()
else  {
  tau = (a-Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              //  Close else.
}              // Close if()
else  {
  // *
// *           (d(i)+d(i+1))/2 <= the ith eigenvalue < d(i+1)
// *
// *           We choose d(i+1) as origin.
// *
orgati = false;
del = d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset];
a = c*del-z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]-z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset];
b = z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset]*del;
if (a < zero)  {
    tau = two*b/(a-Math.sqrt(Math.abs(a*a+four*b*c)));
}              // Close if()
else  {
  tau = -(a+Math.sqrt(Math.abs(a*a+four*b*c)))/(two*c);
}              //  Close else.
}              //  Close else.
// *
if (orgati)  {
    {
forloop130:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = (d[(j)- 1+ _d_offset]-d[(i)- 1+ _d_offset])-tau;
Dummy.label("Dlaed4",130);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop140:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = (d[(j)- 1+ _d_offset]-d[(ip1)- 1+ _d_offset])-tau;
Dummy.label("Dlaed4",140);
}              //  Close for() loop. 
}
}              //  Close else.
if (orgati)  {
    ii = i;
}              // Close if()
else  {
  ii = i+1;
}              //  Close else.
iim1 = ii-1;
iip1 = ii+1;
// *
// *        Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop150:
for (j = 1; j <= iim1; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",150);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *        Evaluate PHI and the derivative DPHI
// *
dphi = zero;
phi = zero;
{
int _j_inc = -1;
forloop160:
for (j = n; j >= iip1; j += _j_inc) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
phi = phi+z[(j)- 1+ _z_offset]*temp;
dphi = dphi+temp*temp;
erretm = erretm+phi;
Dummy.label("Dlaed4",160);
}              //  Close for() loop. 
}
// *
w = rhoinv+phi+psi;
// *
// *        W is the value of the secular function with
// *        its ii-th element removed.
// *
swtch3 = false;
if (orgati)  {
    if (w < zero)  
    swtch3 = true;
}              // Close if()
else  {
  if (w > zero)  
    swtch3 = true;
}              //  Close else.
if (ii == 1 || ii == n)  
    swtch3 = false;
// *
temp = z[(ii)- 1+ _z_offset]/delta[(ii)- 1+ _delta_offset];
dw = dpsi+dphi+temp*temp;
temp = z[(ii)- 1+ _z_offset]*temp;
w = w+temp;
erretm = eight*(phi-psi)+erretm+two*rhoinv+three*Math.abs(temp)+Math.abs(tau)*dw;
// *
// *        Test for convergence
// *
if (Math.abs(w) <= eps*erretm)  {
    if (orgati)  {
    dlam.val = d[(i)- 1+ _d_offset]+tau;
}              // Close if()
else  {
  dlam.val = d[(ip1)- 1+ _d_offset]+tau;
}              //  Close else.
Dummy.go_to("Dlaed4",250);
}              // Close if()
// *
// *        Calculate the new step
// *
niter = niter+1;
if (!swtch3)  {
    if (orgati)  {
    c = w-delta[(ip1)- 1+ _delta_offset]*dw-(d[(i)- 1+ _d_offset]-d[(ip1)- 1+ _d_offset])*Math.pow((z[(i)- 1+ _z_offset]/delta[(i)- 1+ _delta_offset]), 2);
}              // Close if()
else  {
  c = w-delta[(i)- 1+ _delta_offset]*dw-(d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset])*Math.pow((z[(ip1)- 1+ _z_offset]/delta[(ip1)- 1+ _delta_offset]), 2);
}              //  Close else.
a = (delta[(i)- 1+ _delta_offset]+delta[(ip1)- 1+ _delta_offset])*w-delta[(i)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*dw;
b = delta[(i)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*w;
if (c == zero)  {
    if (a == zero)  {
    if (orgati)  {
    a = z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]+delta[(ip1)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*(dpsi+dphi);
}              // Close if()
else  {
  a = z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset]+delta[(i)- 1+ _delta_offset]*delta[(i)- 1+ _delta_offset]*(dpsi+dphi);
}              //  Close else.
}              // Close if()
eta.val = b/a;
}              // Close if()
else if (a <= zero)  {
    eta.val = (a-Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close else if()
else  {
  eta.val = two*b/(a+Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
}              // Close if()
else  {
  // *
// *           Interpolation using THREE most relevant poles
// *
temp = rhoinv+psi+phi;
if (orgati)  {
    temp1 = z[(iim1)- 1+ _z_offset]/delta[(iim1)- 1+ _delta_offset];
temp1 = temp1*temp1;
c = temp-delta[(iip1)- 1+ _delta_offset]*(dpsi+dphi)-(d[(iim1)- 1+ _d_offset]-d[(iip1)- 1+ _d_offset])*temp1;
zz[(1)- 1] = z[(iim1)- 1+ _z_offset]*z[(iim1)- 1+ _z_offset];
zz[(3)- 1] = delta[(iip1)- 1+ _delta_offset]*delta[(iip1)- 1+ _delta_offset]*((dpsi-temp1)+dphi);
}              // Close if()
else  {
  temp1 = z[(iip1)- 1+ _z_offset]/delta[(iip1)- 1+ _delta_offset];
temp1 = temp1*temp1;
c = temp-delta[(iim1)- 1+ _delta_offset]*(dpsi+dphi)-(d[(iip1)- 1+ _d_offset]-d[(iim1)- 1+ _d_offset])*temp1;
zz[(1)- 1] = delta[(iim1)- 1+ _delta_offset]*delta[(iim1)- 1+ _delta_offset]*(dpsi+(dphi-temp1));
zz[(3)- 1] = z[(iip1)- 1+ _z_offset]*z[(iip1)- 1+ _z_offset];
}              //  Close else.
zz[(2)- 1] = z[(ii)- 1+ _z_offset]*z[(ii)- 1+ _z_offset];
Dlaed6.dlaed6(niter,orgati,c,delta,(iim1)- 1+ _delta_offset,zz,0,w,eta,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed4",250);
}              //  Close else.
// *
// *        Note, eta should be positive if w is negative, and
// *        eta should be negative otherwise. However,
// *        if for some reason caused by roundoff, eta*w > 0,
// *        we simply use one Newton step instead. This way
// *        will guarantee eta*w < 0.
// *
if (w*eta.val >= zero)  
    eta.val = -w/dw;
temp = tau+eta.val;
del = (d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset])/two;
if (orgati)  {
    if (temp >= del)  
    eta.val = del-tau;
if (temp <= zero)  
    eta.val = eta.val/two;
}              // Close if()
else  {
  if (temp <= -del)  
    eta.val = -del-tau;
if (temp >= zero)  
    eta.val = eta.val/two;
}              //  Close else.
// *
prew = w;
// *
label170:
   Dummy.label("Dlaed4",170);
{
forloop180:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = delta[(j)- 1+ _delta_offset]-eta.val;
Dummy.label("Dlaed4",180);
}              //  Close for() loop. 
}
// *
// *        Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop190:
for (j = 1; j <= iim1; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",190);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *        Evaluate PHI and the derivative DPHI
// *
dphi = zero;
phi = zero;
{
int _j_inc = -1;
forloop200:
for (j = n; j >= iip1; j += _j_inc) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
phi = phi+z[(j)- 1+ _z_offset]*temp;
dphi = dphi+temp*temp;
erretm = erretm+phi;
Dummy.label("Dlaed4",200);
}              //  Close for() loop. 
}
// *
temp = z[(ii)- 1+ _z_offset]/delta[(ii)- 1+ _delta_offset];
dw = dpsi+dphi+temp*temp;
temp = z[(ii)- 1+ _z_offset]*temp;
w = rhoinv+phi+psi+temp;
erretm = eight*(phi-psi)+erretm+two*rhoinv+three*Math.abs(temp)+Math.abs(tau+eta.val)*dw;
// *
swtch = false;
if (orgati)  {
    if (-w > Math.abs(prew)/ten)  
    swtch = true;
}              // Close if()
else  {
  if (w > Math.abs(prew)/ten)  
    swtch = true;
}              //  Close else.
// *
tau = tau+eta.val;
// *
// *        Main loop to update the values of the array   DELTA
// *
iter = niter+1;
// *
{
forloop240:
for (niter = iter; niter <= maxit; niter++) {
// *
// *           Test for convergence
// *
if (Math.abs(w) <= eps*erretm)  {
    if (orgati)  {
    dlam.val = d[(i)- 1+ _d_offset]+tau;
}              // Close if()
else  {
  dlam.val = d[(ip1)- 1+ _d_offset]+tau;
}              //  Close else.
Dummy.go_to("Dlaed4",250);
}              // Close if()
// *
// *           Calculate the new step
// *
if (!swtch3)  {
    if (!swtch)  {
    if (orgati)  {
    c = w-delta[(ip1)- 1+ _delta_offset]*dw-(d[(i)- 1+ _d_offset]-d[(ip1)- 1+ _d_offset])*Math.pow((z[(i)- 1+ _z_offset]/delta[(i)- 1+ _delta_offset]), 2);
}              // Close if()
else  {
  c = w-delta[(i)- 1+ _delta_offset]*dw-(d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset])*Math.pow((z[(ip1)- 1+ _z_offset]/delta[(ip1)- 1+ _delta_offset]), 2);
}              //  Close else.
}              // Close if()
else  {
  temp = z[(ii)- 1+ _z_offset]/delta[(ii)- 1+ _delta_offset];
if (orgati)  {
    dpsi = dpsi+temp*temp;
}              // Close if()
else  {
  dphi = dphi+temp*temp;
}              //  Close else.
c = w-delta[(i)- 1+ _delta_offset]*dpsi-delta[(ip1)- 1+ _delta_offset]*dphi;
}              //  Close else.
a = (delta[(i)- 1+ _delta_offset]+delta[(ip1)- 1+ _delta_offset])*w-delta[(i)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*dw;
b = delta[(i)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*w;
if (c == zero)  {
    if (a == zero)  {
    if (!swtch)  {
    if (orgati)  {
    a = z[(i)- 1+ _z_offset]*z[(i)- 1+ _z_offset]+delta[(ip1)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*(dpsi+dphi);
}              // Close if()
else  {
  a = z[(ip1)- 1+ _z_offset]*z[(ip1)- 1+ _z_offset]+delta[(i)- 1+ _delta_offset]*delta[(i)- 1+ _delta_offset]*(dpsi+dphi);
}              //  Close else.
}              // Close if()
else  {
  a = delta[(i)- 1+ _delta_offset]*delta[(i)- 1+ _delta_offset]*dpsi+delta[(ip1)- 1+ _delta_offset]*delta[(ip1)- 1+ _delta_offset]*dphi;
}              //  Close else.
}              // Close if()
eta.val = b/a;
}              // Close if()
else if (a <= zero)  {
    eta.val = (a-Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close else if()
else  {
  eta.val = two*b/(a+Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
}              // Close if()
else  {
  // *
// *              Interpolation using THREE most relevant poles
// *
temp = rhoinv+psi+phi;
if (swtch)  {
    c = temp-delta[(iim1)- 1+ _delta_offset]*dpsi-delta[(iip1)- 1+ _delta_offset]*dphi;
zz[(1)- 1] = delta[(iim1)- 1+ _delta_offset]*delta[(iim1)- 1+ _delta_offset]*dpsi;
zz[(3)- 1] = delta[(iip1)- 1+ _delta_offset]*delta[(iip1)- 1+ _delta_offset]*dphi;
}              // Close if()
else  {
  if (orgati)  {
    temp1 = z[(iim1)- 1+ _z_offset]/delta[(iim1)- 1+ _delta_offset];
temp1 = temp1*temp1;
c = temp-delta[(iip1)- 1+ _delta_offset]*(dpsi+dphi)-(d[(iim1)- 1+ _d_offset]-d[(iip1)- 1+ _d_offset])*temp1;
zz[(1)- 1] = z[(iim1)- 1+ _z_offset]*z[(iim1)- 1+ _z_offset];
zz[(3)- 1] = delta[(iip1)- 1+ _delta_offset]*delta[(iip1)- 1+ _delta_offset]*((dpsi-temp1)+dphi);
}              // Close if()
else  {
  temp1 = z[(iip1)- 1+ _z_offset]/delta[(iip1)- 1+ _delta_offset];
temp1 = temp1*temp1;
c = temp-delta[(iim1)- 1+ _delta_offset]*(dpsi+dphi)-(d[(iip1)- 1+ _d_offset]-d[(iim1)- 1+ _d_offset])*temp1;
zz[(1)- 1] = delta[(iim1)- 1+ _delta_offset]*delta[(iim1)- 1+ _delta_offset]*(dpsi+(dphi-temp1));
zz[(3)- 1] = z[(iip1)- 1+ _z_offset]*z[(iip1)- 1+ _z_offset];
}              //  Close else.
}              //  Close else.
Dlaed6.dlaed6(niter,orgati,c,delta,(iim1)- 1+ _delta_offset,zz,0,w,eta,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed4",250);
}              //  Close else.
// *
// *           Note, eta should be positive if w is negative, and
// *           eta should be negative otherwise. However,
// *           if for some reason caused by roundoff, eta*w > 0,
// *           we simply use one Newton step instead. This way
// *           will guarantee eta*w < 0.
// *
if (w*eta.val >= zero)  
    eta.val = -w/dw;
temp = tau+eta.val;
del = (d[(ip1)- 1+ _d_offset]-d[(i)- 1+ _d_offset])/two;
if (orgati)  {
    if (temp >= del)  
    eta.val = del-tau;
if (temp <= zero)  
    eta.val = eta.val/two;
}              // Close if()
else  {
  if (temp <= -del)  
    eta.val = -del-tau;
if (temp >= zero)  
    eta.val = eta.val/two;
}              //  Close else.
// *
{
forloop210:
for (j = 1; j <= n; j++) {
delta[(j)- 1+ _delta_offset] = delta[(j)- 1+ _delta_offset]-eta.val;
Dummy.label("Dlaed4",210);
}              //  Close for() loop. 
}
// *
tau = tau+eta.val;
prew = w;
// *
// *           Evaluate PSI and the derivative DPSI
// *
dpsi = zero;
psi = zero;
erretm = zero;
{
forloop220:
for (j = 1; j <= iim1; j++) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
psi = psi+z[(j)- 1+ _z_offset]*temp;
dpsi = dpsi+temp*temp;
erretm = erretm+psi;
Dummy.label("Dlaed4",220);
}              //  Close for() loop. 
}
erretm = Math.abs(erretm);
// *
// *           Evaluate PHI and the derivative DPHI
// *
dphi = zero;
phi = zero;
{
int _j_inc = -1;
forloop230:
for (j = n; j >= iip1; j += _j_inc) {
temp = z[(j)- 1+ _z_offset]/delta[(j)- 1+ _delta_offset];
phi = phi+z[(j)- 1+ _z_offset]*temp;
dphi = dphi+temp*temp;
erretm = erretm+phi;
Dummy.label("Dlaed4",230);
}              //  Close for() loop. 
}
// *
temp = z[(ii)- 1+ _z_offset]/delta[(ii)- 1+ _delta_offset];
dw = dpsi+dphi+temp*temp;
temp = z[(ii)- 1+ _z_offset]*temp;
w = rhoinv+phi+psi+temp;
erretm = eight*(phi-psi)+erretm+two*rhoinv+three*Math.abs(temp)+Math.abs(tau)*dw;
if (w*prew > zero && Math.abs(w) > Math.abs(prew)/ten)  
    swtch = !swtch;
// *
Dummy.label("Dlaed4",240);
}              //  Close for() loop. 
}
// *
// *        Return with INFO = 1, NITER = MAXIT and not converged
// *
info.val = 1;
if (orgati)  {
    dlam.val = d[(i)- 1+ _d_offset]+tau;
}              // Close if()
else  {
  dlam.val = d[(ip1)- 1+ _d_offset]+tau;
}              //  Close else.
// *
}              //  Close else.
// *
label250:
   Dummy.label("Dlaed4",250);
Dummy.go_to("Dlaed4",999999);
// *
// *     End of DLAED4
// *
Dummy.label("Dlaed4",999999);
return;
   }
} // End class.
