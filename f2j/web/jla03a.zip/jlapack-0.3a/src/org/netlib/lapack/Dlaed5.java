/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaed5 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  This subroutine computes the I-th eigenvalue of a symmetric rank-one
// *  modification of a 2-by-2 diagonal matrix
// *
// *             diag( D )  +  RHO *  Z * transpose(Z) .
// *
// *  The diagonal elements in the array D are assumed to satisfy
// *
// *             D(i) < D(j)  for  i < j .
// *
// *  We also assume RHO > 0 and that the Euclidean norm of the vector
// *  Z is one.
// *
// *  Arguments
// *  =========
// *
// *  I      (input) INTEGER
// *         The index of the eigenvalue to be computed.  I = 1 or I = 2.
// *
// *  D      (input) DOUBLE PRECISION array, dimension (2)
// *         The original eigenvalues.  We assume D(1) < D(2).
// *
// *  Z      (input) DOUBLE PRECISION array, dimension (2)
// *         The components of the updating vector.
// *
// *  DELTA  (output) DOUBLE PRECISION array, dimension (2)
// *         The vector DELTA contains the information necessary
// *         to construct the eigenvectors.
// *
// *  RHO    (input) DOUBLE PRECISION
// *         The scalar in the symmetric updating formula.
// *
// *  DLAM   (output) DOUBLE PRECISION
// *         The computed lambda_I, the I-th updated eigenvalue.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double four= 4.0e0;
// *     ..
// *     .. Local Scalars ..
static double b= 0.0;
static double c= 0.0;
static double del= 0.0;
static double tau= 0.0;
static double temp= 0.0;
static double w= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaed5 (int i,
double [] d, int _d_offset,
double [] z, int _z_offset,
double [] delta, int _delta_offset,
double rho,
doubleW dlam)  {

del = d[(2)- 1+ _d_offset]-d[(1)- 1+ _d_offset];
if (i == 1)  {
    w = one+two*rho*(z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]-z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset])/del;
if (w > zero)  {
    b = del+rho*(z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset]+z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]);
c = rho*z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset]*del;
// *
// *           B > ZERO, always
// *
tau = two*c/(b+Math.sqrt(Math.abs(b*b-four*c)));
dlam.val = d[(1)- 1+ _d_offset]+tau;
delta[(1)- 1+ _delta_offset] = -z[(1)- 1+ _z_offset]/tau;
delta[(2)- 1+ _delta_offset] = z[(2)- 1+ _z_offset]/(del-tau);
}              // Close if()
else  {
  b = -del+rho*(z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset]+z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]);
c = rho*z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]*del;
if (b > zero)  {
    tau = -two*c/(b+Math.sqrt(b*b+four*c));
}              // Close if()
else  {
  tau = (b-Math.sqrt(b*b+four*c))/two;
}              //  Close else.
dlam.val = d[(2)- 1+ _d_offset]+tau;
delta[(1)- 1+ _delta_offset] = -z[(1)- 1+ _z_offset]/(del+tau);
delta[(2)- 1+ _delta_offset] = -z[(2)- 1+ _z_offset]/tau;
}              //  Close else.
temp = Math.sqrt(delta[(1)- 1+ _delta_offset]*delta[(1)- 1+ _delta_offset]+delta[(2)- 1+ _delta_offset]*delta[(2)- 1+ _delta_offset]);
delta[(1)- 1+ _delta_offset] = delta[(1)- 1+ _delta_offset]/temp;
delta[(2)- 1+ _delta_offset] = delta[(2)- 1+ _delta_offset]/temp;
}              // Close if()
else  {
  // *
// *     Now I=2
// *
b = -del+rho*(z[(1)- 1+ _z_offset]*z[(1)- 1+ _z_offset]+z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]);
c = rho*z[(2)- 1+ _z_offset]*z[(2)- 1+ _z_offset]*del;
if (b > zero)  {
    tau = (b+Math.sqrt(b*b+four*c))/two;
}              // Close if()
else  {
  tau = two*c/(-b+Math.sqrt(b*b+four*c));
}              //  Close else.
dlam.val = d[(2)- 1+ _d_offset]+tau;
delta[(1)- 1+ _delta_offset] = -z[(1)- 1+ _z_offset]/(del+tau);
delta[(2)- 1+ _delta_offset] = -z[(2)- 1+ _z_offset]/tau;
temp = Math.sqrt(delta[(1)- 1+ _delta_offset]*delta[(1)- 1+ _delta_offset]+delta[(2)- 1+ _delta_offset]*delta[(2)- 1+ _delta_offset]);
delta[(1)- 1+ _delta_offset] = delta[(1)- 1+ _delta_offset]/temp;
delta[(2)- 1+ _delta_offset] = delta[(2)- 1+ _delta_offset]/temp;
}              //  Close else.
Dummy.go_to("Dlaed5",999999);
// *
// *     End OF DLAED5
// *
Dummy.label("Dlaed5",999999);
return;
   }
} // End class.
