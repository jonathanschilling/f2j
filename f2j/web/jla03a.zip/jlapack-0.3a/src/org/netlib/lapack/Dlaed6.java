/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaed6 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED6 computes the positive or negative root (closest to the origin)
// *  of
// *                   z(1)        z(2)        z(3)
// *  f(x) =   rho + --------- + ---------- + ---------
// *                  d(1)-x      d(2)-x      d(3)-x
// *
// *  It is assumed that
// *
// *        if ORGATI = .true. the root is between d(2) and d(3);
// *        otherwise it is between d(1) and d(2)
// *
// *  This routine will be called by DLAED4 when necessary. In most cases,
// *  the root sought is the smallest in magnitude, though it might not be
// *  in some extremely rare situations.
// *
// *  Arguments
// *  =========
// *
// *  KNITER       (input) INTEGER
// *               Refer to DLAED4 for its significance.
// *
// *  ORGATI       (input) LOGICAL
// *               If ORGATI is true, the needed root is between d(2) and
// *               d(3); otherwise it is between d(1) and d(2).  See
// *               DLAED4 for further details.
// *
// *  RHO          (input) DOUBLE PRECISION
// *               Refer to the equation f(x) above.
// *
// *  D            (input) DOUBLE PRECISION array, dimension (3)
// *               D satisfies d(1) < d(2) < d(3).
// *
// *  Z            (input) DOUBLE PRECISION array, dimension (3)
// *               Each of the elements in z must be positive.
// *
// *  FINIT        (input) DOUBLE PRECISION
// *               The value of f at 0. It is more accurate than the one
// *               evaluated inside this routine (if someone wants to do
// *               so).
// *
// *  TAU          (output) DOUBLE PRECISION
// *               The root of the equation f(x).
// *
// *  INFO         (output) INTEGER
// *               = 0: successful exit
// *               > 0: if INFO = 1, failure to converge
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int maxit= 20;
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double three= 3.0e0;
static double four= 4.0e0;
static double eight= 8.0e0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Local Arrays ..
static double [] dscale= new double[(3)];
static double [] zscale= new double[(3)];
// *     ..
// *     .. Local Scalars ..
static boolean scale= false;
static int i= 0;
static int iter= 0;
static int niter= 0;
static double a= 0.0;
static double b= 0.0;
static double base= 0.0;
static double c= 0.0;
static double ddf= 0.0;
static double df= 0.0;
static double eps= 0.0;
static double erretm= 0.0;
static double eta= 0.0;
static double f= 0.0;
static double fc= 0.0;
static double pretau= 0.0;
static double sclfac= 0.0;
static double sclinv= 0.0;
static double small1= 0.0;
static double small2= 0.0;
static double sminv1= 0.0;
static double sminv2= 0.0;
static double temp= 0.0;
static double temp1= 0.0;
static double temp2= 0.0;
static double temp3= 0.0;
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaed6 (int kniter,
boolean orgati,
double rho,
double [] d, int _d_offset,
double [] z, int _z_offset,
double finit,
doubleW tau,
intW info)  {

info.val = 0;
// *
niter = 1;
tau.val = zero;
if (kniter == 2)  {
    if (orgati)  {
    temp = (d[(3)- 1+ _d_offset]-d[(2)- 1+ _d_offset])/two;
c = rho+z[(1)- 1+ _z_offset]/((d[(1)- 1+ _d_offset]-d[(2)- 1+ _d_offset])-temp);
a = c*(d[(2)- 1+ _d_offset]+d[(3)- 1+ _d_offset])+z[(2)- 1+ _z_offset]+z[(3)- 1+ _z_offset];
b = c*d[(2)- 1+ _d_offset]*d[(3)- 1+ _d_offset]+z[(2)- 1+ _z_offset]*d[(3)- 1+ _d_offset]+z[(3)- 1+ _z_offset]*d[(2)- 1+ _d_offset];
}              // Close if()
else  {
  temp = (d[(1)- 1+ _d_offset]-d[(2)- 1+ _d_offset])/two;
c = rho+z[(3)- 1+ _z_offset]/((d[(3)- 1+ _d_offset]-d[(2)- 1+ _d_offset])-temp);
a = c*(d[(1)- 1+ _d_offset]+d[(2)- 1+ _d_offset])+z[(1)- 1+ _z_offset]+z[(2)- 1+ _z_offset];
b = c*d[(1)- 1+ _d_offset]*d[(2)- 1+ _d_offset]+z[(1)- 1+ _z_offset]*d[(2)- 1+ _d_offset]+z[(2)- 1+ _z_offset]*d[(1)- 1+ _d_offset];
}              //  Close else.
if (c == zero)  {
    tau.val = b/a;
}              // Close if()
else if (a <= zero)  {
    tau.val = (a-Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close else if()
else  {
  tau.val = two*b/(a+Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
temp = rho+z[(1)- 1+ _z_offset]/(d[(1)- 1+ _d_offset]-tau.val)+z[(2)- 1+ _z_offset]/(d[(2)- 1+ _d_offset]-tau.val)+z[(3)- 1+ _z_offset]/(d[(3)- 1+ _d_offset]-tau.val);
if (Math.abs(finit) <= Math.abs(temp))  
    tau.val = zero;
}              // Close if()
// *
// *     On first call to routine, get machine parameters for
// *     possible scaling to avoid overflow
// *
if (first)  {
    eps = Dlamch.dlamch("Epsilon");
base = Dlamch.dlamch("Base");
small1 = Math.pow(base, ((int)(Math.log(Dlamch.dlamch("SafMin"))/Math.log(base)/three)));
sminv1 = one/small1;
small2 = small1*small1;
sminv2 = sminv1*sminv1;
first = false;
}              // Close if()
// *
// *     Determine if scaling of inputs necessary to avoid overflow
// *     when computing 1/TEMP**3
// *
if (orgati)  {
    temp = Math.min(Math.abs(d[(2)- 1+ _d_offset]-tau.val), Math.abs(d[(3)- 1+ _d_offset]-tau.val)) ;
}              // Close if()
else  {
  temp = Math.min(Math.abs(d[(1)- 1+ _d_offset]-tau.val), Math.abs(d[(2)- 1+ _d_offset]-tau.val)) ;
}              //  Close else.
scale = false;
if (temp <= small1)  {
    scale = true;
if (temp <= small2)  {
    // *
// *        Scale up by power of radix nearest 1/SAFMIN**(2/3)
// *
sclfac = sminv2;
sclinv = small2;
}              // Close if()
else  {
  // *
// *        Scale up by power of radix nearest 1/SAFMIN**(1/3)
// *
sclfac = sminv1;
sclinv = small1;
}              //  Close else.
// *
// *        Scaling up safe because D, Z, TAU scaled elsewhere to be O(1)
// *
{
forloop10:
for (i = 1; i <= 3; i++) {
dscale[(i)- 1] = d[(i)- 1+ _d_offset]*sclfac;
zscale[(i)- 1] = z[(i)- 1+ _z_offset]*sclfac;
Dummy.label("Dlaed6",10);
}              //  Close for() loop. 
}
tau.val = tau.val*sclfac;
}              // Close if()
else  {
  // *
// *        Copy D and Z to DSCALE and ZSCALE
// *
{
forloop20:
for (i = 1; i <= 3; i++) {
dscale[(i)- 1] = d[(i)- 1+ _d_offset];
zscale[(i)- 1] = z[(i)- 1+ _z_offset];
Dummy.label("Dlaed6",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
fc = zero;
df = zero;
ddf = zero;
{
forloop30:
for (i = 1; i <= 3; i++) {
temp = one/(dscale[(i)- 1]-tau.val);
temp1 = zscale[(i)- 1]*temp;
temp2 = temp1*temp;
temp3 = temp2*temp;
fc = fc+temp1/dscale[(i)- 1];
df = df+temp2;
ddf = ddf+temp3;
Dummy.label("Dlaed6",30);
}              //  Close for() loop. 
}
f = finit+tau.val*fc;
// *
if (Math.abs(f) <= zero)  
    Dummy.go_to("Dlaed6",60);
// *
// *        Iteration begins
// *
// *     It is not hard to see that
// *
// *           1) Iterations will go up monotonically
// *              if FINIT < 0;
// *
// *           2) Iterations will go down monotonically
// *              if FINIT > 0.
// *
iter = niter+1;
// *
{
forloop50:
for (niter = iter; niter <= maxit; niter++) {
// *
if (orgati)  {
    temp1 = dscale[(2)- 1]-tau.val;
temp2 = dscale[(3)- 1]-tau.val;
}              // Close if()
else  {
  temp1 = dscale[(1)- 1]-tau.val;
temp2 = dscale[(2)- 1]-tau.val;
}              //  Close else.
a = (temp1+temp2)*f-temp1*temp2*df;
b = temp1*temp2*f;
c = f-(temp1+temp2)*df+temp1*temp2*ddf;
if (c == zero)  {
    eta = b/a;
}              // Close if()
else if (a <= zero)  {
    eta = (a-Math.sqrt(Math.abs(a*a-four*b*c)))/(two*c);
}              // Close else if()
else  {
  eta = two*b/(a+Math.sqrt(Math.abs(a*a-four*b*c)));
}              //  Close else.
if (f*eta >= zero)  {
    eta = -f/df;
}              // Close if()
// *
temp = eta+tau.val;
if (orgati)  {
    if (eta > zero && temp >= dscale[(3)- 1])  
    eta = (dscale[(3)- 1]-tau.val)/two;
if (eta < zero && temp <= dscale[(2)- 1])  
    eta = (dscale[(2)- 1]-tau.val)/two;
}              // Close if()
else  {
  if (eta > zero && temp >= dscale[(2)- 1])  
    eta = (dscale[(2)- 1]-tau.val)/two;
if (eta < zero && temp <= dscale[(1)- 1])  
    eta = (dscale[(1)- 1]-tau.val)/two;
}              //  Close else.
pretau = tau.val;
tau.val = tau.val+eta;
// *
fc = zero;
erretm = Math.abs(rho);
df = zero;
ddf = zero;
{
forloop40:
for (i = 1; i <= 3; i++) {
temp = one/(dscale[(i)- 1]-tau.val);
temp1 = zscale[(i)- 1]*temp;
temp2 = temp1*temp;
temp3 = temp2*temp;
fc = fc+temp1/(dscale[(i)- 1]-pretau);
erretm = erretm+Math.abs(temp1);
df = df+temp2;
ddf = ddf+temp3;
Dummy.label("Dlaed6",40);
}              //  Close for() loop. 
}
f = f+eta*fc;
erretm = eight*erretm+Math.abs(tau.val)*df;
if (Math.abs(f) <= eps*erretm)  
    Dummy.go_to("Dlaed6",60);
Dummy.label("Dlaed6",50);
}              //  Close for() loop. 
}
info.val = 1;
label60:
   Dummy.label("Dlaed6",60);
// *
// *     Undo scaling
// *
if (scale)  
    tau.val = tau.val*sclinv;
Dummy.go_to("Dlaed6",999999);
// *
// *     End of DLAED6
// *
Dummy.label("Dlaed6",999999);
return;
   }
} // End class.
