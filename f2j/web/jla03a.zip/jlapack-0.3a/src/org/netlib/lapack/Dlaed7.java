/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed7 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED7 computes the updated eigensystem of a diagonal
// *  matrix after modification by a rank-one symmetric matrix. This
// *  routine is used only for the eigenproblem which requires all
// *  eigenvalues and optionally eigenvectors of a dense symmetric matrix
// *  that has been reduced to tridiagonal form.  DLAED1 handles
// *  the case in which all eigenvalues and eigenvectors of a symmetric
// *  tridiagonal matrix are desired.
// *
// *    T = Q(in) ( D(in) + RHO * Z*Z' ) Q'(in) = Q(out) * D(out) * Q'(out)
// *
// *     where Z = Q'u, u is a vector of length N with ones in the
// *     CUTPNT and CUTPNT + 1 th elements and zeros elsewhere.
// *
// *     The eigenvectors of the original matrix are stored in Q, and the
// *     eigenvalues are in D.  The algorithm consists of three stages:
// *
// *        The first stage consists of deflating the size of the problem
// *        when there are multiple eigenvalues or if there is a zero in
// *        the Z vector.  For each such occurence the dimension of the
// *        secular equation problem is reduced by one.  This stage is
// *        performed by the routine DLAED8.
// *
// *        The second stage consists of calculating the updated
// *        eigenvalues. This is done by finding the roots of the secular
// *        equation via the routine DLAED4 (as called by SLAED9).
// *        This routine also calculates the eigenvectors of the current
// *        problem.
// *
// *        The final stage consists of computing the updated eigenvectors
// *        directly using the updated eigenvalues.  The eigenvectors for
// *        the current problem are multiplied with the eigenvectors from
// *        the overall problem.
// *
// *  Arguments
// *  =========
// *
// *  ICOMPQ  (input) INTEGER
// *          = 0:  Compute eigenvalues only.
// *          = 1:  Compute eigenvectors of original dense symmetric matrix
// *                also.  On entry, Q contains the orthogonal matrix used
// *                to reduce the original matrix to tridiagonal form.
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  QSIZ   (input) INTEGER
// *         The dimension of the orthogonal matrix used to reduce
// *         the full matrix to tridiagonal form.  QSIZ >= N if ICOMPQ = 1.
// *
// *  TLVLS  (input) INTEGER
// *         The total number of merging levels in the overall divide and
// *         conquer tree.
// *
// *  CURLVL (input) INTEGER
// *         The current level in the overall merge routine,
// *         0 <= CURLVL <= TLVLS.
// *
// *  CURPBM (input) INTEGER
// *         The current problem in the current level in the overall
// *         merge routine (counting from upper left to lower right).
// *
// *  D      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On entry, the eigenvalues of the rank-1-perturbed matrix.
// *         On exit, the eigenvalues of the repaired matrix.
// *
// *  Q      (input/output) DOUBLE PRECISION array, dimension (LDQ, N)
// *         On entry, the eigenvectors of the rank-1-perturbed matrix.
// *         On exit, the eigenvectors of the repaired tridiagonal matrix.
// *
// *  LDQ    (input) INTEGER
// *         The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  INDXQ  (output) INTEGER array, dimension (N)
// *         The permutation which will reintegrate the subproblem just
// *         solved back into sorted order, i.e., D( INDXQ( I = 1, N ) )
// *         will be in ascending order.
// *
// *  RHO    (input) DOUBLE PRECISION
// *         The subdiagonal element used to create the rank-1
// *         modification.
// *
// *  CUTPNT (input) INTEGER
// *         Contains the location of the last eigenvalue in the leading
// *         sub-matrix.  min(1,N) <= CUTPNT <= N.
// *
// *  QSTORE (input/output) DOUBLE PRECISION array, dimension (N**2+1)
// *         Stores eigenvectors of submatrices encountered during
// *         divide and conquer, packed together. QPTR points to
// *         beginning of the submatrices.
// *
// *  QPTR   (input/output) INTEGER array, dimension (N+2)
// *         List of indices pointing to beginning of submatrices stored
// *         in QSTORE. The submatrices are numbered starting at the
// *         bottom left of the divide and conquer tree, from left to
// *         right and bottom to top.
// *
// *  PRMPTR (input) INTEGER array, dimension (N lg N)
// *         Contains a list of pointers which indicate where in PERM a
// *         level's permutation is stored.  PRMPTR(i+1) - PRMPTR(i)
// *         indicates the size of the permutation and also the size of
// *         the full, non-deflated problem.
// *
// *  PERM   (input) INTEGER array, dimension (N lg N)
// *         Contains the permutations (from deflation and sorting) to be
// *         applied to each eigenblock.
// *
// *  GIVPTR (input) INTEGER array, dimension (N lg N)
// *         Contains a list of pointers which indicate where in GIVCOL a
// *         level's Givens rotations are stored.  GIVPTR(i+1) - GIVPTR(i)
// *         indicates the number of Givens rotations.
// *
// *  GIVCOL (input) INTEGER array, dimension (2, N lg N)
// *         Each pair of numbers indicates a pair of columns to take place
// *         in a Givens rotation.
// *
// *  GIVNUM (input) DOUBLE PRECISION array, dimension (2, N lg N)
// *         Each number indicates the S value to be used in the
// *         corresponding Givens rotation.
// *
// *  WORK   (workspace) DOUBLE PRECISION array, dimension (3*N+QSIZ*N)
// *
// *  IWORK  (workspace) INTEGER array, dimension (4*N)
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = 1, an eigenvalue did not converge
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int coltyp= 0;
static int curr= 0;
static int i= 0;
static int idlmda= 0;
static int indx= 0;
static int indxc= 0;
static int indxp= 0;
static int iq2= 0;
static int is= 0;
static int iw= 0;
static int iz= 0;
static intW k= new intW(0);
static int ldq2= 0;
static int n1= 0;
static int n2= 0;
static int ptr= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed7 (int icompq,
int n,
int qsiz,
int tlvls,
int curlvl,
int curpbm,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
int [] indxq, int _indxq_offset,
doubleW rho,
int cutpnt,
double [] qstore, int _qstore_offset,
int [] qptr, int _qptr_offset,
int [] prmptr, int _prmptr_offset,
int [] perm, int _perm_offset,
int [] givptr, int _givptr_offset,
int [] givcol, int _givcol_offset,
double [] givnum, int _givnum_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
// *
if (icompq < 0 || icompq > 1)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (icompq == 1 && qsiz < n)  {
    info.val = -4;
}              // Close else if()
else if (ldq < Math.max(1, n) )  {
    info.val = -9;
}              // Close else if()
else if (Math.min(1, n)  > cutpnt || n < cutpnt)  {
    info.val = -12;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED7",-info.val);
Dummy.go_to("Dlaed7",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaed7",999999);
// *
// *     The following values are for bookkeeping purposes only.  They are
// *     integer pointers which indicate the portion of the workspace
// *     used by a particular array in DLAED8 and SLAED9.
// *
if (icompq == 1)  {
    ldq2 = qsiz;
}              // Close if()
else  {
  ldq2 = n;
}              //  Close else.
// *
iz = 1;
idlmda = iz+n;
iw = idlmda+n;
iq2 = iw+n;
is = iq2+n*ldq2;
// *
indx = 1;
indxc = indx+n;
coltyp = indxc+n;
indxp = coltyp+n;
// *
// *     Form the z-vector which consists of the last row of Q_1 and the
// *     first row of Q_2.
// *
ptr = (int)(1+Math.pow(2, tlvls));
{
forloop10:
for (i = 1; i <= curlvl-1; i++) {
ptr = (int)(ptr+Math.pow(2, (tlvls-i)));
Dummy.label("Dlaed7",10);
}              //  Close for() loop. 
}
curr = ptr+curpbm;
Dlaeda.dlaeda(n,tlvls,curlvl,curpbm,prmptr,_prmptr_offset,perm,_perm_offset,givptr,_givptr_offset,givcol,_givcol_offset,givnum,_givnum_offset,qstore,_qstore_offset,qptr,_qptr_offset,work,(iz)- 1+ _work_offset,work,(iz+n)- 1+ _work_offset,info);
// *
// *     When solving the final problem, we no longer need the stored data,
// *     so we will overwrite the data from this level onto the previously
// *     used storage space.
// *
if (curlvl == tlvls)  {
    qptr[(curr)- 1+ _qptr_offset] = 1;
prmptr[(curr)- 1+ _prmptr_offset] = 1;
givptr[(curr)- 1+ _givptr_offset] = 1;
}              // Close if()
// *
// *     Sort and Deflate eigenvalues.
// *
dlaed8_adapter(icompq,k,n,qsiz,d,_d_offset,q,_q_offset,ldq,indxq,_indxq_offset,rho,cutpnt,work,(iz)- 1+ _work_offset,work,(idlmda)- 1+ _work_offset,work,(iq2)- 1+ _work_offset,ldq2,work,(iw)- 1+ _work_offset,perm,(prmptr[(curr)- 1+ _prmptr_offset])- 1+ _perm_offset,givptr,(curr+1)- 1+ _givptr_offset,givcol,(1)- 1+(givptr[(curr)- 1+ _givptr_offset]- 1)*2+ _givcol_offset,givnum,(1)- 1+(givptr[(curr)- 1+ _givptr_offset]- 1)*2+ _givnum_offset,iwork,(indxp)- 1+ _iwork_offset,iwork,(indx)- 1+ _iwork_offset,info);
prmptr[(curr+1)- 1+ _prmptr_offset] = prmptr[(curr)- 1+ _prmptr_offset]+n;
givptr[(curr+1)- 1+ _givptr_offset] = givptr[(curr+1)- 1+ _givptr_offset]+givptr[(curr)- 1+ _givptr_offset];
// *
// *     Solve Secular Equation.
// *
if (k.val != 0)  {
    Dlaed9.dlaed9(k.val,1,k.val,n,d,_d_offset,work,(is)- 1+ _work_offset,k.val,rho.val,work,(idlmda)- 1+ _work_offset,work,(iw)- 1+ _work_offset,qstore,(qptr[(curr)- 1+ _qptr_offset])- 1+ _qstore_offset,k.val,info);
if (info.val != 0)  
    Dummy.go_to("Dlaed7",30);
if (icompq == 1)  {
    Dgemm.dgemm("N","N",qsiz,k.val,k.val,one,work,(iq2)- 1+ _work_offset,ldq2,qstore,(qptr[(curr)- 1+ _qptr_offset])- 1+ _qstore_offset,k.val,zero,q,_q_offset,ldq);
}              // Close if()
qptr[(curr+1)- 1+ _qptr_offset] = (int)(qptr[(curr)- 1+ _qptr_offset]+Math.pow(k.val, 2));
// *
// *     Prepare the INDXQ sorting permutation.
// *
n1 = k.val;
n2 = n-k.val;
Dlamrg.dlamrg(n1,n2,d,_d_offset,1,-1,indxq,_indxq_offset);
}              // Close if()
else  {
  qptr[(curr+1)- 1+ _qptr_offset] = qptr[(curr)- 1+ _qptr_offset];
{
forloop20:
for (i = 1; i <= n; i++) {
indxq[(i)- 1+ _indxq_offset] = i;
Dummy.label("Dlaed7",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
label30:
   Dummy.label("Dlaed7",30);
Dummy.go_to("Dlaed7",999999);
// *
// *     End of DLAED7
// *
Dummy.label("Dlaed7",999999);
return;
   }
// adapter for dlaed8
private static void dlaed8_adapter(int arg0 ,intW arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,int arg6 ,int [] arg7 , int arg7_offset ,doubleW arg8 ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset ,int arg13 ,double [] arg14 , int arg14_offset ,int [] arg15 , int arg15_offset ,int [] arg16 , int arg16_offset ,int [] arg17 , int arg17_offset ,double [] arg18 , int arg18_offset ,int [] arg19 , int arg19_offset ,int [] arg20 , int arg20_offset ,intW arg21 )
{
intW _f2j_tmp16 = new intW(arg16[arg16_offset]);

Dlaed8.dlaed8(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8,arg9,arg10, arg10_offset,arg11, arg11_offset,arg12, arg12_offset,arg13,arg14, arg14_offset,arg15, arg15_offset,_f2j_tmp16,arg17, arg17_offset,arg18, arg18_offset,arg19, arg19_offset,arg20, arg20_offset,arg21);

arg16[arg16_offset] = _f2j_tmp16.val;
}

} // End class.
