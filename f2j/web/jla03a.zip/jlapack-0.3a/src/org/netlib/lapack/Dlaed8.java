/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed8 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED8 merges the two sets of eigenvalues together into a single
// *  sorted set.  Then it tries to deflate the size of the problem.
// *  There are two ways in which deflation can occur:  when two or more
// *  eigenvalues are close together or if there is a tiny element in the
// *  Z vector.  For each such occurrence the order of the related secular
// *  equation problem is reduced by one.
// *
// *  Arguments
// *  =========
// *
// *  ICOMPQ  (input) INTEGER
// *          = 0:  Compute eigenvalues only.
// *          = 1:  Compute eigenvectors of original dense symmetric matrix
// *                also.  On entry, Q contains the orthogonal matrix used
// *                to reduce the original matrix to tridiagonal form.
// *
// *  K      (output) INTEGER
// *         The number of non-deflated eigenvalues, and the order of the
// *         related secular equation.
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  QSIZ   (input) INTEGER
// *         The dimension of the orthogonal matrix used to reduce
// *         the full matrix to tridiagonal form.  QSIZ >= N if ICOMPQ = 1.
// *
// *  D      (input/output) DOUBLE PRECISION array, dimension (N)
// *         On entry, the eigenvalues of the two submatrices to be
// *         combined.  On exit, the trailing (N-K) updated eigenvalues
// *         (those which were deflated) sorted into increasing order.
// *
// *  Q      (input/output) DOUBLE PRECISION array, dimension (LDQ,N)
// *         If ICOMPQ = 0, Q is not referenced.  Otherwise,
// *         on entry, Q contains the eigenvectors of the partially solved
// *         system which has been previously updated in matrix
// *         multiplies with other partially solved eigensystems.
// *         On exit, Q contains the trailing (N-K) updated eigenvectors
// *         (those which were deflated) in its last N-K columns.
// *
// *  LDQ    (input) INTEGER
// *         The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  INDXQ  (input) INTEGER array, dimension (N)
// *         The permutation which separately sorts the two sub-problems
// *         in D into ascending order.  Note that elements in the second
// *         half of this permutation must first have CUTPNT added to
// *         their values in order to be accurate.
// *
// *  RHO    (input/output) DOUBLE PRECISION
// *         On entry, the off-diagonal element associated with the rank-1
// *         cut which originally split the two submatrices which are now
// *         being recombined.
// *         On exit, RHO has been modified to the value required by
// *         DLAED3.
// *
// *  CUTPNT (input) INTEGER
// *         The location of the last eigenvalue in the leading
// *         sub-matrix.  min(1,N) <= CUTPNT <= N.
// *
// *  Z      (input) DOUBLE PRECISION array, dimension (N)
// *         On entry, Z contains the updating vector (the last row of
// *         the first sub-eigenvector matrix and the first row of the
// *         second sub-eigenvector matrix).
// *         On exit, the contents of Z are destroyed by the updating
// *         process.
// *
// *  DLAMDA (output) DOUBLE PRECISION array, dimension (N)
// *         A copy of the first K eigenvalues which will be used by
// *         DLAED3 to form the secular equation.
// *
// *  Q2     (output) DOUBLE PRECISION array, dimension (LDQ2,N)
// *         If ICOMPQ = 0, Q2 is not referenced.  Otherwise,
// *         a copy of the first K eigenvectors which will be used by
// *         DLAED7 in a matrix multiply (DGEMM) to update the new
// *         eigenvectors.
// *
// *  LDQ2   (input) INTEGER
// *         The leading dimension of the array Q2.  LDQ2 >= max(1,N).
// *
// *  W      (output) DOUBLE PRECISION array, dimension (N)
// *         The first k values of the final deflation-altered z-vector and
// *         will be passed to DLAED3.
// *
// *  PERM   (output) INTEGER array, dimension (N)
// *         The permutations (from deflation and sorting) to be applied
// *         to each eigenblock.
// *
// *  GIVPTR (output) INTEGER
// *         The number of Givens rotations which took place in this
// *         subproblem.
// *
// *  GIVCOL (output) INTEGER array, dimension (2, N)
// *         Each pair of numbers indicates a pair of columns to take place
// *         in a Givens rotation.
// *
// *  GIVNUM (output) DOUBLE PRECISION array, dimension (2, N)
// *         Each number indicates the S value to be used in the
// *         corresponding Givens rotation.
// *
// *  INDXP  (workspace) INTEGER array, dimension (N)
// *         The permutation used to place deflated values of D at the end
// *         of the array.  INDXP(1:K) points to the nondeflated D-values
// *         and INDXP(K+1:N) points to the deflated eigenvalues.
// *
// *  INDX   (workspace) INTEGER array, dimension (N)
// *         The permutation used to sort the contents of D into ascending
// *         order.
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double mone= -1.0e0;
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double eight= 8.0e0;
// *     ..
// *     .. Local Scalars ..
// *
static int i= 0;
static int imax= 0;
static int j= 0;
static int jlam= 0;
static int jmax= 0;
static int jp= 0;
static int k2= 0;
static int n1= 0;
static int n1p1= 0;
static int n2= 0;
static double c= 0.0;
static double eps= 0.0;
static double s= 0.0;
static double t= 0.0;
static double tau= 0.0;
static double tol= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed8 (int icompq,
intW k,
int n,
int qsiz,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
int [] indxq, int _indxq_offset,
doubleW rho,
int cutpnt,
double [] z, int _z_offset,
double [] dlamda, int _dlamda_offset,
double [] q2, int _q2_offset,
int ldq2,
double [] w, int _w_offset,
int [] perm, int _perm_offset,
intW givptr,
int [] givcol, int _givcol_offset,
double [] givnum, int _givnum_offset,
int [] indxp, int _indxp_offset,
int [] indx, int _indx_offset,
intW info)  {

info.val = 0;
// *
if (icompq < 0 || icompq > 1)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -3;
}              // Close else if()
else if (icompq == 1 && qsiz < n)  {
    info.val = -4;
}              // Close else if()
else if (ldq < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
else if (cutpnt < Math.min(1, n)  || cutpnt > n)  {
    info.val = -10;
}              // Close else if()
else if (ldq2 < Math.max(1, n) )  {
    info.val = -14;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED8",-info.val);
Dummy.go_to("Dlaed8",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaed8",999999);
// *
n1 = cutpnt;
n2 = n-n1;
n1p1 = n1+1;
// *
if (rho.val < zero)  {
    Dscal.dscal(n2,mone,z,(n1p1)- 1+ _z_offset,1);
}              // Close if()
// *
// *     Normalize z so that norm(z) = 1
// *
t = one/Math.sqrt(two);
{
forloop10:
for (j = 1; j <= n; j++) {
indx[(j)- 1+ _indx_offset] = j;
Dummy.label("Dlaed8",10);
}              //  Close for() loop. 
}
Dscal.dscal(n,t,z,_z_offset,1);
rho.val = Math.abs(two*rho.val);
// *
// *     Sort the eigenvalues into increasing order
// *
{
forloop20:
for (i = cutpnt+1; i <= n; i++) {
indxq[(i)- 1+ _indxq_offset] = indxq[(i)- 1+ _indxq_offset]+cutpnt;
Dummy.label("Dlaed8",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n; i++) {
dlamda[(i)- 1+ _dlamda_offset] = d[(indxq[(i)- 1+ _indxq_offset])- 1+ _d_offset];
w[(i)- 1+ _w_offset] = z[(indxq[(i)- 1+ _indxq_offset])- 1+ _z_offset];
Dummy.label("Dlaed8",30);
}              //  Close for() loop. 
}
i = 1;
j = cutpnt+1;
Dlamrg.dlamrg(n1,n2,dlamda,_dlamda_offset,1,1,indx,_indx_offset);
{
forloop40:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = dlamda[(indx[(i)- 1+ _indx_offset])- 1+ _dlamda_offset];
z[(i)- 1+ _z_offset] = w[(indx[(i)- 1+ _indx_offset])- 1+ _w_offset];
Dummy.label("Dlaed8",40);
}              //  Close for() loop. 
}
// *
// *     Calculate the allowable deflation tolerence
// *
imax = Idamax.idamax(n,z,_z_offset,1);
jmax = Idamax.idamax(n,d,_d_offset,1);
eps = Dlamch.dlamch("Epsilon");
tol = eight*eps*Math.abs(d[(jmax)- 1+ _d_offset]);
// *
// *     If the rank-1 modifier is small enough, no more needs to be done
// *     except to reorganize Q so that its columns correspond with the
// *     elements in D.
// *
if (rho.val*Math.abs(z[(imax)- 1+ _z_offset]) <= tol)  {
    k.val = 0;
if (icompq == 0)  {
    {
forloop50:
for (j = 1; j <= n; j++) {
perm[(j)- 1+ _perm_offset] = indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset];
Dummy.label("Dlaed8",50);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop60:
for (j = 1; j <= n; j++) {
perm[(j)- 1+ _perm_offset] = indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset];
Dcopy.dcopy(qsiz,q,(1)- 1+(perm[(j)- 1+ _perm_offset]- 1)*ldq+ _q_offset,1,q2,(1)- 1+(j- 1)*ldq2+ _q2_offset,1);
Dummy.label("Dlaed8",60);
}              //  Close for() loop. 
}
Dlacpy.dlacpy("A",qsiz,n,q2,(1)- 1+(1- 1)*ldq2+ _q2_offset,ldq2,q,(1)- 1+(1- 1)*ldq+ _q_offset,ldq);
}              //  Close else.
Dummy.go_to("Dlaed8",999999);
}              // Close if()
// *
// *     If there are multiple eigenvalues then the problem deflates.  Here
// *     the number of equal eigenvalues are found.  As each equal
// *     eigenvalue is found, an elementary reflector is computed to rotate
// *     the corresponding eigensubspace so that the corresponding
// *     components of Z are zero in this new basis.
// *
k.val = 0;
givptr.val = 0;
k2 = n+1;
{
forloop70:
for (j = 1; j <= n; j++) {
if (rho.val*Math.abs(z[(j)- 1+ _z_offset]) <= tol)  {
    // *
// *           Deflate due to small z component.
// *
k2 = k2-1;
indxp[(k2)- 1+ _indxp_offset] = j;
if (j == n)  
    Dummy.go_to("Dlaed8",110);
}              // Close if()
else  {
  jlam = j;
Dummy.go_to("Dlaed8",80);
}              //  Close else.
Dummy.label("Dlaed8",70);
}              //  Close for() loop. 
}
label80:
   Dummy.label("Dlaed8",80);
j = j+1;
if (j > n)  
    Dummy.go_to("Dlaed8",100);
if (rho.val*Math.abs(z[(j)- 1+ _z_offset]) <= tol)  {
    // *
// *        Deflate due to small z component.
// *
k2 = k2-1;
indxp[(k2)- 1+ _indxp_offset] = j;
}              // Close if()
else  {
  // *
// *        Check if eigenvalues are close enough to allow deflation.
// *
s = z[(jlam)- 1+ _z_offset];
c = z[(j)- 1+ _z_offset];
// *
// *        Find sqrt(a**2+b**2) without overflow or
// *        destructive underflow.
// *
tau = Dlapy2.dlapy2(c,s);
t = d[(j)- 1+ _d_offset]-d[(jlam)- 1+ _d_offset];
c = c/tau;
s = -s/tau;
if (Math.abs(t*c*s) <= tol)  {
    // *
// *           Deflation is possible.
// *
z[(j)- 1+ _z_offset] = tau;
z[(jlam)- 1+ _z_offset] = zero;
// *
// *           Record the appropriate Givens rotation
// *
givptr.val = givptr.val+1;
givcol[(1)- 1+(givptr.val- 1)*2+ _givcol_offset] = indxq[(indx[(jlam)- 1+ _indx_offset])- 1+ _indxq_offset];
givcol[(2)- 1+(givptr.val- 1)*2+ _givcol_offset] = indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset];
givnum[(1)- 1+(givptr.val- 1)*2+ _givnum_offset] = c;
givnum[(2)- 1+(givptr.val- 1)*2+ _givnum_offset] = s;
if (icompq == 1)  {
    Drot.drot(qsiz,q,(1)- 1+(indxq[(indx[(jlam)- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,q,(1)- 1+(indxq[(indx[(j)- 1+ _indx_offset])- 1+ _indxq_offset]- 1)*ldq+ _q_offset,1,c,s);
}              // Close if()
t = d[(jlam)- 1+ _d_offset]*c*c+d[(j)- 1+ _d_offset]*s*s;
d[(j)- 1+ _d_offset] = d[(jlam)- 1+ _d_offset]*s*s+d[(j)- 1+ _d_offset]*c*c;
d[(jlam)- 1+ _d_offset] = t;
k2 = k2-1;
i = 1;
label90:
   Dummy.label("Dlaed8",90);
if (k2+i <= n)  {
    if (d[(jlam)- 1+ _d_offset] < d[(indxp[(k2+i)- 1+ _indxp_offset])- 1+ _d_offset])  {
    indxp[(k2+i-1)- 1+ _indxp_offset] = indxp[(k2+i)- 1+ _indxp_offset];
indxp[(k2+i)- 1+ _indxp_offset] = jlam;
i = i+1;
Dummy.go_to("Dlaed8",90);
}              // Close if()
else  {
  indxp[(k2+i-1)- 1+ _indxp_offset] = jlam;
}              //  Close else.
}              // Close if()
else  {
  indxp[(k2+i-1)- 1+ _indxp_offset] = jlam;
}              //  Close else.
jlam = j;
}              // Close if()
else  {
  k.val = k.val+1;
w[(k.val)- 1+ _w_offset] = z[(jlam)- 1+ _z_offset];
dlamda[(k.val)- 1+ _dlamda_offset] = d[(jlam)- 1+ _d_offset];
indxp[(k.val)- 1+ _indxp_offset] = jlam;
jlam = j;
}              //  Close else.
}              //  Close else.
Dummy.go_to("Dlaed8",80);
label100:
   Dummy.label("Dlaed8",100);
// *
// *     Record the last eigenvalue.
// *
k.val = k.val+1;
w[(k.val)- 1+ _w_offset] = z[(jlam)- 1+ _z_offset];
dlamda[(k.val)- 1+ _dlamda_offset] = d[(jlam)- 1+ _d_offset];
indxp[(k.val)- 1+ _indxp_offset] = jlam;
// *
label110:
   Dummy.label("Dlaed8",110);
// *
// *     Sort the eigenvalues and corresponding eigenvectors into DLAMDA
// *     and Q2 respectively.  The eigenvalues/vectors which were not
// *     deflated go into the first K slots of DLAMDA and Q2 respectively,
// *     while those which were deflated go into the last N - K slots.
// *
if (icompq == 0)  {
    {
forloop120:
for (j = 1; j <= n; j++) {
jp = indxp[(j)- 1+ _indxp_offset];
dlamda[(j)- 1+ _dlamda_offset] = d[(jp)- 1+ _d_offset];
perm[(j)- 1+ _perm_offset] = indxq[(indx[(jp)- 1+ _indx_offset])- 1+ _indxq_offset];
Dummy.label("Dlaed8",120);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop130:
for (j = 1; j <= n; j++) {
jp = indxp[(j)- 1+ _indxp_offset];
dlamda[(j)- 1+ _dlamda_offset] = d[(jp)- 1+ _d_offset];
perm[(j)- 1+ _perm_offset] = indxq[(indx[(jp)- 1+ _indx_offset])- 1+ _indxq_offset];
Dcopy.dcopy(qsiz,q,(1)- 1+(perm[(j)- 1+ _perm_offset]- 1)*ldq+ _q_offset,1,q2,(1)- 1+(j- 1)*ldq2+ _q2_offset,1);
Dummy.label("Dlaed8",130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     The deflated eigenvalues and their corresponding vectors go back
// *     into the last N - K slots of D and Q respectively.
// *
if (k.val < n)  {
    if (icompq == 0)  {
    Dcopy.dcopy(n-k.val,dlamda,(k.val+1)- 1+ _dlamda_offset,1,d,(k.val+1)- 1+ _d_offset,1);
}              // Close if()
else  {
  Dcopy.dcopy(n-k.val,dlamda,(k.val+1)- 1+ _dlamda_offset,1,d,(k.val+1)- 1+ _d_offset,1);
Dlacpy.dlacpy("A",qsiz,n-k.val,q2,(1)- 1+(k.val+1- 1)*ldq2+ _q2_offset,ldq2,q,(1)- 1+(k.val+1- 1)*ldq+ _q_offset,ldq);
}              //  Close else.
}              // Close if()
// *
Dummy.go_to("Dlaed8",999999);
// *
// *     End of DLAED8
// *
Dummy.label("Dlaed8",999999);
return;
   }
} // End class.
