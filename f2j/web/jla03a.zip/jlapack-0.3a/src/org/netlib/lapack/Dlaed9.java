/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaed9 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Oak Ridge National Lab, Argonne National Lab,
// *     Courant Institute, NAG Ltd., and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAED9 finds the roots of the secular equation, as defined by the
// *  values in D, Z, and RHO, between KSTART and KSTOP.  It makes the
// *  appropriate calls to DLAED4 and then stores the new matrix of
// *  eigenvectors for use in calculating the next level of Z vectors.
// *
// *  Arguments
// *  =========
// *
// *  K       (input) INTEGER
// *          The number of terms in the rational function to be solved by
// *          DLAED4.  K >= 0.
// *
// *  KSTART  (input) INTEGER
// *  KSTOP   (input) INTEGER
// *          The updated eigenvalues Lambda(I), KSTART <= I <= KSTOP
// *          are to be computed.  1 <= KSTART <= KSTOP <= K.
// *
// *  N       (input) INTEGER
// *          The number of rows and columns in the Q matrix.
// *          N >= K (delation may result in N > K).
// *
// *  D       (output) DOUBLE PRECISION array, dimension (N)
// *          D(I) contains the updated eigenvalues
// *          for KSTART <= I <= KSTOP.
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDQ,N)
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= max( 1, N ).
// *
// *  RHO     (input) DOUBLE PRECISION
// *          The value of the parameter in the rank one update equation.
// *          RHO >= 0 required.
// *
// *  DLAMDA  (input) DOUBLE PRECISION array, dimension (K)
// *          The first K elements of this array contain the old roots
// *          of the deflated updating problem.  These are the poles
// *          of the secular equation.
// *
// *  W       (input) DOUBLE PRECISION array, dimension (K)
// *          The first K elements of this array contain the components
// *          of the deflation-adjusted updating vector.
// *
// *  S       (output) DOUBLE PRECISION array, dimension (LDS, K)
// *          Will contain the eigenvectors of the repaired matrix which
// *          will be stored for subsequent Z vector calculation and
// *          multiplied by the previously accumulated eigenvectors
// *          to update the system.
// *
// *  LDS     (input) INTEGER
// *          The leading dimension of S.  LDS >= max( 1, K ).
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  if INFO = 1, an eigenvalue did not converge
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaed9 (int k,
int kstart,
int kstop,
int n,
double [] d, int _d_offset,
double [] q, int _q_offset,
int ldq,
double rho,
double [] dlamda, int _dlamda_offset,
double [] w, int _w_offset,
double [] s, int _s_offset,
int lds,
intW info)  {

info.val = 0;
// *
if (k < 0)  {
    info.val = -1;
}              // Close if()
else if (kstart < 1 || kstart > Math.max(1, k) )  {
    info.val = -2;
}              // Close else if()
else if (Math.max(1, kstop)  < kstart || kstop > Math.max(1, k) )  {
    info.val = -3;
}              // Close else if()
else if (n < k)  {
    info.val = -4;
}              // Close else if()
else if (ldq < Math.max(1, k) )  {
    info.val = -7;
}              // Close else if()
else if (lds < Math.max(1, k) )  {
    info.val = -12;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAED9",-info.val);
Dummy.go_to("Dlaed9",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (k == 0)  
    Dummy.go_to("Dlaed9",999999);
// *
// *     Modify values DLAMDA(i) to make sure all DLAMDA(i)-DLAMDA(j) can
// *     be computed with high relative accuracy (barring over/underflow).
// *     This is a problem on machines without a guard digit in
// *     add/subtract (Cray XMP, Cray YMP, Cray C 90 and Cray 2).
// *     The following code replaces DLAMDA(I) by 2*DLAMDA(I)-DLAMDA(I),
// *     which on any of these machines zeros out the bottommost
// *     bit of DLAMDA(I) if it is 1; this makes the subsequent
// *     subtractions DLAMDA(I)-DLAMDA(J) unproblematic when cancellation
// *     occurs. On binary machines with a guard digit (almost all
// *     machines) it does not change DLAMDA(I) at all. On hexadecimal
// *     and decimal machines with a guard digit, it slightly
// *     changes the bottommost bits of DLAMDA(I). It does not account
// *     for hexadecimal or decimal machines without guard digits
// *     (we know of none). We use a subroutine call to compute
// *     2*DLAMBDA(I) to prevent optimizing compilers from eliminating
// *     this code.
// *
{
forloop10:
for (i = 1; i <= n; i++) {
dlamda[(i)- 1+ _dlamda_offset] = Dlamc3.dlamc3(dlamda[(i)- 1+ _dlamda_offset],dlamda[(i)- 1+ _dlamda_offset])-dlamda[(i)- 1+ _dlamda_offset];
Dummy.label("Dlaed9",10);
}              //  Close for() loop. 
}
// *
{
forloop20:
for (j = kstart; j <= kstop; j++) {
dlaed4_adapter(k,j,dlamda,_dlamda_offset,w,_w_offset,q,(1)- 1+(j- 1)*ldq+ _q_offset,rho,d,(j)- 1+ _d_offset,info);
// *
// *        If the zero finder fails, the computation is terminated.
// *
if (info.val != 0)  
    Dummy.go_to("Dlaed9",120);
Dummy.label("Dlaed9",20);
}              //  Close for() loop. 
}
// *
if (k == 1 || k == 2)  {
    {
forloop40:
for (i = 1; i <= k; i++) {
{
forloop30:
for (j = 1; j <= k; j++) {
s[(j)- 1+(i- 1)*lds+ _s_offset] = q[(j)- 1+(i- 1)*ldq+ _q_offset];
Dummy.label("Dlaed9",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaed9",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dlaed9",120);
}              // Close if()
// *
// *     Compute updated W.
// *
Dcopy.dcopy(k,w,_w_offset,1,s,_s_offset,1);
// *
// *     Initialize W(I) = Q(I,I)
// *
Dcopy.dcopy(k,q,_q_offset,ldq+1,w,_w_offset,1);
{
forloop70:
for (j = 1; j <= k; j++) {
{
forloop50:
for (i = 1; i <= j-1; i++) {
w[(i)- 1+ _w_offset] = w[(i)- 1+ _w_offset]*(q[(i)- 1+(j- 1)*ldq+ _q_offset]/(dlamda[(i)- 1+ _dlamda_offset]-dlamda[(j)- 1+ _dlamda_offset]));
Dummy.label("Dlaed9",50);
}              //  Close for() loop. 
}
{
forloop60:
for (i = j+1; i <= k; i++) {
w[(i)- 1+ _w_offset] = w[(i)- 1+ _w_offset]*(q[(i)- 1+(j- 1)*ldq+ _q_offset]/(dlamda[(i)- 1+ _dlamda_offset]-dlamda[(j)- 1+ _dlamda_offset]));
Dummy.label("Dlaed9",60);
}              //  Close for() loop. 
}
Dummy.label("Dlaed9",70);
}              //  Close for() loop. 
}
{
forloop80:
for (i = 1; i <= k; i++) {
w[(i)- 1+ _w_offset] = ((s[(i)- 1+(1- 1)*lds+ _s_offset]) >= 0 ? Math.abs(Math.sqrt(-w[(i)- 1+ _w_offset])) : -Math.abs(Math.sqrt(-w[(i)- 1+ _w_offset])));
Dummy.label("Dlaed9",80);
}              //  Close for() loop. 
}
// *
// *     Compute eigenvectors of the modified rank-1 modification.
// *
{
forloop110:
for (j = 1; j <= k; j++) {
{
forloop90:
for (i = 1; i <= k; i++) {
q[(i)- 1+(j- 1)*ldq+ _q_offset] = w[(i)- 1+ _w_offset]/q[(i)- 1+(j- 1)*ldq+ _q_offset];
Dummy.label("Dlaed9",90);
}              //  Close for() loop. 
}
temp = Dnrm2.dnrm2(k,q,(1)- 1+(j- 1)*ldq+ _q_offset,1);
{
forloop100:
for (i = 1; i <= k; i++) {
s[(i)- 1+(j- 1)*lds+ _s_offset] = q[(i)- 1+(j- 1)*ldq+ _q_offset]/temp;
Dummy.label("Dlaed9",100);
}              //  Close for() loop. 
}
Dummy.label("Dlaed9",110);
}              //  Close for() loop. 
}
// *
label120:
   Dummy.label("Dlaed9",120);
Dummy.go_to("Dlaed9",999999);
// *
// *     End of DLAED9
// *
Dummy.label("Dlaed9",999999);
return;
   }
// adapter for dlaed4
private static void dlaed4_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double arg5 ,double [] arg6 , int arg6_offset ,intW arg7 )
{
doubleW _f2j_tmp6 = new doubleW(arg6[arg6_offset]);

Dlaed4.dlaed4(arg0,arg1,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5,_f2j_tmp6,arg7);

arg6[arg6_offset] = _f2j_tmp6.val;
}

} // End class.
