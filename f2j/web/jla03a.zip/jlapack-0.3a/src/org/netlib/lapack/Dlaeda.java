/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaeda {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAEDA computes the Z vector corresponding to the merge step in the
// *  CURLVLth step of the merge process with TLVLS steps for the CURPBMth
// *  problem.
// *
// *  Arguments
// *  =========
// *
// *  N      (input) INTEGER
// *         The dimension of the symmetric tridiagonal matrix.  N >= 0.
// *
// *  TLVLS  (input) INTEGER
// *         The total number of merging levels in the overall divide and
// *         conquer tree.
// *
// *  CURLVL (input) INTEGER
// *         The current level in the overall merge routine,
// *         0 <= curlvl <= tlvls.
// *
// *  CURPBM (input) INTEGER
// *         The current problem in the current level in the overall
// *         merge routine (counting from upper left to lower right).
// *
// *  PRMPTR (input) INTEGER array, dimension (N lg N)
// *         Contains a list of pointers which indicate where in PERM a
// *         level's permutation is stored.  PRMPTR(i+1) - PRMPTR(i)
// *         indicates the size of the permutation and incidentally the
// *         size of the full, non-deflated problem.
// *
// *  PERM   (input) INTEGER array, dimension (N lg N)
// *         Contains the permutations (from deflation and sorting) to be
// *         applied to each eigenblock.
// *
// *  GIVPTR (input) INTEGER array, dimension (N lg N)
// *         Contains a list of pointers which indicate where in GIVCOL a
// *         level's Givens rotations are stored.  GIVPTR(i+1) - GIVPTR(i)
// *         indicates the number of Givens rotations.
// *
// *  GIVCOL (input) INTEGER array, dimension (2, N lg N)
// *         Each pair of numbers indicates a pair of columns to take place
// *         in a Givens rotation.
// *
// *  GIVNUM (input) DOUBLE PRECISION array, dimension (2, N lg N)
// *         Each number indicates the S value to be used in the
// *         corresponding Givens rotation.
// *
// *  Q      (input) DOUBLE PRECISION array, dimension (N**2)
// *         Contains the square eigenblocks from previous levels, the
// *         starting positions for blocks are given by QPTR.
// *
// *  QPTR   (input) INTEGER array, dimension (N+2)
// *         Contains a list of pointers which indicate where in Q an
// *         eigenblock is stored.  SQRT( QPTR(i+1) - QPTR(i) ) indicates
// *         the size of the block.
// *
// *  Z      (output) DOUBLE PRECISION array, dimension (N)
// *         On output this vector contains the updating vector (the last
// *         row of the first sub-eigenvector matrix and the first row of
// *         the second sub-eigenvector matrix).
// *
// *  ZTEMP  (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  INFO   (output) INTEGER
// *          = 0:  successful exit.
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int bsiz1= 0;
static int bsiz2= 0;
static int curr= 0;
static int i= 0;
static int k= 0;
static int mid= 0;
static int psiz1= 0;
static int psiz2= 0;
static int ptr= 0;
static int zptr1= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlaeda (int n,
int tlvls,
int curlvl,
int curpbm,
int [] prmptr, int _prmptr_offset,
int [] perm, int _perm_offset,
int [] givptr, int _givptr_offset,
int [] givcol, int _givcol_offset,
double [] givnum, int _givnum_offset,
double [] q, int _q_offset,
int [] qptr, int _qptr_offset,
double [] z, int _z_offset,
double [] ztemp, int _ztemp_offset,
intW info)  {

info.val = 0;
// *
if (n < 0)  {
    info.val = -1;
}              // Close if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAEDA",-info.val);
Dummy.go_to("Dlaeda",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaeda",999999);
// *
// *     Determine location of first number in second half.
// *
mid = n/2+1;
// *
// *     Gather last/first rows of appropriate eigenblocks into center of Z
// *
ptr = 1;
// *
// *     Determine location of lowest level subproblem in the full storage
// *     scheme
// *
curr = (int)(ptr+curpbm*Math.pow(2, curlvl)+Math.pow(2, (curlvl-1))-1);
// *
// *     Determine size of these matrices.  We add HALF to the value of
// *     the SQRT in case the machine underestimates one of these square
// *     roots.
// *
bsiz1 = (int)(half+Math.sqrt((double)(qptr[(curr+1)- 1+ _qptr_offset]-qptr[(curr)- 1+ _qptr_offset])));
bsiz2 = (int)(half+Math.sqrt((double)(qptr[(curr+2)- 1+ _qptr_offset]-qptr[(curr+1)- 1+ _qptr_offset])));
{
forloop10:
for (k = 1; k <= mid-bsiz1-1; k++) {
z[(k)- 1+ _z_offset] = zero;
Dummy.label("Dlaeda",10);
}              //  Close for() loop. 
}
Dcopy.dcopy(bsiz1,q,(qptr[(curr)- 1+ _qptr_offset]+bsiz1-1)- 1+ _q_offset,bsiz1,z,(mid-bsiz1)- 1+ _z_offset,1);
Dcopy.dcopy(bsiz2,q,(qptr[(curr+1)- 1+ _qptr_offset])- 1+ _q_offset,bsiz2,z,(mid)- 1+ _z_offset,1);
{
forloop20:
for (k = mid+bsiz2; k <= n; k++) {
z[(k)- 1+ _z_offset] = zero;
Dummy.label("Dlaeda",20);
}              //  Close for() loop. 
}
// *
// *     Loop thru remaining levels 1 -> CURLVL applying the Givens
// *     rotations and permutation and then multiplying the center matrices
// *     against the current Z.
// *
ptr = (int)(Math.pow(2, tlvls)+1);
{
forloop70:
for (k = 1; k <= curlvl-1; k++) {
curr = (int)(ptr+curpbm*Math.pow(2, (curlvl-k))+Math.pow(2, (curlvl-k-1))-1);
psiz1 = prmptr[(curr+1)- 1+ _prmptr_offset]-prmptr[(curr)- 1+ _prmptr_offset];
psiz2 = prmptr[(curr+2)- 1+ _prmptr_offset]-prmptr[(curr+1)- 1+ _prmptr_offset];
zptr1 = mid-psiz1;
// *
// *       Apply Givens at CURR and CURR+1
// *
{
forloop30:
for (i = givptr[(curr)- 1+ _givptr_offset]; i <= givptr[(curr+1)- 1+ _givptr_offset]-1; i++) {
Drot.drot(1,z,(zptr1+givcol[(1)- 1+(i- 1)*2+ _givcol_offset]-1)- 1+ _z_offset,1,z,(zptr1+givcol[(2)- 1+(i- 1)*2+ _givcol_offset]-1)- 1+ _z_offset,1,givnum[(1)- 1+(i- 1)*2+ _givnum_offset],givnum[(2)- 1+(i- 1)*2+ _givnum_offset]);
Dummy.label("Dlaeda",30);
}              //  Close for() loop. 
}
{
forloop40:
for (i = givptr[(curr+1)- 1+ _givptr_offset]; i <= givptr[(curr+2)- 1+ _givptr_offset]-1; i++) {
Drot.drot(1,z,(mid-1+givcol[(1)- 1+(i- 1)*2+ _givcol_offset])- 1+ _z_offset,1,z,(mid-1+givcol[(2)- 1+(i- 1)*2+ _givcol_offset])- 1+ _z_offset,1,givnum[(1)- 1+(i- 1)*2+ _givnum_offset],givnum[(2)- 1+(i- 1)*2+ _givnum_offset]);
Dummy.label("Dlaeda",40);
}              //  Close for() loop. 
}
psiz1 = prmptr[(curr+1)- 1+ _prmptr_offset]-prmptr[(curr)- 1+ _prmptr_offset];
psiz2 = prmptr[(curr+2)- 1+ _prmptr_offset]-prmptr[(curr+1)- 1+ _prmptr_offset];
{
forloop50:
for (i = 0; i <= psiz1-1; i++) {
ztemp[(i+1)- 1+ _ztemp_offset] = z[(zptr1+perm[(prmptr[(curr)- 1+ _prmptr_offset]+i)- 1+ _perm_offset]-1)- 1+ _z_offset];
Dummy.label("Dlaeda",50);
}              //  Close for() loop. 
}
{
forloop60:
for (i = 0; i <= psiz2-1; i++) {
ztemp[(psiz1+i+1)- 1+ _ztemp_offset] = z[(mid+perm[(prmptr[(curr+1)- 1+ _prmptr_offset]+i)- 1+ _perm_offset]-1)- 1+ _z_offset];
Dummy.label("Dlaeda",60);
}              //  Close for() loop. 
}
// *
// *        Multiply Blocks at CURR and CURR+1
// *
// *        Determine size of these matrices.  We add HALF to the value of
// *        the SQRT in case the machine underestimates one of these
// *        square roots.
// *
bsiz1 = (int)(half+Math.sqrt((double)(qptr[(curr+1)- 1+ _qptr_offset]-qptr[(curr)- 1+ _qptr_offset])));
bsiz2 = (int)(half+Math.sqrt((double)(qptr[(curr+2)- 1+ _qptr_offset]-qptr[(curr+1)- 1+ _qptr_offset])));
if (bsiz1 > 0)  {
    Dgemv.dgemv("T",bsiz1,bsiz1,one,q,(qptr[(curr)- 1+ _qptr_offset])- 1+ _q_offset,bsiz1,ztemp,(1)- 1+ _ztemp_offset,1,zero,z,(zptr1)- 1+ _z_offset,1);
}              // Close if()
Dcopy.dcopy(psiz1-bsiz1,ztemp,(bsiz1+1)- 1+ _ztemp_offset,1,z,(zptr1+bsiz1)- 1+ _z_offset,1);
if (bsiz2 > 0)  {
    Dgemv.dgemv("T",bsiz2,bsiz2,one,q,(qptr[(curr+1)- 1+ _qptr_offset])- 1+ _q_offset,bsiz2,ztemp,(psiz1+1)- 1+ _ztemp_offset,1,zero,z,(mid)- 1+ _z_offset,1);
}              // Close if()
Dcopy.dcopy(psiz2-bsiz2,ztemp,(psiz1+bsiz2+1)- 1+ _ztemp_offset,1,z,(mid+bsiz2)- 1+ _z_offset,1);
// *
ptr = (int)(ptr+Math.pow(2, (tlvls-k)));
Dummy.label("Dlaeda",70);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dlaeda",999999);
// *
// *     End of DLAEDA
// *
Dummy.label("Dlaeda",999999);
return;
   }
} // End class.
