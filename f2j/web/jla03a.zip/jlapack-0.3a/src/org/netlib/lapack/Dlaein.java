/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaein {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAEIN uses inverse iteration to find a right or left eigenvector
// *  corresponding to the eigenvalue (WR,WI) of a real upper Hessenberg
// *  matrix H.
// *
// *  Arguments
// *  =========
// *
// *  RIGHTV   (input) LOGICAL
// *          = .TRUE. : compute right eigenvector;
// *          = .FALSE.: compute left eigenvector.
// *
// *  NOINIT   (input) LOGICAL
// *          = .TRUE. : no initial vector supplied in (VR,VI).
// *          = .FALSE.: initial vector supplied in (VR,VI).
// *
// *  N       (input) INTEGER
// *          The order of the matrix H.  N >= 0.
// *
// *  H       (input) DOUBLE PRECISION array, dimension (LDH,N)
// *          The upper Hessenberg matrix H.
// *
// *  LDH     (input) INTEGER
// *          The leading dimension of the array H.  LDH >= max(1,N).
// *
// *  WR      (input) DOUBLE PRECISION
// *  WI      (input) DOUBLE PRECISION
// *          The real and imaginary parts of the eigenvalue of H whose
// *          corresponding right or left eigenvector is to be computed.
// *
// *  VR      (input/output) DOUBLE PRECISION array, dimension (N)
// *  VI      (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, if NOINIT = .FALSE. and WI = 0.0, VR must contain
// *          a real starting vector for inverse iteration using the real
// *          eigenvalue WR; if NOINIT = .FALSE. and WI.ne.0.0, VR and VI
// *          must contain the real and imaginary parts of a complex
// *          starting vector for inverse iteration using the complex
// *          eigenvalue (WR,WI); otherwise VR and VI need not be set.
// *          On exit, if WI = 0.0 (real eigenvalue), VR contains the
// *          computed real eigenvector; if WI.ne.0.0 (complex eigenvalue),
// *          VR and VI contain the real and imaginary parts of the
// *          computed complex eigenvector. The eigenvector is normalized
// *          so that the component of largest magnitude has magnitude 1;
// *          here the magnitude of a complex number (x,y) is taken to be
// *          |x| + |y|.
// *          VI is not referenced if WI = 0.0.
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (LDB,N)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= N+1.
// *
// *  WORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  EPS3    (input) DOUBLE PRECISION
// *          A small machine-dependent value which is used to perturb
// *          close eigenvalues, and to replace zero pivots.
// *
// *  SMLNUM  (input) DOUBLE PRECISION
// *          A machine-dependent value close to the underflow threshold.
// *
// *  BIGNUM  (input) DOUBLE PRECISION
// *          A machine-dependent value close to the overflow threshold.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          = 1:  inverse iteration did not converge; VR is set to the
// *                last iterate, and so is VI if WI.ne.0.0.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double tenth= 1.0e-1;
// *     ..
// *     .. Local Scalars ..
static String normin= new String(" ");
static String trans= new String(" ");
static int i= 0;
static int i1= 0;
static int i2= 0;
static int i3= 0;
static intW ierr= new intW(0);
static int its= 0;
static int j= 0;
static double absbii= 0.0;
static double absbjj= 0.0;
static double ei= 0.0;
static double ej= 0.0;
static double growto= 0.0;
static double norm= 0.0;
static double nrmsml= 0.0;
static double rec= 0.0;
static double rootn= 0.0;
static doubleW scale= new doubleW(0.0);
static double temp= 0.0;
static double vcrit= 0.0;
static double vmax= 0.0;
static double vnorm= 0.0;
static double w= 0.0;
static double w1= 0.0;
static double x= 0.0;
static double xi= 0.0;
static double xr= 0.0;
static double y= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaein (boolean rightv,
boolean noinit,
int n,
double [] h, int _h_offset,
int ldh,
double wr,
double wi,
double [] vr, int _vr_offset,
double [] vi, int _vi_offset,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
double eps3,
double smlnum,
double bignum,
intW info)  {

info.val = 0;
// *
// *     GROWTO is the threshold used in the acceptance test for an
// *     eigenvector.
// *
rootn = Math.sqrt((double)(n));
growto = tenth/rootn;
nrmsml = Math.max(one, eps3*rootn) *smlnum;
// *
// *     Form B = H - (WR,WI)*I (except that the subdiagonal elements and
// *     the imaginary parts of the diagonal elements are not stored).
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = h[(i)- 1+(j- 1)*ldh+ _h_offset];
Dummy.label("Dlaein",10);
}              //  Close for() loop. 
}
b[(j)- 1+(j- 1)*ldb+ _b_offset] = h[(j)- 1+(j- 1)*ldh+ _h_offset]-wr;
Dummy.label("Dlaein",20);
}              //  Close for() loop. 
}
// *
if (wi == zero)  {
    // *
// *        Real eigenvalue.
// *
if (noinit)  {
    // *
// *           Set initial vector.
// *
{
forloop30:
for (i = 1; i <= n; i++) {
vr[(i)- 1+ _vr_offset] = eps3;
Dummy.label("Dlaein",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Scale supplied initial vector.
// *
vnorm = Dnrm2.dnrm2(n,vr,_vr_offset,1);
Dscal.dscal(n,(eps3*rootn)/Math.max(vnorm, nrmsml) ,vr,_vr_offset,1);
}              //  Close else.
// *
if (rightv)  {
    // *
// *           LU decomposition with partial pivoting of B, replacing zero
// *           pivots by EPS3.
// *
{
forloop60:
for (i = 1; i <= n-1; i++) {
ei = h[(i+1)- 1+(i- 1)*ldh+ _h_offset];
if (Math.abs(b[(i)- 1+(i- 1)*ldb+ _b_offset]) < Math.abs(ei))  {
    // *
// *                 Interchange rows and eliminate.
// *
x = b[(i)- 1+(i- 1)*ldb+ _b_offset]/ei;
b[(i)- 1+(i- 1)*ldb+ _b_offset] = ei;
{
forloop40:
for (j = i+1; j <= n; j++) {
temp = b[(i+1)- 1+(j- 1)*ldb+ _b_offset];
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-x*temp;
b[(i)- 1+(j- 1)*ldb+ _b_offset] = temp;
Dummy.label("Dlaein",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *                 Eliminate without interchange.
// *
if (b[(i)- 1+(i- 1)*ldb+ _b_offset] == zero)  
    b[(i)- 1+(i- 1)*ldb+ _b_offset] = eps3;
x = ei/b[(i)- 1+(i- 1)*ldb+ _b_offset];
if (x != zero)  {
    {
forloop50:
for (j = i+1; j <= n; j++) {
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i+1)- 1+(j- 1)*ldb+ _b_offset]-x*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlaein",50);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
Dummy.label("Dlaein",60);
}              //  Close for() loop. 
}
if (b[(n)- 1+(n- 1)*ldb+ _b_offset] == zero)  
    b[(n)- 1+(n- 1)*ldb+ _b_offset] = eps3;
// *
trans = "N";
// *
}              // Close if()
else  {
  // *
// *           UL decomposition with partial pivoting of B, replacing zero
// *           pivots by EPS3.
// *
{
int _j_inc = -1;
forloop90:
for (j = n; j >= 2; j += _j_inc) {
ej = h[(j)- 1+(j-1- 1)*ldh+ _h_offset];
if (Math.abs(b[(j)- 1+(j- 1)*ldb+ _b_offset]) < Math.abs(ej))  {
    // *
// *                 Interchange columns and eliminate.
// *
x = b[(j)- 1+(j- 1)*ldb+ _b_offset]/ej;
b[(j)- 1+(j- 1)*ldb+ _b_offset] = ej;
{
forloop70:
for (i = 1; i <= j-1; i++) {
temp = b[(i)- 1+(j-1- 1)*ldb+ _b_offset];
b[(i)- 1+(j-1- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-x*temp;
b[(i)- 1+(j- 1)*ldb+ _b_offset] = temp;
Dummy.label("Dlaein",70);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *                 Eliminate without interchange.
// *
if (b[(j)- 1+(j- 1)*ldb+ _b_offset] == zero)  
    b[(j)- 1+(j- 1)*ldb+ _b_offset] = eps3;
x = ej/b[(j)- 1+(j- 1)*ldb+ _b_offset];
if (x != zero)  {
    {
forloop80:
for (i = 1; i <= j-1; i++) {
b[(i)- 1+(j-1- 1)*ldb+ _b_offset] = b[(i)- 1+(j-1- 1)*ldb+ _b_offset]-x*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlaein",80);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
Dummy.label("Dlaein",90);
}              //  Close for() loop. 
}
if (b[(1)- 1+(1- 1)*ldb+ _b_offset] == zero)  
    b[(1)- 1+(1- 1)*ldb+ _b_offset] = eps3;
// *
trans = "T";
// *
}              //  Close else.
// *
normin = "N";
{
forloop110:
for (its = 1; its <= n; its++) {
// *
// *           Solve U*x = scale*v for a right eigenvector
// *             or U'*x = scale*v for a left eigenvector,
// *           overwriting x on v.
// *
Dlatrs.dlatrs("Upper",trans,"Nonunit",normin,n,b,_b_offset,ldb,vr,_vr_offset,scale,work,_work_offset,ierr);
normin = "Y";
// *
// *           Test for sufficient growth in the norm of v.
// *
vnorm = Dasum.dasum(n,vr,_vr_offset,1);
if (vnorm >= growto*scale.val)  
    Dummy.go_to("Dlaein",120);
// *
// *           Choose new orthogonal starting vector and try again.
// *
temp = eps3/(rootn+one);
vr[(1)- 1+ _vr_offset] = eps3;
{
forloop100:
for (i = 2; i <= n; i++) {
vr[(i)- 1+ _vr_offset] = temp;
Dummy.label("Dlaein",100);
}              //  Close for() loop. 
}
vr[(n-its+1)- 1+ _vr_offset] = vr[(n-its+1)- 1+ _vr_offset]-eps3*rootn;
Dummy.label("Dlaein",110);
}              //  Close for() loop. 
}
// *
// *        Failure to find eigenvector in N iterations.
// *
info.val = 1;
// *
label120:
   Dummy.label("Dlaein",120);
// *
// *        Normalize eigenvector.
// *
i = Idamax.idamax(n,vr,_vr_offset,1);
Dscal.dscal(n,one/Math.abs(vr[(i)- 1+ _vr_offset]),vr,_vr_offset,1);
}              // Close if()
else  {
  // *
// *        Complex eigenvalue.
// *
if (noinit)  {
    // *
// *           Set initial vector.
// *
{
forloop130:
for (i = 1; i <= n; i++) {
vr[(i)- 1+ _vr_offset] = eps3;
vi[(i)- 1+ _vi_offset] = zero;
Dummy.label("Dlaein",130);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Scale supplied initial vector.
// *
norm = Dlapy2.dlapy2(Dnrm2.dnrm2(n,vr,_vr_offset,1),Dnrm2.dnrm2(n,vi,_vi_offset,1));
rec = (eps3*rootn)/Math.max(norm, nrmsml) ;
Dscal.dscal(n,rec,vr,_vr_offset,1);
Dscal.dscal(n,rec,vi,_vi_offset,1);
}              //  Close else.
// *
if (rightv)  {
    // *
// *           LU decomposition with partial pivoting of B, replacing zero
// *           pivots by EPS3.
// *
// *           The imaginary part of the (i,j)-th element of U is stored in
// *           B(j+1,i).
// *
b[(2)- 1+(1- 1)*ldb+ _b_offset] = -wi;
{
forloop140:
for (i = 2; i <= n; i++) {
b[(i+1)- 1+(1- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlaein",140);
}              //  Close for() loop. 
}
// *
{
forloop170:
for (i = 1; i <= n-1; i++) {
absbii = Dlapy2.dlapy2(b[(i)- 1+(i- 1)*ldb+ _b_offset],b[(i+1)- 1+(i- 1)*ldb+ _b_offset]);
ei = h[(i+1)- 1+(i- 1)*ldh+ _h_offset];
if (absbii < Math.abs(ei))  {
    // *
// *                 Interchange rows and eliminate.
// *
xr = b[(i)- 1+(i- 1)*ldb+ _b_offset]/ei;
xi = b[(i+1)- 1+(i- 1)*ldb+ _b_offset]/ei;
b[(i)- 1+(i- 1)*ldb+ _b_offset] = ei;
b[(i+1)- 1+(i- 1)*ldb+ _b_offset] = zero;
{
forloop150:
for (j = i+1; j <= n; j++) {
temp = b[(i+1)- 1+(j- 1)*ldb+ _b_offset];
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-xr*temp;
b[(j+1)- 1+(i+1- 1)*ldb+ _b_offset] = b[(j+1)- 1+(i- 1)*ldb+ _b_offset]-xi*temp;
b[(i)- 1+(j- 1)*ldb+ _b_offset] = temp;
b[(j+1)- 1+(i- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlaein",150);
}              //  Close for() loop. 
}
b[(i+2)- 1+(i- 1)*ldb+ _b_offset] = -wi;
b[(i+1)- 1+(i+1- 1)*ldb+ _b_offset] = b[(i+1)- 1+(i+1- 1)*ldb+ _b_offset]-xi*wi;
b[(i+2)- 1+(i+1- 1)*ldb+ _b_offset] = b[(i+2)- 1+(i+1- 1)*ldb+ _b_offset]+xr*wi;
}              // Close if()
else  {
  // *
// *                 Eliminate without interchanging rows.
// *
if (absbii == zero)  {
    b[(i)- 1+(i- 1)*ldb+ _b_offset] = eps3;
b[(i+1)- 1+(i- 1)*ldb+ _b_offset] = zero;
absbii = eps3;
}              // Close if()
ei = (ei/absbii)/absbii;
xr = b[(i)- 1+(i- 1)*ldb+ _b_offset]*ei;
xi = -b[(i+1)- 1+(i- 1)*ldb+ _b_offset]*ei;
{
forloop160:
for (j = i+1; j <= n; j++) {
b[(i+1)- 1+(j- 1)*ldb+ _b_offset] = b[(i+1)- 1+(j- 1)*ldb+ _b_offset]-xr*b[(i)- 1+(j- 1)*ldb+ _b_offset]+xi*b[(j+1)- 1+(i- 1)*ldb+ _b_offset];
b[(j+1)- 1+(i+1- 1)*ldb+ _b_offset] = -xr*b[(j+1)- 1+(i- 1)*ldb+ _b_offset]-xi*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlaein",160);
}              //  Close for() loop. 
}
b[(i+2)- 1+(i+1- 1)*ldb+ _b_offset] = b[(i+2)- 1+(i+1- 1)*ldb+ _b_offset]-wi;
}              //  Close else.
// *
// *              Compute 1-norm of offdiagonal elements of i-th row.
// *
work[(i)- 1+ _work_offset] = Dasum.dasum(n-i,b,(i)- 1+(i+1- 1)*ldb+ _b_offset,ldb)+Dasum.dasum(n-i,b,(i+2)- 1+(i- 1)*ldb+ _b_offset,1);
Dummy.label("Dlaein",170);
}              //  Close for() loop. 
}
if (b[(n)- 1+(n- 1)*ldb+ _b_offset] == zero && b[(n+1)- 1+(n- 1)*ldb+ _b_offset] == zero)  
    b[(n)- 1+(n- 1)*ldb+ _b_offset] = eps3;
work[(n)- 1+ _work_offset] = zero;
// *
i1 = n;
i2 = 1;
i3 = -1;
}              // Close if()
else  {
  // *
// *           UL decomposition with partial pivoting of conjg(B),
// *           replacing zero pivots by EPS3.
// *
// *           The imaginary part of the (i,j)-th element of U is stored in
// *           B(j+1,i).
// *
b[(n+1)- 1+(n- 1)*ldb+ _b_offset] = wi;
{
forloop180:
for (j = 1; j <= n-1; j++) {
b[(n+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlaein",180);
}              //  Close for() loop. 
}
// *
{
int _j_inc = -1;
forloop210:
for (j = n; j >= 2; j += _j_inc) {
ej = h[(j)- 1+(j-1- 1)*ldh+ _h_offset];
absbjj = Dlapy2.dlapy2(b[(j)- 1+(j- 1)*ldb+ _b_offset],b[(j+1)- 1+(j- 1)*ldb+ _b_offset]);
if (absbjj < Math.abs(ej))  {
    // *
// *                 Interchange columns and eliminate
// *
xr = b[(j)- 1+(j- 1)*ldb+ _b_offset]/ej;
xi = b[(j+1)- 1+(j- 1)*ldb+ _b_offset]/ej;
b[(j)- 1+(j- 1)*ldb+ _b_offset] = ej;
b[(j+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
{
forloop190:
for (i = 1; i <= j-1; i++) {
temp = b[(i)- 1+(j-1- 1)*ldb+ _b_offset];
b[(i)- 1+(j-1- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-xr*temp;
b[(j)- 1+(i- 1)*ldb+ _b_offset] = b[(j+1)- 1+(i- 1)*ldb+ _b_offset]-xi*temp;
b[(i)- 1+(j- 1)*ldb+ _b_offset] = temp;
b[(j+1)- 1+(i- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlaein",190);
}              //  Close for() loop. 
}
b[(j+1)- 1+(j-1- 1)*ldb+ _b_offset] = wi;
b[(j-1)- 1+(j-1- 1)*ldb+ _b_offset] = b[(j-1)- 1+(j-1- 1)*ldb+ _b_offset]+xi*wi;
b[(j)- 1+(j-1- 1)*ldb+ _b_offset] = b[(j)- 1+(j-1- 1)*ldb+ _b_offset]-xr*wi;
}              // Close if()
else  {
  // *
// *                 Eliminate without interchange.
// *
if (absbjj == zero)  {
    b[(j)- 1+(j- 1)*ldb+ _b_offset] = eps3;
b[(j+1)- 1+(j- 1)*ldb+ _b_offset] = zero;
absbjj = eps3;
}              // Close if()
ej = (ej/absbjj)/absbjj;
xr = b[(j)- 1+(j- 1)*ldb+ _b_offset]*ej;
xi = -b[(j+1)- 1+(j- 1)*ldb+ _b_offset]*ej;
{
forloop200:
for (i = 1; i <= j-1; i++) {
b[(i)- 1+(j-1- 1)*ldb+ _b_offset] = b[(i)- 1+(j-1- 1)*ldb+ _b_offset]-xr*b[(i)- 1+(j- 1)*ldb+ _b_offset]+xi*b[(j+1)- 1+(i- 1)*ldb+ _b_offset];
b[(j)- 1+(i- 1)*ldb+ _b_offset] = -xr*b[(j+1)- 1+(i- 1)*ldb+ _b_offset]-xi*b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlaein",200);
}              //  Close for() loop. 
}
b[(j)- 1+(j-1- 1)*ldb+ _b_offset] = b[(j)- 1+(j-1- 1)*ldb+ _b_offset]+wi;
}              //  Close else.
// *
// *              Compute 1-norm of offdiagonal elements of j-th column.
// *
work[(j)- 1+ _work_offset] = Dasum.dasum(j-1,b,(1)- 1+(j- 1)*ldb+ _b_offset,1)+Dasum.dasum(j-1,b,(j+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dummy.label("Dlaein",210);
}              //  Close for() loop. 
}
if (b[(1)- 1+(1- 1)*ldb+ _b_offset] == zero && b[(2)- 1+(1- 1)*ldb+ _b_offset] == zero)  
    b[(1)- 1+(1- 1)*ldb+ _b_offset] = eps3;
work[(1)- 1+ _work_offset] = zero;
// *
i1 = 1;
i2 = n;
i3 = 1;
}              //  Close else.
// *
{
forloop270:
for (its = 1; its <= n; its++) {
scale.val = one;
vmax = one;
vcrit = bignum;
// *
// *           Solve U*(xr,xi) = scale*(vr,vi) for a right eigenvector,
// *             or U'*(xr,xi) = scale*(vr,vi) for a left eigenvector,
// *           overwriting (xr,xi) on (vr,vi).
// *
{
int _i_inc = i3;
forloop250:
for (i = i1; (_i_inc < 0) ? i >= i2 : i <= i2; i += _i_inc) {
// *
if (work[(i)- 1+ _work_offset] > vcrit)  {
    rec = one/vmax;
Dscal.dscal(n,rec,vr,_vr_offset,1);
Dscal.dscal(n,rec,vi,_vi_offset,1);
scale.val = scale.val*rec;
vmax = one;
vcrit = bignum;
}              // Close if()
// *
xr = vr[(i)- 1+ _vr_offset];
xi = vi[(i)- 1+ _vi_offset];
if (rightv)  {
    {
forloop220:
for (j = i+1; j <= n; j++) {
xr = xr-b[(i)- 1+(j- 1)*ldb+ _b_offset]*vr[(j)- 1+ _vr_offset]+b[(j+1)- 1+(i- 1)*ldb+ _b_offset]*vi[(j)- 1+ _vi_offset];
xi = xi-b[(i)- 1+(j- 1)*ldb+ _b_offset]*vi[(j)- 1+ _vi_offset]-b[(j+1)- 1+(i- 1)*ldb+ _b_offset]*vr[(j)- 1+ _vr_offset];
Dummy.label("Dlaein",220);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop230:
for (j = 1; j <= i-1; j++) {
xr = xr-b[(j)- 1+(i- 1)*ldb+ _b_offset]*vr[(j)- 1+ _vr_offset]+b[(i+1)- 1+(j- 1)*ldb+ _b_offset]*vi[(j)- 1+ _vi_offset];
xi = xi-b[(j)- 1+(i- 1)*ldb+ _b_offset]*vi[(j)- 1+ _vi_offset]-b[(i+1)- 1+(j- 1)*ldb+ _b_offset]*vr[(j)- 1+ _vr_offset];
Dummy.label("Dlaein",230);
}              //  Close for() loop. 
}
}              //  Close else.
// *
w = Math.abs(b[(i)- 1+(i- 1)*ldb+ _b_offset])+Math.abs(b[(i+1)- 1+(i- 1)*ldb+ _b_offset]);
if (w > smlnum)  {
    if (w < one)  {
    w1 = Math.abs(xr)+Math.abs(xi);
if (w1 > w*bignum)  {
    rec = one/w1;
Dscal.dscal(n,rec,vr,_vr_offset,1);
Dscal.dscal(n,rec,vi,_vi_offset,1);
xr = vr[(i)- 1+ _vr_offset];
xi = vi[(i)- 1+ _vi_offset];
scale.val = scale.val*rec;
vmax = vmax*rec;
}              // Close if()
}              // Close if()
// *
// *                 Divide by diagonal element of B.
// *
dladiv_adapter(xr,xi,b[(i)- 1+(i- 1)*ldb+ _b_offset],b[(i+1)- 1+(i- 1)*ldb+ _b_offset],vr,(i)- 1+ _vr_offset,vi,(i)- 1+ _vi_offset);
vmax = Math.max(Math.abs(vr[(i)- 1+ _vr_offset])+Math.abs(vi[(i)- 1+ _vi_offset]), vmax) ;
vcrit = bignum/vmax;
}              // Close if()
else  {
  {
forloop240:
for (j = 1; j <= n; j++) {
vr[(j)- 1+ _vr_offset] = zero;
vi[(j)- 1+ _vi_offset] = zero;
Dummy.label("Dlaein",240);
}              //  Close for() loop. 
}
vr[(i)- 1+ _vr_offset] = one;
vi[(i)- 1+ _vi_offset] = one;
scale.val = zero;
vmax = one;
vcrit = bignum;
}              //  Close else.
Dummy.label("Dlaein",250);
}              //  Close for() loop. 
}
// *
// *           Test for sufficient growth in the norm of (VR,VI).
// *
vnorm = Dasum.dasum(n,vr,_vr_offset,1)+Dasum.dasum(n,vi,_vi_offset,1);
if (vnorm >= growto*scale.val)  
    Dummy.go_to("Dlaein",280);
// *
// *           Choose a new orthogonal starting vector and try again.
// *
y = eps3/(rootn+one);
vr[(1)- 1+ _vr_offset] = eps3;
vi[(1)- 1+ _vi_offset] = zero;
// *
{
forloop260:
for (i = 2; i <= n; i++) {
vr[(i)- 1+ _vr_offset] = y;
vi[(i)- 1+ _vi_offset] = zero;
Dummy.label("Dlaein",260);
}              //  Close for() loop. 
}
vr[(n-its+1)- 1+ _vr_offset] = vr[(n-its+1)- 1+ _vr_offset]-eps3*rootn;
Dummy.label("Dlaein",270);
}              //  Close for() loop. 
}
// *
// *        Failure to find eigenvector in N iterations
// *
info.val = 1;
// *
label280:
   Dummy.label("Dlaein",280);
// *
// *        Normalize eigenvector.
// *
vnorm = zero;
{
forloop290:
for (i = 1; i <= n; i++) {
vnorm = Math.max(vnorm, Math.abs(vr[(i)- 1+ _vr_offset])+Math.abs(vi[(i)- 1+ _vi_offset])) ;
Dummy.label("Dlaein",290);
}              //  Close for() loop. 
}
Dscal.dscal(n,one/vnorm,vr,_vr_offset,1);
Dscal.dscal(n,one/vnorm,vi,_vi_offset,1);
// *
}              //  Close else.
// *
Dummy.go_to("Dlaein",999999);
// *
// *     End of DLAEIN
// *
Dummy.label("Dlaein",999999);
return;
   }
// adapter for dladiv
private static void dladiv_adapter(double arg0 ,double arg1 ,double arg2 ,double arg3 ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);
doubleW _f2j_tmp5 = new doubleW(arg5[arg5_offset]);

Dladiv.dladiv(arg0,arg1,arg2,arg3,_f2j_tmp4,_f2j_tmp5);

arg4[arg4_offset] = _f2j_tmp4.val;
arg5[arg5_offset] = _f2j_tmp5.val;
}

} // End class.
