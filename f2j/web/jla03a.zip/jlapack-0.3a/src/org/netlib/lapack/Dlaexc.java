/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaexc {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAEXC swaps adjacent diagonal blocks T11 and T22 of order 1 or 2 in
// *  an upper quasi-triangular matrix T by an orthogonal similarity
// *  transformation.
// *
// *  T must be in Schur canonical form, that is, block upper triangular
// *  with 1-by-1 and 2-by-2 diagonal blocks; each 2-by-2 diagonal block
// *  has its diagonal elemnts equal and its off-diagonal elements of
// *  opposite sign.
// *
// *  Arguments
// *  =========
// *
// *  WANTQ   (input) LOGICAL
// *          = .TRUE. : accumulate the transformation in the matrix Q;
// *          = .FALSE.: do not accumulate the transformation.
// *
// *  N       (input) INTEGER
// *          The order of the matrix T. N >= 0.
// *
// *  T       (input/output) DOUBLE PRECISION array, dimension (LDT,N)
// *          On entry, the upper quasi-triangular matrix T, in Schur
// *          canonical form.
// *          On exit, the updated matrix T, again in Schur canonical form.
// *
// *  LDT     (input)  INTEGER
// *          The leading dimension of the array T. LDT >= max(1,N).
// *
// *  Q       (input/output) DOUBLE PRECISION array, dimension (LDQ,N)
// *          On entry, if WANTQ is .TRUE., the orthogonal matrix Q.
// *          On exit, if WANTQ is .TRUE., the updated matrix Q.
// *          If WANTQ is .FALSE., Q is not referenced.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.
// *          LDQ >= 1; and if WANTQ is .TRUE., LDQ >= N.
// *
// *  J1      (input) INTEGER
// *          The index of the first row of the first block T11.
// *
// *  N1      (input) INTEGER
// *          The order of the first block T11. N1 = 0, 1 or 2.
// *
// *  N2      (input) INTEGER
// *          The order of the second block T22. N2 = 0, 1 or 2.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          = 1: the transformed matrix T would be too far from Schur
// *               form; the blocks are not swapped and T and Q are
// *               unchanged.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double ten= 1.0e+1;
static int ldd= 4;
static int ldx= 2;
// *     ..
// *     .. Local Scalars ..
static intW ierr= new intW(0);
static int j2= 0;
static int j3= 0;
static int j4= 0;
static int k= 0;
static int nd= 0;
static doubleW cs= new doubleW(0.0);
static double dnorm= 0.0;
static double eps= 0.0;
static doubleW scale= new doubleW(0.0);
static double smlnum= 0.0;
static doubleW sn= new doubleW(0.0);
static double t11= 0.0;
static double t22= 0.0;
static double t33= 0.0;
static doubleW tau= new doubleW(0.0);
static doubleW tau1= new doubleW(0.0);
static doubleW tau2= new doubleW(0.0);
static doubleW temp= new doubleW(0.0);
static double thresh= 0.0;
static doubleW wi1= new doubleW(0.0);
static doubleW wi2= new doubleW(0.0);
static doubleW wr1= new doubleW(0.0);
static doubleW wr2= new doubleW(0.0);
static doubleW xnorm= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] d= new double[(ldd) * (4)];
static double [] u= new double[(3)];
static double [] u1= new double[(3)];
static double [] u2= new double[(3)];
static double [] x= new double[(ldx) * (2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaexc (boolean wantq,
int n,
double [] t, int _t_offset,
int ldt,
double [] q, int _q_offset,
int ldq,
int j1,
int n1,
int n2,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (n == 0 || n1 == 0 || n2 == 0)  
    Dummy.go_to("Dlaexc",999999);
if (j1+n1 > n)  
    Dummy.go_to("Dlaexc",999999);
// *
j2 = j1+1;
j3 = j1+2;
j4 = j1+3;
// *
if (n1 == 1 && n2 == 1)  {
    // *
// *        Swap two 1-by-1 blocks.
// *
t11 = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
t22 = t[(j2)- 1+(j2- 1)*ldt+ _t_offset];
// *
// *        Determine the transformation to perform the interchange.
// *
Dlartg.dlartg(t[(j1)- 1+(j2- 1)*ldt+ _t_offset],t22-t11,cs,sn,temp);
// *
// *        Apply transformation to the matrix T.
// *
if (j3 <= n)  
    Drot.drot(n-j1-1,t,(j1)- 1+(j3- 1)*ldt+ _t_offset,ldt,t,(j2)- 1+(j3- 1)*ldt+ _t_offset,ldt,cs.val,sn.val);
Drot.drot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,cs.val,sn.val);
// *
t[(j1)- 1+(j1- 1)*ldt+ _t_offset] = t22;
t[(j2)- 1+(j2- 1)*ldt+ _t_offset] = t11;
// *
if (wantq)  {
    // *
// *           Accumulate transformation in the matrix Q.
// *
Drot.drot(n,q,(1)- 1+(j1- 1)*ldq+ _q_offset,1,q,(1)- 1+(j2- 1)*ldq+ _q_offset,1,cs.val,sn.val);
}              // Close if()
// *
}              // Close if()
else  {
  // *
// *        Swapping involves at least one 2-by-2 block.
// *
// *        Copy the diagonal block of order N1+N2 to the local array D
// *        and compute its norm.
// *
nd = n1+n2;
Dlacpy.dlacpy("Full",nd,nd,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,d,0,ldd);
dnorm = Dlange.dlange("Max",nd,nd,d,0,ldd,work,_work_offset);
// *
// *        Compute machine-dependent threshold for test for accepting
// *        swap.
// *
eps = Dlamch.dlamch("P");
smlnum = Dlamch.dlamch("S")/eps;
thresh = Math.max(ten*eps*dnorm, smlnum) ;
// *
// *        Solve T11*X - X*T22 = scale*T12 for X.
// *
Dlasy2.dlasy2(false,false,-1,n1,n2,d,0,ldd,d,(n1+1)- 1+(n1+1- 1)*ldd,ldd,d,(1)- 1+(n1+1- 1)*ldd,ldd,scale,x,0,ldx,xnorm,ierr);
// *
// *        Swap the adjacent diagonal blocks.
// *
k = n1+n1+n2-3;
if (k == 1) 
  Dummy.go_to("Dlaexc",10);
else if (k == 2) 
  Dummy.go_to("Dlaexc",20);
else if (k == 3) 
  Dummy.go_to("Dlaexc",30);
// *
label10:
   Dummy.label("Dlaexc",10);
// *
// *        N1 = 1, N2 = 2: generate elementary reflector H so that:
// *
// *        ( scale, X11, X12 ) H = ( 0, 0, * )
// *
u[(1)- 1] = scale.val;
u[(2)- 1] = x[(1)- 1+(1- 1)*ldx];
u[(3)- 1] = x[(1)- 1+(2- 1)*ldx];
dlarfg_adapter(3,u,(3)- 1,u,0,1,tau);
u[(3)- 1] = one;
t11 = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
// *
// *        Perform swap provisionally on diagonal block in D.
// *
Dlarfx.dlarfx("L",3,3,u,0,tau.val,d,0,ldd,work,_work_offset);
Dlarfx.dlarfx("R",3,3,u,0,tau.val,d,0,ldd,work,_work_offset);
// *
// *        Test whether to reject swap.
// *
if (Math.max((Math.abs(d[(3)- 1+(1- 1)*ldd])) > (Math.abs(d[(3)- 1+(2- 1)*ldd])) ? (Math.abs(d[(3)- 1+(1- 1)*ldd])) : (Math.abs(d[(3)- 1+(2- 1)*ldd])), Math.abs(d[(3)- 1+(3- 1)*ldd]-t11)) > thresh)  
    Dummy.go_to("Dlaexc",50);
// *
// *        Accept swap: apply transformation to the entire matrix T.
// *
Dlarfx.dlarfx("L",3,n-j1+1,u,0,tau.val,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
Dlarfx.dlarfx("R",j2,3,u,0,tau.val,t,(1)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
// *
t[(j3)- 1+(j1- 1)*ldt+ _t_offset] = zero;
t[(j3)- 1+(j2- 1)*ldt+ _t_offset] = zero;
t[(j3)- 1+(j3- 1)*ldt+ _t_offset] = t11;
// *
if (wantq)  {
    // *
// *           Accumulate transformation in the matrix Q.
// *
Dlarfx.dlarfx("R",n,3,u,0,tau.val,q,(1)- 1+(j1- 1)*ldq+ _q_offset,ldq,work,_work_offset);
}              // Close if()
Dummy.go_to("Dlaexc",40);
// *
label20:
   Dummy.label("Dlaexc",20);
// *
// *        N1 = 2, N2 = 1: generate elementary reflector H so that:
// *
// *        H (  -X11 ) = ( * )
// *          (  -X21 ) = ( 0 )
// *          ( scale ) = ( 0 )
// *
u[(1)- 1] = -x[(1)- 1+(1- 1)*ldx];
u[(2)- 1] = -x[(2)- 1+(1- 1)*ldx];
u[(3)- 1] = scale.val;
dlarfg_adapter(3,u,(1)- 1,u,(2)- 1,1,tau);
u[(1)- 1] = one;
t33 = t[(j3)- 1+(j3- 1)*ldt+ _t_offset];
// *
// *        Perform swap provisionally on diagonal block in D.
// *
Dlarfx.dlarfx("L",3,3,u,0,tau.val,d,0,ldd,work,_work_offset);
Dlarfx.dlarfx("R",3,3,u,0,tau.val,d,0,ldd,work,_work_offset);
// *
// *        Test whether to reject swap.
// *
if (Math.max((Math.abs(d[(2)- 1+(1- 1)*ldd])) > (Math.abs(d[(3)- 1+(1- 1)*ldd])) ? (Math.abs(d[(2)- 1+(1- 1)*ldd])) : (Math.abs(d[(3)- 1+(1- 1)*ldd])), Math.abs(d[(1)- 1+(1- 1)*ldd]-t33)) > thresh)  
    Dummy.go_to("Dlaexc",50);
// *
// *        Accept swap: apply transformation to the entire matrix T.
// *
Dlarfx.dlarfx("R",j3,3,u,0,tau.val,t,(1)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
Dlarfx.dlarfx("L",3,n-j1,u,0,tau.val,t,(j1)- 1+(j2- 1)*ldt+ _t_offset,ldt,work,_work_offset);
// *
t[(j1)- 1+(j1- 1)*ldt+ _t_offset] = t33;
t[(j2)- 1+(j1- 1)*ldt+ _t_offset] = zero;
t[(j3)- 1+(j1- 1)*ldt+ _t_offset] = zero;
// *
if (wantq)  {
    // *
// *           Accumulate transformation in the matrix Q.
// *
Dlarfx.dlarfx("R",n,3,u,0,tau.val,q,(1)- 1+(j1- 1)*ldq+ _q_offset,ldq,work,_work_offset);
}              // Close if()
Dummy.go_to("Dlaexc",40);
// *
label30:
   Dummy.label("Dlaexc",30);
// *
// *        N1 = 2, N2 = 2: generate elementary reflectors H(1) and H(2) so
// *        that:
// *
// *        H(2) H(1) (  -X11  -X12 ) = (  *  * )
// *                  (  -X21  -X22 )   (  0  * )
// *                  ( scale    0  )   (  0  0 )
// *                  (    0  scale )   (  0  0 )
// *
u1[(1)- 1] = -x[(1)- 1+(1- 1)*ldx];
u1[(2)- 1] = -x[(2)- 1+(1- 1)*ldx];
u1[(3)- 1] = scale.val;
dlarfg_adapter(3,u1,(1)- 1,u1,(2)- 1,1,tau1);
u1[(1)- 1] = one;
// *
temp.val = -tau1.val*(x[(1)- 1+(2- 1)*ldx]+u1[(2)- 1]*x[(2)- 1+(2- 1)*ldx]);
u2[(1)- 1] = -temp.val*u1[(2)- 1]-x[(2)- 1+(2- 1)*ldx];
u2[(2)- 1] = -temp.val*u1[(3)- 1];
u2[(3)- 1] = scale.val;
dlarfg_adapter(3,u2,(1)- 1,u2,(2)- 1,1,tau2);
u2[(1)- 1] = one;
// *
// *        Perform swap provisionally on diagonal block in D.
// *
Dlarfx.dlarfx("L",3,4,u1,0,tau1.val,d,0,ldd,work,_work_offset);
Dlarfx.dlarfx("R",4,3,u1,0,tau1.val,d,0,ldd,work,_work_offset);
Dlarfx.dlarfx("L",3,4,u2,0,tau2.val,d,(2)- 1+(1- 1)*ldd,ldd,work,_work_offset);
Dlarfx.dlarfx("R",4,3,u2,0,tau2.val,d,(1)- 1+(2- 1)*ldd,ldd,work,_work_offset);
// *
// *        Test whether to reject swap.
// *
if (Math.max(Math.max(Math.max(Math.abs(d[(3)- 1+(1- 1)*ldd]), Math.abs(d[(3)- 1+(2- 1)*ldd])), Math.abs(d[(4)- 1+(1- 1)*ldd])), Math.abs(d[(4)- 1+(2- 1)*ldd]))  > thresh)  
    Dummy.go_to("Dlaexc",50);
// *
// *        Accept swap: apply transformation to the entire matrix T.
// *
Dlarfx.dlarfx("L",3,n-j1+1,u1,0,tau1.val,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
Dlarfx.dlarfx("R",j4,3,u1,0,tau1.val,t,(1)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
Dlarfx.dlarfx("L",3,n-j1+1,u2,0,tau2.val,t,(j2)- 1+(j1- 1)*ldt+ _t_offset,ldt,work,_work_offset);
Dlarfx.dlarfx("R",j4,3,u2,0,tau2.val,t,(1)- 1+(j2- 1)*ldt+ _t_offset,ldt,work,_work_offset);
// *
t[(j3)- 1+(j1- 1)*ldt+ _t_offset] = zero;
t[(j3)- 1+(j2- 1)*ldt+ _t_offset] = zero;
t[(j4)- 1+(j1- 1)*ldt+ _t_offset] = zero;
t[(j4)- 1+(j2- 1)*ldt+ _t_offset] = zero;
// *
if (wantq)  {
    // *
// *           Accumulate transformation in the matrix Q.
// *
Dlarfx.dlarfx("R",n,3,u1,0,tau1.val,q,(1)- 1+(j1- 1)*ldq+ _q_offset,ldq,work,_work_offset);
Dlarfx.dlarfx("R",n,3,u2,0,tau2.val,q,(1)- 1+(j2- 1)*ldq+ _q_offset,ldq,work,_work_offset);
}              // Close if()
// *
label40:
   Dummy.label("Dlaexc",40);
// *
if (n2 == 2)  {
    // *
// *           Standardize new 2-by-2 block T11
// *
dlanv2_adapter(t,(j1)- 1+(j1- 1)*ldt+ _t_offset,t,(j1)- 1+(j2- 1)*ldt+ _t_offset,t,(j2)- 1+(j1- 1)*ldt+ _t_offset,t,(j2)- 1+(j2- 1)*ldt+ _t_offset,wr1,wi1,wr2,wi2,cs,sn);
Drot.drot(n-j1-1,t,(j1)- 1+(j1+2- 1)*ldt+ _t_offset,ldt,t,(j2)- 1+(j1+2- 1)*ldt+ _t_offset,ldt,cs.val,sn.val);
Drot.drot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,cs.val,sn.val);
if (wantq)  
    Drot.drot(n,q,(1)- 1+(j1- 1)*ldq+ _q_offset,1,q,(1)- 1+(j2- 1)*ldq+ _q_offset,1,cs.val,sn.val);
}              // Close if()
// *
if (n1 == 2)  {
    // *
// *           Standardize new 2-by-2 block T22
// *
j3 = j1+n2;
j4 = j3+1;
dlanv2_adapter(t,(j3)- 1+(j3- 1)*ldt+ _t_offset,t,(j3)- 1+(j4- 1)*ldt+ _t_offset,t,(j4)- 1+(j3- 1)*ldt+ _t_offset,t,(j4)- 1+(j4- 1)*ldt+ _t_offset,wr1,wi1,wr2,wi2,cs,sn);
if (j3+2 <= n)  
    Drot.drot(n-j3-1,t,(j3)- 1+(j3+2- 1)*ldt+ _t_offset,ldt,t,(j4)- 1+(j3+2- 1)*ldt+ _t_offset,ldt,cs.val,sn.val);
Drot.drot(j3-1,t,(1)- 1+(j3- 1)*ldt+ _t_offset,1,t,(1)- 1+(j4- 1)*ldt+ _t_offset,1,cs.val,sn.val);
if (wantq)  
    Drot.drot(n,q,(1)- 1+(j3- 1)*ldq+ _q_offset,1,q,(1)- 1+(j4- 1)*ldq+ _q_offset,1,cs.val,sn.val);
}              // Close if()
// *
}              //  Close else.
Dummy.go_to("Dlaexc",999999);
// *
// *     Exit with INFO = 1 if swap was rejected.
// *
label50:
   Dummy.label("Dlaexc",50);
info.val = 1;
Dummy.go_to("Dlaexc",999999);
// *
// *     End of DLAEXC
// *
Dummy.label("Dlaexc",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,doubleW arg4 )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,arg4);

arg1[arg1_offset] = _f2j_tmp1.val;
}

// adapter for dlanv2
private static void dlanv2_adapter(double [] arg0 , int arg0_offset ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,doubleW arg4 ,doubleW arg5 ,doubleW arg6 ,doubleW arg7 ,doubleW arg8 ,doubleW arg9 )
{
doubleW _f2j_tmp0 = new doubleW(arg0[arg0_offset]);
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp2 = new doubleW(arg2[arg2_offset]);
doubleW _f2j_tmp3 = new doubleW(arg3[arg3_offset]);

Dlanv2.dlanv2(_f2j_tmp0,_f2j_tmp1,_f2j_tmp2,_f2j_tmp3,arg4,arg5,arg6,arg7,arg8,arg9);

arg0[arg0_offset] = _f2j_tmp0.val;
arg1[arg1_offset] = _f2j_tmp1.val;
arg2[arg2_offset] = _f2j_tmp2.val;
arg3[arg3_offset] = _f2j_tmp3.val;
}

} // End class.
