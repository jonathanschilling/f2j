/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlag2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAG2 computes the eigenvalues of a 2 x 2 generalized eigenvalue
// *  problem  A - w B, with scaling as necessary to avoid over-/underflow.
// *
// *  The scaling factor "s" results in a modified eigenvalue equation
// *
// *      s A - w B
// *
// *  where  s  is a non-negative scaling factor chosen so that  w,  w B,
// *  and  s A  do not overflow and, if possible, do not underflow, either.
// *
// *  Arguments
// *  =========
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, 2)
// *          On entry, the 2 x 2 matrix A.  It is assumed that its 1-norm
// *          is less than 1/SAFMIN.  Entries less than
// *          sqrt(SAFMIN)*norm(A) are subject to being treated as zero.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= 2.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB, 2)
// *          On entry, the 2 x 2 upper triangular matrix B.  It is
// *          assumed that the one-norm of B is less than 1/SAFMIN.  The
// *          diagonals should be at least sqrt(SAFMIN) times the largest
// *          element of B (in absolute value); if a diagonal is smaller
// *          than that, then  +/- sqrt(SAFMIN) will be used instead of
// *          that diagonal.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= 2.
// *
// *  SAFMIN  (input) DOUBLE PRECISION
// *          The smallest positive number s.t. 1/SAFMIN does not
// *          overflow.  (This should always be DLAMCH('S') -- it is an
// *          argument in order to avoid having to call DLAMCH frequently.)
// *
// *  SCALE1  (output) DOUBLE PRECISION
// *          A scaling factor used to avoid over-/underflow in the
// *          eigenvalue equation which defines the first eigenvalue.  If
// *          the eigenvalues are complex, then the eigenvalues are
// *          ( WR1  +/-  WI i ) / SCALE1  (which may lie outside the
// *          exponent range of the machine), SCALE1=SCALE2, and SCALE1
// *          will always be positive.  If the eigenvalues are real, then
// *          the first (real) eigenvalue is  WR1 / SCALE1 , but this may
// *          overflow or underflow, and in fact, SCALE1 may be zero or
// *          less than the underflow threshhold if the exact eigenvalue
// *          is sufficiently large.
// *
// *  SCALE2  (output) DOUBLE PRECISION
// *          A scaling factor used to avoid over-/underflow in the
// *          eigenvalue equation which defines the second eigenvalue.  If
// *          the eigenvalues are complex, then SCALE2=SCALE1.  If the
// *          eigenvalues are real, then the second (real) eigenvalue is
// *          WR2 / SCALE2 , but this may overflow or underflow, and in
// *          fact, SCALE2 may be zero or less than the underflow
// *          threshhold if the exact eigenvalue is sufficiently large.
// *
// *  WR1     (output) DOUBLE PRECISION
// *          If the eigenvalue is real, then WR1 is SCALE1 times the
// *          eigenvalue closest to the (2,2) element of A B**(-1).  If the
// *          eigenvalue is complex, then WR1=WR2 is SCALE1 times the real
// *          part of the eigenvalues.
// *
// *  WR2     (output) DOUBLE PRECISION
// *          If the eigenvalue is real, then WR2 is SCALE2 times the
// *          other eigenvalue.  If the eigenvalue is complex, then
// *          WR1=WR2 is SCALE1 times the real part of the eigenvalues.
// *
// *  WI      (output) DOUBLE PRECISION
// *          If the eigenvalue is real, then WI is zero.  If the
// *          eigenvalue is complex, then WI is SCALE1 times the imaginary
// *          part of the eigenvalues.  WI will always be non-negative.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
static double half= one/two;
static double fuzzy1= one+1.0e-5;
// *     ..
// *     .. Local Scalars ..
static double a11= 0.0;
static double a12= 0.0;
static double a21= 0.0;
static double a22= 0.0;
static double abi22= 0.0;
static double anorm= 0.0;
static double as11= 0.0;
static double as12= 0.0;
static double as22= 0.0;
static double ascale= 0.0;
static double b11= 0.0;
static double b12= 0.0;
static double b22= 0.0;
static double binv11= 0.0;
static double binv22= 0.0;
static double bmin= 0.0;
static double bnorm= 0.0;
static double bscale= 0.0;
static double bsize= 0.0;
static double c1= 0.0;
static double c2= 0.0;
static double c3= 0.0;
static double c4= 0.0;
static double c5= 0.0;
static double diff= 0.0;
static double discr= 0.0;
static double pp= 0.0;
static double qq= 0.0;
static double r= 0.0;
static double rtmax= 0.0;
static double rtmin= 0.0;
static double s1= 0.0;
static double s2= 0.0;
static double safmax= 0.0;
static double shift= 0.0;
static double ss= 0.0;
static double sum= 0.0;
static double wabs= 0.0;
static double wbig= 0.0;
static double wdet= 0.0;
static double wscale= 0.0;
static double wsize= 0.0;
static double wsmall= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlag2 (double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double safmin,
doubleW scale1,
doubleW scale2,
doubleW wr1,
doubleW wr2,
doubleW wi)  {

rtmin = Math.sqrt(safmin);
rtmax = one/rtmin;
safmax = one/safmin;
// *
// *     Scale A
// *
anorm = Math.max((Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(1- 1)*lda+ _a_offset])) > (Math.abs(a[(1)- 1+(2- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(2- 1)*lda+ _a_offset])) ? (Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(1- 1)*lda+ _a_offset])) : (Math.abs(a[(1)- 1+(2- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(2- 1)*lda+ _a_offset])), safmin);
ascale = one/anorm;
a11 = ascale*a[(1)- 1+(1- 1)*lda+ _a_offset];
a21 = ascale*a[(2)- 1+(1- 1)*lda+ _a_offset];
a12 = ascale*a[(1)- 1+(2- 1)*lda+ _a_offset];
a22 = ascale*a[(2)- 1+(2- 1)*lda+ _a_offset];
// *
// *     Perturb B if necessary to insure non-singularity
// *
b11 = b[(1)- 1+(1- 1)*ldb+ _b_offset];
b12 = b[(1)- 1+(2- 1)*ldb+ _b_offset];
b22 = b[(2)- 1+(2- 1)*ldb+ _b_offset];
bmin = rtmin*Math.max(Math.max(Math.max(Math.abs(b11), Math.abs(b12)), Math.abs(b22)), rtmin) ;
if (Math.abs(b11) < bmin)  
    b11 = ((b11) >= 0 ? Math.abs(bmin) : -Math.abs(bmin));
if (Math.abs(b22) < bmin)  
    b22 = ((b22) >= 0 ? Math.abs(bmin) : -Math.abs(bmin));
// *
// *     Scale B
// *
bnorm = Math.max((Math.abs(b11)) > (Math.abs(b12)+Math.abs(b22)) ? (Math.abs(b11)) : (Math.abs(b12)+Math.abs(b22)), safmin);
bsize = Math.max(Math.abs(b11), Math.abs(b22)) ;
bscale = one/bsize;
b11 = b11*bscale;
b12 = b12*bscale;
b22 = b22*bscale;
// *
// *     Compute larger eigenvalue by method described by C. van Loan
// *
// *     ( AS is A shifted by -SHIFT*B )
// *
binv11 = one/b11;
binv22 = one/b22;
s1 = a11*binv11;
s2 = a22*binv22;
if (Math.abs(s1) <= Math.abs(s2))  {
    as12 = a12-s1*b12;
as22 = a22-s1*b22;
ss = a21*(binv11*binv22);
abi22 = as22*binv22-ss*b12;
pp = half*abi22;
shift = s1;
}              // Close if()
else  {
  as12 = a12-s2*b12;
as11 = a11-s2*b11;
ss = a21*(binv11*binv22);
abi22 = -ss*b12;
pp = half*(as11*binv11+abi22);
shift = s2;
}              //  Close else.
qq = ss*as12;
if (Math.abs(pp*rtmin) >= one)  {
    discr = Math.pow((rtmin*pp), 2)+qq*safmin;
r = Math.sqrt(Math.abs(discr))*rtmax;
}              // Close if()
else  {
  if (Math.pow(pp, 2)+Math.abs(qq) <= safmin)  {
    discr = Math.pow((rtmax*pp), 2)+qq*safmax;
r = Math.sqrt(Math.abs(discr))*rtmin;
}              // Close if()
else  {
  discr = Math.pow(pp, 2)+qq;
r = Math.sqrt(Math.abs(discr));
}              //  Close else.
}              //  Close else.
// *
// *     Note: the test of R in the following IF is to cover the case when
// *           DISCR is small and negative and is flushed to zero during
// *           the calculation of R.  On machines which have a consistent
// *           flush-to-zero threshhold and handle numbers above that
// *           threshhold correctly, it would not be necessary.
// *
if (discr >= zero || r == zero)  {
    sum = pp+((pp) >= 0 ? Math.abs(r) : -Math.abs(r));
diff = pp-((pp) >= 0 ? Math.abs(r) : -Math.abs(r));
wbig = shift+sum;
// *
// *        Compute smaller eigenvalue
// *
wsmall = shift+diff;
if (half*Math.abs(wbig) > Math.max(Math.abs(wsmall), safmin) )  {
    wdet = (a11*a22-a12*a21)*(binv11*binv22);
wsmall = wdet/wbig;
}              // Close if()
// *
// *        Choose (real) eigenvalue closest to 2,2 element of A*B**(-1)
// *        for WR1.
// *
if (pp > abi22)  {
    wr1.val = Math.min(wbig, wsmall) ;
wr2.val = Math.max(wbig, wsmall) ;
}              // Close if()
else  {
  wr1.val = Math.max(wbig, wsmall) ;
wr2.val = Math.min(wbig, wsmall) ;
}              //  Close else.
wi.val = zero;
}              // Close if()
else  {
  // *
// *        Complex eigenvalues
// *
wr1.val = shift+pp;
wr2.val = wr1.val;
wi.val = r;
}              //  Close else.
// *
// *     Further scaling to avoid underflow and overflow in computing
// *     SCALE1 and overflow in computing w*B.
// *
// *     This scale factor (WSCALE) is bounded from above using C1 and C2,
// *     and from below using C3 and C4.
// *        C1 implements the condition  s A  must never overflow.
// *        C2 implements the condition  w B  must never overflow.
// *        C3, with C2,
// *           implement the condition that s A - w B must never overflow.
// *        C4 implements the condition  s    should not underflow.
// *        C5 implements the condition  max(s,|w|) should be at least 2.
// *
c1 = bsize*(safmin*Math.max(one, ascale) );
c2 = safmin*Math.max(one, bnorm) ;
c3 = bsize*safmin;
if (ascale <= one && bsize <= one)  {
    c4 = Math.min(one, (ascale/safmin)*bsize) ;
}              // Close if()
else  {
  c4 = one;
}              //  Close else.
if (ascale <= one || bsize <= one)  {
    c5 = Math.min(one, ascale*bsize) ;
}              // Close if()
else  {
  c5 = one;
}              //  Close else.
// *
// *     Scale first eigenvalue
// *
wabs = Math.abs(wr1.val)+Math.abs(wi.val);
wsize = Math.max(Math.max(Math.max(safmin, c1), fuzzy1*(wabs*c2+c3)), Math.min(c4, half*Math.max(wabs, c5) ) ) ;
if (wsize != one)  {
    wscale = one/wsize;
if (wsize > one)  {
    scale1.val = (Math.max(ascale, bsize) *wscale)*Math.min(ascale, bsize) ;
}              // Close if()
else  {
  scale1.val = (Math.min(ascale, bsize) *wscale)*Math.max(ascale, bsize) ;
}              //  Close else.
wr1.val = wr1.val*wscale;
if (wi.val != zero)  {
    wi.val = wi.val*wscale;
wr2.val = wr1.val;
scale2.val = scale1.val;
}              // Close if()
}              // Close if()
else  {
  scale1.val = ascale*bsize;
scale2.val = scale1.val;
}              //  Close else.
// *
// *     Scale second eigenvalue (if real)
// *
if (wi.val == zero)  {
    wsize = Math.max(Math.max(Math.max(safmin, c1), fuzzy1*(Math.abs(wr2.val)*c2+c3)), Math.min(c4, half*Math.max(Math.abs(wr2.val), c5) ) ) ;
if (wsize != one)  {
    wscale = one/wsize;
if (wsize > one)  {
    scale2.val = (Math.max(ascale, bsize) *wscale)*Math.min(ascale, bsize) ;
}              // Close if()
else  {
  scale2.val = (Math.min(ascale, bsize) *wscale)*Math.max(ascale, bsize) ;
}              //  Close else.
wr2.val = wr2.val*wscale;
}              // Close if()
else  {
  scale2.val = ascale*bsize;
}              //  Close else.
}              // Close if()
// *
// *     End of DLAG2
// *
Dummy.go_to("Dlag2",999999);
Dummy.label("Dlag2",999999);
return;
   }
} // End class.
