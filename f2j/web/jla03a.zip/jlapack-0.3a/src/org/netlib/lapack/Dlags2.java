/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlags2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGS2 computes 2-by-2 orthogonal matrices U, V and Q, such
// *  that if ( UPPER ) then
// *
// *            U'*A*Q = U'*( A1 A2 )*Q = ( x  0  )
// *                        ( 0  A3 )     ( x  x  )
// *  and
// *            V'*B*Q = V'*( B1 B2 )*Q = ( x  0  )
// *                        ( 0  B3 )     ( x  x  )
// *
// *  or if ( .NOT.UPPER ) then
// *
// *            U'*A*Q = U'*( A1 0  )*Q = ( x  x  )
// *                        ( A2 A3 )     ( 0  x  )
// *  and
// *            V'*B*Q = V'*( B1 0  )*Q = ( x  x  )
// *                        ( B2 B3 )     ( 0  x  )
// *
// *  The rows of the transformed A and B are parallel, where
// *
// *    U = (  CSU  SNU ), V = (  CSV SNV ), Q = (  CSQ   SNQ )
// *        ( -SNU  CSU )      ( -SNV CSV )      ( -SNQ   CSQ )
// *
// *  Z' denotes the transpose of Z.
// *
// *
// *  Arguments
// *  =========
// *
// *  UPPER   (input) LOGICAL
// *          = .TRUE.: the input matrices A and B are upper triangular.
// *          = .FALSE.: the input matrices A and B are lower triangular.
// *
// *  A1      (input) DOUBLE PRECISION
// *  A2      (input) DOUBLE PRECISION
// *  A3      (input) DOUBLE PRECISION
// *          On entry, A1, A2 and A3 are elements of the input 2-by-2
// *          upper (lower) triangular matrix A.
// *
// *  B1      (input) DOUBLE PRECISION
// *  B2      (input) DOUBLE PRECISION
// *  B3      (input) DOUBLE PRECISION
// *          On entry, B1, B2 and B3 are elements of the input 2-by-2
// *          upper (lower) triangular matrix B.
// *
// *  CSU     (output) DOUBLE PRECISION
// *  SNU     (output) DOUBLE PRECISION
// *          The desired orthogonal matrix U.
// *
// *  CSV     (output) DOUBLE PRECISION
// *  SNV     (output) DOUBLE PRECISION
// *          The desired orthogonal matrix V.
// *
// *  CSQ     (output) DOUBLE PRECISION
// *  SNQ     (output) DOUBLE PRECISION
// *          The desired orthogonal matrix Q.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static double a= 0.0;
static double aua11= 0.0;
static double aua12= 0.0;
static double aua21= 0.0;
static double aua22= 0.0;
static double avb12= 0.0;
static double avb11= 0.0;
static double avb21= 0.0;
static double avb22= 0.0;
static double b= 0.0;
static double c= 0.0;
static doubleW csl= new doubleW(0.0);
static doubleW csr= new doubleW(0.0);
static double d= 0.0;
static doubleW r= new doubleW(0.0);
static doubleW s1= new doubleW(0.0);
static doubleW s2= new doubleW(0.0);
static doubleW snl= new doubleW(0.0);
static doubleW snr= new doubleW(0.0);
static double ua11= 0.0;
static double ua11r= 0.0;
static double ua12= 0.0;
static double ua21= 0.0;
static double ua22= 0.0;
static double ua22r= 0.0;
static double vb11= 0.0;
static double vb11r= 0.0;
static double vb12= 0.0;
static double vb21= 0.0;
static double vb22= 0.0;
static double vb22r= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlags2 (boolean upper,
double a1,
double a2,
double a3,
double b1,
double b2,
double b3,
doubleW csu,
doubleW snu,
doubleW csv,
doubleW snv,
doubleW csq,
doubleW snq)  {

if (upper)  {
    // *
// *        Input matrices A and B are upper triangular matrices
// *
// *        Form matrix C = A*adj(B) = ( a b )
// *                                   ( 0 d )
// *
a = a1*b3;
d = a3*b1;
b = a2*b1-a1*b2;
// *
// *        The SVD of real 2-by-2 triangular C
// *
// *         ( CSL -SNL )*( A B )*(  CSR  SNR ) = ( R 0 )
// *         ( SNL  CSL ) ( 0 D ) ( -SNR  CSR )   ( 0 T )
// *
Dlasv2.dlasv2(a,b,d,s1,s2,snr,csr,snl,csl);
// *
if (Math.abs(csl.val) >= Math.abs(snl.val) || Math.abs(csr.val) >= Math.abs(snr.val))  {
    // *
// *           Compute the (1,1) and (1,2) elements of U'*A and V'*B,
// *           and (1,2) element of |U|'*|A| and |V|'*|B|.
// *
ua11r = csl.val*a1;
ua12 = csl.val*a2+snl.val*a3;
// *
vb11r = csr.val*b1;
vb12 = csr.val*b2+snr.val*b3;
// *
aua12 = Math.abs(csl.val)*Math.abs(a2)+Math.abs(snl.val)*Math.abs(a3);
avb12 = Math.abs(csr.val)*Math.abs(b2)+Math.abs(snr.val)*Math.abs(b3);
// *
// *           zero (1,2) elements of U'*A and V'*B
// *
if ((Math.abs(ua11r)+Math.abs(ua12)) != zero)  {
    if (aua12/(Math.abs(ua11r)+Math.abs(ua12)) <= avb12/(Math.abs(vb11r)+Math.abs(vb12)))  {
    Dlartg.dlartg(-ua11r,ua12,csq,snq,r);
}              // Close if()
else  {
  Dlartg.dlartg(-vb11r,vb12,csq,snq,r);
}              //  Close else.
}              // Close if()
else  {
  Dlartg.dlartg(-vb11r,vb12,csq,snq,r);
}              //  Close else.
// *
csu.val = csl.val;
snu.val = -snl.val;
csv.val = csr.val;
snv.val = -snr.val;
// *
}              // Close if()
else  {
  // *
// *           Compute the (2,1) and (2,2) elements of U'*A and V'*B,
// *           and (2,2) element of |U|'*|A| and |V|'*|B|.
// *
ua21 = -snl.val*a1;
ua22 = -snl.val*a2+csl.val*a3;
// *
vb21 = -snr.val*b1;
vb22 = -snr.val*b2+csr.val*b3;
// *
aua22 = Math.abs(snl.val)*Math.abs(a2)+Math.abs(csl.val)*Math.abs(a3);
avb22 = Math.abs(snr.val)*Math.abs(b2)+Math.abs(csr.val)*Math.abs(b3);
// *
// *           zero (2,2) elements of U'*A and V'*B, and then swap.
// *
if ((Math.abs(ua21)+Math.abs(ua22)) != zero)  {
    if (aua22/(Math.abs(ua21)+Math.abs(ua22)) <= avb22/(Math.abs(vb21)+Math.abs(vb22)))  {
    Dlartg.dlartg(-ua21,ua22,csq,snq,r);
}              // Close if()
else  {
  Dlartg.dlartg(-vb21,vb22,csq,snq,r);
}              //  Close else.
}              // Close if()
else  {
  Dlartg.dlartg(-vb21,vb22,csq,snq,r);
}              //  Close else.
// *
csu.val = snl.val;
snu.val = csl.val;
csv.val = snr.val;
snv.val = csr.val;
// *
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *        Input matrices A and B are lower triangular matrices
// *
// *        Form matrix C = A*adj(B) = ( a 0 )
// *                                   ( c d )
// *
a = a1*b3;
d = a3*b1;
c = a2*b3-a3*b2;
// *
// *        The SVD of real 2-by-2 triangular C
// *
// *         ( CSL -SNL )*( A 0 )*(  CSR  SNR ) = ( R 0 )
// *         ( SNL  CSL ) ( C D ) ( -SNR  CSR )   ( 0 T )
// *
Dlasv2.dlasv2(a,c,d,s1,s2,snr,csr,snl,csl);
// *
if (Math.abs(csr.val) >= Math.abs(snr.val) || Math.abs(csl.val) >= Math.abs(snl.val))  {
    // *
// *           Compute the (2,1) and (2,2) elements of U'*A and V'*B,
// *           and (2,1) element of |U|'*|A| and |V|'*|B|.
// *
ua21 = -snr.val*a1+csr.val*a2;
ua22r = csr.val*a3;
// *
vb21 = -snl.val*b1+csl.val*b2;
vb22r = csl.val*b3;
// *
aua21 = Math.abs(snr.val)*Math.abs(a1)+Math.abs(csr.val)*Math.abs(a2);
avb21 = Math.abs(snl.val)*Math.abs(b1)+Math.abs(csl.val)*Math.abs(b2);
// *
// *           zero (2,1) elements of U'*A and V'*B.
// *
if ((Math.abs(ua21)+Math.abs(ua22r)) != zero)  {
    if (aua21/(Math.abs(ua21)+Math.abs(ua22r)) <= avb21/(Math.abs(vb21)+Math.abs(vb22r)))  {
    Dlartg.dlartg(ua22r,ua21,csq,snq,r);
}              // Close if()
else  {
  Dlartg.dlartg(vb22r,vb21,csq,snq,r);
}              //  Close else.
}              // Close if()
else  {
  Dlartg.dlartg(vb22r,vb21,csq,snq,r);
}              //  Close else.
// *
csu.val = csr.val;
snu.val = -snr.val;
csv.val = csl.val;
snv.val = -snl.val;
// *
}              // Close if()
else  {
  // *
// *           Compute the (1,1) and (1,2) elements of U'*A and V'*B,
// *           and (1,1) element of |U|'*|A| and |V|'*|B|.
// *
ua11 = csr.val*a1+snr.val*a2;
ua12 = snr.val*a3;
// *
vb11 = csl.val*b1+snl.val*b2;
vb12 = snl.val*b3;
// *
aua11 = Math.abs(csr.val)*Math.abs(a1)+Math.abs(snr.val)*Math.abs(a2);
avb11 = Math.abs(csl.val)*Math.abs(b1)+Math.abs(snl.val)*Math.abs(b2);
// *
// *           zero (1,1) elements of U'*A and V'*B, and then swap.
// *
if ((Math.abs(ua11)+Math.abs(ua12)) != zero)  {
    if (aua11/(Math.abs(ua11)+Math.abs(ua12)) <= avb11/(Math.abs(vb11)+Math.abs(vb12)))  {
    Dlartg.dlartg(ua12,ua11,csq,snq,r);
}              // Close if()
else  {
  Dlartg.dlartg(vb12,vb11,csq,snq,r);
}              //  Close else.
}              // Close if()
else  {
  Dlartg.dlartg(vb12,vb11,csq,snq,r);
}              //  Close else.
// *
csu.val = snr.val;
snu.val = csr.val;
csv.val = snl.val;
snv.val = csl.val;
// *
}              //  Close else.
// *
}              //  Close else.
// *
Dummy.go_to("Dlags2",999999);
// *
// *     End of DLAGS2
// *
Dummy.label("Dlags2",999999);
return;
   }
} // End class.
