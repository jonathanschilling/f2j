/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlagtf {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGTF factorizes the matrix (T - lambda*I), where T is an n by n
// *  tridiagonal matrix and lambda is a scalar, as
// *
// *     T - lambda*I = PLU,
// *
// *  where P is a permutation matrix, L is a unit lower tridiagonal matrix
// *  with at most one non-zero sub-diagonal elements per column and U is
// *  an upper triangular matrix with at most two non-zero super-diagonal
// *  elements per column.
// *
// *  The factorization is obtained by Gaussian elimination with partial
// *  pivoting and implicit row scaling.
// *
// *  The parameter LAMBDA is included in the routine so that DLAGTF may
// *  be used, in conjunction with DLAGTS, to obtain eigenvectors of T by
// *  inverse iteration.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix T.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, A must contain the diagonal elements of T.
// *
// *          On exit, A is overwritten by the n diagonal elements of the
// *          upper triangular matrix U of the factorization of T.
// *
// *  LAMBDA  (input) DOUBLE PRECISION
// *          On entry, the scalar lambda.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, B must contain the (n-1) super-diagonal elements of
// *          T.
// *
// *          On exit, B is overwritten by the (n-1) super-diagonal
// *          elements of the matrix U of the factorization of T.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, C must contain the (n-1) sub-diagonal elements of
// *          T.
// *
// *          On exit, C is overwritten by the (n-1) sub-diagonal elements
// *          of the matrix L of the factorization of T.
// *
// *  TOL     (input) DOUBLE PRECISION
// *          On entry, a relative tolerance used to indicate whether or
// *          not the matrix (T - lambda*I) is nearly singular. TOL should
// *          normally be chose as approximately the largest relative error
// *          in the elements of T. For example, if the elements of T are
// *          correct to about 4 significant figures, then TOL should be
// *          set to about 5*10**(-4). If TOL is supplied as less than eps,
// *          where eps is the relative machine precision, then the value
// *          eps is used in place of TOL.
// *
// *  D       (output) DOUBLE PRECISION array, dimension (N-2)
// *          On exit, D is overwritten by the (n-2) second super-diagonal
// *          elements of the matrix U of the factorization of T.
// *
// *  IN      (output) INTEGER array, dimension (N)
// *          On exit, IN contains details of the permutation matrix P. If
// *          an interchange occurred at the kth step of the elimination,
// *          then IN(k) = 1, otherwise IN(k) = 0. The element IN(n)
// *          returns the smallest positive integer j such that
// *
// *             abs( u(j,j) ).le. norm( (T - lambda*I)(j) )*TOL,
// *
// *          where norm( A(j) ) denotes the sum of the absolute values of
// *          the jth row of the matrix A. If no such j exists then IN(n)
// *          is returned as zero. If IN(n) is returned as positive, then a
// *          diagonal element of U is small, indicating that
// *          (T - lambda*I) is singular or nearly singular,
// *
// *  INFO    (output)
// *          = 0   : successful exit
// *          .lt. 0: if INFO = -k, the kth argument had an illegal value
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int k= 0;
static double eps= 0.0;
static double mult= 0.0;
static double piv1= 0.0;
static double piv2= 0.0;
static double scale1= 0.0;
static double scale2= 0.0;
static double temp= 0.0;
static double tl= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlagtf (int n,
double [] a, int _a_offset,
double lambda,
double [] b, int _b_offset,
double [] c, int _c_offset,
double tol,
double [] d, int _d_offset,
int [] in, int _in_offset,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
Xerbla.xerbla("DLAGTF",-info.val);
Dummy.go_to("Dlagtf",999999);
}              // Close if()
// *
if (n == 0)  
    Dummy.go_to("Dlagtf",999999);
// *
a[(1)- 1+ _a_offset] = a[(1)- 1+ _a_offset]-lambda;
in[(n)- 1+ _in_offset] = 0;
if (n == 1)  {
    if (a[(1)- 1+ _a_offset] == zero)  
    in[(1)- 1+ _in_offset] = 1;
Dummy.go_to("Dlagtf",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
// *
tl = Math.max(tol, eps) ;
scale1 = Math.abs(a[(1)- 1+ _a_offset])+Math.abs(b[(1)- 1+ _b_offset]);
{
forloop10:
for (k = 1; k <= n-1; k++) {
a[(k+1)- 1+ _a_offset] = a[(k+1)- 1+ _a_offset]-lambda;
scale2 = Math.abs(c[(k)- 1+ _c_offset])+Math.abs(a[(k+1)- 1+ _a_offset]);
if (k < (n-1))  
    scale2 = scale2+Math.abs(b[(k+1)- 1+ _b_offset]);
if (a[(k)- 1+ _a_offset] == zero)  {
    piv1 = zero;
}              // Close if()
else  {
  piv1 = Math.abs(a[(k)- 1+ _a_offset])/scale1;
}              //  Close else.
if (c[(k)- 1+ _c_offset] == zero)  {
    in[(k)- 1+ _in_offset] = 0;
piv2 = zero;
scale1 = scale2;
if (k < (n-1))  
    d[(k)- 1+ _d_offset] = zero;
}              // Close if()
else  {
  piv2 = Math.abs(c[(k)- 1+ _c_offset])/scale2;
if (piv2 <= piv1)  {
    in[(k)- 1+ _in_offset] = 0;
scale1 = scale2;
c[(k)- 1+ _c_offset] = c[(k)- 1+ _c_offset]/a[(k)- 1+ _a_offset];
a[(k+1)- 1+ _a_offset] = a[(k+1)- 1+ _a_offset]-c[(k)- 1+ _c_offset]*b[(k)- 1+ _b_offset];
if (k < (n-1))  
    d[(k)- 1+ _d_offset] = zero;
}              // Close if()
else  {
  in[(k)- 1+ _in_offset] = 1;
mult = a[(k)- 1+ _a_offset]/c[(k)- 1+ _c_offset];
a[(k)- 1+ _a_offset] = c[(k)- 1+ _c_offset];
temp = a[(k+1)- 1+ _a_offset];
a[(k+1)- 1+ _a_offset] = b[(k)- 1+ _b_offset]-mult*temp;
if (k < (n-1))  {
    d[(k)- 1+ _d_offset] = b[(k+1)- 1+ _b_offset];
b[(k+1)- 1+ _b_offset] = -mult*d[(k)- 1+ _d_offset];
}              // Close if()
b[(k)- 1+ _b_offset] = temp;
c[(k)- 1+ _c_offset] = mult;
}              //  Close else.
}              //  Close else.
if ((Math.max(piv1, piv2)  <= tl) && (in[(n)- 1+ _in_offset] == 0))  
    in[(n)- 1+ _in_offset] = k;
Dummy.label("Dlagtf",10);
}              //  Close for() loop. 
}
if ((Math.abs(a[(n)- 1+ _a_offset]) <= scale1*tl) && (in[(n)- 1+ _in_offset] == 0))  
    in[(n)- 1+ _in_offset] = n;
// *
Dummy.go_to("Dlagtf",999999);
// *
// *     End of DLAGTF
// *
Dummy.label("Dlagtf",999999);
return;
   }
} // End class.
