/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlagtm {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGTM performs a matrix-vector product of the form
// *
// *     B := alpha * A * X + beta * B
// *
// *  where A is a tridiagonal matrix of order N, B and X are N by NRHS
// *  matrices, and alpha and beta are real scalars, each of which may be
// *  0., 1., or -1.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER
// *          Specifies the operation applied to A.
// *          = 'N':  No transpose, B := alpha * A * X + beta * B
// *          = 'T':  Transpose,    B := alpha * A'* X + beta * B
// *          = 'C':  Conjugate transpose = Transpose
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices X and B.
// *
// *  ALPHA   (input) DOUBLE PRECISION
// *          The scalar alpha.  ALPHA must be 0., 1., or -1.; otherwise,
// *          it is assumed to be 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) sub-diagonal elements of T.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal elements of T.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) super-diagonal elements of T.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The N by NRHS matrix X.
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(N,1).
// *
// *  BETA    (input) DOUBLE PRECISION
// *          The scalar beta.  BETA must be 0., 1., or -1.; otherwise,
// *          it is assumed to be 1.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the N by NRHS matrix B.
// *          On exit, B is overwritten by the matrix expression
// *          B := alpha * A * X + beta * B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(N,1).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlagtm (String trans,
int n,
int nrhs,
double alpha,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] x, int _x_offset,
int ldx,
double beta,
double [] b, int _b_offset,
int ldb)  {

if (n == 0)  
    Dummy.go_to("Dlagtm",999999);
// *
// *     Multiply B by BETA if BETA.NE.1.
// *
if (beta == zero)  {
    {
forloop20:
for (j = 1; j <= nrhs; j++) {
{
forloop10:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlagtm",10);
}              //  Close for() loop. 
}
Dummy.label("Dlagtm",20);
}              //  Close for() loop. 
}
}              // Close if()
else if (beta == -one)  {
    {
forloop40:
for (j = 1; j <= nrhs; j++) {
{
forloop30:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = -b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlagtm",30);
}              //  Close for() loop. 
}
Dummy.label("Dlagtm",40);
}              //  Close for() loop. 
}
}              // Close else if()
// *
if (alpha == one)  {
    if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    // *
// *           Compute B := B + A*X
// *
{
forloop60:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]+du[(1)- 1+ _du_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]+dl[(n-1)- 1+ _dl_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]+d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop50:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]+dl[(i-1)- 1+ _dl_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]+d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]+du[(i)- 1+ _du_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlagtm",50);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlagtm",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Compute B := B + A'*X
// *
{
forloop80:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]+dl[(1)- 1+ _dl_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]+du[(n-1)- 1+ _du_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]+d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop70:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]+du[(i-1)- 1+ _du_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]+d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]+dl[(i)- 1+ _dl_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlagtm",70);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlagtm",80);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else if (alpha == -one)  {
    if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    // *
// *           Compute B := B - A*X
// *
{
forloop100:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]-du[(1)- 1+ _du_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]-dl[(n-1)- 1+ _dl_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]-d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop90:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-dl[(i-1)- 1+ _dl_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]-d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]-du[(i)- 1+ _du_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlagtm",90);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlagtm",100);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Compute B := B - A'*X
// *
{
forloop120:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]-dl[(1)- 1+ _dl_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]-du[(n-1)- 1+ _du_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]-d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop110:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-du[(i-1)- 1+ _du_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]-d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]-dl[(i)- 1+ _dl_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlagtm",110);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlagtm",120);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
Dummy.go_to("Dlagtm",999999);
// *
// *     End of DLAGTM
// *
Dummy.label("Dlagtm",999999);
return;
   }
} // End class.
