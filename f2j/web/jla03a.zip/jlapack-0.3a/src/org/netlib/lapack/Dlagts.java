/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlagts {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGTS may be used to solve one of the systems of equations
// *
// *     (T - lambda*I)*x = y   or   (T - lambda*I)'*x = y,
// *
// *  where T is an n by n tridiagonal matrix, for x, following the
// *  factorization of (T - lambda*I) as
// *
// *     (T - lambda*I) = P*L*U ,
// *
// *  by routine DLAGTF. The choice of equation to be solved is
// *  controlled by the argument JOB, and in each case there is an option
// *  to perturb zero or very small diagonal elements of U, this option
// *  being intended for use in applications such as inverse iteration.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) INTEGER
// *          Specifies the job to be performed by DLAGTS as follows:
// *          =  1: The equations  (T - lambda*I)x = y  are to be solved,
// *                but diagonal elements of U are not to be perturbed.
// *          = -1: The equations  (T - lambda*I)x = y  are to be solved
// *                and, if overflow would otherwise occur, the diagonal
// *                elements of U are to be perturbed. See argument TOL
// *                below.
// *          =  2: The equations  (T - lambda*I)'x = y  are to be solved,
// *                but diagonal elements of U are not to be perturbed.
// *          = -2: The equations  (T - lambda*I)'x = y  are to be solved
// *                and, if overflow would otherwise occur, the diagonal
// *                elements of U are to be perturbed. See argument TOL
// *                below.
// *
// *  N       (input) INTEGER
// *          The order of the matrix T.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N)
// *          On entry, A must contain the diagonal elements of U as
// *          returned from DLAGTF.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, B must contain the first super-diagonal elements of
// *          U as returned from DLAGTF.
// *
// *  C       (input) DOUBLE PRECISION array, dimension (N-1)
// *          On entry, C must contain the sub-diagonal elements of L as
// *          returned from DLAGTF.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N-2)
// *          On entry, D must contain the second super-diagonal elements
// *          of U as returned from DLAGTF.
// *
// *  IN      (input) INTEGER array, dimension (N)
// *          On entry, IN must contain details of the matrix P as returned
// *          from DLAGTF.
// *
// *  Y       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, the right hand side vector y.
// *          On exit, Y is overwritten by the solution vector x.
// *
// *  TOL     (input/output) DOUBLE PRECISION
// *          On entry, with  JOB .lt. 0, TOL should be the minimum
// *          perturbation to be made to very small diagonal elements of U.
// *          TOL should normally be chosen as about eps*norm(U), where eps
// *          is the relative machine precision, but if TOL is supplied as
// *          non-positive, then it is reset to eps*max( abs( u(i,j) ) ).
// *          If  JOB .gt. 0  then TOL is not referenced.
// *
// *          On exit, TOL is changed as described above, only if TOL is
// *          non-positive on entry. Otherwise TOL is unchanged.
// *
// *  INFO    (output) INTEGER
// *          = 0   : successful exit
// *          .lt. 0: if INFO = -i, the i-th argument had an illegal value
// *          .gt. 0: overflow would occur when computing the INFO(th)
// *                  element of the solution vector x. This can only occur
// *                  when JOB is supplied as positive and either means
// *                  that a diagonal element of U is very small, or that
// *                  the elements of the right-hand side vector y are very
// *                  large.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int k= 0;
static double absak= 0.0;
static double ak= 0.0;
static double bignum= 0.0;
static double eps= 0.0;
static double pert= 0.0;
static double sfmin= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlagts (int job,
int n,
double [] a, int _a_offset,
double [] b, int _b_offset,
double [] c, int _c_offset,
double [] d, int _d_offset,
int [] in, int _in_offset,
double [] y, int _y_offset,
doubleW tol,
intW info)  {

info.val = 0;
if ((Math.abs(job) > 2) || (job == 0))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAGTS",-info.val);
Dummy.go_to("Dlagts",999999);
}              // Close if()
// *
if (n == 0)  
    Dummy.go_to("Dlagts",999999);
// *
eps = Dlamch.dlamch("Epsilon");
sfmin = Dlamch.dlamch("Safe minimum");
bignum = one/sfmin;
// *
if (job < 0)  {
    if (tol.val <= zero)  {
    tol.val = Math.abs(a[(1)- 1+ _a_offset]);
if (n > 1)  
    tol.val = Math.max((tol.val) > (Math.abs(a[(2)- 1+ _a_offset])) ? (tol.val) : (Math.abs(a[(2)- 1+ _a_offset])), Math.abs(b[(1)- 1+ _b_offset]));
{
forloop10:
for (k = 3; k <= n; k++) {
tol.val = Math.max(Math.max(Math.max(tol.val, Math.abs(a[(k)- 1+ _a_offset])), Math.abs(b[(k-1)- 1+ _b_offset])), Math.abs(d[(k-2)- 1+ _d_offset])) ;
Dummy.label("Dlagts",10);
}              //  Close for() loop. 
}
tol.val = tol.val*eps;
if (tol.val == zero)  
    tol.val = eps;
}              // Close if()
}              // Close if()
// *
if (Math.abs(job) == 1)  {
    {
forloop20:
for (k = 2; k <= n; k++) {
if (in[(k-1)- 1+ _in_offset] == 0)  {
    y[(k)- 1+ _y_offset] = y[(k)- 1+ _y_offset]-c[(k-1)- 1+ _c_offset]*y[(k-1)- 1+ _y_offset];
}              // Close if()
else  {
  temp = y[(k-1)- 1+ _y_offset];
y[(k-1)- 1+ _y_offset] = y[(k)- 1+ _y_offset];
y[(k)- 1+ _y_offset] = temp-c[(k-1)- 1+ _c_offset]*y[(k)- 1+ _y_offset];
}              //  Close else.
Dummy.label("Dlagts",20);
}              //  Close for() loop. 
}
if (job == 1)  {
    {
int _k_inc = -1;
forloop30:
for (k = n; k >= 1; k += _k_inc) {
if (k <= n-2)  {
    temp = y[(k)- 1+ _y_offset]-b[(k)- 1+ _b_offset]*y[(k+1)- 1+ _y_offset]-d[(k)- 1+ _d_offset]*y[(k+2)- 1+ _y_offset];
}              // Close if()
else if (k == n-1)  {
    temp = y[(k)- 1+ _y_offset]-b[(k)- 1+ _b_offset]*y[(k+1)- 1+ _y_offset];
}              // Close else if()
else  {
  temp = y[(k)- 1+ _y_offset];
}              //  Close else.
ak = a[(k)- 1+ _a_offset];
absak = Math.abs(ak);
if (absak < one)  {
    if (absak < sfmin)  {
    if (absak == zero || Math.abs(temp)*sfmin > absak)  {
    info.val = k;
Dummy.go_to("Dlagts",999999);
}              // Close if()
else  {
  temp = temp*bignum;
ak = ak*bignum;
}              //  Close else.
}              // Close if()
else if (Math.abs(temp) > absak*bignum)  {
    info.val = k;
Dummy.go_to("Dlagts",999999);
}              // Close else if()
}              // Close if()
y[(k)- 1+ _y_offset] = temp/ak;
Dummy.label("Dlagts",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
int _k_inc = -1;
forloop50:
for (k = n; k >= 1; k += _k_inc) {
if (k <= n-2)  {
    temp = y[(k)- 1+ _y_offset]-b[(k)- 1+ _b_offset]*y[(k+1)- 1+ _y_offset]-d[(k)- 1+ _d_offset]*y[(k+2)- 1+ _y_offset];
}              // Close if()
else if (k == n-1)  {
    temp = y[(k)- 1+ _y_offset]-b[(k)- 1+ _b_offset]*y[(k+1)- 1+ _y_offset];
}              // Close else if()
else  {
  temp = y[(k)- 1+ _y_offset];
}              //  Close else.
ak = a[(k)- 1+ _a_offset];
pert = ((ak) >= 0 ? Math.abs(tol.val) : -Math.abs(tol.val));
label40:
   Dummy.label("Dlagts",40);
absak = Math.abs(ak);
if (absak < one)  {
    if (absak < sfmin)  {
    if (absak == zero || Math.abs(temp)*sfmin > absak)  {
    ak = ak+pert;
pert = 2*pert;
Dummy.go_to("Dlagts",40);
}              // Close if()
else  {
  temp = temp*bignum;
ak = ak*bignum;
}              //  Close else.
}              // Close if()
else if (Math.abs(temp) > absak*bignum)  {
    ak = ak+pert;
pert = 2*pert;
Dummy.go_to("Dlagts",40);
}              // Close else if()
}              // Close if()
y[(k)- 1+ _y_offset] = temp/ak;
Dummy.label("Dlagts",50);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  // *
// *        Come to here if  JOB = 2 or -2
// *
if (job == 2)  {
    {
forloop60:
for (k = 1; k <= n; k++) {
if (k >= 3)  {
    temp = y[(k)- 1+ _y_offset]-b[(k-1)- 1+ _b_offset]*y[(k-1)- 1+ _y_offset]-d[(k-2)- 1+ _d_offset]*y[(k-2)- 1+ _y_offset];
}              // Close if()
else if (k == 2)  {
    temp = y[(k)- 1+ _y_offset]-b[(k-1)- 1+ _b_offset]*y[(k-1)- 1+ _y_offset];
}              // Close else if()
else  {
  temp = y[(k)- 1+ _y_offset];
}              //  Close else.
ak = a[(k)- 1+ _a_offset];
absak = Math.abs(ak);
if (absak < one)  {
    if (absak < sfmin)  {
    if (absak == zero || Math.abs(temp)*sfmin > absak)  {
    info.val = k;
Dummy.go_to("Dlagts",999999);
}              // Close if()
else  {
  temp = temp*bignum;
ak = ak*bignum;
}              //  Close else.
}              // Close if()
else if (Math.abs(temp) > absak*bignum)  {
    info.val = k;
Dummy.go_to("Dlagts",999999);
}              // Close else if()
}              // Close if()
y[(k)- 1+ _y_offset] = temp/ak;
Dummy.label("Dlagts",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (k = 1; k <= n; k++) {
if (k >= 3)  {
    temp = y[(k)- 1+ _y_offset]-b[(k-1)- 1+ _b_offset]*y[(k-1)- 1+ _y_offset]-d[(k-2)- 1+ _d_offset]*y[(k-2)- 1+ _y_offset];
}              // Close if()
else if (k == 2)  {
    temp = y[(k)- 1+ _y_offset]-b[(k-1)- 1+ _b_offset]*y[(k-1)- 1+ _y_offset];
}              // Close else if()
else  {
  temp = y[(k)- 1+ _y_offset];
}              //  Close else.
ak = a[(k)- 1+ _a_offset];
pert = ((ak) >= 0 ? Math.abs(tol.val) : -Math.abs(tol.val));
label70:
   Dummy.label("Dlagts",70);
absak = Math.abs(ak);
if (absak < one)  {
    if (absak < sfmin)  {
    if (absak == zero || Math.abs(temp)*sfmin > absak)  {
    ak = ak+pert;
pert = 2*pert;
Dummy.go_to("Dlagts",70);
}              // Close if()
else  {
  temp = temp*bignum;
ak = ak*bignum;
}              //  Close else.
}              // Close if()
else if (Math.abs(temp) > absak*bignum)  {
    ak = ak+pert;
pert = 2*pert;
Dummy.go_to("Dlagts",70);
}              // Close else if()
}              // Close if()
y[(k)- 1+ _y_offset] = temp/ak;
Dummy.label("Dlagts",80);
}              //  Close for() loop. 
}
}              //  Close else.
// *
{
int _k_inc = -1;
forloop90:
for (k = n; k >= 2; k += _k_inc) {
if (in[(k-1)- 1+ _in_offset] == 0)  {
    y[(k-1)- 1+ _y_offset] = y[(k-1)- 1+ _y_offset]-c[(k-1)- 1+ _c_offset]*y[(k)- 1+ _y_offset];
}              // Close if()
else  {
  temp = y[(k-1)- 1+ _y_offset];
y[(k-1)- 1+ _y_offset] = y[(k)- 1+ _y_offset];
y[(k)- 1+ _y_offset] = temp-c[(k-1)- 1+ _c_offset]*y[(k)- 1+ _y_offset];
}              //  Close else.
Dummy.label("Dlagts",90);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     End of DLAGTS
// *
Dummy.label("Dlagts",999999);
return;
   }
} // End class.
