/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlahqr {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAHQR is an auxiliary routine called by DHSEQR to update the
// *  eigenvalues and Schur decomposition already computed by DHSEQR, by
// *  dealing with the Hessenberg submatrix in rows and columns ILO to IHI.
// *
// *  Arguments
// *  =========
// *
// *  WANTT   (input) LOGICAL
// *          = .TRUE. : the full Schur form T is required;
// *          = .FALSE.: only eigenvalues are required.
// *
// *  WANTZ   (input) LOGICAL
// *          = .TRUE. : the matrix of Schur vectors Z is required;
// *          = .FALSE.: Schur vectors are not required.
// *
// *  N       (input) INTEGER
// *          The order of the matrix H.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          It is assumed that H is already upper quasi-triangular in
// *          rows and columns IHI+1:N, and that H(ILO,ILO-1) = 0 (unless
// *          ILO = 1). DLAHQR works primarily with the Hessenberg
// *          submatrix in rows and columns ILO to IHI, but applies
// *          transformations to all of H if WANTT is .TRUE..
// *          1 <= ILO <= max(1,IHI); IHI <= N.
// *
// *  H       (input/output) DOUBLE PRECISION array, dimension (LDH,N)
// *          On entry, the upper Hessenberg matrix H.
// *          On exit, if WANTT is .TRUE., H is upper quasi-triangular in
// *          rows and columns ILO:IHI, with any 2-by-2 diagonal blocks in
// *          standard form. If WANTT is .FALSE., the contents of H are
// *          unspecified on exit.
// *
// *  LDH     (input) INTEGER
// *          The leading dimension of the array H. LDH >= max(1,N).
// *
// *  WR      (output) DOUBLE PRECISION array, dimension (N)
// *  WI      (output) DOUBLE PRECISION array, dimension (N)
// *          The real and imaginary parts, respectively, of the computed
// *          eigenvalues ILO to IHI are stored in the corresponding
// *          elements of WR and WI. If two eigenvalues are computed as a
// *          complex conjugate pair, they are stored in consecutive
// *          elements of WR and WI, say the i-th and (i+1)th, with
// *          WI(i) > 0 and WI(i+1) < 0. If WANTT is .TRUE., the
// *          eigenvalues are stored in the same order as on the diagonal
// *          of the Schur form returned in H, with WR(i) = H(i,i), and, if
// *          H(i:i+1,i:i+1) is a 2-by-2 diagonal block,
// *          WI(i) = sqrt(H(i+1,i)*H(i,i+1)) and WI(i+1) = -WI(i).
// *
// *  ILOZ    (input) INTEGER
// *  IHIZ    (input) INTEGER
// *          Specify the rows of Z to which transformations must be
// *          applied if WANTZ is .TRUE..
// *          1 <= ILOZ <= ILO; IHI <= IHIZ <= N.
// *
// *  Z       (input/output) DOUBLE PRECISION array, dimension (LDZ,N)
// *          If WANTZ is .TRUE., on entry Z must contain the current
// *          matrix Z of transformations accumulated by DHSEQR, and on
// *          exit Z has been updated; transformations are applied only to
// *          the submatrix Z(ILOZ:IHIZ,ILO:IHI).
// *          If WANTZ is .FALSE., Z is not referenced.
// *
// *  LDZ     (input) INTEGER
// *          The leading dimension of the array Z. LDZ >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          > 0: DLAHQR failed to compute all the eigenvalues ILO to IHI
// *               in a total of 30*(IHI-ILO+1) iterations; if INFO = i,
// *               elements i+1:ihi of WR and WI contain those eigenvalues
// *               which have been successfully computed.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double dat1= 0.75e+0;
static double dat2= -0.4375e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int i1= 0;
static int i2= 0;
static int itn= 0;
static int its= 0;
static int j= 0;
static int k= 0;
static int l= 0;
static int m= 0;
static int nh= 0;
static int nr= 0;
static int nz= 0;
static doubleW cs= new doubleW(0.0);
static double h00= 0.0;
static double h10= 0.0;
static double h11= 0.0;
static double h12= 0.0;
static double h21= 0.0;
static double h22= 0.0;
static double h33= 0.0;
static double h33s= 0.0;
static double h43h34= 0.0;
static double h44= 0.0;
static double h44s= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double s= 0.0;
static double smlnum= 0.0;
static doubleW sn= new doubleW(0.0);
static double sum= 0.0;
static doubleW t1= new doubleW(0.0);
static double t2= 0.0;
static double t3= 0.0;
static double tst1= 0.0;
static double ulp= 0.0;
static doubleW unfl= new doubleW(0.0);
static double v1= 0.0;
static double v2= 0.0;
static double v3= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] v= new double[(3)];
static double [] work= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlahqr (boolean wantt,
boolean wantz,
int n,
int ilo,
int ihi,
double [] h, int _h_offset,
int ldh,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
int iloz,
int ihiz,
double [] z, int _z_offset,
int ldz,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlahqr",999999);
if (ilo == ihi)  {
    wr[(ilo)- 1+ _wr_offset] = h[(ilo)- 1+(ilo- 1)*ldh+ _h_offset];
wi[(ilo)- 1+ _wi_offset] = zero;
Dummy.go_to("Dlahqr",999999);
}              // Close if()
// *
nh = ihi-ilo+1;
nz = ihiz-iloz+1;
// *
// *     Set machine-dependent constants for the stopping criterion.
// *     If norm(H) <= sqrt(OVFL), overflow should not occur.
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = one/unfl.val;
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Precision");
smlnum = unfl.val*(nh/ulp);
// *
// *     I1 and I2 are the indices of the first row and last column of H
// *     to which transformations must be applied. If eigenvalues only are
// *     being computed, I1 and I2 are set inside the main loop.
// *
if (wantt)  {
    i1 = 1;
i2 = n;
}              // Close if()
// *
// *     ITN is the total number of QR iterations allowed.
// *
itn = 30*nh;
// *
// *     The main loop begins here. I is the loop index and decreases from
// *     IHI to ILO in steps of 1 or 2. Each iteration of the loop works
// *     with the active submatrix in rows and columns L to I.
// *     Eigenvalues I+1 to IHI have already converged. Either L = ILO or
// *     H(L,L-1) is negligible so that the matrix splits.
// *
i = ihi;
label10:
   Dummy.label("Dlahqr",10);
l = ilo;
if (i < ilo)  
    Dummy.go_to("Dlahqr",150);
// *
// *     Perform QR iterations on rows and columns ILO to I until a
// *     submatrix of order 1 or 2 splits off at the bottom because a
// *     subdiagonal element has become negligible.
// *
{
forloop130:
for (its = 0; its <= itn; its++) {
// *
// *        Look for a single small subdiagonal element.
// *
{
int _k_inc = -1;
forloop20:
for (k = i; k >= l+1; k += _k_inc) {
tst1 = Math.abs(h[(k-1)- 1+(k-1- 1)*ldh+ _h_offset])+Math.abs(h[(k)- 1+(k- 1)*ldh+ _h_offset]);
if (tst1 == zero)  
    tst1 = Dlanhs.dlanhs("1",i-l+1,h,(l)- 1+(l- 1)*ldh+ _h_offset,ldh,work,0);
if (Math.abs(h[(k)- 1+(k-1- 1)*ldh+ _h_offset]) <= Math.max(ulp*tst1, smlnum) )  
    Dummy.go_to("Dlahqr",30);
Dummy.label("Dlahqr",20);
}              //  Close for() loop. 
}
label30:
   Dummy.label("Dlahqr",30);
l = k;
if (l > ilo)  {
    // *
// *           H(L,L-1) is negligible
// *
h[(l)- 1+(l-1- 1)*ldh+ _h_offset] = zero;
}              // Close if()
// *
// *        Exit from loop if a submatrix of order 1 or 2 has split off.
// *
if (l >= i-1)  
    Dummy.go_to("Dlahqr",140);
// *
// *        Now the active submatrix is in rows and columns L to I. If
// *        eigenvalues only are being computed, only the active submatrix
// *        need be transformed.
// *
if (!wantt)  {
    i1 = l;
i2 = i;
}              // Close if()
// *
if (its == 10 || its == 20)  {
    // *
// *           Exceptional shift.
// *
s = Math.abs(h[(i)- 1+(i-1- 1)*ldh+ _h_offset])+Math.abs(h[(i-1)- 1+(i-2- 1)*ldh+ _h_offset]);
h44 = dat1*s;
h33 = h44;
h43h34 = dat2*s*s;
}              // Close if()
else  {
  // *
// *           Prepare to use Wilkinson's double shift
// *
h44 = h[(i)- 1+(i- 1)*ldh+ _h_offset];
h33 = h[(i-1)- 1+(i-1- 1)*ldh+ _h_offset];
h43h34 = h[(i)- 1+(i-1- 1)*ldh+ _h_offset]*h[(i-1)- 1+(i- 1)*ldh+ _h_offset];
}              //  Close else.
// *
// *        Look for two consecutive small subdiagonal elements.
// *
{
int _m_inc = -1;
forloop40:
for (m = i-2; m >= l; m += _m_inc) {
// *
// *           Determine the effect of starting the double-shift QR
// *           iteration at row M, and see if this would make H(M,M-1)
// *           negligible.
// *
h11 = h[(m)- 1+(m- 1)*ldh+ _h_offset];
h22 = h[(m+1)- 1+(m+1- 1)*ldh+ _h_offset];
h21 = h[(m+1)- 1+(m- 1)*ldh+ _h_offset];
h12 = h[(m)- 1+(m+1- 1)*ldh+ _h_offset];
h44s = h44-h11;
h33s = h33-h11;
v1 = (h33s*h44s-h43h34)/h21+h12;
v2 = h22-h11-h33s-h44s;
v3 = h[(m+2)- 1+(m+1- 1)*ldh+ _h_offset];
s = Math.abs(v1)+Math.abs(v2)+Math.abs(v3);
v1 = v1/s;
v2 = v2/s;
v3 = v3/s;
v[(1)- 1] = v1;
v[(2)- 1] = v2;
v[(3)- 1] = v3;
if (m == l)  
    Dummy.go_to("Dlahqr",50);
h00 = h[(m-1)- 1+(m-1- 1)*ldh+ _h_offset];
h10 = h[(m)- 1+(m-1- 1)*ldh+ _h_offset];
tst1 = Math.abs(v1)*(Math.abs(h00)+Math.abs(h11)+Math.abs(h22));
if (Math.abs(h10)*(Math.abs(v2)+Math.abs(v3)) <= ulp*tst1)  
    Dummy.go_to("Dlahqr",50);
Dummy.label("Dlahqr",40);
}              //  Close for() loop. 
}
label50:
   Dummy.label("Dlahqr",50);
// *
// *        Double-shift QR step
// *
{
forloop120:
for (k = m; k <= i-1; k++) {
// *
// *           The first iteration of this loop determines a reflection G
// *           from the vector V and applies it from left and right to H,
// *           thus creating a nonzero bulge below the subdiagonal.
// *
// *           Each subsequent iteration determines a reflection G to
// *           restore the Hessenberg form in the (K-1)th column, and thus
// *           chases the bulge one step toward the bottom of the active
// *           submatrix. NR is the order of G.
// *
nr = (int)(Math.min(3, i-k+1) );
if (k > m)  
    Dcopy.dcopy(nr,h,(k)- 1+(k-1- 1)*ldh+ _h_offset,1,v,0,1);
dlarfg_adapter(nr,v,(1)- 1,v,(2)- 1,1,t1);
if (k > m)  {
    h[(k)- 1+(k-1- 1)*ldh+ _h_offset] = v[(1)- 1];
h[(k+1)- 1+(k-1- 1)*ldh+ _h_offset] = zero;
if (k < i-1)  
    h[(k+2)- 1+(k-1- 1)*ldh+ _h_offset] = zero;
}              // Close if()
else if (m > l)  {
    h[(k)- 1+(k-1- 1)*ldh+ _h_offset] = -h[(k)- 1+(k-1- 1)*ldh+ _h_offset];
}              // Close else if()
v2 = v[(2)- 1];
t2 = t1.val*v2;
if (nr == 3)  {
    v3 = v[(3)- 1];
t3 = t1.val*v3;
// *
// *              Apply G from the left to transform the rows of the matrix
// *              in columns K to I2.
// *
{
forloop60:
for (j = k; j <= i2; j++) {
sum = h[(k)- 1+(j- 1)*ldh+ _h_offset]+v2*h[(k+1)- 1+(j- 1)*ldh+ _h_offset]+v3*h[(k+2)- 1+(j- 1)*ldh+ _h_offset];
h[(k)- 1+(j- 1)*ldh+ _h_offset] = h[(k)- 1+(j- 1)*ldh+ _h_offset]-sum*t1.val;
h[(k+1)- 1+(j- 1)*ldh+ _h_offset] = h[(k+1)- 1+(j- 1)*ldh+ _h_offset]-sum*t2;
h[(k+2)- 1+(j- 1)*ldh+ _h_offset] = h[(k+2)- 1+(j- 1)*ldh+ _h_offset]-sum*t3;
Dummy.label("Dlahqr",60);
}              //  Close for() loop. 
}
// *
// *              Apply G from the right to transform the columns of the
// *              matrix in rows I1 to min(K+3,I).
// *
{
forloop70:
for (j = i1; j <= Math.min(k+3, i) ; j++) {
sum = h[(j)- 1+(k- 1)*ldh+ _h_offset]+v2*h[(j)- 1+(k+1- 1)*ldh+ _h_offset]+v3*h[(j)- 1+(k+2- 1)*ldh+ _h_offset];
h[(j)- 1+(k- 1)*ldh+ _h_offset] = h[(j)- 1+(k- 1)*ldh+ _h_offset]-sum*t1.val;
h[(j)- 1+(k+1- 1)*ldh+ _h_offset] = h[(j)- 1+(k+1- 1)*ldh+ _h_offset]-sum*t2;
h[(j)- 1+(k+2- 1)*ldh+ _h_offset] = h[(j)- 1+(k+2- 1)*ldh+ _h_offset]-sum*t3;
Dummy.label("Dlahqr",70);
}              //  Close for() loop. 
}
// *
if (wantz)  {
    // *
// *                 Accumulate transformations in the matrix Z
// *
{
forloop80:
for (j = iloz; j <= ihiz; j++) {
sum = z[(j)- 1+(k- 1)*ldz+ _z_offset]+v2*z[(j)- 1+(k+1- 1)*ldz+ _z_offset]+v3*z[(j)- 1+(k+2- 1)*ldz+ _z_offset];
z[(j)- 1+(k- 1)*ldz+ _z_offset] = z[(j)- 1+(k- 1)*ldz+ _z_offset]-sum*t1.val;
z[(j)- 1+(k+1- 1)*ldz+ _z_offset] = z[(j)- 1+(k+1- 1)*ldz+ _z_offset]-sum*t2;
z[(j)- 1+(k+2- 1)*ldz+ _z_offset] = z[(j)- 1+(k+2- 1)*ldz+ _z_offset]-sum*t3;
Dummy.label("Dlahqr",80);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else if (nr == 2)  {
    // *
// *              Apply G from the left to transform the rows of the matrix
// *              in columns K to I2.
// *
{
forloop90:
for (j = k; j <= i2; j++) {
sum = h[(k)- 1+(j- 1)*ldh+ _h_offset]+v2*h[(k+1)- 1+(j- 1)*ldh+ _h_offset];
h[(k)- 1+(j- 1)*ldh+ _h_offset] = h[(k)- 1+(j- 1)*ldh+ _h_offset]-sum*t1.val;
h[(k+1)- 1+(j- 1)*ldh+ _h_offset] = h[(k+1)- 1+(j- 1)*ldh+ _h_offset]-sum*t2;
Dummy.label("Dlahqr",90);
}              //  Close for() loop. 
}
// *
// *              Apply G from the right to transform the columns of the
// *              matrix in rows I1 to min(K+3,I).
// *
{
forloop100:
for (j = i1; j <= i; j++) {
sum = h[(j)- 1+(k- 1)*ldh+ _h_offset]+v2*h[(j)- 1+(k+1- 1)*ldh+ _h_offset];
h[(j)- 1+(k- 1)*ldh+ _h_offset] = h[(j)- 1+(k- 1)*ldh+ _h_offset]-sum*t1.val;
h[(j)- 1+(k+1- 1)*ldh+ _h_offset] = h[(j)- 1+(k+1- 1)*ldh+ _h_offset]-sum*t2;
Dummy.label("Dlahqr",100);
}              //  Close for() loop. 
}
// *
if (wantz)  {
    // *
// *                 Accumulate transformations in the matrix Z
// *
{
forloop110:
for (j = iloz; j <= ihiz; j++) {
sum = z[(j)- 1+(k- 1)*ldz+ _z_offset]+v2*z[(j)- 1+(k+1- 1)*ldz+ _z_offset];
z[(j)- 1+(k- 1)*ldz+ _z_offset] = z[(j)- 1+(k- 1)*ldz+ _z_offset]-sum*t1.val;
z[(j)- 1+(k+1- 1)*ldz+ _z_offset] = z[(j)- 1+(k+1- 1)*ldz+ _z_offset]-sum*t2;
Dummy.label("Dlahqr",110);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close else if()
Dummy.label("Dlahqr",120);
}              //  Close for() loop. 
}
// *
Dummy.label("Dlahqr",130);
}              //  Close for() loop. 
}
// *
// *     Failure to converge in remaining number of iterations
// *
info.val = i;
Dummy.go_to("Dlahqr",999999);
// *
label140:
   Dummy.label("Dlahqr",140);
// *
if (l == i)  {
    // *
// *        H(I,I-1) is negligible: one eigenvalue has converged.
// *
wr[(i)- 1+ _wr_offset] = h[(i)- 1+(i- 1)*ldh+ _h_offset];
wi[(i)- 1+ _wi_offset] = zero;
}              // Close if()
else if (l == i-1)  {
    // *
// *        H(I-1,I-2) is negligible: a pair of eigenvalues have converged.
// *
// *        Transform the 2-by-2 submatrix to standard Schur form,
// *        and compute and store the eigenvalues.
// *
dlanv2_adapter(h,(i-1)- 1+(i-1- 1)*ldh+ _h_offset,h,(i-1)- 1+(i- 1)*ldh+ _h_offset,h,(i)- 1+(i-1- 1)*ldh+ _h_offset,h,(i)- 1+(i- 1)*ldh+ _h_offset,wr,(i-1)- 1+ _wr_offset,wi,(i-1)- 1+ _wi_offset,wr,(i)- 1+ _wr_offset,wi,(i)- 1+ _wi_offset,cs,sn);
// *
if (wantt)  {
    // *
// *           Apply the transformation to the rest of H.
// *
if (i2 > i)  
    Drot.drot(i2-i,h,(i-1)- 1+(i+1- 1)*ldh+ _h_offset,ldh,h,(i)- 1+(i+1- 1)*ldh+ _h_offset,ldh,cs.val,sn.val);
Drot.drot(i-i1-1,h,(i1)- 1+(i-1- 1)*ldh+ _h_offset,1,h,(i1)- 1+(i- 1)*ldh+ _h_offset,1,cs.val,sn.val);
}              // Close if()
if (wantz)  {
    // *
// *           Apply the transformation to Z.
// *
Drot.drot(nz,z,(iloz)- 1+(i-1- 1)*ldz+ _z_offset,1,z,(iloz)- 1+(i- 1)*ldz+ _z_offset,1,cs.val,sn.val);
}              // Close if()
}              // Close else if()
// *
// *     Decrement number of remaining iterations, and return to start of
// *     the main loop with new value of I.
// *
itn = itn-its;
i = l-1;
Dummy.go_to("Dlahqr",10);
// *
label150:
   Dummy.label("Dlahqr",150);
Dummy.go_to("Dlahqr",999999);
// *
// *     End of DLAHQR
// *
Dummy.label("Dlahqr",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,doubleW arg4 )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,arg4);

arg1[arg1_offset] = _f2j_tmp1.val;
}

// adapter for dlanv2
private static void dlanv2_adapter(double [] arg0 , int arg0_offset ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset ,doubleW arg8 ,doubleW arg9 )
{
doubleW _f2j_tmp0 = new doubleW(arg0[arg0_offset]);
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp2 = new doubleW(arg2[arg2_offset]);
doubleW _f2j_tmp3 = new doubleW(arg3[arg3_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);
doubleW _f2j_tmp5 = new doubleW(arg5[arg5_offset]);
doubleW _f2j_tmp6 = new doubleW(arg6[arg6_offset]);
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dlanv2.dlanv2(_f2j_tmp0,_f2j_tmp1,_f2j_tmp2,_f2j_tmp3,_f2j_tmp4,_f2j_tmp5,_f2j_tmp6,_f2j_tmp7,arg8,arg9);

arg0[arg0_offset] = _f2j_tmp0.val;
arg1[arg1_offset] = _f2j_tmp1.val;
arg2[arg2_offset] = _f2j_tmp2.val;
arg3[arg3_offset] = _f2j_tmp3.val;
arg4[arg4_offset] = _f2j_tmp4.val;
arg5[arg5_offset] = _f2j_tmp5.val;
arg6[arg6_offset] = _f2j_tmp6.val;
arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
