/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlahrd {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAHRD reduces the first NB columns of a real general n-by-(n-k+1)
// *  matrix A so that elements below the k-th subdiagonal are zero. The
// *  reduction is performed by an orthogonal similarity transformation
// *  Q' * A * Q. The routine returns the matrices V and T which determine
// *  Q as a block reflector I - V*T*V', and also the matrix Y = A * V * T.
// *
// *  This is an auxiliary routine called by DGEHRD.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.
// *
// *  K       (input) INTEGER
// *          The offset for the reduction. Elements below the k-th
// *          subdiagonal in the first NB columns are reduced to zero.
// *
// *  NB      (input) INTEGER
// *          The number of columns to be reduced.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N-K+1)
// *          On entry, the n-by-(n-k+1) general matrix A.
// *          On exit, the elements on and above the k-th subdiagonal in
// *          the first NB columns are overwritten with the corresponding
// *          elements of the reduced matrix; the elements below the k-th
// *          subdiagonal, with the array TAU, represent the matrix Q as a
// *          product of elementary reflectors. The other columns of A are
// *          unchanged. See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (NB)
// *          The scalar factors of the elementary reflectors. See Further
// *          Details.
// *
// *  T       (output) DOUBLE PRECISION array, dimension (NB,NB)
// *          The upper triangular matrix T.
// *
// *  LDT     (input) INTEGER
// *          The leading dimension of the array T.  LDT >= NB.
// *
// *  Y       (output) DOUBLE PRECISION array, dimension (LDY,NB)
// *          The n-by-nb matrix Y.
// *
// *  LDY     (input) INTEGER
// *          The leading dimension of the array Y. LDY >= N.
// *
// *  Further Details
// *  ===============
// *
// *  The matrix Q is represented as a product of nb elementary reflectors
// *
// *     Q = H(1) H(2) . . . H(nb).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i+k-1) = 0, v(i+k) = 1; v(i+k+1:n) is stored on exit in
// *  A(i+k+1:n,i), and tau in TAU(i).
// *
// *  The elements of the vectors v together form the (n-k+1)-by-nb matrix
// *  V which is needed, with T and Y, to apply the transformation to the
// *  unreduced part of the matrix, using an update of the form:
// *  A := (I - V*T*V') * (A - Y*V').
// *
// *  The contents of A on exit are illustrated by the following example
// *  with n = 7, k = 3 and nb = 2:
// *
// *     ( a   h   a   a   a )
// *     ( a   h   a   a   a )
// *     ( a   h   a   a   a )
// *     ( h   h   a   a   a )
// *     ( v1  h   a   a   a )
// *     ( v1  v2  a   a   a )
// *     ( v1  v2  a   a   a )
// *
// *  where a denotes an element of the original matrix A, h denotes a
// *  modified element of the upper Hessenberg matrix H, and vi denotes an
// *  element of the vector defining H(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double ei= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlahrd (int n,
int k,
int nb,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] t, int _t_offset,
int ldt,
double [] y, int _y_offset,
int ldy)  {

if (n <= 1)  
    Dummy.go_to("Dlahrd",999999);
// *
{
forloop10:
for (i = 1; i <= nb; i++) {
if (i > 1)  {
    // *
// *           Update A(1:n,i)
// *
// *           Compute i-th column of A - Y * V'
// *
Dgemv.dgemv("No transpose",n,i-1,-one,y,_y_offset,ldy,a,(k+i-1)- 1+(1- 1)*lda+ _a_offset,lda,one,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
// *
// *           Apply I - V * T' * V' to this column (call it b) from the
// *           left, using the last column of T as workspace
// *
// *           Let  V = ( V1 )   and   b = ( b1 )   (first I-1 rows)
// *                    ( V2 )             ( b2 )
// *
// *           where V1 is unit lower triangular
// *
// *           w := V1' * b1
// *
Dcopy.dcopy(i-1,a,(k+1)- 1+(i- 1)*lda+ _a_offset,1,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1);
Dtrmv.dtrmv("Lower","Transpose","Unit",i-1,a,(k+1)- 1+(1- 1)*lda+ _a_offset,lda,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1);
// *
// *           w := w + V2'*b2
// *
Dgemv.dgemv("Transpose",n-k-i+1,i-1,one,a,(k+i)- 1+(1- 1)*lda+ _a_offset,lda,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,one,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1);
// *
// *           w := T'*w
// *
Dtrmv.dtrmv("Upper","Transpose","Non-unit",i-1,t,_t_offset,ldt,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1);
// *
// *           b2 := b2 - V2*w
// *
Dgemv.dgemv("No transpose",n-k-i+1,i-1,-one,a,(k+i)- 1+(1- 1)*lda+ _a_offset,lda,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1,one,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1);
// *
// *           b1 := b1 - V1*w
// *
Dtrmv.dtrmv("Lower","No transpose","Unit",i-1,a,(k+1)- 1+(1- 1)*lda+ _a_offset,lda,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1);
Daxpy.daxpy(i-1,-one,t,(1)- 1+(nb- 1)*ldt+ _t_offset,1,a,(k+1)- 1+(i- 1)*lda+ _a_offset,1);
// *
a[(k+i-1)- 1+(i-1- 1)*lda+ _a_offset] = ei;
}              // Close if()
// *
// *        Generate the elementary reflector H(i) to annihilate
// *        A(k+i+1:n,i)
// *
dlarfg_adapter(n-k-i+1,a,(k+i)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(k+i+1, n) )- 1+(i- 1)*lda+ _a_offset),1,tau,(i)- 1+ _tau_offset);
ei = a[(k+i)- 1+(i- 1)*lda+ _a_offset];
a[(k+i)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *        Compute  Y(1:n,i)
// *
Dgemv.dgemv("No transpose",n,n-k-i+1,one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,zero,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dgemv.dgemv("Transpose",n-k-i+1,i-1,one,a,(k+i)- 1+(1- 1)*lda+ _a_offset,lda,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,zero,t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
Dgemv.dgemv("No transpose",n,i-1,-one,y,_y_offset,ldy,t,(1)- 1+(i- 1)*ldt+ _t_offset,1,one,y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
Dscal.dscal(n,tau[(i)- 1+ _tau_offset],y,(1)- 1+(i- 1)*ldy+ _y_offset,1);
// *
// *        Compute T(1:i,i)
// *
Dscal.dscal(i-1,-tau[(i)- 1+ _tau_offset],t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
Dtrmv.dtrmv("Upper","No transpose","Non-unit",i-1,t,_t_offset,ldt,t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
t[(i)- 1+(i- 1)*ldt+ _t_offset] = tau[(i)- 1+ _tau_offset];
// *
Dummy.label("Dlahrd",10);
}              //  Close for() loop. 
}
a[(k+nb)- 1+(nb- 1)*lda+ _a_offset] = ei;
// *
Dummy.go_to("Dlahrd",999999);
// *
// *     End of DLAHRD
// *
Dummy.label("Dlahrd",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
