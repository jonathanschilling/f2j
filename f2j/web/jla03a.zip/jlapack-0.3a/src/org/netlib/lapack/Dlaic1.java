/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaic1 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAIC1 applies one step of incremental condition estimation in
// *  its simplest version:
// *
// *  Let x, twonorm(x) = 1, be an approximate singular vector of an j-by-j
// *  lower triangular matrix L, such that
// *           twonorm(L*x) = sest
// *  Then DLAIC1 computes sestpr, s, c such that
// *  the vector
// *                  [ s*x ]
// *           xhat = [  c  ]
// *  is an approximate singular vector of
// *                  [ L     0  ]
// *           Lhat = [ w' gamma ]
// *  in the sense that
// *           twonorm(Lhat*xhat) = sestpr.
// *
// *  Depending on JOB, an estimate for the largest or smallest singular
// *  value is computed.
// *
// *  Note that [s c]' and sestpr**2 is an eigenpair of the system
// *
// *      diag(sest*sest, 0) + [alpha  gamma] * [ alpha ]
// *                                            [ gamma ]
// *
// *  where  alpha =  x'*w.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) INTEGER
// *          = 1: an estimate for the largest singular value is computed.
// *          = 2: an estimate for the smallest singular value is computed.
// *
// *  J       (input) INTEGER
// *          Length of X and W
// *
// *  X       (input) DOUBLE PRECISION array, dimension (J)
// *          The j-vector x.
// *
// *  SEST    (input) DOUBLE PRECISION
// *          Estimated singular value of j by j matrix L
// *
// *  W       (input) DOUBLE PRECISION array, dimension (J)
// *          The j-vector w.
// *
// *  GAMMA   (input) DOUBLE PRECISION
// *          The diagonal element gamma.
// *
// *  SEDTPR  (output) DOUBLE PRECISION
// *          Estimated singular value of (j+1) by (j+1) matrix Lhat.
// *
// *  S       (output) DOUBLE PRECISION
// *          Sine needed in forming xhat.
// *
// *  C       (output) DOUBLE PRECISION
// *          Cosine needed in forming xhat.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double half= 0.5e0;
static double four= 4.0e0;
// *     ..
// *     .. Local Scalars ..
static double absalp= 0.0;
static double absest= 0.0;
static double absgam= 0.0;
static double alpha= 0.0;
static double b= 0.0;
static double cosine= 0.0;
static double eps= 0.0;
static double norma= 0.0;
static double s1= 0.0;
static double s2= 0.0;
static double sine= 0.0;
static double t= 0.0;
static double test= 0.0;
static double tmp= 0.0;
static double zeta1= 0.0;
static double zeta2= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaic1 (int job,
int j,
double [] x, int _x_offset,
double sest,
double [] w, int _w_offset,
double gamma,
doubleW sestpr,
doubleW s,
doubleW c)  {

eps = Dlamch.dlamch("Epsilon");
alpha = Ddot.ddot(j,x,_x_offset,1,w,_w_offset,1);
// *
absalp = Math.abs(alpha);
absgam = Math.abs(gamma);
absest = Math.abs(sest);
// *
if (job == 1)  {
    // *
// *        Estimating largest singular value
// *
// *        special cases
// *
if (sest == zero)  {
    s1 = Math.max(absgam, absalp) ;
if (s1 == zero)  {
    s.val = zero;
c.val = one;
sestpr.val = zero;
}              // Close if()
else  {
  s.val = alpha/s1;
c.val = gamma/s1;
tmp = Math.sqrt(s.val*s.val+c.val*c.val);
s.val = s.val/tmp;
c.val = c.val/tmp;
sestpr.val = s1*tmp;
}              //  Close else.
Dummy.go_to("Dlaic1",999999);
}              // Close if()
else if (absgam <= eps*absest)  {
    s.val = one;
c.val = zero;
tmp = Math.max(absest, absalp) ;
s1 = absest/tmp;
s2 = absalp/tmp;
sestpr.val = tmp*Math.sqrt(s1*s1+s2*s2);
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else if (absalp <= eps*absest)  {
    s1 = absgam;
s2 = absest;
if (s1 <= s2)  {
    s.val = one;
c.val = zero;
sestpr.val = s2;
}              // Close if()
else  {
  s.val = zero;
c.val = one;
sestpr.val = s1;
}              //  Close else.
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else if (absest <= eps*absalp || absest <= eps*absgam)  {
    s1 = absgam;
s2 = absalp;
if (s1 <= s2)  {
    tmp = s1/s2;
s.val = Math.sqrt(one+tmp*tmp);
sestpr.val = s2*s.val;
c.val = (gamma/s2)/s.val;
s.val = ((alpha) >= 0 ? Math.abs(one) : -Math.abs(one))/s.val;
}              // Close if()
else  {
  tmp = s2/s1;
c.val = Math.sqrt(one+tmp*tmp);
sestpr.val = s1*c.val;
s.val = (alpha/s1)/c.val;
c.val = ((gamma) >= 0 ? Math.abs(one) : -Math.abs(one))/c.val;
}              //  Close else.
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else  {
  // *
// *           normal case
// *
zeta1 = alpha/absest;
zeta2 = gamma/absest;
// *
b = (one-zeta1*zeta1-zeta2*zeta2)*half;
c.val = zeta1*zeta1;
if (b > zero)  {
    t = c.val/(b+Math.sqrt(b*b+c.val));
}              // Close if()
else  {
  t = Math.sqrt(b*b+c.val)-b;
}              //  Close else.
// *
sine = -zeta1/t;
cosine = -zeta2/(one+t);
tmp = Math.sqrt(sine*sine+cosine*cosine);
s.val = sine/tmp;
c.val = cosine/tmp;
sestpr.val = Math.sqrt(t+one)*absest;
Dummy.go_to("Dlaic1",999999);
}              //  Close else.
// *
}              // Close if()
else if (job == 2)  {
    // *
// *        Estimating smallest singular value
// *
// *        special cases
// *
if (sest == zero)  {
    sestpr.val = zero;
if (Math.max(absgam, absalp)  == zero)  {
    sine = one;
cosine = zero;
}              // Close if()
else  {
  sine = -gamma;
cosine = alpha;
}              //  Close else.
s1 = Math.max(Math.abs(sine), Math.abs(cosine)) ;
s.val = sine/s1;
c.val = cosine/s1;
tmp = Math.sqrt(s.val*s.val+c.val*c.val);
s.val = s.val/tmp;
c.val = c.val/tmp;
Dummy.go_to("Dlaic1",999999);
}              // Close if()
else if (absgam <= eps*absest)  {
    s.val = zero;
c.val = one;
sestpr.val = absgam;
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else if (absalp <= eps*absest)  {
    s1 = absgam;
s2 = absest;
if (s1 <= s2)  {
    s.val = zero;
c.val = one;
sestpr.val = s1;
}              // Close if()
else  {
  s.val = one;
c.val = zero;
sestpr.val = s2;
}              //  Close else.
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else if (absest <= eps*absalp || absest <= eps*absgam)  {
    s1 = absgam;
s2 = absalp;
if (s1 <= s2)  {
    tmp = s1/s2;
c.val = Math.sqrt(one+tmp*tmp);
sestpr.val = absest*(tmp/c.val);
s.val = -(gamma/s2)/c.val;
c.val = ((alpha) >= 0 ? Math.abs(one) : -Math.abs(one))/c.val;
}              // Close if()
else  {
  tmp = s2/s1;
s.val = Math.sqrt(one+tmp*tmp);
sestpr.val = absest/s.val;
c.val = (alpha/s1)/s.val;
s.val = -((gamma) >= 0 ? Math.abs(one) : -Math.abs(one))/s.val;
}              //  Close else.
Dummy.go_to("Dlaic1",999999);
}              // Close else if()
else  {
  // *
// *           normal case
// *
zeta1 = alpha/absest;
zeta2 = gamma/absest;
// *
norma = Math.max(one+zeta1*zeta1+Math.abs(zeta1*zeta2), Math.abs(zeta1*zeta2)+zeta2*zeta2) ;
// *
// *           See if root is closer to zero or to ONE
// *
test = one+two*(zeta1-zeta2)*(zeta1+zeta2);
if (test >= zero)  {
    // *
// *              root is close to zero, compute directly
// *
b = (zeta1*zeta1+zeta2*zeta2+one)*half;
c.val = zeta2*zeta2;
t = c.val/(b+Math.sqrt(Math.abs(b*b-c.val)));
sine = zeta1/(one-t);
cosine = -zeta2/t;
sestpr.val = Math.sqrt(t+four*eps*eps*norma)*absest;
}              // Close if()
else  {
  // *
// *              root is closer to ONE, shift by that amount
// *
b = (zeta2*zeta2+zeta1*zeta1-one)*half;
c.val = zeta1*zeta1;
if (b >= zero)  {
    t = -c.val/(b+Math.sqrt(b*b+c.val));
}              // Close if()
else  {
  t = b-Math.sqrt(b*b+c.val);
}              //  Close else.
sine = -zeta1/t;
cosine = -zeta2/(one+t);
sestpr.val = Math.sqrt(one+t+four*eps*eps*norma)*absest;
}              //  Close else.
tmp = Math.sqrt(sine*sine+cosine*cosine);
s.val = sine/tmp;
c.val = cosine/tmp;
Dummy.go_to("Dlaic1",999999);
// *
}              //  Close else.
}              // Close else if()
Dummy.go_to("Dlaic1",999999);
// *
// *     End of DLAIC1
// *
Dummy.label("Dlaic1",999999);
return;
   }
} // End class.
