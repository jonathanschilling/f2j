/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaln2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLALN2 solves a system of the form  (ca A - w D ) X = s B
// *  or (ca A' - w D) X = s B   with possible scaling ("s") and
// *  perturbation of A.  (A' means A-transpose.)
// *
// *  A is an NA x NA real matrix, ca is a real scalar, D is an NA x NA
// *  real diagonal matrix, w is a real or complex value, and X and B are
// *  NA x 1 matrices -- real if w is real, complex if w is complex.  NA
// *  may be 1 or 2.
// *
// *  If w is complex, X and B are represented as NA x 2 matrices,
// *  the first column of each being the real part and the second
// *  being the imaginary part.
// *
// *  "s" is a scaling factor (.LE. 1), computed by DLALN2, which is
// *  so chosen that X can be computed without overflow.  X is further
// *  scaled if necessary to assure that norm(ca A - w D)*norm(X) is less
// *  than overflow.
// *
// *  If both singular values of (ca A - w D) are less than SMIN,
// *  SMIN*identity will be used instead of (ca A - w D).  If only one
// *  singular value is less than SMIN, one element of (ca A - w D) will be
// *  perturbed enough to make the smallest singular value roughly SMIN.
// *  If both singular values are at least SMIN, (ca A - w D) will not be
// *  perturbed.  In any case, the perturbation will be at most some small
// *  multiple of max( SMIN, ulp*norm(ca A - w D) ).  The singular values
// *  are computed by infinity-norm approximations, and thus will only be
// *  correct to a factor of 2 or so.
// *
// *  Note: all input quantities are assumed to be smaller than overflow
// *  by a reasonable factor.  (See BIGNUM.)
// *
// *  Arguments
// *  ==========
// *
// *  LTRANS  (input) LOGICAL
// *          =.TRUE.:  A-transpose will be used.
// *          =.FALSE.: A will be used (not transposed.)
// *
// *  NA      (input) INTEGER
// *          The size of the matrix A.  It may (only) be 1 or 2.
// *
// *  NW      (input) INTEGER
// *          1 if "w" is real, 2 if "w" is complex.  It may only be 1
// *          or 2.
// *
// *  SMIN    (input) DOUBLE PRECISION
// *          The desired lower bound on the singular values of A.  This
// *          should be a safe distance away from underflow or overflow,
// *          say, between (underflow/machine precision) and  (machine
// *          precision * overflow ).  (See BIGNUM and ULP.)
// *
// *  CA      (input) DOUBLE PRECISION
// *          The coefficient c, which A is multiplied by.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,NA)
// *          The NA x NA matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least NA.
// *
// *  D1      (input) DOUBLE PRECISION
// *          The 1,1 element in the diagonal matrix D.
// *
// *  D2      (input) DOUBLE PRECISION
// *          The 2,2 element in the diagonal matrix D.  Not used if NW=1.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NW)
// *          The NA x NW matrix B (right-hand side).  If NW=2 ("w" is
// *          complex), column 1 contains the real part of B and column 2
// *          contains the imaginary part.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  It must be at least NA.
// *
// *  WR      (input) DOUBLE PRECISION
// *          The real part of the scalar "w".
// *
// *  WI      (input) DOUBLE PRECISION
// *          The imaginary part of the scalar "w".  Not used if NW=1.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (LDX,NW)
// *          The NA x NW matrix X (unknowns), as computed by DLALN2.
// *          If NW=2 ("w" is complex), on exit, column 1 will contain
// *          the real part of X and column 2 will contain the imaginary
// *          part.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of X.  It must be at least NA.
// *
// *  SCALE   (output) DOUBLE PRECISION
// *          The scale factor that B must be multiplied by to insure
// *          that overflow does not occur when computing X.  Thus,
// *          (ca A - w D) X  will be SCALE*B, not B (ignoring
// *          perturbations of A.)  It will be at most 1.
// *
// *  XNORM   (output) DOUBLE PRECISION
// *          The infinity-norm of X, when X is regarded as an NA x NW
// *          real matrix.
// *
// *  INFO    (output) INTEGER
// *          An error flag.  It will be set to zero if no error occurs,
// *          a negative number if an argument is in error, or a positive
// *          number if  ca A - w D  had to be perturbed.
// *          The possible values are:
// *          = 0: No error occurred, and (ca A - w D) did not have to be
// *                 perturbed.
// *          = 1: (ca A - w D) had to be perturbed to make its smallest
// *               (or only) singular value greater than SMIN.
// *          NOTE: In the interests of speed, this routine does not
// *                check the inputs for errors.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
// *     ..
// *     .. Local Scalars ..
static int icmax= 0;
static int j= 0;
static double bbnd= 0.0;
static double bi1= 0.0;
static double bi2= 0.0;
static double bignum= 0.0;
static double bnorm= 0.0;
static double br1= 0.0;
static double br2= 0.0;
static double ci21= 0.0;
static double ci22= 0.0;
static double cmax= 0.0;
static double cnorm= 0.0;
static double cr21= 0.0;
static double cr22= 0.0;
static double csi= 0.0;
static double csr= 0.0;
static double li21= 0.0;
static double lr21= 0.0;
static double smini= 0.0;
static double smlnum= 0.0;
static double temp= 0.0;
static double u22abs= 0.0;
static double ui11= 0.0;
static double ui11r= 0.0;
static double ui12= 0.0;
static double ui12s= 0.0;
static double ui22= 0.0;
static double ur11= 0.0;
static double ur11r= 0.0;
static double ur12= 0.0;
static double ur12s= 0.0;
static double ur22= 0.0;
static double xi1= 0.0;
static doubleW xi2= new doubleW(0.0);
static double xr1= 0.0;
static doubleW xr2= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
  // ci equivalenced to ci_civ
  // civ equivalenced to ci_civ
  // cr equivalenced to cr_crv
  // crv equivalenced to cr_crv
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Equivalences ..
static double [] ci_civ= new double[(2) * (2)];
static double [] cr_crv= new double[(2) * (2)];
// *     ..
// *     .. Data statements ..
static boolean [] zswap = {false 
, false , true , true };
static boolean [] rswap = {false 
, true , false , true };
static int [] ipivot = {1 
, 2 , 3 , 4 , 2 , 1 
, 4 , 3 , 3 , 4 , 1 
, 2 , 4 , 3 , 2 , 1 
};
// *     ..
// *     .. Executable Statements ..
// *
// *     Compute BIGNUM
// *

public static void dlaln2 (boolean ltrans,
int na,
int nw,
double smin,
double ca,
double [] a, int _a_offset,
int lda,
double d1,
double d2,
double [] b, int _b_offset,
int ldb,
double wr,
double wi,
double [] x, int _x_offset,
int ldx,
doubleW scale,
doubleW xnorm,
intW info)  {

smlnum = two*Dlamch.dlamch("Safe minimum");
bignum = one/smlnum;
smini = Math.max(smin, smlnum) ;
// *
// *     Don't check for input errors
// *
info.val = 0;
// *
// *     Standard Initializations
// *
scale.val = one;
// *
if (na == 1)  {
    // *
// *        1 x 1  (i.e., scalar) system   C X = B
// *
if (nw == 1)  {
    // *
// *           Real 1x1 system.
// *
// *           C = ca A - w D
// *
csr = ca*a[(1)- 1+(1- 1)*lda+ _a_offset]-wr*d1;
cnorm = Math.abs(csr);
// *
// *           If | C | < SMINI, use C = SMINI
// *
if (cnorm < smini)  {
    csr = smini;
cnorm = smini;
info.val = 1;
}              // Close if()
// *
// *           Check scaling for  X = B / C
// *
bnorm = Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset]);
if (cnorm < one && bnorm > one)  {
    if (bnorm > bignum*cnorm)  
    scale.val = one/bnorm;
}              // Close if()
// *
// *           Compute X
// *
x[(1)- 1+(1- 1)*ldx+ _x_offset] = (b[(1)- 1+(1- 1)*ldb+ _b_offset]*scale.val)/csr;
xnorm.val = Math.abs(x[(1)- 1+(1- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  // *
// *           Complex 1x1 system (w is complex)
// *
// *           C = ca A - w D
// *
csr = ca*a[(1)- 1+(1- 1)*lda+ _a_offset]-wr*d1;
csi = -wi*d1;
cnorm = Math.abs(csr)+Math.abs(csi);
// *
// *           If | C | < SMINI, use C = SMINI
// *
if (cnorm < smini)  {
    csr = smini;
csi = zero;
cnorm = smini;
info.val = 1;
}              // Close if()
// *
// *           Check scaling for  X = B / C
// *
bnorm = Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset])+Math.abs(b[(1)- 1+(2- 1)*ldb+ _b_offset]);
if (cnorm < one && bnorm > one)  {
    if (bnorm > bignum*cnorm)  
    scale.val = one/bnorm;
}              // Close if()
// *
// *           Compute X
// *
dladiv_adapter(scale.val*b[(1)- 1+(1- 1)*ldb+ _b_offset],scale.val*b[(1)- 1+(2- 1)*ldb+ _b_offset],csr,csi,x,(1)- 1+(1- 1)*ldx+ _x_offset,x,(1)- 1+(2- 1)*ldx+ _x_offset);
xnorm.val = Math.abs(x[(1)- 1+(1- 1)*ldx+ _x_offset])+Math.abs(x[(1)- 1+(2- 1)*ldx+ _x_offset]);
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *        2x2 System
// *
// *        Compute the real part of  C = ca A - w D  (or  ca A' - w D )
// *
cr_crv[(1)- 1+(1- 1)*2] = ca*a[(1)- 1+(1- 1)*lda+ _a_offset]-wr*d1;
cr_crv[(2)- 1+(2- 1)*2] = ca*a[(2)- 1+(2- 1)*lda+ _a_offset]-wr*d2;
if (ltrans)  {
    cr_crv[(1)- 1+(2- 1)*2] = ca*a[(2)- 1+(1- 1)*lda+ _a_offset];
cr_crv[(2)- 1+(1- 1)*2] = ca*a[(1)- 1+(2- 1)*lda+ _a_offset];
}              // Close if()
else  {
  cr_crv[(2)- 1+(1- 1)*2] = ca*a[(2)- 1+(1- 1)*lda+ _a_offset];
cr_crv[(1)- 1+(2- 1)*2] = ca*a[(1)- 1+(2- 1)*lda+ _a_offset];
}              //  Close else.
// *
if (nw == 1)  {
    // *
// *           Real 2x2 system  (w is real)
// *
// *           Find the largest element in C
// *
cmax = zero;
icmax = 0;
// *
{
forloop10:
for (j = 1; j <= 4; j++) {
if (Math.abs(cr_crv[(j)- 1]) > cmax)  {
    cmax = Math.abs(cr_crv[(j)- 1]);
icmax = j;
}              // Close if()
Dummy.label("Dlaln2",10);
}              //  Close for() loop. 
}
// *
// *           If norm(C) < SMINI, use SMINI*identity.
// *
if (cmax < smini)  {
    bnorm = Math.max(Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset]), Math.abs(b[(2)- 1+(1- 1)*ldb+ _b_offset])) ;
if (smini < one && bnorm > one)  {
    if (bnorm > bignum*smini)  
    scale.val = one/bnorm;
}              // Close if()
temp = scale.val/smini;
x[(1)- 1+(1- 1)*ldx+ _x_offset] = temp*b[(1)- 1+(1- 1)*ldb+ _b_offset];
x[(2)- 1+(1- 1)*ldx+ _x_offset] = temp*b[(2)- 1+(1- 1)*ldb+ _b_offset];
xnorm.val = temp*bnorm;
info.val = 1;
Dummy.go_to("Dlaln2",999999);
}              // Close if()
// *
// *           Gaussian elimination with complete pivoting.
// *
ur11 = cr_crv[(icmax)- 1];
cr21 = cr_crv[(ipivot[(2)- 1+(icmax- 1)*4])- 1];
ur12 = cr_crv[(ipivot[(3)- 1+(icmax- 1)*4])- 1];
cr22 = cr_crv[(ipivot[(4)- 1+(icmax- 1)*4])- 1];
ur11r = one/ur11;
lr21 = ur11r*cr21;
ur22 = cr22-ur12*lr21;
// *
// *           If smaller pivot < SMINI, use SMINI
// *
if (Math.abs(ur22) < smini)  {
    ur22 = smini;
info.val = 1;
}              // Close if()
if (rswap[(icmax)- 1])  {
    br1 = b[(2)- 1+(1- 1)*ldb+ _b_offset];
br2 = b[(1)- 1+(1- 1)*ldb+ _b_offset];
}              // Close if()
else  {
  br1 = b[(1)- 1+(1- 1)*ldb+ _b_offset];
br2 = b[(2)- 1+(1- 1)*ldb+ _b_offset];
}              //  Close else.
br2 = br2-lr21*br1;
bbnd = Math.max(Math.abs(br1*(ur22*ur11r)), Math.abs(br2)) ;
if (bbnd > one && Math.abs(ur22) < one)  {
    if (bbnd >= bignum*Math.abs(ur22))  
    scale.val = one/bbnd;
}              // Close if()
// *
xr2.val = (br2*scale.val)/ur22;
xr1 = (scale.val*br1)*ur11r-xr2.val*(ur11r*ur12);
if (zswap[(icmax)- 1])  {
    x[(1)- 1+(1- 1)*ldx+ _x_offset] = xr2.val;
x[(2)- 1+(1- 1)*ldx+ _x_offset] = xr1;
}              // Close if()
else  {
  x[(1)- 1+(1- 1)*ldx+ _x_offset] = xr1;
x[(2)- 1+(1- 1)*ldx+ _x_offset] = xr2.val;
}              //  Close else.
xnorm.val = Math.max(Math.abs(xr1), Math.abs(xr2.val)) ;
// *
// *           Further scaling if  norm(A) norm(X) > overflow
// *
if (xnorm.val > one && cmax > one)  {
    if (xnorm.val > bignum/cmax)  {
    temp = cmax/bignum;
x[(1)- 1+(1- 1)*ldx+ _x_offset] = temp*x[(1)- 1+(1- 1)*ldx+ _x_offset];
x[(2)- 1+(1- 1)*ldx+ _x_offset] = temp*x[(2)- 1+(1- 1)*ldx+ _x_offset];
xnorm.val = temp*xnorm.val;
scale.val = temp*scale.val;
}              // Close if()
}              // Close if()
}              // Close if()
else  {
  // *
// *           Complex 2x2 system  (w is complex)
// *
// *           Find the largest element in C
// *
ci_civ[(1)- 1+(1- 1)*2] = -wi*d1;
ci_civ[(2)- 1+(1- 1)*2] = zero;
ci_civ[(1)- 1+(2- 1)*2] = zero;
ci_civ[(2)- 1+(2- 1)*2] = -wi*d2;
cmax = zero;
icmax = 0;
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
if (Math.abs(cr_crv[(j)- 1])+Math.abs(ci_civ[(j)- 1]) > cmax)  {
    cmax = Math.abs(cr_crv[(j)- 1])+Math.abs(ci_civ[(j)- 1]);
icmax = j;
}              // Close if()
Dummy.label("Dlaln2",20);
}              //  Close for() loop. 
}
// *
// *           If norm(C) < SMINI, use SMINI*identity.
// *
if (cmax < smini)  {
    bnorm = Math.max(Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset])+Math.abs(b[(1)- 1+(2- 1)*ldb+ _b_offset]), Math.abs(b[(2)- 1+(1- 1)*ldb+ _b_offset])+Math.abs(b[(2)- 1+(2- 1)*ldb+ _b_offset])) ;
if (smini < one && bnorm > one)  {
    if (bnorm > bignum*smini)  
    scale.val = one/bnorm;
}              // Close if()
temp = scale.val/smini;
x[(1)- 1+(1- 1)*ldx+ _x_offset] = temp*b[(1)- 1+(1- 1)*ldb+ _b_offset];
x[(2)- 1+(1- 1)*ldx+ _x_offset] = temp*b[(2)- 1+(1- 1)*ldb+ _b_offset];
x[(1)- 1+(2- 1)*ldx+ _x_offset] = temp*b[(1)- 1+(2- 1)*ldb+ _b_offset];
x[(2)- 1+(2- 1)*ldx+ _x_offset] = temp*b[(2)- 1+(2- 1)*ldb+ _b_offset];
xnorm.val = temp*bnorm;
info.val = 1;
Dummy.go_to("Dlaln2",999999);
}              // Close if()
// *
// *           Gaussian elimination with complete pivoting.
// *
ur11 = cr_crv[(icmax)- 1];
ui11 = ci_civ[(icmax)- 1];
cr21 = cr_crv[(ipivot[(2)- 1+(icmax- 1)*4])- 1];
ci21 = ci_civ[(ipivot[(2)- 1+(icmax- 1)*4])- 1];
ur12 = cr_crv[(ipivot[(3)- 1+(icmax- 1)*4])- 1];
ui12 = ci_civ[(ipivot[(3)- 1+(icmax- 1)*4])- 1];
cr22 = cr_crv[(ipivot[(4)- 1+(icmax- 1)*4])- 1];
ci22 = ci_civ[(ipivot[(4)- 1+(icmax- 1)*4])- 1];
if (icmax == 1 || icmax == 4)  {
    // *
// *              Code when off-diagonals of pivoted C are real
// *
if (Math.abs(ur11) > Math.abs(ui11))  {
    temp = ui11/ur11;
ur11r = one/(ur11*(one+Math.pow(temp, 2)));
ui11r = -temp*ur11r;
}              // Close if()
else  {
  temp = ur11/ui11;
ui11r = -one/(ui11*(one+Math.pow(temp, 2)));
ur11r = -temp*ui11r;
}              //  Close else.
lr21 = cr21*ur11r;
li21 = cr21*ui11r;
ur12s = ur12*ur11r;
ui12s = ur12*ui11r;
ur22 = cr22-ur12*lr21;
ui22 = ci22-ur12*li21;
}              // Close if()
else  {
  // *
// *              Code when diagonals of pivoted C are real
// *
ur11r = one/ur11;
ui11r = zero;
lr21 = cr21*ur11r;
li21 = ci21*ur11r;
ur12s = ur12*ur11r;
ui12s = ui12*ur11r;
ur22 = cr22-ur12*lr21+ui12*li21;
ui22 = -ur12*li21-ui12*lr21;
}              //  Close else.
u22abs = Math.abs(ur22)+Math.abs(ui22);
// *
// *           If smaller pivot < SMINI, use SMINI
// *
if (u22abs < smini)  {
    ur22 = smini;
ui22 = zero;
info.val = 1;
}              // Close if()
if (rswap[(icmax)- 1])  {
    br2 = b[(1)- 1+(1- 1)*ldb+ _b_offset];
br1 = b[(2)- 1+(1- 1)*ldb+ _b_offset];
bi2 = b[(1)- 1+(2- 1)*ldb+ _b_offset];
bi1 = b[(2)- 1+(2- 1)*ldb+ _b_offset];
}              // Close if()
else  {
  br1 = b[(1)- 1+(1- 1)*ldb+ _b_offset];
br2 = b[(2)- 1+(1- 1)*ldb+ _b_offset];
bi1 = b[(1)- 1+(2- 1)*ldb+ _b_offset];
bi2 = b[(2)- 1+(2- 1)*ldb+ _b_offset];
}              //  Close else.
br2 = br2-lr21*br1+li21*bi1;
bi2 = bi2-li21*br1-lr21*bi1;
bbnd = Math.max((Math.abs(br1)+Math.abs(bi1))*(u22abs*(Math.abs(ur11r)+Math.abs(ui11r))), Math.abs(br2)+Math.abs(bi2)) ;
if (bbnd > one && u22abs < one)  {
    if (bbnd >= bignum*u22abs)  {
    scale.val = one/bbnd;
br1 = scale.val*br1;
bi1 = scale.val*bi1;
br2 = scale.val*br2;
bi2 = scale.val*bi2;
}              // Close if()
}              // Close if()
// *
Dladiv.dladiv(br2,bi2,ur22,ui22,xr2,xi2);
xr1 = ur11r*br1-ui11r*bi1-ur12s*xr2.val+ui12s*xi2.val;
xi1 = ui11r*br1+ur11r*bi1-ui12s*xr2.val-ur12s*xi2.val;
if (zswap[(icmax)- 1])  {
    x[(1)- 1+(1- 1)*ldx+ _x_offset] = xr2.val;
x[(2)- 1+(1- 1)*ldx+ _x_offset] = xr1;
x[(1)- 1+(2- 1)*ldx+ _x_offset] = xi2.val;
x[(2)- 1+(2- 1)*ldx+ _x_offset] = xi1;
}              // Close if()
else  {
  x[(1)- 1+(1- 1)*ldx+ _x_offset] = xr1;
x[(2)- 1+(1- 1)*ldx+ _x_offset] = xr2.val;
x[(1)- 1+(2- 1)*ldx+ _x_offset] = xi1;
x[(2)- 1+(2- 1)*ldx+ _x_offset] = xi2.val;
}              //  Close else.
xnorm.val = Math.max(Math.abs(xr1)+Math.abs(xi1), Math.abs(xr2.val)+Math.abs(xi2.val)) ;
// *
// *           Further scaling if  norm(A) norm(X) > overflow
// *
if (xnorm.val > one && cmax > one)  {
    if (xnorm.val > bignum/cmax)  {
    temp = cmax/bignum;
x[(1)- 1+(1- 1)*ldx+ _x_offset] = temp*x[(1)- 1+(1- 1)*ldx+ _x_offset];
x[(2)- 1+(1- 1)*ldx+ _x_offset] = temp*x[(2)- 1+(1- 1)*ldx+ _x_offset];
x[(1)- 1+(2- 1)*ldx+ _x_offset] = temp*x[(1)- 1+(2- 1)*ldx+ _x_offset];
x[(2)- 1+(2- 1)*ldx+ _x_offset] = temp*x[(2)- 1+(2- 1)*ldx+ _x_offset];
xnorm.val = temp*xnorm.val;
scale.val = temp*scale.val;
}              // Close if()
}              // Close if()
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dlaln2",999999);
// *
// *     End of DLALN2
// *
Dummy.label("Dlaln2",999999);
return;
   }
// adapter for dladiv
private static void dladiv_adapter(double arg0 ,double arg1 ,double arg2 ,double arg3 ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset )
{
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);
doubleW _f2j_tmp5 = new doubleW(arg5[arg5_offset]);

Dladiv.dladiv(arg0,arg1,arg2,arg3,_f2j_tmp4,_f2j_tmp5);

arg4[arg4_offset] = _f2j_tmp4.val;
arg5[arg5_offset] = _f2j_tmp5.val;
}

} // End class.
