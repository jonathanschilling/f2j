/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamc1 {

// *
// ************************************************************************
// *
// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMC1 determines the machine parameters given by BETA, T, RND, and
// *  IEEE1.
// *
// *  Arguments
// *  =========
// *
// *  BETA    (output) INTEGER
// *          The base of the machine.
// *
// *  T       (output) INTEGER
// *          The number of ( BETA ) digits in the mantissa.
// *
// *  RND     (output) LOGICAL
// *          Specifies whether proper rounding  ( RND = .TRUE. )  or
// *          chopping  ( RND = .FALSE. )  occurs in addition. This may not
// *          be a reliable guide to the way in which the machine performs
// *          its arithmetic.
// *
// *  IEEE1   (output) LOGICAL
// *          Specifies whether rounding appears to be done in the IEEE
// *          'round to nearest' style.
// *
// *  Further Details
// *  ===============
// *
// *  The routine is based on the routine  ENVRON  by Malcolm and
// *  incorporates suggestions by Gentleman and Marovich. See
// *
// *     Malcolm M. A. (1972) Algorithms to reveal properties of
// *        floating-point arithmetic. Comms. of the ACM, 15, 949-951.
// *
// *     Gentleman W. M. and Marovich S. B. (1974) More on algorithms
// *        that reveal properties of floating point arithmetic units.
// *        Comms. of the ACM, 17, 276-277.
// *
// * =====================================================================
// *
// *     .. Local Scalars ..
static boolean lieee1= false;
static boolean lrnd= false;
static int lbeta= 0;
static int lt= 0;
static double a= 0.0;
static double b= 0.0;
static double c= 0.0;
static double f= 0.0;
static double one= 0.0;
static double qtr= 0.0;
static double savec= 0.0;
static double t1= 0.0;
static double t2= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlamc1 (intW beta,
intW t,
booleanW rnd,
booleanW ieee1)  {

if (first)  {
    first = false;
one = (double)(1);
// *
// *        LBETA,  LIEEE1,  LT and  LRND  are the  local values  of  BETA,
// *        IEEE1, T and RND.
// *
// *        Throughout this routine  we use the function  DLAMC3  to ensure
// *        that relevant values are  stored and not held in registers,  or
// *        are not affected by optimizers.
// *
// *        Compute  a = 2.0**m  with the  smallest positive integer m such
// *        that
// *
// *           fl( a + 1.0 ) = a.
// *
a = (double)(1);
c = (double)(1);
// *
// *+       WHILE( C.EQ.ONE )LOOP
label10:
   Dummy.label("Dlamc1",10);
while (c == one)  {
    a = 2*a;
c = Dlamc3.dlamc3(a,one);
c = Dlamc3.dlamc3(c,-a);
// goto 10 (end while)
}              // Close if()
// *+       END WHILE
// *
// *        Now compute  b = 2.0**m  with the smallest positive integer m
// *        such that
// *
// *           fl( a + b ) .gt. a.
// *
b = (double)(1);
c = Dlamc3.dlamc3(a,b);
// *
// *+       WHILE( C.EQ.A )LOOP
label20:
   Dummy.label("Dlamc1",20);
while (c == a)  {
    b = 2*b;
c = Dlamc3.dlamc3(a,b);
// goto 20 (end while)
}              // Close if()
// *+       END WHILE
// *
// *        Now compute the base.  a and c  are neighbouring floating point
// *        numbers  in the  interval  ( beta**t, beta**( t + 1 ) )  and so
// *        their difference is beta. Adding 0.25 to c is to ensure that it
// *        is truncated to beta and not ( beta - 1 ).
// *
qtr = one/4;
savec = c;
c = Dlamc3.dlamc3(c,-a);
lbeta = (int)(c+qtr);
// *
// *        Now determine whether rounding or chopping occurs,  by adding a
// *        bit  less  than  beta/2  and a  bit  more  than  beta/2  to  a.
// *
b = (double)(lbeta);
f = Dlamc3.dlamc3(b/2,-b/100);
c = Dlamc3.dlamc3(f,a);
if (c == a)  {
    lrnd = true;
}              // Close if()
else  {
  lrnd = false;
}              //  Close else.
f = Dlamc3.dlamc3(b/2,b/100);
c = Dlamc3.dlamc3(f,a);
if ((lrnd) && (c == a))  
    lrnd = false;
// *
// *        Try and decide whether rounding is done in the  IEEE  'round to
// *        nearest' style. B/2 is half a unit in the last place of the two
// *        numbers A and SAVEC. Furthermore, A is even, i.e. has last  bit
// *        zero, and SAVEC is odd. Thus adding B/2 to A should not  change
// *        A, but adding B/2 to SAVEC should change SAVEC.
// *
t1 = Dlamc3.dlamc3(b/2,a);
t2 = Dlamc3.dlamc3(b/2,savec);
lieee1 = (t1 == a) && (t2 > savec) && lrnd;
// *
// *        Now find  the  mantissa, t.  It should  be the  integer part of
// *        log to the base beta of a,  however it is safer to determine  t
// *        by powering.  So we find t as the smallest positive integer for
// *        which
// *
// *           fl( beta**t + 1.0 ) = 1.0.
// *
lt = 0;
a = (double)(1);
c = (double)(1);
// *
// *+       WHILE( C.EQ.ONE )LOOP
label30:
   Dummy.label("Dlamc1",30);
while (c == one)  {
    lt = lt+1;
a = a*lbeta;
c = Dlamc3.dlamc3(a,one);
c = Dlamc3.dlamc3(c,-a);
// goto 30 (end while)
}              // Close if()
// *+       END WHILE
// *
}              // Close if()
// *
beta.val = lbeta;
t.val = lt;
rnd.val = lrnd;
ieee1.val = lieee1;
Dummy.go_to("Dlamc1",999999);
// *
// *     End of DLAMC1
// *
Dummy.label("Dlamc1",999999);
return;
   }
} // End class.
