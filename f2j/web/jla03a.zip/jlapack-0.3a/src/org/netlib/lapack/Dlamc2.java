/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamc2 {

// *
// ************************************************************************
// *
// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMC2 determines the machine parameters specified in its argument
// *  list.
// *
// *  Arguments
// *  =========
// *
// *  BETA    (output) INTEGER
// *          The base of the machine.
// *
// *  T       (output) INTEGER
// *          The number of ( BETA ) digits in the mantissa.
// *
// *  RND     (output) LOGICAL
// *          Specifies whether proper rounding  ( RND = .TRUE. )  or
// *          chopping  ( RND = .FALSE. )  occurs in addition. This may not
// *          be a reliable guide to the way in which the machine performs
// *          its arithmetic.
// *
// *  EPS     (output) DOUBLE PRECISION
// *          The smallest positive number such that
// *
// *             fl( 1.0 - EPS ) .LT. 1.0,
// *
// *          where fl denotes the computed value.
// *
// *  EMIN    (output) INTEGER
// *          The minimum exponent before (gradual) underflow occurs.
// *
// *  RMIN    (output) DOUBLE PRECISION
// *          The smallest normalized number for the machine, given by
// *          BASE**( EMIN - 1 ), where  BASE  is the floating point value
// *          of BETA.
// *
// *  EMAX    (output) INTEGER
// *          The maximum exponent before overflow occurs.
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          The largest positive number for the machine, given by
// *          BASE**EMAX * ( 1 - EPS ), where  BASE  is the floating point
// *          value of BETA.
// *
// *  Further Details
// *  ===============
// *
// *  The computation of  EPS  is based on a routine PARANOIA by
// *  W. Kahan of the University of California at Berkeley.
// *
// * =====================================================================
// *
// *     .. Local Scalars ..
static boolean ieee= false;
static booleanW lieee1= new booleanW(false);
static booleanW lrnd= new booleanW(false);
static intW gnmin= new intW(0);
static intW gpmin= new intW(0);
static int i= 0;
static intW lbeta= new intW(0);
static intW lemax= new intW(0);
static int lemin= 0;
static intW lt= new intW(0);
static intW ngnmin= new intW(0);
static intW ngpmin= new intW(0);
static double a= 0.0;
static double b= 0.0;
static double c= 0.0;
static double half= 0.0;
static double leps= 0.0;
static doubleW lrmax= new doubleW(0.0);
static double lrmin= 0.0;
static double one= 0.0;
static double rbase= 0.0;
static double sixth= 0.0;
static double small= 0.0;
static double third= 0.0;
static double two= 0.0;
static double zero= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean iwarn = false;
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlamc2 (intW beta,
intW t,
booleanW rnd,
doubleW eps,
intW emin,
doubleW rmin,
intW emax,
doubleW rmax)  {

if (first)  {
    first = false;
zero = (double)(0);
one = (double)(1);
two = (double)(2);
// *
// *        LBETA, LT, LRND, LEPS, LEMIN and LRMIN  are the local values of
// *        BETA, T, RND, EPS, EMIN and RMIN.
// *
// *        Throughout this routine  we use the function  DLAMC3  to ensure
// *        that relevant values are stored  and not held in registers,  or
// *        are not affected by optimizers.
// *
// *        DLAMC1 returns the parameters  LBETA, LT, LRND and LIEEE1.
// *
Dlamc1.dlamc1(lbeta,lt,lrnd,lieee1);
// *
// *        Start to find EPS.
// *
b = (double)(lbeta.val);
a = Math.pow(b, (-lt.val));
leps = a;
// *
// *        Try some tricks to see whether or not this is the correct  EPS.
// *
b = two/3;
half = one/2;
sixth = Dlamc3.dlamc3(b,-half);
third = Dlamc3.dlamc3(sixth,sixth);
b = Dlamc3.dlamc3(third,-half);
b = Dlamc3.dlamc3(b,sixth);
b = Math.abs(b);
if (b < leps)  
    b = leps;
// *
leps = (double)(1);
// *
// *+       WHILE( ( LEPS.GT.B ).AND.( B.GT.ZERO ) )LOOP
label10:
   Dummy.label("Dlamc2",10);
while ((leps > b) && (b > zero))  {
    leps = b;
c = Dlamc3.dlamc3(half*leps,(Math.pow(two, 5))*(Math.pow(leps, 2)));
c = Dlamc3.dlamc3(half,-c);
b = Dlamc3.dlamc3(half,c);
c = Dlamc3.dlamc3(half,-b);
b = Dlamc3.dlamc3(half,c);
// goto 10 (end while)
}              // Close if()
// *+       END WHILE
// *
if (a < leps)  
    leps = a;
// *
// *        Computation of EPS complete.
// *
// *        Now find  EMIN.  Let A = + or - 1, and + or - (1 + BASE**(-3)).
// *        Keep dividing  A by BETA until (gradual) underflow occurs. This
// *        is detected when we cannot recover the previous A.
// *
rbase = one/lbeta.val;
small = one;
{
forloop20:
for (i = 1; i <= 3; i++) {
small = Dlamc3.dlamc3(small*rbase,zero);
Dummy.label("Dlamc2",20);
}              //  Close for() loop. 
}
a = Dlamc3.dlamc3(one,small);
Dlamc4.dlamc4(ngpmin,one,lbeta.val);
Dlamc4.dlamc4(ngnmin,-one,lbeta.val);
Dlamc4.dlamc4(gpmin,a,lbeta.val);
Dlamc4.dlamc4(gnmin,-a,lbeta.val);
ieee = false;
// *
if ((ngpmin.val == ngnmin.val) && (gpmin.val == gnmin.val))  {
    if (ngpmin.val == gpmin.val)  {
    lemin = ngpmin.val;
// *            ( Non twos-complement machines, no gradual underflow;
// *              e.g.,  VAX )
}              // Close if()
else if ((gpmin.val-ngpmin.val) == 3)  {
    lemin = ngpmin.val-1+lt.val;
ieee = true;
// *            ( Non twos-complement machines, with gradual underflow;
// *              e.g., IEEE standard followers )
}              // Close else if()
else  {
  lemin = (int)(Math.min(ngpmin.val, gpmin.val) );
// *            ( A guess; no known machine )
iwarn = true;
}              //  Close else.
// *
}              // Close if()
else if ((ngpmin.val == gpmin.val) && (ngnmin.val == gnmin.val))  {
    if (Math.abs(ngpmin.val-ngnmin.val) == 1)  {
    lemin = (int)(Math.max(ngpmin.val, ngnmin.val) );
// *            ( Twos-complement machines, no gradual underflow;
// *              e.g., CYBER 205 )
}              // Close if()
else  {
  lemin = (int)(Math.min(ngpmin.val, ngnmin.val) );
// *            ( A guess; no known machine )
iwarn = true;
}              //  Close else.
// *
}              // Close else if()
else if ((Math.abs(ngpmin.val-ngnmin.val) == 1) && (gpmin.val == gnmin.val))  {
    if ((gpmin.val-Math.min(ngpmin.val, ngnmin.val) ) == 3)  {
    lemin = (int)(Math.max(ngpmin.val, ngnmin.val) -1+lt.val);
// *            ( Twos-complement machines with gradual underflow;
// *              no known machine )
}              // Close if()
else  {
  lemin = (int)(Math.min(ngpmin.val, ngnmin.val) );
// *            ( A guess; no known machine )
iwarn = true;
}              //  Close else.
// *
}              // Close else if()
else  {
  lemin = (int)(Math.min(Math.min(Math.min(ngpmin.val, ngnmin.val), gpmin.val), gnmin.val) );
// *         ( A guess; no known machine )
iwarn = true;
}              //  Close else.
// ***
// * Comment out this if block if EMIN is ok
if (iwarn)  {
    first = true;
System.out.println("\n\n"  + " WARNING. The value EMIN may be incorrect:-"  + "  EMIN = "  + (lemin) + " "  + "\n"  + " If, after inspection, the value EMIN looks"  + " acceptable please comment out "  + "\n"  + " the IF block as marked within the code of routine"  + " DLAMC2,"  + "\n"  + " otherwise supply EMIN explicitly."  + "\n" );
}              // Close if()
// ***
// *
// *        Assume IEEE arithmetic if we found denormalised  numbers above,
// *        or if arithmetic seems to round in the  IEEE style,  determined
// *        in routine DLAMC1. A true IEEE machine should have both  things
// *        true; however, faulty machines may have one or the other.
// *
ieee = ieee || lieee1.val;
// *
// *        Compute  RMIN by successive division by  BETA. We could compute
// *        RMIN as BASE**( EMIN - 1 ),  but some machines underflow during
// *        this computation.
// *
lrmin = (double)(1);
{
forloop30:
for (i = 1; i <= 1-lemin; i++) {
lrmin = Dlamc3.dlamc3(lrmin*rbase,zero);
Dummy.label("Dlamc2",30);
}              //  Close for() loop. 
}
// *
// *        Finally, call DLAMC5 to compute EMAX and RMAX.
// *
Dlamc5.dlamc5(lbeta.val,lt.val,lemin,ieee,lemax,lrmax);
}              // Close if()
// *
beta.val = lbeta.val;
t.val = lt.val;
rnd.val = lrnd.val;
eps.val = leps;
emin.val = lemin;
rmin.val = lrmin;
emax.val = lemax.val;
rmax.val = lrmax.val;
// *
Dummy.go_to("Dlamc2",999999);
// *
// *
// *     End of DLAMC2
// *
Dummy.label("Dlamc2",999999);
return;
   }
} // End class.
