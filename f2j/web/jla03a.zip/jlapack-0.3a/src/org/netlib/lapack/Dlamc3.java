/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamc3 {

// *
// ************************************************************************
// *
// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMC3  is intended to force  A  and  B  to be stored prior to doing
// *  the addition of  A  and  B ,  for use in situations where optimizers
// *  might hold one of these in a register.
// *
// *  Arguments
// *  =========
// *
// *  A, B    (input) DOUBLE PRECISION
// *          The values A and B.
// *
// * =====================================================================
// *
// *     .. Executable Statements ..
// *
static double dlamc3 = 0.0;


public static double dlamc3 (double a,
double b)  {

dlamc3 = a+b;
// *
Dummy.go_to("Dlamc3",999999);
// *
// *     End of DLAMC3
// *
Dummy.label("Dlamc3",999999);
return dlamc3;
   }
} // End class.
