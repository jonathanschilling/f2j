/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamc4 {

// *
// ************************************************************************
// *
// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMC4 is a service routine for DLAMC2.
// *
// *  Arguments
// *  =========
// *
// *  EMIN    (output) EMIN
// *          The minimum exponent before (gradual) underflow, computed by
// *          setting A = START and dividing by BASE until the previous A
// *          can not be recovered.
// *
// *  START   (input) DOUBLE PRECISION
// *          The starting point for determining EMIN.
// *
// *  BASE    (input) INTEGER
// *          The base of the machine.
// *
// * =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static double a= 0.0;
static double b1= 0.0;
static double b2= 0.0;
static double c1= 0.0;
static double c2= 0.0;
static double d1= 0.0;
static double d2= 0.0;
static double one= 0.0;
static double rbase= 0.0;
static double zero= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlamc4 (intW emin,
double start,
int base)  {

a = start;
one = (double)(1);
rbase = one/base;
zero = (double)(0);
emin.val = 1;
b1 = Dlamc3.dlamc3(a*rbase,zero);
c1 = a;
c2 = a;
d1 = a;
d2 = a;
// *+    WHILE( ( C1.EQ.A ).AND.( C2.EQ.A ).AND.
// *    $       ( D1.EQ.A ).AND.( D2.EQ.A )      )LOOP
label10:
   Dummy.label("Dlamc4",10);
while ((c1 == a) && (c2 == a) && (d1 == a) && (d2 == a))  {
    emin.val = emin.val-1;
a = b1;
b1 = Dlamc3.dlamc3(a/base,zero);
c1 = Dlamc3.dlamc3(b1*base,zero);
d1 = zero;
{
forloop20:
for (i = 1; i <= base; i++) {
d1 = d1+b1;
Dummy.label("Dlamc4",20);
}              //  Close for() loop. 
}
b2 = Dlamc3.dlamc3(a*rbase,zero);
c2 = Dlamc3.dlamc3(b2/rbase,zero);
d2 = zero;
{
forloop30:
for (i = 1; i <= base; i++) {
d2 = d2+b2;
Dummy.label("Dlamc4",30);
}              //  Close for() loop. 
}
// goto 10 (end while)
}              // Close if()
// *+    END WHILE
// *
Dummy.go_to("Dlamc4",999999);
// *
// *     End of DLAMC4
// *
Dummy.label("Dlamc4",999999);
return;
   }
} // End class.
