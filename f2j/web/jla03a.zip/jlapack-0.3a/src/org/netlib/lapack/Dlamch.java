/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamch {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMCH determines double precision machine parameters.
// *
// *  Arguments
// *  =========
// *
// *  CMACH   (input) CHARACTER*1
// *          Specifies the value to be returned by DLAMCH:
// *          = 'E' or 'e',   DLAMCH := eps
// *          = 'S' or 's ,   DLAMCH := sfmin
// *          = 'B' or 'b',   DLAMCH := base
// *          = 'P' or 'p',   DLAMCH := eps*base
// *          = 'N' or 'n',   DLAMCH := t
// *          = 'R' or 'r',   DLAMCH := rnd
// *          = 'M' or 'm',   DLAMCH := emin
// *          = 'U' or 'u',   DLAMCH := rmin
// *          = 'L' or 'l',   DLAMCH := emax
// *          = 'O' or 'o',   DLAMCH := rmax
// *
// *          where
// *
// *          eps   = relative machine precision
// *          sfmin = safe minimum, such that 1/sfmin does not overflow
// *          base  = base of the machine
// *          prec  = eps*base
// *          t     = number of (base) digits in the mantissa
// *          rnd   = 1.0 when rounding occurs in addition, 0.0 otherwise
// *          emin  = minimum exponent before (gradual) underflow
// *          rmin  = underflow threshold - base**(emin-1)
// *          emax  = largest exponent before overflow
// *          rmax  = overflow threshold  - (base**emax)*(1-eps)
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static booleanW lrnd= new booleanW(false);
static intW beta= new intW(0);
static intW imax= new intW(0);
static intW imin= new intW(0);
static intW it= new intW(0);
static double base= 0.0;
static double emax= 0.0;
static double emin= 0.0;
static doubleW eps= new doubleW(0.0);
static double prec= 0.0;
static double rmach= 0.0;
static doubleW rmax= new doubleW(0.0);
static doubleW rmin= new doubleW(0.0);
static double rnd= 0.0;
static double sfmin= 0.0;
static double small= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *
static double dlamch = 0.0;


public static double dlamch (String cmach)  {

if (first)  {
    first = false;
Dlamc2.dlamc2(beta,it,lrnd,eps,imin,rmin,imax,rmax);
base = (double)(beta.val);
t = (double)(it.val);
if (lrnd.val)  {
    rnd = one;
eps.val = (Math.pow(base, (1-it.val)))/2;
}              // Close if()
else  {
  rnd = zero;
eps.val = Math.pow(base, (1-it.val));
}              //  Close else.
prec = eps.val*base;
emin = (double)(imin.val);
emax = (double)(imax.val);
sfmin = rmin.val;
small = one/rmax.val;
if (small >= sfmin)  {
    // *
// *           Use SMALL plus a bit, to avoid the possibility of rounding
// *           causing overflow when computing  1/sfmin.
// *
sfmin = small*(one+eps.val);
}              // Close if()
}              // Close if()
// *
if ((cmach.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0)))  {
    rmach = eps.val;
}              // Close if()
else if ((cmach.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    rmach = sfmin;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    rmach = base;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)))  {
    rmach = prec;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    rmach = t;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    rmach = rnd;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    rmach = emin;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    rmach = rmin.val;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    rmach = emax;
}              // Close else if()
else if ((cmach.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0)))  {
    rmach = rmax.val;
}              // Close else if()
// *
dlamch = rmach;
Dummy.go_to("Dlamch",999999);
// *
// *     End of DLAMCH
// *
Dummy.label("Dlamch",999999);
return dlamch;
   }
} // End class.
