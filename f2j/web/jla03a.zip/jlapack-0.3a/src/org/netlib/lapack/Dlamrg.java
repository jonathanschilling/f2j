/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlamrg {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAMRG will create a permutation list which will merge the elements
// *  of A (which is composed of two independently sorted sets) into a
// *  single set which is sorted in ascending order.
// *
// *  Arguments
// *  =========
// *
// *  N1     (input) INTEGER
// *  N2     (input) INTEGER
// *         These arguements contain the respective lengths of the two
// *         sorted lists to be merged.
// *
// *  A      (input) DOUBLE PRECISION array, dimension (N1+N2)
// *         The first N1 elements of A contain a list of numbers which
// *         are sorted in either ascending or descending order.  Likewise
// *         for the final N2 elements.
// *
// *  DTRD1  (input) INTEGER
// *  DTRD2  (input) INTEGER
// *         These are the strides to be taken through the array A.
// *         Allowable strides are 1 and -1.  They indicate whether a
// *         subset of A is sorted in ascending (DTRDx = 1) or descending
// *         (DTRDx = -1) order.
// *
// *  INDEX  (output) INTEGER array, dimension (N1+N2)
// *         On exit this array will contain a permutation such that
// *         if B( I ) = A( INDEX( I ) ) for I=1,N1+N2, then B will be
// *         sorted in ascending order.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int ind1= 0;
static int ind2= 0;
static int n1sv= 0;
static int n2sv= 0;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlamrg (int n1,
int n2,
double [] a, int _a_offset,
int dtrd1,
int dtrd2,
int [] index, int _index_offset)  {

n1sv = n1;
n2sv = n2;
if (dtrd1 > 0)  {
    ind1 = 1;
}              // Close if()
else  {
  ind1 = n1;
}              //  Close else.
if (dtrd2 > 0)  {
    ind2 = 1+n1;
}              // Close if()
else  {
  ind2 = n1+n2;
}              //  Close else.
i = 1;
// *     while ( (N1SV > 0) & (N2SV > 0) )
label10:
   Dummy.label("Dlamrg",10);
while (n1sv > 0 && n2sv > 0)  {
    if (a[(ind1)- 1+ _a_offset] <= a[(ind2)- 1+ _a_offset])  {
    index[(i)- 1+ _index_offset] = ind1;
i = i+1;
ind1 = ind1+dtrd1;
n1sv = n1sv-1;
}              // Close if()
else  {
  index[(i)- 1+ _index_offset] = ind2;
i = i+1;
ind2 = ind2+dtrd2;
n2sv = n2sv-1;
}              //  Close else.
// goto 10 (end while)
}              // Close if()
// *     end while
if (n1sv == 0)  {
    {
forloop20:
for (n1sv = 1; n1sv <= n2sv; n1sv++) {
index[(i)- 1+ _index_offset] = ind2;
i = i+1;
ind2 = ind2+dtrd2;
Dummy.label("Dlamrg",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *     N2SV .EQ. 0
{
forloop30:
for (n2sv = 1; n2sv <= n1sv; n2sv++) {
index[(i)- 1+ _index_offset] = ind1;
i = i+1;
ind1 = ind1+dtrd1;
Dummy.label("Dlamrg",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dummy.go_to("Dlamrg",999999);
// *
// *     End of DLAMRG
// *
Dummy.label("Dlamrg",999999);
return;
   }
} // End class.
