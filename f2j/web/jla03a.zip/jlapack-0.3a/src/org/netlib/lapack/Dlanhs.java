/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlanhs {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANHS  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the  element of  largest absolute value  of a
// *  Hessenberg matrix A.
// *
// *  Description
// *  ===========
// *
// *  DLANHS returns the value
// *
// *     DLANHS = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANHS as described
// *          above.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.  When N = 0, DLANHS is
// *          set to zero.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The n by n upper Hessenberg matrix A; the part of A below the
// *          first sub-diagonal is not referenced.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(N,1).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= N when NORM = 'I'; otherwise, WORK is not
// *          referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlanhs = 0.0;


public static double dlanhs (String norm,
int n,
double [] a, int _a_offset,
int lda,
double [] work, int _work_offset)  {

if (n == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
value = zero;
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= Math.min(n, j+1) ; i++) {
value = Math.max(value, Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dlanhs",10);
}              //  Close for() loop. 
}
Dummy.label("Dlanhs",20);
}              //  Close for() loop. 
}
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find norm1(A).
// *
value = zero;
{
forloop40:
for (j = 1; j <= n; j++) {
sum.val = zero;
{
forloop30:
for (i = 1; i <= Math.min(n, j+1) ; i++) {
sum.val = sum.val+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlanhs",30);
}              //  Close for() loop. 
}
value = Math.max(value, sum.val) ;
Dummy.label("Dlanhs",40);
}              //  Close for() loop. 
}
}              // Close else if()
else if ((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    // *
// *        Find normI(A).
// *
{
forloop50:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlanhs",50);
}              //  Close for() loop. 
}
{
forloop70:
for (j = 1; j <= n; j++) {
{
forloop60:
for (i = 1; i <= Math.min(n, j+1) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlanhs",60);
}              //  Close for() loop. 
}
Dummy.label("Dlanhs",70);
}              //  Close for() loop. 
}
value = zero;
{
forloop80:
for (i = 1; i <= n; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlanhs",80);
}              //  Close for() loop. 
}
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
scale.val = zero;
sum.val = one;
{
forloop90:
for (j = 1; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(n, j+1) ),a,(1)- 1+(j- 1)*lda+ _a_offset,1,scale,sum);
Dummy.label("Dlanhs",90);
}              //  Close for() loop. 
}
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlanhs = value;
Dummy.go_to("Dlanhs",999999);
// *
// *     End of DLANHS
// *
Dummy.label("Dlanhs",999999);
return dlanhs;
   }
} // End class.
