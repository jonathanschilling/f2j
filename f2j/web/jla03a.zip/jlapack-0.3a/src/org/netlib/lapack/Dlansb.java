/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlansb {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANSB  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the element of  largest absolute value  of an
// *  n by n symmetric band matrix A,  with k super-diagonals.
// *
// *  Description
// *  ===========
// *
// *  DLANSB returns the value
// *
// *     DLANSB = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANSB as described
// *          above.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          band matrix A is supplied.
// *          = 'U':  Upper triangular part is supplied
// *          = 'L':  Lower triangular part is supplied
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.  When N = 0, DLANSB is
// *          set to zero.
// *
// *  K       (input) INTEGER
// *          The number of super-diagonals or sub-diagonals of the
// *          band matrix A.  K >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The upper or lower triangle of the symmetric band matrix A,
// *          stored in the first K+1 rows of AB.  The j-th column of A is
// *          stored in the j-th column of the array AB as follows:
// *          if UPLO = 'U', AB(k+1+i-j,j) = A(i,j) for max(1,j-k)<=i<=j;
// *          if UPLO = 'L', AB(1+i-j,j)   = A(i,j) for j<=i<=min(n,j+k).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= K+1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= N when NORM = 'I' or '1' or 'O'; otherwise,
// *          WORK is not referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int l= 0;
static double absa= 0.0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlansb = 0.0;


public static double dlansb (String norm,
String uplo,
int n,
int k,
double [] ab, int _ab_offset,
int ldab,
double [] work, int _work_offset)  {

if (n == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = (int)(Math.max(k+2-j, 1) ); i <= k+1; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlansb",10);
}              //  Close for() loop. 
}
Dummy.label("Dlansb",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= Math.min(n+1-j, k+1) ; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlansb",30);
}              //  Close for() loop. 
}
Dummy.label("Dlansb",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find normI(A) ( = norm1(A), since A is symmetric).
// *
value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop60:
for (j = 1; j <= n; j++) {
sum.val = zero;
l = k+1-j;
{
forloop50:
for (i = (int)(Math.max(1, j-k) ); i <= j-1; i++) {
absa = Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
sum.val = sum.val+absa;
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+absa;
Dummy.label("Dlansb",50);
}              //  Close for() loop. 
}
work[(j)- 1+ _work_offset] = sum.val+Math.abs(ab[(k+1)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlansb",60);
}              //  Close for() loop. 
}
{
forloop70:
for (i = 1; i <= n; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlansb",70);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlansb",80);
}              //  Close for() loop. 
}
{
forloop100:
for (j = 1; j <= n; j++) {
sum.val = work[(j)- 1+ _work_offset]+Math.abs(ab[(1)- 1+(j- 1)*ldab+ _ab_offset]);
l = 1-j;
{
forloop90:
for (i = j+1; i <= Math.min(n, j+k) ; i++) {
absa = Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
sum.val = sum.val+absa;
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+absa;
Dummy.label("Dlansb",90);
}              //  Close for() loop. 
}
value = Math.max(value, sum.val) ;
Dummy.label("Dlansb",100);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
scale.val = zero;
sum.val = one;
if (k > 0)  {
    if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop110:
for (j = 2; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(j-1, k) ),ab,(int)((Math.max(k+2-j, 1) )- 1+(j- 1)*ldab+ _ab_offset),1,scale,sum);
Dummy.label("Dlansb",110);
}              //  Close for() loop. 
}
l = k+1;
}              // Close if()
else  {
  {
forloop120:
for (j = 1; j <= n-1; j++) {
Dlassq.dlassq((int) ( Math.min(n-j, k) ),ab,(2)- 1+(j- 1)*ldab+ _ab_offset,1,scale,sum);
Dummy.label("Dlansb",120);
}              //  Close for() loop. 
}
l = 1;
}              //  Close else.
sum.val = 2*sum.val;
}              // Close if()
else  {
  l = 1;
}              //  Close else.
Dlassq.dlassq(n,ab,(l)- 1+(1- 1)*ldab+ _ab_offset,ldab,scale,sum);
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlansb = value;
Dummy.go_to("Dlansb",999999);
// *
// *     End of DLANSB
// *
Dummy.label("Dlansb",999999);
return dlansb;
   }
} // End class.
