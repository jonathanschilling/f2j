/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlansp {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANSP  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the  element of  largest absolute value  of a
// *  real symmetric matrix A,  supplied in packed form.
// *
// *  Description
// *  ===========
// *
// *  DLANSP returns the value
// *
// *     DLANSP = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANSP as described
// *          above.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is supplied.
// *          = 'U':  Upper triangular part of A is supplied
// *          = 'L':  Lower triangular part of A is supplied
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.  When N = 0, DLANSP is
// *          set to zero.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangle of the symmetric matrix A, packed
// *          columnwise in a linear array.  The j-th column of A is stored
// *          in the array AP as follows:
// *          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L', AP(i + (j-1)*(2n-j)/2) = A(i,j) for j<=i<=n.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= N when NORM = 'I' or '1' or 'O'; otherwise,
// *          WORK is not referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int k= 0;
static double absa= 0.0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlansp = 0.0;


public static double dlansp (String norm,
String uplo,
int n,
double [] ap, int _ap_offset,
double [] work, int _work_offset)  {

if (n == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    k = 1;
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = k; i <= k+j-1; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlansp",10);
}              //  Close for() loop. 
}
k = k+j;
Dummy.label("Dlansp",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  k = 1;
{
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = k; i <= k+n-j; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlansp",30);
}              //  Close for() loop. 
}
k = k+n-j+1;
Dummy.label("Dlansp",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find normI(A) ( = norm1(A), since A is symmetric).
// *
value = zero;
k = 1;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop60:
for (j = 1; j <= n; j++) {
sum.val = zero;
{
forloop50:
for (i = 1; i <= j-1; i++) {
absa = Math.abs(ap[(k)- 1+ _ap_offset]);
sum.val = sum.val+absa;
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+absa;
k = k+1;
Dummy.label("Dlansp",50);
}              //  Close for() loop. 
}
work[(j)- 1+ _work_offset] = sum.val+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
Dummy.label("Dlansp",60);
}              //  Close for() loop. 
}
{
forloop70:
for (i = 1; i <= n; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlansp",70);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlansp",80);
}              //  Close for() loop. 
}
{
forloop100:
for (j = 1; j <= n; j++) {
sum.val = work[(j)- 1+ _work_offset]+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
{
forloop90:
for (i = j+1; i <= n; i++) {
absa = Math.abs(ap[(k)- 1+ _ap_offset]);
sum.val = sum.val+absa;
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+absa;
k = k+1;
Dummy.label("Dlansp",90);
}              //  Close for() loop. 
}
value = Math.max(value, sum.val) ;
Dummy.label("Dlansp",100);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
scale.val = zero;
sum.val = one;
k = 2;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop110:
for (j = 2; j <= n; j++) {
Dlassq.dlassq(j-1,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+j;
Dummy.label("Dlansp",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop120:
for (j = 1; j <= n-1; j++) {
Dlassq.dlassq(n-j,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+n-j+1;
Dummy.label("Dlansp",120);
}              //  Close for() loop. 
}
}              //  Close else.
sum.val = 2*sum.val;
k = 1;
{
forloop130:
for (i = 1; i <= n; i++) {
if (ap[(k)- 1+ _ap_offset] != zero)  {
    absa = Math.abs(ap[(k)- 1+ _ap_offset]);
if (scale.val < absa)  {
    sum.val = one+sum.val*Math.pow((scale.val/absa), 2);
scale.val = absa;
}              // Close if()
else  {
  sum.val = sum.val+Math.pow((absa/scale.val), 2);
}              //  Close else.
}              // Close if()
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    k = k+i+1;
}              // Close if()
else  {
  k = k+n-i+1;
}              //  Close else.
Dummy.label("Dlansp",130);
}              //  Close for() loop. 
}
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlansp = value;
Dummy.go_to("Dlansp",999999);
// *
// *     End of DLANSP
// *
Dummy.label("Dlansp",999999);
return dlansp;
   }
} // End class.
