/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlantb {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANTB  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the element of  largest absolute value  of an
// *  n by n triangular band matrix A,  with ( k + 1 ) diagonals.
// *
// *  Description
// *  ===========
// *
// *  DLANTB returns the value
// *
// *     DLANTB = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANTB as described
// *          above.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.  When N = 0, DLANTB is
// *          set to zero.
// *
// *  K       (input) INTEGER
// *          The number of super-diagonals of the matrix A if UPLO = 'U',
// *          or the number of sub-diagonals of the matrix A if UPLO = 'L'.
// *          K >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The upper or lower triangular band matrix A, stored in the
// *          first k+1 rows of AB.  The j-th column of A is stored
// *          in the j-th column of the array AB as follows:
// *          if UPLO = 'U', AB(k+1+i-j,j) = A(i,j) for max(1,j-k)<=i<=j;
// *          if UPLO = 'L', AB(1+i-j,j)   = A(i,j) for j<=i<=min(n,j+k).
// *          Note that when DIAG = 'U', the elements of the array AB
// *          corresponding to the diagonal elements of the matrix A are
// *          not referenced, but are assumed to be one.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= K+1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= N when NORM = 'I'; otherwise, WORK is not
// *          referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean udiag= false;
static int i= 0;
static int j= 0;
static int l= 0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlantb = 0.0;


public static double dlantb (String norm,
String uplo,
String diag,
int n,
int k,
double [] ab, int _ab_offset,
int ldab,
double [] work, int _work_offset)  {

if (n == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    value = one;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = (int)(Math.max(k+2-j, 1) ); i <= k; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlantb",10);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 2; i <= Math.min(n+1-j, k+1) ; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlantb",30);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = (int)(Math.max(k+2-j, 1) ); i <= k+1; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlantb",50);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (j = 1; j <= n; j++) {
{
forloop70:
for (i = 1; i <= Math.min(n+1-j, k+1) ; i++) {
value = Math.max(value, Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset])) ;
Dummy.label("Dlantb",70);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",80);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find norm1(A).
// *
value = zero;
udiag = (diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop110:
for (j = 1; j <= n; j++) {
if (udiag)  {
    sum.val = one;
{
forloop90:
for (i = (int)(Math.max(k+2-j, 1) ); i <= k; i++) {
sum.val = sum.val+Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",90);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop100:
for (i = (int)(Math.max(k+2-j, 1) ); i <= k+1; i++) {
sum.val = sum.val+Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",100);
}              //  Close for() loop. 
}
}              //  Close else.
value = Math.max(value, sum.val) ;
Dummy.label("Dlantb",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop140:
for (j = 1; j <= n; j++) {
if (udiag)  {
    sum.val = one;
{
forloop120:
for (i = 2; i <= Math.min(n+1-j, k+1) ; i++) {
sum.val = sum.val+Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",120);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop130:
for (i = 1; i <= Math.min(n+1-j, k+1) ; i++) {
sum.val = sum.val+Math.abs(ab[(i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",130);
}              //  Close for() loop. 
}
}              //  Close else.
value = Math.max(value, sum.val) ;
Dummy.label("Dlantb",140);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if ((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    // *
// *        Find normI(A).
// *
value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop150:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantb",150);
}              //  Close for() loop. 
}
{
forloop170:
for (j = 1; j <= n; j++) {
l = k+1-j;
{
forloop160:
for (i = (int)(Math.max(1, j-k) ); i <= j-1; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",160);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",170);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop180:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantb",180);
}              //  Close for() loop. 
}
{
forloop200:
for (j = 1; j <= n; j++) {
l = k+1-j;
{
forloop190:
for (i = (int)(Math.max(1, j-k) ); i <= j; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",190);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",200);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop210:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantb",210);
}              //  Close for() loop. 
}
{
forloop230:
for (j = 1; j <= n; j++) {
l = 1-j;
{
forloop220:
for (i = j+1; i <= Math.min(n, j+k) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",220);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",230);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop240:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantb",240);
}              //  Close for() loop. 
}
{
forloop260:
for (j = 1; j <= n; j++) {
l = 1-j;
{
forloop250:
for (i = j; i <= Math.min(n, j+k) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ab[(l+i)- 1+(j- 1)*ldab+ _ab_offset]);
Dummy.label("Dlantb",250);
}              //  Close for() loop. 
}
Dummy.label("Dlantb",260);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
{
forloop270:
for (i = 1; i <= n; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlantb",270);
}              //  Close for() loop. 
}
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = (double)(n);
if (k > 0)  {
    {
forloop280:
for (j = 2; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(j-1, k) ),ab,(int)((Math.max(k+2-j, 1) )- 1+(j- 1)*ldab+ _ab_offset),1,scale,sum);
Dummy.label("Dlantb",280);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
{
forloop290:
for (j = 1; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(j, k+1) ),ab,(int)((Math.max(k+2-j, 1) )- 1+(j- 1)*ldab+ _ab_offset),1,scale,sum);
Dummy.label("Dlantb",290);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = (double)(n);
if (k > 0)  {
    {
forloop300:
for (j = 1; j <= n-1; j++) {
Dlassq.dlassq((int) ( Math.min(n-j, k) ),ab,(2)- 1+(j- 1)*ldab+ _ab_offset,1,scale,sum);
Dummy.label("Dlantb",300);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
{
forloop310:
for (j = 1; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(n-j+1, k+1) ),ab,(1)- 1+(j- 1)*ldab+ _ab_offset,1,scale,sum);
Dummy.label("Dlantb",310);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlantb = value;
Dummy.go_to("Dlantb",999999);
// *
// *     End of DLANTB
// *
Dummy.label("Dlantb",999999);
return dlantb;
   }
} // End class.
