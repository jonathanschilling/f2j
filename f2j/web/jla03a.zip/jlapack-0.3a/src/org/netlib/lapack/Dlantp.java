/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlantp {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANTP  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the  element of  largest absolute value  of a
// *  triangular matrix A, supplied in packed form.
// *
// *  Description
// *  ===========
// *
// *  DLANTP returns the value
// *
// *     DLANTP = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANTP as described
// *          above.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.  When N = 0, DLANTP is
// *          set to zero.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangular matrix A, packed columnwise in
// *          a linear array.  The j-th column of A is stored in the array
// *          AP as follows:
// *          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L', AP(i + (j-1)*(2n-j)/2) = A(i,j) for j<=i<=n.
// *          Note that when DIAG = 'U', the elements of the array AP
// *          corresponding to the diagonal elements of the matrix A are
// *          not referenced, but are assumed to be one.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= N when NORM = 'I'; otherwise, WORK is not
// *          referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean udiag= false;
static int i= 0;
static int j= 0;
static int k= 0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlantp = 0.0;


public static double dlantp (String norm,
String uplo,
String diag,
int n,
double [] ap, int _ap_offset,
double [] work, int _work_offset)  {

if (n == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
k = 1;
if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    value = one;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = k; i <= k+j-2; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlantp",10);
}              //  Close for() loop. 
}
k = k+j;
Dummy.label("Dlantp",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = k+1; i <= k+n-j; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlantp",30);
}              //  Close for() loop. 
}
k = k+n-j+1;
Dummy.label("Dlantp",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = k; i <= k+j-1; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlantp",50);
}              //  Close for() loop. 
}
k = k+j;
Dummy.label("Dlantp",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (j = 1; j <= n; j++) {
{
forloop70:
for (i = k; i <= k+n-j; i++) {
value = Math.max(value, Math.abs(ap[(i)- 1+ _ap_offset])) ;
Dummy.label("Dlantp",70);
}              //  Close for() loop. 
}
k = k+n-j+1;
Dummy.label("Dlantp",80);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find norm1(A).
// *
value = zero;
k = 1;
udiag = (diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop110:
for (j = 1; j <= n; j++) {
if (udiag)  {
    sum.val = one;
{
forloop90:
for (i = k; i <= k+j-2; i++) {
sum.val = sum.val+Math.abs(ap[(i)- 1+ _ap_offset]);
Dummy.label("Dlantp",90);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop100:
for (i = k; i <= k+j-1; i++) {
sum.val = sum.val+Math.abs(ap[(i)- 1+ _ap_offset]);
Dummy.label("Dlantp",100);
}              //  Close for() loop. 
}
}              //  Close else.
k = k+j;
value = Math.max(value, sum.val) ;
Dummy.label("Dlantp",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop140:
for (j = 1; j <= n; j++) {
if (udiag)  {
    sum.val = one;
{
forloop120:
for (i = k+1; i <= k+n-j; i++) {
sum.val = sum.val+Math.abs(ap[(i)- 1+ _ap_offset]);
Dummy.label("Dlantp",120);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop130:
for (i = k; i <= k+n-j; i++) {
sum.val = sum.val+Math.abs(ap[(i)- 1+ _ap_offset]);
Dummy.label("Dlantp",130);
}              //  Close for() loop. 
}
}              //  Close else.
k = k+n-j+1;
value = Math.max(value, sum.val) ;
Dummy.label("Dlantp",140);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if ((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    // *
// *        Find normI(A).
// *
k = 1;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop150:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantp",150);
}              //  Close for() loop. 
}
{
forloop170:
for (j = 1; j <= n; j++) {
{
forloop160:
for (i = 1; i <= j-1; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
Dummy.label("Dlantp",160);
}              //  Close for() loop. 
}
k = k+1;
Dummy.label("Dlantp",170);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop180:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantp",180);
}              //  Close for() loop. 
}
{
forloop200:
for (j = 1; j <= n; j++) {
{
forloop190:
for (i = 1; i <= j; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
Dummy.label("Dlantp",190);
}              //  Close for() loop. 
}
Dummy.label("Dlantp",200);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop210:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantp",210);
}              //  Close for() loop. 
}
{
forloop230:
for (j = 1; j <= n; j++) {
k = k+1;
{
forloop220:
for (i = j+1; i <= n; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
Dummy.label("Dlantp",220);
}              //  Close for() loop. 
}
Dummy.label("Dlantp",230);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop240:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantp",240);
}              //  Close for() loop. 
}
{
forloop260:
for (j = 1; j <= n; j++) {
{
forloop250:
for (i = j; i <= n; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(ap[(k)- 1+ _ap_offset]);
k = k+1;
Dummy.label("Dlantp",250);
}              //  Close for() loop. 
}
Dummy.label("Dlantp",260);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
value = zero;
{
forloop270:
for (i = 1; i <= n; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlantp",270);
}              //  Close for() loop. 
}
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = (double)(n);
k = 2;
{
forloop280:
for (j = 2; j <= n; j++) {
Dlassq.dlassq(j-1,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+j;
Dummy.label("Dlantp",280);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
k = 1;
{
forloop290:
for (j = 1; j <= n; j++) {
Dlassq.dlassq(j,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+j;
Dummy.label("Dlantp",290);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = (double)(n);
k = 2;
{
forloop300:
for (j = 1; j <= n-1; j++) {
Dlassq.dlassq(n-j,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+n-j+1;
Dummy.label("Dlantp",300);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
k = 1;
{
forloop310:
for (j = 1; j <= n; j++) {
Dlassq.dlassq(n-j+1,ap,(k)- 1+ _ap_offset,1,scale,sum);
k = k+n-j+1;
Dummy.label("Dlantp",310);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlantp = value;
Dummy.go_to("Dlantp",999999);
// *
// *     End of DLANTP
// *
Dummy.label("Dlantp",999999);
return dlantp;
   }
} // End class.
