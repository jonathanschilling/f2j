/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlantr {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANTR  returns the value of the one norm,  or the Frobenius norm, or
// *  the  infinity norm,  or the  element of  largest absolute value  of a
// *  trapezoidal or triangular matrix A.
// *
// *  Description
// *  ===========
// *
// *  DLANTR returns the value
// *
// *     DLANTR = ( max(abs(A(i,j))), NORM = 'M' or 'm'
// *              (
// *              ( norm1(A),         NORM = '1', 'O' or 'o'
// *              (
// *              ( normI(A),         NORM = 'I' or 'i'
// *              (
// *              ( normF(A),         NORM = 'F', 'f', 'E' or 'e'
// *
// *  where  norm1  denotes the  one norm of a matrix (maximum column sum),
// *  normI  denotes the  infinity norm  of a matrix  (maximum row sum) and
// *  normF  denotes the  Frobenius norm of a matrix (square root of sum of
// *  squares).  Note that  max(abs(A(i,j)))  is not a  matrix norm.
// *
// *  Arguments
// *  =========
// *
// *  NORM    (input) CHARACTER*1
// *          Specifies the value to be returned in DLANTR as described
// *          above.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower trapezoidal.
// *          = 'U':  Upper trapezoidal
// *          = 'L':  Lower trapezoidal
// *          Note that A is triangular instead of trapezoidal if M = N.
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A has unit diagonal.
// *          = 'N':  Non-unit diagonal
// *          = 'U':  Unit diagonal
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0, and if
// *          UPLO = 'U', M <= N.  When M = 0, DLANTR is set to zero.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0, and if
// *          UPLO = 'L', N <= M.  When N = 0, DLANTR is set to zero.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The trapezoidal matrix A (A is triangular if M = N).
// *          If UPLO = 'U', the leading m by n upper trapezoidal part of
// *          the array A contains the upper trapezoidal matrix, and the
// *          strictly lower triangular part of A is not referenced.
// *          If UPLO = 'L', the leading m by n lower trapezoidal part of
// *          the array A contains the lower trapezoidal matrix, and the
// *          strictly upper triangular part of A is not referenced.  Note
// *          that when DIAG = 'U', the diagonal elements of A are not
// *          referenced and are assumed to be one.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(M,1).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK),
// *          where LWORK >= M when NORM = 'I'; otherwise, WORK is not
// *          referenced.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean udiag= false;
static int i= 0;
static int j= 0;
static doubleW scale= new doubleW(0.0);
static doubleW sum= new doubleW(0.0);
static double value= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlantr = 0.0;


public static double dlantr (String norm,
String uplo,
String diag,
int m,
int n,
double [] a, int _a_offset,
int lda,
double [] work, int _work_offset)  {

if (Math.min(m, n)  == 0)  {
    value = zero;
}              // Close if()
else if ((norm.toLowerCase().charAt(0) == "M".toLowerCase().charAt(0)))  {
    // *
// *        Find max(abs(A(i,j))).
// *
if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    value = one;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= Math.min(m, j-1) ; i++) {
value = Math.max(value, Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dlantr",10);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = j+1; i <= m; i++) {
value = Math.max(value, Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dlantr",30);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  value = zero;
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = 1; i <= Math.min(m, j) ; i++) {
value = Math.max(value, Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dlantr",50);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (j = 1; j <= n; j++) {
{
forloop70:
for (i = j; i <= m; i++) {
value = Math.max(value, Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset])) ;
Dummy.label("Dlantr",70);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",80);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0))) || (norm.trim().equalsIgnoreCase("1".trim())))  {
    // *
// *        Find norm1(A).
// *
value = zero;
udiag = (diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop110:
for (j = 1; j <= n; j++) {
if ((udiag) && (j <= m))  {
    sum.val = one;
{
forloop90:
for (i = 1; i <= j-1; i++) {
sum.val = sum.val+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",90);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop100:
for (i = 1; i <= Math.min(m, j) ; i++) {
sum.val = sum.val+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",100);
}              //  Close for() loop. 
}
}              //  Close else.
value = Math.max(value, sum.val) ;
Dummy.label("Dlantr",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop140:
for (j = 1; j <= n; j++) {
if (udiag)  {
    sum.val = one;
{
forloop120:
for (i = j+1; i <= m; i++) {
sum.val = sum.val+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",120);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  sum.val = zero;
{
forloop130:
for (i = j; i <= m; i++) {
sum.val = sum.val+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",130);
}              //  Close for() loop. 
}
}              //  Close else.
value = Math.max(value, sum.val) ;
Dummy.label("Dlantr",140);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
else if ((norm.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    // *
// *        Find normI(A).
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop150:
for (i = 1; i <= m; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantr",150);
}              //  Close for() loop. 
}
{
forloop170:
for (j = 1; j <= n; j++) {
{
forloop160:
for (i = 1; i <= Math.min(m, j-1) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",160);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",170);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop180:
for (i = 1; i <= m; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantr",180);
}              //  Close for() loop. 
}
{
forloop200:
for (j = 1; j <= n; j++) {
{
forloop190:
for (i = 1; i <= Math.min(m, j) ; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",190);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",200);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop210:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = one;
Dummy.label("Dlantr",210);
}              //  Close for() loop. 
}
{
forloop220:
for (i = n+1; i <= m; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantr",220);
}              //  Close for() loop. 
}
{
forloop240:
for (j = 1; j <= n; j++) {
{
forloop230:
for (i = j+1; i <= m; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",230);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",240);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop250:
for (i = 1; i <= m; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dlantr",250);
}              //  Close for() loop. 
}
{
forloop270:
for (j = 1; j <= n; j++) {
{
forloop260:
for (i = j; i <= m; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(a[(i)- 1+(j- 1)*lda+ _a_offset]);
Dummy.label("Dlantr",260);
}              //  Close for() loop. 
}
Dummy.label("Dlantr",270);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
value = zero;
{
forloop280:
for (i = 1; i <= m; i++) {
value = Math.max(value, work[(i)- 1+ _work_offset]) ;
Dummy.label("Dlantr",280);
}              //  Close for() loop. 
}
}              // Close else if()
else if (((norm.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0))) || ((norm.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0))))  {
    // *
// *        Find normF(A).
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = Math.min(m, n) ;
{
forloop290:
for (j = 2; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(m, j-1) ),a,(1)- 1+(j- 1)*lda+ _a_offset,1,scale,sum);
Dummy.label("Dlantr",290);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
{
forloop300:
for (j = 1; j <= n; j++) {
Dlassq.dlassq((int) ( Math.min(m, j) ),a,(1)- 1+(j- 1)*lda+ _a_offset,1,scale,sum);
Dummy.label("Dlantr",300);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    scale.val = one;
sum.val = Math.min(m, n) ;
{
forloop310:
for (j = 1; j <= n; j++) {
Dlassq.dlassq(m-j,a,(int)((Math.min(m, j+1) )- 1+(j- 1)*lda+ _a_offset),1,scale,sum);
Dummy.label("Dlantr",310);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  scale.val = zero;
sum.val = one;
{
forloop320:
for (j = 1; j <= n; j++) {
Dlassq.dlassq(m-j+1,a,(j)- 1+(j- 1)*lda+ _a_offset,1,scale,sum);
Dummy.label("Dlantr",320);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
value = scale.val*Math.sqrt(sum.val);
}              // Close else if()
// *
dlantr = value;
Dummy.go_to("Dlantr",999999);
// *
// *     End of DLANTR
// *
Dummy.label("Dlantr",999999);
return dlantr;
   }
} // End class.
