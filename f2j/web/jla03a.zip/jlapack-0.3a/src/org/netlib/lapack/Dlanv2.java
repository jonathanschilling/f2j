/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlanv2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994 
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLANV2 computes the Schur factorization of a real 2-by-2 nonsymmetric
// *  matrix in standard form:
// *
// *       [ A  B ] = [ CS -SN ] [ AA  BB ] [ CS  SN ]
// *       [ C  D ]   [ SN  CS ] [ CC  DD ] [-SN  CS ]
// *
// *  where either
// *  1) CC = 0 so that AA and DD are real eigenvalues of the matrix, or
// *  2) AA = DD and BB*CC < 0, so that AA + or - sqrt(BB*CC) are complex
// *  conjugate eigenvalues.
// *
// *  Arguments
// *  =========
// *
// *  A       (input/output) DOUBLE PRECISION
// *  B       (input/output) DOUBLE PRECISION
// *  C       (input/output) DOUBLE PRECISION
// *  D       (input/output) DOUBLE PRECISION
// *          On entry, the elements of the input matrix.
// *          On exit, they are overwritten by the elements of the
// *          standardised Schur form.
// *
// *  RT1R    (output) DOUBLE PRECISION
// *  RT1I    (output) DOUBLE PRECISION
// *  RT2R    (output) DOUBLE PRECISION
// *  RT2I    (output) DOUBLE PRECISION
// *          The real and imaginary parts of the eigenvalues. If the
// *          eigenvalues are both real, abs(RT1R) >= abs(RT2R); if the
// *          eigenvalues are a complex conjugate pair, RT1I > 0.
// *
// *  CS      (output) DOUBLE PRECISION
// *  SN      (output) DOUBLE PRECISION
// *          Parameters of the rotation matrix.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double half= 0.5e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static double aa= 0.0;
static double bb= 0.0;
static double cc= 0.0;
static double cs1= 0.0;
static double dd= 0.0;
static double p= 0.0;
static double sab= 0.0;
static double sac= 0.0;
static double sigma= 0.0;
static double sn1= 0.0;
static double tau= 0.0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize CS and SN
// *

public static void dlanv2 (doubleW a,
doubleW b,
doubleW c,
doubleW d,
doubleW rt1r,
doubleW rt1i,
doubleW rt2r,
doubleW rt2i,
doubleW cs,
doubleW sn)  {

cs.val = one;
sn.val = zero;
// *
if (c.val == zero)  {
    Dummy.go_to("Dlanv2",10);
// *
}              // Close if()
else if (b.val == zero)  {
    // *
// *        Swap rows and columns
// *
cs.val = zero;
sn.val = one;
temp = d.val;
d.val = a.val;
a.val = temp;
b.val = -c.val;
c.val = zero;
Dummy.go_to("Dlanv2",10);
}              // Close else if()
else if ((a.val-d.val) == zero && ((b.val) >= 0 ? Math.abs(one) : -Math.abs(one)) != ((c.val) >= 0 ? Math.abs(one) : -Math.abs(one)))  {
    Dummy.go_to("Dlanv2",10);
}              // Close else if()
else  {
  // *
// *        Make diagonal elements equal
// *
temp = a.val-d.val;
p = half*temp;
sigma = b.val+c.val;
tau = Dlapy2.dlapy2(sigma,temp);
cs1 = Math.sqrt(half*(one+Math.abs(sigma)/tau));
sn1 = -(p/(tau*cs1))*((sigma) >= 0 ? Math.abs(one) : -Math.abs(one));
// *
// *        Compute [ AA  BB ] = [ A  B ] [ CS1 -SN1 ]
// *                [ CC  DD ]   [ C  D ] [ SN1  CS1 ]
// *
aa = a.val*cs1+b.val*sn1;
bb = -a.val*sn1+b.val*cs1;
cc = c.val*cs1+d.val*sn1;
dd = -c.val*sn1+d.val*cs1;
// *
// *        Compute [ A  B ] = [ CS1  SN1 ] [ AA  BB ]
// *                [ C  D ]   [-SN1  CS1 ] [ CC  DD ]
// *
a.val = aa*cs1+cc*sn1;
b.val = bb*cs1+dd*sn1;
c.val = -aa*sn1+cc*cs1;
d.val = -bb*sn1+dd*cs1;
// *
// *        Accumulate transformation
// *
temp = cs.val*cs1-sn.val*sn1;
sn.val = cs.val*sn1+sn.val*cs1;
cs.val = temp;
// *
temp = half*(a.val+d.val);
a.val = temp;
d.val = temp;
// *
if (c.val != zero)  {
    if (b.val != zero)  {
    if (((b.val) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((c.val) >= 0 ? Math.abs(one) : -Math.abs(one)))  {
    // *
// *                 Real eigenvalues: reduce to upper triangular form
// *
sab = Math.sqrt(Math.abs(b.val));
sac = Math.sqrt(Math.abs(c.val));
p = ((c.val) >= 0 ? Math.abs(sab*sac) : -Math.abs(sab*sac));
tau = one/Math.sqrt(Math.abs(b.val+c.val));
a.val = temp+p;
d.val = temp-p;
b.val = b.val-c.val;
c.val = zero;
cs1 = sab*tau;
sn1 = sac*tau;
temp = cs.val*cs1-sn.val*sn1;
sn.val = cs.val*sn1+sn.val*cs1;
cs.val = temp;
}              // Close if()
}              // Close if()
else  {
  b.val = -c.val;
c.val = zero;
temp = cs.val;
cs.val = -sn.val;
sn.val = temp;
}              //  Close else.
}              // Close if()
}              //  Close else.
// *
label10:
   Dummy.label("Dlanv2",10);
// *
// *     Store eigenvalues in (RT1R,RT1I) and (RT2R,RT2I).
// *
rt1r.val = a.val;
rt2r.val = d.val;
if (c.val == zero)  {
    rt1i.val = zero;
rt2i.val = zero;
}              // Close if()
else  {
  rt1i.val = Math.sqrt(Math.abs(b.val))*Math.sqrt(Math.abs(c.val));
rt2i.val = -rt1i.val;
}              //  Close else.
Dummy.go_to("Dlanv2",999999);
// *
// *     End of DLANV2
// *
Dummy.label("Dlanv2",999999);
return;
   }
} // End class.
