/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaord {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAORD sorts the elements of a vector x in increasing or decreasing
// *  order.
// *
// *  Arguments
// *  =========
// *
// *  JOB     (input) CHARACTER
// *          = 'I':  Sort in increasing order
// *          = 'D':  Sort in decreasing order
// *
// *  N       (input) INTEGER
// *          The length of the vector X.
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension
// *                         (1+(N-1)*INCX)
// *          On entry, the vector of length n to be sorted.
// *          On exit, the vector x is sorted in the prescribed order.
// *
// *  INCX    (input) INTEGER
// *          The spacing between successive elements of X.  INCX >= 0.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int inc= 0;
static int ix= 0;
static int ixnext= 0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaord (String job,
int n,
double [] x, int _x_offset,
int incx)  {

inc = (int)(Math.abs(incx));
if ((job.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    // *
// *        Sort in increasing order
// *
{
forloop20:
for (i = 2; i <= n; i++) {
ix = 1+(i-1)*inc;
label10:
   Dummy.label("Dlaord",10);
if (ix == 1)  
    continue forloop20;
ixnext = ix-inc;
if (x[(ix)- 1+ _x_offset] > x[(ixnext)- 1+ _x_offset])  {
    continue forloop20;
}              // Close if()
else  {
  temp = x[(ix)- 1+ _x_offset];
x[(ix)- 1+ _x_offset] = x[(ixnext)- 1+ _x_offset];
x[(ixnext)- 1+ _x_offset] = temp;
}              //  Close else.
ix = ixnext;
Dummy.go_to("Dlaord",10);
Dummy.label("Dlaord",20);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((job.toLowerCase().charAt(0) == "D".toLowerCase().charAt(0)))  {
    // *
// *        Sort in decreasing order
// *
{
forloop40:
for (i = 2; i <= n; i++) {
ix = 1+(i-1)*inc;
label30:
   Dummy.label("Dlaord",30);
if (ix == 1)  
    continue forloop40;
ixnext = ix-inc;
if (x[(ix)- 1+ _x_offset] < x[(ixnext)- 1+ _x_offset])  {
    continue forloop40;
}              // Close if()
else  {
  temp = x[(ix)- 1+ _x_offset];
x[(ix)- 1+ _x_offset] = x[(ixnext)- 1+ _x_offset];
x[(ixnext)- 1+ _x_offset] = temp;
}              //  Close else.
ix = ixnext;
Dummy.go_to("Dlaord",30);
Dummy.label("Dlaord",40);
}              //  Close for() loop. 
}
}              // Close else if()
Dummy.go_to("Dlaord",999999);
// *
// *     End of DLAORD
// *
Dummy.label("Dlaord",999999);
return;
   }
} // End class.
