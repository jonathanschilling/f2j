/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlapll {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  Given two column vectors X and Y, let
// *
// *                       A = ( X Y ).
// *
// *  The subroutine first computes the QR factorization of A = Q*R,
// *  and then computes the SVD of the 2-by-2 upper triangular matrix R.
// *  The smaller singular value of R is returned in SSMIN, which is used
// *  as the measurement of the linear dependency of the vectors X and Y.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The length of the vectors X and Y.
// *
// *  X       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCX)
// *          On entry, X contains the N-vector X.
// *          On exit, X is overwritten.
// *
// *  INCX    (input) INTEGER
// *          The increment between successive elements of X. INCX > 0.
// *
// *  Y       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCY)
// *          On entry, Y contains the N-vector Y.
// *          On exit, Y is overwritten.
// *
// *  INCY    (input) INTEGER
// *          The increment between successive elements of Y. INCY > 0.
// *
// *  SSMIN   (output) DOUBLE PRECISION
// *          The smallest singular value of the N-by-2 matrix A = ( X Y ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static double a11= 0.0;
static double a12= 0.0;
static double a22= 0.0;
static double c= 0.0;
static doubleW ssmax= new doubleW(0.0);
static doubleW tau= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlapll (int n,
double [] x, int _x_offset,
int incx,
double [] y, int _y_offset,
int incy,
doubleW ssmin)  {

if (n <= 1)  {
    ssmin.val = zero;
Dummy.go_to("Dlapll",999999);
}              // Close if()
// *
// *     Compute the QR factorization of the N-by-2 matrix ( X Y )
// *
dlarfg_adapter(n,x,(1)- 1+ _x_offset,x,(1+incx)- 1+ _x_offset,incx,tau);
a11 = x[(1)- 1+ _x_offset];
x[(1)- 1+ _x_offset] = one;
// *
c = -tau.val*Ddot.ddot(n,x,_x_offset,incx,y,_y_offset,incy);
Daxpy.daxpy(n,c,x,_x_offset,incx,y,_y_offset,incy);
// *
dlarfg_adapter(n-1,y,(1+incy)- 1+ _y_offset,y,(1+2*incy)- 1+ _y_offset,incy,tau);
// *
a12 = y[(1)- 1+ _y_offset];
a22 = y[(1+incy)- 1+ _y_offset];
// *
// *     Compute the SVD of 2-by-2 Upper triangular matrix.
// *
Dlas2.dlas2(a11,a12,a22,ssmin,ssmax);
// *
Dummy.go_to("Dlapll",999999);
// *
// *     End of DLAPLL
// *
Dummy.label("Dlapll",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,doubleW arg4 )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,arg4);

arg1[arg1_offset] = _f2j_tmp1.val;
}

} // End class.
