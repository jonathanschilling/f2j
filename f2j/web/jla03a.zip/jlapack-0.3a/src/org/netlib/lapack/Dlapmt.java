/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlapmt {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAPMT rearranges the columns of the M by N matrix X as specified
// *  by the permutation K(1),K(2),...,K(N) of the integers 1,...,N.
// *  If FORWRD = .TRUE.,  forward permutation:
// *
// *       X(*,K(J)) is moved X(*,J) for J = 1,2,...,N.
// *
// *  If FORWRD = .FALSE., backward permutation:
// *
// *       X(*,J) is moved to X(*,K(J)) for J = 1,2,...,N.
// *
// *  Arguments
// *  =========
// *
// *  FORWRD  (input) LOGICAL
// *          = .TRUE., forward permutation
// *          = .FALSE., backward permutation
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix X. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix X. N >= 0.
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension (LDX,N)
// *          On entry, the M by N matrix X.
// *          On exit, X contains the permuted matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X, LDX >= MAX(1,M).
// *
// *  K       (input) INTEGER array, dimension (N)
// *          On entry, K contains the permutation vector.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int ii= 0;
static int in= 0;
static int j= 0;
static double temp= 0.0;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlapmt (boolean forwrd,
int m,
int n,
double [] x, int _x_offset,
int ldx,
int [] k, int _k_offset)  {

if (n <= 1)  
    Dummy.go_to("Dlapmt",999999);
// *
{
forloop10:
for (i = 1; i <= n; i++) {
k[(i)- 1+ _k_offset] = -k[(i)- 1+ _k_offset];
Dummy.label("Dlapmt",10);
}              //  Close for() loop. 
}
// *
if (forwrd)  {
    // *
// *        Forward permutation
// *
{
forloop50:
for (i = 1; i <= n; i++) {
// *
if (k[(i)- 1+ _k_offset] > 0)  
    Dummy.go_to("Dlapmt",40);
// *
j = i;
k[(j)- 1+ _k_offset] = -k[(j)- 1+ _k_offset];
in = k[(j)- 1+ _k_offset];
// *
label20:
   Dummy.label("Dlapmt",20);
if (k[(in)- 1+ _k_offset] > 0)  
    Dummy.go_to("Dlapmt",40);
// *
{
forloop30:
for (ii = 1; ii <= m; ii++) {
temp = x[(ii)- 1+(j- 1)*ldx+ _x_offset];
x[(ii)- 1+(j- 1)*ldx+ _x_offset] = x[(ii)- 1+(in- 1)*ldx+ _x_offset];
x[(ii)- 1+(in- 1)*ldx+ _x_offset] = temp;
Dummy.label("Dlapmt",30);
}              //  Close for() loop. 
}
// *
k[(in)- 1+ _k_offset] = -k[(in)- 1+ _k_offset];
j = in;
in = k[(in)- 1+ _k_offset];
Dummy.go_to("Dlapmt",20);
// *
label40:
   Dummy.label("Dlapmt",40);
// *
Dummy.label("Dlapmt",50);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *        Backward permutation
// *
{
forloop90:
for (i = 1; i <= n; i++) {
// *
if (k[(i)- 1+ _k_offset] > 0)  
    Dummy.go_to("Dlapmt",80);
// *
k[(i)- 1+ _k_offset] = -k[(i)- 1+ _k_offset];
j = k[(i)- 1+ _k_offset];
label60:
   Dummy.label("Dlapmt",60);
if (j == i)  
    Dummy.go_to("Dlapmt",80);
// *
{
forloop70:
for (ii = 1; ii <= m; ii++) {
temp = x[(ii)- 1+(i- 1)*ldx+ _x_offset];
x[(ii)- 1+(i- 1)*ldx+ _x_offset] = x[(ii)- 1+(j- 1)*ldx+ _x_offset];
x[(ii)- 1+(j- 1)*ldx+ _x_offset] = temp;
Dummy.label("Dlapmt",70);
}              //  Close for() loop. 
}
// *
k[(j)- 1+ _k_offset] = -k[(j)- 1+ _k_offset];
j = k[(j)- 1+ _k_offset];
Dummy.go_to("Dlapmt",60);
// *
label80:
   Dummy.label("Dlapmt",80);
// *
Dummy.label("Dlapmt",90);
}              //  Close for() loop. 
}
// *
}              //  Close else.
// *
Dummy.go_to("Dlapmt",999999);
// *
// *     End of DLAPMT
// *
Dummy.label("Dlapmt",999999);
return;
   }
} // End class.
