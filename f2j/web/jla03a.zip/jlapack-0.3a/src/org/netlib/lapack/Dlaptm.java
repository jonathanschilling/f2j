/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaptm {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAPTM multiplies an N by NRHS matrix X by a symmetric tridiagonal
// *  matrix A and stores the result in a matrix B.  The operation has the
// *  form
// *
// *     B := alpha * A * X + beta * B
// *
// *  where alpha may be either 1. or -1. and beta may be 0., 1., or -1.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices X and B.
// *
// *  ALPHA   (input) DOUBLE PRECISION
// *          The scalar alpha.  ALPHA must be 1. or -1.; otherwise,
// *          it is assumed to be 0.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the tridiagonal matrix A.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal or superdiagonal elements of A.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The N by NRHS matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(N,1).
// *
// *  BETA    (input) DOUBLE PRECISION
// *          The scalar beta.  BETA must be 0., 1., or -1.; otherwise,
// *          it is assumed to be 1.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the N by NRHS matrix B.
// *          On exit, B is overwritten by the matrix expression
// *          B := alpha * A * X + beta * B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(N,1).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaptm (int n,
int nrhs,
double alpha,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] x, int _x_offset,
int ldx,
double beta,
double [] b, int _b_offset,
int ldb)  {

if (n == 0)  
    Dummy.go_to("Dlaptm",999999);
// *
// *     Multiply B by BETA if BETA.NE.1.
// *
if (beta == zero)  {
    {
forloop20:
for (j = 1; j <= nrhs; j++) {
{
forloop10:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = zero;
Dummy.label("Dlaptm",10);
}              //  Close for() loop. 
}
Dummy.label("Dlaptm",20);
}              //  Close for() loop. 
}
}              // Close if()
else if (beta == -one)  {
    {
forloop40:
for (j = 1; j <= nrhs; j++) {
{
forloop30:
for (i = 1; i <= n; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = -b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Dlaptm",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaptm",40);
}              //  Close for() loop. 
}
}              // Close else if()
// *
if (alpha == one)  {
    // *
// *        Compute B := B + A*X
// *
{
forloop60:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]+d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]+e[(1)- 1+ _e_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]+e[(n-1)- 1+ _e_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]+d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop50:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]+e[(i-1)- 1+ _e_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]+d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]+e[(i)- 1+ _e_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlaptm",50);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlaptm",60);
}              //  Close for() loop. 
}
}              // Close if()
else if (alpha == -one)  {
    // *
// *        Compute B := B - A*X
// *
{
forloop80:
for (j = 1; j <= nrhs; j++) {
if (n == 1)  {
    b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset];
}              // Close if()
else  {
  b[(1)- 1+(j- 1)*ldb+ _b_offset] = b[(1)- 1+(j- 1)*ldb+ _b_offset]-d[(1)- 1+ _d_offset]*x[(1)- 1+(j- 1)*ldx+ _x_offset]-e[(1)- 1+ _e_offset]*x[(2)- 1+(j- 1)*ldx+ _x_offset];
b[(n)- 1+(j- 1)*ldb+ _b_offset] = b[(n)- 1+(j- 1)*ldb+ _b_offset]-e[(n-1)- 1+ _e_offset]*x[(n-1)- 1+(j- 1)*ldx+ _x_offset]-d[(n)- 1+ _d_offset]*x[(n)- 1+(j- 1)*ldx+ _x_offset];
{
forloop70:
for (i = 2; i <= n-1; i++) {
b[(i)- 1+(j- 1)*ldb+ _b_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset]-e[(i-1)- 1+ _e_offset]*x[(i-1)- 1+(j- 1)*ldx+ _x_offset]-d[(i)- 1+ _d_offset]*x[(i)- 1+(j- 1)*ldx+ _x_offset]-e[(i)- 1+ _e_offset]*x[(i+1)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dlaptm",70);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dlaptm",80);
}              //  Close for() loop. 
}
}              // Close else if()
Dummy.go_to("Dlaptm",999999);
// *
// *     End of DLAPTM
// *
Dummy.label("Dlaptm",999999);
return;
   }
} // End class.
