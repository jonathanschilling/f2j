/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlapy2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAPY2 returns sqrt(x**2+y**2), taking care not to cause unnecessary
// *  overflow.
// *
// *  Arguments
// *  =========
// *
// *  X       (input) DOUBLE PRECISION
// *  Y       (input) DOUBLE PRECISION
// *          X and Y specify the values x and y.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static double w= 0.0;
static double xabs= 0.0;
static double yabs= 0.0;
static double z= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlapy2 = 0.0;


public static double dlapy2 (double x,
double y)  {

xabs = Math.abs(x);
yabs = Math.abs(y);
w = Math.max(xabs, yabs) ;
z = Math.min(xabs, yabs) ;
if (z == zero)  {
    dlapy2 = w;
}              // Close if()
else  {
  dlapy2 = w*Math.sqrt(one+Math.pow((z/w), 2));
}              //  Close else.
Dummy.go_to("Dlapy2",999999);
// *
// *     End of DLAPY2
// *
Dummy.label("Dlapy2",999999);
return dlapy2;
   }
} // End class.
