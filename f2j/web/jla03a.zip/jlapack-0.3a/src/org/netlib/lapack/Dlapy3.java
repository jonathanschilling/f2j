/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlapy3 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAPY3 returns sqrt(x**2+y**2+z**2), taking care not to cause
// *  unnecessary overflow.
// *
// *  Arguments
// *  =========
// *
// *  X       (input) DOUBLE PRECISION
// *  Y       (input) DOUBLE PRECISION
// *  Z       (input) DOUBLE PRECISION
// *          X, Y and Z specify the values x, y and z.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static double w= 0.0;
static double xabs= 0.0;
static double yabs= 0.0;
static double zabs= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dlapy3 = 0.0;


public static double dlapy3 (double x,
double y,
double z)  {

xabs = Math.abs(x);
yabs = Math.abs(y);
zabs = Math.abs(z);
w = Math.max((xabs) > (yabs) ? (xabs) : (yabs), zabs);
if (w == zero)  {
    dlapy3 = zero;
}              // Close if()
else  {
  dlapy3 = w*Math.sqrt(Math.pow((xabs/w), 2)+Math.pow((yabs/w), 2)+Math.pow((zabs/w), 2));
}              //  Close else.
Dummy.go_to("Dlapy3",999999);
// *
// *     End of DLAPY3
// *
Dummy.label("Dlapy3",999999);
return dlapy3;
   }
} // End class.
