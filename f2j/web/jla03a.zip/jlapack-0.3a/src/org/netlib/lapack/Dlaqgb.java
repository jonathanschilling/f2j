/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaqgb {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAQGB equilibrates a general M by N band matrix A with KL
// *  subdiagonals and KU superdiagonals using the row and scaling factors
// *  in the vectors R and C.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  AB      (input/output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          On entry, the matrix A in band storage, in rows 1 to KL+KU+1.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(m,j+kl)
// *
// *          On exit, the equilibrated matrix, in the same storage format
// *          as A.  See EQUED for the form of the equilibrated matrix.
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDA >= KL+KU+1.
// *
// *  R       (output) DOUBLE PRECISION array, dimension (M)
// *          The row scale factors for A.
// *
// *  C       (output) DOUBLE PRECISION array, dimension (N)
// *          The column scale factors for A.
// *
// *  ROWCND  (output) DOUBLE PRECISION
// *          Ratio of the smallest R(i) to the largest R(i).
// *
// *  COLCND  (output) DOUBLE PRECISION
// *          Ratio of the smallest C(i) to the largest C(i).
// *
// *  AMAX    (input) DOUBLE PRECISION
// *          Absolute value of largest matrix entry.
// *
// *  EQUED   (output) CHARACTER*1
// *          Specifies the form of equilibration that was done.
// *          = 'N':  No equilibration
// *          = 'R':  Row equilibration, i.e., A has been premultiplied by
// *                  diag(R).
// *          = 'C':  Column equilibration, i.e., A has been postmultiplied
// *                  by diag(C).
// *          = 'B':  Both row and column equilibration, i.e., A has been
// *                  replaced by diag(R) * A * diag(C).
// *
// *  Internal Parameters
// *  ===================
// *
// *  THRESH is a threshold value used to decide if row or column scaling
// *  should be done based on the ratio of the row or column scaling
// *  factors.  If ROWCND < THRESH, row scaling is done, and if
// *  COLCND < THRESH, column scaling is done.
// *
// *  LARGE and SMALL are threshold values used to decide if row scaling
// *  should be done based on the absolute size of the largest matrix
// *  element.  If AMAX > LARGE or AMAX < SMALL, row scaling is done.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double thresh= 0.1e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double cj= 0.0;
static double large= 0.0;
static double small= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlaqgb (int m,
int n,
int kl,
int ku,
double [] ab, int _ab_offset,
int ldab,
double [] r, int _r_offset,
double [] c, int _c_offset,
double rowcnd,
double colcnd,
double amax,
StringW equed)  {

if (m <= 0 || n <= 0)  {
    equed.val = "N";
Dummy.go_to("Dlaqgb",999999);
}              // Close if()
// *
// *     Initialize LARGE and SMALL.
// *
small = Dlamch.dlamch("Safe minimum")/Dlamch.dlamch("Precision");
large = one/small;
// *
if (rowcnd >= thresh && amax >= small && amax <= large)  {
    // *
// *        No row scaling
// *
if (colcnd >= thresh)  {
    // *
// *           No column scaling
// *
equed.val = "N";
}              // Close if()
else  {
  // *
// *           Column scaling
// *
{
forloop20:
for (j = 1; j <= n; j++) {
cj = c[(j)- 1+ _c_offset];
{
forloop10:
for (i = (int)(Math.max(1, j-ku) ); i <= Math.min(m, j+kl) ; i++) {
ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset] = cj*ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset];
Dummy.label("Dlaqgb",10);
}              //  Close for() loop. 
}
Dummy.label("Dlaqgb",20);
}              //  Close for() loop. 
}
equed.val = "C";
}              //  Close else.
}              // Close if()
else if (colcnd >= thresh)  {
    // *
// *        Row scaling, no column scaling
// *
{
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = (int)(Math.max(1, j-ku) ); i <= Math.min(m, j+kl) ; i++) {
ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset] = r[(i)- 1+ _r_offset]*ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset];
Dummy.label("Dlaqgb",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaqgb",40);
}              //  Close for() loop. 
}
equed.val = "R";
}              // Close else if()
else  {
  // *
// *        Row and column scaling
// *
{
forloop60:
for (j = 1; j <= n; j++) {
cj = c[(j)- 1+ _c_offset];
{
forloop50:
for (i = (int)(Math.max(1, j-ku) ); i <= Math.min(m, j+kl) ; i++) {
ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset] = cj*r[(i)- 1+ _r_offset]*ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset];
Dummy.label("Dlaqgb",50);
}              //  Close for() loop. 
}
Dummy.label("Dlaqgb",60);
}              //  Close for() loop. 
}
equed.val = "B";
}              //  Close else.
// *
Dummy.go_to("Dlaqgb",999999);
// *
// *     End of DLAQGB
// *
Dummy.label("Dlaqgb",999999);
return;
   }
} // End class.
