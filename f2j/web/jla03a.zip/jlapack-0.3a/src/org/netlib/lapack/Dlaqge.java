/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaqge {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAQGE equilibrates a general M by N matrix A using the row and
// *  scaling factors in the vectors R and C.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the M by N matrix A.
// *          On exit, the equilibrated matrix.  See EQUED for the form of
// *          the equilibrated matrix.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(M,1).
// *
// *  R       (input) DOUBLE PRECISION array, dimension (M)
// *          The row scale factors for A.
// *
// *  C       (input) DOUBLE PRECISION array, dimension (N)
// *          The column scale factors for A.
// *
// *  ROWCND  (input) DOUBLE PRECISION
// *          Ratio of the smallest R(i) to the largest R(i).
// *
// *  COLCND  (input) DOUBLE PRECISION
// *          Ratio of the smallest C(i) to the largest C(i).
// *
// *  AMAX    (input) DOUBLE PRECISION
// *          Absolute value of largest matrix entry.
// *
// *  EQUED   (output) CHARACTER*1
// *          Specifies the form of equilibration that was done.
// *          = 'N':  No equilibration
// *          = 'R':  Row equilibration, i.e., A has been premultiplied by
// *                  diag(R).
// *          = 'C':  Column equilibration, i.e., A has been postmultiplied
// *                  by diag(C).
// *          = 'B':  Both row and column equilibration, i.e., A has been
// *                  replaced by diag(R) * A * diag(C).
// *
// *  Internal Parameters
// *  ===================
// *
// *  THRESH is a threshold value used to decide if row or column scaling
// *  should be done based on the ratio of the row or column scaling
// *  factors.  If ROWCND < THRESH, row scaling is done, and if
// *  COLCND < THRESH, column scaling is done.
// *
// *  LARGE and SMALL are threshold values used to decide if row scaling
// *  should be done based on the absolute size of the largest matrix
// *  element.  If AMAX > LARGE or AMAX < SMALL, row scaling is done.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double thresh= 0.1e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double cj= 0.0;
static double large= 0.0;
static double small= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlaqge (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] r, int _r_offset,
double [] c, int _c_offset,
double rowcnd,
double colcnd,
double amax,
StringW equed)  {

if (m <= 0 || n <= 0)  {
    equed.val = "N";
Dummy.go_to("Dlaqge",999999);
}              // Close if()
// *
// *     Initialize LARGE and SMALL.
// *
small = Dlamch.dlamch("Safe minimum")/Dlamch.dlamch("Precision");
large = one/small;
// *
if (rowcnd >= thresh && amax >= small && amax <= large)  {
    // *
// *        No row scaling
// *
if (colcnd >= thresh)  {
    // *
// *           No column scaling
// *
equed.val = "N";
}              // Close if()
else  {
  // *
// *           Column scaling
// *
{
forloop20:
for (j = 1; j <= n; j++) {
cj = c[(j)- 1+ _c_offset];
{
forloop10:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = cj*a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlaqge",10);
}              //  Close for() loop. 
}
Dummy.label("Dlaqge",20);
}              //  Close for() loop. 
}
equed.val = "C";
}              //  Close else.
}              // Close if()
else if (colcnd >= thresh)  {
    // *
// *        Row scaling, no column scaling
// *
{
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = r[(i)- 1+ _r_offset]*a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlaqge",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaqge",40);
}              //  Close for() loop. 
}
equed.val = "R";
}              // Close else if()
else  {
  // *
// *        Row and column scaling
// *
{
forloop60:
for (j = 1; j <= n; j++) {
cj = c[(j)- 1+ _c_offset];
{
forloop50:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = cj*r[(i)- 1+ _r_offset]*a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlaqge",50);
}              //  Close for() loop. 
}
Dummy.label("Dlaqge",60);
}              //  Close for() loop. 
}
equed.val = "B";
}              //  Close else.
// *
Dummy.go_to("Dlaqge",999999);
// *
// *     End of DLAQGE
// *
Dummy.label("Dlaqge",999999);
return;
   }
} // End class.
