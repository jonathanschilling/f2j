/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaqtr {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAQTR solves the real quasi-triangular system
// *
// *               op(T)*p = scale*c,               if LREAL = .TRUE.
// *
// *  or the complex quasi-triangular systems
// *
// *             op(T + iB)*(p+iq) = scale*(c+id),  if LREAL = .FALSE.
// *
// *  in real arithmetic, where T is upper quasi-triangular.
// *  If LREAL = .FALSE., then the first diagonal block of T must be
// *  1 by 1, B is the specially structured matrix
// *
// *                 B = [ b(1) b(2) ... b(n) ]
// *                     [       w            ]
// *                     [           w        ]
// *                     [              .     ]
// *                     [                 w  ]
// *
// *  op(A) = A or A', A' denotes the conjugate transpose of
// *  matrix A.
// *
// *  On input, X = [ c ].  On output, X = [ p ].
// *                [ d ]                  [ q ]
// *
// *  This subroutine is designed for the condition number estimation
// *  in routine DTRSNA.
// *
// *  Arguments
// *  =========
// *
// *  LTRAN   (input) LOGICAL
// *          On entry, LTRAN specifies the option of conjugate transpose:
// *             = .FALSE.,    op(T+i*B) = T+i*B,
// *             = .TRUE.,     op(T+i*B) = (T+i*B)'.
// *
// *  LREAL   (input) LOGICAL
// *          On entry, LREAL specifies the input matrix structure:
// *             = .FALSE.,    the input is complex
// *             = .TRUE.,     the input is real
// *
// *  N       (input) INTEGER
// *          On entry, N specifies the order of T+i*B. N >= 0.
// *
// *  T       (input) DOUBLE PRECISION array, dimension (LDT,N)
// *          On entry, T contains a matrix in Schur canonical form.
// *          If LREAL = .FALSE., then the first diagonal block of T mu
// *          be 1 by 1.
// *
// *  LDT     (input) INTEGER
// *          The leading dimension of the matrix T. LDT >= max(1,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (N)
// *          On entry, B contains the elements to form the matrix
// *          B as described above.
// *          If LREAL = .TRUE., B is not referenced.
// *
// *  W       (input) DOUBLE PRECISION
// *          On entry, W is the diagonal element of the matrix B.
// *          If LREAL = .TRUE., W is not referenced.
// *
// *  SCALE   (output) DOUBLE PRECISION
// *          On exit, SCALE is the scale factor.
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension (2*N)
// *          On entry, X contains the right hand side of the system.
// *          On exit, X is overwritten by the solution.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          On exit, INFO is set to
// *             0: successful exit.
// *               1: the some diagonal 1 by 1 block has been perturbed by
// *                  a small number SMIN to keep nonsingularity.
// *               2: the some diagonal 2 by 2 block has been perturbed by
// *                  a small number in DLALN2 to keep nonsingularity.
// *          NOTE: In the interests of speed, this routine does not
// *                check the inputs for errors.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static int i= 0;
static intW ierr= new intW(0);
static int j= 0;
static int j1= 0;
static int j2= 0;
static int jnext= 0;
static int k= 0;
static int n1= 0;
static int n2= 0;
static double bignum= 0.0;
static double eps= 0.0;
static double rec= 0.0;
static doubleW scaloc= new doubleW(0.0);
static doubleW si= new doubleW(0.0);
static double smin= 0.0;
static double sminw= 0.0;
static double smlnum= 0.0;
static doubleW sr= new doubleW(0.0);
static double tjj= 0.0;
static double tmp= 0.0;
static double xj= 0.0;
static double xmax= 0.0;
static doubleW xnorm= new doubleW(0.0);
static double z= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] d= new double[(2) * (2)];
static double [] v= new double[(2) * (2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Do not test the input parameters for errors
// *

public static void dlaqtr (boolean ltran,
boolean lreal,
int n,
double [] t, int _t_offset,
int ldt,
double [] b, int _b_offset,
double w,
doubleW scale,
double [] x, int _x_offset,
double [] work, int _work_offset,
intW info)  {

notran = !ltran;
info.val = 0;
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlaqtr",999999);
// *
// *     Set constants to control overflow
// *
eps = Dlamch.dlamch("P");
smlnum = Dlamch.dlamch("S")/eps;
bignum = one/smlnum;
// *
xnorm.val = Dlange.dlange("M",n,n,t,_t_offset,ldt,d,0);
if (!lreal)  
    xnorm.val = Math.max((xnorm.val) > (Math.abs(w)) ? (xnorm.val) : (Math.abs(w)), Dlange.dlange("M",n,1,b,_b_offset,n,d,0));
smin = Math.max(smlnum, eps*xnorm.val) ;
// *
// *     Compute 1-norm of each column of strictly upper triangular
// *     part of T to control overflow in triangular solver.
// *
work[(1)- 1+ _work_offset] = zero;
{
forloop10:
for (j = 2; j <= n; j++) {
work[(j)- 1+ _work_offset] = Dasum.dasum(j-1,t,(1)- 1+(j- 1)*ldt+ _t_offset,1);
Dummy.label("Dlaqtr",10);
}              //  Close for() loop. 
}
// *
if (!lreal)  {
    {
forloop20:
for (i = 2; i <= n; i++) {
work[(i)- 1+ _work_offset] = work[(i)- 1+ _work_offset]+Math.abs(b[(i)- 1+ _b_offset]);
Dummy.label("Dlaqtr",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
n2 = 2*n;
n1 = n;
if (!lreal)  
    n1 = n2;
k = Idamax.idamax(n1,x,_x_offset,1);
xmax = Math.abs(x[(k)- 1+ _x_offset]);
scale.val = one;
// *
if (xmax > bignum)  {
    scale.val = bignum/xmax;
Dscal.dscal(n1,scale.val,x,_x_offset,1);
xmax = bignum;
}              // Close if()
// *
if (lreal)  {
    // *
if (notran)  {
    // *
// *           Solve T*p = scale*c
// *
jnext = n;
{
int _j_inc = -1;
forloop30:
for (j = n; j >= 1; j += _j_inc) {
if (j > jnext)  
    continue forloop30;
j1 = j;
j2 = j;
jnext = j-1;
if (j > 1 && t[(j)- 1+(j-1- 1)*ldt+ _t_offset] != zero)  {
    j1 = j-1;
j2 = j;
jnext = j-2;
}              // Close if()
// *
if (j1 == j2)  {
    // *
// *                 Meet 1 by 1 diagonal block
// *
// *                 Scale to avoid overflow when computing
// *                     x(j) = b(j)/T(j,j)
// *
xj = Math.abs(x[(j1)- 1+ _x_offset]);
tjj = Math.abs(t[(j1)- 1+(j1- 1)*ldt+ _t_offset]);
tmp = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
if (tjj < smin)  {
    tmp = smin;
tjj = smin;
info.val = 1;
}              // Close if()
// *
if (xj == zero)  
    continue forloop30;
// *
if (tjj < one)  {
    if (xj > bignum*tjj)  {
    rec = one/xj;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
x[(j1)- 1+ _x_offset] = x[(j1)- 1+ _x_offset]/tmp;
xj = Math.abs(x[(j1)- 1+ _x_offset]);
// *
// *                 Scale x if necessary to avoid overflow when adding a
// *                 multiple of column j1 of T.
// *
if (xj > one)  {
    rec = one/xj;
if (work[(j1)- 1+ _work_offset] > (bignum-xmax)*rec)  {
    Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
}              // Close if()
}              // Close if()
if (j1 > 1)  {
    Daxpy.daxpy(j1-1,-x[(j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
k = Idamax.idamax(j1-1,x,_x_offset,1);
xmax = Math.abs(x[(k)- 1+ _x_offset]);
}              // Close if()
// *
}              // Close if()
else  {
  // *
// *                 Meet 2 by 2 diagonal block
// *
// *                 Call 2 by 2 linear system solve, to take
// *                 care of possible overflow by scaling factor.
// *
d[(1)- 1+(1- 1)*2] = x[(j1)- 1+ _x_offset];
d[(2)- 1+(1- 1)*2] = x[(j2)- 1+ _x_offset];
Dlaln2.dlaln2(false,2,1,smin,one,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,one,one,d,0,2,zero,zero,v,0,2,scaloc,xnorm,ierr);
if (ierr.val != 0)  
    info.val = 2;
// *
if (scaloc.val != one)  {
    Dscal.dscal(n,scaloc.val,x,_x_offset,1);
scale.val = scale.val*scaloc.val;
}              // Close if()
x[(j1)- 1+ _x_offset] = v[(1)- 1+(1- 1)*2];
x[(j2)- 1+ _x_offset] = v[(2)- 1+(1- 1)*2];
// *
// *                 Scale V(1,1) (= X(J1)) and/or V(2,1) (=X(J2))
// *                 to avoid overflow in updating right-hand side.
// *
xj = Math.max(Math.abs(v[(1)- 1+(1- 1)*2]), Math.abs(v[(2)- 1+(1- 1)*2])) ;
if (xj > one)  {
    rec = one/xj;
if (Math.max(work[(j1)- 1+ _work_offset], work[(j2)- 1+ _work_offset])  > (bignum-xmax)*rec)  {
    Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
}              // Close if()
}              // Close if()
// *
// *                 Update right-hand side
// *
if (j1 > 1)  {
    Daxpy.daxpy(j1-1,-x[(j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
Daxpy.daxpy(j1-1,-x[(j2)- 1+ _x_offset],t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,_x_offset,1);
k = Idamax.idamax(j1-1,x,_x_offset,1);
xmax = Math.abs(x[(k)- 1+ _x_offset]);
}              // Close if()
// *
}              //  Close else.
// *
Dummy.label("Dlaqtr",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *           Solve T'*p = scale*c
// *
jnext = 1;
{
forloop40:
for (j = 1; j <= n; j++) {
if (j < jnext)  
    continue forloop40;
j1 = j;
j2 = j;
jnext = j+1;
if (j < n && t[(j+1)- 1+(j- 1)*ldt+ _t_offset] != zero)  {
    j1 = j;
j2 = j+1;
jnext = j+2;
}              // Close if()
// *
if (j1 == j2)  {
    // *
// *                 1 by 1 diagonal block
// *
// *                 Scale if necessary to avoid overflow in forming the
// *                 right-hand side element by inner product.
// *
xj = Math.abs(x[(j1)- 1+ _x_offset]);
if (xmax > one)  {
    rec = one/xmax;
if (work[(j1)- 1+ _work_offset] > (bignum-xj)*rec)  {
    Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
// *
x[(j1)- 1+ _x_offset] = x[(j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
// *
xj = Math.abs(x[(j1)- 1+ _x_offset]);
tjj = Math.abs(t[(j1)- 1+(j1- 1)*ldt+ _t_offset]);
tmp = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
if (tjj < smin)  {
    tmp = smin;
tjj = smin;
info.val = 1;
}              // Close if()
// *
if (tjj < one)  {
    if (xj > bignum*tjj)  {
    rec = one/xj;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
x[(j1)- 1+ _x_offset] = x[(j1)- 1+ _x_offset]/tmp;
xmax = Math.max(xmax, Math.abs(x[(j1)- 1+ _x_offset])) ;
// *
}              // Close if()
else  {
  // *
// *                 2 by 2 diagonal block
// *
// *                 Scale if necessary to avoid overflow in forming the
// *                 right-hand side elements by inner product.
// *
xj = Math.max(Math.abs(x[(j1)- 1+ _x_offset]), Math.abs(x[(j2)- 1+ _x_offset])) ;
if (xmax > one)  {
    rec = one/xmax;
if (Math.max(work[(j2)- 1+ _work_offset], work[(j1)- 1+ _work_offset])  > (bignum-xj)*rec)  {
    Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
// *
d[(1)- 1+(1- 1)*2] = x[(j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
d[(2)- 1+(1- 1)*2] = x[(j2)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,_x_offset,1);
// *
Dlaln2.dlaln2(true,2,1,smin,one,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,one,one,d,0,2,zero,zero,v,0,2,scaloc,xnorm,ierr);
if (ierr.val != 0)  
    info.val = 2;
// *
if (scaloc.val != one)  {
    Dscal.dscal(n,scaloc.val,x,_x_offset,1);
scale.val = scale.val*scaloc.val;
}              // Close if()
x[(j1)- 1+ _x_offset] = v[(1)- 1+(1- 1)*2];
x[(j2)- 1+ _x_offset] = v[(2)- 1+(1- 1)*2];
xmax = Math.max((Math.abs(x[(j1)- 1+ _x_offset])) > (Math.abs(x[(j2)- 1+ _x_offset])) ? (Math.abs(x[(j1)- 1+ _x_offset])) : (Math.abs(x[(j2)- 1+ _x_offset])), xmax);
// *
}              //  Close else.
Dummy.label("Dlaqtr",40);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close if()
else  {
  // *
sminw = Math.max(eps*Math.abs(w), smin) ;
if (notran)  {
    // *
// *           Solve (T + iB)*(p+iq) = c+id
// *
jnext = n;
{
int _j_inc = -1;
forloop70:
for (j = n; j >= 1; j += _j_inc) {
if (j > jnext)  
    continue forloop70;
j1 = j;
j2 = j;
jnext = j-1;
if (j > 1 && t[(j)- 1+(j-1- 1)*ldt+ _t_offset] != zero)  {
    j1 = j-1;
j2 = j;
jnext = j-2;
}              // Close if()
// *
if (j1 == j2)  {
    // *
// *                 1 by 1 diagonal block
// *
// *                 Scale if necessary to avoid overflow in division
// *
z = w;
if (j1 == 1)  
    z = b[(1)- 1+ _b_offset];
xj = Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(n+j1)- 1+ _x_offset]);
tjj = Math.abs(t[(j1)- 1+(j1- 1)*ldt+ _t_offset])+Math.abs(z);
tmp = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
if (tjj < sminw)  {
    tmp = sminw;
tjj = sminw;
info.val = 1;
}              // Close if()
// *
if (xj == zero)  
    continue forloop70;
// *
if (tjj < one)  {
    if (xj > bignum*tjj)  {
    rec = one/xj;
Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
Dladiv.dladiv(x[(j1)- 1+ _x_offset],x[(n+j1)- 1+ _x_offset],tmp,z,sr,si);
x[(j1)- 1+ _x_offset] = sr.val;
x[(n+j1)- 1+ _x_offset] = si.val;
xj = Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(n+j1)- 1+ _x_offset]);
// *
// *                 Scale x if necessary to avoid overflow when adding a
// *                 multiple of column j1 of T.
// *
if (xj > one)  {
    rec = one/xj;
if (work[(j1)- 1+ _work_offset] > (bignum-xmax)*rec)  {
    Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
}              // Close if()
}              // Close if()
// *
if (j1 > 1)  {
    Daxpy.daxpy(j1-1,-x[(j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
Daxpy.daxpy(j1-1,-x[(n+j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
// *
x[(1)- 1+ _x_offset] = x[(1)- 1+ _x_offset]+b[(j1)- 1+ _b_offset]*x[(n+j1)- 1+ _x_offset];
x[(n+1)- 1+ _x_offset] = x[(n+1)- 1+ _x_offset]-b[(j1)- 1+ _b_offset]*x[(j1)- 1+ _x_offset];
// *
xmax = zero;
{
forloop50:
for (k = 1; k <= j1-1; k++) {
xmax = Math.max(xmax, Math.abs(x[(k)- 1+ _x_offset])+Math.abs(x[(k+n)- 1+ _x_offset])) ;
Dummy.label("Dlaqtr",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
else  {
  // *
// *                 Meet 2 by 2 diagonal block
// *
d[(1)- 1+(1- 1)*2] = x[(j1)- 1+ _x_offset];
d[(2)- 1+(1- 1)*2] = x[(j2)- 1+ _x_offset];
d[(1)- 1+(2- 1)*2] = x[(n+j1)- 1+ _x_offset];
d[(2)- 1+(2- 1)*2] = x[(n+j2)- 1+ _x_offset];
Dlaln2.dlaln2(false,2,2,sminw,one,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,one,one,d,0,2,zero,-w,v,0,2,scaloc,xnorm,ierr);
if (ierr.val != 0)  
    info.val = 2;
// *
if (scaloc.val != one)  {
    Dscal.dscal(2*n,scaloc.val,x,_x_offset,1);
scale.val = scaloc.val*scale.val;
}              // Close if()
x[(j1)- 1+ _x_offset] = v[(1)- 1+(1- 1)*2];
x[(j2)- 1+ _x_offset] = v[(2)- 1+(1- 1)*2];
x[(n+j1)- 1+ _x_offset] = v[(1)- 1+(2- 1)*2];
x[(n+j2)- 1+ _x_offset] = v[(2)- 1+(2- 1)*2];
// *
// *                 Scale X(J1), .... to avoid overflow in
// *                 updating right hand side.
// *
xj = Math.max(Math.abs(v[(1)- 1+(1- 1)*2])+Math.abs(v[(1)- 1+(2- 1)*2]), Math.abs(v[(2)- 1+(1- 1)*2])+Math.abs(v[(2)- 1+(2- 1)*2])) ;
if (xj > one)  {
    rec = one/xj;
if (Math.max(work[(j1)- 1+ _work_offset], work[(j2)- 1+ _work_offset])  > (bignum-xmax)*rec)  {
    Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
}              // Close if()
}              // Close if()
// *
// *                 Update the right-hand side.
// *
if (j1 > 1)  {
    Daxpy.daxpy(j1-1,-x[(j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
Daxpy.daxpy(j1-1,-x[(j2)- 1+ _x_offset],t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,_x_offset,1);
// *
Daxpy.daxpy(j1-1,-x[(n+j1)- 1+ _x_offset],t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
Daxpy.daxpy(j1-1,-x[(n+j2)- 1+ _x_offset],t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
// *
x[(1)- 1+ _x_offset] = x[(1)- 1+ _x_offset]+b[(j1)- 1+ _b_offset]*x[(n+j1)- 1+ _x_offset]+b[(j2)- 1+ _b_offset]*x[(n+j2)- 1+ _x_offset];
x[(n+1)- 1+ _x_offset] = x[(n+1)- 1+ _x_offset]-b[(j1)- 1+ _b_offset]*x[(j1)- 1+ _x_offset]-b[(j2)- 1+ _b_offset]*x[(j2)- 1+ _x_offset];
// *
xmax = zero;
{
forloop60:
for (k = 1; k <= j1-1; k++) {
xmax = Math.max(Math.abs(x[(k)- 1+ _x_offset])+Math.abs(x[(k+n)- 1+ _x_offset]), xmax) ;
Dummy.label("Dlaqtr",60);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              //  Close else.
Dummy.label("Dlaqtr",70);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *           Solve (T + iB)'*(p+iq) = c+id
// *
jnext = 1;
{
forloop80:
for (j = 1; j <= n; j++) {
if (j < jnext)  
    continue forloop80;
j1 = j;
j2 = j;
jnext = j+1;
if (j < n && t[(j+1)- 1+(j- 1)*ldt+ _t_offset] != zero)  {
    j1 = j;
j2 = j+1;
jnext = j+2;
}              // Close if()
// *
if (j1 == j2)  {
    // *
// *                 1 by 1 diagonal block
// *
// *                 Scale if necessary to avoid overflow in forming the
// *                 right-hand side element by inner product.
// *
xj = Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(j1+n)- 1+ _x_offset]);
if (xmax > one)  {
    rec = one/xmax;
if (work[(j1)- 1+ _work_offset] > (bignum-xj)*rec)  {
    Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
// *
x[(j1)- 1+ _x_offset] = x[(j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
x[(n+j1)- 1+ _x_offset] = x[(n+j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
if (j1 > 1)  {
    x[(j1)- 1+ _x_offset] = x[(j1)- 1+ _x_offset]-b[(j1)- 1+ _b_offset]*x[(n+1)- 1+ _x_offset];
x[(n+j1)- 1+ _x_offset] = x[(n+j1)- 1+ _x_offset]+b[(j1)- 1+ _b_offset]*x[(1)- 1+ _x_offset];
}              // Close if()
xj = Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(j1+n)- 1+ _x_offset]);
// *
z = w;
if (j1 == 1)  
    z = b[(1)- 1+ _b_offset];
// *
// *                 Scale if necessary to avoid overflow in
// *                 complex division
// *
tjj = Math.abs(t[(j1)- 1+(j1- 1)*ldt+ _t_offset])+Math.abs(z);
tmp = t[(j1)- 1+(j1- 1)*ldt+ _t_offset];
if (tjj < sminw)  {
    tmp = sminw;
tjj = sminw;
info.val = 1;
}              // Close if()
// *
if (tjj < one)  {
    if (xj > bignum*tjj)  {
    rec = one/xj;
Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
Dladiv.dladiv(x[(j1)- 1+ _x_offset],x[(n+j1)- 1+ _x_offset],tmp,-z,sr,si);
x[(j1)- 1+ _x_offset] = sr.val;
x[(j1+n)- 1+ _x_offset] = si.val;
xmax = Math.max(Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(j1+n)- 1+ _x_offset]), xmax) ;
// *
}              // Close if()
else  {
  // *
// *                 2 by 2 diagonal block
// *
// *                 Scale if necessary to avoid overflow in forming the
// *                 right-hand side element by inner product.
// *
xj = Math.max(Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(n+j1)- 1+ _x_offset]), Math.abs(x[(j2)- 1+ _x_offset])+Math.abs(x[(n+j2)- 1+ _x_offset])) ;
if (xmax > one)  {
    rec = one/xmax;
if (Math.max(work[(j1)- 1+ _work_offset], work[(j2)- 1+ _work_offset])  > (bignum-xj)/xmax)  {
    Dscal.dscal(n2,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
// *
d[(1)- 1+(1- 1)*2] = x[(j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,_x_offset,1);
d[(2)- 1+(1- 1)*2] = x[(j2)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,_x_offset,1);
d[(1)- 1+(2- 1)*2] = x[(n+j1)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j1- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
d[(2)- 1+(2- 1)*2] = x[(n+j2)- 1+ _x_offset]-Ddot.ddot(j1-1,t,(1)- 1+(j2- 1)*ldt+ _t_offset,1,x,(n+1)- 1+ _x_offset,1);
d[(1)- 1+(1- 1)*2] = d[(1)- 1+(1- 1)*2]-b[(j1)- 1+ _b_offset]*x[(n+1)- 1+ _x_offset];
d[(2)- 1+(1- 1)*2] = d[(2)- 1+(1- 1)*2]-b[(j2)- 1+ _b_offset]*x[(n+1)- 1+ _x_offset];
d[(1)- 1+(2- 1)*2] = d[(1)- 1+(2- 1)*2]+b[(j1)- 1+ _b_offset]*x[(1)- 1+ _x_offset];
d[(2)- 1+(2- 1)*2] = d[(2)- 1+(2- 1)*2]+b[(j2)- 1+ _b_offset]*x[(1)- 1+ _x_offset];
// *
Dlaln2.dlaln2(true,2,2,sminw,one,t,(j1)- 1+(j1- 1)*ldt+ _t_offset,ldt,one,one,d,0,2,zero,w,v,0,2,scaloc,xnorm,ierr);
if (ierr.val != 0)  
    info.val = 2;
// *
if (scaloc.val != one)  {
    Dscal.dscal(n2,scaloc.val,x,_x_offset,1);
scale.val = scaloc.val*scale.val;
}              // Close if()
x[(j1)- 1+ _x_offset] = v[(1)- 1+(1- 1)*2];
x[(j2)- 1+ _x_offset] = v[(2)- 1+(1- 1)*2];
x[(n+j1)- 1+ _x_offset] = v[(1)- 1+(2- 1)*2];
x[(n+j2)- 1+ _x_offset] = v[(2)- 1+(2- 1)*2];
xmax = Math.max((Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(n+j1)- 1+ _x_offset])) > (Math.abs(x[(j2)- 1+ _x_offset])+Math.abs(x[(n+j2)- 1+ _x_offset])) ? (Math.abs(x[(j1)- 1+ _x_offset])+Math.abs(x[(n+j1)- 1+ _x_offset])) : (Math.abs(x[(j2)- 1+ _x_offset])+Math.abs(x[(n+j2)- 1+ _x_offset])), xmax);
// *
}              //  Close else.
// *
Dummy.label("Dlaqtr",80);
}              //  Close for() loop. 
}
// *
}              //  Close else.
// *
}              //  Close else.
// *
Dummy.go_to("Dlaqtr",999999);
// *
// *     End of DLAQTR
// *
Dummy.label("Dlaqtr",999999);
return;
   }
} // End class.
