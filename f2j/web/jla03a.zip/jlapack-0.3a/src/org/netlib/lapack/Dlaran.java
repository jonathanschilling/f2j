/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaran {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARAN returns a random real number from a uniform (0,1)
// *  distribution.
// *
// *  Arguments
// *  =========
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator; the array
// *          elements must be between 0 and 4095, and ISEED(4) must be
// *          odd.
// *          On exit, the seed is updated.
// *
// *  Further Details
// *  ===============
// *
// *  This routine uses a multiplicative congruential method with modulus
// *  2**48 and multiplier 33952834046453 (see G.S.Fishman,
// *  'Multiplicative congruential random number generators with modulus
// *  2**b: an exhaustive analysis for b = 32 and a partial analysis for
// *  b = 48', Math. Comp. 189, pp 331-344, 1990).
// *
// *  48-bit integers are stored in 4 integer array elements with 12 bits
// *  per element. Hence the routine is portable across machines with
// *  integers of 32 bits or more.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int m1= 494;
static int m2= 322;
static int m3= 2508;
static int m4= 2549;
static double one= 1.0e+0;
static int ipw2= 4096;
static double r= one/ipw2;
// *     ..
// *     .. Local Scalars ..
static int it1= 0;
static int it2= 0;
static int it3= 0;
static int it4= 0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     multiply the seed by the multiplier modulo 2**48
// *
static double dlaran = 0.0;


public static double dlaran (int [] iseed, int _iseed_offset)  {

it4 = iseed[(4)- 1+ _iseed_offset]*m4;
it3 = it4/ipw2;
it4 = it4-ipw2*it3;
it3 = it3+iseed[(3)- 1+ _iseed_offset]*m4+iseed[(4)- 1+ _iseed_offset]*m3;
it2 = it3/ipw2;
it3 = it3-ipw2*it2;
it2 = it2+iseed[(2)- 1+ _iseed_offset]*m4+iseed[(3)- 1+ _iseed_offset]*m3+iseed[(4)- 1+ _iseed_offset]*m2;
it1 = it2/ipw2;
it2 = it2-ipw2*it1;
it1 = it1+iseed[(1)- 1+ _iseed_offset]*m4+iseed[(2)- 1+ _iseed_offset]*m3+iseed[(3)- 1+ _iseed_offset]*m2+iseed[(4)- 1+ _iseed_offset]*m1;
it1 = (it1)%(ipw2) ;
// *
// *     return updated seed
// *
iseed[(1)- 1+ _iseed_offset] = it1;
iseed[(2)- 1+ _iseed_offset] = it2;
iseed[(3)- 1+ _iseed_offset] = it3;
iseed[(4)- 1+ _iseed_offset] = it4;
// *
// *     convert 48-bit integer to a real number in the interval (0,1)
// *
dlaran = r*((double)(it1)+r*((double)(it2)+r*((double)(it3)+r*((double)(it4)))));
Dummy.go_to("Dlaran",999999);
// *
// *     End of DLARAN
// *
Dummy.label("Dlaran",999999);
return dlaran;
   }
} // End class.
