/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlarf {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARF applies a real elementary reflector H to a real m by n matrix
// *  C, from either the left or the right. H is represented in the form
// *
// *        H = I - tau * v * v'
// *
// *  where tau is a real scalar and v is a real vector.
// *
// *  If tau = 0, then H is taken to be the unit matrix.
// *
// *  Arguments
// *  =========
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'L': form  H * C
// *          = 'R': form  C * H
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix C.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix C.
// *
// *  V       (input) DOUBLE PRECISION array, dimension
// *                     (1 + (M-1)*abs(INCV)) if SIDE = 'L'
// *                  or (1 + (N-1)*abs(INCV)) if SIDE = 'R'
// *          The vector v in the representation of H. V is not used if
// *          TAU = 0.
// *
// *  INCV    (input) INTEGER
// *          The increment between elements of v. INCV <> 0.
// *
// *  TAU     (input) DOUBLE PRECISION
// *          The value tau in the representation of H.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
// *          On entry, the m by n matrix C.
// *          On exit, C is overwritten by the matrix H * C if SIDE = 'L',
// *          or C * H if SIDE = 'R'.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C. LDC >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                         (N) if SIDE = 'L'
// *                      or (M) if SIDE = 'R'
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlarf (String side,
int m,
int n,
double [] v, int _v_offset,
int incv,
double tau,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset)  {

if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *        Form  H * C
// *
if (tau != zero)  {
    // *
// *           w := C' * v
// *
Dgemv.dgemv("Transpose",m,n,one,c,_c_offset,Ldc,v,_v_offset,incv,zero,work,_work_offset,1);
// *
// *           C := C - v * w'
// *
Dger.dger(m,n,-tau,v,_v_offset,incv,work,_work_offset,1,c,_c_offset,Ldc);
}              // Close if()
}              // Close if()
else  {
  // *
// *        Form  C * H
// *
if (tau != zero)  {
    // *
// *           w := C * v
// *
Dgemv.dgemv("No transpose",m,n,one,c,_c_offset,Ldc,v,_v_offset,incv,zero,work,_work_offset,1);
// *
// *           C := C - w * v'
// *
Dger.dger(m,n,-tau,work,_work_offset,1,v,_v_offset,incv,c,_c_offset,Ldc);
}              // Close if()
}              //  Close else.
Dummy.go_to("Dlarf",999999);
// *
// *     End of DLARF
// *
Dummy.label("Dlarf",999999);
return;
   }
} // End class.
