/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlarfb {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARFB applies a real block reflector H or its transpose H' to a
// *  real m by n matrix C, from either the left or the right.
// *
// *  Arguments
// *  =========
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'L': apply H or H' from the Left
// *          = 'R': apply H or H' from the Right
// *
// *  TRANS   (input) CHARACTER*1
// *          = 'N': apply H (No transpose)
// *          = 'T': apply H' (Transpose)
// *
// *  DIRECT  (input) CHARACTER*1
// *          Indicates how H is formed from a product of elementary
// *          reflectors
// *          = 'F': H = H(1) H(2) . . . H(k) (Forward)
// *          = 'B': H = H(k) . . . H(2) H(1) (Backward)
// *
// *  STOREV  (input) CHARACTER*1
// *          Indicates how the vectors which define the elementary
// *          reflectors are stored:
// *          = 'C': Columnwise
// *          = 'R': Rowwise
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix C.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix C.
// *
// *  K       (input) INTEGER
// *          The order of the matrix T (= the number of elementary
// *          reflectors whose product defines the block reflector).
// *
// *  V       (input) DOUBLE PRECISION array, dimension
// *                                (LDV,K) if STOREV = 'C'
// *                                (LDV,M) if STOREV = 'R' and SIDE = 'L'
// *                                (LDV,N) if STOREV = 'R' and SIDE = 'R'
// *          The matrix V. See further details.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V.
// *          If STOREV = 'C' and SIDE = 'L', LDV >= max(1,M);
// *          if STOREV = 'C' and SIDE = 'R', LDV >= max(1,N);
// *          if STOREV = 'R', LDV >= K.
// *
// *  T       (input) DOUBLE PRECISION array, dimension (LDT,K)
// *          The triangular k by k matrix T in the representation of the
// *          block reflector.
// *
// *  LDT     (input) INTEGER
// *          The leading dimension of the array T. LDT >= K.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
// *          On entry, the m by n matrix C.
// *          On exit, C is overwritten by H*C or H'*C or C*H or C*H'.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C. LDA >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK,K)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of the array WORK.
// *          If SIDE = 'L', LDWORK >= max(1,N);
// *          if SIDE = 'R', LDWORK >= max(1,M).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static String transt= new String(" ");
static int i= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlarfb (String side,
String trans,
String direct,
String storev,
int m,
int n,
int k,
double [] v, int _v_offset,
int ldv,
double [] t, int _t_offset,
int ldt,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset,
int ldwork)  {

if (m <= 0 || n <= 0)  
    Dummy.go_to("Dlarfb",999999);
// *
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    transt = "T";
}              // Close if()
else  {
  transt = "N";
}              //  Close else.
// *
if ((storev.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    // *
if ((direct.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    // *
// *           Let  V =  ( V1 )    (first K rows)
// *                     ( V2 )
// *           where  V1  is unit lower triangular.
// *
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *              Form  H * C  or  H' * C  where  C = ( C1 )
// *                                                  ( C2 )
// *
// *              W := C' * V  =  (C1'*V1 + C2'*V2)  (stored in WORK)
// *
// *              W := C1'
// *
{
forloop10:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(n,c,(j)- 1+(1- 1)*Ldc+ _c_offset,Ldc,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",10);
}              //  Close for() loop. 
}
// *
// *              W := W * V1
// *
Dtrmm.dtrmm("Right","Lower","No transpose","Unit",n,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
if (m > k)  {
    // *
// *                 W := W + C2'*V2
// *
Dgemm.dgemm("Transpose","No transpose",n,k,m-k,one,c,(k+1)- 1+(1- 1)*Ldc+ _c_offset,Ldc,v,(k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T'  or  W * T
// *
Dtrmm.dtrmm("Right","Upper",transt,"Non-unit",n,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - V * W'
// *
if (m > k)  {
    // *
// *                 C2 := C2 - V2 * W'
// *
Dgemm.dgemm("No transpose","Transpose",m-k,n,k,-one,v,(k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork,one,c,(k+1)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V1'
// *
Dtrmm.dtrmm("Right","Lower","Transpose","Unit",n,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C1 := C1 - W'
// *
{
forloop30:
for (j = 1; j <= k; j++) {
{
forloop20:
for (i = 1; i <= n; i++) {
c[(j)- 1+(i- 1)*Ldc+ _c_offset] = c[(j)- 1+(i- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",20);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    // *
// *              Form  C * H  or  C * H'  where  C = ( C1  C2 )
// *
// *              W := C * V  =  (C1*V1 + C2*V2)  (stored in WORK)
// *
// *              W := C1
// *
{
forloop40:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(m,c,(1)- 1+(j- 1)*Ldc+ _c_offset,1,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",40);
}              //  Close for() loop. 
}
// *
// *              W := W * V1
// *
Dtrmm.dtrmm("Right","Lower","No transpose","Unit",m,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
if (n > k)  {
    // *
// *                 W := W + C2 * V2
// *
Dgemm.dgemm("No transpose","No transpose",m,k,n-k,one,c,(1)- 1+(k+1- 1)*Ldc+ _c_offset,Ldc,v,(k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T  or  W * T'
// *
Dtrmm.dtrmm("Right","Upper",trans,"Non-unit",m,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - W * V'
// *
if (n > k)  {
    // *
// *                 C2 := C2 - W * V2'
// *
Dgemm.dgemm("No transpose","Transpose",m,n-k,k,-one,work,_work_offset,ldwork,v,(k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,one,c,(1)- 1+(k+1- 1)*Ldc+ _c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V1'
// *
Dtrmm.dtrmm("Right","Lower","Transpose","Unit",m,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C1 := C1 - W
// *
{
forloop60:
for (j = 1; j <= k; j++) {
{
forloop50:
for (i = 1; i <= m; i++) {
c[(i)- 1+(j- 1)*Ldc+ _c_offset] = c[(i)- 1+(j- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",50);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",60);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              // Close if()
else  {
  // *
// *           Let  V =  ( V1 )
// *                     ( V2 )    (last K rows)
// *           where  V2  is unit upper triangular.
// *
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *              Form  H * C  or  H' * C  where  C = ( C1 )
// *                                                  ( C2 )
// *
// *              W := C' * V  =  (C1'*V1 + C2'*V2)  (stored in WORK)
// *
// *              W := C2'
// *
{
forloop70:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(n,c,(m-k+j)- 1+(1- 1)*Ldc+ _c_offset,Ldc,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",70);
}              //  Close for() loop. 
}
// *
// *              W := W * V2
// *
Dtrmm.dtrmm("Right","Upper","No transpose","Unit",n,k,one,v,(m-k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
if (m > k)  {
    // *
// *                 W := W + C1'*V1
// *
Dgemm.dgemm("Transpose","No transpose",n,k,m-k,one,c,_c_offset,Ldc,v,_v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T'  or  W * T
// *
Dtrmm.dtrmm("Right","Lower",transt,"Non-unit",n,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - V * W'
// *
if (m > k)  {
    // *
// *                 C1 := C1 - V1 * W'
// *
Dgemm.dgemm("No transpose","Transpose",m-k,n,k,-one,v,_v_offset,ldv,work,_work_offset,ldwork,one,c,_c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V2'
// *
Dtrmm.dtrmm("Right","Upper","Transpose","Unit",n,k,one,v,(m-k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C2 := C2 - W'
// *
{
forloop90:
for (j = 1; j <= k; j++) {
{
forloop80:
for (i = 1; i <= n; i++) {
c[(m-k+j)- 1+(i- 1)*Ldc+ _c_offset] = c[(m-k+j)- 1+(i- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",80);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",90);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    // *
// *              Form  C * H  or  C * H'  where  C = ( C1  C2 )
// *
// *              W := C * V  =  (C1*V1 + C2*V2)  (stored in WORK)
// *
// *              W := C2
// *
{
forloop100:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(m,c,(1)- 1+(n-k+j- 1)*Ldc+ _c_offset,1,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",100);
}              //  Close for() loop. 
}
// *
// *              W := W * V2
// *
Dtrmm.dtrmm("Right","Upper","No transpose","Unit",m,k,one,v,(n-k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
if (n > k)  {
    // *
// *                 W := W + C1 * V1
// *
Dgemm.dgemm("No transpose","No transpose",m,k,n-k,one,c,_c_offset,Ldc,v,_v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T  or  W * T'
// *
Dtrmm.dtrmm("Right","Lower",trans,"Non-unit",m,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - W * V'
// *
if (n > k)  {
    // *
// *                 C1 := C1 - W * V1'
// *
Dgemm.dgemm("No transpose","Transpose",m,n-k,k,-one,work,_work_offset,ldwork,v,_v_offset,ldv,one,c,_c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V2'
// *
Dtrmm.dtrmm("Right","Upper","Transpose","Unit",m,k,one,v,(n-k+1)- 1+(1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C2 := C2 - W
// *
{
forloop120:
for (j = 1; j <= k; j++) {
{
forloop110:
for (i = 1; i <= m; i++) {
c[(i)- 1+(n-k+j- 1)*Ldc+ _c_offset] = c[(i)- 1+(n-k+j- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",110);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",120);
}              //  Close for() loop. 
}
}              // Close else if()
}              //  Close else.
// *
}              // Close if()
else if ((storev.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    // *
if ((direct.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    // *
// *           Let  V =  ( V1  V2 )    (V1: first K columns)
// *           where  V1  is unit upper triangular.
// *
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *              Form  H * C  or  H' * C  where  C = ( C1 )
// *                                                  ( C2 )
// *
// *              W := C' * V'  =  (C1'*V1' + C2'*V2') (stored in WORK)
// *
// *              W := C1'
// *
{
forloop130:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(n,c,(j)- 1+(1- 1)*Ldc+ _c_offset,Ldc,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",130);
}              //  Close for() loop. 
}
// *
// *              W := W * V1'
// *
Dtrmm.dtrmm("Right","Upper","Transpose","Unit",n,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
if (m > k)  {
    // *
// *                 W := W + C2'*V2'
// *
Dgemm.dgemm("Transpose","Transpose",n,k,m-k,one,c,(k+1)- 1+(1- 1)*Ldc+ _c_offset,Ldc,v,(1)- 1+(k+1- 1)*ldv+ _v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T'  or  W * T
// *
Dtrmm.dtrmm("Right","Upper",transt,"Non-unit",n,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - V' * W'
// *
if (m > k)  {
    // *
// *                 C2 := C2 - V2' * W'
// *
Dgemm.dgemm("Transpose","Transpose",m-k,n,k,-one,v,(1)- 1+(k+1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork,one,c,(k+1)- 1+(1- 1)*Ldc+ _c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V1
// *
Dtrmm.dtrmm("Right","Upper","No transpose","Unit",n,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C1 := C1 - W'
// *
{
forloop150:
for (j = 1; j <= k; j++) {
{
forloop140:
for (i = 1; i <= n; i++) {
c[(j)- 1+(i- 1)*Ldc+ _c_offset] = c[(j)- 1+(i- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",140);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",150);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    // *
// *              Form  C * H  or  C * H'  where  C = ( C1  C2 )
// *
// *              W := C * V'  =  (C1*V1' + C2*V2')  (stored in WORK)
// *
// *              W := C1
// *
{
forloop160:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(m,c,(1)- 1+(j- 1)*Ldc+ _c_offset,1,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",160);
}              //  Close for() loop. 
}
// *
// *              W := W * V1'
// *
Dtrmm.dtrmm("Right","Upper","Transpose","Unit",m,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
if (n > k)  {
    // *
// *                 W := W + C2 * V2'
// *
Dgemm.dgemm("No transpose","Transpose",m,k,n-k,one,c,(1)- 1+(k+1- 1)*Ldc+ _c_offset,Ldc,v,(1)- 1+(k+1- 1)*ldv+ _v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T  or  W * T'
// *
Dtrmm.dtrmm("Right","Upper",trans,"Non-unit",m,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - W * V
// *
if (n > k)  {
    // *
// *                 C2 := C2 - W * V2
// *
Dgemm.dgemm("No transpose","No transpose",m,n-k,k,-one,work,_work_offset,ldwork,v,(1)- 1+(k+1- 1)*ldv+ _v_offset,ldv,one,c,(1)- 1+(k+1- 1)*Ldc+ _c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V1
// *
Dtrmm.dtrmm("Right","Upper","No transpose","Unit",m,k,one,v,_v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C1 := C1 - W
// *
{
forloop180:
for (j = 1; j <= k; j++) {
{
forloop170:
for (i = 1; i <= m; i++) {
c[(i)- 1+(j- 1)*Ldc+ _c_offset] = c[(i)- 1+(j- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",170);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",180);
}              //  Close for() loop. 
}
// *
}              // Close else if()
// *
}              // Close if()
else  {
  // *
// *           Let  V =  ( V1  V2 )    (V2: last K columns)
// *           where  V2  is unit lower triangular.
// *
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *              Form  H * C  or  H' * C  where  C = ( C1 )
// *                                                  ( C2 )
// *
// *              W := C' * V'  =  (C1'*V1' + C2'*V2') (stored in WORK)
// *
// *              W := C2'
// *
{
forloop190:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(n,c,(m-k+j)- 1+(1- 1)*Ldc+ _c_offset,Ldc,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",190);
}              //  Close for() loop. 
}
// *
// *              W := W * V2'
// *
Dtrmm.dtrmm("Right","Lower","Transpose","Unit",n,k,one,v,(1)- 1+(m-k+1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
if (m > k)  {
    // *
// *                 W := W + C1'*V1'
// *
Dgemm.dgemm("Transpose","Transpose",n,k,m-k,one,c,_c_offset,Ldc,v,_v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T'  or  W * T
// *
Dtrmm.dtrmm("Right","Lower",transt,"Non-unit",n,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - V' * W'
// *
if (m > k)  {
    // *
// *                 C1 := C1 - V1' * W'
// *
Dgemm.dgemm("Transpose","Transpose",m-k,n,k,-one,v,_v_offset,ldv,work,_work_offset,ldwork,one,c,_c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V2
// *
Dtrmm.dtrmm("Right","Lower","No transpose","Unit",n,k,one,v,(1)- 1+(m-k+1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C2 := C2 - W'
// *
{
forloop210:
for (j = 1; j <= k; j++) {
{
forloop200:
for (i = 1; i <= n; i++) {
c[(m-k+j)- 1+(i- 1)*Ldc+ _c_offset] = c[(m-k+j)- 1+(i- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",200);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",210);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    // *
// *              Form  C * H  or  C * H'  where  C = ( C1  C2 )
// *
// *              W := C * V'  =  (C1*V1' + C2*V2')  (stored in WORK)
// *
// *              W := C2
// *
{
forloop220:
for (j = 1; j <= k; j++) {
Dcopy.dcopy(m,c,(1)- 1+(n-k+j- 1)*Ldc+ _c_offset,1,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dlarfb",220);
}              //  Close for() loop. 
}
// *
// *              W := W * V2'
// *
Dtrmm.dtrmm("Right","Lower","Transpose","Unit",m,k,one,v,(1)- 1+(n-k+1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
if (n > k)  {
    // *
// *                 W := W + C1 * V1'
// *
Dgemm.dgemm("No transpose","Transpose",m,k,n-k,one,c,_c_offset,Ldc,v,_v_offset,ldv,one,work,_work_offset,ldwork);
}              // Close if()
// *
// *              W := W * T  or  W * T'
// *
Dtrmm.dtrmm("Right","Lower",trans,"Non-unit",m,k,one,t,_t_offset,ldt,work,_work_offset,ldwork);
// *
// *              C := C - W * V
// *
if (n > k)  {
    // *
// *                 C1 := C1 - W * V1
// *
Dgemm.dgemm("No transpose","No transpose",m,n-k,k,-one,work,_work_offset,ldwork,v,_v_offset,ldv,one,c,_c_offset,Ldc);
}              // Close if()
// *
// *              W := W * V2
// *
Dtrmm.dtrmm("Right","Lower","No transpose","Unit",m,k,one,v,(1)- 1+(n-k+1- 1)*ldv+ _v_offset,ldv,work,_work_offset,ldwork);
// *
// *              C1 := C1 - W
// *
{
forloop240:
for (j = 1; j <= k; j++) {
{
forloop230:
for (i = 1; i <= m; i++) {
c[(i)- 1+(n-k+j- 1)*Ldc+ _c_offset] = c[(i)- 1+(n-k+j- 1)*Ldc+ _c_offset]-work[(i)- 1+(j- 1)*ldwork+ _work_offset];
Dummy.label("Dlarfb",230);
}              //  Close for() loop. 
}
Dummy.label("Dlarfb",240);
}              //  Close for() loop. 
}
// *
}              // Close else if()
// *
}              //  Close else.
}              // Close else if()
// *
Dummy.go_to("Dlarfb",999999);
// *
// *     End of DLARFB
// *
Dummy.label("Dlarfb",999999);
return;
   }
} // End class.
