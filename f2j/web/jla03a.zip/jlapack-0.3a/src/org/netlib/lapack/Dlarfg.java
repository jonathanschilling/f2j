/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlarfg {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARFG generates a real elementary reflector H of order n, such
// *  that
// *
// *        H * ( alpha ) = ( beta ),   H' * H = I.
// *            (   x   )   (   0  )
// *
// *  where alpha and beta are scalars, and x is an (n-1)-element real
// *  vector. H is represented in the form
// *
// *        H = I - tau * ( 1 ) * ( 1 v' ) ,
// *                      ( v )
// *
// *  where tau is a real scalar and v is a real (n-1)-element
// *  vector.
// *
// *  If the elements of x are all zero, then tau = 0 and H is taken to be
// *  the unit matrix.
// *
// *  Otherwise  1 <= tau <= 2.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the elementary reflector.
// *
// *  ALPHA   (input/output) DOUBLE PRECISION
// *          On entry, the value alpha.
// *          On exit, it is overwritten with the value beta.
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension
// *                         (1+(N-2)*abs(INCX))
// *          On entry, the vector x.
// *          On exit, it is overwritten with the vector v.
// *
// *  INCX    (input) INTEGER
// *          The increment between elements of X. INCX > 0.
// *
// *  TAU     (output) DOUBLE PRECISION
// *          The value tau.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static int knt= 0;
static double beta= 0.0;
static double rsafmn= 0.0;
static double safmin= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlarfg (int n,
doubleW alpha,
double [] x, int _x_offset,
int incx,
doubleW tau)  {

if (n <= 1)  {
    tau.val = zero;
Dummy.go_to("Dlarfg",999999);
}              // Close if()
// *
xnorm = Dnrm2.dnrm2(n-1,x,_x_offset,incx);
// *
if (xnorm == zero)  {
    // *
// *        H  =  I
// *
tau.val = zero;
}              // Close if()
else  {
  // *
// *        general case
// *
beta = -((alpha.val) >= 0 ? Math.abs(Dlapy2.dlapy2(alpha.val,xnorm)) : -Math.abs(Dlapy2.dlapy2(alpha.val,xnorm)));
safmin = Dlamch.dlamch("S")/Dlamch.dlamch("E");
if (Math.abs(beta) < safmin)  {
    // *
// *           XNORM, BETA may be inaccurate; scale X and recompute them
// *
rsafmn = one/safmin;
knt = 0;
label10:
   Dummy.label("Dlarfg",10);
knt = knt+1;
Dscal.dscal(n-1,rsafmn,x,_x_offset,incx);
beta = beta*rsafmn;
alpha.val = alpha.val*rsafmn;
if (Math.abs(beta) < safmin)  
    Dummy.go_to("Dlarfg",10);
// *
// *           New BETA is at most 1, at least SAFMIN
// *
xnorm = Dnrm2.dnrm2(n-1,x,_x_offset,incx);
beta = -((alpha.val) >= 0 ? Math.abs(Dlapy2.dlapy2(alpha.val,xnorm)) : -Math.abs(Dlapy2.dlapy2(alpha.val,xnorm)));
tau.val = (beta-alpha.val)/beta;
Dscal.dscal(n-1,one/(alpha.val-beta),x,_x_offset,incx);
// *
// *           If ALPHA is subnormal, it may lose relative accuracy
// *
alpha.val = beta;
{
forloop20:
for (j = 1; j <= knt; j++) {
alpha.val = alpha.val*safmin;
Dummy.label("Dlarfg",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  tau.val = (beta-alpha.val)/beta;
Dscal.dscal(n-1,one/(alpha.val-beta),x,_x_offset,incx);
alpha.val = beta;
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dlarfg",999999);
// *
// *     End of DLARFG
// *
Dummy.label("Dlarfg",999999);
return;
   }
} // End class.
