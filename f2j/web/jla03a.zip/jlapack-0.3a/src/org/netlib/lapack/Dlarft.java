/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlarft {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARFT forms the triangular factor T of a real block reflector H
// *  of order n, which is defined as a product of k elementary reflectors.
// *
// *  If DIRECT = 'F', H = H(1) H(2) . . . H(k) and T is upper triangular;
// *
// *  If DIRECT = 'B', H = H(k) . . . H(2) H(1) and T is lower triangular.
// *
// *  If STOREV = 'C', the vector which defines the elementary reflector
// *  H(i) is stored in the i-th column of the array V, and
// *
// *     H  =  I - V * T * V'
// *
// *  If STOREV = 'R', the vector which defines the elementary reflector
// *  H(i) is stored in the i-th row of the array V, and
// *
// *     H  =  I - V' * T * V
// *
// *  Arguments
// *  =========
// *
// *  DIRECT  (input) CHARACTER*1
// *          Specifies the order in which the elementary reflectors are
// *          multiplied to form the block reflector:
// *          = 'F': H = H(1) H(2) . . . H(k) (Forward)
// *          = 'B': H = H(k) . . . H(2) H(1) (Backward)
// *
// *  STOREV  (input) CHARACTER*1
// *          Specifies how the vectors which define the elementary
// *          reflectors are stored (see also Further Details):
// *          = 'C': columnwise
// *          = 'R': rowwise
// *
// *  N       (input) INTEGER
// *          The order of the block reflector H. N >= 0.
// *
// *  K       (input) INTEGER
// *          The order of the triangular factor T (= the number of
// *          elementary reflectors). K >= 1.
// *
// *  V       (input/output) DOUBLE PRECISION array, dimension
// *                               (LDV,K) if STOREV = 'C'
// *                               (LDV,N) if STOREV = 'R'
// *          The matrix V. See further details.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V.
// *          If STOREV = 'C', LDV >= max(1,N); if STOREV = 'R', LDV >= K.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (K)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i).
// *
// *  T       (output) DOUBLE PRECISION array, dimension (LDT,K)
// *          The k by k triangular factor T of the block reflector.
// *          If DIRECT = 'F', T is upper triangular; if DIRECT = 'B', T is
// *          lower triangular. The rest of the array is not used.
// *
// *  LDT     (input) INTEGER
// *          The leading dimension of the array T. LDT >= K.
// *
// *  Further Details
// *  ===============
// *
// *  The shape of the matrix V and the storage of the vectors which define
// *  the H(i) is best illustrated by the following example with n = 5 and
// *  k = 3. The elements equal to 1 are not stored; the corresponding
// *  array elements are modified but restored on exit. The rest of the
// *  array is not used.
// *
// *  DIRECT = 'F' and STOREV = 'C':         DIRECT = 'F' and STOREV = 'R':
// *
// *               V = (  1       )                 V = (  1 v1 v1 v1 v1 )
// *                   ( v1  1    )                     (     1 v2 v2 v2 )
// *                   ( v1 v2  1 )                     (        1 v3 v3 )
// *                   ( v1 v2 v3 )
// *                   ( v1 v2 v3 )
// *
// *  DIRECT = 'B' and STOREV = 'C':         DIRECT = 'B' and STOREV = 'R':
// *
// *               V = ( v1 v2 v3 )                 V = ( v1 v1  1       )
// *                   ( v1 v2 v3 )                     ( v2 v2 v2  1    )
// *                   (  1 v2 v3 )                     ( v3 v3 v3 v3  1 )
// *                   (     1 v3 )
// *                   (        1 )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double vii= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlarft (String direct,
String storev,
int n,
int k,
double [] v, int _v_offset,
int ldv,
double [] tau, int _tau_offset,
double [] t, int _t_offset,
int ldt)  {

if (n == 0)  
    Dummy.go_to("Dlarft",999999);
// *
if ((direct.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    {
forloop20:
for (i = 1; i <= k; i++) {
if (tau[(i)- 1+ _tau_offset] == zero)  {
    // *
// *              H(i)  =  I
// *
{
forloop10:
for (j = 1; j <= i; j++) {
t[(j)- 1+(i- 1)*ldt+ _t_offset] = zero;
Dummy.label("Dlarft",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *              general case
// *
vii = v[(i)- 1+(i- 1)*ldv+ _v_offset];
v[(i)- 1+(i- 1)*ldv+ _v_offset] = one;
if ((storev.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    // *
// *                 T(1:i-1,i) := - tau(i) * V(i:n,1:i-1)' * V(i:n,i)
// *
Dgemv.dgemv("Transpose",n-i+1,i-1,-tau[(i)- 1+ _tau_offset],v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(i)- 1+(i- 1)*ldv+ _v_offset,1,zero,t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
}              // Close if()
else  {
  // *
// *                 T(1:i-1,i) := - tau(i) * V(1:i-1,i:n) * V(i,i:n)'
// *
Dgemv.dgemv("No transpose",i-1,n-i+1,-tau[(i)- 1+ _tau_offset],v,(1)- 1+(i- 1)*ldv+ _v_offset,ldv,v,(i)- 1+(i- 1)*ldv+ _v_offset,ldv,zero,t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
}              //  Close else.
v[(i)- 1+(i- 1)*ldv+ _v_offset] = vii;
// *
// *              T(1:i-1,i) := T(1:i-1,1:i-1) * T(1:i-1,i)
// *
Dtrmv.dtrmv("Upper","No transpose","Non-unit",i-1,t,_t_offset,ldt,t,(1)- 1+(i- 1)*ldt+ _t_offset,1);
t[(i)- 1+(i- 1)*ldt+ _t_offset] = tau[(i)- 1+ _tau_offset];
}              //  Close else.
Dummy.label("Dlarft",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
int _i_inc = -1;
forloop40:
for (i = k; i >= 1; i += _i_inc) {
if (tau[(i)- 1+ _tau_offset] == zero)  {
    // *
// *              H(i)  =  I
// *
{
forloop30:
for (j = i; j <= k; j++) {
t[(j)- 1+(i- 1)*ldt+ _t_offset] = zero;
Dummy.label("Dlarft",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *              general case
// *
if (i < k)  {
    if ((storev.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    vii = v[(n-k+i)- 1+(i- 1)*ldv+ _v_offset];
v[(n-k+i)- 1+(i- 1)*ldv+ _v_offset] = one;
// *
// *                    T(i+1:k,i) :=
// *                            - tau(i) * V(1:n-k+i,i+1:k)' * V(1:n-k+i,i)
// *
Dgemv.dgemv("Transpose",n-k+i,k-i,-tau[(i)- 1+ _tau_offset],v,(1)- 1+(i+1- 1)*ldv+ _v_offset,ldv,v,(1)- 1+(i- 1)*ldv+ _v_offset,1,zero,t,(i+1)- 1+(i- 1)*ldt+ _t_offset,1);
v[(n-k+i)- 1+(i- 1)*ldv+ _v_offset] = vii;
}              // Close if()
else  {
  vii = v[(i)- 1+(n-k+i- 1)*ldv+ _v_offset];
v[(i)- 1+(n-k+i- 1)*ldv+ _v_offset] = one;
// *
// *                    T(i+1:k,i) :=
// *                            - tau(i) * V(i+1:k,1:n-k+i) * V(i,1:n-k+i)'
// *
Dgemv.dgemv("No transpose",k-i,n-k+i,-tau[(i)- 1+ _tau_offset],v,(i+1)- 1+(1- 1)*ldv+ _v_offset,ldv,v,(i)- 1+(1- 1)*ldv+ _v_offset,ldv,zero,t,(i+1)- 1+(i- 1)*ldt+ _t_offset,1);
v[(i)- 1+(n-k+i- 1)*ldv+ _v_offset] = vii;
}              //  Close else.
// *
// *                 T(i+1:k,i) := T(i+1:k,i+1:k) * T(i+1:k,i)
// *
Dtrmv.dtrmv("Lower","No transpose","Non-unit",k-i,t,(i+1)- 1+(i+1- 1)*ldt+ _t_offset,ldt,t,(i+1)- 1+(i- 1)*ldt+ _t_offset,1);
}              // Close if()
t[(i)- 1+(i- 1)*ldt+ _t_offset] = tau[(i)- 1+ _tau_offset];
}              //  Close else.
Dummy.label("Dlarft",40);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dlarft",999999);
// *
// *     End of DLARFT
// *
Dummy.label("Dlarft",999999);
return;
   }
} // End class.
