/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlarfx {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARFX applies a real elementary reflector H to a real m by n
// *  matrix C, from either the left or the right. H is represented in the
// *  form
// *
// *        H = I - tau * v * v'
// *
// *  where tau is a real scalar and v is a real vector.
// *
// *  If tau = 0, then H is taken to be the unit matrix
// *
// *  This version uses inline code if H has order < 11.
// *
// *  Arguments
// *  =========
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'L': form  H * C
// *          = 'R': form  C * H
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix C.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix C.
// *
// *  V       (input) DOUBLE PRECISION array, dimension (M) if SIDE = 'L'
// *                                     or (N) if SIDE = 'R'
// *          The vector v in the representation of H.
// *
// *  TAU     (input) DOUBLE PRECISION
// *          The value tau in the representation of H.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
// *          On entry, the m by n matrix C.
// *          On exit, C is overwritten by the matrix H * C if SIDE = 'L',
// *          or C * H if SIDE = 'R'.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C. LDA >= (1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (N) if SIDE = 'L'
// *                      or (M) if SIDE = 'R'
// *          WORK is not referenced if H has order < 11.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double sum= 0.0;
static double t1= 0.0;
static double t10= 0.0;
static double t2= 0.0;
static double t3= 0.0;
static double t4= 0.0;
static double t5= 0.0;
static double t6= 0.0;
static double t7= 0.0;
static double t8= 0.0;
static double t9= 0.0;
static double v1= 0.0;
static double v10= 0.0;
static double v2= 0.0;
static double v3= 0.0;
static double v4= 0.0;
static double v5= 0.0;
static double v6= 0.0;
static double v7= 0.0;
static double v8= 0.0;
static double v9= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlarfx (String side,
int m,
int n,
double [] v, int _v_offset,
double tau,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset)  {

if (tau == zero)  
    Dummy.go_to("Dlarfx",999999);
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *        Form  H * C, where H has order m.
// *
if (m == 1) 
  Dummy.go_to("Dlarfx",10);
else if (m == 2) 
  Dummy.go_to("Dlarfx",30);
else if (m == 3) 
  Dummy.go_to("Dlarfx",50);
else if (m == 4) 
  Dummy.go_to("Dlarfx",70);
else if (m == 5) 
  Dummy.go_to("Dlarfx",90);
else if (m == 6) 
  Dummy.go_to("Dlarfx",110);
else if (m == 7) 
  Dummy.go_to("Dlarfx",130);
else if (m == 8) 
  Dummy.go_to("Dlarfx",150);
else if (m == 9) 
  Dummy.go_to("Dlarfx",170);
else if (m == 10) 
  Dummy.go_to("Dlarfx",190);
// *
// *        Code for general M
// *
// *        w := C'*v
// *
Dgemv.dgemv("Transpose",m,n,one,c,_c_offset,Ldc,v,_v_offset,1,zero,work,_work_offset,1);
// *
// *        C := C - tau * v * w'
// *
Dger.dger(m,n,-tau,v,_v_offset,1,work,_work_offset,1,c,_c_offset,Ldc);
Dummy.go_to("Dlarfx",410);
label10:
   Dummy.label("Dlarfx",10);
// *
// *        Special code for 1 x 1 Householder
// *
t1 = one-tau*v[(1)- 1+ _v_offset]*v[(1)- 1+ _v_offset];
{
forloop20:
for (j = 1; j <= n; j++) {
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = t1*c[(1)- 1+(j- 1)*Ldc+ _c_offset];
Dummy.label("Dlarfx",20);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label30:
   Dummy.label("Dlarfx",30);
// *
// *        Special code for 2 x 2 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
{
forloop40:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
Dummy.label("Dlarfx",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label50:
   Dummy.label("Dlarfx",50);
// *
// *        Special code for 3 x 3 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
{
forloop60:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
Dummy.label("Dlarfx",60);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label70:
   Dummy.label("Dlarfx",70);
// *
// *        Special code for 4 x 4 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
{
forloop80:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
Dummy.label("Dlarfx",80);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label90:
   Dummy.label("Dlarfx",90);
// *
// *        Special code for 5 x 5 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
{
forloop100:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
Dummy.label("Dlarfx",100);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label110:
   Dummy.label("Dlarfx",110);
// *
// *        Special code for 6 x 6 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
{
forloop120:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset]+v6*c[(6)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
c[(6)- 1+(j- 1)*Ldc+ _c_offset] = c[(6)- 1+(j- 1)*Ldc+ _c_offset]-sum*t6;
Dummy.label("Dlarfx",120);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label130:
   Dummy.label("Dlarfx",130);
// *
// *        Special code for 7 x 7 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
{
forloop140:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset]+v6*c[(6)- 1+(j- 1)*Ldc+ _c_offset]+v7*c[(7)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
c[(6)- 1+(j- 1)*Ldc+ _c_offset] = c[(6)- 1+(j- 1)*Ldc+ _c_offset]-sum*t6;
c[(7)- 1+(j- 1)*Ldc+ _c_offset] = c[(7)- 1+(j- 1)*Ldc+ _c_offset]-sum*t7;
Dummy.label("Dlarfx",140);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label150:
   Dummy.label("Dlarfx",150);
// *
// *        Special code for 8 x 8 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
{
forloop160:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset]+v6*c[(6)- 1+(j- 1)*Ldc+ _c_offset]+v7*c[(7)- 1+(j- 1)*Ldc+ _c_offset]+v8*c[(8)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
c[(6)- 1+(j- 1)*Ldc+ _c_offset] = c[(6)- 1+(j- 1)*Ldc+ _c_offset]-sum*t6;
c[(7)- 1+(j- 1)*Ldc+ _c_offset] = c[(7)- 1+(j- 1)*Ldc+ _c_offset]-sum*t7;
c[(8)- 1+(j- 1)*Ldc+ _c_offset] = c[(8)- 1+(j- 1)*Ldc+ _c_offset]-sum*t8;
Dummy.label("Dlarfx",160);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label170:
   Dummy.label("Dlarfx",170);
// *
// *        Special code for 9 x 9 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
v9 = v[(9)- 1+ _v_offset];
t9 = tau*v9;
{
forloop180:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset]+v6*c[(6)- 1+(j- 1)*Ldc+ _c_offset]+v7*c[(7)- 1+(j- 1)*Ldc+ _c_offset]+v8*c[(8)- 1+(j- 1)*Ldc+ _c_offset]+v9*c[(9)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
c[(6)- 1+(j- 1)*Ldc+ _c_offset] = c[(6)- 1+(j- 1)*Ldc+ _c_offset]-sum*t6;
c[(7)- 1+(j- 1)*Ldc+ _c_offset] = c[(7)- 1+(j- 1)*Ldc+ _c_offset]-sum*t7;
c[(8)- 1+(j- 1)*Ldc+ _c_offset] = c[(8)- 1+(j- 1)*Ldc+ _c_offset]-sum*t8;
c[(9)- 1+(j- 1)*Ldc+ _c_offset] = c[(9)- 1+(j- 1)*Ldc+ _c_offset]-sum*t9;
Dummy.label("Dlarfx",180);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label190:
   Dummy.label("Dlarfx",190);
// *
// *        Special code for 10 x 10 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
v9 = v[(9)- 1+ _v_offset];
t9 = tau*v9;
v10 = v[(10)- 1+ _v_offset];
t10 = tau*v10;
{
forloop200:
for (j = 1; j <= n; j++) {
sum = v1*c[(1)- 1+(j- 1)*Ldc+ _c_offset]+v2*c[(2)- 1+(j- 1)*Ldc+ _c_offset]+v3*c[(3)- 1+(j- 1)*Ldc+ _c_offset]+v4*c[(4)- 1+(j- 1)*Ldc+ _c_offset]+v5*c[(5)- 1+(j- 1)*Ldc+ _c_offset]+v6*c[(6)- 1+(j- 1)*Ldc+ _c_offset]+v7*c[(7)- 1+(j- 1)*Ldc+ _c_offset]+v8*c[(8)- 1+(j- 1)*Ldc+ _c_offset]+v9*c[(9)- 1+(j- 1)*Ldc+ _c_offset]+v10*c[(10)- 1+(j- 1)*Ldc+ _c_offset];
c[(1)- 1+(j- 1)*Ldc+ _c_offset] = c[(1)- 1+(j- 1)*Ldc+ _c_offset]-sum*t1;
c[(2)- 1+(j- 1)*Ldc+ _c_offset] = c[(2)- 1+(j- 1)*Ldc+ _c_offset]-sum*t2;
c[(3)- 1+(j- 1)*Ldc+ _c_offset] = c[(3)- 1+(j- 1)*Ldc+ _c_offset]-sum*t3;
c[(4)- 1+(j- 1)*Ldc+ _c_offset] = c[(4)- 1+(j- 1)*Ldc+ _c_offset]-sum*t4;
c[(5)- 1+(j- 1)*Ldc+ _c_offset] = c[(5)- 1+(j- 1)*Ldc+ _c_offset]-sum*t5;
c[(6)- 1+(j- 1)*Ldc+ _c_offset] = c[(6)- 1+(j- 1)*Ldc+ _c_offset]-sum*t6;
c[(7)- 1+(j- 1)*Ldc+ _c_offset] = c[(7)- 1+(j- 1)*Ldc+ _c_offset]-sum*t7;
c[(8)- 1+(j- 1)*Ldc+ _c_offset] = c[(8)- 1+(j- 1)*Ldc+ _c_offset]-sum*t8;
c[(9)- 1+(j- 1)*Ldc+ _c_offset] = c[(9)- 1+(j- 1)*Ldc+ _c_offset]-sum*t9;
c[(10)- 1+(j- 1)*Ldc+ _c_offset] = c[(10)- 1+(j- 1)*Ldc+ _c_offset]-sum*t10;
Dummy.label("Dlarfx",200);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
}              // Close if()
else  {
  // *
// *        Form  C * H, where H has order n.
// *
if (n == 1) 
  Dummy.go_to("Dlarfx",210);
else if (n == 2) 
  Dummy.go_to("Dlarfx",230);
else if (n == 3) 
  Dummy.go_to("Dlarfx",250);
else if (n == 4) 
  Dummy.go_to("Dlarfx",270);
else if (n == 5) 
  Dummy.go_to("Dlarfx",290);
else if (n == 6) 
  Dummy.go_to("Dlarfx",310);
else if (n == 7) 
  Dummy.go_to("Dlarfx",330);
else if (n == 8) 
  Dummy.go_to("Dlarfx",350);
else if (n == 9) 
  Dummy.go_to("Dlarfx",370);
else if (n == 10) 
  Dummy.go_to("Dlarfx",390);
// *
// *        Code for general N
// *
// *        w := C * v
// *
Dgemv.dgemv("No transpose",m,n,one,c,_c_offset,Ldc,v,_v_offset,1,zero,work,_work_offset,1);
// *
// *        C := C - tau * w * v'
// *
Dger.dger(m,n,-tau,work,_work_offset,1,v,_v_offset,1,c,_c_offset,Ldc);
Dummy.go_to("Dlarfx",410);
label210:
   Dummy.label("Dlarfx",210);
// *
// *        Special code for 1 x 1 Householder
// *
t1 = one-tau*v[(1)- 1+ _v_offset]*v[(1)- 1+ _v_offset];
{
forloop220:
for (j = 1; j <= m; j++) {
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = t1*c[(j)- 1+(1- 1)*Ldc+ _c_offset];
Dummy.label("Dlarfx",220);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label230:
   Dummy.label("Dlarfx",230);
// *
// *        Special code for 2 x 2 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
{
forloop240:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
Dummy.label("Dlarfx",240);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label250:
   Dummy.label("Dlarfx",250);
// *
// *        Special code for 3 x 3 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
{
forloop260:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
Dummy.label("Dlarfx",260);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label270:
   Dummy.label("Dlarfx",270);
// *
// *        Special code for 4 x 4 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
{
forloop280:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
Dummy.label("Dlarfx",280);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label290:
   Dummy.label("Dlarfx",290);
// *
// *        Special code for 5 x 5 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
{
forloop300:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
Dummy.label("Dlarfx",300);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label310:
   Dummy.label("Dlarfx",310);
// *
// *        Special code for 6 x 6 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
{
forloop320:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset]+v6*c[(j)- 1+(6- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
c[(j)- 1+(6- 1)*Ldc+ _c_offset] = c[(j)- 1+(6- 1)*Ldc+ _c_offset]-sum*t6;
Dummy.label("Dlarfx",320);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label330:
   Dummy.label("Dlarfx",330);
// *
// *        Special code for 7 x 7 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
{
forloop340:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset]+v6*c[(j)- 1+(6- 1)*Ldc+ _c_offset]+v7*c[(j)- 1+(7- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
c[(j)- 1+(6- 1)*Ldc+ _c_offset] = c[(j)- 1+(6- 1)*Ldc+ _c_offset]-sum*t6;
c[(j)- 1+(7- 1)*Ldc+ _c_offset] = c[(j)- 1+(7- 1)*Ldc+ _c_offset]-sum*t7;
Dummy.label("Dlarfx",340);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label350:
   Dummy.label("Dlarfx",350);
// *
// *        Special code for 8 x 8 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
{
forloop360:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset]+v6*c[(j)- 1+(6- 1)*Ldc+ _c_offset]+v7*c[(j)- 1+(7- 1)*Ldc+ _c_offset]+v8*c[(j)- 1+(8- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
c[(j)- 1+(6- 1)*Ldc+ _c_offset] = c[(j)- 1+(6- 1)*Ldc+ _c_offset]-sum*t6;
c[(j)- 1+(7- 1)*Ldc+ _c_offset] = c[(j)- 1+(7- 1)*Ldc+ _c_offset]-sum*t7;
c[(j)- 1+(8- 1)*Ldc+ _c_offset] = c[(j)- 1+(8- 1)*Ldc+ _c_offset]-sum*t8;
Dummy.label("Dlarfx",360);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label370:
   Dummy.label("Dlarfx",370);
// *
// *        Special code for 9 x 9 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
v9 = v[(9)- 1+ _v_offset];
t9 = tau*v9;
{
forloop380:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset]+v6*c[(j)- 1+(6- 1)*Ldc+ _c_offset]+v7*c[(j)- 1+(7- 1)*Ldc+ _c_offset]+v8*c[(j)- 1+(8- 1)*Ldc+ _c_offset]+v9*c[(j)- 1+(9- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
c[(j)- 1+(6- 1)*Ldc+ _c_offset] = c[(j)- 1+(6- 1)*Ldc+ _c_offset]-sum*t6;
c[(j)- 1+(7- 1)*Ldc+ _c_offset] = c[(j)- 1+(7- 1)*Ldc+ _c_offset]-sum*t7;
c[(j)- 1+(8- 1)*Ldc+ _c_offset] = c[(j)- 1+(8- 1)*Ldc+ _c_offset]-sum*t8;
c[(j)- 1+(9- 1)*Ldc+ _c_offset] = c[(j)- 1+(9- 1)*Ldc+ _c_offset]-sum*t9;
Dummy.label("Dlarfx",380);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
label390:
   Dummy.label("Dlarfx",390);
// *
// *        Special code for 10 x 10 Householder
// *
v1 = v[(1)- 1+ _v_offset];
t1 = tau*v1;
v2 = v[(2)- 1+ _v_offset];
t2 = tau*v2;
v3 = v[(3)- 1+ _v_offset];
t3 = tau*v3;
v4 = v[(4)- 1+ _v_offset];
t4 = tau*v4;
v5 = v[(5)- 1+ _v_offset];
t5 = tau*v5;
v6 = v[(6)- 1+ _v_offset];
t6 = tau*v6;
v7 = v[(7)- 1+ _v_offset];
t7 = tau*v7;
v8 = v[(8)- 1+ _v_offset];
t8 = tau*v8;
v9 = v[(9)- 1+ _v_offset];
t9 = tau*v9;
v10 = v[(10)- 1+ _v_offset];
t10 = tau*v10;
{
forloop400:
for (j = 1; j <= m; j++) {
sum = v1*c[(j)- 1+(1- 1)*Ldc+ _c_offset]+v2*c[(j)- 1+(2- 1)*Ldc+ _c_offset]+v3*c[(j)- 1+(3- 1)*Ldc+ _c_offset]+v4*c[(j)- 1+(4- 1)*Ldc+ _c_offset]+v5*c[(j)- 1+(5- 1)*Ldc+ _c_offset]+v6*c[(j)- 1+(6- 1)*Ldc+ _c_offset]+v7*c[(j)- 1+(7- 1)*Ldc+ _c_offset]+v8*c[(j)- 1+(8- 1)*Ldc+ _c_offset]+v9*c[(j)- 1+(9- 1)*Ldc+ _c_offset]+v10*c[(j)- 1+(10- 1)*Ldc+ _c_offset];
c[(j)- 1+(1- 1)*Ldc+ _c_offset] = c[(j)- 1+(1- 1)*Ldc+ _c_offset]-sum*t1;
c[(j)- 1+(2- 1)*Ldc+ _c_offset] = c[(j)- 1+(2- 1)*Ldc+ _c_offset]-sum*t2;
c[(j)- 1+(3- 1)*Ldc+ _c_offset] = c[(j)- 1+(3- 1)*Ldc+ _c_offset]-sum*t3;
c[(j)- 1+(4- 1)*Ldc+ _c_offset] = c[(j)- 1+(4- 1)*Ldc+ _c_offset]-sum*t4;
c[(j)- 1+(5- 1)*Ldc+ _c_offset] = c[(j)- 1+(5- 1)*Ldc+ _c_offset]-sum*t5;
c[(j)- 1+(6- 1)*Ldc+ _c_offset] = c[(j)- 1+(6- 1)*Ldc+ _c_offset]-sum*t6;
c[(j)- 1+(7- 1)*Ldc+ _c_offset] = c[(j)- 1+(7- 1)*Ldc+ _c_offset]-sum*t7;
c[(j)- 1+(8- 1)*Ldc+ _c_offset] = c[(j)- 1+(8- 1)*Ldc+ _c_offset]-sum*t8;
c[(j)- 1+(9- 1)*Ldc+ _c_offset] = c[(j)- 1+(9- 1)*Ldc+ _c_offset]-sum*t9;
c[(j)- 1+(10- 1)*Ldc+ _c_offset] = c[(j)- 1+(10- 1)*Ldc+ _c_offset]-sum*t10;
Dummy.label("Dlarfx",400);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarfx",410);
}              //  Close else.
label410:
   Dummy.label("Dlarfx",410);
Dummy.go_to("Dlarfx",999999);
// *
// *     End of DLARFX
// *
Dummy.label("Dlarfx",999999);
return;
   }
} // End class.
