/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlargv {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARGV generates a vector of real plane rotations, determined by
// *  elements of the real vectors x and y. For i = 1,2,...,n
// *
// *     (  c(i)  s(i) ) ( x(i) ) = ( a(i) )
// *     ( -s(i)  c(i) ) ( y(i) ) = (   0  )
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of plane rotations to be generated.
// *
// *  X       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCX)
// *          On entry, the vector x.
// *          On exit, x(i) is overwritten by a(i), for i = 1,...,n.
// *
// *  INCX    (input) INTEGER
// *          The increment between elements of X. INCX > 0.
// *
// *  Y       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCY)
// *          On entry, the vector y.
// *          On exit, the sines of the plane rotations.
// *
// *  INCY    (input) INTEGER
// *          The increment between elements of Y. INCY > 0.
// *
// *  C       (output) DOUBLE PRECISION array, dimension (1+(N-1)*INCC)
// *          The cosines of the plane rotations.
// *
// *  INCC    (input) INTEGER
// *          The increment between elements of C. INCC > 0.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ic= 0;
static int ix= 0;
static int iy= 0;
static double tt= 0.0;
static double w= 0.0;
static double xi= 0.0;
static double yi= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlargv (int n,
double [] x, int _x_offset,
int incx,
double [] y, int _y_offset,
int incy,
double [] c, int _c_offset,
int incc)  {

ix = 1;
iy = 1;
ic = 1;
{
forloop10:
for (i = 1; i <= n; i++) {
xi = x[(ix)- 1+ _x_offset];
yi = y[(iy)- 1+ _y_offset];
if (xi == zero)  {
    c[(ic)- 1+ _c_offset] = zero;
y[(iy)- 1+ _y_offset] = one;
x[(ix)- 1+ _x_offset] = yi;
}              // Close if()
else  {
  w = Math.max(Math.abs(xi), Math.abs(yi)) ;
xi = xi/w;
yi = yi/w;
tt = Math.sqrt(xi*xi+yi*yi);
c[(ic)- 1+ _c_offset] = xi/tt;
y[(iy)- 1+ _y_offset] = yi/tt;
x[(ix)- 1+ _x_offset] = w*tt;
}              //  Close else.
ix = ix+incx;
iy = iy+incy;
ic = ic+incc;
Dummy.label("Dlargv",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dlargv",999999);
// *
// *     End of DLARGV
// *
Dummy.label("Dlargv",999999);
return;
   }
} // End class.
