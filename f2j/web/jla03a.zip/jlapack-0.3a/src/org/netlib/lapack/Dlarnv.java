/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlarnv {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994 
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARNV returns a vector of n random real numbers from a uniform or
// *  normal distribution.
// *
// *  Arguments
// *  =========
// *
// *  IDIST   (input) INTEGER
// *          Specifies the distribution of the random numbers:
// *          = 1:  uniform (0,1)
// *          = 2:  uniform (-1,1)
// *          = 3:  normal (0,1)
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator; the array
// *          elements must be between 0 and 4095, and ISEED(4) must be
// *          odd.
// *          On exit, the seed is updated.
// *
// *  N       (input) INTEGER
// *          The number of random numbers to be generated.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (N)
// *          The generated random numbers.
// *
// *  Further Details
// *  ===============
// *
// *  This routine calls the auxiliary routine DLARUV to generate random
// *  real numbers from a uniform (0,1) distribution, in batches of up to
// *  128 using vectorisable code. The Box-Muller method is used to
// *  transform numbers from a uniform to a normal distribution.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double two= 2.0e+0;
static int lv= 128;
static double twopi= 6.2831853071795864769252867663e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int il= 0;
static int il2= 0;
static int iv= 0;
// *     ..
// *     .. Local Arrays ..
static double [] u= new double[(lv)];
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlarnv (int idist,
int [] iseed, int _iseed_offset,
int n,
double [] x, int _x_offset)  {

{
int _iv_inc = lv/2;
forloop40:
for (iv = 1; (_iv_inc < 0) ? iv >= n : iv <= n; iv += _iv_inc) {
il = (int)(Math.min(lv/2, n-iv+1) );
if (idist == 3)  {
    il2 = 2*il;
}              // Close if()
else  {
  il2 = il;
}              //  Close else.
// *
// *        Call DLARUV to generate IL2 numbers from a uniform (0,1)
// *        distribution (IL2 <= LV)
// *
Dlaruv.dlaruv(iseed,_iseed_offset,il2,u,0);
// *
if (idist == 1)  {
    // *
// *           Copy generated numbers
// *
{
forloop10:
for (i = 1; i <= il; i++) {
x[(iv+i-1)- 1+ _x_offset] = u[(i)- 1];
Dummy.label("Dlarnv",10);
}              //  Close for() loop. 
}
}              // Close if()
else if (idist == 2)  {
    // *
// *           Convert generated numbers to uniform (-1,1) distribution
// *
{
forloop20:
for (i = 1; i <= il; i++) {
x[(iv+i-1)- 1+ _x_offset] = two*u[(i)- 1]-one;
Dummy.label("Dlarnv",20);
}              //  Close for() loop. 
}
}              // Close else if()
else if (idist == 3)  {
    // *
// *           Convert generated numbers to normal (0,1) distribution
// *
{
forloop30:
for (i = 1; i <= il; i++) {
x[(iv+i-1)- 1+ _x_offset] = Math.sqrt(-two*Math.log(u[(2*i-1)- 1]))*Math.cos(twopi*u[(2*i)- 1]);
Dummy.label("Dlarnv",30);
}              //  Close for() loop. 
}
}              // Close else if()
Dummy.label("Dlarnv",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarnv",999999);
// *
// *     End of DLARNV
// *
Dummy.label("Dlarnv",999999);
return;
   }
} // End class.
