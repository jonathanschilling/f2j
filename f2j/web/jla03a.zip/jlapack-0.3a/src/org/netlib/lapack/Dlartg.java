/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlartg {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARTG generate a plane rotation so that
// *
// *     [  CS  SN  ]  .  [ F ]  =  [ R ]   where CS**2 + SN**2 = 1.
// *     [ -SN  CS  ]     [ G ]     [ 0 ]
// *
// *  This is a slower, more accurate version of the BLAS1 routine DROTG,
// *  with the following other differences:
// *     F and G are unchanged on return.
// *     If G=0, then CS=1 and SN=0.
// *     If F=0 and (G .ne. 0), then CS=0 and SN=1 without doing any
// *        floating point operations (saves work in DBDSQR when
// *        there are zeros on the diagonal).
// *
// *  If F exceeds G in magnitude, CS will be positive.
// *
// *  Arguments
// *  =========
// *
// *  F       (input) DOUBLE PRECISION
// *          The first component of vector to be rotated.
// *
// *  G       (input) DOUBLE PRECISION
// *          The second component of vector to be rotated.
// *
// *  CS      (output) DOUBLE PRECISION
// *          The cosine of the rotation.
// *
// *  SN      (output) DOUBLE PRECISION
// *          The sine of the rotation.
// *
// *  R       (output) DOUBLE PRECISION
// *          The nonzero component of the rotated vector.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
// *     ..
// *     .. Local Scalars ..
static int count= 0;
static int i= 0;
static double eps= 0.0;
static double f1= 0.0;
static double g1= 0.0;
static double safmin= 0.0;
static double safmn2= 0.0;
static double safmx2= 0.0;
static double scale= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlartg (double f,
double g,
doubleW cs,
doubleW sn,
doubleW r)  {

if (first)  {
    first = false;
safmin = Dlamch.dlamch("S");
eps = Dlamch.dlamch("E");
safmn2 = Math.pow(Dlamch.dlamch("B"), (int)(Math.log(safmin/eps)/Math.log(Dlamch.dlamch("B"))/two));
safmx2 = one/safmn2;
}              // Close if()
if (g == zero)  {
    cs.val = one;
sn.val = zero;
r.val = f;
}              // Close if()
else if (f == zero)  {
    cs.val = zero;
sn.val = one;
r.val = g;
}              // Close else if()
else  {
  f1 = f;
g1 = g;
scale = Math.max(Math.abs(f1), Math.abs(g1)) ;
if (scale >= safmx2)  {
    count = 0;
label10:
   Dummy.label("Dlartg",10);
count = count+1;
f1 = f1*safmn2;
g1 = g1*safmn2;
scale = Math.max(Math.abs(f1), Math.abs(g1)) ;
if (scale >= safmx2)  
    Dummy.go_to("Dlartg",10);
r.val = Math.sqrt(Math.pow(f1, 2)+Math.pow(g1, 2));
cs.val = f1/r.val;
sn.val = g1/r.val;
{
forloop20:
for (i = 1; i <= count; i++) {
r.val = r.val*safmx2;
Dummy.label("Dlartg",20);
}              //  Close for() loop. 
}
}              // Close if()
else if (scale <= safmn2)  {
    count = 0;
label30:
   Dummy.label("Dlartg",30);
count = count+1;
f1 = f1*safmx2;
g1 = g1*safmx2;
scale = Math.max(Math.abs(f1), Math.abs(g1)) ;
if (scale <= safmn2)  
    Dummy.go_to("Dlartg",30);
r.val = Math.sqrt(Math.pow(f1, 2)+Math.pow(g1, 2));
cs.val = f1/r.val;
sn.val = g1/r.val;
{
forloop40:
for (i = 1; i <= count; i++) {
r.val = r.val*safmn2;
Dummy.label("Dlartg",40);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  r.val = Math.sqrt(Math.pow(f1, 2)+Math.pow(g1, 2));
cs.val = f1/r.val;
sn.val = g1/r.val;
}              //  Close else.
if (Math.abs(f) > Math.abs(g) && cs.val < zero)  {
    cs.val = -cs.val;
sn.val = -sn.val;
r.val = -r.val;
}              // Close if()
}              //  Close else.
Dummy.go_to("Dlartg",999999);
// *
// *     End of DLARTG
// *
Dummy.label("Dlartg",999999);
return;
   }
} // End class.
