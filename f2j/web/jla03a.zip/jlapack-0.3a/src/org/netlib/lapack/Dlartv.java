/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlartv {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARTV applies a vector of real plane rotations to elements of the
// *  real vectors x and y. For i = 1,2,...,n
// *
// *     ( x(i) ) := (  c(i)  s(i) ) ( x(i) )
// *     ( y(i) )    ( -s(i)  c(i) ) ( y(i) )
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of plane rotations to be applied.
// *
// *  X       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCX)
// *          The vector x.
// *
// *  INCX    (input) INTEGER
// *          The increment between elements of X. INCX > 0.
// *
// *  Y       (input/output) DOUBLE PRECISION array,
// *                         dimension (1+(N-1)*INCY)
// *          The vector y.
// *
// *  INCY    (input) INTEGER
// *          The increment between elements of Y. INCY > 0.
// *
// *  C       (input) DOUBLE PRECISION array, dimension (1+(N-1)*INCC)
// *          The cosines of the plane rotations.
// *
// *  S       (input) DOUBLE PRECISION array, dimension (1+(N-1)*INCC)
// *          The sines of the plane rotations.
// *
// *  INCC    (input) INTEGER
// *          The increment between elements of C and S. INCC > 0.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int ic= 0;
static int ix= 0;
static int iy= 0;
static double xi= 0.0;
static double yi= 0.0;
// *     ..
// *     .. Executable Statements ..
// *

public static void dlartv (int n,
double [] x, int _x_offset,
int incx,
double [] y, int _y_offset,
int incy,
double [] c, int _c_offset,
double [] s, int _s_offset,
int incc)  {

ix = 1;
iy = 1;
ic = 1;
{
forloop10:
for (i = 1; i <= n; i++) {
xi = x[(ix)- 1+ _x_offset];
yi = y[(iy)- 1+ _y_offset];
x[(ix)- 1+ _x_offset] = c[(ic)- 1+ _c_offset]*xi+s[(ic)- 1+ _s_offset]*yi;
y[(iy)- 1+ _y_offset] = c[(ic)- 1+ _c_offset]*yi-s[(ic)- 1+ _s_offset]*xi;
ix = ix+incx;
iy = iy+incy;
ic = ic+incc;
Dummy.label("Dlartv",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dlartv",999999);
// *
// *     End of DLARTV
// *
Dummy.label("Dlartv",999999);
return;
   }
} // End class.
