/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlas2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAS2  computes the singular values of the 2-by-2 matrix
// *     [  F   G  ]
// *     [  0   H  ].
// *  On return, SSMIN is the smaller singular value and SSMAX is the
// *  larger singular value.
// *
// *  Arguments
// *  =========
// *
// *  F       (input) DOUBLE PRECISION
// *          The (1,1) element of the 2-by-2 matrix.
// *
// *  G       (input) DOUBLE PRECISION
// *          The (1,2) element of the 2-by-2 matrix.
// *
// *  H       (input) DOUBLE PRECISION
// *          The (2,2) element of the 2-by-2 matrix.
// *
// *  SSMIN   (output) DOUBLE PRECISION
// *          The smaller singular value.
// *
// *  SSMAX   (output) DOUBLE PRECISION
// *          The larger singular value.
// *
// *  Further Details
// *  ===============
// *
// *  Barring over/underflow, all output quantities are correct to within
// *  a few units in the last place (ulps), even in the absence of a guard
// *  digit in addition/subtraction.
// *
// *  In IEEE arithmetic, the code works correctly if one matrix element is
// *  infinite.
// *
// *  Overflow will not occur unless the largest singular value itself
// *  overflows, or is within a few ulps of overflow. (On machines with
// *  partial overflow, like the Cray, overflow may occur if the largest
// *  singular value is within a factor of 2 of overflow.)
// *
// *  Underflow is harmless if underflow is gradual. Otherwise, results
// *  may correspond to a matrix modified by perturbations of size near
// *  the underflow threshold.
// *
// *  ====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
// *     ..
// *     .. Local Scalars ..
static double as= 0.0;
static double at= 0.0;
static double au= 0.0;
static double c= 0.0;
static double fa= 0.0;
static double fhmn= 0.0;
static double fhmx= 0.0;
static double ga= 0.0;
static double ha= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlas2 (double f,
double g,
double h,
doubleW ssmin,
doubleW ssmax)  {

fa = Math.abs(f);
ga = Math.abs(g);
ha = Math.abs(h);
fhmn = Math.min(fa, ha) ;
fhmx = Math.max(fa, ha) ;
if (fhmn == zero)  {
    ssmin.val = zero;
if (fhmx == zero)  {
    ssmax.val = ga;
}              // Close if()
else  {
  ssmax.val = Math.max(fhmx, ga) *Math.sqrt(one+Math.pow((Math.min(fhmx, ga) /Math.max(fhmx, ga) ), 2));
}              //  Close else.
}              // Close if()
else  {
  if (ga < fhmx)  {
    as = one+fhmn/fhmx;
at = (fhmx-fhmn)/fhmx;
au = Math.pow((ga/fhmx), 2);
c = two/(Math.sqrt(as*as+au)+Math.sqrt(at*at+au));
ssmin.val = fhmn*c;
ssmax.val = fhmx/c;
}              // Close if()
else  {
  au = fhmx/ga;
if (au == zero)  {
    // *
// *              Avoid possible harmful underflow if exponent range
// *              asymmetric (true SSMIN may not underflow even if
// *              AU underflows)
// *
ssmin.val = (fhmn*fhmx)/ga;
ssmax.val = ga;
}              // Close if()
else  {
  as = one+fhmn/fhmx;
at = (fhmx-fhmn)/fhmx;
c = one/(Math.sqrt(one+Math.pow((as*au), 2))+Math.sqrt(one+Math.pow((at*au), 2)));
ssmin.val = (fhmn*c)*au;
ssmin.val = ssmin.val+ssmin.val;
ssmax.val = ga/(c+c);
}              //  Close else.
}              //  Close else.
}              //  Close else.
Dummy.go_to("Dlas2",999999);
// *
// *     End of DLAS2
// *
Dummy.label("Dlas2",999999);
return;
   }
} // End class.
