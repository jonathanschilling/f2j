/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlascl {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASCL multiplies the M by N real matrix A by the real scalar
// *  CTO/CFROM.  This is done without over/underflow as long as the final
// *  result CTO*A(I,J)/CFROM does not over/underflow. TYPE specifies that
// *  A may be full, upper triangular, lower triangular, upper Hessenberg,
// *  or banded.
// *
// *  Arguments
// *  =========
// *
// *  TYPE    (input) CHARACTER*1
// *          TYPE indices the storage type of the input matrix.
// *          = 'G':  A is a full matrix.
// *          = 'L':  A is a lower triangular matrix.
// *          = 'U':  A is an upper triangular matrix.
// *          = 'H':  A is an upper Hessenberg matrix.
// *          = 'B':  A is a symmetric band matrix with lower bandwidth KL
// *                  and upper bandwidth KU and with the only the lower
// *                  half stored.
// *          = 'Q':  A is a symmetric band matrix with lower bandwidth KL
// *                  and upper bandwidth KU and with the only the upper
// *                  half stored.
// *          = 'Z':  A is a band matrix with lower bandwidth KL and upper
// *                  bandwidth KU.
// *
// *  KL      (input) INTEGER
// *          The lower bandwidth of A.  Referenced only if TYPE = 'B',
// *          'Q' or 'Z'.
// *
// *  KU      (input) INTEGER
// *          The upper bandwidth of A.  Referenced only if TYPE = 'B',
// *          'Q' or 'Z'.
// *
// *  CFROM   (input) DOUBLE PRECISION
// *  CTO     (input) DOUBLE PRECISION
// *          The matrix A is multiplied by CTO/CFROM. A(I,J) is computed
// *          without over/underflow if the final result CTO*A(I,J)/CFROM
// *          can be represented without over/underflow.  CFROM must be
// *          nonzero.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,M)
// *          The matrix to be multiplied by CTO/CFROM.  See TYPE for the
// *          storage type.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  INFO    (output) INTEGER
// *          0  - successful exit
// *          <0 - if INFO = -i, the i-th argument had an illegal value.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean done= false;
static int i= 0;
static int itype= 0;
static int j= 0;
static int k1= 0;
static int k2= 0;
static int k3= 0;
static int k4= 0;
static double bignum= 0.0;
static double cfrom1= 0.0;
static double cfromc= 0.0;
static double cto1= 0.0;
static double ctoc= 0.0;
static double mul= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dlascl (String type,
int kl,
int ku,
double cfrom,
double cto,
int m,
int n,
double [] a, int _a_offset,
int lda,
intW info)  {

info.val = 0;
// *
if ((type.toLowerCase().charAt(0) == "G".toLowerCase().charAt(0)))  {
    itype = 0;
}              // Close if()
else if ((type.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    itype = 1;
}              // Close else if()
else if ((type.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    itype = 2;
}              // Close else if()
else if ((type.toLowerCase().charAt(0) == "H".toLowerCase().charAt(0)))  {
    itype = 3;
}              // Close else if()
else if ((type.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    itype = 4;
}              // Close else if()
else if ((type.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0)))  {
    itype = 5;
}              // Close else if()
else if ((type.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0)))  {
    itype = 6;
}              // Close else if()
else  {
  itype = -1;
}              //  Close else.
// *
if (itype == -1)  {
    info.val = -1;
}              // Close if()
else if (cfrom == zero)  {
    info.val = -4;
}              // Close else if()
else if (m < 0)  {
    info.val = -6;
}              // Close else if()
else if (n < 0 || (itype == 4 && n != m) || (itype == 5 && n != m))  {
    info.val = -7;
}              // Close else if()
else if (itype <= 3 && lda < Math.max(1, m) )  {
    info.val = -9;
}              // Close else if()
else if (itype >= 4)  {
    if (kl < 0 || kl > Math.max(m-1, 0) )  {
    info.val = -2;
}              // Close if()
else if (ku < 0 || ku > Math.max(n-1, 0)  || ((itype == 4 || itype == 5) && kl != ku))  {
    info.val = -3;
}              // Close else if()
else if ((itype == 4 && lda < kl+1) || (itype == 5 && lda < ku+1) || (itype == 6 && lda < 2*kl+ku+1))  {
    info.val = -9;
}              // Close else if()
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DLASCL",-info.val);
Dummy.go_to("Dlascl",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0 || m == 0)  
    Dummy.go_to("Dlascl",999999);
// *
// *     Get machine parameters
// *
smlnum = Dlamch.dlamch("S");
bignum = one/smlnum;
// *
cfromc = cfrom;
ctoc = cto;
// *
label10:
   Dummy.label("Dlascl",10);
cfrom1 = cfromc*smlnum;
cto1 = ctoc/bignum;
if (Math.abs(cfrom1) > Math.abs(ctoc) && ctoc != zero)  {
    mul = smlnum;
done = false;
cfromc = cfrom1;
}              // Close if()
else if (Math.abs(cto1) > Math.abs(cfromc))  {
    mul = bignum;
done = false;
ctoc = cto1;
}              // Close else if()
else  {
  mul = ctoc/cfromc;
done = true;
}              //  Close else.
// *
if (itype == 0)  {
    // *
// *        Full matrix
// *
{
forloop30:
for (j = 1; j <= n; j++) {
{
forloop20:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",20);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (itype == 1)  {
    // *
// *        Lower triangular matrix
// *
{
forloop50:
for (j = 1; j <= n; j++) {
{
forloop40:
for (i = j; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",40);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",50);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 2)  {
    // *
// *        Upper triangular matrix
// *
{
forloop70:
for (j = 1; j <= n; j++) {
{
forloop60:
for (i = 1; i <= Math.min(j, m) ; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",60);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",70);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 3)  {
    // *
// *        Upper Hessenberg matrix
// *
{
forloop90:
for (j = 1; j <= n; j++) {
{
forloop80:
for (i = 1; i <= Math.min(j+1, m) ; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",80);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",90);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *        Lower half of a symmetric band matrix
// *
k3 = kl+1;
k4 = n+1;
{
forloop110:
for (j = 1; j <= n; j++) {
{
forloop100:
for (i = 1; i <= Math.min(k3, k4-j) ; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",100);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",110);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *        Upper half of a symmetric band matrix
// *
k1 = ku+2;
k3 = ku+1;
{
forloop130:
for (j = 1; j <= n; j++) {
{
forloop120:
for (i = (int)(Math.max(k1-j, 1) ); i <= k3; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",120);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",130);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 6)  {
    // *
// *        Band matrix
// *
k1 = kl+ku+2;
k2 = kl+1;
k3 = 2*kl+ku+1;
k4 = kl+ku+1+m;
{
forloop150:
for (j = 1; j <= n; j++) {
{
forloop140:
for (i = (int)(Math.max(k1-j, k2) ); i <= Math.min(k3, k4-j) ; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset]*mul;
Dummy.label("Dlascl",140);
}              //  Close for() loop. 
}
Dummy.label("Dlascl",150);
}              //  Close for() loop. 
}
// *
}              // Close else if()
// *
if (!done)  
    Dummy.go_to("Dlascl",10);
// *
Dummy.go_to("Dlascl",999999);
// *
// *     End of DLASCL
// *
Dummy.label("Dlascl",999999);
return;
   }
} // End class.
