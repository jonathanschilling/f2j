/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlaset {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASET initializes an m-by-n matrix A to BETA on the diagonal and
// *  ALPHA on the offdiagonals.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies the part of the matrix A to be set.
// *          = 'U':      Upper triangular part is set; the strictly lower
// *                      triangular part of A is not changed.
// *          = 'L':      Lower triangular part is set; the strictly upper
// *                      triangular part of A is not changed.
// *          Otherwise:  All of the matrix A is set.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  ALPHA   (input) DOUBLE PRECISION
// *          The constant to which the offdiagonal elements are to be set.
// *
// *  BETA    (input) DOUBLE PRECISION
// *          The constant to which the diagonal elements are to be set.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On exit, the leading m-by-n submatrix of A is set as follows:
// *
// *          if UPLO = 'U', A(i,j) = ALPHA, 1<=i<=j-1, 1<=j<=n,
// *          if UPLO = 'L', A(i,j) = ALPHA, j+1<=i<=m, 1<=j<=n,
// *          otherwise,     A(i,j) = ALPHA, 1<=i<=m, 1<=j<=n, i.ne.j,
// *
// *          and, for all UPLO, A(i,i) = BETA, 1<=i<=min(m,n).
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// * =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlaset (String uplo,
int m,
int n,
double alpha,
double beta,
double [] a, int _a_offset,
int lda)  {

if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *        Set the strictly upper triangular or trapezoidal part of the
// *        array to ALPHA.
// *
{
forloop20:
for (j = 2; j <= n; j++) {
{
forloop10:
for (i = 1; i <= Math.min(j-1, m) ; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = alpha;
Dummy.label("Dlaset",10);
}              //  Close for() loop. 
}
Dummy.label("Dlaset",20);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if ((uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    // *
// *        Set the strictly lower triangular or trapezoidal part of the
// *        array to ALPHA.
// *
{
forloop40:
for (j = 1; j <= Math.min(m, n) ; j++) {
{
forloop30:
for (i = j+1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = alpha;
Dummy.label("Dlaset",30);
}              //  Close for() loop. 
}
Dummy.label("Dlaset",40);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else  {
  // *
// *        Set the leading m-by-n submatrix to ALPHA.
// *
{
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = alpha;
Dummy.label("Dlaset",50);
}              //  Close for() loop. 
}
Dummy.label("Dlaset",60);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Set the first min(M,N) diagonal elements to BETA.
// *
{
forloop70:
for (i = 1; i <= Math.min(m, n) ; i++) {
a[(i)- 1+(i- 1)*lda+ _a_offset] = beta;
Dummy.label("Dlaset",70);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dlaset",999999);
// *
// *     End of DLASET
// *
Dummy.label("Dlaset",999999);
return;
   }
} // End class.
