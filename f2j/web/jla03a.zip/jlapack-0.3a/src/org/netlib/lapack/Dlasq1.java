/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlasq1 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *     Purpose
// *     =======
// *
// *     DLASQ1 computes the singular values of a real N-by-N bidiagonal
// *     matrix with diagonal D and off-diagonal E. The singular values are
// *     computed to high relative accuracy, barring over/underflow or
// *     denormalization. The algorithm is described in
// *
// *     "Accurate singular values and differential qd algorithms," by
// *     K. V. Fernando and B. N. Parlett,
// *     Numer. Math., Vol-67, No. 2, pp. 191-230,1994.
// *
// *     See also
// *     "Implementation of differential qd algorithms," by
// *     K. V. Fernando and B. N. Parlett, Technical Report,
// *     Department of Mathematics, University of California at Berkeley,
// *     1994 (Under preparation).
// *
// *     Arguments
// *     =========
// *
// *  N       (input) INTEGER
// *          The number of rows and columns in the matrix. N >= 0.
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, D contains the diagonal elements of the
// *          bidiagonal matrix whose SVD is desired. On normal exit,
// *          D contains the singular values in decreasing order.
// *
// *  E       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, elements E(1:N-1) contain the off-diagonal elements
// *          of the bidiagonal matrix whose SVD is desired.
// *          On exit, E is overwritten.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, the algorithm did not converge;  i
// *                specifies how many superdiagonals did not converge.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double meigth= -0.125e0;
static double zero= 0.0e0;
static double one= 1.0e0;
static double ten= 10.0e0;
static double hundrd= 100.0e0;
static double two56= 256.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean restrt= false;
static int i= 0;
static intW ierr= new intW(0);
static int j= 0;
static int ke= 0;
static intW kend= new intW(0);
static int m= 0;
static int ny= 0;
static doubleW dm= new doubleW(0.0);
static double dx= 0.0;
static double eps= 0.0;
static double scl= 0.0;
static double sfmin= 0.0;
static doubleW sig1= new doubleW(0.0);
static doubleW sig2= new doubleW(0.0);
static doubleW sigmn= new doubleW(0.0);
static doubleW sigmx= new doubleW(0.0);
static double small2= 0.0;
static double thresh= 0.0;
static double tol= 0.0;
static double tol2= 0.0;
static double tolmul= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..

public static void dlasq1 (int n,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -2;
Xerbla.xerbla("DLASQ1",-info.val);
Dummy.go_to("Dlasq1",999999);
}              // Close if()
else if (n == 0)  {
    Dummy.go_to("Dlasq1",999999);
}              // Close else if()
else if (n == 1)  {
    d[(1)- 1+ _d_offset] = Math.abs(d[(1)- 1+ _d_offset]);
Dummy.go_to("Dlasq1",999999);
}              // Close else if()
else if (n == 2)  {
    Dlas2.dlas2(d[(1)- 1+ _d_offset],e[(1)- 1+ _e_offset],d[(2)- 1+ _d_offset],sigmn,sigmx);
d[(1)- 1+ _d_offset] = sigmx.val;
d[(2)- 1+ _d_offset] = sigmn.val;
Dummy.go_to("Dlasq1",999999);
}              // Close else if()
// *
// *     Estimate the largest singular value
// *
sigmx.val = zero;
{
forloop10:
for (i = 1; i <= n-1; i++) {
sigmx.val = Math.max(sigmx.val, Math.abs(e[(i)- 1+ _e_offset])) ;
Dummy.label("Dlasq1",10);
}              //  Close for() loop. 
}
// *
// *     Early return if sigmx is zero (matrix is already diagonal)
// *
if (sigmx.val == zero)  
    Dummy.go_to("Dlasq1",70);
// *
{
forloop20:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = Math.abs(d[(i)- 1+ _d_offset]);
sigmx.val = Math.max(sigmx.val, d[(i)- 1+ _d_offset]) ;
Dummy.label("Dlasq1",20);
}              //  Close for() loop. 
}
// *
// *     Get machine parameters
// *
eps = Dlamch.dlamch("EPSILON");
sfmin = Dlamch.dlamch("SAFE MINIMUM");
// *
// *     Compute singular values to relative accuracy TOL
// *     It is assumed that tol**2 does not underflow.
// *
tolmul = Math.max(ten, Math.min(hundrd, Math.pow(eps, (-meigth))) ) ;
tol = tolmul*eps;
tol2 = Math.pow(tol, 2);
// *
thresh = sigmx.val*Math.sqrt(sfmin)*tol;
// *
// *     Scale matrix so the square of the largest element is
// *     1 / ( 256 * SFMIN )
// *
scl = Math.sqrt(one/(two56*sfmin));
small2 = one/(two56*Math.pow(tolmul, 2));
Dcopy.dcopy(n,d,_d_offset,1,work,(1)- 1+ _work_offset,1);
Dcopy.dcopy(n-1,e,_e_offset,1,work,(n+1)- 1+ _work_offset,1);
Dlascl.dlascl("G",0,0,sigmx.val,scl,n,1,work,(1)- 1+ _work_offset,n,ierr);
Dlascl.dlascl("G",0,0,sigmx.val,scl,n-1,1,work,(n+1)- 1+ _work_offset,n-1,ierr);
// *
// *     Square D and E (the input for the qd algorithm)
// *
{
forloop30:
for (j = 1; j <= 2*n-1; j++) {
work[(j)- 1+ _work_offset] = Math.pow(work[(j)- 1+ _work_offset], 2);
Dummy.label("Dlasq1",30);
}              //  Close for() loop. 
}
// *
// *     Apply qd algorithm
// *
m = 0;
e[(n)- 1+ _e_offset] = zero;
dx = work[(1)- 1+ _work_offset];
dm.val = dx;
ke = 0;
restrt = false;
{
forloop60:
for (i = 1; i <= n; i++) {
if (Math.abs(e[(i)- 1+ _e_offset]) <= thresh || work[(n+i)- 1+ _work_offset] <= tol2*(dm.val/(double)(i-m)))  {
    ny = i-m;
if (ny == 1)  {
    Dummy.go_to("Dlasq1",50);
}              // Close if()
else if (ny == 2)  {
    Dlas2.dlas2(d[(m+1)- 1+ _d_offset],e[(m+1)- 1+ _e_offset],d[(m+2)- 1+ _d_offset],sig1,sig2);
d[(m+1)- 1+ _d_offset] = sig1.val;
d[(m+2)- 1+ _d_offset] = sig2.val;
}              // Close else if()
else  {
  kend.val = ke+1-m;
Dlasq2.dlasq2(ny,d,(m+1)- 1+ _d_offset,e,(m+1)- 1+ _e_offset,work,(m+1)- 1+ _work_offset,work,(m+n+1)- 1+ _work_offset,eps,tol2,small2,dm,kend,info);
// *
// *                 Return, INFO = number of unconverged superdiagonals
// *
if (info.val != 0)  {
    info.val = info.val+i;
Dummy.go_to("Dlasq1",999999);
}              // Close if()
// *
// *                 Undo scaling
// *
{
forloop40:
for (j = m+1; j <= m+ny; j++) {
d[(j)- 1+ _d_offset] = Math.sqrt(d[(j)- 1+ _d_offset]);
Dummy.label("Dlasq1",40);
}              //  Close for() loop. 
}
Dlascl.dlascl("G",0,0,scl,sigmx.val,ny,1,d,(m+1)- 1+ _d_offset,ny,ierr);
}              //  Close else.
label50:
   Dummy.label("Dlasq1",50);
m = i;
if (i != n)  {
    dx = work[(i+1)- 1+ _work_offset];
dm.val = dx;
ke = i;
restrt = true;
}              // Close if()
}              // Close if()
if (i != n && !restrt)  {
    dx = work[(i+1)- 1+ _work_offset]*(dx/(dx+work[(n+i)- 1+ _work_offset]));
if (dm.val > dx)  {
    dm.val = dx;
ke = i;
}              // Close if()
}              // Close if()
restrt = false;
Dummy.label("Dlasq1",60);
}              //  Close for() loop. 
}
kend.val = ke+1;
// *
// *     Sort the singular values into decreasing order
// *
label70:
   Dummy.label("Dlasq1",70);
Dlasrt.dlasrt("D",n,d,_d_offset,info);
Dummy.go_to("Dlasq1",999999);
// *
// *     End of DLASQ1
// *
Dummy.label("Dlasq1",999999);
return;
   }
} // End class.
