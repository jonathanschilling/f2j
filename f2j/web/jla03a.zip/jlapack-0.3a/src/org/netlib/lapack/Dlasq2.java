/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlasq2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *     Purpose
// *     =======
// *
// *     DLASQ2 computes the singular values of a real N-by-N unreduced
// *     bidiagonal matrix with squared diagonal elements in Q and
// *     squared off-diagonal elements in E. The singular values are
// *     computed to relative accuracy TOL, barring over/underflow or
// *     denormalization.
// *
// *     Arguments
// *     =========
// *
// *  M       (input) INTEGER
// *          The number of rows and columns in the matrix. M >= 0.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (M)
// *          On normal exit, contains the squared singular values.
// *
// *  E       (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  QQ      (input/output) DOUBLE PRECISION array, dimension (M)
// *          On entry, QQ contains the squared diagonal elements of the
// *          bidiagonal matrix whose SVD is desired.
// *          On exit, QQ is overwritten.
// *
// *  EE      (input/output) DOUBLE PRECISION array, dimension (M)
// *          On entry, EE(1:N-1) contains the squared off-diagonal
// *          elements of the bidiagonal matrix whose SVD is desired.
// *          On exit, EE is overwritten.
// *
// *  EPS     (input) DOUBLE PRECISION
// *          Machine epsilon.
// *
// *  TOL2    (input) DOUBLE PRECISION
// *          Desired relative accuracy of computed eigenvalues
// *          as defined in DLASQ1.
// *
// *  SMALL2  (input) DOUBLE PRECISION
// *          A threshold value as defined in DLASQ1.
// *
// *  SUP     (input/output) DOUBLE PRECISION
// *          Upper bound for the smallest eigenvalue.
// *
// *  KEND    (input/output) INTEGER
// *          Index where minimum d occurs.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *          > 0:  if INFO = i, the algorithm did not converge;  i
// *                specifies how many superdiagonals did not converge.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double four= 4.0e+0;
static double half= 0.5e+0;
// *     ..
// *     .. Local Scalars ..
static intW iconv= new intW(0);
static intW iphase= new intW(0);
static int isp= 0;
static intW n= new intW(0);
static intW off= new intW(0);
static int off1= 0;
static double qemax= 0.0;
static doubleW sigma= new doubleW(0.0);
static double xinf= 0.0;
static double xx= 0.0;
static double yy= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..

public static void dlasq2 (int m,
double [] q, int _q_offset,
double [] e, int _e_offset,
double [] qq, int _qq_offset,
double [] ee, int _ee_offset,
double eps,
double tol2,
double small2,
doubleW sup,
intW kend,
intW info)  {

n.val = m;
// *
// *     Set the default maximum number of iterations
// *
off.val = 0;
off1 = off.val+1;
sigma.val = zero;
xinf = zero;
iconv.val = 0;
iphase.val = 2;
// *
// *     Try deflation at the bottom
// *
// *     1x1 deflation
// *
label10:
   Dummy.label("Dlasq2",10);
if (n.val <= 2)  
    Dummy.go_to("Dlasq2",20);
if (ee[(n.val-1)- 1+ _ee_offset] <= Math.max((qq[(n.val)- 1+ _qq_offset]) > (xinf) ? (qq[(n.val)- 1+ _qq_offset]) : (xinf), small2)*tol2)  {
    q[(n.val)- 1+ _q_offset] = qq[(n.val)- 1+ _qq_offset];
n.val = n.val-1;
if (kend.val > n.val)  
    kend.val = n.val;
sup.val = Math.min(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]) ;
Dummy.go_to("Dlasq2",10);
}              // Close if()
// *
// *     2x2 deflation
// *
if (ee[(n.val-2)- 1+ _ee_offset] <= Math.max((xinf) > (small2) ? (xinf) : (small2), (qq[(n.val)- 1+ _qq_offset]/(qq[(n.val)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qq[(n.val-1)- 1+ _qq_offset]))*qq[(n.val-1)- 1+ _qq_offset])*tol2)  {
    qemax = Math.max((qq[(n.val)- 1+ _qq_offset]) > (qq[(n.val-1)- 1+ _qq_offset]) ? (qq[(n.val)- 1+ _qq_offset]) : (qq[(n.val-1)- 1+ _qq_offset]), ee[(n.val-1)- 1+ _ee_offset]);
if (qemax != zero)  {
    if (qemax == qq[(n.val-1)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val)- 1+ _qq_offset]-qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*ee[(n.val-1)- 1+ _ee_offset]/qemax));
}              // Close if()
else if (qemax == qq[(n.val)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val-1)- 1+ _qq_offset]-qq[(n.val)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*ee[(n.val-1)- 1+ _ee_offset]/qemax));
}              // Close else if()
else  {
  xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val)- 1+ _qq_offset]-qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*qq[(n.val-1)- 1+ _qq_offset]/qemax));
}              //  Close else.
yy = (Math.max(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]) /xx)*Math.min(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]) ;
}              // Close if()
else  {
  xx = zero;
yy = zero;
}              //  Close else.
q[(n.val-1)- 1+ _q_offset] = xx;
q[(n.val)- 1+ _q_offset] = yy;
n.val = n.val-2;
if (kend.val > n.val)  
    kend.val = n.val;
sup.val = qq[(n.val)- 1+ _qq_offset];
Dummy.go_to("Dlasq2",10);
}              // Close if()
// *
label20:
   Dummy.label("Dlasq2",20);
if (n.val == 0)  {
    // *
// *         The lower branch is finished
// *
if (off.val == 0)  {
    // *
// *         No upper branch; return to DLASQ1
// *
Dummy.go_to("Dlasq2",999999);
}              // Close if()
else  {
  // *
// *         Going back to upper branch
// *
xinf = zero;
if (ee[(off.val)- 1+ _ee_offset] > zero)  {
    isp = (int)((ee[(off.val)- 1+ _ee_offset]) >= 0 ? (ee[(off.val)- 1+ _ee_offset]) + .5 : (ee[(off.val)- 1+ _ee_offset]) - .5);
iphase.val = 1;
}              // Close if()
else  {
  isp = -(int)((ee[(off.val)- 1+ _ee_offset]) >= 0 ? (ee[(off.val)- 1+ _ee_offset]) + .5 : (ee[(off.val)- 1+ _ee_offset]) - .5);
iphase.val = 2;
}              //  Close else.
sigma.val = e[(off.val)- 1+ _e_offset];
n.val = off.val-isp+1;
off1 = isp;
off.val = off1-1;
if (n.val <= 2)  
    Dummy.go_to("Dlasq2",20);
if (iphase.val == 1)  {
    sup.val = Math.min((q[(n.val+off.val)- 1+ _q_offset]) < (q[(n.val-1+off.val)- 1+ _q_offset]) ? (q[(n.val+off.val)- 1+ _q_offset]) : (q[(n.val-1+off.val)- 1+ _q_offset]), q[(n.val-2+off.val)- 1+ _q_offset]);
}              // Close if()
else  {
  sup.val = Math.min((qq[(n.val+off.val)- 1+ _qq_offset]) < (qq[(n.val-1+off.val)- 1+ _qq_offset]) ? (qq[(n.val+off.val)- 1+ _qq_offset]) : (qq[(n.val-1+off.val)- 1+ _qq_offset]), qq[(n.val-2+off.val)- 1+ _qq_offset]);
}              //  Close else.
kend.val = 0;
iconv.val = -3;
}              //  Close else.
}              // Close if()
else if (n.val == 1)  {
    // *
// *     1x1 Solver
// *
if (iphase.val == 1)  {
    q[(off1)- 1+ _q_offset] = q[(off1)- 1+ _q_offset]+sigma.val;
}              // Close if()
else  {
  q[(off1)- 1+ _q_offset] = qq[(off1)- 1+ _qq_offset]+sigma.val;
}              //  Close else.
n.val = 0;
Dummy.go_to("Dlasq2",20);
// *
// *     2x2 Solver
// *
}              // Close else if()
else if (n.val == 2)  {
    if (iphase.val == 2)  {
    qemax = Math.max((qq[(n.val+off.val)- 1+ _qq_offset]) > (qq[(n.val-1+off.val)- 1+ _qq_offset]) ? (qq[(n.val+off.val)- 1+ _qq_offset]) : (qq[(n.val-1+off.val)- 1+ _qq_offset]), ee[(n.val-1+off.val)- 1+ _ee_offset]);
if (qemax != zero)  {
    if (qemax == qq[(n.val-1+off.val)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val+off.val)- 1+ _qq_offset]+qq[(n.val-1+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val+off.val)- 1+ _qq_offset]-qq[(n.val-1+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset])/qemax), 2)+four*ee[(off.val+n.val-1)- 1+ _ee_offset]/qemax));
}              // Close if()
else if (qemax == qq[(n.val+off.val)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val+off.val)- 1+ _qq_offset]+qq[(n.val-1+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val-1+off.val)- 1+ _qq_offset]-qq[(n.val+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset])/qemax), 2)+four*ee[(n.val-1+off.val)- 1+ _ee_offset]/qemax));
}              // Close else if()
else  {
  xx = half*(qq[(n.val+off.val)- 1+ _qq_offset]+qq[(n.val-1+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val+off.val)- 1+ _qq_offset]-qq[(n.val-1+off.val)- 1+ _qq_offset]+ee[(n.val-1+off.val)- 1+ _ee_offset])/qemax), 2)+four*qq[(n.val-1+off.val)- 1+ _qq_offset]/qemax));
}              //  Close else.
yy = (Math.max(qq[(n.val+off.val)- 1+ _qq_offset], qq[(n.val-1+off.val)- 1+ _qq_offset]) /xx)*Math.min(qq[(n.val+off.val)- 1+ _qq_offset], qq[(n.val-1+off.val)- 1+ _qq_offset]) ;
}              // Close if()
else  {
  xx = zero;
yy = zero;
}              //  Close else.
}              // Close if()
else  {
  qemax = Math.max((q[(n.val+off.val)- 1+ _q_offset]) > (q[(n.val-1+off.val)- 1+ _q_offset]) ? (q[(n.val+off.val)- 1+ _q_offset]) : (q[(n.val-1+off.val)- 1+ _q_offset]), e[(n.val-1+off.val)- 1+ _e_offset]);
if (qemax != zero)  {
    if (qemax == q[(n.val-1+off.val)- 1+ _q_offset])  {
    xx = half*(q[(n.val+off.val)- 1+ _q_offset]+q[(n.val-1+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val+off.val)- 1+ _q_offset]-q[(n.val-1+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset])/qemax), 2)+four*e[(n.val-1+off.val)- 1+ _e_offset]/qemax));
}              // Close if()
else if (qemax == q[(n.val+off.val)- 1+ _q_offset])  {
    xx = half*(q[(n.val+off.val)- 1+ _q_offset]+q[(n.val-1+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val-1+off.val)- 1+ _q_offset]-q[(n.val+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset])/qemax), 2)+four*e[(n.val-1+off.val)- 1+ _e_offset]/qemax));
}              // Close else if()
else  {
  xx = half*(q[(n.val+off.val)- 1+ _q_offset]+q[(n.val-1+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val+off.val)- 1+ _q_offset]-q[(n.val-1+off.val)- 1+ _q_offset]+e[(n.val-1+off.val)- 1+ _e_offset])/qemax), 2)+four*q[(n.val-1+off.val)- 1+ _q_offset]/qemax));
}              //  Close else.
yy = (Math.max(q[(n.val+off.val)- 1+ _q_offset], q[(n.val-1+off.val)- 1+ _q_offset]) /xx)*Math.min(q[(n.val+off.val)- 1+ _q_offset], q[(n.val-1+off.val)- 1+ _q_offset]) ;
}              // Close if()
else  {
  xx = zero;
yy = zero;
}              //  Close else.
}              //  Close else.
q[(n.val-1+off.val)- 1+ _q_offset] = sigma.val+xx;
q[(n.val+off.val)- 1+ _q_offset] = yy+sigma.val;
n.val = 0;
Dummy.go_to("Dlasq2",20);
}              // Close else if()
Dlasq3.dlasq3(n,q,(off1)- 1+ _q_offset,e,(off1)- 1+ _e_offset,qq,(off1)- 1+ _qq_offset,ee,(off1)- 1+ _ee_offset,sup,sigma,kend,off,iphase,iconv,eps,tol2,small2);
if (sup.val < zero)  {
    info.val = n.val+off.val;
Dummy.go_to("Dlasq2",999999);
}              // Close if()
off1 = off.val+1;
Dummy.go_to("Dlasq2",20);
// *
// *     End of DLASQ2
// *
Dummy.label("Dlasq2",999999);
return;
   }
} // End class.
