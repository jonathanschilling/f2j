/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlasq3 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *     Purpose
// *     =======
// *
// *     DLASQ3 is the workhorse of the whole bidiagonal SVD algorithm.
// *     This can be described as the differential qd with shifts.
// *
// *     Arguments
// *     =========
// *
// *  N       (input/output) INTEGER
// *          On entry, N specifies the number of rows and columns
// *          in the matrix. N must be at least 3.
// *          On exit N is non-negative and less than the input value.
// *
// *  Q       (input/output) DOUBLE PRECISION array, dimension (N)
// *          Q array in ping (see IPHASE below)
// *
// *  E       (input/output) DOUBLE PRECISION array, dimension (N)
// *          E array in ping (see IPHASE below)
// *
// *  QQ      (input/output) DOUBLE PRECISION array, dimension (N)
// *          Q array in pong (see IPHASE below)
// *
// *  EE      (input/output) DOUBLE PRECISION array, dimension (N)
// *          E array in pong (see IPHASE below)
// *
// *  SUP     (input/output) DOUBLE PRECISION
// *          Upper bound for the smallest eigenvalue
// *
// *  SIGMA   (input/output) DOUBLE PRECISION
// *          Accumulated shift for the present submatrix
// *
// *  KEND    (input/output) INTEGER
// *          Index where minimum D(i) occurs in recurrence for
// *          splitting criterion
// *
// *  OFF     (input/output) INTEGER
// *          Offset for arrays
// *
// *  IPHASE  (input/output) INTEGER
// *          If IPHASE = 1 (ping) then data is in Q and E arrays
// *          If IPHASE = 2 (pong) then data is in QQ and EE arrays
// *
// *  ICONV   (input) INTEGER
// *          If ICONV = 0 a bottom part of a matrix (with a split)
// *          If ICONV =-3 a top part of a matrix (with a split)
// *
// *  EPS     (input) DOUBLE PRECISION
// *          Machine epsilon
// *
// *  TOL2    (input) DOUBLE PRECISION
// *          Square of the relative tolerance TOL as defined in DLASQ1
// *
// *  SMALL2  (input) DOUBLE PRECISION
// *          A threshold value as defined in DLASQ1
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int npp= 32;
static int ipp= 5;
static double half= 0.5e+0;
static double four= 4.0e+0;
static int iflmax= 2;
// *     ..
// *     .. Local Scalars ..
static boolean ldef= false;
static boolean lsplit= false;
static int i= 0;
static int ic= 0;
static int icnt= 0;
static int ifl= 0;
static int ip= 0;
static int isp= 0;
static int k1end= 0;
static int k2end= 0;
static int ke= 0;
static int ks= 0;
static int maxit= 0;
static int n1= 0;
static int n2= 0;
static double d= 0.0;
static double dm= 0.0;
static double qemax= 0.0;
static double t1= 0.0;
static doubleW tau= new doubleW(0.0);
static double tolx= 0.0;
static double toly= 0.0;
static double tolz= 0.0;
static double xx= 0.0;
static double yy= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..

public static void dlasq3 (intW n,
double [] q, int _q_offset,
double [] e, int _e_offset,
double [] qq, int _qq_offset,
double [] ee, int _ee_offset,
doubleW sup,
doubleW sigma,
intW kend,
intW off,
intW iphase,
intW iconv,
double eps,
double tol2,
double small2)  {

icnt = 0;
tau.val = zero;
dm = sup.val;
tolx = sigma.val*tol2;
tolz = Math.max(small2, sigma.val) *tol2;
// *
// *     Set maximum number of iterations
// *
maxit = 100*n.val;
// *
// *     Flipping
// *
ic = 2;
if (n.val > 3)  {
    if (iphase.val == 1)  {
    {
forloop10:
for (i = 1; i <= n.val-2; i++) {
if (q[(i)- 1+ _q_offset] > q[(i+1)- 1+ _q_offset])  
    ic = ic+1;
if (e[(i)- 1+ _e_offset] > e[(i+1)- 1+ _e_offset])  
    ic = ic+1;
Dummy.label("Dlasq3",10);
}              //  Close for() loop. 
}
if (q[(n.val-1)- 1+ _q_offset] > q[(n.val)- 1+ _q_offset])  
    ic = ic+1;
if (ic < n.val)  {
    Dcopy.dcopy(n.val,q,_q_offset,1,qq,_qq_offset,-1);
Dcopy.dcopy(n.val-1,e,_e_offset,1,ee,_ee_offset,-1);
if (kend.val != 0)  
    kend.val = n.val-kend.val+1;
iphase.val = 2;
}              // Close if()
}              // Close if()
else  {
  {
forloop20:
for (i = 1; i <= n.val-2; i++) {
if (qq[(i)- 1+ _qq_offset] > qq[(i+1)- 1+ _qq_offset])  
    ic = ic+1;
if (ee[(i)- 1+ _ee_offset] > ee[(i+1)- 1+ _ee_offset])  
    ic = ic+1;
Dummy.label("Dlasq3",20);
}              //  Close for() loop. 
}
if (qq[(n.val-1)- 1+ _qq_offset] > qq[(n.val)- 1+ _qq_offset])  
    ic = ic+1;
if (ic < n.val)  {
    Dcopy.dcopy(n.val,qq,_qq_offset,1,q,_q_offset,-1);
Dcopy.dcopy(n.val-1,ee,_ee_offset,1,e,_e_offset,-1);
if (kend.val != 0)  
    kend.val = n.val-kend.val+1;
iphase.val = 1;
}              // Close if()
}              //  Close else.
}              // Close if()
if (iconv.val == -3)  {
    if (iphase.val == 1)  {
    Dummy.go_to("Dlasq3",180);
}              // Close if()
else  {
  Dummy.go_to("Dlasq3",80);
}              //  Close else.
}              // Close if()
if (iphase.val == 2)  
    Dummy.go_to("Dlasq3",130);
// *
// *     The ping section of the code
// *
label30:
   Dummy.label("Dlasq3",30);
ifl = 0;
// *
// *     Compute the shift
// *
if (kend.val == 0 || sup.val == zero)  {
    tau.val = zero;
}              // Close if()
else if (icnt > 0 && dm <= tolz)  {
    tau.val = zero;
}              // Close else if()
else  {
  ip = (int)(Math.max(ipp, n.val/npp) );
n2 = 2*ip+1;
if (n2 >= n.val)  {
    n1 = 1;
n2 = n.val;
}              // Close if()
else if (kend.val+ip > n.val)  {
    n1 = n.val-2*ip;
}              // Close else if()
else if (kend.val-ip < 1)  {
    n1 = 1;
}              // Close else if()
else  {
  n1 = kend.val-ip;
}              //  Close else.
Dlasq4.dlasq4(n2,q,(n1)- 1+ _q_offset,e,(n1)- 1+ _e_offset,tau,sup);
}              //  Close else.
label40:
   Dummy.label("Dlasq3",40);
icnt = icnt+1;
if (icnt > maxit)  {
    sup.val = -one;
Dummy.go_to("Dlasq3",999999);
}              // Close if()
if (tau.val == zero)  {
    // *
// *     dqd algorithm
// *
d = q[(1)- 1+ _q_offset];
dm = d;
ke = 0;
{
forloop50:
for (i = 1; i <= n.val-3; i++) {
qq[(i)- 1+ _qq_offset] = d+e[(i)- 1+ _e_offset];
d = (d/qq[(i)- 1+ _qq_offset])*q[(i+1)- 1+ _q_offset];
if (dm > d)  {
    dm = d;
ke = i;
}              // Close if()
Dummy.label("Dlasq3",50);
}              //  Close for() loop. 
}
ke = ke+1;
// *
// *     Penultimate dqd step (in ping)
// *
k2end = ke;
qq[(n.val-2)- 1+ _qq_offset] = d+e[(n.val-2)- 1+ _e_offset];
d = (d/qq[(n.val-2)- 1+ _qq_offset])*q[(n.val-1)- 1+ _q_offset];
if (dm > d)  {
    dm = d;
ke = n.val-1;
}              // Close if()
// *
// *     Final dqd step (in ping)
// *
k1end = ke;
qq[(n.val-1)- 1+ _qq_offset] = d+e[(n.val-1)- 1+ _e_offset];
d = (d/qq[(n.val-1)- 1+ _qq_offset])*q[(n.val)- 1+ _q_offset];
if (dm > d)  {
    dm = d;
ke = n.val;
}              // Close if()
qq[(n.val)- 1+ _qq_offset] = d;
}              // Close if()
else  {
  // *
// *     The dqds algorithm (in ping)
// *
d = q[(1)- 1+ _q_offset]-tau.val;
dm = d;
ke = 0;
if (d < zero)  
    Dummy.go_to("Dlasq3",120);
{
forloop60:
for (i = 1; i <= n.val-3; i++) {
qq[(i)- 1+ _qq_offset] = d+e[(i)- 1+ _e_offset];
d = (d/qq[(i)- 1+ _qq_offset])*q[(i+1)- 1+ _q_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = i;
if (d < zero)  
    Dummy.go_to("Dlasq3",120);
}              // Close if()
Dummy.label("Dlasq3",60);
}              //  Close for() loop. 
}
ke = ke+1;
// *
// *     Penultimate dqds step (in ping)
// *
k2end = ke;
qq[(n.val-2)- 1+ _qq_offset] = d+e[(n.val-2)- 1+ _e_offset];
d = (d/qq[(n.val-2)- 1+ _qq_offset])*q[(n.val-1)- 1+ _q_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = n.val-1;
if (d < zero)  
    Dummy.go_to("Dlasq3",120);
}              // Close if()
// *
// *     Final dqds step (in ping)
// *
k1end = ke;
qq[(n.val-1)- 1+ _qq_offset] = d+e[(n.val-1)- 1+ _e_offset];
d = (d/qq[(n.val-1)- 1+ _qq_offset])*q[(n.val)- 1+ _q_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = n.val;
}              // Close if()
qq[(n.val)- 1+ _qq_offset] = d;
}              //  Close else.
// *
// *        Convergence when QQ(N) is small (in ping)
// *
if (Math.abs(qq[(n.val)- 1+ _qq_offset]) <= sigma.val*tol2)  {
    qq[(n.val)- 1+ _qq_offset] = zero;
dm = zero;
ke = n.val;
}              // Close if()
if (qq[(n.val)- 1+ _qq_offset] < zero)  
    Dummy.go_to("Dlasq3",120);
// *
// *     Non-negative qd array: Update the e's
// *
{
forloop70:
for (i = 1; i <= n.val-1; i++) {
ee[(i)- 1+ _ee_offset] = (e[(i)- 1+ _e_offset]/qq[(i)- 1+ _qq_offset])*q[(i+1)- 1+ _q_offset];
Dummy.label("Dlasq3",70);
}              //  Close for() loop. 
}
// *
// *     Updating sigma and iphase in ping
// *
sigma.val = sigma.val+tau.val;
iphase.val = 2;
label80:
   Dummy.label("Dlasq3",80);
tolx = sigma.val*tol2;
toly = sigma.val*eps;
tolz = Math.max(sigma.val, small2) *tol2;
// *
// *     Checking for deflation and convergence (in ping)
// *
label90:
   Dummy.label("Dlasq3",90);
if (n.val <= 2)  
    Dummy.go_to("Dlasq3",999999);
// *
// *        Deflation: bottom 1x1 (in ping)
// *
ldef = false;
if (ee[(n.val-1)- 1+ _ee_offset] <= tolz)  {
    ldef = true;
}              // Close if()
else if (sigma.val > zero)  {
    if (ee[(n.val-1)- 1+ _ee_offset] <= eps*(sigma.val+qq[(n.val)- 1+ _qq_offset]))  {
    if (ee[(n.val-1)- 1+ _ee_offset]*(qq[(n.val)- 1+ _qq_offset]/(qq[(n.val)- 1+ _qq_offset]+sigma.val)) <= tol2*(qq[(n.val)- 1+ _qq_offset]+sigma.val))  {
    ldef = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (ee[(n.val-1)- 1+ _ee_offset] <= qq[(n.val)- 1+ _qq_offset]*tol2)  {
    ldef = true;
}              // Close if()
}              //  Close else.
if (ldef)  {
    q[(n.val)- 1+ _q_offset] = qq[(n.val)- 1+ _qq_offset]+sigma.val;
n.val = n.val-1;
iconv.val = iconv.val+1;
Dummy.go_to("Dlasq3",90);
}              // Close if()
// *
// *        Deflation: bottom 2x2 (in ping)
// *
ldef = false;
if (ee[(n.val-2)- 1+ _ee_offset] <= tolz)  {
    ldef = true;
}              // Close if()
else if (sigma.val > zero)  {
    t1 = sigma.val+ee[(n.val-1)- 1+ _ee_offset]*(sigma.val/(sigma.val+qq[(n.val)- 1+ _qq_offset]));
if (ee[(n.val-2)- 1+ _ee_offset]*(t1/(qq[(n.val-1)- 1+ _qq_offset]+t1)) <= toly)  {
    if (ee[(n.val-2)- 1+ _ee_offset]*(qq[(n.val-1)- 1+ _qq_offset]/(qq[(n.val-1)- 1+ _qq_offset]+t1)) <= tolx)  {
    ldef = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (ee[(n.val-2)- 1+ _ee_offset] <= (qq[(n.val)- 1+ _qq_offset]/(qq[(n.val)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qq[(n.val-1)- 1+ _qq_offset]))*qq[(n.val-1)- 1+ _qq_offset]*tol2)  {
    ldef = true;
}              // Close if()
}              //  Close else.
if (ldef)  {
    qemax = Math.max((qq[(n.val)- 1+ _qq_offset]) > (qq[(n.val-1)- 1+ _qq_offset]) ? (qq[(n.val)- 1+ _qq_offset]) : (qq[(n.val-1)- 1+ _qq_offset]), ee[(n.val-1)- 1+ _ee_offset]);
if (qemax != zero)  {
    if (qemax == qq[(n.val-1)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val)- 1+ _qq_offset]-qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*ee[(n.val-1)- 1+ _ee_offset]/qemax));
}              // Close if()
else if (qemax == qq[(n.val)- 1+ _qq_offset])  {
    xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val-1)- 1+ _qq_offset]-qq[(n.val)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*ee[(n.val-1)- 1+ _ee_offset]/qemax));
}              // Close else if()
else  {
  xx = half*(qq[(n.val)- 1+ _qq_offset]+qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset]+qemax*Math.sqrt(Math.pow(((qq[(n.val)- 1+ _qq_offset]-qq[(n.val-1)- 1+ _qq_offset]+ee[(n.val-1)- 1+ _ee_offset])/qemax), 2)+four*qq[(n.val-1)- 1+ _qq_offset]/qemax));
}              //  Close else.
yy = (Math.max(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]) /xx)*Math.min(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]) ;
}              // Close if()
else  {
  xx = zero;
yy = zero;
}              //  Close else.
q[(n.val-1)- 1+ _q_offset] = sigma.val+xx;
q[(n.val)- 1+ _q_offset] = yy+sigma.val;
n.val = n.val-2;
iconv.val = iconv.val+2;
Dummy.go_to("Dlasq3",90);
}              // Close if()
// *
// *     Updating bounds before going to pong
// *
if (iconv.val == 0)  {
    kend.val = ke;
sup.val = Math.min(dm, sup.val-tau.val) ;
}              // Close if()
else if (iconv.val > 0)  {
    sup.val = Math.min(Math.min(Math.min(Math.min(Math.min(qq[(n.val)- 1+ _qq_offset], qq[(n.val-1)- 1+ _qq_offset]), qq[(n.val-2)- 1+ _qq_offset]), qq[(1)- 1+ _qq_offset]), qq[(2)- 1+ _qq_offset]), qq[(3)- 1+ _qq_offset]) ;
if (iconv.val == 1)  {
    kend.val = k1end;
}              // Close if()
else if (iconv.val == 2)  {
    kend.val = k2end;
}              // Close else if()
else  {
  kend.val = n.val;
}              //  Close else.
icnt = 0;
maxit = 100*n.val;
}              // Close else if()
// *
// *     Checking for splitting in ping
// *
lsplit = false;
{
int _ks_inc = -1;
forloop100:
for (ks = n.val-3; ks >= 3; ks += _ks_inc) {
if (ee[(ks)- 1+ _ee_offset] <= toly)  {
    if (ee[(ks)- 1+ _ee_offset]*(Math.min(qq[(ks+1)- 1+ _qq_offset], qq[(ks)- 1+ _qq_offset]) /(Math.min(qq[(ks+1)- 1+ _qq_offset], qq[(ks)- 1+ _qq_offset]) +sigma.val)) <= tolx)  {
    lsplit = true;
Dummy.go_to("Dlasq3",110);
}              // Close if()
}              // Close if()
Dummy.label("Dlasq3",100);
}              //  Close for() loop. 
}
// *
ks = 2;
if (ee[(2)- 1+ _ee_offset] <= tolz)  {
    lsplit = true;
}              // Close if()
else if (sigma.val > zero)  {
    t1 = sigma.val+ee[(1)- 1+ _ee_offset]*(sigma.val/(sigma.val+qq[(1)- 1+ _qq_offset]));
if (ee[(2)- 1+ _ee_offset]*(t1/(qq[(1)- 1+ _qq_offset]+t1)) <= toly)  {
    if (ee[(2)- 1+ _ee_offset]*(qq[(1)- 1+ _qq_offset]/(qq[(1)- 1+ _qq_offset]+t1)) <= tolx)  {
    lsplit = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (ee[(2)- 1+ _ee_offset] <= (qq[(1)- 1+ _qq_offset]/(qq[(1)- 1+ _qq_offset]+ee[(1)- 1+ _ee_offset]+qq[(2)- 1+ _qq_offset]))*qq[(2)- 1+ _qq_offset]*tol2)  {
    lsplit = true;
}              // Close if()
}              //  Close else.
if (lsplit)  
    Dummy.go_to("Dlasq3",110);
// *
ks = 1;
if (ee[(1)- 1+ _ee_offset] <= tolz)  {
    lsplit = true;
}              // Close if()
else if (sigma.val > zero)  {
    if (ee[(1)- 1+ _ee_offset] <= eps*(sigma.val+qq[(1)- 1+ _qq_offset]))  {
    if (ee[(1)- 1+ _ee_offset]*(qq[(1)- 1+ _qq_offset]/(qq[(1)- 1+ _qq_offset]+sigma.val)) <= tol2*(qq[(1)- 1+ _qq_offset]+sigma.val))  {
    lsplit = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (ee[(1)- 1+ _ee_offset] <= qq[(1)- 1+ _qq_offset]*tol2)  {
    lsplit = true;
}              // Close if()
}              //  Close else.
// *
label110:
   Dummy.label("Dlasq3",110);
if (lsplit)  {
    sup.val = Math.min((qq[(n.val)- 1+ _qq_offset]) < (qq[(n.val-1)- 1+ _qq_offset]) ? (qq[(n.val)- 1+ _qq_offset]) : (qq[(n.val-1)- 1+ _qq_offset]), qq[(n.val-2)- 1+ _qq_offset]);
isp = -(off.val+1);
off.val = off.val+ks;
n.val = n.val-ks;
kend.val = (int)(Math.max(1, kend.val-ks) );
e[(ks)- 1+ _e_offset] = sigma.val;
ee[(ks)- 1+ _ee_offset] = (double)(isp);
iconv.val = 0;
Dummy.go_to("Dlasq3",999999);
}              // Close if()
// *
// *     Coincidence
// *
if (tau.val == zero && dm <= tolz && kend.val != n.val && iconv.val == 0 && icnt > 0)  {
    Dcopy.dcopy(n.val-ke,e,(ke)- 1+ _e_offset,1,qq,(ke)- 1+ _qq_offset,1);
qq[(n.val)- 1+ _qq_offset] = zero;
Dcopy.dcopy(n.val-ke,q,(ke+1)- 1+ _q_offset,1,ee,(ke)- 1+ _ee_offset,1);
sup.val = zero;
}              // Close if()
iconv.val = 0;
Dummy.go_to("Dlasq3",130);
// *
// *     A new shift when the previous failed (in ping)
// *
label120:
   Dummy.label("Dlasq3",120);
ifl = ifl+1;
sup.val = tau.val;
// *
// *     SUP is small or
// *     Too many bad shifts (ping)
// *
if (sup.val <= tolz || ifl >= iflmax)  {
    tau.val = zero;
Dummy.go_to("Dlasq3",40);
// *
// *     The asymptotic shift (in ping)
// *
}              // Close if()
else  {
  tau.val = Math.max(tau.val+d, zero) ;
if (tau.val <= tolz)  
    tau.val = zero;
Dummy.go_to("Dlasq3",40);
}              //  Close else.
// *
// *     the pong section of the code
// *
label130:
   Dummy.label("Dlasq3",130);
ifl = 0;
// *
// *     Compute the shift (in pong)
// *
if (kend.val == 0 && sup.val == zero)  {
    tau.val = zero;
}              // Close if()
else if (icnt > 0 && dm <= tolz)  {
    tau.val = zero;
}              // Close else if()
else  {
  ip = (int)(Math.max(ipp, n.val/npp) );
n2 = 2*ip+1;
if (n2 >= n.val)  {
    n1 = 1;
n2 = n.val;
}              // Close if()
else if (kend.val+ip > n.val)  {
    n1 = n.val-2*ip;
}              // Close else if()
else if (kend.val-ip < 1)  {
    n1 = 1;
}              // Close else if()
else  {
  n1 = kend.val-ip;
}              //  Close else.
Dlasq4.dlasq4(n2,qq,(n1)- 1+ _qq_offset,ee,(n1)- 1+ _ee_offset,tau,sup);
}              //  Close else.
label140:
   Dummy.label("Dlasq3",140);
icnt = icnt+1;
if (icnt > maxit)  {
    sup.val = -sup.val;
Dummy.go_to("Dlasq3",999999);
}              // Close if()
if (tau.val == zero)  {
    // *
// *     The dqd algorithm (in pong)
// *
d = qq[(1)- 1+ _qq_offset];
dm = d;
ke = 0;
{
forloop150:
for (i = 1; i <= n.val-3; i++) {
q[(i)- 1+ _q_offset] = d+ee[(i)- 1+ _ee_offset];
d = (d/q[(i)- 1+ _q_offset])*qq[(i+1)- 1+ _qq_offset];
if (dm > d)  {
    dm = d;
ke = i;
}              // Close if()
Dummy.label("Dlasq3",150);
}              //  Close for() loop. 
}
ke = ke+1;
// *
// *     Penultimate dqd step (in pong)
// *
k2end = ke;
q[(n.val-2)- 1+ _q_offset] = d+ee[(n.val-2)- 1+ _ee_offset];
d = (d/q[(n.val-2)- 1+ _q_offset])*qq[(n.val-1)- 1+ _qq_offset];
if (dm > d)  {
    dm = d;
ke = n.val-1;
}              // Close if()
// *
// *     Final dqd step (in pong)
// *
k1end = ke;
q[(n.val-1)- 1+ _q_offset] = d+ee[(n.val-1)- 1+ _ee_offset];
d = (d/q[(n.val-1)- 1+ _q_offset])*qq[(n.val)- 1+ _qq_offset];
if (dm > d)  {
    dm = d;
ke = n.val;
}              // Close if()
q[(n.val)- 1+ _q_offset] = d;
}              // Close if()
else  {
  // *
// *     The dqds algorithm (in pong)
// *
d = qq[(1)- 1+ _qq_offset]-tau.val;
dm = d;
ke = 0;
if (d < zero)  
    Dummy.go_to("Dlasq3",220);
{
forloop160:
for (i = 1; i <= n.val-3; i++) {
q[(i)- 1+ _q_offset] = d+ee[(i)- 1+ _ee_offset];
d = (d/q[(i)- 1+ _q_offset])*qq[(i+1)- 1+ _qq_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = i;
if (d < zero)  
    Dummy.go_to("Dlasq3",220);
}              // Close if()
Dummy.label("Dlasq3",160);
}              //  Close for() loop. 
}
ke = ke+1;
// *
// *     Penultimate dqds step (in pong)
// *
k2end = ke;
q[(n.val-2)- 1+ _q_offset] = d+ee[(n.val-2)- 1+ _ee_offset];
d = (d/q[(n.val-2)- 1+ _q_offset])*qq[(n.val-1)- 1+ _qq_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = n.val-1;
if (d < zero)  
    Dummy.go_to("Dlasq3",220);
}              // Close if()
// *
// *     Final dqds step (in pong)
// *
k1end = ke;
q[(n.val-1)- 1+ _q_offset] = d+ee[(n.val-1)- 1+ _ee_offset];
d = (d/q[(n.val-1)- 1+ _q_offset])*qq[(n.val)- 1+ _qq_offset]-tau.val;
if (dm > d)  {
    dm = d;
ke = n.val;
}              // Close if()
q[(n.val)- 1+ _q_offset] = d;
}              //  Close else.
// *
// *        Convergence when is small (in pong)
// *
if (Math.abs(q[(n.val)- 1+ _q_offset]) <= sigma.val*tol2)  {
    q[(n.val)- 1+ _q_offset] = zero;
dm = zero;
ke = n.val;
}              // Close if()
if (q[(n.val)- 1+ _q_offset] < zero)  
    Dummy.go_to("Dlasq3",220);
// *
// *     Non-negative qd array: Update the e's
// *
{
forloop170:
for (i = 1; i <= n.val-1; i++) {
e[(i)- 1+ _e_offset] = (ee[(i)- 1+ _ee_offset]/q[(i)- 1+ _q_offset])*qq[(i+1)- 1+ _qq_offset];
Dummy.label("Dlasq3",170);
}              //  Close for() loop. 
}
// *
// *     Updating sigma and iphase in pong
// *
sigma.val = sigma.val+tau.val;
label180:
   Dummy.label("Dlasq3",180);
iphase.val = 1;
tolx = sigma.val*tol2;
toly = sigma.val*eps;
// *
// *     Checking for deflation and convergence (in pong)
// *
label190:
   Dummy.label("Dlasq3",190);
if (n.val <= 2)  
    Dummy.go_to("Dlasq3",999999);
// *
// *        Deflation: bottom 1x1 (in pong)
// *
ldef = false;
if (e[(n.val-1)- 1+ _e_offset] <= tolz)  {
    ldef = true;
}              // Close if()
else if (sigma.val > zero)  {
    if (e[(n.val-1)- 1+ _e_offset] <= eps*(sigma.val+q[(n.val)- 1+ _q_offset]))  {
    if (e[(n.val-1)- 1+ _e_offset]*(q[(n.val)- 1+ _q_offset]/(q[(n.val)- 1+ _q_offset]+sigma.val)) <= tol2*(q[(n.val)- 1+ _q_offset]+sigma.val))  {
    ldef = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (e[(n.val-1)- 1+ _e_offset] <= q[(n.val)- 1+ _q_offset]*tol2)  {
    ldef = true;
}              // Close if()
}              //  Close else.
if (ldef)  {
    q[(n.val)- 1+ _q_offset] = q[(n.val)- 1+ _q_offset]+sigma.val;
n.val = n.val-1;
iconv.val = iconv.val+1;
Dummy.go_to("Dlasq3",190);
}              // Close if()
// *
// *        Deflation: bottom 2x2 (in pong)
// *
ldef = false;
if (e[(n.val-2)- 1+ _e_offset] <= tolz)  {
    ldef = true;
}              // Close if()
else if (sigma.val > zero)  {
    t1 = sigma.val+e[(n.val-1)- 1+ _e_offset]*(sigma.val/(sigma.val+q[(n.val)- 1+ _q_offset]));
if (e[(n.val-2)- 1+ _e_offset]*(t1/(q[(n.val-1)- 1+ _q_offset]+t1)) <= toly)  {
    if (e[(n.val-2)- 1+ _e_offset]*(q[(n.val-1)- 1+ _q_offset]/(q[(n.val-1)- 1+ _q_offset]+t1)) <= tolx)  {
    ldef = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (e[(n.val-2)- 1+ _e_offset] <= (q[(n.val)- 1+ _q_offset]/(q[(n.val)- 1+ _q_offset]+ee[(n.val-1)- 1+ _ee_offset]+q[(n.val-1)- 1+ _q_offset])*q[(n.val-1)- 1+ _q_offset])*tol2)  {
    ldef = true;
}              // Close if()
}              //  Close else.
if (ldef)  {
    qemax = Math.max((q[(n.val)- 1+ _q_offset]) > (q[(n.val-1)- 1+ _q_offset]) ? (q[(n.val)- 1+ _q_offset]) : (q[(n.val-1)- 1+ _q_offset]), e[(n.val-1)- 1+ _e_offset]);
if (qemax != zero)  {
    if (qemax == q[(n.val-1)- 1+ _q_offset])  {
    xx = half*(q[(n.val)- 1+ _q_offset]+q[(n.val-1)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val)- 1+ _q_offset]-q[(n.val-1)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset])/qemax), 2)+four*e[(n.val-1)- 1+ _e_offset]/qemax));
}              // Close if()
else if (qemax == q[(n.val)- 1+ _q_offset])  {
    xx = half*(q[(n.val)- 1+ _q_offset]+q[(n.val-1)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val-1)- 1+ _q_offset]-q[(n.val)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset])/qemax), 2)+four*e[(n.val-1)- 1+ _e_offset]/qemax));
}              // Close else if()
else  {
  xx = half*(q[(n.val)- 1+ _q_offset]+q[(n.val-1)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset]+qemax*Math.sqrt(Math.pow(((q[(n.val)- 1+ _q_offset]-q[(n.val-1)- 1+ _q_offset]+e[(n.val-1)- 1+ _e_offset])/qemax), 2)+four*q[(n.val-1)- 1+ _q_offset]/qemax));
}              //  Close else.
yy = (Math.max(q[(n.val)- 1+ _q_offset], q[(n.val-1)- 1+ _q_offset]) /xx)*Math.min(q[(n.val)- 1+ _q_offset], q[(n.val-1)- 1+ _q_offset]) ;
}              // Close if()
else  {
  xx = zero;
yy = zero;
}              //  Close else.
q[(n.val-1)- 1+ _q_offset] = sigma.val+xx;
q[(n.val)- 1+ _q_offset] = yy+sigma.val;
n.val = n.val-2;
iconv.val = iconv.val+2;
Dummy.go_to("Dlasq3",190);
}              // Close if()
// *
// *     Updating bounds before going to pong
// *
if (iconv.val == 0)  {
    kend.val = ke;
sup.val = Math.min(dm, sup.val-tau.val) ;
}              // Close if()
else if (iconv.val > 0)  {
    sup.val = Math.min(Math.min(Math.min(Math.min(Math.min(q[(n.val)- 1+ _q_offset], q[(n.val-1)- 1+ _q_offset]), q[(n.val-2)- 1+ _q_offset]), q[(1)- 1+ _q_offset]), q[(2)- 1+ _q_offset]), q[(3)- 1+ _q_offset]) ;
if (iconv.val == 1)  {
    kend.val = k1end;
}              // Close if()
else if (iconv.val == 2)  {
    kend.val = k2end;
}              // Close else if()
else  {
  kend.val = n.val;
}              //  Close else.
icnt = 0;
maxit = 100*n.val;
}              // Close else if()
// *
// *     Checking for splitting in pong
// *
lsplit = false;
{
int _ks_inc = -1;
forloop200:
for (ks = n.val-3; ks >= 3; ks += _ks_inc) {
if (e[(ks)- 1+ _e_offset] <= toly)  {
    if (e[(ks)- 1+ _e_offset]*(Math.min(q[(ks+1)- 1+ _q_offset], q[(ks)- 1+ _q_offset]) /(Math.min(q[(ks+1)- 1+ _q_offset], q[(ks)- 1+ _q_offset]) +sigma.val)) <= tolx)  {
    lsplit = true;
Dummy.go_to("Dlasq3",210);
}              // Close if()
}              // Close if()
Dummy.label("Dlasq3",200);
}              //  Close for() loop. 
}
// *
ks = 2;
if (e[(2)- 1+ _e_offset] <= tolz)  {
    lsplit = true;
}              // Close if()
else if (sigma.val > zero)  {
    t1 = sigma.val+e[(1)- 1+ _e_offset]*(sigma.val/(sigma.val+q[(1)- 1+ _q_offset]));
if (e[(2)- 1+ _e_offset]*(t1/(q[(1)- 1+ _q_offset]+t1)) <= toly)  {
    if (e[(2)- 1+ _e_offset]*(q[(1)- 1+ _q_offset]/(q[(1)- 1+ _q_offset]+t1)) <= tolx)  {
    lsplit = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (e[(2)- 1+ _e_offset] <= (q[(1)- 1+ _q_offset]/(q[(1)- 1+ _q_offset]+e[(1)- 1+ _e_offset]+q[(2)- 1+ _q_offset]))*q[(2)- 1+ _q_offset]*tol2)  {
    lsplit = true;
}              // Close if()
}              //  Close else.
if (lsplit)  
    Dummy.go_to("Dlasq3",210);
// *
ks = 1;
if (e[(1)- 1+ _e_offset] <= tolz)  {
    lsplit = true;
}              // Close if()
else if (sigma.val > zero)  {
    if (e[(1)- 1+ _e_offset] <= eps*(sigma.val+q[(1)- 1+ _q_offset]))  {
    if (e[(1)- 1+ _e_offset]*(q[(1)- 1+ _q_offset]/(q[(1)- 1+ _q_offset]+sigma.val)) <= tol2*(q[(1)- 1+ _q_offset]+sigma.val))  {
    lsplit = true;
}              // Close if()
}              // Close if()
}              // Close else if()
else  {
  if (e[(1)- 1+ _e_offset] <= q[(1)- 1+ _q_offset]*tol2)  {
    lsplit = true;
}              // Close if()
}              //  Close else.
// *
label210:
   Dummy.label("Dlasq3",210);
if (lsplit)  {
    sup.val = Math.min((q[(n.val)- 1+ _q_offset]) < (q[(n.val-1)- 1+ _q_offset]) ? (q[(n.val)- 1+ _q_offset]) : (q[(n.val-1)- 1+ _q_offset]), q[(n.val-2)- 1+ _q_offset]);
isp = off.val+1;
off.val = off.val+ks;
kend.val = (int)(Math.max(1, kend.val-ks) );
n.val = n.val-ks;
e[(ks)- 1+ _e_offset] = sigma.val;
ee[(ks)- 1+ _ee_offset] = (double)(isp);
iconv.val = 0;
Dummy.go_to("Dlasq3",999999);
}              // Close if()
// *
// *     Coincidence
// *
if (tau.val == zero && dm <= tolz && kend.val != n.val && iconv.val == 0 && icnt > 0)  {
    Dcopy.dcopy(n.val-ke,ee,(ke)- 1+ _ee_offset,1,q,(ke)- 1+ _q_offset,1);
q[(n.val)- 1+ _q_offset] = zero;
Dcopy.dcopy(n.val-ke,qq,(ke+1)- 1+ _qq_offset,1,e,(ke)- 1+ _e_offset,1);
sup.val = zero;
}              // Close if()
iconv.val = 0;
Dummy.go_to("Dlasq3",30);
// *
// *     Computation of a new shift when the previous failed (in pong)
// *
label220:
   Dummy.label("Dlasq3",220);
ifl = ifl+1;
sup.val = tau.val;
// *
// *     SUP is small or
// *     Too many bad shifts (in pong)
// *
if (sup.val <= tolz || ifl >= iflmax)  {
    tau.val = zero;
Dummy.go_to("Dlasq3",140);
// *
// *     The asymptotic shift (in pong)
// *
}              // Close if()
else  {
  tau.val = Math.max(tau.val+d, zero) ;
if (tau.val <= tolz)  
    tau.val = zero;
Dummy.go_to("Dlasq3",140);
}              //  Close else.
// *
// *     End of DLASQ3
// *
Dummy.label("Dlasq3",999999);
return;
   }
} // End class.
