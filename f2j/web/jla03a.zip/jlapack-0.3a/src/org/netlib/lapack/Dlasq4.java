/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlasq4 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *     Purpose
// *     =======
// *
// *     DLASQ4 estimates TAU, the smallest eigenvalue of a matrix. This
// *     routine improves the input value of SUP which is an upper bound
// *     for the smallest eigenvalue for this matrix .
// *
// *     Arguments
// *     =========
// *
// *  N       (input) INTEGER
// *          On entry, N specifies the number of rows and columns
// *          in the matrix. N must be at least 0.
// *
// *  Q       (input) DOUBLE PRECISION array, dimension (N)
// *          Q array
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N)
// *          E array
// *
// *  TAU     (output) DOUBLE PRECISION
// *          Estimate of the shift
// *
// *  SUP     (input/output) DOUBLE PRECISION
// *          Upper bound for the smallest singular value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double bis= 0.9999e+0;
static double bis1= 0.7e+0;
static int iflmax= 5;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ifl= 0;
static double d= 0.0;
static double dm= 0.0;
static double xinf= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..

public static void dlasq4 (int n,
double [] q, int _q_offset,
double [] e, int _e_offset,
doubleW tau,
doubleW sup)  {

ifl = 1;
sup.val = Math.min(Math.min(Math.min(Math.min(Math.min(Math.min(sup.val, q[(1)- 1+ _q_offset]), q[(2)- 1+ _q_offset]), q[(3)- 1+ _q_offset]), q[(n)- 1+ _q_offset]), q[(n-1)- 1+ _q_offset]), q[(n-2)- 1+ _q_offset]) ;
tau.val = sup.val*bis;
xinf = zero;
label10:
   Dummy.label("Dlasq4",10);
if (ifl == iflmax)  {
    tau.val = xinf;
Dummy.go_to("Dlasq4",999999);
}              // Close if()
d = q[(1)- 1+ _q_offset]-tau.val;
dm = d;
{
forloop20:
for (i = 1; i <= n-2; i++) {
d = (d/(d+e[(i)- 1+ _e_offset]))*q[(i+1)- 1+ _q_offset]-tau.val;
if (dm > d)  
    dm = d;
if (d < zero)  {
    sup.val = tau.val;
tau.val = Math.max(sup.val*Math.pow(bis1, ifl), d+tau.val) ;
ifl = ifl+1;
Dummy.go_to("Dlasq4",10);
}              // Close if()
Dummy.label("Dlasq4",20);
}              //  Close for() loop. 
}
d = (d/(d+e[(n-1)- 1+ _e_offset]))*q[(n)- 1+ _q_offset]-tau.val;
if (dm > d)  
    dm = d;
if (d < zero)  {
    sup.val = tau.val;
xinf = Math.max(xinf, d+tau.val) ;
if (sup.val*Math.pow(bis1, ifl) <= xinf)  {
    tau.val = xinf;
}              // Close if()
else  {
  tau.val = sup.val*Math.pow(bis1, ifl);
ifl = ifl+1;
Dummy.go_to("Dlasq4",10);
}              //  Close else.
}              // Close if()
else  {
  sup.val = Math.min(sup.val, dm+tau.val) ;
}              //  Close else.
Dummy.go_to("Dlasq4",999999);
// *
// *     End of DLASQ4
// *
Dummy.label("Dlasq4",999999);
return;
   }
} // End class.
