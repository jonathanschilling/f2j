/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlasrt {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  Sort the numbers in D in increasing order (if ID = 'I') or
// *  in decreasing order (if ID = 'D' ).
// *
// *  Use Quick Sort, reverting to Insertion sort on arrays of
// *  size <= 20. Dimension of STACK limits N to about 2**32.
// *
// *  Arguments
// *  =========
// *
// *  ID      (input) CHARACTER*1
// *          = 'I': sort D in increasing order;
// *          = 'D': sort D in decreasing order.
// *
// *  N       (input) INTEGER
// *          The length of the array D.
// *
// *  D       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, the array to be sorted.
// *          On exit, D has been sorted into increasing order
// *          (D(1) <= ... <= D(N) ) or into decreasing order
// *          (D(1) >= ... >= D(N) ), depending on ID.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int select= 20;
// *     ..
// *     .. Local Scalars ..
static int dir= 0;
static int endd= 0;
static int i= 0;
static int j= 0;
static int start= 0;
static int stkpnt= 0;
static double d1= 0.0;
static double d2= 0.0;
static double d3= 0.0;
static double dmnmx= 0.0;
static double tmp= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] stack= new int[(2) * (32)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input paramters.
// *

public static void dlasrt (String id,
int n,
double [] d, int _d_offset,
intW info)  {

info.val = 0;
dir = -1;
if ((id.toLowerCase().charAt(0) == "D".toLowerCase().charAt(0)))  {
    dir = 0;
}              // Close if()
else if ((id.toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    dir = 1;
}              // Close else if()
if (dir == -1)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLASRT",-info.val);
Dummy.go_to("Dlasrt",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n <= 1)  
    Dummy.go_to("Dlasrt",999999);
// *
stkpnt = 1;
stack[(1)- 1+(1- 1)*2] = 1;
stack[(2)- 1+(1- 1)*2] = n;
label10:
   Dummy.label("Dlasrt",10);
start = stack[(1)- 1+(stkpnt- 1)*2];
endd = stack[(2)- 1+(stkpnt- 1)*2];
stkpnt = stkpnt-1;
if (endd-start <= select && endd-start > 0)  {
    // *
// *        Do Insertion sort on D( START:ENDD )
// *
if (dir == 0)  {
    // *
// *           Sort into decreasing order
// *
{
forloop30:
for (i = start+1; i <= endd; i++) {
{
int _j_inc = -1;
forloop20:
for (j = i; j >= start+1; j += _j_inc) {
if (d[(j)- 1+ _d_offset] > d[(j-1)- 1+ _d_offset])  {
    dmnmx = d[(j)- 1+ _d_offset];
d[(j)- 1+ _d_offset] = d[(j-1)- 1+ _d_offset];
d[(j-1)- 1+ _d_offset] = dmnmx;
}              // Close if()
else  {
  continue forloop30;
}              //  Close else.
Dummy.label("Dlasrt",20);
}              //  Close for() loop. 
}
Dummy.label("Dlasrt",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *           Sort into increasing order
// *
{
forloop50:
for (i = start+1; i <= endd; i++) {
{
int _j_inc = -1;
forloop40:
for (j = i; j >= start+1; j += _j_inc) {
if (d[(j)- 1+ _d_offset] < d[(j-1)- 1+ _d_offset])  {
    dmnmx = d[(j)- 1+ _d_offset];
d[(j)- 1+ _d_offset] = d[(j-1)- 1+ _d_offset];
d[(j-1)- 1+ _d_offset] = dmnmx;
}              // Close if()
else  {
  continue forloop50;
}              //  Close else.
Dummy.label("Dlasrt",40);
}              //  Close for() loop. 
}
Dummy.label("Dlasrt",50);
}              //  Close for() loop. 
}
// *
}              //  Close else.
// *
}              // Close if()
else if (endd-start > select)  {
    // *
// *        Partition D( START:ENDD ) and stack parts, largest one first
// *
// *        Choose partition entry as median of 3
// *
d1 = d[(start)- 1+ _d_offset];
d2 = d[(endd)- 1+ _d_offset];
i = (start+endd)/2;
d3 = d[(i)- 1+ _d_offset];
if (d1 < d2)  {
    if (d3 < d1)  {
    dmnmx = d1;
}              // Close if()
else if (d3 < d2)  {
    dmnmx = d3;
}              // Close else if()
else  {
  dmnmx = d2;
}              //  Close else.
}              // Close if()
else  {
  if (d3 < d2)  {
    dmnmx = d2;
}              // Close if()
else if (d3 < d1)  {
    dmnmx = d3;
}              // Close else if()
else  {
  dmnmx = d1;
}              //  Close else.
}              //  Close else.
// *
if (dir == 0)  {
    // *
// *           Sort into decreasing order
// *
i = start-1;
j = endd+1;
label60:
   Dummy.label("Dlasrt",60);
label70:
   Dummy.label("Dlasrt",70);
j = j-1;
if (d[(j)- 1+ _d_offset] < dmnmx)  
    Dummy.go_to("Dlasrt",70);
label80:
   Dummy.label("Dlasrt",80);
i = i+1;
if (d[(i)- 1+ _d_offset] > dmnmx)  
    Dummy.go_to("Dlasrt",80);
if (i < j)  {
    tmp = d[(i)- 1+ _d_offset];
d[(i)- 1+ _d_offset] = d[(j)- 1+ _d_offset];
d[(j)- 1+ _d_offset] = tmp;
Dummy.go_to("Dlasrt",60);
}              // Close if()
if (j-start > endd-j-1)  {
    stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = start;
stack[(2)- 1+(stkpnt- 1)*2] = j;
stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = j+1;
stack[(2)- 1+(stkpnt- 1)*2] = endd;
}              // Close if()
else  {
  stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = j+1;
stack[(2)- 1+(stkpnt- 1)*2] = endd;
stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = start;
stack[(2)- 1+(stkpnt- 1)*2] = j;
}              //  Close else.
}              // Close if()
else  {
  // *
// *           Sort into increasing order
// *
i = start-1;
j = endd+1;
label90:
   Dummy.label("Dlasrt",90);
label100:
   Dummy.label("Dlasrt",100);
j = j-1;
if (d[(j)- 1+ _d_offset] > dmnmx)  
    Dummy.go_to("Dlasrt",100);
label110:
   Dummy.label("Dlasrt",110);
i = i+1;
if (d[(i)- 1+ _d_offset] < dmnmx)  
    Dummy.go_to("Dlasrt",110);
if (i < j)  {
    tmp = d[(i)- 1+ _d_offset];
d[(i)- 1+ _d_offset] = d[(j)- 1+ _d_offset];
d[(j)- 1+ _d_offset] = tmp;
Dummy.go_to("Dlasrt",90);
}              // Close if()
if (j-start > endd-j-1)  {
    stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = start;
stack[(2)- 1+(stkpnt- 1)*2] = j;
stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = j+1;
stack[(2)- 1+(stkpnt- 1)*2] = endd;
}              // Close if()
else  {
  stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = j+1;
stack[(2)- 1+(stkpnt- 1)*2] = endd;
stkpnt = stkpnt+1;
stack[(1)- 1+(stkpnt- 1)*2] = start;
stack[(2)- 1+(stkpnt- 1)*2] = j;
}              //  Close else.
}              //  Close else.
}              // Close else if()
if (stkpnt > 0)  
    Dummy.go_to("Dlasrt",10);
Dummy.go_to("Dlasrt",999999);
// *
// *     End of DLASRT
// *
Dummy.label("Dlasrt",999999);
return;
   }
} // End class.
