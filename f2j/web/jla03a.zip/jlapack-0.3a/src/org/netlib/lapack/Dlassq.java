/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlassq {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASSQ  returns the values  scl  and  smsq  such that
// *
// *     ( scl**2 )*smsq = x( 1 )**2 +...+ x( n )**2 + ( scale**2 )*sumsq,
// *
// *  where  x( i ) = X( 1 + ( i - 1 )*INCX ). The value of  sumsq  is
// *  assumed to be non-negative and  scl  returns the value
// *
// *     scl = max( scale, abs( x( i ) ) ).
// *
// *  scale and sumsq must be supplied in SCALE and SUMSQ and
// *  scl and smsq are overwritten on SCALE and SUMSQ respectively.
// *
// *  The routine makes only one pass through the vector x.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of elements to be used from the vector X.
// *
// *  X       (input) DOUBLE PRECISION
// *          The vector for which a scaled sum of squares is computed.
// *             x( i )  = X( 1 + ( i - 1 )*INCX ), 1 <= i <= n.
// *
// *  INCX    (input) INTEGER
// *          The increment between successive values of the vector X.
// *          INCX > 0.
// *
// *  SCALE   (input/output) DOUBLE PRECISION
// *          On entry, the value  scale  in the equation above.
// *          On exit, SCALE is overwritten with  scl , the scaling factor
// *          for the sum of squares.
// *
// *  SUMSQ   (input/output) DOUBLE PRECISION
// *          On entry, the value  sumsq  in the equation above.
// *          On exit, SUMSQ is overwritten with  smsq , the basic sum of
// *          squares from which  scl  has been factored out.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int ix= 0;
static double absxi= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlassq (int n,
double [] x, int _x_offset,
int incx,
doubleW scale,
doubleW sumsq)  {

if (n > 0)  {
    {
int _ix_inc = incx;
forloop10:
for (ix = 1; (_ix_inc < 0) ? ix >= 1+(n-1)*incx : ix <= 1+(n-1)*incx; ix += _ix_inc) {
if (x[(ix)- 1+ _x_offset] != zero)  {
    absxi = Math.abs(x[(ix)- 1+ _x_offset]);
if (scale.val < absxi)  {
    sumsq.val = 1+sumsq.val*Math.pow((scale.val/absxi), 2);
scale.val = absxi;
}              // Close if()
else  {
  sumsq.val = sumsq.val+Math.pow((absxi/scale.val), 2);
}              //  Close else.
}              // Close if()
Dummy.label("Dlassq",10);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dlassq",999999);
// *
// *     End of DLASSQ
// *
Dummy.label("Dlassq",999999);
return;
   }
} // End class.
