/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dlasv2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASV2 computes the singular value decomposition of a 2-by-2
// *  triangular matrix
// *     [  F   G  ]
// *     [  0   H  ].
// *  On return, abs(SSMAX) is the larger singular value, abs(SSMIN) is the
// *  smaller singular value, and (CSL,SNL) and (CSR,SNR) are the left and
// *  right singular vectors for abs(SSMAX), giving the decomposition
// *
// *     [ CSL  SNL ] [  F   G  ] [ CSR -SNR ]  =  [ SSMAX   0   ]
// *     [-SNL  CSL ] [  0   H  ] [ SNR  CSR ]     [  0    SSMIN ].
// *
// *  Arguments
// *  =========
// *
// *  F       (input) DOUBLE PRECISION
// *          The (1,1) element of the 2-by-2 matrix.
// *
// *  G       (input) DOUBLE PRECISION
// *          The (1,2) element of the 2-by-2 matrix.
// *
// *  H       (input) DOUBLE PRECISION
// *          The (2,2) element of the 2-by-2 matrix.
// *
// *  SSMIN   (output) DOUBLE PRECISION
// *          abs(SSMIN) is the smaller singular value.
// *
// *  SSMAX   (output) DOUBLE PRECISION
// *          abs(SSMAX) is the larger singular value.
// *
// *  SNL     (output) DOUBLE PRECISION
// *  CSL     (output) DOUBLE PRECISION
// *          The vector (CSL, SNL) is a unit left singular vector for the
// *          singular value abs(SSMAX).
// *
// *  SNR     (output) DOUBLE PRECISION
// *  CSR     (output) DOUBLE PRECISION
// *          The vector (CSR, SNR) is a unit right singular vector for the
// *          singular value abs(SSMAX).
// *
// *  Further Details
// *  ===============
// *
// *  Any input parameter may be aliased with any output parameter.
// *
// *  Barring over/underflow and assuming a guard digit in subtraction, all
// *  output quantities are correct to within a few units in the last
// *  place (ulps).
// *
// *  In IEEE arithmetic, the code works correctly if one matrix element is
// *  infinite.
// *
// *  Overflow will not occur unless the largest singular value itself
// *  overflows or is within a few ulps of overflow. (On machines with
// *  partial overflow, like the Cray, overflow may occur if the largest
// *  singular value is within a factor of 2 of overflow.)
// *
// *  Underflow is harmless if underflow is gradual. Otherwise, results
// *  may correspond to a matrix modified by perturbations of size near
// *  the underflow threshold.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double four= 4.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean gasmal= false;
static boolean swap= false;
static int pmax= 0;
static double a= 0.0;
static double clt= 0.0;
static double crt= 0.0;
static double d= 0.0;
static double fa= 0.0;
static double ft= 0.0;
static double ga= 0.0;
static double gt= 0.0;
static double ha= 0.0;
static double ht= 0.0;
static double l= 0.0;
static double m= 0.0;
static double mm= 0.0;
static double r= 0.0;
static double s= 0.0;
static double slt= 0.0;
static double srt= 0.0;
static double t= 0.0;
static double temp= 0.0;
static double tsign= 0.0;
static double tt= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlasv2 (double f,
double g,
double h,
doubleW ssmin,
doubleW ssmax,
doubleW snr,
doubleW csr,
doubleW snl,
doubleW csl)  {

ft = f;
fa = Math.abs(ft);
ht = h;
ha = Math.abs(h);
// *
// *     PMAX points to the maximum absolute element of matrix
// *       PMAX = 1 if F largest in absolute values
// *       PMAX = 2 if G largest in absolute values
// *       PMAX = 3 if H largest in absolute values
// *
pmax = 1;
swap = (ha > fa);
if (swap)  {
    pmax = 3;
temp = ft;
ft = ht;
ht = temp;
temp = fa;
fa = ha;
ha = temp;
// *
// *        Now FA .ge. HA
// *
}              // Close if()
gt = g;
ga = Math.abs(gt);
if (ga == zero)  {
    // *
// *        Diagonal matrix
// *
ssmin.val = ha;
ssmax.val = fa;
clt = one;
crt = one;
slt = zero;
srt = zero;
}              // Close if()
else  {
  gasmal = true;
if (ga > fa)  {
    pmax = 2;
if ((fa/ga) < Dlamch.dlamch("EPS"))  {
    // *
// *              Case of very large GA
// *
gasmal = false;
ssmax.val = ga;
if (ha > one)  {
    ssmin.val = fa/(ga/ha);
}              // Close if()
else  {
  ssmin.val = (fa/ga)*ha;
}              //  Close else.
clt = one;
slt = ht/gt;
srt = one;
crt = ft/gt;
}              // Close if()
}              // Close if()
if (gasmal)  {
    // *
// *           Normal case
// *
d = fa-ha;
if (d == fa)  {
    // *
// *              Copes with infinite F or H
// *
l = one;
}              // Close if()
else  {
  l = d/fa;
}              //  Close else.
// *
// *           Note that 0 .le. L .le. 1
// *
m = gt/ft;
// *
// *           Note that abs(M) .le. 1/macheps
// *
t = two-l;
// *
// *           Note that T .ge. 1
// *
mm = m*m;
tt = t*t;
s = Math.sqrt(tt+mm);
// *
// *           Note that 1 .le. S .le. 1 + 1/macheps
// *
if (l == zero)  {
    r = Math.abs(m);
}              // Close if()
else  {
  r = Math.sqrt(l*l+mm);
}              //  Close else.
// *
// *           Note that 0 .le. R .le. 1 + 1/macheps
// *
a = half*(s+r);
// *
// *           Note that 1 .le. A .le. 1 + abs(M)
// *
ssmin.val = ha/a;
ssmax.val = fa*a;
if (mm == zero)  {
    // *
// *              Note that M is very tiny
// *
if (l == zero)  {
    t = ((ft) >= 0 ? Math.abs(two) : -Math.abs(two))*((gt) >= 0 ? Math.abs(one) : -Math.abs(one));
}              // Close if()
else  {
  t = gt/((ft) >= 0 ? Math.abs(d) : -Math.abs(d))+m/t;
}              //  Close else.
}              // Close if()
else  {
  t = (m/(s+t)+m/(r+l))*(one+a);
}              //  Close else.
l = Math.sqrt(t*t+four);
crt = two/l;
srt = t/l;
clt = (crt+srt*m)/a;
slt = (ht/ft)*srt/a;
}              // Close if()
}              //  Close else.
if (swap)  {
    csl.val = srt;
snl.val = crt;
csr.val = slt;
snr.val = clt;
}              // Close if()
else  {
  csl.val = clt;
snl.val = slt;
csr.val = crt;
snr.val = srt;
}              //  Close else.
// *
// *     Correct signs of SSMAX and SSMIN
// *
if (pmax == 1)  
    tsign = ((csr.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((csl.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((f) >= 0 ? Math.abs(one) : -Math.abs(one));
if (pmax == 2)  
    tsign = ((snr.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((csl.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((g) >= 0 ? Math.abs(one) : -Math.abs(one));
if (pmax == 3)  
    tsign = ((snr.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((snl.val) >= 0 ? Math.abs(one) : -Math.abs(one))*((h) >= 0 ? Math.abs(one) : -Math.abs(one));
ssmax.val = ((tsign) >= 0 ? Math.abs(ssmax.val) : -Math.abs(ssmax.val));
ssmin.val = ((tsign*((f) >= 0 ? Math.abs(one) : -Math.abs(one))*((h) >= 0 ? Math.abs(one) : -Math.abs(one))) >= 0 ? Math.abs(ssmin.val) : -Math.abs(ssmin.val));
Dummy.go_to("Dlasv2",999999);
// *
// *     End of DLASV2
// *
Dummy.label("Dlasv2",999999);
return;
   }
} // End class.
