/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlaswp {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASWP performs a series of row interchanges on the matrix A.
// *  One row interchange is initiated for each of rows K1 through K2 of A.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the matrix of column dimension N to which the row
// *          interchanges will be applied.
// *          On exit, the permuted matrix.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *
// *  K1      (input) INTEGER
// *          The first element of IPIV for which a row interchange will
// *          be done.
// *
// *  K2      (input) INTEGER
// *          The last element of IPIV for which a row interchange will
// *          be done.
// *
// *  IPIV    (input) INTEGER array, dimension (M*abs(INCX))
// *          The vector of pivot indices.  Only the elements in positions
// *          K1 through K2 of IPIV are accessed.
// *          IPIV(K) = L implies rows K and L are to be interchanged.
// *
// *  INCX    (input) INTEGER
// *          The increment between successive values of IPIV.  If IPIV
// *          is negative, the pivots are applied in reverse order.
// *
// * =====================================================================
// *
// *     .. Local Scalars ..
static int i= 0;
static int ip= 0;
static int ix= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Interchange row I with row IPIV(I) for each of rows K1 through K2.
// *

public static void dlaswp (int n,
double [] a, int _a_offset,
int lda,
int k1,
int k2,
int [] ipiv, int _ipiv_offset,
int incx)  {

if (incx == 0)  
    Dummy.go_to("Dlaswp",999999);
if (incx > 0)  {
    ix = k1;
}              // Close if()
else  {
  ix = 1+(1-k2)*incx;
}              //  Close else.
if (incx == 1)  {
    {
forloop10:
for (i = k1; i <= k2; i++) {
ip = ipiv[(i)- 1+ _ipiv_offset];
if (ip != i)  
    Dswap.dswap(n,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,a,(ip)- 1+(1- 1)*lda+ _a_offset,lda);
Dummy.label("Dlaswp",10);
}              //  Close for() loop. 
}
}              // Close if()
else if (incx > 1)  {
    {
forloop20:
for (i = k1; i <= k2; i++) {
ip = ipiv[(ix)- 1+ _ipiv_offset];
if (ip != i)  
    Dswap.dswap(n,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,a,(ip)- 1+(1- 1)*lda+ _a_offset,lda);
ix = ix+incx;
Dummy.label("Dlaswp",20);
}              //  Close for() loop. 
}
}              // Close else if()
else if (incx < 0)  {
    {
int _i_inc = -1;
forloop30:
for (i = k2; i >= k1; i += _i_inc) {
ip = ipiv[(ix)- 1+ _ipiv_offset];
if (ip != i)  
    Dswap.dswap(n,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,a,(ip)- 1+(1- 1)*lda+ _a_offset,lda);
ix = ix+incx;
Dummy.label("Dlaswp",30);
}              //  Close for() loop. 
}
}              // Close else if()
// *
Dummy.go_to("Dlaswp",999999);
// *
// *     End of DLASWP
// *
Dummy.label("Dlaswp",999999);
return;
   }
} // End class.
