/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlasy2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASY2 solves for the N1 by N2 matrix X, 1 <= N1,N2 <= 2, in
// *
// *         op(TL)*X + ISGN*X*op(TR) = SCALE*B,
// *
// *  where TL is N1 by N1, TR is N2 by N2, B is N1 by N2, and ISGN = 1 or
// *  -1.  op(T) = T or T', where T' denotes the transpose of T.
// *
// *  Arguments
// *  =========
// *
// *  LTRANL  (input) LOGICAL
// *          On entry, LTRANL specifies the op(TL):
// *             = .FALSE., op(TL) = TL,
// *             = .TRUE., op(TL) = TL'.
// *
// *  LTRANR  (input) LOGICAL
// *          On entry, LTRANR specifies the op(TR):
// *            = .FALSE., op(TR) = TR,
// *            = .TRUE., op(TR) = TR'.
// *
// *  ISGN    (input) INTEGER
// *          On entry, ISGN specifies the sign of the equation
// *          as described before. ISGN may only be 1 or -1.
// *
// *  N1      (input) INTEGER
// *          On entry, N1 specifies the order of matrix TL.
// *          N1 may only be 0, 1 or 2.
// *
// *  N2      (input) INTEGER
// *          On entry, N2 specifies the order of matrix TR.
// *          N2 may only be 0, 1 or 2.
// *
// *  TL      (input) DOUBLE PRECISION array, dimension (LDTL,2)
// *          On entry, TL contains an N1 by N1 matrix.
// *
// *  LDTL    (input) INTEGER
// *          The leading dimension of the matrix TL. LDTL >= max(1,N1).
// *
// *  TR      (input) DOUBLE PRECISION array, dimension (LDTR,2)
// *          On entry, TR contains an N2 by N2 matrix.
// *
// *  LDTR    (input) INTEGER
// *          The leading dimension of the matrix TR. LDTR >= max(1,N2).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,2)
// *          On entry, the N1 by N2 matrix B contains the right-hand
// *          side of the equation.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the matrix B. LDB >= max(1,N1).
// *
// *  SCALE   (output) DOUBLE PRECISION
// *          On exit, SCALE contains the scale factor. SCALE is chosen
// *          less than or equal to 1 to prevent the solution overflowing.
// *
// *  X       (output) DOUBLE PRECISION array, dimension (LDX,2)
// *          On exit, X contains the N1 by N2 solution.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the matrix X. LDX >= max(1,N1).
// *
// *  XNORM   (output) DOUBLE PRECISION
// *          On exit, XNORM is the infinity-norm of the solution.
// *
// *  INFO    (output) INTEGER
// *          On exit, INFO is set to
// *             0: successful exit.
// *             1: TL and TR have too close eigenvalues, so TL or
// *                TR is perturbed to get a nonsingular equation.
// *          NOTE: In the interests of speed, this routine does not
// *                check the inputs for errors.
// *
// * =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
static double half= 0.5e+0;
static double eight= 8.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean bswap= false;
static boolean xswap= false;
static int i= 0;
static int ip= 0;
static int ipiv= 0;
static int ipsv= 0;
static int j= 0;
static int jp= 0;
static int jpsv= 0;
static int k= 0;
static double bet= 0.0;
static double eps= 0.0;
static double gam= 0.0;
static double l21= 0.0;
static double sgn= 0.0;
static double smin= 0.0;
static double smlnum= 0.0;
static double tau1= 0.0;
static double temp= 0.0;
static double u11= 0.0;
static double u12= 0.0;
static double u22= 0.0;
static double xmax= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] jpiv= new int[(4)];
static double [] btmp= new double[(4)];
static double [] t16= new double[(4) * (4)];
static double [] tmp= new double[(4)];
static double [] x2= new double[(2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] locu22 = {4 
, 3 , 2 , 1 };
static int [] locl21 = {2 
, 1 , 4 , 3 };
static int [] locu12 = {3 
, 4 , 1 , 2 };
static boolean [] xswpiv = {false 
, false , true , true };
static boolean [] bswpiv = {false 
, true , false , true };
// *     ..
// *     .. Executable Statements ..
// *
// *     Do not check the input parameters for errors
// *

public static void dlasy2 (boolean ltranl,
boolean ltranr,
int isgn,
int n1,
int n2,
double [] tl, int _tl_offset,
int ldtl,
double [] tr, int _tr_offset,
int ldtr,
double [] b, int _b_offset,
int ldb,
doubleW scale,
double [] x, int _x_offset,
int ldx,
doubleW xnorm,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (n1 == 0 || n2 == 0)  
    Dummy.go_to("Dlasy2",999999);
// *
// *     Set constants to control overflow
// *
eps = Dlamch.dlamch("P");
smlnum = Dlamch.dlamch("S")/eps;
sgn = (double)(isgn);
// *
k = n1+n1+n2-2;
if (k == 1) 
  Dummy.go_to("Dlasy2",10);
else if (k == 2) 
  Dummy.go_to("Dlasy2",20);
else if (k == 3) 
  Dummy.go_to("Dlasy2",30);
else if (k == 4) 
  Dummy.go_to("Dlasy2",50);
// *
// *     1 by 1: TL11*X + SGN*X*TR11 = B11
// *
label10:
   Dummy.label("Dlasy2",10);
tau1 = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
bet = Math.abs(tau1);
if (bet <= smlnum)  {
    tau1 = smlnum;
bet = smlnum;
info.val = 1;
}              // Close if()
// *
scale.val = one;
gam = Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset]);
if (smlnum*gam > bet)  
    scale.val = one/gam;
// *
x[(1)- 1+(1- 1)*ldx+ _x_offset] = (b[(1)- 1+(1- 1)*ldb+ _b_offset]*scale.val)/tau1;
xnorm.val = Math.abs(x[(1)- 1+(1- 1)*ldx+ _x_offset]);
Dummy.go_to("Dlasy2",999999);
// *
// *     1 by 2:
// *     TL11*[X11 X12] + ISGN*[X11 X12]*op[TR11 TR12]  = [B11 B12]
// *                                       [TR21 TR22]
// *
label20:
   Dummy.label("Dlasy2",20);
// *
smin = Math.max(eps*Math.max(Math.max(Math.max(Math.max(Math.abs(tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]), Math.abs(tr[(1)- 1+(1- 1)*ldtr+ _tr_offset])), Math.abs(tr[(1)- 1+(2- 1)*ldtr+ _tr_offset])), Math.abs(tr[(2)- 1+(1- 1)*ldtr+ _tr_offset])), Math.abs(tr[(2)- 1+(2- 1)*ldtr+ _tr_offset])) , smlnum) ;
tmp[(1)- 1] = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
tmp[(4)- 1] = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(2)- 1+(2- 1)*ldtr+ _tr_offset];
if (ltranr)  {
    tmp[(2)- 1] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
tmp[(3)- 1] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
}              // Close if()
else  {
  tmp[(2)- 1] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
tmp[(3)- 1] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
}              //  Close else.
btmp[(1)- 1] = b[(1)- 1+(1- 1)*ldb+ _b_offset];
btmp[(2)- 1] = b[(1)- 1+(2- 1)*ldb+ _b_offset];
Dummy.go_to("Dlasy2",40);
// *
// *     2 by 1:
// *          op[TL11 TL12]*[X11] + ISGN* [X11]*TR11  = [B11]
// *            [TL21 TL22] [X21]         [X21]         [B21]
// *
label30:
   Dummy.label("Dlasy2",30);
smin = Math.max(eps*Math.max(Math.max(Math.max(Math.max(Math.abs(tr[(1)- 1+(1- 1)*ldtr+ _tr_offset]), Math.abs(tl[(1)- 1+(1- 1)*ldtl+ _tl_offset])), Math.abs(tl[(1)- 1+(2- 1)*ldtl+ _tl_offset])), Math.abs(tl[(2)- 1+(1- 1)*ldtl+ _tl_offset])), Math.abs(tl[(2)- 1+(2- 1)*ldtl+ _tl_offset])) , smlnum) ;
tmp[(1)- 1] = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
tmp[(4)- 1] = tl[(2)- 1+(2- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
if (ltranl)  {
    tmp[(2)- 1] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
tmp[(3)- 1] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
}              // Close if()
else  {
  tmp[(2)- 1] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
tmp[(3)- 1] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
}              //  Close else.
btmp[(1)- 1] = b[(1)- 1+(1- 1)*ldb+ _b_offset];
btmp[(2)- 1] = b[(2)- 1+(1- 1)*ldb+ _b_offset];
label40:
   Dummy.label("Dlasy2",40);
// *
// *     Solve 2 by 2 system using complete pivoting.
// *     Set pivots less than SMIN to SMIN.
// *
ipiv = Idamax.idamax(4,tmp,0,1);
u11 = tmp[(ipiv)- 1];
if (Math.abs(u11) <= smin)  {
    info.val = 1;
u11 = smin;
}              // Close if()
u12 = tmp[(locu12[(ipiv)- 1])- 1];
l21 = tmp[(locl21[(ipiv)- 1])- 1]/u11;
u22 = tmp[(locu22[(ipiv)- 1])- 1]-u12*l21;
xswap = xswpiv[(ipiv)- 1];
bswap = bswpiv[(ipiv)- 1];
if (Math.abs(u22) <= smin)  {
    info.val = 1;
u22 = smin;
}              // Close if()
if (bswap)  {
    temp = btmp[(2)- 1];
btmp[(2)- 1] = btmp[(1)- 1]-l21*temp;
btmp[(1)- 1] = temp;
}              // Close if()
else  {
  btmp[(2)- 1] = btmp[(2)- 1]-l21*btmp[(1)- 1];
}              //  Close else.
scale.val = one;
if ((two*smlnum)*Math.abs(btmp[(2)- 1]) > Math.abs(u22) || (two*smlnum)*Math.abs(btmp[(1)- 1]) > Math.abs(u11))  {
    scale.val = half/Math.max(Math.abs(btmp[(1)- 1]), Math.abs(btmp[(2)- 1])) ;
btmp[(1)- 1] = btmp[(1)- 1]*scale.val;
btmp[(2)- 1] = btmp[(2)- 1]*scale.val;
}              // Close if()
x2[(2)- 1] = btmp[(2)- 1]/u22;
x2[(1)- 1] = btmp[(1)- 1]/u11-(u12/u11)*x2[(2)- 1];
if (xswap)  {
    temp = x2[(2)- 1];
x2[(2)- 1] = x2[(1)- 1];
x2[(1)- 1] = temp;
}              // Close if()
x[(1)- 1+(1- 1)*ldx+ _x_offset] = x2[(1)- 1];
if (n1 == 1)  {
    x[(1)- 1+(2- 1)*ldx+ _x_offset] = x2[(2)- 1];
xnorm.val = Math.abs(x[(1)- 1+(1- 1)*ldx+ _x_offset])+Math.abs(x[(1)- 1+(2- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  x[(2)- 1+(1- 1)*ldx+ _x_offset] = x2[(2)- 1];
xnorm.val = Math.max(Math.abs(x[(1)- 1+(1- 1)*ldx+ _x_offset]), Math.abs(x[(2)- 1+(1- 1)*ldx+ _x_offset])) ;
}              //  Close else.
Dummy.go_to("Dlasy2",999999);
// *
// *     2 by 2:
// *     op[TL11 TL12]*[X11 X12] +ISGN* [X11 X12]*op[TR11 TR12] = [B11 B12]
// *       [TL21 TL22] [X21 X22]        [X21 X22]   [TR21 TR22]   [B21 B22]
// *
// *     Solve equivalent 4 by 4 system using complete pivoting.
// *     Set pivots less than SMIN to SMIN.
// *
label50:
   Dummy.label("Dlasy2",50);
smin = Math.max(Math.max(Math.max(Math.abs(tr[(1)- 1+(1- 1)*ldtr+ _tr_offset]), Math.abs(tr[(1)- 1+(2- 1)*ldtr+ _tr_offset])), Math.abs(tr[(2)- 1+(1- 1)*ldtr+ _tr_offset])), Math.abs(tr[(2)- 1+(2- 1)*ldtr+ _tr_offset])) ;
smin = Math.max(Math.max(Math.max(Math.max(smin, Math.abs(tl[(1)- 1+(1- 1)*ldtl+ _tl_offset])), Math.abs(tl[(1)- 1+(2- 1)*ldtl+ _tl_offset])), Math.abs(tl[(2)- 1+(1- 1)*ldtl+ _tl_offset])), Math.abs(tl[(2)- 1+(2- 1)*ldtl+ _tl_offset])) ;
smin = Math.max(eps*smin, smlnum) ;
btmp[(1)- 1] = zero;
Dcopy.dcopy(16,btmp,0,0,t16,0,1);
t16[(1)- 1+(1- 1)*4] = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
t16[(2)- 1+(2- 1)*4] = tl[(2)- 1+(2- 1)*ldtl+ _tl_offset]+sgn*tr[(1)- 1+(1- 1)*ldtr+ _tr_offset];
t16[(3)- 1+(3- 1)*4] = tl[(1)- 1+(1- 1)*ldtl+ _tl_offset]+sgn*tr[(2)- 1+(2- 1)*ldtr+ _tr_offset];
t16[(4)- 1+(4- 1)*4] = tl[(2)- 1+(2- 1)*ldtl+ _tl_offset]+sgn*tr[(2)- 1+(2- 1)*ldtr+ _tr_offset];
if (ltranl)  {
    t16[(1)- 1+(2- 1)*4] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
t16[(2)- 1+(1- 1)*4] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
t16[(3)- 1+(4- 1)*4] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
t16[(4)- 1+(3- 1)*4] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
}              // Close if()
else  {
  t16[(1)- 1+(2- 1)*4] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
t16[(2)- 1+(1- 1)*4] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
t16[(3)- 1+(4- 1)*4] = tl[(1)- 1+(2- 1)*ldtl+ _tl_offset];
t16[(4)- 1+(3- 1)*4] = tl[(2)- 1+(1- 1)*ldtl+ _tl_offset];
}              //  Close else.
if (ltranr)  {
    t16[(1)- 1+(3- 1)*4] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
t16[(2)- 1+(4- 1)*4] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
t16[(3)- 1+(1- 1)*4] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
t16[(4)- 1+(2- 1)*4] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
}              // Close if()
else  {
  t16[(1)- 1+(3- 1)*4] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
t16[(2)- 1+(4- 1)*4] = sgn*tr[(2)- 1+(1- 1)*ldtr+ _tr_offset];
t16[(3)- 1+(1- 1)*4] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
t16[(4)- 1+(2- 1)*4] = sgn*tr[(1)- 1+(2- 1)*ldtr+ _tr_offset];
}              //  Close else.
btmp[(1)- 1] = b[(1)- 1+(1- 1)*ldb+ _b_offset];
btmp[(2)- 1] = b[(2)- 1+(1- 1)*ldb+ _b_offset];
btmp[(3)- 1] = b[(1)- 1+(2- 1)*ldb+ _b_offset];
btmp[(4)- 1] = b[(2)- 1+(2- 1)*ldb+ _b_offset];
// *
// *     Perform elimination
// *
{
forloop100:
for (i = 1; i <= 3; i++) {
xmax = zero;
{
forloop70:
for (ip = i; ip <= 4; ip++) {
{
forloop60:
for (jp = i; jp <= 4; jp++) {
if (Math.abs(t16[(ip)- 1+(jp- 1)*4]) >= xmax)  {
    xmax = Math.abs(t16[(ip)- 1+(jp- 1)*4]);
ipsv = ip;
jpsv = jp;
}              // Close if()
Dummy.label("Dlasy2",60);
}              //  Close for() loop. 
}
Dummy.label("Dlasy2",70);
}              //  Close for() loop. 
}
if (ipsv != i)  {
    Dswap.dswap(4,t16,(ipsv)- 1+(1- 1)*4,4,t16,(i)- 1+(1- 1)*4,4);
temp = btmp[(i)- 1];
btmp[(i)- 1] = btmp[(ipsv)- 1];
btmp[(ipsv)- 1] = temp;
}              // Close if()
if (jpsv != i)  
    Dswap.dswap(4,t16,(1)- 1+(jpsv- 1)*4,1,t16,(1)- 1+(i- 1)*4,1);
jpiv[(i)- 1] = jpsv;
if (Math.abs(t16[(i)- 1+(i- 1)*4]) < smin)  {
    info.val = 1;
t16[(i)- 1+(i- 1)*4] = smin;
}              // Close if()
{
forloop90:
for (j = i+1; j <= 4; j++) {
t16[(j)- 1+(i- 1)*4] = t16[(j)- 1+(i- 1)*4]/t16[(i)- 1+(i- 1)*4];
btmp[(j)- 1] = btmp[(j)- 1]-t16[(j)- 1+(i- 1)*4]*btmp[(i)- 1];
{
forloop80:
for (k = i+1; k <= 4; k++) {
t16[(j)- 1+(k- 1)*4] = t16[(j)- 1+(k- 1)*4]-t16[(j)- 1+(i- 1)*4]*t16[(i)- 1+(k- 1)*4];
Dummy.label("Dlasy2",80);
}              //  Close for() loop. 
}
Dummy.label("Dlasy2",90);
}              //  Close for() loop. 
}
Dummy.label("Dlasy2",100);
}              //  Close for() loop. 
}
if (Math.abs(t16[(4)- 1+(4- 1)*4]) < smin)  
    t16[(4)- 1+(4- 1)*4] = smin;
scale.val = one;
if ((eight*smlnum)*Math.abs(btmp[(1)- 1]) > Math.abs(t16[(1)- 1+(1- 1)*4]) || (eight*smlnum)*Math.abs(btmp[(2)- 1]) > Math.abs(t16[(2)- 1+(2- 1)*4]) || (eight*smlnum)*Math.abs(btmp[(3)- 1]) > Math.abs(t16[(3)- 1+(3- 1)*4]) || (eight*smlnum)*Math.abs(btmp[(4)- 1]) > Math.abs(t16[(4)- 1+(4- 1)*4]))  {
    scale.val = (one/eight)/Math.max(Math.max(Math.max(Math.abs(btmp[(1)- 1]), Math.abs(btmp[(2)- 1])), Math.abs(btmp[(3)- 1])), Math.abs(btmp[(4)- 1])) ;
btmp[(1)- 1] = btmp[(1)- 1]*scale.val;
btmp[(2)- 1] = btmp[(2)- 1]*scale.val;
btmp[(3)- 1] = btmp[(3)- 1]*scale.val;
btmp[(4)- 1] = btmp[(4)- 1]*scale.val;
}              // Close if()
{
forloop120:
for (i = 1; i <= 4; i++) {
k = 5-i;
temp = one/t16[(k)- 1+(k- 1)*4];
tmp[(k)- 1] = btmp[(k)- 1]*temp;
{
forloop110:
for (j = k+1; j <= 4; j++) {
tmp[(k)- 1] = tmp[(k)- 1]-(temp*t16[(k)- 1+(j- 1)*4])*tmp[(j)- 1];
Dummy.label("Dlasy2",110);
}              //  Close for() loop. 
}
Dummy.label("Dlasy2",120);
}              //  Close for() loop. 
}
{
forloop130:
for (i = 1; i <= 3; i++) {
if (jpiv[(4-i)- 1] != 4-i)  {
    temp = tmp[(4-i)- 1];
tmp[(4-i)- 1] = tmp[(jpiv[(4-i)- 1])- 1];
tmp[(jpiv[(4-i)- 1])- 1] = temp;
}              // Close if()
Dummy.label("Dlasy2",130);
}              //  Close for() loop. 
}
x[(1)- 1+(1- 1)*ldx+ _x_offset] = tmp[(1)- 1];
x[(2)- 1+(1- 1)*ldx+ _x_offset] = tmp[(2)- 1];
x[(1)- 1+(2- 1)*ldx+ _x_offset] = tmp[(3)- 1];
x[(2)- 1+(2- 1)*ldx+ _x_offset] = tmp[(4)- 1];
xnorm.val = Math.max(Math.abs(tmp[(1)- 1])+Math.abs(tmp[(3)- 1]), Math.abs(tmp[(2)- 1])+Math.abs(tmp[(4)- 1])) ;
Dummy.go_to("Dlasy2",999999);
// *
// *     End of DLASY2
// *
Dummy.label("Dlasy2",999999);
return;
   }
} // End class.
