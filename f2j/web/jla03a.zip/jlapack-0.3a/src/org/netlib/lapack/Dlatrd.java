/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlatrd {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATRD reduces NB rows and columns of a real symmetric matrix A to
// *  symmetric tridiagonal form by an orthogonal similarity
// *  transformation Q' * A * Q, and returns the matrices V and W which are
// *  needed to apply the transformation to the unreduced part of A.
// *
// *  If UPLO = 'U', DLATRD reduces the last NB rows and columns of a
// *  matrix, of which the upper triangle is supplied;
// *  if UPLO = 'L', DLATRD reduces the first NB rows and columns of a
// *  matrix, of which the lower triangle is supplied.
// *
// *  This is an auxiliary routine called by DSYTRD.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U': Upper triangular
// *          = 'L': Lower triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.
// *
// *  NB      (input) INTEGER
// *          The number of rows and columns to be reduced.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the symmetric matrix A.  If UPLO = 'U', the leading
// *          n-by-n upper triangular part of A contains the upper
// *          triangular part of the matrix A, and the strictly lower
// *          triangular part of A is not referenced.  If UPLO = 'L', the
// *          leading n-by-n lower triangular part of A contains the lower
// *          triangular part of the matrix A, and the strictly upper
// *          triangular part of A is not referenced.
// *          On exit:
// *          if UPLO = 'U', the last NB columns have been reduced to
// *            tridiagonal form, with the diagonal elements overwriting
// *            the diagonal elements of A; the elements above the diagonal
// *            with the array TAU, represent the orthogonal matrix Q as a
// *            product of elementary reflectors;
// *          if UPLO = 'L', the first NB columns have been reduced to
// *            tridiagonal form, with the diagonal elements overwriting
// *            the diagonal elements of A; the elements below the diagonal
// *            with the array TAU, represent the  orthogonal matrix Q as a
// *            product of elementary reflectors.
// *          See Further Details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= (1,N).
// *
// *  E       (output) DOUBLE PRECISION array, dimension (N-1)
// *          If UPLO = 'U', E(n-nb:n-1) contains the superdiagonal
// *          elements of the last NB columns of the reduced matrix;
// *          if UPLO = 'L', E(1:nb) contains the subdiagonal elements of
// *          the first NB columns of the reduced matrix.
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (N-1)
// *          The scalar factors of the elementary reflectors, stored in
// *          TAU(n-nb:n-1) if UPLO = 'U', and in TAU(1:nb) if UPLO = 'L'.
// *          See Further Details.
// *
// *  W       (output) DOUBLE PRECISION array, dimension (LDW,NB)
// *          The n-by-nb matrix W required to update the unreduced part
// *          of A.
// *
// *  LDW     (input) INTEGER
// *          The leading dimension of the array W. LDW >= max(1,N).
// *
// *  Further Details
// *  ===============
// *
// *  If UPLO = 'U', the matrix Q is represented as a product of elementary
// *  reflectors
// *
// *     Q = H(n) H(n-1) . . . H(n-nb+1).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(i:n) = 0 and v(i-1) = 1; v(1:i-1) is stored on exit in A(1:i-1,i),
// *  and tau in TAU(i-1).
// *
// *  If UPLO = 'L', the matrix Q is represented as a product of elementary
// *  reflectors
// *
// *     Q = H(1) H(2) . . . H(nb).
// *
// *  Each H(i) has the form
// *
// *     H(i) = I - tau * v * v'
// *
// *  where tau is a real scalar, and v is a real vector with
// *  v(1:i) = 0 and v(i+1) = 1; v(i+1:n) is stored on exit in A(i+1:n,i),
// *  and tau in TAU(i).
// *
// *  The elements of the vectors v together form the n-by-nb matrix V
// *  which is needed, with W, to apply the transformation to the unreduced
// *  part of the matrix, using a symmetric rank-2k update of the form:
// *  A := A - V*W' - W*V'.
// *
// *  The contents of A on exit are illustrated by the following examples
// *  with n = 5 and nb = 2:
// *
// *  if UPLO = 'U':                       if UPLO = 'L':
// *
// *    (  a   a   a   v4  v5 )              (  d                  )
// *    (      a   a   v4  v5 )              (  1   d              )
// *    (          a   1   v5 )              (  v1  1   a          )
// *    (              d   1  )              (  v1  v2  a   a      )
// *    (                  d  )              (  v1  v2  a   a   a  )
// *
// *  where d denotes a diagonal element of the reduced matrix, a denotes
// *  an element of the original matrix that is unchanged, and vi denotes
// *  an element of the vector defining H(i).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double half= 0.5e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int iw= 0;
static double alpha= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dlatrd (String uplo,
int n,
int nb,
double [] a, int _a_offset,
int lda,
double [] e, int _e_offset,
double [] tau, int _tau_offset,
double [] w, int _w_offset,
int ldw)  {

if (n <= 0)  
    Dummy.go_to("Dlatrd",999999);
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *        Reduce last NB columns of upper triangle
// *
{
int _i_inc = -1;
forloop10:
for (i = n; i >= n-nb+1; i += _i_inc) {
iw = i-n+nb;
if (i < n)  {
    // *
// *              Update A(1:i,i)
// *
Dgemv.dgemv("No transpose",i,n-i,-one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,w,(i)- 1+(iw+1- 1)*ldw+ _w_offset,ldw,one,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
Dgemv.dgemv("No transpose",i,n-i,-one,w,(1)- 1+(iw+1- 1)*ldw+ _w_offset,ldw,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,one,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
}              // Close if()
if (i > 1)  {
    // *
// *              Generate elementary reflector H(i) to annihilate
// *              A(1:i-2,i)
// *
dlarfg_adapter(i-1,a,(i-1)- 1+(i- 1)*lda+ _a_offset,a,(1)- 1+(i- 1)*lda+ _a_offset,1,tau,(i-1)- 1+ _tau_offset);
e[(i-1)- 1+ _e_offset] = a[(i-1)- 1+(i- 1)*lda+ _a_offset];
a[(i-1)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Compute W(1:i-1,i)
// *
Dsymv.dsymv("Upper",i-1,one,a,_a_offset,lda,a,(1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(1)- 1+(iw- 1)*ldw+ _w_offset,1);
if (i < n)  {
    Dgemv.dgemv("Transpose",i-1,n-i,one,w,(1)- 1+(iw+1- 1)*ldw+ _w_offset,ldw,a,(1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(i+1)- 1+(iw- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("No transpose",i-1,n-i,-one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,w,(i+1)- 1+(iw- 1)*ldw+ _w_offset,1,one,w,(1)- 1+(iw- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("Transpose",i-1,n-i,one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(i+1)- 1+(iw- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("No transpose",i-1,n-i,-one,w,(1)- 1+(iw+1- 1)*ldw+ _w_offset,ldw,w,(i+1)- 1+(iw- 1)*ldw+ _w_offset,1,one,w,(1)- 1+(iw- 1)*ldw+ _w_offset,1);
}              // Close if()
Dscal.dscal(i-1,tau[(i-1)- 1+ _tau_offset],w,(1)- 1+(iw- 1)*ldw+ _w_offset,1);
alpha = -half*tau[(i-1)- 1+ _tau_offset]*Ddot.ddot(i-1,w,(1)- 1+(iw- 1)*ldw+ _w_offset,1,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
Daxpy.daxpy(i-1,alpha,a,(1)- 1+(i- 1)*lda+ _a_offset,1,w,(1)- 1+(iw- 1)*ldw+ _w_offset,1);
}              // Close if()
// *
Dummy.label("Dlatrd",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Reduce first NB columns of lower triangle
// *
{
forloop20:
for (i = 1; i <= nb; i++) {
// *
// *           Update A(i:n,i)
// *
Dgemv.dgemv("No transpose",n-i+1,i-1,-one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,w,(i)- 1+(1- 1)*ldw+ _w_offset,ldw,one,a,(i)- 1+(i- 1)*lda+ _a_offset,1);
Dgemv.dgemv("No transpose",n-i+1,i-1,-one,w,(i)- 1+(1- 1)*ldw+ _w_offset,ldw,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(i- 1)*lda+ _a_offset,1);
if (i < n)  {
    // *
// *              Generate elementary reflector H(i) to annihilate
// *              A(i+2:n,i)
// *
dlarfg_adapter(n-i,a,(i+1)- 1+(i- 1)*lda+ _a_offset,a,(int)((Math.min(i+2, n) )- 1+(i- 1)*lda+ _a_offset),1,tau,(i)- 1+ _tau_offset);
e[(i)- 1+ _e_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
a[(i+1)- 1+(i- 1)*lda+ _a_offset] = one;
// *
// *              Compute W(i+1:n,i)
// *
Dsymv.dsymv("Lower",n-i,one,a,(i+1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("Transpose",n-i,i-1,one,w,(i+1)- 1+(1- 1)*ldw+ _w_offset,ldw,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(1)- 1+(i- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("No transpose",n-i,i-1,-one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,w,(1)- 1+(i- 1)*ldw+ _w_offset,1,one,w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("Transpose",n-i,i-1,one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,zero,w,(1)- 1+(i- 1)*ldw+ _w_offset,1);
Dgemv.dgemv("No transpose",n-i,i-1,-one,w,(i+1)- 1+(1- 1)*ldw+ _w_offset,ldw,w,(1)- 1+(i- 1)*ldw+ _w_offset,1,one,w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1);
Dscal.dscal(n-i,tau[(i)- 1+ _tau_offset],w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1);
alpha = -half*tau[(i)- 1+ _tau_offset]*Ddot.ddot(n-i,w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1);
Daxpy.daxpy(n-i,alpha,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,w,(i+1)- 1+(i- 1)*ldw+ _w_offset,1);
}              // Close if()
// *
Dummy.label("Dlatrd",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dummy.go_to("Dlatrd",999999);
// *
// *     End of DLATRD
// *
Dummy.label("Dlatrd",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

} // End class.
