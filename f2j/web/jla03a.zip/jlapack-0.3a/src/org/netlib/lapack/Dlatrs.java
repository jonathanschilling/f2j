/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlatrs {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     June 30, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATRS solves one of the triangular systems
// *
// *     A *x = s*b  or  A'*x = s*b
// *
// *  with scaling to prevent overflow.  Here A is an upper or lower
// *  triangular matrix, A' denotes the transpose of A, x and b are
// *  n-element vectors, and s is a scaling factor, usually less than
// *  or equal to 1, chosen so that the components of x will be less than
// *  the overflow threshold.  If the unscaled problem will not cause
// *  overflow, the Level 2 BLAS routine DTRSV is called.  If the matrix A
// *  is singular (A(j,j) = 0 for some j), then s is set to 0 and a
// *  non-trivial solution to A*x = 0 is returned.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation applied to A.
// *          = 'N':  Solve A * x = s*b  (No transpose)
// *          = 'T':  Solve A'* x = s*b  (Transpose)
// *          = 'C':  Solve A'* x = s*b  (Conjugate transpose = Transpose)
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  NORMIN  (input) CHARACTER*1
// *          Specifies whether CNORM has been set or not.
// *          = 'Y':  CNORM contains the column norms on entry
// *          = 'N':  CNORM is not set on entry.  On exit, the norms will
// *                  be computed and stored in CNORM.
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The triangular matrix A.  If UPLO = 'U', the leading n by n
// *          upper triangular part of the array A contains the upper
// *          triangular matrix, and the strictly lower triangular part of
// *          A is not referenced.  If UPLO = 'L', the leading n by n lower
// *          triangular part of the array A contains the lower triangular
// *          matrix, and the strictly upper triangular part of A is not
// *          referenced.  If DIAG = 'U', the diagonal elements of A are
// *          also not referenced and are assumed to be 1.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max (1,N).
// *
// *  X       (input/output) DOUBLE PRECISION array, dimension (N)
// *          On entry, the right hand side b of the triangular system.
// *          On exit, X is overwritten by the solution vector x.
// *
// *  SCALE   (output) DOUBLE PRECISION
// *          The scaling factor s for the triangular system
// *             A * x = s*b  or  A'* x = s*b.
// *          If SCALE = 0, the matrix A is singular or badly scaled, and
// *          the vector x is an exact or approximate solution to A*x = 0.
// *
// *  CNORM   (input or output) DOUBLE PRECISION array, dimension (N)
// *
// *          If NORMIN = 'Y', CNORM is an input argument and CNORM(j)
// *          contains the norm of the off-diagonal part of the j-th column
// *          of A.  If TRANS = 'N', CNORM(j) must be greater than or equal
// *          to the infinity-norm, and if TRANS = 'T' or 'C', CNORM(j)
// *          must be greater than or equal to the 1-norm.
// *
// *          If NORMIN = 'N', CNORM is an output argument and CNORM(j)
// *          returns the 1-norm of the offdiagonal part of the j-th column
// *          of A.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -k, the k-th argument had an illegal value
// *
// *  Further Details
// *  ======= =======
// *
// *  A rough bound on x is computed; if that is less than overflow, DTRSV
// *  is called, otherwise, specific code is used which checks for possible
// *  overflow or divide-by-zero at every operation.
// *
// *  A columnwise scheme is used for solving A*x = b.  The basic algorithm
// *  if A is lower triangular is
// *
// *       x[1:n] := b[1:n]
// *       for j = 1, ..., n
// *            x(j) := x(j) / A(j,j)
// *            x[j+1:n] := x[j+1:n] - x(j) * A[j+1:n,j]
// *       end
// *
// *  Define bounds on the components of x after j iterations of the loop:
// *     M(j) = bound on x[1:j]
// *     G(j) = bound on x[j+1:n]
// *  Initially, let M(0) = 0 and G(0) = max{x(i), i=1,...,n}.
// *
// *  Then for iteration j+1 we have
// *     M(j+1) <= G(j) / | A(j+1,j+1) |
// *     G(j+1) <= G(j) + M(j+1) * | A[j+2:n,j+1] |
// *            <= G(j) ( 1 + CNORM(j+1) / | A(j+1,j+1) | )
// *
// *  where CNORM(j+1) is greater than or equal to the infinity-norm of
// *  column j+1 of A, not counting the diagonal.  Hence
// *
// *     G(j) <= G(0) product ( 1 + CNORM(i) / | A(i,i) | )
// *                  1<=i<=j
// *  and
// *
// *     |x(j)| <= ( G(0) / |A(j,j)| ) product ( 1 + CNORM(i) / |A(i,i)| )
// *                                   1<=i< j
// *
// *  Since |x(j)| <= M(j), we use the Level 2 BLAS routine DTRSV if the
// *  reciprocal of the largest M(j), j=1,..,n, is larger than
// *  max(underflow, 1/overflow).
// *
// *  The bound on x(j) is also used to determine when a step in the
// *  columnwise method can be performed without fear of overflow.  If
// *  the computed bound is greater than a large constant, x is scaled to
// *  prevent overflow, but if the bound overflows, x is set to 0, x(j) to
// *  1, and scale to 0, and a non-trivial solution to A*x = 0 is found.
// *
// *  Similarly, a row-wise scheme is used to solve A'*x = b.  The basic
// *  algorithm for A upper triangular is
// *
// *       for j = 1, ..., n
// *            x(j) := ( b(j) - A[1:j-1,j]' * x[1:j-1] ) / A(j,j)
// *       end
// *
// *  We simultaneously compute two bounds
// *       G(j) = bound on ( b(i) - A[1:i-1,i]' * x[1:i-1] ), 1<=i<=j
// *       M(j) = bound on x(i), 1<=i<=j
// *
// *  The initial values are G(0) = 0, M(0) = max{b(i), i=1,..,n}, and we
// *  add the constraint G(j) >= G(j-1) and M(j) >= M(j-1) for j >= 1.
// *  Then the bound on x(j) is
// *
// *       M(j) <= M(j-1) * ( 1 + CNORM(j) ) / | A(j,j) |
// *
// *            <= M(0) * product ( ( 1 + CNORM(i) ) / |A(i,i)| )
// *                      1<=i<=j
// *
// *  and we can safely call DTRSV if 1/M(n) and 1/G(n) are both greater
// *  than max(underflow, 1/overflow).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double half= 0.5e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static boolean nounit= false;
static boolean upper= false;
static int i= 0;
static int imax= 0;
static int j= 0;
static int jfirst= 0;
static int jinc= 0;
static int jlast= 0;
static double bignum= 0.0;
static double grow= 0.0;
static double rec= 0.0;
static double smlnum= 0.0;
static double sumj= 0.0;
static double tjj= 0.0;
static double tjjs= 0.0;
static double tmax= 0.0;
static double tscal= 0.0;
static double uscal= 0.0;
static double xbnd= 0.0;
static double xj= 0.0;
static double xmax= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlatrs (String uplo,
String trans,
String diag,
String normin,
int n,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
doubleW scale,
double [] cnorm, int _cnorm_offset,
intW info)  {

info.val = 0;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
nounit = (diag.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
// *
// *     Test the input parameters.
// *
if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (!nounit && !(diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    info.val = -3;
}              // Close else if()
else if (!(normin.toLowerCase().charAt(0) == "Y".toLowerCase().charAt(0)) && !(normin.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    info.val = -4;
}              // Close else if()
else if (n < 0)  {
    info.val = -5;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLATRS",-info.val);
Dummy.go_to("Dlatrs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlatrs",999999);
// *
// *     Determine machine dependent parameters to control overflow.
// *
smlnum = Dlamch.dlamch("Safe minimum")/Dlamch.dlamch("Precision");
bignum = one/smlnum;
scale.val = one;
// *
if ((normin.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    // *
// *        Compute the 1-norm of each column, not including the diagonal.
// *
if (upper)  {
    // *
// *           A is upper triangular.
// *
{
forloop10:
for (j = 1; j <= n; j++) {
cnorm[(j)- 1+ _cnorm_offset] = Dasum.dasum(j-1,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatrs",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           A is lower triangular.
// *
{
forloop20:
for (j = 1; j <= n-1; j++) {
cnorm[(j)- 1+ _cnorm_offset] = Dasum.dasum(n-j,a,(j+1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatrs",20);
}              //  Close for() loop. 
}
cnorm[(n)- 1+ _cnorm_offset] = zero;
}              //  Close else.
}              // Close if()
// *
// *     Scale the column norms by TSCAL if the maximum element in CNORM is
// *     greater than BIGNUM.
// *
imax = Idamax.idamax(n,cnorm,_cnorm_offset,1);
tmax = cnorm[(imax)- 1+ _cnorm_offset];
if (tmax <= bignum)  {
    tscal = one;
}              // Close if()
else  {
  tscal = one/(smlnum*tmax);
Dscal.dscal(n,tscal,cnorm,_cnorm_offset,1);
}              //  Close else.
// *
// *     Compute a bound on the computed solution vector to see if the
// *     Level 2 BLAS routine DTRSV can be used.
// *
j = Idamax.idamax(n,x,_x_offset,1);
xmax = Math.abs(x[(j)- 1+ _x_offset]);
xbnd = xmax;
if (notran)  {
    // *
// *        Compute the growth in A * x = b.
// *
if (upper)  {
    jfirst = n;
jlast = 1;
jinc = -1;
}              // Close if()
else  {
  jfirst = 1;
jlast = n;
jinc = 1;
}              //  Close else.
// *
if (tscal != one)  {
    grow = zero;
Dummy.go_to("Dlatrs",50);
}              // Close if()
// *
if (nounit)  {
    // *
// *           A is non-unit triangular.
// *
// *           Compute GROW = 1/G(j) and XBND = 1/M(j).
// *           Initially, G(0) = max{x(i), i=1,...,n}.
// *
grow = one/Math.max(xbnd, smlnum) ;
xbnd = grow;
{
int _j_inc = jinc;
forloop30:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Exit the loop if the growth factor is too small.
// *
if (grow <= smlnum)  
    Dummy.go_to("Dlatrs",50);
// *
// *              M(j) = G(j-1) / abs(A(j,j))
// *
tjj = Math.abs(a[(j)- 1+(j- 1)*lda+ _a_offset]);
xbnd = Math.min(xbnd, Math.min(one, tjj) *grow) ;
if (tjj+cnorm[(j)- 1+ _cnorm_offset] >= smlnum)  {
    // *
// *                 G(j) = G(j-1)*( 1 + CNORM(j) / abs(A(j,j)) )
// *
grow = grow*(tjj/(tjj+cnorm[(j)- 1+ _cnorm_offset]));
}              // Close if()
else  {
  // *
// *                 G(j) could overflow, set GROW to 0.
// *
grow = zero;
}              //  Close else.
Dummy.label("Dlatrs",30);
}              //  Close for() loop. 
}
grow = xbnd;
}              // Close if()
else  {
  // *
// *           A is unit triangular.
// *
// *           Compute GROW = 1/G(j), where G(0) = max{x(i), i=1,...,n}.
// *
grow = Math.min(one, one/Math.max(xbnd, smlnum) ) ;
{
int _j_inc = jinc;
forloop40:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Exit the loop if the growth factor is too small.
// *
if (grow <= smlnum)  
    Dummy.go_to("Dlatrs",50);
// *
// *              G(j) = G(j-1)*( 1 + CNORM(j) )
// *
grow = grow*(one/(one+cnorm[(j)- 1+ _cnorm_offset]));
Dummy.label("Dlatrs",40);
}              //  Close for() loop. 
}
}              //  Close else.
label50:
   Dummy.label("Dlatrs",50);
// *
}              // Close if()
else  {
  // *
// *        Compute the growth in A' * x = b.
// *
if (upper)  {
    jfirst = 1;
jlast = n;
jinc = 1;
}              // Close if()
else  {
  jfirst = n;
jlast = 1;
jinc = -1;
}              //  Close else.
// *
if (tscal != one)  {
    grow = zero;
Dummy.go_to("Dlatrs",80);
}              // Close if()
// *
if (nounit)  {
    // *
// *           A is non-unit triangular.
// *
// *           Compute GROW = 1/G(j) and XBND = 1/M(j).
// *           Initially, M(0) = max{x(i), i=1,...,n}.
// *
grow = one/Math.max(xbnd, smlnum) ;
xbnd = grow;
{
int _j_inc = jinc;
forloop60:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Exit the loop if the growth factor is too small.
// *
if (grow <= smlnum)  
    Dummy.go_to("Dlatrs",80);
// *
// *              G(j) = max( G(j-1), M(j-1)*( 1 + CNORM(j) ) )
// *
xj = one+cnorm[(j)- 1+ _cnorm_offset];
grow = Math.min(grow, xbnd/xj) ;
// *
// *              M(j) = M(j-1)*( 1 + CNORM(j) ) / abs(A(j,j))
// *
tjj = Math.abs(a[(j)- 1+(j- 1)*lda+ _a_offset]);
if (xj > tjj)  
    xbnd = xbnd*(tjj/xj);
Dummy.label("Dlatrs",60);
}              //  Close for() loop. 
}
grow = Math.min(grow, xbnd) ;
}              // Close if()
else  {
  // *
// *           A is unit triangular.
// *
// *           Compute GROW = 1/G(j), where G(0) = max{x(i), i=1,...,n}.
// *
grow = Math.min(one, one/Math.max(xbnd, smlnum) ) ;
{
int _j_inc = jinc;
forloop70:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Exit the loop if the growth factor is too small.
// *
if (grow <= smlnum)  
    Dummy.go_to("Dlatrs",80);
// *
// *              G(j) = ( 1 + CNORM(j) )*G(j-1)
// *
xj = one+cnorm[(j)- 1+ _cnorm_offset];
grow = grow/xj;
Dummy.label("Dlatrs",70);
}              //  Close for() loop. 
}
}              //  Close else.
label80:
   Dummy.label("Dlatrs",80);
}              //  Close else.
// *
if ((grow*tscal) > smlnum)  {
    // *
// *        Use the Level 2 BLAS solve if the reciprocal of the bound on
// *        elements of X is not too small.
// *
Dtrsv.dtrsv(uplo,trans,diag,n,a,_a_offset,lda,x,_x_offset,1);
}              // Close if()
else  {
  // *
// *        Use a Level 1 BLAS solve, scaling intermediate results.
// *
if (xmax > bignum)  {
    // *
// *           Scale X so that its components are less than or equal to
// *           BIGNUM in absolute value.
// *
scale.val = bignum/xmax;
Dscal.dscal(n,scale.val,x,_x_offset,1);
xmax = bignum;
}              // Close if()
// *
if (notran)  {
    // *
// *           Solve A * x = b
// *
{
int _j_inc = jinc;
forloop110:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Compute x(j) = b(j) / A(j,j), scaling x if necessary.
// *
xj = Math.abs(x[(j)- 1+ _x_offset]);
if (nounit)  {
    tjjs = a[(j)- 1+(j- 1)*lda+ _a_offset]*tscal;
}              // Close if()
else  {
  tjjs = tscal;
if (tscal == one)  
    Dummy.go_to("Dlatrs",100);
}              //  Close else.
tjj = Math.abs(tjjs);
if (tjj > smlnum)  {
    // *
// *                    abs(A(j,j)) > SMLNUM:
// *
if (tjj < one)  {
    if (xj > tjj*bignum)  {
    // *
// *                          Scale x by 1/b(j).
// *
rec = one/xj;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]/tjjs;
xj = Math.abs(x[(j)- 1+ _x_offset]);
}              // Close if()
else if (tjj > zero)  {
    // *
// *                    0 < abs(A(j,j)) <= SMLNUM:
// *
if (xj > tjj*bignum)  {
    // *
// *                       Scale x by (1/abs(x(j)))*abs(A(j,j))*BIGNUM
// *                       to avoid overflow when dividing by A(j,j).
// *
rec = (tjj*bignum)/xj;
if (cnorm[(j)- 1+ _cnorm_offset] > one)  {
    // *
// *                          Scale by 1/CNORM(j) to avoid overflow when
// *                          multiplying x(j) times column j.
// *
rec = rec/cnorm[(j)- 1+ _cnorm_offset];
}              // Close if()
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]/tjjs;
xj = Math.abs(x[(j)- 1+ _x_offset]);
}              // Close else if()
else  {
  // *
// *                    A(j,j) = 0:  Set x(1:n) = 0, x(j) = 1, and
// *                    scale = 0, and compute a solution to A*x = 0.
// *
{
forloop90:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = zero;
Dummy.label("Dlatrs",90);
}              //  Close for() loop. 
}
x[(j)- 1+ _x_offset] = one;
xj = one;
scale.val = zero;
xmax = zero;
}              //  Close else.
label100:
   Dummy.label("Dlatrs",100);
// *
// *              Scale x if necessary to avoid overflow when adding a
// *              multiple of column j of A.
// *
if (xj > one)  {
    rec = one/xj;
if (cnorm[(j)- 1+ _cnorm_offset] > (bignum-xmax)*rec)  {
    // *
// *                    Scale x by 1/(2*abs(x(j))).
// *
rec = rec*half;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
}              // Close if()
}              // Close if()
else if (xj*cnorm[(j)- 1+ _cnorm_offset] > (bignum-xmax))  {
    // *
// *                 Scale x by 1/2.
// *
Dscal.dscal(n,half,x,_x_offset,1);
scale.val = scale.val*half;
}              // Close else if()
// *
if (upper)  {
    if (j > 1)  {
    // *
// *                    Compute the update
// *                       x(1:j-1) := x(1:j-1) - x(j) * A(1:j-1,j)
// *
Daxpy.daxpy(j-1,-x[(j)- 1+ _x_offset]*tscal,a,(1)- 1+(j- 1)*lda+ _a_offset,1,x,_x_offset,1);
i = Idamax.idamax(j-1,x,_x_offset,1);
xmax = Math.abs(x[(i)- 1+ _x_offset]);
}              // Close if()
}              // Close if()
else  {
  if (j < n)  {
    // *
// *                    Compute the update
// *                       x(j+1:n) := x(j+1:n) - x(j) * A(j+1:n,j)
// *
Daxpy.daxpy(n-j,-x[(j)- 1+ _x_offset]*tscal,a,(j+1)- 1+(j- 1)*lda+ _a_offset,1,x,(j+1)- 1+ _x_offset,1);
i = j+Idamax.idamax(n-j,x,(j+1)- 1+ _x_offset,1);
xmax = Math.abs(x[(i)- 1+ _x_offset]);
}              // Close if()
}              //  Close else.
Dummy.label("Dlatrs",110);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *           Solve A' * x = b
// *
{
int _j_inc = jinc;
forloop160:
for (j = jfirst; (_j_inc < 0) ? j >= jlast : j <= jlast; j += _j_inc) {
// *
// *              Compute x(j) = b(j) - sum A(k,j)*x(k).
// *                                    k<>j
// *
xj = Math.abs(x[(j)- 1+ _x_offset]);
uscal = tscal;
rec = one/Math.max(xmax, one) ;
if (cnorm[(j)- 1+ _cnorm_offset] > (bignum-xj)*rec)  {
    // *
// *                 If x(j) could overflow, scale x by 1/(2*XMAX).
// *
rec = rec*half;
if (nounit)  {
    tjjs = a[(j)- 1+(j- 1)*lda+ _a_offset]*tscal;
}              // Close if()
else  {
  tjjs = tscal;
}              //  Close else.
tjj = Math.abs(tjjs);
if (tjj > one)  {
    // *
// *                       Divide by A(j,j) when scaling x if A(j,j) > 1.
// *
rec = Math.min(one, rec*tjj) ;
uscal = uscal/tjjs;
}              // Close if()
if (rec < one)  {
    Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
// *
sumj = zero;
if (uscal == one)  {
    // *
// *                 If the scaling needed for A in the dot product is 1,
// *                 call DDOT to perform the dot product.
// *
if (upper)  {
    sumj = Ddot.ddot(j-1,a,(1)- 1+(j- 1)*lda+ _a_offset,1,x,_x_offset,1);
}              // Close if()
else if (j < n)  {
    sumj = Ddot.ddot(n-j,a,(j+1)- 1+(j- 1)*lda+ _a_offset,1,x,(j+1)- 1+ _x_offset,1);
}              // Close else if()
}              // Close if()
else  {
  // *
// *                 Otherwise, use in-line code for the dot product.
// *
if (upper)  {
    {
forloop120:
for (i = 1; i <= j-1; i++) {
sumj = sumj+(a[(i)- 1+(j- 1)*lda+ _a_offset]*uscal)*x[(i)- 1+ _x_offset];
Dummy.label("Dlatrs",120);
}              //  Close for() loop. 
}
}              // Close if()
else if (j < n)  {
    {
forloop130:
for (i = j+1; i <= n; i++) {
sumj = sumj+(a[(i)- 1+(j- 1)*lda+ _a_offset]*uscal)*x[(i)- 1+ _x_offset];
Dummy.label("Dlatrs",130);
}              //  Close for() loop. 
}
}              // Close else if()
}              //  Close else.
// *
if (uscal == tscal)  {
    // *
// *                 Compute x(j) := ( x(j) - sumj ) / A(j,j) if 1/A(j,j)
// *                 was not used to scale the dotproduct.
// *
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]-sumj;
xj = Math.abs(x[(j)- 1+ _x_offset]);
if (nounit)  {
    tjjs = a[(j)- 1+(j- 1)*lda+ _a_offset]*tscal;
}              // Close if()
else  {
  tjjs = tscal;
if (tscal == one)  
    Dummy.go_to("Dlatrs",150);
}              //  Close else.
// *
// *                    Compute x(j) = x(j) / A(j,j), scaling if necessary.
// *
tjj = Math.abs(tjjs);
if (tjj > smlnum)  {
    // *
// *                       abs(A(j,j)) > SMLNUM:
// *
if (tjj < one)  {
    if (xj > tjj*bignum)  {
    // *
// *                             Scale X by 1/abs(x(j)).
// *
rec = one/xj;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
}              // Close if()
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]/tjjs;
}              // Close if()
else if (tjj > zero)  {
    // *
// *                       0 < abs(A(j,j)) <= SMLNUM:
// *
if (xj > tjj*bignum)  {
    // *
// *                          Scale x by (1/abs(x(j)))*abs(A(j,j))*BIGNUM.
// *
rec = (tjj*bignum)/xj;
Dscal.dscal(n,rec,x,_x_offset,1);
scale.val = scale.val*rec;
xmax = xmax*rec;
}              // Close if()
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]/tjjs;
}              // Close else if()
else  {
  // *
// *                       A(j,j) = 0:  Set x(1:n) = 0, x(j) = 1, and
// *                       scale = 0, and compute a solution to A'*x = 0.
// *
{
forloop140:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = zero;
Dummy.label("Dlatrs",140);
}              //  Close for() loop. 
}
x[(j)- 1+ _x_offset] = one;
scale.val = zero;
xmax = zero;
}              //  Close else.
label150:
   Dummy.label("Dlatrs",150);
}              // Close if()
else  {
  // *
// *                 Compute x(j) := x(j) / A(j,j)  - sumj if the dot
// *                 product has already been divided by 1/A(j,j).
// *
x[(j)- 1+ _x_offset] = x[(j)- 1+ _x_offset]/tjjs-sumj;
}              //  Close else.
xmax = Math.max(xmax, Math.abs(x[(j)- 1+ _x_offset])) ;
Dummy.label("Dlatrs",160);
}              //  Close for() loop. 
}
}              //  Close else.
scale.val = scale.val/tscal;
}              //  Close else.
// *
// *     Scale the column norms by 1/TSCAL for return.
// *
if (tscal != one)  {
    Dscal.dscal(n,one/tscal,cnorm,_cnorm_offset,1);
}              // Close if()
// *
Dummy.go_to("Dlatrs",999999);
// *
// *     End of DLATRS
// *
Dummy.label("Dlatrs",999999);
return;
   }
} // End class.
