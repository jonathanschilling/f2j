/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlauu2 {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAUU2 computes the product U * U' or L' * L, where the triangular
// *  factor U or L is stored in the upper or lower triangular part of
// *  the array A.
// *
// *  If UPLO = 'U' or 'u' then the upper triangle of the result is stored,
// *  overwriting the factor U in A.
// *  If UPLO = 'L' or 'l' then the lower triangle of the result is stored,
// *  overwriting the factor L in A.
// *
// *  This is the unblocked form of the algorithm, calling Level 2 BLAS.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the triangular factor stored in the array A
// *          is upper or lower triangular:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The order of the triangular factor U or L.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the triangular factor U or L.
// *          On exit, if UPLO = 'U', the upper triangle of A is
// *          overwritten with the upper triangle of the product U * U';
// *          if UPLO = 'L', the lower triangle of A is overwritten with
// *          the lower triangle of the product L' * L.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static int i= 0;
static double aii= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlauu2 (String uplo,
int n,
double [] a, int _a_offset,
int lda,
intW info)  {

info.val = 0;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAUU2",-info.val);
Dummy.go_to("Dlauu2",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlauu2",999999);
// *
if (upper)  {
    // *
// *        Compute the product U * U'.
// *
{
forloop10:
for (i = 1; i <= n; i++) {
aii = a[(i)- 1+(i- 1)*lda+ _a_offset];
if (i < n)  {
    a[(i)- 1+(i- 1)*lda+ _a_offset] = Ddot.ddot(n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
Dgemv.dgemv("No transpose",i-1,n-i,one,a,(1)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda,aii,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
}              // Close if()
else  {
  Dscal.dscal(i,aii,a,(1)- 1+(i- 1)*lda+ _a_offset,1);
}              //  Close else.
Dummy.label("Dlauu2",10);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *        Compute the product L' * L.
// *
{
forloop20:
for (i = 1; i <= n; i++) {
aii = a[(i)- 1+(i- 1)*lda+ _a_offset];
if (i < n)  {
    a[(i)- 1+(i- 1)*lda+ _a_offset] = Ddot.ddot(n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,1,a,(i)- 1+(i- 1)*lda+ _a_offset,1);
Dgemv.dgemv("Transpose",n-i,i-1,one,a,(i+1)- 1+(1- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(i- 1)*lda+ _a_offset,1,aii,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
}              // Close if()
else  {
  Dscal.dscal(i,aii,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
}              //  Close else.
Dummy.label("Dlauu2",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dummy.go_to("Dlauu2",999999);
// *
// *     End of DLAUU2
// *
Dummy.label("Dlauu2",999999);
return;
   }
} // End class.
