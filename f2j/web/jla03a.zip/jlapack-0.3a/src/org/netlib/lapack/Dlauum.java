/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlauum {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAUUM computes the product U * U' or L' * L, where the triangular
// *  factor U or L is stored in the upper or lower triangular part of
// *  the array A.
// *
// *  If UPLO = 'U' or 'u' then the upper triangle of the result is stored,
// *  overwriting the factor U in A.
// *  If UPLO = 'L' or 'l' then the lower triangle of the result is stored,
// *  overwriting the factor L in A.
// *
// *  This is the blocked form of the algorithm, calling Level 3 BLAS.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the triangular factor stored in the array A
// *          is upper or lower triangular:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The order of the triangular factor U or L.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the triangular factor U or L.
// *          On exit, if UPLO = 'U', the upper triangle of A is
// *          overwritten with the upper triangle of the product U * U';
// *          if UPLO = 'L', the lower triangle of A is overwritten with
// *          the lower triangle of the product L' * L.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static int i= 0;
static int ib= 0;
static int nb= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlauum (String uplo,
int n,
double [] a, int _a_offset,
int lda,
intW info)  {

info.val = 0;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAUUM",-info.val);
Dummy.go_to("Dlauum",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlauum",999999);
// *
// *     Determine the block size for this environment.
// *
nb = Ilaenv.ilaenv(1,"DLAUUM",uplo,n,-1,-1,-1);
// *
if (nb <= 1 || nb >= n)  {
    // *
// *        Use unblocked code
// *
Dlauu2.dlauu2(uplo,n,a,_a_offset,lda,info);
}              // Close if()
else  {
  // *
// *        Use blocked code
// *
if (upper)  {
    // *
// *           Compute the product U * U'.
// *
{
int _i_inc = nb;
forloop10:
for (i = 1; (_i_inc < 0) ? i >= n : i <= n; i += _i_inc) {
ib = (int)(Math.min(nb, n-i+1) );
Dtrmm.dtrmm("Right","Upper","Transpose","Non-unit",i-1,ib,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,a,(1)- 1+(i- 1)*lda+ _a_offset,lda);
Dlauu2.dlauu2("Upper",ib,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,info);
if (i+ib <= n)  {
    Dgemm.dgemm("No transpose","Transpose",i-1,ib,n-i-ib+1,one,a,(1)- 1+(i+ib- 1)*lda+ _a_offset,lda,a,(i)- 1+(i+ib- 1)*lda+ _a_offset,lda,one,a,(1)- 1+(i- 1)*lda+ _a_offset,lda);
Dsyrk.dsyrk("Upper","No transpose",ib,n-i-ib+1,one,a,(i)- 1+(i+ib- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
}              // Close if()
Dummy.label("Dlauum",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Compute the product L' * L.
// *
{
int _i_inc = nb;
forloop20:
for (i = 1; (_i_inc < 0) ? i >= n : i <= n; i += _i_inc) {
ib = (int)(Math.min(nb, n-i+1) );
Dtrmm.dtrmm("Left","Lower","Transpose","Non-unit",ib,i-1,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
Dlauu2.dlauu2("Lower",ib,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,info);
if (i+ib <= n)  {
    Dgemm.dgemm("Transpose","No transpose",ib,i-1,n-i-ib+1,one,a,(i+ib)- 1+(i- 1)*lda+ _a_offset,lda,a,(i+ib)- 1+(1- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
Dsyrk.dsyrk("Lower","Transpose",ib,n-i-ib+1,one,a,(i+ib)- 1+(i- 1)*lda+ _a_offset,lda,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
}              // Close if()
Dummy.label("Dlauum",20);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dlauum",999999);
// *
// *     End of DLAUUM
// *
Dummy.label("Dlauum",999999);
return;
   }
} // End class.
