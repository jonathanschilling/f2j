/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dlavsy {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAVSY  performs one of the matrix-vector operations
// *     x := A*x  or  x := A'*x,
// *  where x is an N element vector and A is one of the factors
// *  from the block U*D*U' or L*D*L' factorization computed by DSYTRF.
// *
// *  If TRANS = 'N', multiplies by U  or U * D  (or L  or L * D)
// *  If TRANS = 'T', multiplies by U' or D * U' (or L' or D * L')
// *  If TRANS = 'C', multiplies by U' or D * U' (or L' or D * L')
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the factor stored in A is upper or lower
// *          triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation to be performed:
// *          = 'N':  x := A*x
// *          = 'T':  x := A'*x
// *          = 'C':  x := A'*x
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the diagonal blocks are unit
// *          matrices.  If the diagonal blocks are assumed to be unit,
// *          then A = U or A = L, otherwise A = U*D or A = L*D.
// *          = 'U':  Diagonal blocks are assumed to be unit matrices.
// *          = 'N':  Diagonal blocks are assumed to be non-unit matrices.
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of vectors
// *          x to be multiplied by A.  NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The block diagonal matrix D and the multipliers used to
// *          obtain the factor U or L as computed by DSYTRF.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DSYTRF.
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, B contains NRHS vectors of length N.
// *          On exit, B is overwritten with the product A * B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean nounit= false;
static int j= 0;
static int k= 0;
static int kp= 0;
static double d11= 0.0;
static double d12= 0.0;
static double d21= 0.0;
static double d22= 0.0;
static double t1= 0.0;
static double t2= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlavsy (String uplo,
String trans,
String diag,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
int [] ipiv, int _ipiv_offset,
double [] b, int _b_offset,
int ldb,
intW info)  {

info.val = 0;
if (!(uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)) && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!(trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) && !(trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (!(diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)) && !(diag.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    info.val = -3;
}              // Close else if()
else if (n < 0)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -6;
}              // Close else if()
else if (ldb < Math.max(1, n) )  {
    info.val = -9;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLAVSY ",-info.val);
Dummy.go_to("Dlavsy",999999);
}              // Close if()
// *
// *     Quick return if possible.
// *
if (n == 0)  
    Dummy.go_to("Dlavsy",999999);
// *
nounit = (diag.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
// *------------------------------------------
// *
// *     Compute  B := A * B  (No transpose)
// *
// *------------------------------------------
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    // *
// *        Compute  B := U*B
// *        where U = P(m)*inv(U(m))* ... *P(1)*inv(U(1))
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *        Loop forward applying the transformations.
// *
k = 1;
label10:
   Dummy.label("Dlavsy",10);
if (k > n)  
    Dummy.go_to("Dlavsy",30);
if (ipiv[(k)- 1+ _ipiv_offset] > 0)  {
    // *
// *              1 x 1 pivot block
// *
// *              Multiply by the diagonal element if forming U * D.
// *
if (nounit)  
    Dscal.dscal(nrhs,a[(k)- 1+(k- 1)*lda+ _a_offset],b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *              Multiply by  P(K) * inv(U(K))  if K > 1.
// *
if (k > 1)  {
    // *
// *                 Apply the transformation.
// *
Dger.dger(k-1,nrhs,one,a,(1)- 1+(k- 1)*lda+ _a_offset,1,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Interchange if P(K) .ne. I.
// *
kp = ipiv[(k)- 1+ _ipiv_offset];
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
k = k+1;
}              // Close if()
else  {
  // *
// *              2 x 2 pivot block
// *
// *              Multiply by the diagonal block if forming U * D.
// *
if (nounit)  {
    d11 = a[(k)- 1+(k- 1)*lda+ _a_offset];
d22 = a[(k+1)- 1+(k+1- 1)*lda+ _a_offset];
d12 = a[(k)- 1+(k+1- 1)*lda+ _a_offset];
d21 = d12;
{
forloop20:
for (j = 1; j <= nrhs; j++) {
t1 = b[(k)- 1+(j- 1)*ldb+ _b_offset];
t2 = b[(k+1)- 1+(j- 1)*ldb+ _b_offset];
b[(k)- 1+(j- 1)*ldb+ _b_offset] = d11*t1+d12*t2;
b[(k+1)- 1+(j- 1)*ldb+ _b_offset] = d21*t1+d22*t2;
Dummy.label("Dlavsy",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Multiply by  P(K) * inv(U(K))  if K > 1.
// *
if (k > 1)  {
    // *
// *                 Apply the transformations.
// *
Dger.dger(k-1,nrhs,one,a,(1)- 1+(k- 1)*lda+ _a_offset,1,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(1)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dger.dger(k-1,nrhs,one,a,(1)- 1+(k+1- 1)*lda+ _a_offset,1,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Interchange if P(K) .ne. I.
// *
kp = (int)(Math.abs(ipiv[(k)- 1+ _ipiv_offset]));
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
k = k+2;
}              //  Close else.
Dummy.go_to("Dlavsy",10);
label30:
   Dummy.label("Dlavsy",30);
// *
// *        Compute  B := L*B
// *        where L = P(1)*inv(L(1))* ... *P(m)*inv(L(m)) .
// *
}              // Close if()
else  {
  // *
// *           Loop backward applying the transformations to B.
// *
k = n;
label40:
   Dummy.label("Dlavsy",40);
if (k < 1)  
    Dummy.go_to("Dlavsy",60);
// *
// *           Test the pivot index.  If greater than zero, a 1 x 1
// *           pivot was used, otherwise a 2 x 2 pivot was used.
// *
if (ipiv[(k)- 1+ _ipiv_offset] > 0)  {
    // *
// *              1 x 1 pivot block:
// *
// *              Multiply by the diagonal element if forming L * D.
// *
if (nounit)  
    Dscal.dscal(nrhs,a[(k)- 1+(k- 1)*lda+ _a_offset],b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *              Multiply by  P(K) * inv(L(K))  if K < N.
// *
if (k != n)  {
    kp = ipiv[(k)- 1+ _ipiv_offset];
// *
// *                 Apply the transformation.
// *
Dger.dger(n-k,nrhs,one,a,(k+1)- 1+(k- 1)*lda+ _a_offset,1,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Interchange if a permutation was applied at the
// *                 K-th step of the factorization.
// *
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
k = k-1;
// *
}              // Close if()
else  {
  // *
// *              2 x 2 pivot block:
// *
// *              Multiply by the diagonal block if forming L * D.
// *
if (nounit)  {
    d11 = a[(k-1)- 1+(k-1- 1)*lda+ _a_offset];
d22 = a[(k)- 1+(k- 1)*lda+ _a_offset];
d21 = a[(k)- 1+(k-1- 1)*lda+ _a_offset];
d12 = d21;
{
forloop50:
for (j = 1; j <= nrhs; j++) {
t1 = b[(k-1)- 1+(j- 1)*ldb+ _b_offset];
t2 = b[(k)- 1+(j- 1)*ldb+ _b_offset];
b[(k-1)- 1+(j- 1)*ldb+ _b_offset] = d11*t1+d12*t2;
b[(k)- 1+(j- 1)*ldb+ _b_offset] = d21*t1+d22*t2;
Dummy.label("Dlavsy",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Multiply by  P(K) * inv(L(K))  if K < N.
// *
if (k != n)  {
    // *
// *                 Apply the transformation.
// *
Dger.dger(n-k,nrhs,one,a,(k+1)- 1+(k- 1)*lda+ _a_offset,1,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dger.dger(n-k,nrhs,one,a,(k+1)- 1+(k-1- 1)*lda+ _a_offset,1,b,(k-1)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Interchange if a permutation was applied at the
// *                 K-th step of the factorization.
// *
kp = (int)(Math.abs(ipiv[(k)- 1+ _ipiv_offset]));
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
k = k-2;
}              //  Close else.
Dummy.go_to("Dlavsy",40);
label60:
   Dummy.label("Dlavsy",60);
}              //  Close else.
// *----------------------------------------
// *
// *     Compute  B := A' * B  (transpose)
// *
// *----------------------------------------
}              // Close if()
else  {
  // *
// *        Form  B := U'*B
// *        where U  = P(m)*inv(U(m))* ... *P(1)*inv(U(1))
// *        and   U' = inv(U'(1))*P(1)* ... *inv(U'(m))*P(m)
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *           Loop backward applying the transformations.
// *
k = n;
label70:
   Dummy.label("Dlavsy",70);
if (k < 1)  
    Dummy.go_to("Dlavsy",90);
// *
// *           1 x 1 pivot block.
// *
if (ipiv[(k)- 1+ _ipiv_offset] > 0)  {
    if (k > 1)  {
    // *
// *                 Interchange if P(K) .ne. I.
// *
kp = ipiv[(k)- 1+ _ipiv_offset];
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Apply the transformation
// *
Dgemv.dgemv("Transpose",k-1,nrhs,one,b,_b_offset,ldb,a,(1)- 1+(k- 1)*lda+ _a_offset,1,one,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
if (nounit)  
    Dscal.dscal(nrhs,a[(k)- 1+(k- 1)*lda+ _a_offset],b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
k = k-1;
// *
// *           2 x 2 pivot block.
// *
}              // Close if()
else  {
  if (k > 2)  {
    // *
// *                 Interchange if P(K) .ne. I.
// *
kp = (int)(Math.abs(ipiv[(k)- 1+ _ipiv_offset]));
if (kp != k-1)  
    Dswap.dswap(nrhs,b,(k-1)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Apply the transformations
// *
Dgemv.dgemv("Transpose",k-2,nrhs,one,b,_b_offset,ldb,a,(1)- 1+(k- 1)*lda+ _a_offset,1,one,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dgemv.dgemv("Transpose",k-2,nrhs,one,b,_b_offset,ldb,a,(1)- 1+(k-1- 1)*lda+ _a_offset,1,one,b,(k-1)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
// *
// *              Multiply by the diagonal block if non-unit.
// *
if (nounit)  {
    d11 = a[(k-1)- 1+(k-1- 1)*lda+ _a_offset];
d22 = a[(k)- 1+(k- 1)*lda+ _a_offset];
d12 = a[(k-1)- 1+(k- 1)*lda+ _a_offset];
d21 = d12;
{
forloop80:
for (j = 1; j <= nrhs; j++) {
t1 = b[(k-1)- 1+(j- 1)*ldb+ _b_offset];
t2 = b[(k)- 1+(j- 1)*ldb+ _b_offset];
b[(k-1)- 1+(j- 1)*ldb+ _b_offset] = d11*t1+d12*t2;
b[(k)- 1+(j- 1)*ldb+ _b_offset] = d21*t1+d22*t2;
Dummy.label("Dlavsy",80);
}              //  Close for() loop. 
}
}              // Close if()
k = k-2;
}              //  Close else.
Dummy.go_to("Dlavsy",70);
label90:
   Dummy.label("Dlavsy",90);
// *
// *        Form  B := L'*B
// *        where L  = P(1)*inv(L(1))* ... *P(m)*inv(L(m))
// *        and   L' = inv(L'(m))*P(m)* ... *inv(L'(1))*P(1)
// *
}              // Close if()
else  {
  // *
// *           Loop forward applying the L-transformations.
// *
k = 1;
label100:
   Dummy.label("Dlavsy",100);
if (k > n)  
    Dummy.go_to("Dlavsy",120);
// *
// *           1 x 1 pivot block
// *
if (ipiv[(k)- 1+ _ipiv_offset] > 0)  {
    if (k < n)  {
    // *
// *                 Interchange if P(K) .ne. I.
// *
kp = ipiv[(k)- 1+ _ipiv_offset];
if (kp != k)  
    Dswap.dswap(nrhs,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Apply the transformation
// *
Dgemv.dgemv("Transpose",n-k,nrhs,one,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb,a,(k+1)- 1+(k- 1)*lda+ _a_offset,1,one,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
if (nounit)  
    Dscal.dscal(nrhs,a[(k)- 1+(k- 1)*lda+ _a_offset],b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
k = k+1;
// *
// *           2 x 2 pivot block.
// *
}              // Close if()
else  {
  if (k < n-1)  {
    // *
// *              Interchange if P(K) .ne. I.
// *
kp = (int)(Math.abs(ipiv[(k)- 1+ _ipiv_offset]));
if (kp != k+1)  
    Dswap.dswap(nrhs,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb,b,(kp)- 1+(1- 1)*ldb+ _b_offset,ldb);
// *
// *                 Apply the transformation
// *
Dgemv.dgemv("Transpose",n-k-1,nrhs,one,b,(k+2)- 1+(1- 1)*ldb+ _b_offset,ldb,a,(k+2)- 1+(k+1- 1)*lda+ _a_offset,1,one,b,(k+1)- 1+(1- 1)*ldb+ _b_offset,ldb);
Dgemv.dgemv("Transpose",n-k-1,nrhs,one,b,(k+2)- 1+(1- 1)*ldb+ _b_offset,ldb,a,(k+2)- 1+(k- 1)*lda+ _a_offset,1,one,b,(k)- 1+(1- 1)*ldb+ _b_offset,ldb);
}              // Close if()
// *
// *              Multiply by the diagonal block if non-unit.
// *
if (nounit)  {
    d11 = a[(k)- 1+(k- 1)*lda+ _a_offset];
d22 = a[(k+1)- 1+(k+1- 1)*lda+ _a_offset];
d21 = a[(k+1)- 1+(k- 1)*lda+ _a_offset];
d12 = d21;
{
forloop110:
for (j = 1; j <= nrhs; j++) {
t1 = b[(k)- 1+(j- 1)*ldb+ _b_offset];
t2 = b[(k+1)- 1+(j- 1)*ldb+ _b_offset];
b[(k)- 1+(j- 1)*ldb+ _b_offset] = d11*t1+d12*t2;
b[(k+1)- 1+(j- 1)*ldb+ _b_offset] = d21*t1+d22*t2;
Dummy.label("Dlavsy",110);
}              //  Close for() loop. 
}
}              // Close if()
k = k+2;
}              //  Close else.
Dummy.go_to("Dlavsy",100);
label120:
   Dummy.label("Dlavsy",120);
}              //  Close else.
// *
}              //  Close else.
Dummy.go_to("Dlavsy",999999);
// *
// *     End of DLAVSY
// *
Dummy.label("Dlavsy",999999);
return;
   }
} // End class.
