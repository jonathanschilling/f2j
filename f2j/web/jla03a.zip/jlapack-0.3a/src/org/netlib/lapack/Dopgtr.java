/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dopgtr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DOPGTR generates a real orthogonal matrix Q which is defined as the
// *  product of n-1 elementary reflectors H(i) of order n, as returned by
// *  DSPTRD using packed storage:
// *
// *  if UPLO = 'U', Q = H(n-1) . . . H(2) H(1),
// *
// *  if UPLO = 'L', Q = H(1) H(2) . . . H(n-1).
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          = 'U': Upper triangular packed storage used in previous
// *                 call to DSPTRD;
// *          = 'L': Lower triangular packed storage used in previous
// *                 call to DSPTRD.
// *
// *  N       (input) INTEGER
// *          The order of the matrix Q. N >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The vectors which define the elementary reflectors, as
// *          returned by DSPTRD.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N-1)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DSPTRD.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDQ,N)
// *          The N-by-N orthogonal matrix Q.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q. LDQ >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N-1)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static int i= 0;
static intW iinfo= new intW(0);
static int ij= 0;
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dopgtr (String uplo,
int n,
double [] ap, int _ap_offset,
double [] tau, int _tau_offset,
double [] q, int _q_offset,
int ldq,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (ldq < Math.max(1, n) )  {
    info.val = -6;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DOPGTR",-info.val);
Dummy.go_to("Dopgtr",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dopgtr",999999);
// *
if (upper)  {
    // *
// *        Q was determined by a call to DSPTRD with UPLO = 'U'
// *
// *        Unpack the vectors which define the elementary reflectors and
// *        set the last row and column of Q equal to those of the unit
// *        matrix
// *
ij = 2;
{
forloop20:
for (j = 1; j <= n-1; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
q[(i)- 1+(j- 1)*ldq+ _q_offset] = ap[(ij)- 1+ _ap_offset];
ij = ij+1;
Dummy.label("Dopgtr",10);
}              //  Close for() loop. 
}
ij = ij+2;
q[(n)- 1+(j- 1)*ldq+ _q_offset] = zero;
Dummy.label("Dopgtr",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n-1; i++) {
q[(i)- 1+(n- 1)*ldq+ _q_offset] = zero;
Dummy.label("Dopgtr",30);
}              //  Close for() loop. 
}
q[(n)- 1+(n- 1)*ldq+ _q_offset] = one;
// *
// *        Generate Q(1:n-1,1:n-1)
// *
Dorg2l.dorg2l(n-1,n-1,n-1,q,_q_offset,ldq,tau,_tau_offset,work,_work_offset,iinfo);
// *
}              // Close if()
else  {
  // *
// *        Q was determined by a call to DSPTRD with UPLO = 'L'.
// *
// *        Unpack the vectors which define the elementary reflectors and
// *        set the first row and column of Q equal to those of the unit
// *        matrix
// *
q[(1)- 1+(1- 1)*ldq+ _q_offset] = one;
{
forloop40:
for (i = 2; i <= n; i++) {
q[(i)- 1+(1- 1)*ldq+ _q_offset] = zero;
Dummy.label("Dopgtr",40);
}              //  Close for() loop. 
}
ij = 3;
{
forloop60:
for (j = 2; j <= n; j++) {
q[(1)- 1+(j- 1)*ldq+ _q_offset] = zero;
{
forloop50:
for (i = j+1; i <= n; i++) {
q[(i)- 1+(j- 1)*ldq+ _q_offset] = ap[(ij)- 1+ _ap_offset];
ij = ij+1;
Dummy.label("Dopgtr",50);
}              //  Close for() loop. 
}
ij = ij+2;
Dummy.label("Dopgtr",60);
}              //  Close for() loop. 
}
if (n > 1)  {
    // *
// *           Generate Q(2:n,2:n)
// *
Dorg2r.dorg2r(n-1,n-1,n-1,q,(2)- 1+(2- 1)*ldq+ _q_offset,ldq,tau,_tau_offset,work,_work_offset,iinfo);
}              // Close if()
}              //  Close else.
Dummy.go_to("Dopgtr",999999);
// *
// *     End of DOPGTR
// *
Dummy.label("Dopgtr",999999);
return;
   }
} // End class.
