/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dopmtr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DOPMTR overwrites the general real M-by-N matrix C with
// *
// *                  SIDE = 'L'     SIDE = 'R'
// *  TRANS = 'N':      Q * C          C * Q
// *  TRANS = 'T':      Q**T * C       C * Q**T
// *
// *  where Q is a real orthogonal matrix of order nq, with nq = m if
// *  SIDE = 'L' and nq = n if SIDE = 'R'. Q is defined as the product of
// *  nq-1 elementary reflectors, as returned by DSPTRD using packed
// *  storage:
// *
// *  if UPLO = 'U', Q = H(nq-1) . . . H(2) H(1);
// *
// *  if UPLO = 'L', Q = H(1) H(2) . . . H(nq-1).
// *
// *  Arguments
// *  =========
// *
// *  SIDE    (input) CHARACTER*1
// *          = 'L': apply Q or Q**T from the Left;
// *          = 'R': apply Q or Q**T from the Right.
// *
// *  UPLO    (input) CHARACTER*1
// *          = 'U': Upper triangular packed storage used in previous
// *                 call to DSPTRD;
// *          = 'L': Lower triangular packed storage used in previous
// *                 call to DSPTRD.
// *
// *  TRANS   (input) CHARACTER*1
// *          = 'N':  No transpose, apply Q;
// *          = 'T':  Transpose, apply Q**T.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix C. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix C. N >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension
// *                               (M*(M+1)/2) if SIDE = 'L'
// *                               (N*(N+1)/2) if SIDE = 'R'
// *          The vectors which define the elementary reflectors, as
// *          returned by DSPTRD.  AP is modified by the routine but
// *          restored on exit.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (M-1) if SIDE = 'L'
// *                                     or (N-1) if SIDE = 'R'
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DSPTRD.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC,N)
// *          On entry, the M-by-N matrix C.
// *          On exit, C is overwritten by Q*C or Q**T*C or C*Q**T or C*Q.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C. LDC >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                                   (N) if SIDE = 'L'
// *                                   (M) if SIDE = 'R'
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean forwrd= false;
static boolean left= false;
static boolean notran= false;
static boolean upper= false;
static int i= 0;
static int i1= 0;
static int i2= 0;
static int i3= 0;
static int ic= 0;
static int ii= 0;
static int jc= 0;
static int mi= 0;
static int ni= 0;
static int nq= 0;
static double aii= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dopmtr (String side,
String uplo,
String trans,
int m,
int n,
double [] ap, int _ap_offset,
double [] tau, int _tau_offset,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
left = (side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0));
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
// *
// *     NQ is the order of Q
// *
if (left)  {
    nq = m;
}              // Close if()
else  {
  nq = n;
}              //  Close else.
if (!left && !(side.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -2;
}              // Close else if()
else if (!notran && !(trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    info.val = -3;
}              // Close else if()
else if (m < 0)  {
    info.val = -4;
}              // Close else if()
else if (n < 0)  {
    info.val = -5;
}              // Close else if()
else if (Ldc < Math.max(1, m) )  {
    info.val = -9;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DOPMTR",-info.val);
Dummy.go_to("Dopmtr",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dopmtr",999999);
// *
if (upper)  {
    // *
// *        Q was determined by a call to DSPTRD with UPLO = 'U'
// *
forwrd = (left && notran) || (!left && !notran);
// *
if (forwrd)  {
    i1 = 1;
i2 = nq-1;
i3 = 1;
ii = 2;
}              // Close if()
else  {
  i1 = nq-1;
i2 = 1;
i3 = -1;
ii = nq*(nq+1)/2-1;
}              //  Close else.
// *
if (left)  {
    ni = n;
}              // Close if()
else  {
  mi = m;
}              //  Close else.
// *
{
int _i_inc = i3;
forloop10:
for (i = i1; (_i_inc < 0) ? i >= i2 : i <= i2; i += _i_inc) {
if (left)  {
    // *
// *              H(i) is applied to C(1:i,1:n)
// *
mi = i;
}              // Close if()
else  {
  // *
// *              H(i) is applied to C(1:m,1:i)
// *
ni = i;
}              //  Close else.
// *
// *           Apply H(i)
// *
aii = ap[(ii)- 1+ _ap_offset];
ap[(ii)- 1+ _ap_offset] = one;
Dlarf.dlarf(side,mi,ni,ap,(ii-i+1)- 1+ _ap_offset,1,tau[(i)- 1+ _tau_offset],c,_c_offset,Ldc,work,_work_offset);
ap[(ii)- 1+ _ap_offset] = aii;
// *
if (forwrd)  {
    ii = ii+i+2;
}              // Close if()
else  {
  ii = ii-i-1;
}              //  Close else.
Dummy.label("Dopmtr",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *        Q was determined by a call to DSPTRD with UPLO = 'L'.
// *
forwrd = (left && !notran) || (!left && notran);
// *
if (forwrd)  {
    i1 = 1;
i2 = nq-1;
i3 = 1;
ii = 2;
}              // Close if()
else  {
  i1 = nq-1;
i2 = 1;
i3 = -1;
ii = nq*(nq+1)/2-1;
}              //  Close else.
// *
if (left)  {
    ni = n;
jc = 1;
}              // Close if()
else  {
  mi = m;
ic = 1;
}              //  Close else.
// *
{
int _i_inc = i3;
forloop20:
for (i = i1; (_i_inc < 0) ? i >= i2 : i <= i2; i += _i_inc) {
aii = ap[(ii)- 1+ _ap_offset];
ap[(ii)- 1+ _ap_offset] = one;
if (left)  {
    // *
// *              H(i) is applied to C(i+1:m,1:n)
// *
mi = m-i;
ic = i+1;
}              // Close if()
else  {
  // *
// *              H(i) is applied to C(1:m,i+1:n)
// *
ni = n-i;
jc = i+1;
}              //  Close else.
// *
// *           Apply H(i)
// *
Dlarf.dlarf(side,mi,ni,ap,(ii)- 1+ _ap_offset,1,tau[(i)- 1+ _tau_offset],c,(ic)- 1+(jc- 1)*Ldc+ _c_offset,Ldc,work,_work_offset);
ap[(ii)- 1+ _ap_offset] = aii;
// *
if (forwrd)  {
    ii = ii+nq-i+1;
}              // Close if()
else  {
  ii = ii-nq+i-2;
}              //  Close else.
Dummy.label("Dopmtr",20);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dopmtr",999999);
// *
// *     End of DOPMTR
// *
Dummy.label("Dopmtr",999999);
return;
   }
} // End class.
