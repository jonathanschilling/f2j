/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dorg2l {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORG2L generates an m by n real matrix Q with orthonormal columns,
// *  which is defined as the last n columns of a product of k elementary
// *  reflectors of order m
// *
// *        Q  =  H(k) . . . H(2) H(1)
// *
// *  as returned by DGEQLF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q. M >= N >= 0.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. N >= K >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the (n-k+i)-th column must contain the vector which
// *          defines the elementary reflector H(i), for i = 1,2,...,k, as
// *          returned by DGEQLF in the last k columns of its array
// *          argument A.
// *          On exit, the m by n matrix Q.
// *
// *  LDA     (input) INTEGER
// *          The first dimension of the array A. LDA >= max(1,M).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (K)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DGEQLF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument has an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ii= 0;
static int j= 0;
static int l= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorg2l (int m,
int n,
int k,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0 || n > m)  {
    info.val = -2;
}              // Close else if()
else if (k < 0 || k > n)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORG2L",-info.val);
Dummy.go_to("Dorg2l",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n <= 0)  
    Dummy.go_to("Dorg2l",999999);
// *
// *     Initialise columns 1:n-k to columns of the unit matrix
// *
{
forloop20:
for (j = 1; j <= n-k; j++) {
{
forloop10:
for (l = 1; l <= m; l++) {
a[(l)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorg2l",10);
}              //  Close for() loop. 
}
a[(m-n+j)- 1+(j- 1)*lda+ _a_offset] = one;
Dummy.label("Dorg2l",20);
}              //  Close for() loop. 
}
// *
{
forloop40:
for (i = 1; i <= k; i++) {
ii = n-k+i;
// *
// *        Apply H(i) to A(1:m-k+i,1:n-k+i) from the left
// *
a[(m-n+ii)- 1+(ii- 1)*lda+ _a_offset] = one;
Dlarf.dlarf("Left",m-n+ii,ii-1,a,(1)- 1+(ii- 1)*lda+ _a_offset,1,tau[(i)- 1+ _tau_offset],a,_a_offset,lda,work,_work_offset);
Dscal.dscal(m-n+ii-1,-tau[(i)- 1+ _tau_offset],a,(1)- 1+(ii- 1)*lda+ _a_offset,1);
a[(m-n+ii)- 1+(ii- 1)*lda+ _a_offset] = one-tau[(i)- 1+ _tau_offset];
// *
// *        Set A(m-k+i+1:m,n-k+i) to zero
// *
{
forloop30:
for (l = m-n+ii+1; l <= m; l++) {
a[(l)- 1+(ii- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorg2l",30);
}              //  Close for() loop. 
}
Dummy.label("Dorg2l",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dorg2l",999999);
// *
// *     End of DORG2L
// *
Dummy.label("Dorg2l",999999);
return;
   }
} // End class.
