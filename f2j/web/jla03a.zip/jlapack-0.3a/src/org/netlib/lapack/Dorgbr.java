/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dorgbr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORGBR generates one of the real orthogonal matrices Q or P**T
// *  determined by DGEBRD when reducing a real matrix A to bidiagonal
// *  form: A = Q * B * P**T.  Q and P**T are defined as products of
// *  elementary reflectors H(i) or G(i) respectively.
// *
// *  If VECT = 'Q', A is assumed to have been an M-by-K matrix, and Q
// *  is of order M:
// *  if m >= k, Q = H(1) H(2) . . . H(k) and DORGBR returns the first n
// *  columns of Q, where m >= n >= k;
// *  if m < k, Q = H(1) H(2) . . . H(m-1) and DORGBR returns Q as an
// *  M-by-M matrix.
// *
// *  If VECT = 'P', A is assumed to have been a K-by-N matrix, and P**T
// *  is of order N:
// *  if k < n, P**T = G(k) . . . G(2) G(1) and DORGBR returns the first m
// *  rows of P**T, where n >= m >= k;
// *  if k >= n, P**T = G(n-1) . . . G(2) G(1) and DORGBR returns P**T as
// *  an N-by-N matrix.
// *
// *  Arguments
// *  =========
// *
// *  VECT    (input) CHARACTER*1
// *          Specifies whether the matrix Q or the matrix P**T is
// *          required, as defined in the transformation applied by DGEBRD:
// *          = 'Q':  generate Q;
// *          = 'P':  generate P**T.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q or P**T to be returned.
// *          M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q or P**T to be returned.
// *          N >= 0.
// *          If VECT = 'Q', M >= N >= min(M,K);
// *          if VECT = 'P', N >= M >= min(N,K).
// *
// *  K       (input) INTEGER
// *          If VECT = 'Q', the number of columns in the original M-by-K
// *          matrix reduced by DGEBRD.
// *          If VECT = 'P', the number of rows in the original K-by-N
// *          matrix reduced by DGEBRD.
// *          K >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the vectors which define the elementary reflectors,
// *          as returned by DGEBRD.
// *          On exit, the M-by-N matrix Q or P**T.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,M).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension
// *                                (min(M,K)) if VECT = 'Q'
// *                                (min(N,K)) if VECT = 'P'
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i) or G(i), which determines Q or P**T, as
// *          returned by DGEBRD in its array argument TAUQ or TAUP.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= max(1,min(M,N)).
// *          For optimum performance LWORK >= min(M,N)*NB, where NB
// *          is the optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean wantq= false;
static int i= 0;
static intW iinfo= new intW(0);
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorgbr (String vect,
int m,
int n,
int k,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
wantq = (vect.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0));
if (!wantq && !(vect.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (m < 0)  {
    info.val = -2;
}              // Close else if()
else if (n < 0 || (wantq && (n > m || n < Math.min(m, k) )) || (!wantq && (m > n || m < Math.min(n, k) )))  {
    info.val = -3;
}              // Close else if()
else if (k < 0)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -6;
}              // Close else if()
else if (lwork < Math.max(1, Math.min(m, n) ) )  {
    info.val = -9;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORGBR",-info.val);
Dummy.go_to("Dorgbr",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dorgbr",999999);
}              // Close if()
// *
if (wantq)  {
    // *
// *        Form Q, determined by a call to DGEBRD to reduce an m-by-k
// *        matrix
// *
if (m >= k)  {
    // *
// *           If m >= k, assume m >= n >= k
// *
Dorgqr.dorgqr(m,n,k,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
// *
}              // Close if()
else  {
  // *
// *           If m < k, assume m = n
// *
// *           Shift the vectors which define the elementary reflectors one
// *           column to the right, and set the first row and column of Q
// *           to those of the unit matrix
// *
{
int _j_inc = -1;
forloop20:
for (j = m; j >= 2; j += _j_inc) {
a[(1)- 1+(j- 1)*lda+ _a_offset] = zero;
{
forloop10:
for (i = j+1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j-1- 1)*lda+ _a_offset];
Dummy.label("Dorgbr",10);
}              //  Close for() loop. 
}
Dummy.label("Dorgbr",20);
}              //  Close for() loop. 
}
a[(1)- 1+(1- 1)*lda+ _a_offset] = one;
{
forloop30:
for (i = 2; i <= m; i++) {
a[(i)- 1+(1- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgbr",30);
}              //  Close for() loop. 
}
if (m > 1)  {
    // *
// *              Form Q(2:m,2:m)
// *
Dorgqr.dorgqr(m-1,m-1,m-1,a,(2)- 1+(2- 1)*lda+ _a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
}              // Close if()
}              //  Close else.
}              // Close if()
else  {
  // *
// *        Form P', determined by a call to DGEBRD to reduce a k-by-n
// *        matrix
// *
if (k < n)  {
    // *
// *           If k < n, assume k <= m <= n
// *
Dorglq.dorglq(m,n,k,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
// *
}              // Close if()
else  {
  // *
// *           If k >= n, assume m = n
// *
// *           Shift the vectors which define the elementary reflectors one
// *           row downward, and set the first row and column of P' to
// *           those of the unit matrix
// *
a[(1)- 1+(1- 1)*lda+ _a_offset] = one;
{
forloop40:
for (i = 2; i <= n; i++) {
a[(i)- 1+(1- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgbr",40);
}              //  Close for() loop. 
}
{
forloop60:
for (j = 2; j <= n; j++) {
{
int _i_inc = -1;
forloop50:
for (i = j-1; i >= 2; i += _i_inc) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i-1)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dorgbr",50);
}              //  Close for() loop. 
}
a[(1)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgbr",60);
}              //  Close for() loop. 
}
if (n > 1)  {
    // *
// *              Form P'(2:n,2:n)
// *
Dorglq.dorglq(n-1,n-1,n-1,a,(2)- 1+(2- 1)*lda+ _a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
}              // Close if()
}              //  Close else.
}              //  Close else.
Dummy.go_to("Dorgbr",999999);
// *
// *     End of DORGBR
// *
Dummy.label("Dorgbr",999999);
return;
   }
} // End class.
