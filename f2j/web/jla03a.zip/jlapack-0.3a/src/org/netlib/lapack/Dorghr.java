/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dorghr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORGHR generates a real orthogonal matrix Q which is defined as the
// *  product of IHI-ILO elementary reflectors of order N, as returned by
// *  DGEHRD:
// *
// *  Q = H(ilo) H(ilo+1) . . . H(ihi-1).
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix Q. N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          ILO and IHI must have the same values as in the previous call
// *          of DGEHRD. Q is equal to the unit matrix except in the
// *          submatrix Q(ilo+1:ihi,ilo+1:ihi).
// *          1 <= ILO <= IHI <= N, if N > 0; ILO=1 and IHI=0, if N=0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the vectors which define the elementary reflectors,
// *          as returned by DGEHRD.
// *          On exit, the N-by-N orthogonal matrix Q.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,N).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N-1)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DGEHRD.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= IHI-ILO.
// *          For optimum performance LWORK >= (IHI-ILO)*NB, where NB is
// *          the optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW iinfo= new intW(0);
static int j= 0;
static int nh= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorghr (int n,
int ilo,
int ihi,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (ilo < 1 || ilo > Math.max(1, n) )  {
    info.val = -2;
}              // Close else if()
else if (ihi < Math.min(ilo, n)  || ihi > n)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
else if (lwork < Math.max(1, ihi-ilo) )  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORGHR",-info.val);
Dummy.go_to("Dorghr",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dorghr",999999);
}              // Close if()
// *
// *     Shift the vectors which define the elementary reflectors one
// *     column to the right, and set the first ilo and the last n-ihi
// *     rows and columns to those of the unit matrix
// *
{
int _j_inc = -1;
forloop40:
for (j = ihi; j >= ilo+1; j += _j_inc) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorghr",10);
}              //  Close for() loop. 
}
{
forloop20:
for (i = j+1; i <= ihi; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j-1- 1)*lda+ _a_offset];
Dummy.label("Dorghr",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = ihi+1; i <= n; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorghr",30);
}              //  Close for() loop. 
}
Dummy.label("Dorghr",40);
}              //  Close for() loop. 
}
{
forloop60:
for (j = 1; j <= ilo; j++) {
{
forloop50:
for (i = 1; i <= n; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorghr",50);
}              //  Close for() loop. 
}
a[(j)- 1+(j- 1)*lda+ _a_offset] = one;
Dummy.label("Dorghr",60);
}              //  Close for() loop. 
}
{
forloop80:
for (j = ihi+1; j <= n; j++) {
{
forloop70:
for (i = 1; i <= n; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorghr",70);
}              //  Close for() loop. 
}
a[(j)- 1+(j- 1)*lda+ _a_offset] = one;
Dummy.label("Dorghr",80);
}              //  Close for() loop. 
}
// *
nh = ihi-ilo;
if (nh > 0)  {
    // *
// *        Generate Q(ilo+1:ihi,ilo+1:ihi)
// *
Dorgqr.dorgqr(nh,nh,nh,a,(ilo+1)- 1+(ilo+1- 1)*lda+ _a_offset,lda,tau,(ilo)- 1+ _tau_offset,work,_work_offset,lwork,iinfo);
}              // Close if()
Dummy.go_to("Dorghr",999999);
// *
// *     End of DORGHR
// *
Dummy.label("Dorghr",999999);
return;
   }
} // End class.
