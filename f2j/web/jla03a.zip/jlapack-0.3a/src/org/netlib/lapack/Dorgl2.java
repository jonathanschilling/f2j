/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dorgl2 {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORGL2 generates an m by n real matrix Q with orthonormal rows,
// *  which is defined as the first m rows of a product of k elementary
// *  reflectors of order n
// *
// *        Q  =  H(k) . . . H(2) H(1)
// *
// *  as returned by DGELQF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q. N >= M.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. M >= K >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the i-th row must contain the vector which defines
// *          the elementary reflector H(i), for i = 1,2,...,k, as returned
// *          by DGELQF in the first k rows of its array argument A.
// *          On exit, the m-by-n matrix Q.
// *
// *  LDA     (input) INTEGER
// *          The first dimension of the array A. LDA >= max(1,M).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (K)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DGELQF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument has an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int l= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorgl2 (int m,
int n,
int k,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < m)  {
    info.val = -2;
}              // Close else if()
else if (k < 0 || k > m)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORGL2",-info.val);
Dummy.go_to("Dorgl2",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m <= 0)  
    Dummy.go_to("Dorgl2",999999);
// *
if (k < m)  {
    // *
// *        Initialise rows k+1:m to rows of the unit matrix
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (l = k+1; l <= m; l++) {
a[(l)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgl2",10);
}              //  Close for() loop. 
}
if (j > k && j <= m)  
    a[(j)- 1+(j- 1)*lda+ _a_offset] = one;
Dummy.label("Dorgl2",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
{
int _i_inc = -1;
forloop40:
for (i = k; i >= 1; i += _i_inc) {
// *
// *        Apply H(i) to A(i:m,i:n) from the right
// *
if (i < n)  {
    if (i < m)  {
    a[(i)- 1+(i- 1)*lda+ _a_offset] = one;
Dlarf.dlarf("Right",m-i,n-i+1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,tau[(i)- 1+ _tau_offset],a,(i+1)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset);
}              // Close if()
Dscal.dscal(n-i,-tau[(i)- 1+ _tau_offset],a,(i)- 1+(i+1- 1)*lda+ _a_offset,lda);
}              // Close if()
a[(i)- 1+(i- 1)*lda+ _a_offset] = one-tau[(i)- 1+ _tau_offset];
// *
// *        Set A(1:i-1,i) to zero
// *
{
forloop30:
for (l = 1; l <= i-1; l++) {
a[(i)- 1+(l- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgl2",30);
}              //  Close for() loop. 
}
Dummy.label("Dorgl2",40);
}              //  Close for() loop. 
}
Dummy.go_to("Dorgl2",999999);
// *
// *     End of DORGL2
// *
Dummy.label("Dorgl2",999999);
return;
   }
} // End class.
