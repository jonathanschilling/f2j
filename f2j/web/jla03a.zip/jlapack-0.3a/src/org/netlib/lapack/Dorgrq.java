/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dorgrq {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORGRQ generates an M-by-N real matrix Q with orthonormal rows,
// *  which is defined as the last M rows of a product of K elementary
// *  reflectors of order N
// *
// *        Q  =  H(1) H(2) . . . H(k)
// *
// *  as returned by DGERQF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q. M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q. N >= M.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. M >= K >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the (m-k+i)-th row must contain the vector which
// *          defines the elementary reflector H(i), for i = 1,2,...,k, as
// *          returned by DGERQF in the last k rows of its array argument
// *          A.
// *          On exit, the M-by-N matrix Q.
// *
// *  LDA     (input) INTEGER
// *          The first dimension of the array A. LDA >= max(1,M).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (K)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DGERQF.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= max(1,M).
// *          For optimum performance LWORK >= M*NB, where NB is the
// *          optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument has an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ib= 0;
static int ii= 0;
static intW iinfo= new intW(0);
static int iws= 0;
static int j= 0;
static int kk= 0;
static int l= 0;
static int ldwork= 0;
static int nb= 0;
static int nbmin= 0;
static int nx= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorgrq (int m,
int n,
int k,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < m)  {
    info.val = -2;
}              // Close else if()
else if (k < 0 || k > m)  {
    info.val = -3;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -5;
}              // Close else if()
else if (lwork < Math.max(1, m) )  {
    info.val = -8;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORGRQ",-info.val);
Dummy.go_to("Dorgrq",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m <= 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dorgrq",999999);
}              // Close if()
// *
// *     Determine the block size.
// *
nb = Ilaenv.ilaenv(1,"DORGRQ"," ",m,n,k,-1);
nbmin = 2;
nx = 0;
iws = m;
if (nb > 1 && nb < k)  {
    // *
// *        Determine when to cross over from blocked to unblocked code.
// *
nx = (int)(Math.max(0, Ilaenv.ilaenv(3,"DORGRQ"," ",m,n,k,-1)) );
if (nx < k)  {
    // *
// *           Determine if workspace is large enough for blocked code.
// *
ldwork = m;
iws = ldwork*nb;
if (lwork < iws)  {
    // *
// *              Not enough workspace to use optimal NB:  reduce NB and
// *              determine the minimum value of NB.
// *
nb = lwork/ldwork;
nbmin = (int)(Math.max(2, Ilaenv.ilaenv(2,"DORGRQ"," ",m,n,k,-1)) );
}              // Close if()
}              // Close if()
}              // Close if()
// *
if (nb >= nbmin && nb < k && nx < k)  {
    // *
// *        Use blocked code after the first block.
// *        The last kk rows are handled by the block method.
// *
kk = (int)(Math.min(k, ((k-nx+nb-1)/nb)*nb) );
// *
// *        Set A(1:m-kk,n-kk+1:n) to zero.
// *
{
forloop20:
for (j = n-kk+1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= m-kk; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgrq",10);
}              //  Close for() loop. 
}
Dummy.label("Dorgrq",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  kk = 0;
}              //  Close else.
// *
// *     Use unblocked code for the first or only block.
// *
Dorgr2.dorgr2(m-kk,n-kk,k-kk,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,iinfo);
// *
if (kk > 0)  {
    // *
// *        Use blocked code
// *
{
int _i_inc = nb;
forloop50:
for (i = k-kk+1; (_i_inc < 0) ? i >= k : i <= k; i += _i_inc) {
ib = (int)(Math.min(nb, k-i+1) );
ii = m-k+i;
if (ii > 1)  {
    // *
// *              Form the triangular factor of the block reflector
// *              H = H(i+ib-1) . . . H(i+1) H(i)
// *
Dlarft.dlarft("Backward","Rowwise",n-k+i+ib-1,ib,a,(ii)- 1+(1- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,work,_work_offset,ldwork);
// *
// *              Apply H' to A(1:m-k+i-1,1:n-k+i+ib-1) from the right
// *
Dlarfb.dlarfb("Right","Transpose","Backward","Rowwise",ii-1,n-k+i+ib-1,ib,a,(ii)- 1+(1- 1)*lda+ _a_offset,lda,work,_work_offset,ldwork,a,_a_offset,lda,work,(ib+1)- 1+ _work_offset,ldwork);
}              // Close if()
// *
// *           Apply H' to columns 1:n-k+i+ib-1 of current block
// *
Dorgr2.dorgr2(ib,n-k+i+ib-1,ib,a,(ii)- 1+(1- 1)*lda+ _a_offset,lda,tau,(i)- 1+ _tau_offset,work,_work_offset,iinfo);
// *
// *           Set columns n-k+i+ib:n of current block to zero
// *
{
forloop40:
for (l = n-k+i+ib; l <= n; l++) {
{
forloop30:
for (j = ii; j <= ii+ib-1; j++) {
a[(j)- 1+(l- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgrq",30);
}              //  Close for() loop. 
}
Dummy.label("Dorgrq",40);
}              //  Close for() loop. 
}
Dummy.label("Dorgrq",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
work[(1)- 1+ _work_offset] = (double)(iws);
Dummy.go_to("Dorgrq",999999);
// *
// *     End of DORGRQ
// *
Dummy.label("Dorgrq",999999);
return;
   }
} // End class.
