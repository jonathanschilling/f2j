/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: jlapack.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

package org.netlib.lapack;
import java.lang.*;
import org.netlib.util.*;



public class Dorgtr {

// *
// *  -- LAPACK routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORGTR generates a real orthogonal matrix Q which is defined as the
// *  product of n-1 elementary reflectors of order N, as returned by
// *  DSYTRD:
// *
// *  if UPLO = 'U', Q = H(n-1) . . . H(2) H(1),
// *
// *  if UPLO = 'L', Q = H(1) H(2) . . . H(n-1).
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          = 'U': Upper triangle of A contains elementary reflectors
// *                 from DSYTRD;
// *          = 'L': Lower triangle of A contains elementary reflectors
// *                 from DSYTRD.
// *
// *  N       (input) INTEGER
// *          The order of the matrix Q. N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the vectors which define the elementary reflectors,
// *          as returned by DSYTRD.
// *          On exit, the N-by-N orthogonal matrix Q.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= max(1,N).
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N-1)
// *          TAU(i) must contain the scalar factor of the elementary
// *          reflector H(i), as returned by DSYTRD.
// *
// *  WORK    (workspace/output) DOUBLE PRECISION array, dimension (LWORK)
// *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK. LWORK >= max(1,N-1).
// *          For optimum performance LWORK >= (N-1)*NB, where NB is
// *          the optimal blocksize.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static int i= 0;
static intW iinfo= new intW(0);
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dorgtr (String uplo,
int n,
double [] a, int _a_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
intW info)  {

info.val = 0;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (!upper && !(uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -4;
}              // Close else if()
else if (lwork < Math.max(1, n-1) )  {
    info.val = -7;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DORGTR",-info.val);
Dummy.go_to("Dorgtr",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (n == 0)  {
    work[(1)- 1+ _work_offset] = (double)(1);
Dummy.go_to("Dorgtr",999999);
}              // Close if()
// *
if (upper)  {
    // *
// *        Q was determined by a call to DSYTRD with UPLO = 'U'
// *
// *        Shift the vectors which define the elementary reflectors one
// *        column to the left, and set the last row and column of Q to
// *        those of the unit matrix
// *
{
forloop20:
for (j = 1; j <= n-1; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j+1- 1)*lda+ _a_offset];
Dummy.label("Dorgtr",10);
}              //  Close for() loop. 
}
a[(n)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgtr",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n-1; i++) {
a[(i)- 1+(n- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgtr",30);
}              //  Close for() loop. 
}
a[(n)- 1+(n- 1)*lda+ _a_offset] = one;
// *
// *        Generate Q(1:n-1,1:n-1)
// *
Dorgql.dorgql(n-1,n-1,n-1,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
// *
}              // Close if()
else  {
  // *
// *        Q was determined by a call to DSYTRD with UPLO = 'L'.
// *
// *        Shift the vectors which define the elementary reflectors one
// *        column to the right, and set the first row and column of Q to
// *        those of the unit matrix
// *
{
int _j_inc = -1;
forloop50:
for (j = n; j >= 2; j += _j_inc) {
a[(1)- 1+(j- 1)*lda+ _a_offset] = zero;
{
forloop40:
for (i = j+1; i <= n; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j-1- 1)*lda+ _a_offset];
Dummy.label("Dorgtr",40);
}              //  Close for() loop. 
}
Dummy.label("Dorgtr",50);
}              //  Close for() loop. 
}
a[(1)- 1+(1- 1)*lda+ _a_offset] = one;
{
forloop60:
for (i = 2; i <= n; i++) {
a[(i)- 1+(1- 1)*lda+ _a_offset] = zero;
Dummy.label("Dorgtr",60);
}              //  Close for() loop. 
}
if (n > 1)  {
    // *
// *           Generate Q(2:n,2:n)
// *
Dorgqr.dorgqr(n-1,n-1,n-1,a,(2)- 1+(2- 1)*lda+ _a_offset,lda,tau,_tau_offset,work,_work_offset,lwork,iinfo);
}              // Close if()
}              //  Close else.
Dummy.go_to("Dorgtr",999999);
// *
// *     End of DORGTR
// *
Dummy.label("Dorgtr",999999);
return;
   }
} // End class.
