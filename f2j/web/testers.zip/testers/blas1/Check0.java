/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Check0 {

// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static doubleW sa= new doubleW(0.0);
static doubleW sb= new doubleW(0.0);
static doubleW sc= new doubleW(0.0);
static doubleW ss= new doubleW(0.0);
static int k= 0;
// *     .. Local Arrays ..
// *     .. External Subroutines ..
// *     .. Common blocks ..
// *     .. Data statements ..
static double [] da1 = {0.3e0 
, 0.4e0 , -0.3e0 , -0.4e0 , -0.3e0 , 0.0e0 
, 0.0e0 , 1.0e0 };
static double [] db1 = {0.4e0 
, 0.3e0 , 0.4e0 , 0.3e0 , -0.4e0 , 0.0e0 
, 1.0e0 , 0.0e0 };
static double [] dc1 = {0.6e0 
, 0.8e0 , -0.6e0 , 0.8e0 , 0.6e0 , 1.0e0 
, 0.0e0 , 1.0e0 };
static double [] ds1 = {0.8e0 
, 0.6e0 , 0.8e0 , -0.6e0 , 0.8e0 , 0.0e0 
, 1.0e0 , 0.0e0 };
static double [] datrue = {0.5e0 
, 0.5e0 , 0.5e0 , -0.5e0 , -0.5e0 , 0.0e0 
, 1.0e0 , 1.0e0 };
static double [] dbtrue = {0.0e0 
, 0.6e0 , 0.0e0 , -0.6e0 , 0.0e0 , 0.0e0 
, 1.0e0 , 0.0e0 };
static double d12 = 4096.0e0;
// *     .. Executable Statements ..
// *
// *     Compute true values which cannot be prestored
// *     in decimal notation
// *

public static void check0 (double sfac)  {

dbtrue[(1)- 1] = 1.0e0/0.6e0;
dbtrue[(3)- 1] = -1.0e0/0.6e0;
dbtrue[(5)- 1] = 1.0e0/0.6e0;
// *
{
forloop20:
for (k = 1; k <= 8; k++) {
// *        .. Set N=K for identification in output if any ..
blas1test_combla.n = k;
if (blas1test_combla.icase == 3)  {
    // *           .. DROTG ..
if (k > 8)  
    Dummy.go_to("Check0",40);
sa.val = da1[(k)- 1];
sb.val = db1[(k)- 1];
Drotg.drotg(sa,sb,sc,ss);
Stest1.stest1(sa.val,datrue[(k)- 1],datrue,(k)- 1,sfac);
Stest1.stest1(sb.val,dbtrue[(k)- 1],dbtrue,(k)- 1,sfac);
Stest1.stest1(sc.val,dc1[(k)- 1],dc1,(k)- 1,sfac);
Stest1.stest1(ss.val,ds1[(k)- 1],ds1,(k)- 1,sfac);
}              // Close if()
else  {
  System.out.println((" Shouldn\'t be here in CHECK0"));
System.exit(1);
}              //  Close else.
Dummy.label("Check0",20);
}              //  Close for() loop. 
}
label40:
   Dummy.label("Check0",40);
Dummy.go_to("Check0",999999);
Dummy.label("Check0",999999);
return;
   }
} // End class.
