/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Check1 {

// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static int i= 0;
static int len= 0;
static int np1= 0;
// *     .. Local Arrays ..
static double [] stemp= new double[(1)];
static double [] strue= new double[(8)];
static double [] sx= new double[(8)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Common blocks ..
// *     .. Data statements ..
static double [] sa = {0.3e0 
, -1.0e0 , 0.0e0 , 1.0e0 , 0.3e0 , 0.3e0 
, 0.3e0 , 0.3e0 , 0.3e0 , 0.3e0 };
static double [] dv = {0.1e0 
, 2.0e0 , 2.0e0 , 2.0e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 2.0e0 , 0.3e0 , 3.0e0 , 3.0e0 
, 3.0e0 , 3.0e0 , 3.0e0 , 3.0e0 , 3.0e0 
, 0.3e0 , -0.4e0 , 4.0e0 , 4.0e0 , 4.0e0 
, 4.0e0 , 4.0e0 , 4.0e0 , 0.2e0 , -0.6e0 
, 0.3e0 , 5.0e0 , 5.0e0 , 5.0e0 , 5.0e0 
, 5.0e0 , 0.1e0 , -0.3e0 , 0.5e0 , -0.1e0 
, 6.0e0 , 6.0e0 , 6.0e0 , 6.0e0 , 0.1e0 
, 8.0e0 , 8.0e0 , 8.0e0 , 8.0e0 , 8.0e0 
, 8.0e0 , 8.0e0 , 0.3e0 , 9.0e0 , 9.0e0 
, 9.0e0 , 9.0e0 , 9.0e0 , 9.0e0 , 9.0e0 
, 0.3e0 , 2.0e0 , -0.4e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 2.0e0 , 2.0e0 , 0.2e0 , 3.0e0 
, -0.6e0 , 5.0e0 , 0.3e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 0.1e0 , 4.0e0 , -0.3e0 , 6.0e0 
, -0.5e0 , 7.0e0 , -0.1e0 , 3.0e0 };
static double [] dtrue1 = {0.0e0 
, 0.3e0 , 0.5e0 , 0.7e0 , 0.6e0 };
static double [] dtrue3 = {0.0e0 
, 0.3e0 , 0.7e0 , 1.1e0 , 1.0e0 };
static double [] dtrue5 = {0.10e0 
, 2.0e0 , 2.0e0 , 2.0e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 2.0e0 , -0.3e0 , 3.0e0 , 3.0e0 
, 3.0e0 , 3.0e0 , 3.0e0 , 3.0e0 , 3.0e0 
, 0.0e0 , 0.0e0 , 4.0e0 , 4.0e0 , 4.0e0 
, 4.0e0 , 4.0e0 , 4.0e0 , 0.20e0 , -0.60e0 
, 0.30e0 , 5.0e0 , 5.0e0 , 5.0e0 , 5.0e0 
, 5.0e0 , 0.03e0 , -0.09e0 , 0.15e0 , -0.03e0 
, 6.0e0 , 6.0e0 , 6.0e0 , 6.0e0 , 0.10e0 
, 8.0e0 , 8.0e0 , 8.0e0 , 8.0e0 , 8.0e0 
, 8.0e0 , 8.0e0 , 0.09e0 , 9.0e0 , 9.0e0 
, 9.0e0 , 9.0e0 , 9.0e0 , 9.0e0 , 9.0e0 
, 0.09e0 , 2.0e0 , -0.12e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 2.0e0 , 2.0e0 , 0.06e0 , 3.0e0 
, -0.18e0 , 5.0e0 , 0.09e0 , 2.0e0 , 2.0e0 
, 2.0e0 , 0.03e0 , 4.0e0 , -0.09e0 , 6.0e0 
, -0.15e0 , 7.0e0 , -0.03e0 , 3.0e0 };
static int [] itrue2 = {0 
, 1 , 2 , 2 , 3 };
// *     .. Executable Statements ..

public static void check1 (double sfac)  {

{
forloop80:
for (blas1test_combla.incx = 1; blas1test_combla.incx <= 2; blas1test_combla.incx++) {
{
forloop60:
for (np1 = 1; np1 <= 5; np1++) {
blas1test_combla.n = np1-1;
len = (int)(2*Math.max(blas1test_combla.n, 1) );
// *           .. Set vector arguments ..
{
forloop20:
for (i = 1; i <= len; i++) {
sx[(i)- 1] = dv[(i)+(((np1)+((blas1test_combla.incx) * 5)) *8) - 49];
Dummy.label("Check1",20);
}              //  Close for() loop. 
}
// *
if (blas1test_combla.icase == 7)  {
    // *              .. DNRM2 ..
stemp[(1)- 1] = dtrue1[(np1)- 1];
Stest1.stest1(Dnrm2.dnrm2(blas1test_combla.n,sx,0,blas1test_combla.incx),stemp[0],stemp,0,sfac);
}              // Close if()
else if (blas1test_combla.icase == 8)  {
    // *              .. DASUM ..
stemp[(1)- 1] = dtrue3[(np1)- 1];
Stest1.stest1(Dasum.dasum(blas1test_combla.n,sx,0,blas1test_combla.incx),stemp[0],stemp,0,sfac);
}              // Close else if()
else if (blas1test_combla.icase == 9)  {
    // *              .. DSCAL ..
Dscal.dscal(blas1test_combla.n,sa[((blas1test_combla.incx-1)*5+np1)- 1],sx,0,blas1test_combla.incx);
{
forloop40:
for (i = 1; i <= len; i++) {
strue[(i)- 1] = dtrue5[(i)+(((np1)+((blas1test_combla.incx) * 5)) *8) - 49];
Dummy.label("Check1",40);
}              //  Close for() loop. 
}
Stest.stest(len,sx,0,strue,0,strue,0,sfac);
}              // Close else if()
else if (blas1test_combla.icase == 10)  {
    // *              .. IDAMAX ..
Itest1.itest1(Idamax.idamax(blas1test_combla.n,sx,0,blas1test_combla.incx),itrue2[(np1)- 1]);
}              // Close else if()
else  {
  System.out.println((" Shouldn\'t be here in CHECK1"));
System.exit(1);
}              //  Close else.
Dummy.label("Check1",60);
}              //  Close for() loop. 
}
Dummy.label("Check1",80);
}              //  Close for() loop. 
}
Dummy.go_to("Check1",999999);
Dummy.label("Check1",999999);
return;
   }
} // End class.
