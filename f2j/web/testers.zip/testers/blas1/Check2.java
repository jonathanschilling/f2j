/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Check2 {

// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int ki= 0;
static int kn= 0;
static int ksize= 0;
static int lenx= 0;
static int leny= 0;
static int mx= 0;
static int my= 0;
// *     .. Local Arrays ..
static double [] stx= new double[(7)];
static double [] sty= new double[(7)];
static double [] sx= new double[(7)];
static double [] sy= new double[(7)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Common blocks ..
// *     .. Data statements ..
static double sa = 0.3e0;
static int [] incxs = {1 
, 2 , -2 , -1 };
static int [] incys = {1 
, -2 , 1 , -2 };
static int [] lens = {1 
, 1 , 2 , 4 , 1 , 1 
, 3 , 7 };
static int [] ns = {0 
, 1 , 2 , 4 };
static double [] dx1 = {0.6e0 
, 0.1e0 , -0.5e0 , 0.8e0 , 0.9e0 , -0.3e0 
, -0.4e0 };
static double [] dy1 = {0.5e0 
, -0.9e0 , 0.3e0 , 0.7e0 , -0.6e0 , 0.2e0 
, 0.8e0 };
static double sc = 0.8e0;
static double ss = 0.6e0;
static double [] dt7 = {0.0e0 
, 0.30e0 , 0.21e0 , 0.62e0 , 0.0e0 , 0.30e0 
, -0.07e0 , 0.85e0 , 0.0e0 , 0.30e0 , -0.79e0 
, -0.74e0 , 0.0e0 , 0.30e0 , 0.33e0 , 1.27e0 
};
static double [] dt8 = {0.5e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.68e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.68e0 , -0.87e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.68e0 , -0.87e0 , 0.15e0 , 0.94e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.68e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.35e0 , -0.9e0 , 0.48e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.38e0 , -0.9e0 
, 0.57e0 , 0.7e0 , -0.75e0 , 0.2e0 , 0.98e0 
, 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.68e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.35e0 
, -0.72e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.38e0 , -0.63e0 , 0.15e0 , 0.88e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.68e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.68e0 , -0.9e0 , 0.33e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.68e0 
, -0.9e0 , 0.33e0 , 0.7e0 , -0.75e0 , 0.2e0 
, 1.04e0 };
static double [] dt9x = {0.6e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.78e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 , -0.46e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.78e0 , -0.46e0 , -0.22e0 , 1.06e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.6e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.66e0 , 0.1e0 , -0.1e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.96e0 , 0.1e0 
, -0.76e0 , 0.8e0 , 0.90e0 , -0.3e0 , -0.02e0 
, 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.78e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , -0.06e0 
, 0.1e0 , -0.1e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.90e0 , 0.1e0 , -0.22e0 , 0.8e0 
, 0.18e0 , -0.3e0 , -0.02e0 , 0.6e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.78e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.78e0 , 0.26e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 
, 0.26e0 , -0.76e0 , 1.12e0 , 0.0e0 , 0.0e0 
, 0.0e0 };
static double [] dt9y = {0.5e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.04e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 , -0.78e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.04e0 , -0.78e0 , 0.54e0 , 0.08e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.7e0 , -0.9e0 , -0.12e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.64e0 , -0.9e0 
, -0.30e0 , 0.7e0 , -0.18e0 , 0.2e0 , 0.28e0 
, 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.04e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.7e0 
, -1.08e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.64e0 , -1.26e0 , 0.54e0 , 0.20e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.04e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.04e0 , -0.9e0 , 0.18e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 
, -0.9e0 , 0.18e0 , 0.7e0 , -0.18e0 , 0.2e0 
, 0.16e0 };
static double [] dt10x = {0.6e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 , -0.9e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.5e0 , -0.9e0 , 0.3e0 , 0.7e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.6e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.3e0 , 0.1e0 , 0.5e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.8e0 , 0.1e0 
, -0.6e0 , 0.8e0 , 0.3e0 , -0.3e0 , 0.5e0 
, 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , -0.9e0 
, 0.1e0 , 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.7e0 , 0.1e0 , 0.3e0 , 0.8e0 
, -0.9e0 , -0.3e0 , 0.5e0 , 0.6e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.3e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 
, 0.3e0 , -0.6e0 , 0.8e0 , 0.0e0 , 0.0e0 
, 0.0e0 };
static double [] dt10y = {0.5e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.6e0 , 0.1e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.6e0 , 0.1e0 , -0.5e0 , 0.8e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.6e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , -0.5e0 , -0.9e0 , 0.6e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , -0.4e0 , -0.9e0 
, 0.9e0 , 0.7e0 , -0.5e0 , 0.2e0 , 0.6e0 
, 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.6e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , -0.5e0 
, 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , -0.4e0 , 0.9e0 , -0.5e0 , 0.6e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.6e0 , -0.9e0 , 0.1e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.6e0 
, -0.9e0 , 0.1e0 , 0.7e0 , -0.5e0 , 0.2e0 
, 0.8e0 };
static double [] ssize1 = {0.0e0 
, 0.3e0 , 1.6e0 , 3.2e0 };
static double [] ssize2 = {0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 };
// *     .. Executable Statements ..
// *

public static void check2 (double sfac)  {

{
forloop120:
for (ki = 1; ki <= 4; ki++) {
blas1test_combla.incx = incxs[(ki)- 1];
blas1test_combla.incy = incys[(ki)- 1];
mx = (int)(Math.abs(blas1test_combla.incx));
my = (int)(Math.abs(blas1test_combla.incy));
// *
{
forloop100:
for (kn = 1; kn <= 4; kn++) {
blas1test_combla.n = ns[(kn)- 1];
ksize = (int)(Math.min(2, kn) );
lenx = lens[(kn)- 1+(mx- 1)*4];
leny = lens[(kn)- 1+(my- 1)*4];
// *           .. Initialize all argument arrays ..
{
forloop20:
for (i = 1; i <= 7; i++) {
sx[(i)- 1] = dx1[(i)- 1];
sy[(i)- 1] = dy1[(i)- 1];
Dummy.label("Check2",20);
}              //  Close for() loop. 
}
// *
if (blas1test_combla.icase == 1)  {
    // *              .. DDOT ..
Stest1.stest1(Ddot.ddot(blas1test_combla.n,sx,0,blas1test_combla.incx,sy,0,blas1test_combla.incy),dt7[(kn)- 1+(ki- 1)*4],ssize1,(kn)- 1,sfac);
}              // Close if()
else if (blas1test_combla.icase == 2)  {
    // *              .. DAXPY ..
Daxpy.daxpy(blas1test_combla.n,sa,sx,0,blas1test_combla.incx,sy,0,blas1test_combla.incy);
{
forloop40:
for (j = 1; j <= leny; j++) {
sty[(j)- 1] = dt8[(j)+(((kn)+((ki) * 4)) *7) - 36];
Dummy.label("Check2",40);
}              //  Close for() loop. 
}
Stest.stest(leny,sy,0,sty,0,ssize2,(1)- 1+(ksize- 1)*14,sfac);
}              // Close else if()
else if (blas1test_combla.icase == 5)  {
    // *              .. DCOPY ..
{
forloop60:
for (i = 1; i <= 7; i++) {
sty[(i)- 1] = dt10y[(i)+(((kn)+((ki) * 4)) *7) - 36];
Dummy.label("Check2",60);
}              //  Close for() loop. 
}
Dcopy.dcopy(blas1test_combla.n,sx,0,blas1test_combla.incx,sy,0,blas1test_combla.incy);
Stest.stest(leny,sy,0,sty,0,ssize2,(1)- 1+(1- 1)*14,1.0e0);
}              // Close else if()
else if (blas1test_combla.icase == 6)  {
    // *              .. DSWAP ..
Dswap.dswap(blas1test_combla.n,sx,0,blas1test_combla.incx,sy,0,blas1test_combla.incy);
{
forloop80:
for (i = 1; i <= 7; i++) {
stx[(i)- 1] = dt10x[(i)+(((kn)+((ki) * 4)) *7) - 36];
sty[(i)- 1] = dt10y[(i)+(((kn)+((ki) * 4)) *7) - 36];
Dummy.label("Check2",80);
}              //  Close for() loop. 
}
Stest.stest(lenx,sx,0,stx,0,ssize2,(1)- 1+(1- 1)*14,1.0e0);
Stest.stest(leny,sy,0,sty,0,ssize2,(1)- 1+(1- 1)*14,1.0e0);
}              // Close else if()
else  {
  System.out.println((" Shouldn\'t be here in CHECK2"));
System.exit(1);
}              //  Close else.
Dummy.label("Check2",100);
}              //  Close for() loop. 
}
Dummy.label("Check2",120);
}              //  Close for() loop. 
}
Dummy.go_to("Check2",999999);
Dummy.label("Check2",999999);
return;
   }
} // End class.
