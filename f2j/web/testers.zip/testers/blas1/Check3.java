/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Check3 {

// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static int i= 0;
static int k= 0;
static int ki= 0;
static int kn= 0;
static int ksize= 0;
static int lenx= 0;
static int leny= 0;
static int mx= 0;
static int my= 0;
// *     .. Local Arrays ..
static double [] copyx= new double[(5)];
static double [] copyy= new double[(5)];
static double [] mwpc= new double[(11)];
static double [] mwps= new double[(11)];
static double [] mwpstx= new double[(5)];
static double [] mwpsty= new double[(5)];
static double [] mwptx= new double[(11) * (5)];
static double [] mwpty= new double[(11) * (5)];
static double [] mwpx= new double[(5)];
static double [] mwpy= new double[(5)];
static double [] stx= new double[(7)];
static double [] sty= new double[(7)];
static double [] sx= new double[(7)];
static double [] sy= new double[(7)];
static int [] mwpinx= new int[(11)];
static int [] mwpiny= new int[(11)];
static int [] mwpn= new int[(11)];
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Common blocks ..
// *     .. Data statements ..
static double sa = 0.3e0;
static int [] incxs = {1 
, 2 , -2 , -1 };
static int [] incys = {1 
, -2 , 1 , -2 };
static int [] lens = {1 
, 1 , 2 , 4 , 1 , 1 
, 3 , 7 };
static int [] ns = {0 
, 1 , 2 , 4 };
static double [] dx1 = {0.6e0 
, 0.1e0 , -0.5e0 , 0.8e0 , 0.9e0 , -0.3e0 
, -0.4e0 };
static double [] dy1 = {0.5e0 
, -0.9e0 , 0.3e0 , 0.7e0 , -0.6e0 , 0.2e0 
, 0.8e0 };
static double sc = 0.8e0;
static double ss = 0.6e0;
static double [] dt9x = {0.6e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.78e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 , -0.46e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.78e0 , -0.46e0 , -0.22e0 , 1.06e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.6e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.66e0 , 0.1e0 , -0.1e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.96e0 , 0.1e0 
, -0.76e0 , 0.8e0 , 0.90e0 , -0.3e0 , -0.02e0 
, 0.6e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.78e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , -0.06e0 
, 0.1e0 , -0.1e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.90e0 , 0.1e0 , -0.22e0 , 0.8e0 
, 0.18e0 , -0.3e0 , -0.02e0 , 0.6e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.78e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.78e0 , 0.26e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.78e0 
, 0.26e0 , -0.76e0 , 1.12e0 , 0.0e0 , 0.0e0 
, 0.0e0 };
static double [] dt9y = {0.5e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.04e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 , -0.78e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.04e0 , -0.78e0 , 0.54e0 , 0.08e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.7e0 , -0.9e0 , -0.12e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.64e0 , -0.9e0 
, -0.30e0 , 0.7e0 , -0.18e0 , 0.2e0 , 0.28e0 
, 0.5e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.04e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.7e0 
, -1.08e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.64e0 , -1.26e0 , 0.54e0 , 0.20e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.5e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.04e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.04e0 , -0.9e0 , 0.18e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.04e0 
, -0.9e0 , 0.18e0 , 0.7e0 , -0.18e0 , 0.2e0 
, 0.16e0 };
static double [] ssize2 = {0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 , 0.0e0 
, 0.0e0 , 0.0e0 , 0.0e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 , 1.17e0 
, 1.17e0 , 1.17e0 };
// *     .. Executable Statements ..
// *

public static void check3 (double sfac)  {

{
forloop60:
for (ki = 1; ki <= 4; ki++) {
blas1test_combla.incx = incxs[(ki)- 1];
blas1test_combla.incy = incys[(ki)- 1];
mx = (int)(Math.abs(blas1test_combla.incx));
my = (int)(Math.abs(blas1test_combla.incy));
// *
{
forloop40:
for (kn = 1; kn <= 4; kn++) {
blas1test_combla.n = ns[(kn)- 1];
ksize = (int)(Math.min(2, kn) );
lenx = lens[(kn)- 1+(mx- 1)*4];
leny = lens[(kn)- 1+(my- 1)*4];
// *
if (blas1test_combla.icase == 4)  {
    // *              .. DROT ..
{
forloop20:
for (i = 1; i <= 7; i++) {
sx[(i)- 1] = dx1[(i)- 1];
sy[(i)- 1] = dy1[(i)- 1];
stx[(i)- 1] = dt9x[(i)+(((kn)+((ki) * 4)) *7) - 36];
sty[(i)- 1] = dt9y[(i)+(((kn)+((ki) * 4)) *7) - 36];
Dummy.label("Check3",20);
}              //  Close for() loop. 
}
Drot.drot(blas1test_combla.n,sx,0,blas1test_combla.incx,sy,0,blas1test_combla.incy,sc,ss);
Stest.stest(lenx,sx,0,stx,0,ssize2,(1)- 1+(ksize- 1)*14,sfac);
Stest.stest(leny,sy,0,sty,0,ssize2,(1)- 1+(ksize- 1)*14,sfac);
}              // Close if()
else  {
  System.out.println((" Shouldn\'t be here in CHECK3"));
System.exit(1);
}              //  Close else.
Dummy.label("Check3",40);
}              //  Close for() loop. 
}
Dummy.label("Check3",60);
}              //  Close for() loop. 
}
// *
mwpc[(1)- 1] = (double)(1);
{
forloop80:
for (i = 2; i <= 11; i++) {
mwpc[(i)- 1] = (double)(0);
Dummy.label("Check3",80);
}              //  Close for() loop. 
}
mwps[(1)- 1] = (double)(0);
{
forloop100:
for (i = 2; i <= 6; i++) {
mwps[(i)- 1] = (double)(1);
Dummy.label("Check3",100);
}              //  Close for() loop. 
}
{
forloop120:
for (i = 7; i <= 11; i++) {
mwps[(i)- 1] = (double)(-1);
Dummy.label("Check3",120);
}              //  Close for() loop. 
}
mwpinx[(1)- 1] = 1;
mwpinx[(2)- 1] = 1;
mwpinx[(3)- 1] = 1;
mwpinx[(4)- 1] = -1;
mwpinx[(5)- 1] = 1;
mwpinx[(6)- 1] = -1;
mwpinx[(7)- 1] = 1;
mwpinx[(8)- 1] = 1;
mwpinx[(9)- 1] = -1;
mwpinx[(10)- 1] = 1;
mwpinx[(11)- 1] = -1;
mwpiny[(1)- 1] = 1;
mwpiny[(2)- 1] = 1;
mwpiny[(3)- 1] = -1;
mwpiny[(4)- 1] = -1;
mwpiny[(5)- 1] = 2;
mwpiny[(6)- 1] = 1;
mwpiny[(7)- 1] = 1;
mwpiny[(8)- 1] = -1;
mwpiny[(9)- 1] = -1;
mwpiny[(10)- 1] = 2;
mwpiny[(11)- 1] = 1;
{
forloop140:
for (i = 1; i <= 11; i++) {
mwpn[(i)- 1] = 5;
Dummy.label("Check3",140);
}              //  Close for() loop. 
}
mwpn[(5)- 1] = 3;
mwpn[(10)- 1] = 3;
{
forloop160:
for (i = 1; i <= 5; i++) {
mwpx[(i)- 1] = (double)(i);
mwpy[(i)- 1] = (double)(i);
mwptx[(1)- 1+(i- 1)*11] = (double)(i);
mwpty[(1)- 1+(i- 1)*11] = (double)(i);
mwptx[(2)- 1+(i- 1)*11] = (double)(i);
mwpty[(2)- 1+(i- 1)*11] = (double)(-i);
mwptx[(3)- 1+(i- 1)*11] = (double)(6-i);
mwpty[(3)- 1+(i- 1)*11] = (double)(i-6);
mwptx[(4)- 1+(i- 1)*11] = (double)(i);
mwpty[(4)- 1+(i- 1)*11] = (double)(-i);
mwptx[(6)- 1+(i- 1)*11] = (double)(6-i);
mwpty[(6)- 1+(i- 1)*11] = (double)(i-6);
mwptx[(7)- 1+(i- 1)*11] = (double)(-i);
mwpty[(7)- 1+(i- 1)*11] = (double)(i);
mwptx[(8)- 1+(i- 1)*11] = (double)(i-6);
mwpty[(8)- 1+(i- 1)*11] = (double)(6-i);
mwptx[(9)- 1+(i- 1)*11] = (double)(-i);
mwpty[(9)- 1+(i- 1)*11] = (double)(i);
mwptx[(11)- 1+(i- 1)*11] = (double)(i-6);
mwpty[(11)- 1+(i- 1)*11] = (double)(6-i);
Dummy.label("Check3",160);
}              //  Close for() loop. 
}
mwptx[(5)- 1+(1- 1)*11] = (double)(1);
mwptx[(5)- 1+(2- 1)*11] = (double)(3);
mwptx[(5)- 1+(3- 1)*11] = (double)(5);
mwptx[(5)- 1+(4- 1)*11] = (double)(4);
mwptx[(5)- 1+(5- 1)*11] = (double)(5);
mwpty[(5)- 1+(1- 1)*11] = (double)(-1);
mwpty[(5)- 1+(2- 1)*11] = (double)(2);
mwpty[(5)- 1+(3- 1)*11] = (double)(-2);
mwpty[(5)- 1+(4- 1)*11] = (double)(4);
mwpty[(5)- 1+(5- 1)*11] = (double)(-3);
mwptx[(10)- 1+(1- 1)*11] = (double)(-1);
mwptx[(10)- 1+(2- 1)*11] = (double)(-3);
mwptx[(10)- 1+(3- 1)*11] = (double)(-5);
mwptx[(10)- 1+(4- 1)*11] = (double)(4);
mwptx[(10)- 1+(5- 1)*11] = (double)(5);
mwpty[(10)- 1+(1- 1)*11] = (double)(1);
mwpty[(10)- 1+(2- 1)*11] = (double)(2);
mwpty[(10)- 1+(3- 1)*11] = (double)(2);
mwpty[(10)- 1+(4- 1)*11] = (double)(4);
mwpty[(10)- 1+(5- 1)*11] = (double)(3);
{
forloop200:
for (i = 1; i <= 11; i++) {
blas1test_combla.incx = mwpinx[(i)- 1];
blas1test_combla.incy = mwpiny[(i)- 1];
{
forloop180:
for (k = 1; k <= 5; k++) {
copyx[(k)- 1] = mwpx[(k)- 1];
copyy[(k)- 1] = mwpy[(k)- 1];
mwpstx[(k)- 1] = mwptx[(i)- 1+(k- 1)*11];
mwpsty[(k)- 1] = mwpty[(i)- 1+(k- 1)*11];
Dummy.label("Check3",180);
}              //  Close for() loop. 
}
Drot.drot(mwpn[(i)- 1],copyx,0,blas1test_combla.incx,copyy,0,blas1test_combla.incy,mwpc[(i)- 1],mwps[(i)- 1]);
Stest.stest(5,copyx,0,mwpstx,0,mwpstx,0,sfac);
Stest.stest(5,copyy,0,mwpsty,0,mwpsty,0,sfac);
Dummy.label("Check3",200);
}              //  Close for() loop. 
}
Dummy.go_to("Check3",999999);
Dummy.label("Check3",999999);
return;
   }
} // End class.
