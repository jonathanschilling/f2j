/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dblat1 {

// *     Test program for the DOUBLE PRECISION Level 1 BLAS.
// *     Based upon the original BLAS test routine together with:
// *     F06EAF Example Program Text
// *     .. Parameters ..
static int nout= 6;
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static int ic= 0;
// *     .. External Subroutines ..
// *     .. Common blocks ..
// *     .. Data statements ..
static double sfac = 9.765625e-4;
// *     .. Executable Statements ..

public static void main (String [] args)  {

System.out.println(" Real BLAS Test Program Results"  + "\n"  + " ");
{
forloop20:
for (ic = 1; ic <= 10; ic++) {
blas1test_combla.icase = ic;
Header.header();
// *
// *        .. Initialize  PASS,  INCX,  INCY, and MODE for a new case. ..
// *        .. the value 9999 for INCX, INCY or MODE will appear in the ..
// *        .. detailed  output, if any, for cases  that do not involve ..
// *        .. these parameters ..
// *
blas1test_combla.pass = true;
blas1test_combla.incx = 9999;
blas1test_combla.incy = 9999;
blas1test_combla.mode = 9999;
if (blas1test_combla.icase == 3)  {
    Check0.check0(sfac);
}              // Close if()
else if (blas1test_combla.icase == 7 || blas1test_combla.icase == 8 || blas1test_combla.icase == 9 || blas1test_combla.icase == 10)  {
    Check1.check1(sfac);
}              // Close else if()
else if (blas1test_combla.icase == 1 || blas1test_combla.icase == 2 || blas1test_combla.icase == 5 || blas1test_combla.icase == 6)  {
    Check2.check2(sfac);
}              // Close else if()
else if (blas1test_combla.icase == 4)  {
    Check3.check3(sfac);
}              // Close else if()
// *        -- Print
if (blas1test_combla.pass)  
    System.out.println("                                    ----- PASS -----" );
Dummy.label("Dblat1",20);
}              //  Close for() loop. 
}
System.exit(1);
// *
Dummy.label("Dblat1",999999);
return;
   }
} // End class.
