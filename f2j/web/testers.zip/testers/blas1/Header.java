/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Header {

// *     .. Parameters ..
static int nout= 6;
// *     .. Scalars in Common ..
// *     .. Local Arrays ..
static String [] l= new String[(10)];
// *     .. Common blocks ..
// *     .. Data statements ..
static {
l[(1)- 1] = " DDOT ";
}
static {
l[(2)- 1] = "DAXPY ";
}
static {
l[(3)- 1] = "DROTG ";
}
static {
l[(4)- 1] = " DROT ";
}
static {
l[(5)- 1] = "DCOPY ";
}
static {
l[(6)- 1] = "DSWAP ";
}
static {
l[(7)- 1] = "DNRM2 ";
}
static {
l[(8)- 1] = "DASUM ";
}
static {
l[(9)- 1] = "DSCAL ";
}
static {
l[(10)- 1] = "IDAMAX";
}
// *     .. Executable Statements ..

public static void header ()  {

System.out.println("\n"  + " Test of subprogram number"  + (blas1test_combla.icase) + " "  + "            " + (l[(blas1test_combla.icase)- 1]) + " " );
Dummy.go_to("Header",999999);
// *
Dummy.label("Header",999999);
return;
   }
} // End class.
