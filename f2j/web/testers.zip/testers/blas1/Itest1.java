/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Itest1 {

// *     ********************************* ITEST1 *************************
// *
// *     THIS SUBROUTINE COMPARES THE VARIABLES ICOMP AND ITRUE FOR
// *     EQUALITY.
// *     C. L. LAWSON, JPL, 1974 DEC 10
// *
// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static int id= 0;
// *     .. Common blocks ..
// *     .. Executable Statements ..
// *

public static void itest1 (int icomp,
int itrue)  {

if (icomp == itrue)  
    Dummy.go_to("Itest1",40);
// *
// *                            HERE ICOMP IS NOT EQUAL TO ITRUE.
// *
if (!blas1test_combla.pass)  
    Dummy.go_to("Itest1",20);
// *                             PRINT FAIL MESSAGE AND HEADER.
blas1test_combla.pass = false;
System.out.println("                                       FAIL" );
System.out.println("\n"  + " CASE  N INCX INCY MODE                               "  + " COMP                                TRUE     DIFFERENCE"  + "\n"  + " ");
label20:
   Dummy.label("Itest1",20);
id = icomp-itrue;
System.out.println(" " + (blas1test_combla.icase) + " "  + (blas1test_combla.n) + " "  + (blas1test_combla.incx) + " "  + (blas1test_combla.incy) + " "  + (blas1test_combla.mode) + " " );
label40:
   Dummy.label("Itest1",40);
Dummy.go_to("Itest1",999999);
// *
Dummy.label("Itest1",999999);
return;
   }
} // End class.
