/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Sdiff {

// *     ********************************* SDIFF **************************
// *     COMPUTES DIFFERENCE OF TWO NUMBERS.  C. L. LAWSON, JPL 1974 FEB 15
// *
// *     .. Scalar Arguments ..
// *     .. Executable Statements ..
static double sdiff = 0.0;


public static double sdiff (double sa,
double sb)  {

sdiff = sa-sb;
Dummy.go_to("Sdiff",999999);
Dummy.label("Sdiff",999999);
return sdiff;
   }
} // End class.
