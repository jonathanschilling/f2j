/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Stest {

// *     ********************************* STEST **************************
// *
// *     THIS SUBR COMPARES ARRAYS  SCOMP() AND STRUE() OF LENGTH LEN TO
// *     SEE IF THE TERM BY TERM DIFFERENCES, MULTIPLIED BY SFAC, ARE
// *     NEGLIGIBLE.
// *
// *     C. L. LAWSON, JPL, 1974 DEC 10
// *
// *     .. Parameters ..
static int nout= 6;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static double sd= 0.0;
static int i= 0;
// *     .. External Functions ..
// *     .. Intrinsic Functions ..
// *     .. Common blocks ..
// *     .. Executable Statements ..
// *

public static void stest (int len,
double [] scomp, int _scomp_offset,
double [] strue, int _strue_offset,
double [] ssize, int _ssize_offset,
double sfac)  {

{
forloop40:
for (i = 1; i <= len; i++) {
sd = scomp[(i)- 1+ _scomp_offset]-strue[(i)- 1+ _strue_offset];
if (Sdiff.sdiff(Math.abs(ssize[(i)- 1+ _ssize_offset])+Math.abs(sfac*sd),Math.abs(ssize[(i)- 1+ _ssize_offset])) == 0.0e0)  
    continue forloop40;
// *
// *                             HERE    SCOMP(I) IS NOT CLOSE TO STRUE(I).
// *
if (!blas1test_combla.pass)  
    Dummy.go_to("Stest",20);
// *                             PRINT FAIL MESSAGE AND HEADER.
blas1test_combla.pass = false;
System.out.println("                                       FAIL" );
System.out.println("\n"  + " CASE  N INCX INCY MODE  I                            "  + " COMP(I)                             TRUE(I)  DIFFERENCE"  + "     SIZE(I)"  + "\n"  + " ");
label20:
   Dummy.label("Stest",20);
System.out.println(" " + (blas1test_combla.icase) + " "  + (blas1test_combla.n) + " "  + (blas1test_combla.incx) + " "  + (blas1test_combla.incy) + " "  + (blas1test_combla.mode) + " "  + (i) + " " );
Dummy.label("Stest",40);
}              //  Close for() loop. 
}
Dummy.go_to("Stest",999999);
// *
Dummy.label("Stest",999999);
return;
   }
} // End class.
