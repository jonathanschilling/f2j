/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas1test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Stest1 {

// *     ************************* STEST1 *****************************
// *
// *     THIS IS AN INTERFACE SUBROUTINE TO ACCOMODATE THE FORTRAN
// *     REQUIREMENT THAT WHEN A DUMMY ARGUMENT IS AN ARRAY, THE
// *     ACTUAL ARGUMENT MUST ALSO BE AN ARRAY OR AN ARRAY ELEMENT.
// *
// *     C.L. LAWSON, JPL, 1978 DEC 6
// *
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Arrays ..
static double [] scomp= new double[(1)];
static double [] strue= new double[(1)];
// *     .. External Subroutines ..
// *     .. Executable Statements ..
// *

public static void stest1 (double scomp1,
double strue1,
double [] ssize, int _ssize_offset,
double sfac)  {

scomp[(1)- 1] = scomp1;
strue[(1)- 1] = strue1;
Stest.stest(1,scomp,0,strue,0,ssize,_ssize_offset,sfac);
// *
Dummy.go_to("Stest1",999999);
Dummy.label("Stest1",999999);
return;
   }
} // End class.
