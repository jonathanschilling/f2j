import org.netlib.util.*;

public class blas1test_combla
{
static int icase= 0;
static int n= 0;
static int incx= 0;
static int incy= 0;
static int mode= 0;
static boolean pass= false;
}
