/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dbeg {

// *
// *  Generates random numbers uniformly distributed between -0.5 and 0.5.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Scalar Arguments ..
// *     .. Local Scalars ..
static int i= 0;
static int ic= 0;
static int mi= 0;
// *     .. Save statement ..
// *     .. Intrinsic Functions ..
// *     .. Executable Statements ..
static double dbeg = 0.0;


public static double dbeg (booleanW reset)  {

if (reset.val)  {
    // *        Initialize local variables.
mi = 891;
i = 7;
ic = 0;
reset.val = false;
}              // Close if()
// *
// *     The sequence of values of I is bounded between 1 and 999.
// *     If initial I = 1,2,3,6,7 or 9, the period will be 50.
// *     If initial I = 4 or 8, the period will be 25.
// *     If initial I = 5, the period will be 10.
// *     IC is used to break up the period by skipping 1 value of I in 6.
// *
ic = ic+1;
label10:
   Dummy.label("Dbeg",10);
i = i*mi;
i = i-1000*(i/1000);
if (ic >= 5)  {
    ic = 0;
Dummy.go_to("Dbeg",10);
}              // Close if()
dbeg = (double)(i-500)/1001.0e0;
Dummy.go_to("Dbeg",999999);
// *
// *     End of DBEG.
// *
Dummy.label("Dbeg",999999);
return dbeg;
   }
} // End class.
