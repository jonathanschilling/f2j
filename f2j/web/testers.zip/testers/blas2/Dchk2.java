/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchk2 {

// *
// *  Tests DSYMV, DSBMV and DSPMV.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double als= 0.0;
static double beta= 0.0;
static double bls= 0.0;
static doubleW err= new doubleW(0.0);
static double errmax= 0.0;
static double transl= 0.0;
static int i= 0;
static int ia= 0;
static int ib= 0;
static int ic= 0;
static int ik= 0;
static int in= 0;
static int incx= 0;
static int incxs= 0;
static int incy= 0;
static int incys= 0;
static int ix= 0;
static int iy= 0;
static int k= 0;
static int ks= 0;
static int laa= 0;
static int lda= 0;
static int ldas= 0;
static int lx= 0;
static int ly= 0;
static int n= 0;
static int nargs= 0;
static int nc= 0;
static int nk= 0;
static int ns= 0;
static boolean banded= false;
static boolean full= false;
static boolean Null= false;
static boolean packed= false;
static booleanW reset= new booleanW(false);
static boolean same= false;
static String uplo= new String(" ");
static String uplos= new String(" ");
// *     .. Local Arrays ..
static boolean [] isame= new boolean[(13)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String ich = new String("UL");
// *     .. Executable Statements ..

public static void dchk2 (String sname,
double eps,
double thresh,
int nout,
int ntra,
boolean trace,
boolean rewi,
booleanW fatal,
int nidim,
int [] idim, int _idim_offset,
int nkb,
int [] kb, int _kb_offset,
int nalf,
double [] alf, int _alf_offset,
int nbet,
double [] bet, int _bet_offset,
int ninc,
int [] inc, int _inc_offset,
int nmax,
int incmax,
double [] a, int _a_offset,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
double [] x, int _x_offset,
double [] xx, int _xx_offset,
double [] xs, int _xs_offset,
double [] y, int _y_offset,
double [] yy, int _yy_offset,
double [] ys, int _ys_offset,
double [] yt, int _yt_offset,
double [] g, int _g_offset)  {

full = sname.substring((3)-1,3).trim().equalsIgnoreCase("Y".trim());
banded = sname.substring((3)-1,3).trim().equalsIgnoreCase("B".trim());
packed = sname.substring((3)-1,3).trim().equalsIgnoreCase("P".trim());
// *     Define the number of arguments.
if (full)  {
    nargs = 10;
}              // Close if()
else if (banded)  {
    nargs = 11;
}              // Close else if()
else if (packed)  {
    nargs = 9;
}              // Close else if()
// *
nc = 0;
reset.val = true;
errmax = zero;
// *
{
forloop110:
for (in = 1; in <= nidim; in++) {
n = idim[(in)- 1+ _idim_offset];
// *
if (banded)  {
    nk = nkb;
}              // Close if()
else  {
  nk = 1;
}              //  Close else.
{
forloop100:
for (ik = 1; ik <= nk; ik++) {
if (banded)  {
    k = kb[(ik)- 1+ _kb_offset];
}              // Close if()
else  {
  k = n-1;
}              //  Close else.
// *           Set LDA to 1 more than minimum value if room.
if (banded)  {
    lda = k+1;
}              // Close if()
else  {
  lda = n;
}              //  Close else.
if (lda < nmax)  
    lda = lda+1;
// *           Skip tests if not enough room.
if (lda > nmax)  
    continue forloop100;
if (packed)  {
    laa = (n*(n+1))/2;
}              // Close if()
else  {
  laa = lda*n;
}              //  Close else.
Null = n <= 0;
// *
{
forloop90:
for (ic = 1; ic <= 2; ic++) {
uplo = ich.substring((ic)-1,ic);
// *
// *              Generate the matrix A.
// *
transl = zero;
Dmake.dmake(sname.substring((2)-1,3),uplo," ",n,n,a,_a_offset,nmax,aa,_aa_offset,lda,k,k,reset,transl);
// *
{
forloop80:
for (ix = 1; ix <= ninc; ix++) {
incx = inc[(ix)- 1+ _inc_offset];
lx = (int)(Math.abs(incx)*n);
// *
// *                 Generate the vector X.
// *
transl = half;
Dmake.dmake("GE"," "," ",1,n,x,_x_offset,1,xx,_xx_offset,(int) ( Math.abs(incx)),0,n-1,reset,transl);
if (n > 1)  {
    x[(n/2)- 1+ _x_offset] = zero;
xx[(int)((1+Math.abs(incx)*(n/2-1))- 1+ _xx_offset)] = zero;
}              // Close if()
// *
{
forloop70:
for (iy = 1; iy <= ninc; iy++) {
incy = inc[(iy)- 1+ _inc_offset];
ly = (int)(Math.abs(incy)*n);
// *
{
forloop60:
for (ia = 1; ia <= nalf; ia++) {
alpha = alf[(ia)- 1+ _alf_offset];
// *
{
forloop50:
for (ib = 1; ib <= nbet; ib++) {
beta = bet[(ib)- 1+ _bet_offset];
// *
// *                          Generate the vector Y.
// *
transl = zero;
Dmake.dmake("GE"," "," ",1,n,y,_y_offset,1,yy,_yy_offset,(int) ( Math.abs(incy)),0,n-1,reset,transl);
// *
nc = nc+1;
// *
// *                          Save every datum before calling the
// *                          subroutine.
// *
uplos = uplo;
ns = n;
ks = k;
als = alpha;
{
forloop10:
for (i = 1; i <= laa; i++) {
as[(i)- 1+ _as_offset] = aa[(i)- 1+ _aa_offset];
Dummy.label("Dchk2",10);
}              //  Close for() loop. 
}
ldas = lda;
{
forloop20:
for (i = 1; i <= lx; i++) {
xs[(i)- 1+ _xs_offset] = xx[(i)- 1+ _xx_offset];
Dummy.label("Dchk2",20);
}              //  Close for() loop. 
}
incxs = incx;
bls = beta;
{
forloop30:
for (i = 1; i <= ly; i++) {
ys[(i)- 1+ _ys_offset] = yy[(i)- 1+ _yy_offset];
Dummy.label("Dchk2",30);
}              //  Close for() loop. 
}
incys = incy;
// *
// *                          Call the subroutine.
// *
if (full)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")             ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dsymv.dsymv(uplo,n,alpha,aa,_aa_offset,lda,xx,_xx_offset,incx,beta,yy,_yy_offset,incy);
}              // Close if()
else if (banded)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")         ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dsbmv.dsbmv(uplo,n,k,alpha,aa,_aa_offset,lda,xx,_xx_offset,incx,beta,yy,_yy_offset,incy);
}              // Close else if()
else if (packed)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (alpha) + " "  + ", AP"  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")                ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dspmv.dspmv(uplo,n,alpha,aa,_aa_offset,xx,_xx_offset,incx,beta,yy,_yy_offset,incy);
}              // Close else if()
// *
// *                          Check if error-exit was taken incorrectly.
// *
if (!blas2test_infoc.ok.val)  {
    System.out.println(" ******* FATAL ERROR - ERROR-EXIT TAKEN ON VALID CALL *"  + "******" );
fatal.val = true;
Dummy.go_to("Dchk2",120);
}              // Close if()
// *
// *                          See what data changed inside subroutines.
// *
isame[(1)- 1] = uplo.trim().equalsIgnoreCase(uplos.trim());
isame[(2)- 1] = ns == n;
if (full)  {
    isame[(3)- 1] = als == alpha;
isame[(4)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(5)- 1] = ldas == lda;
isame[(6)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
isame[(7)- 1] = incxs == incx;
isame[(8)- 1] = bls == beta;
if (Null)  {
    isame[(9)- 1] = Lde.lde(ys,_ys_offset,yy,_yy_offset,ly);
}              // Close if()
else  {
  isame[(9)- 1] = Lderes.lderes("GE"," ",1,n,ys,_ys_offset,yy,_yy_offset,(int) ( Math.abs(incy)));
}              //  Close else.
isame[(10)- 1] = incys == incy;
}              // Close if()
else if (banded)  {
    isame[(3)- 1] = ks == k;
isame[(4)- 1] = als == alpha;
isame[(5)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(6)- 1] = ldas == lda;
isame[(7)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
isame[(8)- 1] = incxs == incx;
isame[(9)- 1] = bls == beta;
if (Null)  {
    isame[(10)- 1] = Lde.lde(ys,_ys_offset,yy,_yy_offset,ly);
}              // Close if()
else  {
  isame[(10)- 1] = Lderes.lderes("GE"," ",1,n,ys,_ys_offset,yy,_yy_offset,(int) ( Math.abs(incy)));
}              //  Close else.
isame[(11)- 1] = incys == incy;
}              // Close else if()
else if (packed)  {
    isame[(3)- 1] = als == alpha;
isame[(4)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(5)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
isame[(6)- 1] = incxs == incx;
isame[(7)- 1] = bls == beta;
if (Null)  {
    isame[(8)- 1] = Lde.lde(ys,_ys_offset,yy,_yy_offset,ly);
}              // Close if()
else  {
  isame[(8)- 1] = Lderes.lderes("GE"," ",1,n,ys,_ys_offset,yy,_yy_offset,(int) ( Math.abs(incy)));
}              //  Close else.
isame[(9)- 1] = incys == incy;
}              // Close else if()
// *
// *                          If data was incorrectly changed, report and
// *                          return.
// *
same = true;
{
forloop40:
for (i = 1; i <= nargs; i++) {
same = same && isame[(i)- 1];
if (!isame[(i)- 1])  
    System.out.println(" ******* FATAL ERROR - PARAMETER NUMBER "  + (i) + " "  + " WAS CH"  + "ANGED INCORRECTLY *******" );
Dummy.label("Dchk2",40);
}              //  Close for() loop. 
}
if (!same)  {
    fatal.val = true;
Dummy.go_to("Dchk2",120);
}              // Close if()
// *
if (!Null)  {
    // *
// *                             Check the result.
// *
Dmvch.dmvch("N",n,n,alpha,a,_a_offset,nmax,x,_x_offset,incx,beta,y,_y_offset,incy,yt,_yt_offset,g,_g_offset,yy,_yy_offset,eps,err,fatal,nout,true);
errmax = Math.max(errmax, err.val) ;
// *                             If got really bad answer, report and
// *                             return.
if (fatal.val)  
    Dummy.go_to("Dchk2",120);
}              // Close if()
else  {
  // *                             Avoid repeating tests with N.le.0
continue forloop110;
}              //  Close else.
// *
Dummy.label("Dchk2",50);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",60);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",70);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",90);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",100);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",110);
}              //  Close for() loop. 
}
// *
// *     Report result.
// *
if (errmax < thresh)  {
    System.out.println(" "  + (sname) + " "  + " PASSED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " CALL"  + "S)" );
}              // Close if()
else  {
  System.out.println(" "  + (sname) + " "  + " COMPLETED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " C"  + "ALLS)"  + "\n"  + " ******* BUT WITH MAXIMUM TEST RATIO"  + (errmax) + " "  + " - SUSPECT *******" );
}              //  Close else.
Dummy.go_to("Dchk2",130);
// *
label120:
   Dummy.label("Dchk2",120);
System.out.println(" ******* "  + (sname) + " "  + " FAILED ON CALL NUMBER:" );
if (full)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")             ." );
}              // Close if()
else if (banded)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")         ." );
}              // Close else if()
else if (packed)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "(\'"  + (uplo) + " "  + "\',"  + (n) + " "  + ","  + (alpha) + " "  + ", AP"  + ", X,"  + (incx) + " "  + ","  + (beta) + " "  + ", Y,"  + (incy) + " "  + ")                ." );
}              // Close else if()
// *
label130:
   Dummy.label("Dchk2",130);
Dummy.go_to("Dchk2",999999);
// *
// *
// *     End of DCHK2.
// *
Dummy.label("Dchk2",999999);
return;
   }
} // End class.
