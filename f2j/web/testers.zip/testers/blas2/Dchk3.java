/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchk3 {

// *
// *  Tests DTRMV, DTBMV, DTPMV, DTRSV, DTBSV and DTPSV.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static doubleW err= new doubleW(0.0);
static double errmax= 0.0;
static double transl= 0.0;
static int i= 0;
static int icd= 0;
static int ict= 0;
static int icu= 0;
static int ik= 0;
static int in= 0;
static int incx= 0;
static int incxs= 0;
static int ix= 0;
static int k= 0;
static int ks= 0;
static int laa= 0;
static int lda= 0;
static int ldas= 0;
static int lx= 0;
static int n= 0;
static int nargs= 0;
static int nc= 0;
static int nk= 0;
static int ns= 0;
static boolean banded= false;
static boolean full= false;
static boolean Null= false;
static boolean packed= false;
static booleanW reset= new booleanW(false);
static boolean same= false;
static String diag= new String(" ");
static String diags= new String(" ");
static String trans= new String(" ");
static String transs= new String(" ");
static String uplo= new String(" ");
static String uplos= new String(" ");
// *     .. Local Arrays ..
static boolean [] isame= new boolean[(13)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String ichd = new String("UN");
static String icht = new String("NTC");
static String ichu = new String("UL");
// *     .. Executable Statements ..

public static void dchk3 (String sname,
double eps,
double thresh,
int nout,
int ntra,
boolean trace,
boolean rewi,
booleanW fatal,
int nidim,
int [] idim, int _idim_offset,
int nkb,
int [] kb, int _kb_offset,
int ninc,
int [] inc, int _inc_offset,
int nmax,
int incmax,
double [] a, int _a_offset,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
double [] x, int _x_offset,
double [] xx, int _xx_offset,
double [] xs, int _xs_offset,
double [] xt, int _xt_offset,
double [] g, int _g_offset,
double [] z, int _z_offset)  {

full = sname.substring((3)-1,3).trim().equalsIgnoreCase("R".trim());
banded = sname.substring((3)-1,3).trim().equalsIgnoreCase("B".trim());
packed = sname.substring((3)-1,3).trim().equalsIgnoreCase("P".trim());
// *     Define the number of arguments.
if (full)  {
    nargs = 8;
}              // Close if()
else if (banded)  {
    nargs = 9;
}              // Close else if()
else if (packed)  {
    nargs = 7;
}              // Close else if()
// *
nc = 0;
reset.val = true;
errmax = zero;
// *     Set up zero vector for DMVCH.
{
forloop10:
for (i = 1; i <= nmax; i++) {
z[(i)- 1+ _z_offset] = zero;
Dummy.label("Dchk3",10);
}              //  Close for() loop. 
}
// *
{
forloop110:
for (in = 1; in <= nidim; in++) {
n = idim[(in)- 1+ _idim_offset];
// *
if (banded)  {
    nk = nkb;
}              // Close if()
else  {
  nk = 1;
}              //  Close else.
{
forloop100:
for (ik = 1; ik <= nk; ik++) {
if (banded)  {
    k = kb[(ik)- 1+ _kb_offset];
}              // Close if()
else  {
  k = n-1;
}              //  Close else.
// *           Set LDA to 1 more than minimum value if room.
if (banded)  {
    lda = k+1;
}              // Close if()
else  {
  lda = n;
}              //  Close else.
if (lda < nmax)  
    lda = lda+1;
// *           Skip tests if not enough room.
if (lda > nmax)  
    continue forloop100;
if (packed)  {
    laa = (n*(n+1))/2;
}              // Close if()
else  {
  laa = lda*n;
}              //  Close else.
Null = n <= 0;
// *
{
forloop90:
for (icu = 1; icu <= 2; icu++) {
uplo = ichu.substring((icu)-1,icu);
// *
{
forloop80:
for (ict = 1; ict <= 3; ict++) {
trans = icht.substring((ict)-1,ict);
// *
{
forloop70:
for (icd = 1; icd <= 2; icd++) {
diag = ichd.substring((icd)-1,icd);
// *
// *                    Generate the matrix A.
// *
transl = zero;
Dmake.dmake(sname.substring((2)-1,3),uplo,diag,n,n,a,_a_offset,nmax,aa,_aa_offset,lda,k,k,reset,transl);
// *
{
forloop60:
for (ix = 1; ix <= ninc; ix++) {
incx = inc[(ix)- 1+ _inc_offset];
lx = (int)(Math.abs(incx)*n);
// *
// *                       Generate the vector X.
// *
transl = half;
Dmake.dmake("GE"," "," ",1,n,x,_x_offset,1,xx,_xx_offset,(int) ( Math.abs(incx)),0,n-1,reset,transl);
if (n > 1)  {
    x[(n/2)- 1+ _x_offset] = zero;
xx[(int)((1+Math.abs(incx)*(n/2-1))- 1+ _xx_offset)] = zero;
}              // Close if()
// *
nc = nc+1;
// *
// *                       Save every datum before calling the subroutine.
// *
uplos = uplo;
transs = trans;
diags = diag;
ns = n;
ks = k;
{
forloop20:
for (i = 1; i <= laa; i++) {
as[(i)- 1+ _as_offset] = aa[(i)- 1+ _aa_offset];
Dummy.label("Dchk3",20);
}              //  Close for() loop. 
}
ldas = lda;
{
forloop30:
for (i = 1; i <= lx; i++) {
xs[(i)- 1+ _xs_offset] = xx[(i)- 1+ _xx_offset];
Dummy.label("Dchk3",30);
}              //  Close for() loop. 
}
incxs = incx;
// *
// *                       Call the subroutine.
// *
if (sname.substring((4)-1,5).trim().equalsIgnoreCase("MV".trim()))  {
    if (full)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                     ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtrmv.dtrmv(uplo,trans,diag,n,aa,_aa_offset,lda,xx,_xx_offset,incx);
}              // Close if()
else if (banded)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + " A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                 ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtbmv.dtbmv(uplo,trans,diag,n,k,aa,_aa_offset,lda,xx,_xx_offset,incx);
}              // Close else if()
else if (packed)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", AP, "  + "X,"  + (incx) + " "  + ")                        ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtpmv.dtpmv(uplo,trans,diag,n,aa,_aa_offset,xx,_xx_offset,incx);
}              // Close else if()
}              // Close if()
else if (sname.substring((4)-1,5).trim().equalsIgnoreCase("SV".trim()))  {
    if (full)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                     ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtrsv.dtrsv(uplo,trans,diag,n,aa,_aa_offset,lda,xx,_xx_offset,incx);
}              // Close if()
else if (banded)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + " A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                 ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtbsv.dtbsv(uplo,trans,diag,n,k,aa,_aa_offset,lda,xx,_xx_offset,incx);
}              // Close else if()
else if (packed)  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", AP, "  + "X,"  + (incx) + " "  + ")                        ." );
// *                             IF( REWI )
// *    $                           REWIND NTRA
Dtpsv.dtpsv(uplo,trans,diag,n,aa,_aa_offset,xx,_xx_offset,incx);
}              // Close else if()
}              // Close else if()
// *
// *                       Check if error-exit was taken incorrectly.
// *
if (!blas2test_infoc.ok.val)  {
    System.out.println(" ******* FATAL ERROR - ERROR-EXIT TAKEN ON VALID CALL *"  + "******" );
fatal.val = true;
Dummy.go_to("Dchk3",120);
}              // Close if()
// *
// *                       See what data changed inside subroutines.
// *
isame[(1)- 1] = uplo.trim().equalsIgnoreCase(uplos.trim());
isame[(2)- 1] = trans.trim().equalsIgnoreCase(transs.trim());
isame[(3)- 1] = diag.trim().equalsIgnoreCase(diags.trim());
isame[(4)- 1] = ns == n;
if (full)  {
    isame[(5)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(6)- 1] = ldas == lda;
if (Null)  {
    isame[(7)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
}              // Close if()
else  {
  isame[(7)- 1] = Lderes.lderes("GE"," ",1,n,xs,_xs_offset,xx,_xx_offset,(int) ( Math.abs(incx)));
}              //  Close else.
isame[(8)- 1] = incxs == incx;
}              // Close if()
else if (banded)  {
    isame[(5)- 1] = ks == k;
isame[(6)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(7)- 1] = ldas == lda;
if (Null)  {
    isame[(8)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
}              // Close if()
else  {
  isame[(8)- 1] = Lderes.lderes("GE"," ",1,n,xs,_xs_offset,xx,_xx_offset,(int) ( Math.abs(incx)));
}              //  Close else.
isame[(9)- 1] = incxs == incx;
}              // Close else if()
else if (packed)  {
    isame[(5)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
if (Null)  {
    isame[(6)- 1] = Lde.lde(xs,_xs_offset,xx,_xx_offset,lx);
}              // Close if()
else  {
  isame[(6)- 1] = Lderes.lderes("GE"," ",1,n,xs,_xs_offset,xx,_xx_offset,(int) ( Math.abs(incx)));
}              //  Close else.
isame[(7)- 1] = incxs == incx;
}              // Close else if()
// *
// *                       If data was incorrectly changed, report and
// *                       return.
// *
same = true;
{
forloop40:
for (i = 1; i <= nargs; i++) {
same = same && isame[(i)- 1];
if (!isame[(i)- 1])  
    System.out.println(" ******* FATAL ERROR - PARAMETER NUMBER "  + (i) + " "  + " WAS CH"  + "ANGED INCORRECTLY *******" );
Dummy.label("Dchk3",40);
}              //  Close for() loop. 
}
if (!same)  {
    fatal.val = true;
Dummy.go_to("Dchk3",120);
}              // Close if()
// *
if (!Null)  {
    if (sname.substring((4)-1,5).trim().equalsIgnoreCase("MV".trim()))  {
    // *
// *                             Check the result.
// *
Dmvch.dmvch(trans,n,n,one,a,_a_offset,nmax,x,_x_offset,incx,zero,z,_z_offset,incx,xt,_xt_offset,g,_g_offset,xx,_xx_offset,eps,err,fatal,nout,true);
}              // Close if()
else if (sname.substring((4)-1,5).trim().equalsIgnoreCase("SV".trim()))  {
    // *
// *                             Compute approximation to original vector.
// *
{
forloop50:
for (i = 1; i <= n; i++) {
z[(i)- 1+ _z_offset] = xx[(int)((1+(i-1)*Math.abs(incx))- 1+ _xx_offset)];
xx[(int)((1+(i-1)*Math.abs(incx))- 1+ _xx_offset)] = x[(i)- 1+ _x_offset];
Dummy.label("Dchk3",50);
}              //  Close for() loop. 
}
Dmvch.dmvch(trans,n,n,one,a,_a_offset,nmax,z,_z_offset,incx,zero,x,_x_offset,incx,xt,_xt_offset,g,_g_offset,xx,_xx_offset,eps,err,fatal,nout,false);
}              // Close else if()
errmax = Math.max(errmax, err.val) ;
// *                          If got really bad answer, report and return.
if (fatal.val)  
    Dummy.go_to("Dchk3",120);
}              // Close if()
else  {
  // *                          Avoid repeating tests with N.le.0.
continue forloop110;
}              //  Close else.
// *
Dummy.label("Dchk3",60);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",70);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",90);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",100);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",110);
}              //  Close for() loop. 
}
// *
// *     Report result.
// *
if (errmax < thresh)  {
    System.out.println(" "  + (sname) + " "  + " PASSED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " CALL"  + "S)" );
}              // Close if()
else  {
  System.out.println(" "  + (sname) + " "  + " COMPLETED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " C"  + "ALLS)"  + "\n"  + " ******* BUT WITH MAXIMUM TEST RATIO"  + (errmax) + " "  + " - SUSPECT *******" );
}              //  Close else.
Dummy.go_to("Dchk3",130);
// *
label120:
   Dummy.label("Dchk3",120);
System.out.println(" ******* "  + (sname) + " "  + " FAILED ON CALL NUMBER:" );
if (full)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                     ." );
}              // Close if()
else if (banded)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + " A,"  + (lda) + " "  + ", X,"  + (incx) + " "  + ")                 ." );
}              // Close else if()
else if (packed)  {
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (n) + " "  + ", AP, "  + "X,"  + (incx) + " "  + ")                        ." );
}              // Close else if()
// *
label130:
   Dummy.label("Dchk3",130);
Dummy.go_to("Dchk3",999999);
// *
// *
// *     End of DCHK3.
// *
Dummy.label("Dchk3",999999);
return;
   }
} // End class.
