/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchke {

// *
// *  Tests the error exits from the Level 2 Blas.
// *  Requires a special version of the error-handling routine XERBLA.
// *  ALPHA, BETA, A, X and Y should not need to be defined.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double beta= 0.0;
// *     .. Local Arrays ..
static double [] a= new double[(1) * (1)];
static double [] x= new double[(1)];
static double [] y= new double[(1)];
// *     .. External Subroutines ..
// *     .. Common blocks ..
// *     .. Executable Statements ..
// *     OK is set to .FALSE. by the special version of XERBLA or by CHKXER
// *     if anything is wrong.

public static void dchke (int isnum,
String srnamt,
int nout)  {

blas2test_infoc.ok.val = true;
// *     LERR is set to .TRUE. by the special version of XERBLA each time
// *     it is called, and is then tested and re-set by CHKXER.
blas2test_infoc.lerr.val = false;
if (isnum == 1) 
  Dummy.go_to("Dchke",10);
else if (isnum == 2) 
  Dummy.go_to("Dchke",20);
else if (isnum == 3) 
  Dummy.go_to("Dchke",30);
else if (isnum == 4) 
  Dummy.go_to("Dchke",40);
else if (isnum == 5) 
  Dummy.go_to("Dchke",50);
else if (isnum == 6) 
  Dummy.go_to("Dchke",60);
else if (isnum == 7) 
  Dummy.go_to("Dchke",70);
else if (isnum == 8) 
  Dummy.go_to("Dchke",80);
else if (isnum == 9) 
  Dummy.go_to("Dchke",90);
else if (isnum == 10) 
  Dummy.go_to("Dchke",100);
else if (isnum == 11) 
  Dummy.go_to("Dchke",110);
else if (isnum == 12) 
  Dummy.go_to("Dchke",120);
else if (isnum == 13) 
  Dummy.go_to("Dchke",130);
else if (isnum == 14) 
  Dummy.go_to("Dchke",140);
else if (isnum == 15) 
  Dummy.go_to("Dchke",150);
else if (isnum == 16) 
  Dummy.go_to("Dchke",160);
label10:
   Dummy.label("Dchke",10);
blas2test_infoc.infot = 1;
Dgemv.dgemv("/",0,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dgemv.dgemv("N",-1,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dgemv.dgemv("N",0,-1,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 6;
Dgemv.dgemv("N",2,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 8;
Dgemv.dgemv("N",0,0,alpha,a,0,1,x,0,0,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 11;
Dgemv.dgemv("N",0,0,alpha,a,0,1,x,0,1,beta,y,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label20:
   Dummy.label("Dchke",20);
blas2test_infoc.infot = 1;
Dgbmv.dgbmv("/",0,0,0,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dgbmv.dgbmv("N",-1,0,0,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dgbmv.dgbmv("N",0,-1,0,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dgbmv.dgbmv("N",0,0,-1,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dgbmv.dgbmv("N",2,0,0,-1,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 8;
Dgbmv.dgbmv("N",0,0,1,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 10;
Dgbmv.dgbmv("N",0,0,0,0,alpha,a,0,1,x,0,0,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 13;
Dgbmv.dgbmv("N",0,0,0,0,alpha,a,0,1,x,0,1,beta,y,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label30:
   Dummy.label("Dchke",30);
blas2test_infoc.infot = 1;
Dsymv.dsymv("/",0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dsymv.dsymv("U",-1,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dsymv.dsymv("U",2,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dsymv.dsymv("U",0,alpha,a,0,1,x,0,0,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 10;
Dsymv.dsymv("U",0,alpha,a,0,1,x,0,1,beta,y,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label40:
   Dummy.label("Dchke",40);
blas2test_infoc.infot = 1;
Dsbmv.dsbmv("/",0,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dsbmv.dsbmv("U",-1,0,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dsbmv.dsbmv("U",0,-1,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 6;
Dsbmv.dsbmv("U",0,1,alpha,a,0,1,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 8;
Dsbmv.dsbmv("U",0,0,alpha,a,0,1,x,0,0,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 11;
Dsbmv.dsbmv("U",0,0,alpha,a,0,1,x,0,1,beta,y,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label50:
   Dummy.label("Dchke",50);
blas2test_infoc.infot = 1;
Dspmv.dspmv("/",0,alpha,a,0,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dspmv.dspmv("U",-1,alpha,a,0,x,0,1,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 6;
Dspmv.dspmv("U",0,alpha,a,0,x,0,0,beta,y,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 9;
Dspmv.dspmv("U",0,alpha,a,0,x,0,1,beta,y,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label60:
   Dummy.label("Dchke",60);
blas2test_infoc.infot = 1;
Dtrmv.dtrmv("/","N","N",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtrmv.dtrmv("U","/","N",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtrmv.dtrmv("U","N","/",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtrmv.dtrmv("U","N","N",-1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 6;
Dtrmv.dtrmv("U","N","N",2,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 8;
Dtrmv.dtrmv("U","N","N",0,a,0,1,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label70:
   Dummy.label("Dchke",70);
blas2test_infoc.infot = 1;
Dtbmv.dtbmv("/","N","N",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtbmv.dtbmv("U","/","N",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtbmv.dtbmv("U","N","/",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtbmv.dtbmv("U","N","N",-1,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dtbmv.dtbmv("U","N","N",0,-1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dtbmv.dtbmv("U","N","N",0,1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 9;
Dtbmv.dtbmv("U","N","N",0,0,a,0,1,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label80:
   Dummy.label("Dchke",80);
blas2test_infoc.infot = 1;
Dtpmv.dtpmv("/","N","N",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtpmv.dtpmv("U","/","N",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtpmv.dtpmv("U","N","/",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtpmv.dtpmv("U","N","N",-1,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dtpmv.dtpmv("U","N","N",0,a,0,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label90:
   Dummy.label("Dchke",90);
blas2test_infoc.infot = 1;
Dtrsv.dtrsv("/","N","N",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtrsv.dtrsv("U","/","N",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtrsv.dtrsv("U","N","/",0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtrsv.dtrsv("U","N","N",-1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 6;
Dtrsv.dtrsv("U","N","N",2,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 8;
Dtrsv.dtrsv("U","N","N",0,a,0,1,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label100:
   Dummy.label("Dchke",100);
blas2test_infoc.infot = 1;
Dtbsv.dtbsv("/","N","N",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtbsv.dtbsv("U","/","N",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtbsv.dtbsv("U","N","/",0,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtbsv.dtbsv("U","N","N",-1,0,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dtbsv.dtbsv("U","N","N",0,-1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dtbsv.dtbsv("U","N","N",0,1,a,0,1,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 9;
Dtbsv.dtbsv("U","N","N",0,0,a,0,1,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label110:
   Dummy.label("Dchke",110);
blas2test_infoc.infot = 1;
Dtpsv.dtpsv("/","N","N",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dtpsv.dtpsv("U","/","N",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 3;
Dtpsv.dtpsv("U","N","/",0,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 4;
Dtpsv.dtpsv("U","N","N",-1,a,0,x,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dtpsv.dtpsv("U","N","N",0,a,0,x,0,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label120:
   Dummy.label("Dchke",120);
blas2test_infoc.infot = 1;
Dger.dger(-1,0,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dger.dger(0,-1,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dger.dger(0,0,alpha,x,0,0,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dger.dger(0,0,alpha,x,0,1,y,0,0,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 9;
Dger.dger(2,0,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label130:
   Dummy.label("Dchke",130);
blas2test_infoc.infot = 1;
Dsyr.dsyr("/",0,alpha,x,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dsyr.dsyr("U",-1,alpha,x,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dsyr.dsyr("U",0,alpha,x,0,0,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dsyr.dsyr("U",2,alpha,x,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label140:
   Dummy.label("Dchke",140);
blas2test_infoc.infot = 1;
Dspr.dspr("/",0,alpha,x,0,1,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dspr.dspr("U",-1,alpha,x,0,1,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dspr.dspr("U",0,alpha,x,0,0,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label150:
   Dummy.label("Dchke",150);
blas2test_infoc.infot = 1;
Dsyr2.dsyr2("/",0,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dsyr2.dsyr2("U",-1,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dsyr2.dsyr2("U",0,alpha,x,0,0,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dsyr2.dsyr2("U",0,alpha,x,0,1,y,0,0,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 9;
Dsyr2.dsyr2("U",2,alpha,x,0,1,y,0,1,a,0,1);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
Dummy.go_to("Dchke",170);
label160:
   Dummy.label("Dchke",160);
blas2test_infoc.infot = 1;
Dspr2.dspr2("/",0,alpha,x,0,1,y,0,1,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 2;
Dspr2.dspr2("U",-1,alpha,x,0,1,y,0,1,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 5;
Dspr2.dspr2("U",0,alpha,x,0,0,y,0,1,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
blas2test_infoc.infot = 7;
Dspr2.dspr2("U",0,alpha,x,0,1,y,0,0,a,0);
Chkxer.chkxer(srnamt,blas2test_infoc.infot,nout,blas2test_infoc.lerr,blas2test_infoc.ok);
// *
label170:
   Dummy.label("Dchke",170);
if (blas2test_infoc.ok.val)  {
    System.out.println(" "  + (srnamt) + " "  + " PASSED THE TESTS OF ERROR-EXITS" );
}              // Close if()
else  {
  System.out.println(" ******* "  + (srnamt) + " "  + " FAILED THE TESTS OF ERROR-EXITS *****"  + "**" );
}              //  Close else.
Dummy.go_to("Dchke",999999);
// *
// *
// *     End of DCHKE.
// *
Dummy.label("Dchke",999999);
return;
   }
} // End class.
