/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Ddiff {

// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *
// *     .. Scalar Arguments ..
// *     .. Executable Statements ..
static double ddiff = 0.0;


public static double ddiff (double x,
double y)  {

ddiff = x-y;
Dummy.go_to("Ddiff",999999);
// *
// *     End of DDIFF.
// *
Dummy.label("Ddiff",999999);
return ddiff;
   }
} // End class.
