/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dmake {

// *
// *  Generates values for an M by N matrix A within the bandwidth
// *  defined by KL and KU.
// *  Stores the values in the array AA in the data structure required
// *  by the routine, with unwanted elements set to rogue value.
// *
// *  TYPE is 'GE', 'GB', 'SY', 'SB', 'SP', 'TR', 'TB' OR 'TP'.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double rogue= -1.0e10;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static int i= 0;
static int i1= 0;
static int i2= 0;
static int i3= 0;
static int ibeg= 0;
static int iend= 0;
static int ioff= 0;
static int j= 0;
static int kk= 0;
static boolean gen= false;
static boolean lower= false;
static boolean sym= false;
static boolean tri= false;
static boolean unit= false;
static boolean upper= false;
// *     .. External Functions ..
// *     .. Intrinsic Functions ..
// *     .. Executable Statements ..

public static void dmake (String type,
String uplo,
String diag,
int m,
int n,
double [] a, int _a_offset,
int nmax,
double [] aa, int _aa_offset,
int lda,
int kl,
int ku,
booleanW reset,
double transl)  {

gen = type.substring((1)-1,1).trim().equalsIgnoreCase("G".trim());
sym = type.substring((1)-1,1).trim().equalsIgnoreCase("S".trim());
tri = type.substring((1)-1,1).trim().equalsIgnoreCase("T".trim());
upper = (sym || tri) && uplo.trim().equalsIgnoreCase("U".trim());
lower = (sym || tri) && uplo.trim().equalsIgnoreCase("L".trim());
unit = tri && diag.trim().equalsIgnoreCase("U".trim());
// *
// *     Generate data in array A.
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= m; i++) {
if (gen || (upper && i <= j) || (lower && i >= j))  {
    if ((i <= j && j-i <= ku) || (i >= j && i-j <= kl))  {
    a[(i)- 1+(j- 1)*nmax+ _a_offset] = Dbeg.dbeg(reset)+transl;
}              // Close if()
else  {
  a[(i)- 1+(j- 1)*nmax+ _a_offset] = zero;
}              //  Close else.
if (i != j)  {
    if (sym)  {
    a[(j)- 1+(i- 1)*nmax+ _a_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
}              // Close if()
else if (tri)  {
    a[(j)- 1+(i- 1)*nmax+ _a_offset] = zero;
}              // Close else if()
}              // Close if()
}              // Close if()
Dummy.label("Dmake",10);
}              //  Close for() loop. 
}
if (tri)  
    a[(j)- 1+(j- 1)*nmax+ _a_offset] = a[(j)- 1+(j- 1)*nmax+ _a_offset]+one;
if (unit)  
    a[(j)- 1+(j- 1)*nmax+ _a_offset] = one;
Dummy.label("Dmake",20);
}              //  Close for() loop. 
}
// *
// *     Store elements in array AS in data structure required by routine.
// *
if (type.trim().equalsIgnoreCase("GE".trim()))  {
    {
forloop50:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= m; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",30);
}              //  Close for() loop. 
}
{
forloop40:
for (i = m+1; i <= lda; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",40);
}              //  Close for() loop. 
}
Dummy.label("Dmake",50);
}              //  Close for() loop. 
}
}              // Close if()
else if (type.trim().equalsIgnoreCase("GB".trim()))  {
    {
forloop90:
for (j = 1; j <= n; j++) {
{
forloop60:
for (i1 = 1; i1 <= ku+1-j; i1++) {
aa[(i1+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",60);
}              //  Close for() loop. 
}
{
forloop70:
for (i2 = i1; i2 <= Math.min(kl+ku+1, ku+1+m-j) ; i2++) {
aa[(i2+(j-1)*lda)- 1+ _aa_offset] = a[(i2+j-ku-1)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",70);
}              //  Close for() loop. 
}
{
forloop80:
for (i3 = i2; i3 <= lda; i3++) {
aa[(i3+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",80);
}              //  Close for() loop. 
}
Dummy.label("Dmake",90);
}              //  Close for() loop. 
}
}              // Close else if()
else if (type.trim().equalsIgnoreCase("SY".trim()) || type.trim().equalsIgnoreCase("TR".trim()))  {
    {
forloop130:
for (j = 1; j <= n; j++) {
if (upper)  {
    ibeg = 1;
if (unit)  {
    iend = j-1;
}              // Close if()
else  {
  iend = j;
}              //  Close else.
}              // Close if()
else  {
  if (unit)  {
    ibeg = j+1;
}              // Close if()
else  {
  ibeg = j;
}              //  Close else.
iend = n;
}              //  Close else.
{
forloop100:
for (i = 1; i <= ibeg-1; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",100);
}              //  Close for() loop. 
}
{
forloop110:
for (i = ibeg; i <= iend; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",110);
}              //  Close for() loop. 
}
{
forloop120:
for (i = iend+1; i <= lda; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",120);
}              //  Close for() loop. 
}
Dummy.label("Dmake",130);
}              //  Close for() loop. 
}
}              // Close else if()
else if (type.trim().equalsIgnoreCase("SB".trim()) || type.trim().equalsIgnoreCase("TB".trim()))  {
    {
forloop170:
for (j = 1; j <= n; j++) {
if (upper)  {
    kk = kl+1;
ibeg = (int)(Math.max(1, kl+2-j) );
if (unit)  {
    iend = kl;
}              // Close if()
else  {
  iend = kl+1;
}              //  Close else.
}              // Close if()
else  {
  kk = 1;
if (unit)  {
    ibeg = 2;
}              // Close if()
else  {
  ibeg = 1;
}              //  Close else.
iend = (int)(Math.min(kl+1, 1+m-j) );
}              //  Close else.
{
forloop140:
for (i = 1; i <= ibeg-1; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",140);
}              //  Close for() loop. 
}
{
forloop150:
for (i = ibeg; i <= iend; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = a[(i+j-kk)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",150);
}              //  Close for() loop. 
}
{
forloop160:
for (i = iend+1; i <= lda; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",160);
}              //  Close for() loop. 
}
Dummy.label("Dmake",170);
}              //  Close for() loop. 
}
}              // Close else if()
else if (type.trim().equalsIgnoreCase("SP".trim()) || type.trim().equalsIgnoreCase("TP".trim()))  {
    ioff = 0;
{
forloop190:
for (j = 1; j <= n; j++) {
if (upper)  {
    ibeg = 1;
iend = j;
}              // Close if()
else  {
  ibeg = j;
iend = n;
}              //  Close else.
{
forloop180:
for (i = ibeg; i <= iend; i++) {
ioff = ioff+1;
aa[(ioff)- 1+ _aa_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
if (i == j)  {
    if (unit)  
    aa[(ioff)- 1+ _aa_offset] = rogue;
}              // Close if()
Dummy.label("Dmake",180);
}              //  Close for() loop. 
}
Dummy.label("Dmake",190);
}              //  Close for() loop. 
}
}              // Close else if()
Dummy.go_to("Dmake",999999);
// *
// *     End of DMAKE.
// *
Dummy.label("Dmake",999999);
return;
   }
} // End class.
