/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas2test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dmvch {

// *
// *  Checks the results of the computational tests.
// *
// *  Auxiliary routine for test program for Level 2 Blas.
// *
// *  -- Written on 10-August-1987.
// *     Richard Hanson, Sandia National Labs.
// *     Jeremy Du Croz, NAG Central Office.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double erri= 0.0;
static int i= 0;
static int incxl= 0;
static int incyl= 0;
static int iy= 0;
static int j= 0;
static int jx= 0;
static int kx= 0;
static int ky= 0;
static int ml= 0;
static int nl= 0;
static boolean tran= false;
// *     .. Intrinsic Functions ..
// *     .. Executable Statements ..

public static void dmvch (String trans,
int m,
int n,
double alpha,
double [] a, int _a_offset,
int nmax,
double [] x, int _x_offset,
int incx,
double beta,
double [] y, int _y_offset,
int incy,
double [] yt, int _yt_offset,
double [] g, int _g_offset,
double [] yy, int _yy_offset,
double eps,
doubleW err,
booleanW fatal,
int nout,
boolean mv)  {

tran = trans.trim().equalsIgnoreCase("T".trim()) || trans.trim().equalsIgnoreCase("C".trim());
if (tran)  {
    ml = n;
nl = m;
}              // Close if()
else  {
  ml = m;
nl = n;
}              //  Close else.
if (incx < 0)  {
    kx = nl;
incxl = -1;
}              // Close if()
else  {
  kx = 1;
incxl = 1;
}              //  Close else.
if (incy < 0)  {
    ky = ml;
incyl = -1;
}              // Close if()
else  {
  ky = 1;
incyl = 1;
}              //  Close else.
// *
// *     Compute expected result in YT using data in A, X and Y.
// *     Compute gauges in G.
// *
iy = ky;
{
forloop30:
for (i = 1; i <= ml; i++) {
yt[(iy)- 1+ _yt_offset] = zero;
g[(iy)- 1+ _g_offset] = zero;
jx = kx;
if (tran)  {
    {
forloop10:
for (j = 1; j <= nl; j++) {
yt[(iy)- 1+ _yt_offset] = yt[(iy)- 1+ _yt_offset]+a[(j)- 1+(i- 1)*nmax+ _a_offset]*x[(jx)- 1+ _x_offset];
g[(iy)- 1+ _g_offset] = g[(iy)- 1+ _g_offset]+Math.abs(a[(j)- 1+(i- 1)*nmax+ _a_offset]*x[(jx)- 1+ _x_offset]);
jx = jx+incxl;
Dummy.label("Dmvch",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop20:
for (j = 1; j <= nl; j++) {
yt[(iy)- 1+ _yt_offset] = yt[(iy)- 1+ _yt_offset]+a[(i)- 1+(j- 1)*nmax+ _a_offset]*x[(jx)- 1+ _x_offset];
g[(iy)- 1+ _g_offset] = g[(iy)- 1+ _g_offset]+Math.abs(a[(i)- 1+(j- 1)*nmax+ _a_offset]*x[(jx)- 1+ _x_offset]);
jx = jx+incxl;
Dummy.label("Dmvch",20);
}              //  Close for() loop. 
}
}              //  Close else.
yt[(iy)- 1+ _yt_offset] = alpha*yt[(iy)- 1+ _yt_offset]+beta*y[(iy)- 1+ _y_offset];
g[(iy)- 1+ _g_offset] = Math.abs(alpha)*g[(iy)- 1+ _g_offset]+Math.abs(beta*y[(iy)- 1+ _y_offset]);
iy = iy+incyl;
Dummy.label("Dmvch",30);
}              //  Close for() loop. 
}
// *
// *     Compute the error ratio for this result.
// *
err.val = zero;
{
forloop40:
for (i = 1; i <= ml; i++) {
erri = Math.abs(yt[(i)- 1+ _yt_offset]-yy[(int)((1+(i-1)*Math.abs(incy))- 1+ _yy_offset)])/eps;
if (g[(i)- 1+ _g_offset] != zero)  
    erri = erri/g[(i)- 1+ _g_offset];
err.val = Math.max(err.val, erri) ;
if (err.val*Math.sqrt(eps) >= one)  
    Dummy.go_to("Dmvch",50);
Dummy.label("Dmvch",40);
}              //  Close for() loop. 
}
// *     If the loop completes, all results are at least half accurate.
Dummy.go_to("Dmvch",70);
// *
// *     Report fatal error.
// *
label50:
   Dummy.label("Dmvch",50);
fatal.val = true;
System.out.println(" ******* FATAL ERROR - COMPUTED RESULT IS LESS THAN HAL"  + "F ACCURATE *******"  + "\n"  + "           EXPECTED RESULT   COMPU"  + "TED RESULT" );
{
forloop60:
for (i = 1; i <= ml; i++) {
if (mv)  {
    System.out.println(" " + (i) + " "  + (yt[(i)- 1+ _yt_offset]) + " " );
}              // Close if()
else  {
  System.out.println(" " + (i) + " "  + (yy[(int)((1+(i-1)*Math.abs(incy))- 1+ _yy_offset)]) + " " );
}              //  Close else.
Dummy.label("Dmvch",60);
}              //  Close for() loop. 
}
// *
label70:
   Dummy.label("Dmvch",70);
Dummy.go_to("Dmvch",999999);
// *
// *
// *     End of DMVCH.
// *
Dummy.label("Dmvch",999999);
return;
   }
} // End class.
