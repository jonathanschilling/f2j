import org.netlib.util.*;

public class blas2test_srnamc
{
static String srnamt= new String("      ");
}
