/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Chkxer {

// *
// *  Tests whether XERBLA has detected an error when it should.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Scalar Arguments ..
// *     .. Executable Statements ..

public static void chkxer (String srnamt,
int infot,
int nout,
booleanW lerr,
booleanW ok)  {

if (!lerr.val)  {
    System.out.println(" ***** ILLEGAL VALUE OF PARAMETER NUMBER "  + (infot) + " "  + " NOT D"  + "ETECTED BY "  + (srnamt) + " "  + " *****" );
ok.val = false;
}              // Close if()
lerr.val = false;
Dummy.go_to("Chkxer",999999);
// *
// *
// *     End of CHKXER.
// *
Dummy.label("Chkxer",999999);
return;
   }
} // End class.
