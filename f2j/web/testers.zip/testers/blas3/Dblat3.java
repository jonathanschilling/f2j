/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dblat3 {

// *
// *  Test program for the DOUBLE PRECISION Level 3 Blas.
// *
// *  The program must be driven by a short data file. The first 14 records
// *  of the file are read using list-directed input, the last 6 records
// *  are read using the format ( A6, L2 ). An annotated example of a data
// *  file can be obtained by deleting the first 3 characters from the
// *  following 20 lines:
// *  'DBLAT3.SUMM'     NAME OF SUMMARY OUTPUT FILE
// *  6                 UNIT NUMBER OF SUMMARY FILE
// *  'DBLAT3.SNAP'     NAME OF SNAPSHOT OUTPUT FILE
// *  -1                UNIT NUMBER OF SNAPSHOT FILE (NOT USED IF .LT. 0)
// *  F        LOGICAL FLAG, T TO REWIND SNAPSHOT FILE AFTER EACH RECORD.
// *  F        LOGICAL FLAG, T TO STOP ON FAILURES.
// *  T        LOGICAL FLAG, T TO TEST ERROR EXITS.
// *  16.0     THRESHOLD VALUE OF TEST RATIO
// *  6                 NUMBER OF VALUES OF N
// *  0 1 2 3 5 9       VALUES OF N
// *  3                 NUMBER OF VALUES OF ALPHA
// *  0.0 1.0 0.7       VALUES OF ALPHA
// *  3                 NUMBER OF VALUES OF BETA
// *  0.0 1.0 1.3       VALUES OF BETA
// *  DGEMM  T PUT F FOR NO TEST. SAME COLUMNS.
// *  DSYMM  T PUT F FOR NO TEST. SAME COLUMNS.
// *  DTRMM  T PUT F FOR NO TEST. SAME COLUMNS.
// *  DTRSM  T PUT F FOR NO TEST. SAME COLUMNS.
// *  DSYRK  T PUT F FOR NO TEST. SAME COLUMNS.
// *  DSYR2K T PUT F FOR NO TEST. SAME COLUMNS.
// *
// *  See:
// *
// *     Dongarra J. J., Du Croz J. J., Duff I. S. and Hammarling S.
// *     A Set of Level 3 Basic Linear Algebra Subprograms.
// *
// *     Technical Memorandum No.88 (Revision 1), Mathematics and
// *     Computer Science Division, Argonne National Laboratory, 9700
// *     South Cass Avenue, Argonne, Illinois 60439, US.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static int nin= 5;
static int nsubs= 6;
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
static int nmax= 65;
static int nidmax= 9;
static int nalmax= 7;
static int nbemax= 7;
// *     .. Local Scalars ..
static double eps= 0.0;
static doubleW err= new doubleW(0.0);
static double thresh= 0.0;
static int i= 0;
static int isnum= 0;
static int j= 0;
static int n= 0;
static int nalf= 0;
static int nbet= 0;
static int nidim= 0;
static int nout= 0;
static int ntra= 0;
static booleanW fatal= new booleanW(false);
static boolean ltestt= false;
static boolean rewi= false;
static boolean same= false;
static boolean sfatal= false;
static boolean trace= false;
static boolean tsterr= false;
static String transa= new String(" ");
static String transb= new String(" ");
static String snamet= new String("      ");
static String snaps= new String("                                ");
static String summry= new String("                                ");
// *     .. Local Arrays ..
static double [] aa= new double[(nmax*nmax)];
static double [] ab= new double[(nmax) * (2*nmax)];
static double [] alf= new double[(nalmax)];
static double [] as= new double[(nmax*nmax)];
static double [] bb= new double[(nmax*nmax)];
static double [] bet= new double[(nbemax)];
static double [] bs= new double[(nmax*nmax)];
static double [] c= new double[(nmax) * (nmax)];
static double [] cc= new double[(nmax*nmax)];
static double [] cs= new double[(nmax*nmax)];
static double [] ct= new double[(nmax)];
static double [] g= new double[(nmax)];
static double [] w= new double[(2*nmax)];
static int [] idim= new int[(nidmax)];
static boolean [] ltest= new boolean[(nsubs)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String [] snames = {"DGEMM " 
, "DSYMM " , "DTRMM " , "DTRSM " , "DSYRK " , "DSYR2K" 
};
// *     .. Executable Statements ..
// *
// *     Read name and unit number for summary output file and open file.
// *

public static void main (String [] args)  {

  EasyIn _f2j_in = new EasyIn();
summry = _f2j_in.readChars(32);
_f2j_in.skipRemaining();
nout = _f2j_in.readInt();
_f2j_in.skipRemaining();
// *     OPEN( NOUT, FILE = SUMMRY, STATUS = 'NEW' )
blas3test_infoc.nout_noutc = nout;
// *
// *     Read name and unit number for snapshot output file and open file.
// *
snaps = _f2j_in.readChars(32);
_f2j_in.skipRemaining();
ntra = _f2j_in.readInt();
_f2j_in.skipRemaining();
trace = ntra >= 0;
// *     IF( TRACE )THEN
// *        OPEN( NTRA, FILE = SNAPS, STATUS = 'NEW' )
// *     END IF
// *     Read the flag that directs rewinding of the snapshot file.
rewi = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
rewi = rewi && trace;
// *     Read the flag that directs stopping on any failure.
sfatal = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *     Read the flag that indicates whether error exits are to be tested.
tsterr = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *     Read the threshold value of the test ratio
thresh = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *
// *     Read and check the parameter values for the tests.
// *
// *     Values of N
nidim = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nidim < 1 || nidim > nidmax)  {
    System.out.println(" NUMBER OF VALUES OF "  + ("N") + " "  + " IS LESS THAN 1 OR GREATER "  + "THAN "  + (nidmax) + " " );
Dummy.go_to("Dblat3",220);
}              // Close if()
for(i = 1; i <= nidim; i++)
idim[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop10:
for (i = 1; i <= nidim; i++) {
if (idim[(i)- 1] < 0 || idim[(i)- 1] > nmax)  {
    System.out.println(" VALUE OF N IS LESS THAN 0 OR GREATER THAN "  + (nmax) + " " );
Dummy.go_to("Dblat3",220);
}              // Close if()
Dummy.label("Dblat3",10);
}              //  Close for() loop. 
}
// *     Values of ALPHA
nalf = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nalf < 1 || nalf > nalmax)  {
    System.out.println(" NUMBER OF VALUES OF "  + ("ALPHA") + " "  + " IS LESS THAN 1 OR GREATER "  + "THAN "  + (nalmax) + " " );
Dummy.go_to("Dblat3",220);
}              // Close if()
for(i = 1; i <= nalf; i++)
alf[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *     Values of BETA
nbet = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nbet < 1 || nbet > nbemax)  {
    System.out.println(" NUMBER OF VALUES OF "  + ("BETA") + " "  + " IS LESS THAN 1 OR GREATER "  + "THAN "  + (nbemax) + " " );
Dummy.go_to("Dblat3",220);
}              // Close if()
for(i = 1; i <= nbet; i++)
bet[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *
// *     Report values of parameters.
// *
System.out.println(" TESTS OF THE DOUBLE PRECISION LEVEL 3 BLAS"  + "\n\n"  + " THE F"  + "OLLOWING PARAMETER VALUES WILL BE USED:" );
System.out.print("");
for(i = 1; i <= nidim; i++)
  System.out.print(idim[(i)- 1] + " ");

System.out.println();
System.out.print("");
for(i = 1; i <= nalf; i++)
  System.out.print(alf[(i)- 1] + " ");

System.out.println();
System.out.print("");
for(i = 1; i <= nbet; i++)
  System.out.print(bet[(i)- 1] + " ");

System.out.println();
if (!tsterr)  {
    System.out.println();
System.out.println(" ERROR-EXITS WILL NOT BE TESTED" );
}              // Close if()
System.out.println();
System.out.println(" ROUTINES PASS COMPUTATIONAL TESTS IF TEST RATIO IS LES"  + "S THAN"  + (thresh) + " " );
System.out.println();
// *
// *     Read names of subroutines and flags which indicate
// *     whether they are to be tested.
// *
{
forloop20:
for (i = 1; i <= nsubs; i++) {
ltest[(i)- 1] = false;
Dummy.label("Dblat3",20);
}              //  Close for() loop. 
}
label30:
   Dummy.label("Dblat3",30);
try {
snamet = _f2j_in.readchars(6);
ltestt = _f2j_in.readboolean();
_f2j_in.skipRemaining();
} catch (java.io.IOException e) {
Dummy.go_to("Dblat3",60);
}
{
forloop40:
for (i = 1; i <= nsubs; i++) {
if (snamet.trim().equalsIgnoreCase(snames[(i)- 1].trim()))  
    Dummy.go_to("Dblat3",50);
Dummy.label("Dblat3",40);
}              //  Close for() loop. 
}
System.out.println(" SUBPROGRAM NAME "  + (snamet) + " "  + " NOT RECOGNIZED"  + "\n"  + " ******* T"  + "ESTS ABANDONED *******" );
System.exit(1);
label50:
   Dummy.label("Dblat3",50);
ltest[(i)- 1] = ltestt;
Dummy.go_to("Dblat3",30);
// *
label60:
   Dummy.label("Dblat3",60);
 ; // WARNING: Unimplemented statement in Fortran source.
// *
// *     Compute EPS (the machine precision).
// *
eps = one;
label70:
   Dummy.label("Dblat3",70);
if (Ddiff.ddiff(one+eps,one) == zero)  
    Dummy.go_to("Dblat3",80);
eps = half*eps;
Dummy.go_to("Dblat3",70);
label80:
   Dummy.label("Dblat3",80);
eps = eps+eps;
System.out.println(" RELATIVE MACHINE PRECISION IS TAKEN TO BE"  + (eps) + " " );
// *
// *     Check the reliability of DMMCH using exact data.
// *
n = (int)(Math.min(32, nmax) );
{
forloop100:
for (j = 1; j <= n; j++) {
{
forloop90:
for (i = 1; i <= n; i++) {
ab[(i)- 1+(j- 1)*nmax] = Math.max(i-j+1, 0) ;
Dummy.label("Dblat3",90);
}              //  Close for() loop. 
}
ab[(j)- 1+(nmax+1- 1)*nmax] = (double)(j);
ab[(1)- 1+(nmax+j- 1)*nmax] = (double)(j);
c[(j)- 1+(1- 1)*nmax] = zero;
Dummy.label("Dblat3",100);
}              //  Close for() loop. 
}
{
forloop110:
for (j = 1; j <= n; j++) {
cc[(j)- 1] = (double)(j*((j+1)*j)/2-((j+1)*j*(j-1))/3);
Dummy.label("Dblat3",110);
}              //  Close for() loop. 
}
// *     CC holds the exact result. On exit from DMMCH CT holds
// *     the result computed by DMMCH.
transa = "N";
transb = "N";
Dmmch.dmmch(transa,transb,n,1,n,one,ab,0,nmax,ab,(1)- 1+(nmax+1- 1)*nmax,nmax,zero,c,0,nmax,ct,0,g,0,cc,0,nmax,eps,err,fatal,nout,true);
same = Lde.lde(cc,0,ct,0,n);
if (!same || err.val != zero)  {
    System.out.println(" ERROR IN DMMCH -  IN-LINE DOT PRODUCTS ARE BEING EVALU"  + "ATED WRONGLY."  + "\n"  + " DMMCH WAS CALLED WITH TRANSA = "  + (transa) + " "  + " AND TRANSB = "  + (transb) + " "  + "\n"  + " AND RETURNED SAME = "  + (same) + " "  + " AND "  + "ERR = "  + (err.val) + " "  + "."  + "\n"  + " THIS MAY BE DUE TO FAULTS IN THE "  + "ARITHMETIC OR THE COMPILER."  + "\n"  + " ******* TESTS ABANDONED "  + "*******" );
System.exit(1);
}              // Close if()
transb = "T";
Dmmch.dmmch(transa,transb,n,1,n,one,ab,0,nmax,ab,(1)- 1+(nmax+1- 1)*nmax,nmax,zero,c,0,nmax,ct,0,g,0,cc,0,nmax,eps,err,fatal,nout,true);
same = Lde.lde(cc,0,ct,0,n);
if (!same || err.val != zero)  {
    System.out.println(" ERROR IN DMMCH -  IN-LINE DOT PRODUCTS ARE BEING EVALU"  + "ATED WRONGLY."  + "\n"  + " DMMCH WAS CALLED WITH TRANSA = "  + (transa) + " "  + " AND TRANSB = "  + (transb) + " "  + "\n"  + " AND RETURNED SAME = "  + (same) + " "  + " AND "  + "ERR = "  + (err.val) + " "  + "."  + "\n"  + " THIS MAY BE DUE TO FAULTS IN THE "  + "ARITHMETIC OR THE COMPILER."  + "\n"  + " ******* TESTS ABANDONED "  + "*******" );
System.exit(1);
}              // Close if()
{
forloop120:
for (j = 1; j <= n; j++) {
ab[(j)- 1+(nmax+1- 1)*nmax] = (double)(n-j+1);
ab[(1)- 1+(nmax+j- 1)*nmax] = (double)(n-j+1);
Dummy.label("Dblat3",120);
}              //  Close for() loop. 
}
{
forloop130:
for (j = 1; j <= n; j++) {
cc[(n-j+1)- 1] = (double)(j*((j+1)*j)/2-((j+1)*j*(j-1))/3);
Dummy.label("Dblat3",130);
}              //  Close for() loop. 
}
transa = "T";
transb = "N";
Dmmch.dmmch(transa,transb,n,1,n,one,ab,0,nmax,ab,(1)- 1+(nmax+1- 1)*nmax,nmax,zero,c,0,nmax,ct,0,g,0,cc,0,nmax,eps,err,fatal,nout,true);
same = Lde.lde(cc,0,ct,0,n);
if (!same || err.val != zero)  {
    System.out.println(" ERROR IN DMMCH -  IN-LINE DOT PRODUCTS ARE BEING EVALU"  + "ATED WRONGLY."  + "\n"  + " DMMCH WAS CALLED WITH TRANSA = "  + (transa) + " "  + " AND TRANSB = "  + (transb) + " "  + "\n"  + " AND RETURNED SAME = "  + (same) + " "  + " AND "  + "ERR = "  + (err.val) + " "  + "."  + "\n"  + " THIS MAY BE DUE TO FAULTS IN THE "  + "ARITHMETIC OR THE COMPILER."  + "\n"  + " ******* TESTS ABANDONED "  + "*******" );
System.exit(1);
}              // Close if()
transb = "T";
Dmmch.dmmch(transa,transb,n,1,n,one,ab,0,nmax,ab,(1)- 1+(nmax+1- 1)*nmax,nmax,zero,c,0,nmax,ct,0,g,0,cc,0,nmax,eps,err,fatal,nout,true);
same = Lde.lde(cc,0,ct,0,n);
if (!same || err.val != zero)  {
    System.out.println(" ERROR IN DMMCH -  IN-LINE DOT PRODUCTS ARE BEING EVALU"  + "ATED WRONGLY."  + "\n"  + " DMMCH WAS CALLED WITH TRANSA = "  + (transa) + " "  + " AND TRANSB = "  + (transb) + " "  + "\n"  + " AND RETURNED SAME = "  + (same) + " "  + " AND "  + "ERR = "  + (err.val) + " "  + "."  + "\n"  + " THIS MAY BE DUE TO FAULTS IN THE "  + "ARITHMETIC OR THE COMPILER."  + "\n"  + " ******* TESTS ABANDONED "  + "*******" );
System.exit(1);
}              // Close if()
// *
// *     Test each subroutine in turn.
// *
{
forloop200:
for (isnum = 1; isnum <= nsubs; isnum++) {
System.out.println();
if (!ltest[(isnum)- 1])  {
    // *           Subprogram is not to be tested.
System.out.println(" " + (snames[(isnum)- 1]) + " "  + " WAS NOT TESTED" );
}              // Close if()
else  {
  blas3test_srnamc.srnamt = snames[(isnum)- 1];
// *           Test error exits.
if (tsterr)  {
    Dchke.dchke(isnum,snames[(isnum)- 1],nout);
System.out.println();
}              // Close if()
// *           Test computations.
blas3test_infoc.infot = 0;
blas3test_infoc.ok.val = true;
fatal.val = false;
if (isnum == 1) 
  Dummy.go_to("Dblat3",140);
else if (isnum == 2) 
  Dummy.go_to("Dblat3",150);
else if (isnum == 3) 
  Dummy.go_to("Dblat3",160);
else if (isnum == 4) 
  Dummy.go_to("Dblat3",160);
else if (isnum == 5) 
  Dummy.go_to("Dblat3",170);
else if (isnum == 6) 
  Dummy.go_to("Dblat3",180);
// *           Test DGEMM, 01.
label140:
   Dummy.label("Dblat3",140);
Dchk1.dchk1(snames[(isnum)- 1],eps,thresh,nout,ntra,trace,rewi,fatal,nidim,idim,0,nalf,alf,0,nbet,bet,0,nmax,ab,0,aa,0,as,0,ab,(1)- 1+(nmax+1- 1)*nmax,bb,0,bs,0,c,0,cc,0,cs,0,ct,0,g,0);
Dummy.go_to("Dblat3",190);
// *           Test DSYMM, 02.
label150:
   Dummy.label("Dblat3",150);
Dchk2.dchk2(snames[(isnum)- 1],eps,thresh,nout,ntra,trace,rewi,fatal,nidim,idim,0,nalf,alf,0,nbet,bet,0,nmax,ab,0,aa,0,as,0,ab,(1)- 1+(nmax+1- 1)*nmax,bb,0,bs,0,c,0,cc,0,cs,0,ct,0,g,0);
Dummy.go_to("Dblat3",190);
// *           Test DTRMM, 03, DTRSM, 04.
label160:
   Dummy.label("Dblat3",160);
Dchk3.dchk3(snames[(isnum)- 1],eps,thresh,nout,ntra,trace,rewi,fatal,nidim,idim,0,nalf,alf,0,nmax,ab,0,aa,0,as,0,ab,(1)- 1+(nmax+1- 1)*nmax,bb,0,bs,0,ct,0,g,0,c,0);
Dummy.go_to("Dblat3",190);
// *           Test DSYRK, 05.
label170:
   Dummy.label("Dblat3",170);
Dchk4.dchk4(snames[(isnum)- 1],eps,thresh,nout,ntra,trace,rewi,fatal,nidim,idim,0,nalf,alf,0,nbet,bet,0,nmax,ab,0,aa,0,as,0,ab,(1)- 1+(nmax+1- 1)*nmax,bb,0,bs,0,c,0,cc,0,cs,0,ct,0,g,0);
Dummy.go_to("Dblat3",190);
// *           Test DSYR2K, 06.
label180:
   Dummy.label("Dblat3",180);
Dchk5.dchk5(snames[(isnum)- 1],eps,thresh,nout,ntra,trace,rewi,fatal,nidim,idim,0,nalf,alf,0,nbet,bet,0,nmax,ab,0,aa,0,as,0,bb,0,bs,0,c,0,cc,0,cs,0,ct,0,g,0,w,0);
Dummy.go_to("Dblat3",190);
// *
label190:
   Dummy.label("Dblat3",190);
if (fatal.val && sfatal)  
    Dummy.go_to("Dblat3",210);
}              //  Close else.
Dummy.label("Dblat3",200);
}              //  Close for() loop. 
}
System.out.println("\n"  + " END OF TESTS" );
Dummy.go_to("Dblat3",230);
// *
label210:
   Dummy.label("Dblat3",210);
System.out.println("\n"  + " ******* FATAL ERROR - TESTS ABANDONED *******" );
Dummy.go_to("Dblat3",230);
// *
label220:
   Dummy.label("Dblat3",220);
System.out.println(" AMEND DATA FILE OR INCREASE ARRAY SIZES IN PROGRAM"  + "\n"  + " ******* TESTS ABANDONED *******" );
// *
label230:
   Dummy.label("Dblat3",230);
if (trace)  
     ; // WARNING: Unimplemented statement in Fortran source.
 ; // WARNING: Unimplemented statement in Fortran source.
System.exit(1);
// *
// *
// *     End of DBLAT3.
// *
Dummy.label("Dblat3",999999);
return;
   }
} // End class.
