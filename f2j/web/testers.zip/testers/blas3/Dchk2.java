/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchk2 {

// *
// *  Tests DSYMM.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double als= 0.0;
static double beta= 0.0;
static double bls= 0.0;
static doubleW err= new doubleW(0.0);
static double errmax= 0.0;
static int i= 0;
static int ia= 0;
static int ib= 0;
static int ics= 0;
static int icu= 0;
static int im= 0;
static int in= 0;
static int laa= 0;
static int lbb= 0;
static int lcc= 0;
static int lda= 0;
static int ldas= 0;
static int ldb= 0;
static int ldbs= 0;
static int Ldc= 0;
static int ldcs= 0;
static int m= 0;
static int ms= 0;
static int n= 0;
static int na= 0;
static int nargs= 0;
static int nc= 0;
static int ns= 0;
static boolean left= false;
static boolean Null= false;
static booleanW reset= new booleanW(false);
static boolean same= false;
static String side= new String(" ");
static String sides= new String(" ");
static String uplo= new String(" ");
static String uplos= new String(" ");
// *     .. Local Arrays ..
static boolean [] isame= new boolean[(13)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String ichu = new String("UL");
static String ichs = new String("LR");
// *     .. Executable Statements ..
// *

public static void dchk2 (String sname,
double eps,
double thresh,
int nout,
int ntra,
boolean trace,
boolean rewi,
booleanW fatal,
int nidim,
int [] idim, int _idim_offset,
int nalf,
double [] alf, int _alf_offset,
int nbet,
double [] bet, int _bet_offset,
int nmax,
double [] a, int _a_offset,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
double [] b, int _b_offset,
double [] bb, int _bb_offset,
double [] bs, int _bs_offset,
double [] c, int _c_offset,
double [] cc, int _cc_offset,
double [] cs, int _cs_offset,
double [] ct, int _ct_offset,
double [] g, int _g_offset)  {

nargs = 12;
nc = 0;
reset.val = true;
errmax = zero;
// *
{
forloop100:
for (im = 1; im <= nidim; im++) {
m = idim[(im)- 1+ _idim_offset];
// *
{
forloop90:
for (in = 1; in <= nidim; in++) {
n = idim[(in)- 1+ _idim_offset];
// *           Set LDC to 1 more than minimum value if room.
Ldc = m;
if (Ldc < nmax)  
    Ldc = Ldc+1;
// *           Skip tests if not enough room.
if (Ldc > nmax)  
    continue forloop90;
lcc = Ldc*n;
Null = n <= 0 || m <= 0;
// *
// *           Set LDB to 1 more than minimum value if room.
ldb = m;
if (ldb < nmax)  
    ldb = ldb+1;
// *           Skip tests if not enough room.
if (ldb > nmax)  
    continue forloop90;
lbb = ldb*n;
// *
// *           Generate the matrix B.
// *
Dmake.dmake("GE"," "," ",m,n,b,_b_offset,nmax,bb,_bb_offset,ldb,reset,zero);
// *
{
forloop80:
for (ics = 1; ics <= 2; ics++) {
side = ichs.substring((ics)-1,ics);
left = side.trim().equalsIgnoreCase("L".trim());
// *
if (left)  {
    na = m;
}              // Close if()
else  {
  na = n;
}              //  Close else.
// *              Set LDA to 1 more than minimum value if room.
lda = na;
if (lda < nmax)  
    lda = lda+1;
// *              Skip tests if not enough room.
if (lda > nmax)  
    continue forloop80;
laa = lda*na;
// *
{
forloop70:
for (icu = 1; icu <= 2; icu++) {
uplo = ichu.substring((icu)-1,icu);
// *
// *                 Generate the symmetric matrix A.
// *
Dmake.dmake("SY",uplo," ",na,na,a,_a_offset,nmax,aa,_aa_offset,lda,reset,zero);
// *
{
forloop60:
for (ia = 1; ia <= nalf; ia++) {
alpha = alf[(ia)- 1+ _alf_offset];
// *
{
forloop50:
for (ib = 1; ib <= nbet; ib++) {
beta = bet[(ib)- 1+ _bet_offset];
// *
// *                       Generate the matrix C.
// *
Dmake.dmake("GE"," "," ",m,n,c,_c_offset,nmax,cc,_cc_offset,Ldc,reset,zero);
// *
nc = nc+1;
// *
// *                       Save every datum before calling the
// *                       subroutine.
// *
sides = side;
uplos = uplo;
ms = m;
ns = n;
als = alpha;
{
forloop10:
for (i = 1; i <= laa; i++) {
as[(i)- 1+ _as_offset] = aa[(i)- 1+ _aa_offset];
Dummy.label("Dchk2",10);
}              //  Close for() loop. 
}
ldas = lda;
{
forloop20:
for (i = 1; i <= lbb; i++) {
bs[(i)- 1+ _bs_offset] = bb[(i)- 1+ _bb_offset];
Dummy.label("Dchk2",20);
}              //  Close for() loop. 
}
ldbs = ldb;
bls = beta;
{
forloop30:
for (i = 1; i <= lcc; i++) {
cs[(i)- 1+ _cs_offset] = cc[(i)- 1+ _cc_offset];
Dummy.label("Dchk2",30);
}              //  Close for() loop. 
}
ldcs = Ldc;
// *
// *                       Call the subroutine.
// *
if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (side) + " "  + "\',"  + "\'"  + (uplo) + " "  + "\',"  + (m) + " "  + ","  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ","  + (beta) + " "  + ", C,"  + (Ldc) + " "  + ")   "  + " ." );
if (rewi)  
     ; // WARNING: Unimplemented statement in Fortran source.
Dsymm.dsymm(side,uplo,m,n,alpha,aa,_aa_offset,lda,bb,_bb_offset,ldb,beta,cc,_cc_offset,Ldc);
// *
// *                       Check if error-exit was taken incorrectly.
// *
if (!blas3test_infoc.ok.val)  {
    System.out.println(" ******* FATAL ERROR - ERROR-EXIT TAKEN ON VALID CALL *"  + "******" );
fatal.val = true;
Dummy.go_to("Dchk2",110);
}              // Close if()
// *
// *                       See what data changed inside subroutines.
// *
isame[(1)- 1] = sides.trim().equalsIgnoreCase(side.trim());
isame[(2)- 1] = uplos.trim().equalsIgnoreCase(uplo.trim());
isame[(3)- 1] = ms == m;
isame[(4)- 1] = ns == n;
isame[(5)- 1] = als == alpha;
isame[(6)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(7)- 1] = ldas == lda;
isame[(8)- 1] = Lde.lde(bs,_bs_offset,bb,_bb_offset,lbb);
isame[(9)- 1] = ldbs == ldb;
isame[(10)- 1] = bls == beta;
if (Null)  {
    isame[(11)- 1] = Lde.lde(cs,_cs_offset,cc,_cc_offset,lcc);
}              // Close if()
else  {
  isame[(11)- 1] = Lderes.lderes("GE"," ",m,n,cs,_cs_offset,cc,_cc_offset,Ldc);
}              //  Close else.
isame[(12)- 1] = ldcs == Ldc;
// *
// *                       If data was incorrectly changed, report and
// *                       return.
// *
same = true;
{
forloop40:
for (i = 1; i <= nargs; i++) {
same = same && isame[(i)- 1];
if (!isame[(i)- 1])  
    System.out.println(" ******* FATAL ERROR - PARAMETER NUMBER "  + (i) + " "  + " WAS CH"  + "ANGED INCORRECTLY *******" );
Dummy.label("Dchk2",40);
}              //  Close for() loop. 
}
if (!same)  {
    fatal.val = true;
Dummy.go_to("Dchk2",110);
}              // Close if()
// *
if (!Null)  {
    // *
// *                          Check the result.
// *
if (left)  {
    Dmmch.dmmch("N","N",m,n,m,alpha,a,_a_offset,nmax,b,_b_offset,nmax,beta,c,_c_offset,nmax,ct,_ct_offset,g,_g_offset,cc,_cc_offset,Ldc,eps,err,fatal,nout,true);
}              // Close if()
else  {
  Dmmch.dmmch("N","N",m,n,n,alpha,b,_b_offset,nmax,a,_a_offset,nmax,beta,c,_c_offset,nmax,ct,_ct_offset,g,_g_offset,cc,_cc_offset,Ldc,eps,err,fatal,nout,true);
}              //  Close else.
errmax = Math.max(errmax, err.val) ;
// *                          If got really bad answer, report and
// *                          return.
if (fatal.val)  
    Dummy.go_to("Dchk2",110);
}              // Close if()
// *
Dummy.label("Dchk2",50);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",60);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",70);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",90);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk2",100);
}              //  Close for() loop. 
}
// *
// *     Report result.
// *
if (errmax < thresh)  {
    System.out.println(" "  + (sname) + " "  + " PASSED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " CALL"  + "S)" );
}              // Close if()
else  {
  System.out.println(" "  + (sname) + " "  + " COMPLETED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " C"  + "ALLS)"  + "\n"  + " ******* BUT WITH MAXIMUM TEST RATIO"  + (errmax) + " "  + " - SUSPECT *******" );
}              //  Close else.
Dummy.go_to("Dchk2",120);
// *
label110:
   Dummy.label("Dchk2",110);
System.out.println(" ******* "  + (sname) + " "  + " FAILED ON CALL NUMBER:" );
System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (side) + " "  + "\',"  + "\'"  + (uplo) + " "  + "\',"  + (m) + " "  + ","  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ","  + (beta) + " "  + ", C,"  + (Ldc) + " "  + ")   "  + " ." );
// *
label120:
   Dummy.label("Dchk2",120);
Dummy.go_to("Dchk2",999999);
// *
// *
// *     End of DCHK2.
// *
Dummy.label("Dchk2",999999);
return;
   }
} // End class.
