/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchk3 {

// *
// *  Tests DTRMM and DTRSM.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double als= 0.0;
static doubleW err= new doubleW(0.0);
static double errmax= 0.0;
static int i= 0;
static int ia= 0;
static int icd= 0;
static int ics= 0;
static int ict= 0;
static int icu= 0;
static int im= 0;
static int in= 0;
static int j= 0;
static int laa= 0;
static int lbb= 0;
static int lda= 0;
static int ldas= 0;
static int ldb= 0;
static int ldbs= 0;
static int m= 0;
static int ms= 0;
static int n= 0;
static int na= 0;
static int nargs= 0;
static int nc= 0;
static int ns= 0;
static boolean left= false;
static boolean Null= false;
static booleanW reset= new booleanW(false);
static boolean same= false;
static String diag= new String(" ");
static String diags= new String(" ");
static String side= new String(" ");
static String sides= new String(" ");
static String tranas= new String(" ");
static String transa= new String(" ");
static String uplo= new String(" ");
static String uplos= new String(" ");
// *     .. Local Arrays ..
static boolean [] isame= new boolean[(13)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String ichs = new String("LR");
static String ichd = new String("UN");
static String icht = new String("NTC");
static String ichu = new String("UL");
// *     .. Executable Statements ..
// *

public static void dchk3 (String sname,
double eps,
double thresh,
int nout,
int ntra,
boolean trace,
boolean rewi,
booleanW fatal,
int nidim,
int [] idim, int _idim_offset,
int nalf,
double [] alf, int _alf_offset,
int nmax,
double [] a, int _a_offset,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
double [] b, int _b_offset,
double [] bb, int _bb_offset,
double [] bs, int _bs_offset,
double [] ct, int _ct_offset,
double [] g, int _g_offset,
double [] c, int _c_offset)  {

nargs = 11;
nc = 0;
reset.val = true;
errmax = zero;
// *     Set up zero matrix for DMMCH.
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
c[(i)- 1+(j- 1)*nmax+ _c_offset] = zero;
Dummy.label("Dchk3",10);
}              //  Close for() loop. 
}
Dummy.label("Dchk3",20);
}              //  Close for() loop. 
}
// *
{
forloop140:
for (im = 1; im <= nidim; im++) {
m = idim[(im)- 1+ _idim_offset];
// *
{
forloop130:
for (in = 1; in <= nidim; in++) {
n = idim[(in)- 1+ _idim_offset];
// *           Set LDB to 1 more than minimum value if room.
ldb = m;
if (ldb < nmax)  
    ldb = ldb+1;
// *           Skip tests if not enough room.
if (ldb > nmax)  
    continue forloop130;
lbb = ldb*n;
Null = m <= 0 || n <= 0;
// *
{
forloop120:
for (ics = 1; ics <= 2; ics++) {
side = ichs.substring((ics)-1,ics);
left = side.trim().equalsIgnoreCase("L".trim());
if (left)  {
    na = m;
}              // Close if()
else  {
  na = n;
}              //  Close else.
// *              Set LDA to 1 more than minimum value if room.
lda = na;
if (lda < nmax)  
    lda = lda+1;
// *              Skip tests if not enough room.
if (lda > nmax)  
    continue forloop130;
laa = lda*na;
// *
{
forloop110:
for (icu = 1; icu <= 2; icu++) {
uplo = ichu.substring((icu)-1,icu);
// *
{
forloop100:
for (ict = 1; ict <= 3; ict++) {
transa = icht.substring((ict)-1,ict);
// *
{
forloop90:
for (icd = 1; icd <= 2; icd++) {
diag = ichd.substring((icd)-1,icd);
// *
{
forloop80:
for (ia = 1; ia <= nalf; ia++) {
alpha = alf[(ia)- 1+ _alf_offset];
// *
// *                          Generate the matrix A.
// *
Dmake.dmake("TR",uplo,diag,na,na,a,_a_offset,nmax,aa,_aa_offset,lda,reset,zero);
// *
// *                          Generate the matrix B.
// *
Dmake.dmake("GE"," "," ",m,n,b,_b_offset,nmax,bb,_bb_offset,ldb,reset,zero);
// *
nc = nc+1;
// *
// *                          Save every datum before calling the
// *                          subroutine.
// *
sides = side;
uplos = uplo;
tranas = transa;
diags = diag;
ms = m;
ns = n;
als = alpha;
{
forloop30:
for (i = 1; i <= laa; i++) {
as[(i)- 1+ _as_offset] = aa[(i)- 1+ _aa_offset];
Dummy.label("Dchk3",30);
}              //  Close for() loop. 
}
ldas = lda;
{
forloop40:
for (i = 1; i <= lbb; i++) {
bs[(i)- 1+ _bs_offset] = bb[(i)- 1+ _bb_offset];
Dummy.label("Dchk3",40);
}              //  Close for() loop. 
}
ldbs = ldb;
// *
// *                          Call the subroutine.
// *
if (sname.substring((4)-1,5).trim().equalsIgnoreCase("MM".trim()))  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (side) + " "  + "\',"  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (transa) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (m) + " "  + ","  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ")        ." );
if (rewi)  
     ; // WARNING: Unimplemented statement in Fortran source.
Dtrmm.dtrmm(side,uplo,transa,diag,m,n,alpha,aa,_aa_offset,lda,bb,_bb_offset,ldb);
}              // Close if()
else if (sname.substring((4)-1,5).trim().equalsIgnoreCase("SM".trim()))  {
    if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (side) + " "  + "\',"  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (transa) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (m) + " "  + ","  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ")        ." );
if (rewi)  
     ; // WARNING: Unimplemented statement in Fortran source.
Dtrsm.dtrsm(side,uplo,transa,diag,m,n,alpha,aa,_aa_offset,lda,bb,_bb_offset,ldb);
}              // Close else if()
// *
// *                          Check if error-exit was taken incorrectly.
// *
if (!blas3test_infoc.ok.val)  {
    System.out.println(" ******* FATAL ERROR - ERROR-EXIT TAKEN ON VALID CALL *"  + "******" );
fatal.val = true;
Dummy.go_to("Dchk3",150);
}              // Close if()
// *
// *                          See what data changed inside subroutines.
// *
isame[(1)- 1] = sides.trim().equalsIgnoreCase(side.trim());
isame[(2)- 1] = uplos.trim().equalsIgnoreCase(uplo.trim());
isame[(3)- 1] = tranas.trim().equalsIgnoreCase(transa.trim());
isame[(4)- 1] = diags.trim().equalsIgnoreCase(diag.trim());
isame[(5)- 1] = ms == m;
isame[(6)- 1] = ns == n;
isame[(7)- 1] = als == alpha;
isame[(8)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(9)- 1] = ldas == lda;
if (Null)  {
    isame[(10)- 1] = Lde.lde(bs,_bs_offset,bb,_bb_offset,lbb);
}              // Close if()
else  {
  isame[(10)- 1] = Lderes.lderes("GE"," ",m,n,bs,_bs_offset,bb,_bb_offset,ldb);
}              //  Close else.
isame[(11)- 1] = ldbs == ldb;
// *
// *                          If data was incorrectly changed, report and
// *                          return.
// *
same = true;
{
forloop50:
for (i = 1; i <= nargs; i++) {
same = same && isame[(i)- 1];
if (!isame[(i)- 1])  
    System.out.println(" ******* FATAL ERROR - PARAMETER NUMBER "  + (i) + " "  + " WAS CH"  + "ANGED INCORRECTLY *******" );
Dummy.label("Dchk3",50);
}              //  Close for() loop. 
}
if (!same)  {
    fatal.val = true;
Dummy.go_to("Dchk3",150);
}              // Close if()
// *
if (!Null)  {
    if (sname.substring((4)-1,5).trim().equalsIgnoreCase("MM".trim()))  {
    // *
// *                                Check the result.
// *
if (left)  {
    Dmmch.dmmch(transa,"N",m,n,m,alpha,a,_a_offset,nmax,b,_b_offset,nmax,zero,c,_c_offset,nmax,ct,_ct_offset,g,_g_offset,bb,_bb_offset,ldb,eps,err,fatal,nout,true);
}              // Close if()
else  {
  Dmmch.dmmch("N",transa,m,n,n,alpha,b,_b_offset,nmax,a,_a_offset,nmax,zero,c,_c_offset,nmax,ct,_ct_offset,g,_g_offset,bb,_bb_offset,ldb,eps,err,fatal,nout,true);
}              //  Close else.
}              // Close if()
else if (sname.substring((4)-1,5).trim().equalsIgnoreCase("SM".trim()))  {
    // *
// *                                Compute approximation to original
// *                                matrix.
// *
{
forloop70:
for (j = 1; j <= n; j++) {
{
forloop60:
for (i = 1; i <= m; i++) {
c[(i)- 1+(j- 1)*nmax+ _c_offset] = bb[(i+(j-1)*ldb)- 1+ _bb_offset];
bb[(i+(j-1)*ldb)- 1+ _bb_offset] = alpha*b[(i)- 1+(j- 1)*nmax+ _b_offset];
Dummy.label("Dchk3",60);
}              //  Close for() loop. 
}
Dummy.label("Dchk3",70);
}              //  Close for() loop. 
}
// *
if (left)  {
    Dmmch.dmmch(transa,"N",m,n,m,one,a,_a_offset,nmax,c,_c_offset,nmax,zero,b,_b_offset,nmax,ct,_ct_offset,g,_g_offset,bb,_bb_offset,ldb,eps,err,fatal,nout,false);
}              // Close if()
else  {
  Dmmch.dmmch("N",transa,m,n,n,one,c,_c_offset,nmax,a,_a_offset,nmax,zero,b,_b_offset,nmax,ct,_ct_offset,g,_g_offset,bb,_bb_offset,ldb,eps,err,fatal,nout,false);
}              //  Close else.
}              // Close else if()
errmax = Math.max(errmax, err.val) ;
// *                             If got really bad answer, report and
// *                             return.
if (fatal.val)  
    Dummy.go_to("Dchk3",150);
}              // Close if()
// *
Dummy.label("Dchk3",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",90);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",100);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",110);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",120);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",130);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk3",140);
}              //  Close for() loop. 
}
// *
// *     Report result.
// *
if (errmax < thresh)  {
    System.out.println(" "  + (sname) + " "  + " PASSED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " CALL"  + "S)" );
}              // Close if()
else  {
  System.out.println(" "  + (sname) + " "  + " COMPLETED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " C"  + "ALLS)"  + "\n"  + " ******* BUT WITH MAXIMUM TEST RATIO"  + (errmax) + " "  + " - SUSPECT *******" );
}              //  Close else.
Dummy.go_to("Dchk3",160);
// *
label150:
   Dummy.label("Dchk3",150);
System.out.println(" ******* "  + (sname) + " "  + " FAILED ON CALL NUMBER:" );
System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (side) + " "  + "\',"  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (transa) + " "  + "\',"  + "\'"  + (diag) + " "  + "\',"  + (m) + " "  + ","  + (n) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ")        ." );
// *
label160:
   Dummy.label("Dchk3",160);
Dummy.go_to("Dchk3",999999);
// *
// *
// *     End of DCHK3.
// *
Dummy.label("Dchk3",999999);
return;
   }
} // End class.
