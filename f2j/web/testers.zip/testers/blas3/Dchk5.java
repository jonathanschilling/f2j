/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchk5 {

// *
// *  Tests DSYR2K.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double als= 0.0;
static double beta= 0.0;
static double bets= 0.0;
static doubleW err= new doubleW(0.0);
static double errmax= 0.0;
static int i= 0;
static int ia= 0;
static int ib= 0;
static int ict= 0;
static int icu= 0;
static int ik= 0;
static int in= 0;
static int j= 0;
static int jc= 0;
static int jj= 0;
static int jjab= 0;
static int k= 0;
static int ks= 0;
static int laa= 0;
static int lbb= 0;
static int lcc= 0;
static int lda= 0;
static int ldas= 0;
static int ldb= 0;
static int ldbs= 0;
static int Ldc= 0;
static int ldcs= 0;
static int lj= 0;
static int ma= 0;
static int n= 0;
static int na= 0;
static int nargs= 0;
static int nc= 0;
static int ns= 0;
static boolean Null= false;
static booleanW reset= new booleanW(false);
static boolean same= false;
static boolean tran= false;
static boolean upper= false;
static String trans= new String(" ");
static String transs= new String(" ");
static String uplo= new String(" ");
static String uplos= new String(" ");
// *     .. Local Arrays ..
static boolean [] isame= new boolean[(13)];
// *     .. External Functions ..
// *     .. External Subroutines ..
// *     .. Intrinsic Functions ..
// *     .. Scalars in Common ..
// *     .. Common blocks ..
// *     .. Data statements ..
static String ichu = new String("UL");
static String icht = new String("NTC");
// *     .. Executable Statements ..
// *

public static void dchk5 (String sname,
double eps,
double thresh,
int nout,
int ntra,
boolean trace,
boolean rewi,
booleanW fatal,
int nidim,
int [] idim, int _idim_offset,
int nalf,
double [] alf, int _alf_offset,
int nbet,
double [] bet, int _bet_offset,
int nmax,
double [] ab, int _ab_offset,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
double [] bb, int _bb_offset,
double [] bs, int _bs_offset,
double [] c, int _c_offset,
double [] cc, int _cc_offset,
double [] cs, int _cs_offset,
double [] ct, int _ct_offset,
double [] g, int _g_offset,
double [] w, int _w_offset)  {

nargs = 12;
nc = 0;
reset.val = true;
errmax = zero;
// *
{
forloop130:
for (in = 1; in <= nidim; in++) {
n = idim[(in)- 1+ _idim_offset];
// *        Set LDC to 1 more than minimum value if room.
Ldc = n;
if (Ldc < nmax)  
    Ldc = Ldc+1;
// *        Skip tests if not enough room.
if (Ldc > nmax)  
    continue forloop130;
lcc = Ldc*n;
Null = n <= 0;
// *
{
forloop120:
for (ik = 1; ik <= nidim; ik++) {
k = idim[(ik)- 1+ _idim_offset];
// *
{
forloop110:
for (ict = 1; ict <= 3; ict++) {
trans = icht.substring((ict)-1,ict);
tran = trans.trim().equalsIgnoreCase("T".trim()) || trans.trim().equalsIgnoreCase("C".trim());
if (tran)  {
    ma = k;
na = n;
}              // Close if()
else  {
  ma = n;
na = k;
}              //  Close else.
// *              Set LDA to 1 more than minimum value if room.
lda = ma;
if (lda < nmax)  
    lda = lda+1;
// *              Skip tests if not enough room.
if (lda > nmax)  
    continue forloop110;
laa = lda*na;
// *
// *              Generate the matrix A.
// *
if (tran)  {
    Dmake.dmake("GE"," "," ",ma,na,ab,_ab_offset,2*nmax,aa,_aa_offset,lda,reset,zero);
}              // Close if()
else  {
  Dmake.dmake("GE"," "," ",ma,na,ab,_ab_offset,nmax,aa,_aa_offset,lda,reset,zero);
}              //  Close else.
// *
// *              Generate the matrix B.
// *
ldb = lda;
lbb = laa;
if (tran)  {
    Dmake.dmake("GE"," "," ",ma,na,ab,(k+1)- 1+ _ab_offset,2*nmax,bb,_bb_offset,ldb,reset,zero);
}              // Close if()
else  {
  Dmake.dmake("GE"," "," ",ma,na,ab,(k*nmax+1)- 1+ _ab_offset,nmax,bb,_bb_offset,ldb,reset,zero);
}              //  Close else.
// *
{
forloop100:
for (icu = 1; icu <= 2; icu++) {
uplo = ichu.substring((icu)-1,icu);
upper = uplo.trim().equalsIgnoreCase("U".trim());
// *
{
forloop90:
for (ia = 1; ia <= nalf; ia++) {
alpha = alf[(ia)- 1+ _alf_offset];
// *
{
forloop80:
for (ib = 1; ib <= nbet; ib++) {
beta = bet[(ib)- 1+ _bet_offset];
// *
// *                       Generate the matrix C.
// *
Dmake.dmake("SY",uplo," ",n,n,c,_c_offset,nmax,cc,_cc_offset,Ldc,reset,zero);
// *
nc = nc+1;
// *
// *                       Save every datum before calling the subroutine.
// *
uplos = uplo;
transs = trans;
ns = n;
ks = k;
als = alpha;
{
forloop10:
for (i = 1; i <= laa; i++) {
as[(i)- 1+ _as_offset] = aa[(i)- 1+ _aa_offset];
Dummy.label("Dchk5",10);
}              //  Close for() loop. 
}
ldas = lda;
{
forloop20:
for (i = 1; i <= lbb; i++) {
bs[(i)- 1+ _bs_offset] = bb[(i)- 1+ _bb_offset];
Dummy.label("Dchk5",20);
}              //  Close for() loop. 
}
ldbs = ldb;
bets = beta;
{
forloop30:
for (i = 1; i <= lcc; i++) {
cs[(i)- 1+ _cs_offset] = cc[(i)- 1+ _cc_offset];
Dummy.label("Dchk5",30);
}              //  Close for() loop. 
}
ldcs = Ldc;
// *
// *                       Call the subroutine.
// *
if (trace)  
    System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ","  + (beta) + " "  + ", C,"  + (Ldc) + " "  + ")   "  + " ." );
if (rewi)  
     ; // WARNING: Unimplemented statement in Fortran source.
Dsyr2k.dsyr2k(uplo,trans,n,k,alpha,aa,_aa_offset,lda,bb,_bb_offset,ldb,beta,cc,_cc_offset,Ldc);
// *
// *                       Check if error-exit was taken incorrectly.
// *
if (!blas3test_infoc.ok.val)  {
    System.out.println(" ******* FATAL ERROR - ERROR-EXIT TAKEN ON VALID CALL *"  + "******" );
fatal.val = true;
Dummy.go_to("Dchk5",150);
}              // Close if()
// *
// *                       See what data changed inside subroutines.
// *
isame[(1)- 1] = uplos.trim().equalsIgnoreCase(uplo.trim());
isame[(2)- 1] = transs.trim().equalsIgnoreCase(trans.trim());
isame[(3)- 1] = ns == n;
isame[(4)- 1] = ks == k;
isame[(5)- 1] = als == alpha;
isame[(6)- 1] = Lde.lde(as,_as_offset,aa,_aa_offset,laa);
isame[(7)- 1] = ldas == lda;
isame[(8)- 1] = Lde.lde(bs,_bs_offset,bb,_bb_offset,lbb);
isame[(9)- 1] = ldbs == ldb;
isame[(10)- 1] = bets == beta;
if (Null)  {
    isame[(11)- 1] = Lde.lde(cs,_cs_offset,cc,_cc_offset,lcc);
}              // Close if()
else  {
  isame[(11)- 1] = Lderes.lderes("SY",uplo,n,n,cs,_cs_offset,cc,_cc_offset,Ldc);
}              //  Close else.
isame[(12)- 1] = ldcs == Ldc;
// *
// *                       If data was incorrectly changed, report and
// *                       return.
// *
same = true;
{
forloop40:
for (i = 1; i <= nargs; i++) {
same = same && isame[(i)- 1];
if (!isame[(i)- 1])  
    System.out.println(" ******* FATAL ERROR - PARAMETER NUMBER "  + (i) + " "  + " WAS CH"  + "ANGED INCORRECTLY *******" );
Dummy.label("Dchk5",40);
}              //  Close for() loop. 
}
if (!same)  {
    fatal.val = true;
Dummy.go_to("Dchk5",150);
}              // Close if()
// *
if (!Null)  {
    // *
// *                          Check the result column by column.
// *
jjab = 1;
jc = 1;
{
forloop70:
for (j = 1; j <= n; j++) {
if (upper)  {
    jj = 1;
lj = j;
}              // Close if()
else  {
  jj = j;
lj = n-j+1;
}              //  Close else.
if (tran)  {
    {
forloop50:
for (i = 1; i <= k; i++) {
w[(i)- 1+ _w_offset] = ab[((j-1)*2*nmax+k+i)- 1+ _ab_offset];
w[(k+i)- 1+ _w_offset] = ab[((j-1)*2*nmax+i)- 1+ _ab_offset];
Dummy.label("Dchk5",50);
}              //  Close for() loop. 
}
Dmmch.dmmch("T","N",lj,1,2*k,alpha,ab,(jjab)- 1+ _ab_offset,2*nmax,w,_w_offset,2*nmax,beta,c,(jj)- 1+(j- 1)*nmax+ _c_offset,nmax,ct,_ct_offset,g,_g_offset,cc,(jc)- 1+ _cc_offset,Ldc,eps,err,fatal,nout,true);
}              // Close if()
else  {
  {
forloop60:
for (i = 1; i <= k; i++) {
w[(i)- 1+ _w_offset] = ab[((k+i-1)*nmax+j)- 1+ _ab_offset];
w[(k+i)- 1+ _w_offset] = ab[((i-1)*nmax+j)- 1+ _ab_offset];
Dummy.label("Dchk5",60);
}              //  Close for() loop. 
}
Dmmch.dmmch("N","N",lj,1,2*k,alpha,ab,(jj)- 1+ _ab_offset,nmax,w,_w_offset,2*nmax,beta,c,(jj)- 1+(j- 1)*nmax+ _c_offset,nmax,ct,_ct_offset,g,_g_offset,cc,(jc)- 1+ _cc_offset,Ldc,eps,err,fatal,nout,true);
}              //  Close else.
if (upper)  {
    jc = jc+Ldc;
}              // Close if()
else  {
  jc = jc+Ldc+1;
if (tran)  
    jjab = jjab+2*nmax;
}              //  Close else.
errmax = Math.max(errmax, err.val) ;
// *                             If got really bad answer, report and
// *                             return.
if (fatal.val)  
    Dummy.go_to("Dchk5",140);
Dummy.label("Dchk5",70);
}              //  Close for() loop. 
}
}              // Close if()
// *
Dummy.label("Dchk5",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk5",90);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk5",100);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk5",110);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk5",120);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchk5",130);
}              //  Close for() loop. 
}
// *
// *     Report result.
// *
if (errmax < thresh)  {
    System.out.println(" "  + (sname) + " "  + " PASSED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " CALL"  + "S)" );
}              // Close if()
else  {
  System.out.println(" "  + (sname) + " "  + " COMPLETED THE COMPUTATIONAL TESTS ("  + (nc) + " "  + " C"  + "ALLS)"  + "\n"  + " ******* BUT WITH MAXIMUM TEST RATIO"  + (errmax) + " "  + " - SUSPECT *******" );
}              //  Close else.
Dummy.go_to("Dchk5",160);
// *
label140:
   Dummy.label("Dchk5",140);
if (n > 1)  
    System.out.println("      THESE ARE THE RESULTS FOR COLUMN "  + (j) + " " );
// *
label150:
   Dummy.label("Dchk5",150);
System.out.println(" ******* "  + (sname) + " "  + " FAILED ON CALL NUMBER:" );
System.out.println(" " + (nc) + " "  + ": "  + (sname) + " "  + "("  + "\'"  + (uplo) + " "  + "\',"  + "\'"  + (trans) + " "  + "\',"  + (n) + " "  + ","  + (k) + " "  + ","  + (alpha) + " "  + ", A,"  + (lda) + " "  + ", B,"  + (ldb) + " "  + ","  + (beta) + " "  + ", C,"  + (Ldc) + " "  + ")   "  + " ." );
// *
label160:
   Dummy.label("Dchk5",160);
Dummy.go_to("Dchk5",999999);
// *
// *
// *     End of DCHK5.
// *
Dummy.label("Dchk5",999999);
return;
   }
} // End class.
