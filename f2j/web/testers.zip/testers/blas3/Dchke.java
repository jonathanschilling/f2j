/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;

import org.netlib.blas.*;


public class Dchke {

// *
// *  Tests the error exits from the Level 3 Blas.
// *  Requires a special version of the error-handling routine XERBLA.
// *  ALPHA, BETA, A, B and C should not need to be defined.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Scalar Arguments ..
// *     .. Scalars in Common ..
// *     .. Local Scalars ..
static double alpha= 0.0;
static double beta= 0.0;
// *     .. Local Arrays ..
static double [] a= new double[(2) * (1)];
static double [] b= new double[(2) * (1)];
static double [] c= new double[(2) * (1)];
// *     .. External Subroutines ..
// *     .. Common blocks ..
// *     .. Executable Statements ..
// *     OK is set to .FALSE. by the special version of XERBLA or by CHKXER
// *     if anything is wrong.

public static void dchke (int isnum,
String srnamt,
int nout)  {

blas3test_infoc.ok.val = true;
// *     LERR is set to .TRUE. by the special version of XERBLA each time
// *     it is called, and is then tested and re-set by CHKXER.
blas3test_infoc.lerr.val = false;
if (isnum == 1) 
  Dummy.go_to("Dchke",10);
else if (isnum == 2) 
  Dummy.go_to("Dchke",20);
else if (isnum == 3) 
  Dummy.go_to("Dchke",30);
else if (isnum == 4) 
  Dummy.go_to("Dchke",40);
else if (isnum == 5) 
  Dummy.go_to("Dchke",50);
else if (isnum == 6) 
  Dummy.go_to("Dchke",60);
label10:
   Dummy.label("Dchke",10);
blas3test_infoc.infot = 1;
Dgemm.dgemm("/","N",0,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 1;
Dgemm.dgemm("/","T",0,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dgemm.dgemm("N","/",0,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dgemm.dgemm("T","/",0,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dgemm.dgemm("N","N",-1,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dgemm.dgemm("N","T",-1,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dgemm.dgemm("T","N",-1,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dgemm.dgemm("T","T",-1,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dgemm.dgemm("N","N",0,-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dgemm.dgemm("N","T",0,-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dgemm.dgemm("T","N",0,-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dgemm.dgemm("T","T",0,-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dgemm.dgemm("N","N",0,0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dgemm.dgemm("N","T",0,0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dgemm.dgemm("T","N",0,0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dgemm.dgemm("T","T",0,0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 8;
Dgemm.dgemm("N","N",2,0,0,alpha,a,0,1,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 8;
Dgemm.dgemm("N","T",2,0,0,alpha,a,0,1,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 8;
Dgemm.dgemm("T","N",0,0,2,alpha,a,0,1,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 8;
Dgemm.dgemm("T","T",0,0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dgemm.dgemm("N","N",0,0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dgemm.dgemm("T","N",0,0,2,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dgemm.dgemm("N","T",0,2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dgemm.dgemm("T","T",0,2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 13;
Dgemm.dgemm("N","N",2,0,0,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 13;
Dgemm.dgemm("N","T",2,0,0,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 13;
Dgemm.dgemm("T","N",2,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 13;
Dgemm.dgemm("T","T",2,0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
Dummy.go_to("Dchke",70);
label20:
   Dummy.label("Dchke",20);
blas3test_infoc.infot = 1;
Dsymm.dsymm("/","U",0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dsymm.dsymm("L","/",0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsymm.dsymm("L","U",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsymm.dsymm("R","U",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsymm.dsymm("L","L",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsymm.dsymm("R","L",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsymm.dsymm("L","U",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsymm.dsymm("R","U",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsymm.dsymm("L","L",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsymm.dsymm("R","L",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsymm.dsymm("L","U",2,0,alpha,a,0,1,b,0,2,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsymm.dsymm("R","U",0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsymm.dsymm("L","L",2,0,alpha,a,0,1,b,0,2,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsymm.dsymm("R","L",0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsymm.dsymm("L","U",2,0,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsymm.dsymm("R","U",2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsymm.dsymm("L","L",2,0,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsymm.dsymm("R","L",2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsymm.dsymm("L","U",2,0,alpha,a,0,2,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsymm.dsymm("R","U",2,0,alpha,a,0,1,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsymm.dsymm("L","L",2,0,alpha,a,0,2,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsymm.dsymm("R","L",2,0,alpha,a,0,1,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
Dummy.go_to("Dchke",70);
label30:
   Dummy.label("Dchke",30);
blas3test_infoc.infot = 1;
Dtrmm.dtrmm("/","U","N","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dtrmm.dtrmm("L","/","N","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dtrmm.dtrmm("L","U","/","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dtrmm.dtrmm("L","U","N","/",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("L","U","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("L","U","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("R","U","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("R","U","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("L","L","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("L","L","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("R","L","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrmm.dtrmm("R","L","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("L","U","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("L","U","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("R","U","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("R","U","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("L","L","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("L","L","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("R","L","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrmm.dtrmm("R","L","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("L","U","N","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("L","U","T","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("R","U","N","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("R","U","T","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("L","L","N","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("L","L","T","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("R","L","N","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrmm.dtrmm("R","L","T","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("L","U","N","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("L","U","T","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("R","U","N","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("R","U","T","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("L","L","N","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("L","L","T","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("R","L","N","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrmm.dtrmm("R","L","T","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
Dummy.go_to("Dchke",70);
label40:
   Dummy.label("Dchke",40);
blas3test_infoc.infot = 1;
Dtrsm.dtrsm("/","U","N","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dtrsm.dtrsm("L","/","N","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dtrsm.dtrsm("L","U","/","N",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dtrsm.dtrsm("L","U","N","/",0,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("L","U","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("L","U","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("R","U","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("R","U","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("L","L","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("L","L","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("R","L","N","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 5;
Dtrsm.dtrsm("R","L","T","N",-1,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("L","U","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("L","U","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("R","U","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("R","U","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("L","L","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("L","L","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("R","L","N","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 6;
Dtrsm.dtrsm("R","L","T","N",0,-1,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("L","U","N","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("L","U","T","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("R","U","N","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("R","U","T","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("L","L","N","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("L","L","T","N",2,0,alpha,a,0,1,b,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("R","L","N","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dtrsm.dtrsm("R","L","T","N",0,2,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("L","U","N","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("L","U","T","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("R","U","N","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("R","U","T","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("L","L","N","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("L","L","T","N",2,0,alpha,a,0,2,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("R","L","N","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 11;
Dtrsm.dtrsm("R","L","T","N",2,0,alpha,a,0,1,b,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
Dummy.go_to("Dchke",70);
label50:
   Dummy.label("Dchke",50);
blas3test_infoc.infot = 1;
Dsyrk.dsyrk("/","N",0,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dsyrk.dsyrk("U","/",0,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyrk.dsyrk("U","N",-1,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyrk.dsyrk("U","T",-1,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyrk.dsyrk("L","N",-1,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyrk.dsyrk("L","T",-1,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyrk.dsyrk("U","N",0,-1,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyrk.dsyrk("U","T",0,-1,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyrk.dsyrk("L","N",0,-1,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyrk.dsyrk("L","T",0,-1,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyrk.dsyrk("U","N",2,0,alpha,a,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyrk.dsyrk("U","T",0,2,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyrk.dsyrk("L","N",2,0,alpha,a,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyrk.dsyrk("L","T",0,2,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dsyrk.dsyrk("U","N",2,0,alpha,a,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dsyrk.dsyrk("U","T",2,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dsyrk.dsyrk("L","N",2,0,alpha,a,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 10;
Dsyrk.dsyrk("L","T",2,0,alpha,a,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
Dummy.go_to("Dchke",70);
label60:
   Dummy.label("Dchke",60);
blas3test_infoc.infot = 1;
Dsyr2k.dsyr2k("/","N",0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 2;
Dsyr2k.dsyr2k("U","/",0,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyr2k.dsyr2k("U","N",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyr2k.dsyr2k("U","T",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyr2k.dsyr2k("L","N",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 3;
Dsyr2k.dsyr2k("L","T",-1,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyr2k.dsyr2k("U","N",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyr2k.dsyr2k("U","T",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyr2k.dsyr2k("L","N",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 4;
Dsyr2k.dsyr2k("L","T",0,-1,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyr2k.dsyr2k("U","N",2,0,alpha,a,0,1,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyr2k.dsyr2k("U","T",0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyr2k.dsyr2k("L","N",2,0,alpha,a,0,1,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 7;
Dsyr2k.dsyr2k("L","T",0,2,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsyr2k.dsyr2k("U","N",2,0,alpha,a,0,2,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsyr2k.dsyr2k("U","T",0,2,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsyr2k.dsyr2k("L","N",2,0,alpha,a,0,2,b,0,1,beta,c,0,2);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 9;
Dsyr2k.dsyr2k("L","T",0,2,alpha,a,0,2,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsyr2k.dsyr2k("U","N",2,0,alpha,a,0,2,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsyr2k.dsyr2k("U","T",2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsyr2k.dsyr2k("L","N",2,0,alpha,a,0,2,b,0,2,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
blas3test_infoc.infot = 12;
Dsyr2k.dsyr2k("L","T",2,0,alpha,a,0,1,b,0,1,beta,c,0,1);
Chkxer.chkxer(srnamt,blas3test_infoc.infot,nout,blas3test_infoc.lerr,blas3test_infoc.ok);
// *
label70:
   Dummy.label("Dchke",70);
if (blas3test_infoc.ok.val)  {
    System.out.println(" "  + (srnamt) + " "  + " PASSED THE TESTS OF ERROR-EXITS" );
}              // Close if()
else  {
  System.out.println(" ******* "  + (srnamt) + " "  + " FAILED THE TESTS OF ERROR-EXITS *****"  + "**" );
}              //  Close else.
Dummy.go_to("Dchke",999999);
// *
// *
// *     End of DCHKE.
// *
Dummy.label("Dchke",999999);
return;
   }
} // End class.
