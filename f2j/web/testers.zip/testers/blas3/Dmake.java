/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dmake {

// *
// *  Generates values for an M by N matrix A.
// *  Stores the values in the array AA in the data structure required
// *  by the routine, with unwanted elements set to rogue value.
// *
// *  TYPE is 'GE', 'SY' or 'TR'.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double rogue= -1.0e10;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static int i= 0;
static int ibeg= 0;
static int iend= 0;
static int j= 0;
static boolean gen= false;
static boolean lower= false;
static boolean sym= false;
static boolean tri= false;
static boolean unit= false;
static boolean upper= false;
// *     .. External Functions ..
// *     .. Executable Statements ..

public static void dmake (String type,
String uplo,
String diag,
int m,
int n,
double [] a, int _a_offset,
int nmax,
double [] aa, int _aa_offset,
int lda,
booleanW reset,
double transl)  {

gen = type.trim().equalsIgnoreCase("GE".trim());
sym = type.trim().equalsIgnoreCase("SY".trim());
tri = type.trim().equalsIgnoreCase("TR".trim());
upper = (sym || tri) && uplo.trim().equalsIgnoreCase("U".trim());
lower = (sym || tri) && uplo.trim().equalsIgnoreCase("L".trim());
unit = tri && diag.trim().equalsIgnoreCase("U".trim());
// *
// *     Generate data in array A.
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= m; i++) {
if (gen || (upper && i <= j) || (lower && i >= j))  {
    a[(i)- 1+(j- 1)*nmax+ _a_offset] = Dbeg.dbeg(reset)+transl;
if (i != j)  {
    // *                 Set some elements to zero
if (n > 3 && j == n/2)  
    a[(i)- 1+(j- 1)*nmax+ _a_offset] = zero;
if (sym)  {
    a[(j)- 1+(i- 1)*nmax+ _a_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
}              // Close if()
else if (tri)  {
    a[(j)- 1+(i- 1)*nmax+ _a_offset] = zero;
}              // Close else if()
}              // Close if()
}              // Close if()
Dummy.label("Dmake",10);
}              //  Close for() loop. 
}
if (tri)  
    a[(j)- 1+(j- 1)*nmax+ _a_offset] = a[(j)- 1+(j- 1)*nmax+ _a_offset]+one;
if (unit)  
    a[(j)- 1+(j- 1)*nmax+ _a_offset] = one;
Dummy.label("Dmake",20);
}              //  Close for() loop. 
}
// *
// *     Store elements in array AS in data structure required by routine.
// *
if (type.trim().equalsIgnoreCase("GE".trim()))  {
    {
forloop50:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= m; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",30);
}              //  Close for() loop. 
}
{
forloop40:
for (i = m+1; i <= lda; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",40);
}              //  Close for() loop. 
}
Dummy.label("Dmake",50);
}              //  Close for() loop. 
}
}              // Close if()
else if (type.trim().equalsIgnoreCase("SY".trim()) || type.trim().equalsIgnoreCase("TR".trim()))  {
    {
forloop90:
for (j = 1; j <= n; j++) {
if (upper)  {
    ibeg = 1;
if (unit)  {
    iend = j-1;
}              // Close if()
else  {
  iend = j;
}              //  Close else.
}              // Close if()
else  {
  if (unit)  {
    ibeg = j+1;
}              // Close if()
else  {
  ibeg = j;
}              //  Close else.
iend = n;
}              //  Close else.
{
forloop60:
for (i = 1; i <= ibeg-1; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",60);
}              //  Close for() loop. 
}
{
forloop70:
for (i = ibeg; i <= iend; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = a[(i)- 1+(j- 1)*nmax+ _a_offset];
Dummy.label("Dmake",70);
}              //  Close for() loop. 
}
{
forloop80:
for (i = iend+1; i <= lda; i++) {
aa[(i+(j-1)*lda)- 1+ _aa_offset] = rogue;
Dummy.label("Dmake",80);
}              //  Close for() loop. 
}
Dummy.label("Dmake",90);
}              //  Close for() loop. 
}
}              // Close else if()
Dummy.go_to("Dmake",999999);
// *
// *     End of DMAKE.
// *
Dummy.label("Dmake",999999);
return;
   }
} // End class.
