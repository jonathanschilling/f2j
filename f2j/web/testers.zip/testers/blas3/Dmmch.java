/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Dmmch {

// *
// *  Checks the results of the computational tests.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static double erri= 0.0;
static int i= 0;
static int j= 0;
static int k= 0;
static boolean trana= false;
static boolean tranb= false;
// *     .. Intrinsic Functions ..
// *     .. Executable Statements ..

public static void dmmch (String transa,
String transb,
int m,
int n,
int kk,
double alpha,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double beta,
double [] c, int _c_offset,
int Ldc,
double [] ct, int _ct_offset,
double [] g, int _g_offset,
double [] cc, int _cc_offset,
int ldcc,
double eps,
doubleW err,
booleanW fatal,
int nout,
boolean mv)  {

trana = transa.trim().equalsIgnoreCase("T".trim()) || transa.trim().equalsIgnoreCase("C".trim());
tranb = transb.trim().equalsIgnoreCase("T".trim()) || transb.trim().equalsIgnoreCase("C".trim());
// *
// *     Compute expected result, one column at a time, in CT using data
// *     in A, B and C.
// *     Compute gauges in G.
// *
{
forloop120:
for (j = 1; j <= n; j++) {
// *
{
forloop10:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = zero;
g[(i)- 1+ _g_offset] = zero;
Dummy.label("Dmmch",10);
}              //  Close for() loop. 
}
if (!trana && !tranb)  {
    {
forloop30:
for (k = 1; k <= kk; k++) {
{
forloop20:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = ct[(i)- 1+ _ct_offset]+a[(i)- 1+(k- 1)*lda+ _a_offset]*b[(k)- 1+(j- 1)*ldb+ _b_offset];
g[(i)- 1+ _g_offset] = g[(i)- 1+ _g_offset]+Math.abs(a[(i)- 1+(k- 1)*lda+ _a_offset])*Math.abs(b[(k)- 1+(j- 1)*ldb+ _b_offset]);
Dummy.label("Dmmch",20);
}              //  Close for() loop. 
}
Dummy.label("Dmmch",30);
}              //  Close for() loop. 
}
}              // Close if()
else if (trana && !tranb)  {
    {
forloop50:
for (k = 1; k <= kk; k++) {
{
forloop40:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = ct[(i)- 1+ _ct_offset]+a[(k)- 1+(i- 1)*lda+ _a_offset]*b[(k)- 1+(j- 1)*ldb+ _b_offset];
g[(i)- 1+ _g_offset] = g[(i)- 1+ _g_offset]+Math.abs(a[(k)- 1+(i- 1)*lda+ _a_offset])*Math.abs(b[(k)- 1+(j- 1)*ldb+ _b_offset]);
Dummy.label("Dmmch",40);
}              //  Close for() loop. 
}
Dummy.label("Dmmch",50);
}              //  Close for() loop. 
}
}              // Close else if()
else if (!trana && tranb)  {
    {
forloop70:
for (k = 1; k <= kk; k++) {
{
forloop60:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = ct[(i)- 1+ _ct_offset]+a[(i)- 1+(k- 1)*lda+ _a_offset]*b[(j)- 1+(k- 1)*ldb+ _b_offset];
g[(i)- 1+ _g_offset] = g[(i)- 1+ _g_offset]+Math.abs(a[(i)- 1+(k- 1)*lda+ _a_offset])*Math.abs(b[(j)- 1+(k- 1)*ldb+ _b_offset]);
Dummy.label("Dmmch",60);
}              //  Close for() loop. 
}
Dummy.label("Dmmch",70);
}              //  Close for() loop. 
}
}              // Close else if()
else if (trana && tranb)  {
    {
forloop90:
for (k = 1; k <= kk; k++) {
{
forloop80:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = ct[(i)- 1+ _ct_offset]+a[(k)- 1+(i- 1)*lda+ _a_offset]*b[(j)- 1+(k- 1)*ldb+ _b_offset];
g[(i)- 1+ _g_offset] = g[(i)- 1+ _g_offset]+Math.abs(a[(k)- 1+(i- 1)*lda+ _a_offset])*Math.abs(b[(j)- 1+(k- 1)*ldb+ _b_offset]);
Dummy.label("Dmmch",80);
}              //  Close for() loop. 
}
Dummy.label("Dmmch",90);
}              //  Close for() loop. 
}
}              // Close else if()
{
forloop100:
for (i = 1; i <= m; i++) {
ct[(i)- 1+ _ct_offset] = alpha*ct[(i)- 1+ _ct_offset]+beta*c[(i)- 1+(j- 1)*Ldc+ _c_offset];
g[(i)- 1+ _g_offset] = Math.abs(alpha)*g[(i)- 1+ _g_offset]+Math.abs(beta)*Math.abs(c[(i)- 1+(j- 1)*Ldc+ _c_offset]);
Dummy.label("Dmmch",100);
}              //  Close for() loop. 
}
// *
// *        Compute the error ratio for this result.
// *
err.val = zero;
{
forloop110:
for (i = 1; i <= m; i++) {
erri = Math.abs(ct[(i)- 1+ _ct_offset]-cc[(i)- 1+(j- 1)*ldcc+ _cc_offset])/eps;
if (g[(i)- 1+ _g_offset] != zero)  
    erri = erri/g[(i)- 1+ _g_offset];
err.val = Math.max(err.val, erri) ;
if (err.val*Math.sqrt(eps) >= one)  
    Dummy.go_to("Dmmch",130);
Dummy.label("Dmmch",110);
}              //  Close for() loop. 
}
// *
Dummy.label("Dmmch",120);
}              //  Close for() loop. 
}
// *
// *     If the loop completes, all results are at least half accurate.
Dummy.go_to("Dmmch",150);
// *
// *     Report fatal error.
// *
label130:
   Dummy.label("Dmmch",130);
fatal.val = true;
System.out.println(" ******* FATAL ERROR - COMPUTED RESULT IS LESS THAN HAL"  + "F ACCURATE *******"  + "\n"  + "           EXPECTED RESULT   COMPU"  + "TED RESULT" );
{
forloop140:
for (i = 1; i <= m; i++) {
if (mv)  {
    System.out.println(" " + (i) + " "  + (ct[(i)- 1+ _ct_offset]) + " " );
}              // Close if()
else  {
  System.out.println(" " + (i) + " "  + (cc[(i)- 1+(j- 1)*ldcc+ _cc_offset]) + " " );
}              //  Close else.
Dummy.label("Dmmch",140);
}              //  Close for() loop. 
}
if (n > 1)  
    System.out.println("      THESE ARE THE RESULTS FOR COLUMN "  + (j) + " " );
// *
label150:
   Dummy.label("Dmmch",150);
Dummy.go_to("Dmmch",999999);
// *
// *
// *     End of DMMCH.
// *
Dummy.label("Dmmch",999999);
return;
   }
} // End class.
