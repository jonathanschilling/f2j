/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Lde {

// *
// *  Tests if two arrays are identical.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static int i= 0;
// *     .. Executable Statements ..
static boolean lde = false;


public static boolean lde (double [] ri, int _ri_offset,
double [] rj, int _rj_offset,
int lr)  {

{
forloop10:
for (i = 1; i <= lr; i++) {
if (ri[(i)- 1+ _ri_offset] != rj[(i)- 1+ _rj_offset])  
    Dummy.go_to("Lde",20);
Dummy.label("Lde",10);
}              //  Close for() loop. 
}
lde = true;
Dummy.go_to("Lde",30);
label20:
   Dummy.label("Lde",20);
lde = false;
label30:
   Dummy.label("Lde",30);
Dummy.go_to("Lde",999999);
// *
// *     End of LDE.
// *
Dummy.label("Lde",999999);
return lde;
   }
} // End class.
