/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: blas3test.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;



public class Lderes {

// *
// *  Tests if selected elements in two arrays are equal.
// *
// *  TYPE is 'GE' or 'SY'.
// *
// *  Auxiliary routine for test program for Level 3 Blas.
// *
// *  -- Written on 8-February-1989.
// *     Jack Dongarra, Argonne National Laboratory.
// *     Iain Duff, AERE Harwell.
// *     Jeremy Du Croz, Numerical Algorithms Group Ltd.
// *     Sven Hammarling, Numerical Algorithms Group Ltd.
// *
// *     .. Scalar Arguments ..
// *     .. Array Arguments ..
// *     .. Local Scalars ..
static int i= 0;
static int ibeg= 0;
static int iend= 0;
static int j= 0;
static boolean upper= false;
// *     .. Executable Statements ..
static boolean lderes = false;


public static boolean lderes (String type,
String uplo,
int m,
int n,
double [] aa, int _aa_offset,
double [] as, int _as_offset,
int lda)  {

upper = uplo.trim().equalsIgnoreCase("U".trim());
if (type.trim().equalsIgnoreCase("GE".trim()))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = m+1; i <= lda; i++) {
if (aa[(i)- 1+(j- 1)*lda+ _aa_offset] != as[(i)- 1+(j- 1)*lda+ _as_offset])  
    Dummy.go_to("Lderes",70);
Dummy.label("Lderes",10);
}              //  Close for() loop. 
}
Dummy.label("Lderes",20);
}              //  Close for() loop. 
}
}              // Close if()
else if (type.trim().equalsIgnoreCase("SY".trim()))  {
    {
forloop50:
for (j = 1; j <= n; j++) {
if (upper)  {
    ibeg = 1;
iend = j;
}              // Close if()
else  {
  ibeg = j;
iend = n;
}              //  Close else.
{
forloop30:
for (i = 1; i <= ibeg-1; i++) {
if (aa[(i)- 1+(j- 1)*lda+ _aa_offset] != as[(i)- 1+(j- 1)*lda+ _as_offset])  
    Dummy.go_to("Lderes",70);
Dummy.label("Lderes",30);
}              //  Close for() loop. 
}
{
forloop40:
for (i = iend+1; i <= lda; i++) {
if (aa[(i)- 1+(j- 1)*lda+ _aa_offset] != as[(i)- 1+(j- 1)*lda+ _as_offset])  
    Dummy.go_to("Lderes",70);
Dummy.label("Lderes",40);
}              //  Close for() loop. 
}
Dummy.label("Lderes",50);
}              //  Close for() loop. 
}
}              // Close else if()
// *
label60:
   Dummy.label("Lderes",60);
lderes = true;
Dummy.go_to("Lderes",80);
label70:
   Dummy.label("Lderes",70);
lderes = false;
label80:
   Dummy.label("Lderes",80);
Dummy.go_to("Lderes",999999);
// *
// *     End of LDERES.
// *
Dummy.label("Lderes",999999);
return lderes;
   }
} // End class.
