import org.netlib.util.*;

public class blas3test_infoc
{
static int infot= 0;
static int nout_noutc= 0;
static booleanW ok= new booleanW(false);
static booleanW lerr= new booleanW(false);
}
