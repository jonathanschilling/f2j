import org.netlib.util.*;

public class blas3test_srnamc
{
static String srnamt= new String("      ");
}
