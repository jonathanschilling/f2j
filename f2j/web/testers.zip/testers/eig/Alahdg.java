/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alahdg {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALAHDG prints header information for the different test paths.
// *
// *  Arguments
// *  =========
// *
// *  IOUNIT  (input) INTEGER
// *          The unit number to which the header information should be
// *          printed.
// *
// *  PATH    (input) CHARACTER*3
// *          The name of the path for which the header information is to
// *          be printed.  Current paths are
// *             GQR:  GQR (general matrices)
// *             GRQ:  GRQ (general matrices)
// *             LSE:  LSE Problem
// *             GLM:  GLM Problem
// *             GSV:  Generalized Singular Value Decomposition
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static String c2= new String("   ");
static int itype= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void alahdg (int iounit,
String path)  {

if (iounit <= 0)  
    Dummy.go_to("Alahdg",999999);
c2 = path.substring((1)-1,3);
// *
// *     First line describing matrices in this path
// *
if (c2.regionMatches(true,0,"GQR",0,3))  {
    itype = 1;
System.out.println("\n"  + " " + (path) + " "  + ": GQR factorization of general matrices" );
}              // Close if()
else if (c2.regionMatches(true,0,"GRQ",0,3))  {
    itype = 2;
System.out.println("\n"  + " " + (path) + " "  + ": GRQ factorization of general matrices" );
}              // Close else if()
else if (c2.regionMatches(true,0,"LSE",0,3))  {
    itype = 3;
System.out.println("\n"  + " " + (path) + " "  + ": LSE Problem" );
}              // Close else if()
else if (c2.regionMatches(true,0,"GLM",0,3))  {
    itype = 4;
System.out.println("\n"  + " " + (path) + " "  + ": GLM Problem" );
}              // Close else if()
else if (c2.regionMatches(true,0,"GSV",0,3))  {
    itype = 5;
System.out.println("\n"  + " " + (path) + " "  + ": Generalized Singular Value Decomposition" );
}              // Close else if()
// *
// *     Matrix types
// *
System.out.println(" " + ("Matrix types: ") + " " );
// *
if (itype == 1)  {
    System.out.println("   " + (1) + " "  + ": A-diagonal matrix  B-upper triangular" );
System.out.println("   " + (2) + " "  + ": A-upper triangular B-upper triangular" );
System.out.println("   " + (3) + " "  + ": A-lower triangular B-upper triangular" );
System.out.println("   " + (4) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (5) + " "  + ": Random matrices cond(A)= sqrt( 0.1/EPS ) "  + "cond(B)= sqrt( 0.1/EPS )" );
System.out.println("   " + (6) + " "  + ": Random matrices cond(A)= 0.1/EPS "  + "cond(B)= 0.1/EPS" );
System.out.println("   " + (7) + " "  + ": Matrix scaled near underflow limit" );
System.out.println("   " + (8) + " "  + ": Matrix scaled near overflow limit" );
}              // Close if()
else if (itype == 2)  {
    System.out.println("   " + (1) + " "  + ": A-diagonal matrix  B-lower triangular" );
System.out.println("   " + (2) + " "  + ": A-lower triangular B-diagonal triangular" );
System.out.println("   " + (3) + " "  + ": A-lower triangular B-upper triangular" );
System.out.println("   " + (4) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (5) + " "  + ": Random matrices cond(A)= sqrt( 0.1/EPS ) "  + "cond(B)= sqrt( 0.1/EPS )" );
System.out.println("   " + (6) + " "  + ": Random matrices cond(A)= 0.1/EPS "  + "cond(B)= 0.1/EPS" );
System.out.println("   " + (7) + " "  + ": Matrix scaled near underflow limit" );
System.out.println("   " + (8) + " "  + ": Matrix scaled near overflow limit" );
}              // Close else if()
else if (itype == 3)  {
    System.out.println("   " + (1) + " "  + ": A-diagonal matrix  B-upper triangular" );
System.out.println("   " + (2) + " "  + ": A-upper triangular B-upper triangular" );
System.out.println("   " + (3) + " "  + ": A-lower triangular B-upper triangular" );
System.out.println("   " + (4) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (5) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (6) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (7) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (8) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
}              // Close else if()
else if (itype == 4)  {
    System.out.println("   " + (1) + " "  + ": A-diagonal matrix  B-lower triangular" );
System.out.println("   " + (2) + " "  + ": A-lower triangular B-diagonal triangular" );
System.out.println("   " + (3) + " "  + ": A-lower triangular B-upper triangular" );
System.out.println("   " + (4) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (5) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (6) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (7) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (8) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
}              // Close else if()
else if (itype == 5)  {
    System.out.println("   " + (1) + " "  + ": A-diagonal matrix  B-upper triangular" );
System.out.println("   " + (2) + " "  + ": A-upper triangular B-upper triangular" );
System.out.println("   " + (3) + " "  + ": A-lower triangular B-upper triangular" );
System.out.println("   " + (4) + " "  + ": Random matrices cond(A)=100, cond(B)=10," );
System.out.println("   " + (5) + " "  + ": Random matrices cond(A)= sqrt( 0.1/EPS ) "  + "cond(B)= sqrt( 0.1/EPS )" );
System.out.println("   " + (6) + " "  + ": Random matrices cond(A)= 0.1/EPS "  + "cond(B)= 0.1/EPS" );
System.out.println("   " + (7) + " "  + ": Random matrices cond(A)= sqrt( 0.1/EPS ) "  + "cond(B)=  0.1/EPS " );
System.out.println("   " + (8) + " "  + ": Random matrices cond(A)= 0.1/EPS "  + "cond(B)=  sqrt( 0.1/EPS )" );
}              // Close else if()
// *
// *     Tests performed
// *
System.out.println(" " + ("Test ratios: ") + " " );
// *
if (itype == 1)  {
    // *
// *        GQR decomposition of rectangular matrices
// *
System.out.println("   " + (1) + " "  + ": norm( R - Q\' * A ) / ( min( N, M )*norm( A )"  + "* EPS )" );
System.out.println("   " + (2) + " "  + ": norm( T * Z - Q\' * B )  / ( min(P,N)*norm(B)"  + "* EPS )" );
System.out.println("   " + (3) + " "  + ": norm( I - Q\'*Q )   / ( N * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( I - Z\'*Z )   / ( P * EPS )" );
}              // Close if()
else if (itype == 2)  {
    // *
// *        GRQ decomposition of rectangular matrices
// *
System.out.println("   " + (1) + " "  + ": norm( R - A * Q\' ) / ( min( N,M )*norm(A) * "  + "EPS )" );
System.out.println("   " + (2) + " "  + ": norm( T * Q - Z\' * B )  / ( min( P,N ) * nor"  + "m(B)*EPS )" );
System.out.println("   " + (3) + " "  + ": norm( I - Q\'*Q )   / ( N * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( I - Z\'*Z )   / ( P * EPS )" );
}              // Close else if()
else if (itype == 3)  {
    // *
// *        LSE Problem
// *
System.out.println("   " + (1) + " "  + ": norm( A*x - c )  / ( norm(A)*norm(x) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B*x - d )  / ( norm(B)*norm(x) * EPS )" );
}              // Close else if()
else if (itype == 4)  {
    // *
// *        GLM Problem
// *
System.out.println("   " + (1) + " "  + ": norm( d - A*x - B*y ) / ( (norm(A)+norm(B) )*"  + "(norm(x)+norm(y))*EPS )" );
}              // Close else if()
else if (itype == 5)  {
    // *
// *        GSVD
// *
System.out.println("   " + (1) + " "  + ": norm( U\' * A * Q - D1 * R ) / ( min( M, N )*"  + "norm( A ) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( V\' * B * Q - D2 * R ) / ( min( P, N )*"  + "norm( B ) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( I - U\'*U )   / ( M * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( I - V\'*V )   / ( P * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( I - Q\'*Q )   / ( N * EPS )" );
}              // Close else if()
// *
// *
// *
// *
// *
// *
// *
// *     GQR test ratio
// *
// *
// *     GRQ test ratio
// *
// *
// *     LSE test ratio
// *
// *
// *     GLM test ratio
// *
// *
// *     GSVD test ratio
// *
Dummy.go_to("Alahdg",999999);
// *
// *     End of ALAHDG
// *
Dummy.label("Alahdg",999999);
return;
   }
} // End class.
