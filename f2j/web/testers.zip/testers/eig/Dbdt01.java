/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dbdt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DBDT01 reconstructs a general matrix A from its bidiagonal form
// *     A = Q * B * P'
// *  where Q (m by min(m,n)) and P' (min(m,n) by n) are orthogonal
// *  matrices and B is bidiagonal.
// *
// *  The test ratio to test the reduction is
// *     RESID = norm( A - Q * B * PT ) / ( n * norm(A) * EPS )
// *  where PT = P' and EPS is the machine precision.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrices A and Q.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and P'.
// *
// *  KD      (input) INTEGER
// *          If KD = 0, B is diagonal and the array E is not referenced.
// *          If KD = 1, the reduction was performed by xGEBRD; B is upper
// *          bidiagonal if M >= N, and lower bidiagonal if M < N.
// *          If KD = -1, the reduction was performed by xGBBRD; B is
// *          always upper bidiagonal.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m by n matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  Q       (input) DOUBLE PRECISION array, dimension (LDQ,N)
// *          The m by min(m,n) orthogonal matrix Q in the reduction
// *          A = Q * B * P'.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= max(1,M).
// *
// *  D       (input) DOUBLE PRECISION array, dimension (min(M,N))
// *          The diagonal elements of the bidiagonal matrix B.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (min(M,N)-1)
// *          The superdiagonal elements of the bidiagonal matrix B if
// *          m >= n, or the subdiagonal elements of B if m < n.
// *
// *  PT      (input) DOUBLE PRECISION array, dimension (LDPT,N)
// *          The min(m,n) by n orthogonal matrix P' in the reduction
// *          A = Q * B * P'.
// *
// *  LDPT    (input) INTEGER
// *          The leading dimension of the array PT.
// *          LDPT >= max(1,min(M,N)).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M+N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The test ratio:  norm(A - Q * B * P') / ( n * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dbdt01 (int m,
int n,
int kd,
double [] a, int _a_offset,
int lda,
double [] q, int _q_offset,
int ldq,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] pt, int _pt_offset,
int ldpt,
double [] work, int _work_offset,
doubleW resid)  {

if (m <= 0 || n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dbdt01",999999);
}              // Close if()
// *
// *     Compute A - Q * B * P' one column at a time.
// *
resid.val = zero;
if (kd != 0)  {
    // *
// *        B is bidiagonal.
// *
if (kd != 0 && m >= n)  {
    // *
// *           B is upper bidiagonal and M >= N.
// *
{
forloop20:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
{
forloop10:
for (i = 1; i <= n-1; i++) {
work[(m+i)- 1+ _work_offset] = d[(i)- 1+ _d_offset]*pt[(i)- 1+(j- 1)*ldpt+ _pt_offset]+e[(i)- 1+ _e_offset]*pt[(i+1)- 1+(j- 1)*ldpt+ _pt_offset];
Dummy.label("Dbdt01",10);
}              //  Close for() loop. 
}
work[(m+n)- 1+ _work_offset] = d[(n)- 1+ _d_offset]*pt[(n)- 1+(j- 1)*ldpt+ _pt_offset];
Dgemv.dgemv("No transpose",m,n,-one,q,_q_offset,ldq,work,(m+1)- 1+ _work_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt01",20);
}              //  Close for() loop. 
}
}              // Close if()
else if (kd < 0)  {
    // *
// *           B is upper bidiagonal and M < N.
// *
{
forloop40:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
{
forloop30:
for (i = 1; i <= m-1; i++) {
work[(m+i)- 1+ _work_offset] = d[(i)- 1+ _d_offset]*pt[(i)- 1+(j- 1)*ldpt+ _pt_offset]+e[(i)- 1+ _e_offset]*pt[(i+1)- 1+(j- 1)*ldpt+ _pt_offset];
Dummy.label("Dbdt01",30);
}              //  Close for() loop. 
}
work[(m+m)- 1+ _work_offset] = d[(m)- 1+ _d_offset]*pt[(m)- 1+(j- 1)*ldpt+ _pt_offset];
Dgemv.dgemv("No transpose",m,m,-one,q,_q_offset,ldq,work,(m+1)- 1+ _work_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt01",40);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  // *
// *           B is lower bidiagonal.
// *
{
forloop60:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
work[(m+1)- 1+ _work_offset] = d[(1)- 1+ _d_offset]*pt[(1)- 1+(j- 1)*ldpt+ _pt_offset];
{
forloop50:
for (i = 2; i <= m; i++) {
work[(m+i)- 1+ _work_offset] = e[(i-1)- 1+ _e_offset]*pt[(i-1)- 1+(j- 1)*ldpt+ _pt_offset]+d[(i)- 1+ _d_offset]*pt[(i)- 1+(j- 1)*ldpt+ _pt_offset];
Dummy.label("Dbdt01",50);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",m,m,-one,q,_q_offset,ldq,work,(m+1)- 1+ _work_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt01",60);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  // *
// *        B is diagonal.
// *
if (m >= n)  {
    {
forloop80:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
{
forloop70:
for (i = 1; i <= n; i++) {
work[(m+i)- 1+ _work_offset] = d[(i)- 1+ _d_offset]*pt[(i)- 1+(j- 1)*ldpt+ _pt_offset];
Dummy.label("Dbdt01",70);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",m,n,-one,q,_q_offset,ldq,work,(m+1)- 1+ _work_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt01",80);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop100:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
{
forloop90:
for (i = 1; i <= m; i++) {
work[(m+i)- 1+ _work_offset] = d[(i)- 1+ _d_offset]*pt[(i)- 1+(j- 1)*ldpt+ _pt_offset];
Dummy.label("Dbdt01",90);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",m,m,-one,q,_q_offset,ldq,work,(m+1)- 1+ _work_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt01",100);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
// *
// *     Compute norm(A - Q * B * P') / ( n * norm(A) * EPS )
// *
anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,work,_work_offset);
eps = Dlamch.dlamch("Precision");
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  if (anorm >= resid.val)  {
    resid.val = (resid.val/anorm)/((double)(n)*eps);
}              // Close if()
else  {
  if (anorm < one)  {
    resid.val = (Math.min(resid.val, (double)(n)*anorm) /anorm)/((double)(n)*eps);
}              // Close if()
else  {
  resid.val = Math.min(resid.val/anorm, (double)(n)) /((double)(n)*eps);
}              //  Close else.
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dbdt01",999999);
// *
// *     End of DBDT01
// *
Dummy.label("Dbdt01",999999);
return;
   }
} // End class.
