/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dbdt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DBDT02 tests the change of basis C = U' * B by computing the residual
// *
// *     RESID = norm( B - U * C ) / ( max(m,n) * norm(B) * EPS ),
// *
// *  where B and C are M by N matrices, U is an M by M orthogonal matrix,
// *  and EPS is the machine precision.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrices B and C and the order of
// *          the matrix Q.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices B and C.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,N)
// *          The m by n matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,M).
// *
// *  C       (input) DOUBLE PRECISION array, dimension (LDC,N)
// *          The m by n matrix C, assumed to contain U' * B.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C.  LDC >= max(1,M).
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU,M)
// *          The m by m orthogonal matrix U.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          RESID = norm( B - U * C ) / ( max(m,n) * norm(B) * EPS ),
// *
// * ======================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double bnorm= 0.0;
static double eps= 0.0;
static double realmn= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dbdt02 (int m,
int n,
double [] b, int _b_offset,
int ldb,
double [] c, int _c_offset,
int Ldc,
double [] u, int _u_offset,
int ldu,
double [] work, int _work_offset,
doubleW resid)  {

resid.val = zero;
if (m <= 0 || n <= 0)  
    Dummy.go_to("Dbdt02",999999);
realmn = (double)(Math.max(m, n) );
eps = Dlamch.dlamch("Precision");
// *
// *     Compute norm( B - U * C )
// *
{
forloop10:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,_work_offset,1);
Dgemv.dgemv("No transpose",m,m,-one,u,_u_offset,ldu,c,(1)- 1+(j- 1)*Ldc+ _c_offset,1,one,work,_work_offset,1);
resid.val = Math.max(resid.val, Dasum.dasum(m,work,_work_offset,1)) ;
Dummy.label("Dbdt02",10);
}              //  Close for() loop. 
}
// *
// *     Compute norm of B.
// *
bnorm = Dlange.dlange("1",m,n,b,_b_offset,ldb,work,_work_offset);
// *
if (bnorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  if (bnorm >= resid.val)  {
    resid.val = (resid.val/bnorm)/(realmn*eps);
}              // Close if()
else  {
  if (bnorm < one)  {
    resid.val = (Math.min(resid.val, realmn*bnorm) /bnorm)/(realmn*eps);
}              // Close if()
else  {
  resid.val = Math.min(resid.val/bnorm, realmn) /(realmn*eps);
}              //  Close else.
}              //  Close else.
}              //  Close else.
Dummy.go_to("Dbdt02",999999);
// *
// *     End of DBDT02
// *
Dummy.label("Dbdt02",999999);
return;
   }
} // End class.
