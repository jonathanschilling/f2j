/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dbdt03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DBDT03 reconstructs a bidiagonal matrix B from its SVD:
// *     S = U' * B * V
// *  where U and V are orthogonal matrices and S is diagonal.
// *
// *  The test ratio to test the singular value decomposition is
// *     RESID = norm( B - U * S * VT ) / ( n * norm(B) * EPS )
// *  where VT = V' and EPS is the machine precision.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix B is upper or lower bidiagonal.
// *          = 'U':  Upper bidiagonal
// *          = 'L':  Lower bidiagonal
// *
// *  N       (input) INTEGER
// *          The order of the matrix B.
// *
// *  KD      (input) INTEGER
// *          The bandwidth of the bidiagonal matrix B.  If KD = 1, the
// *          matrix B is bidiagonal, and if KD = 0, B is diagonal and E is
// *          not referenced.  If KD is greater than 1, it is assumed to be
// *          1, and if KD is less than 0, it is assumed to be 0.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the bidiagonal matrix B.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) superdiagonal elements of the bidiagonal matrix B
// *          if UPLO = 'U', or the (n-1) subdiagonal elements of B if
// *          UPLO = 'L'.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU,N)
// *          The n by n orthogonal matrix U in the reduction B = U'*A*P.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= max(1,N)
// *
// *  S       (input) DOUBLE PRECISION array, dimension (N)
// *          The singular values from the SVD of B, sorted in decreasing
// *          order.
// *
// *  VT      (input) DOUBLE PRECISION array, dimension (LDVT,N)
// *          The n by n orthogonal matrix V' in the reduction
// *          B = U * S * V'.
// *
// *  LDVT    (input) INTEGER
// *          The leading dimension of the array VT.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The test ratio:  norm(B - U * S * V') / ( n * norm(A) * EPS )
// *
// * ======================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double bnorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dbdt03 (String uplo,
int n,
int kd,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] u, int _u_offset,
int ldu,
double [] s, int _s_offset,
double [] vt, int _vt_offset,
int ldvt,
double [] work, int _work_offset,
doubleW resid)  {

resid.val = zero;
if (n <= 0)  
    Dummy.go_to("Dbdt03",999999);
// *
// *     Compute B - U * S * V' one column at a time.
// *
bnorm = zero;
if (kd >= 1)  {
    // *
// *        B is bidiagonal.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *           B is upper bidiagonal.
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = s[(i)- 1+ _s_offset]*vt[(i)- 1+(j- 1)*ldvt+ _vt_offset];
Dummy.label("Dbdt03",10);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",n,n,-one,u,_u_offset,ldu,work,(n+1)- 1+ _work_offset,1,zero,work,_work_offset,1);
work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]+d[(j)- 1+ _d_offset];
if (j > 1)  {
    work[(j-1)- 1+ _work_offset] = work[(j-1)- 1+ _work_offset]+e[(j-1)- 1+ _e_offset];
bnorm = Math.max(bnorm, Math.abs(d[(j)- 1+ _d_offset])+Math.abs(e[(j-1)- 1+ _e_offset])) ;
}              // Close if()
else  {
  bnorm = Math.max(bnorm, Math.abs(d[(j)- 1+ _d_offset])) ;
}              //  Close else.
resid.val = Math.max(resid.val, Dasum.dasum(n,work,_work_offset,1)) ;
Dummy.label("Dbdt03",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           B is lower bidiagonal.
// *
{
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = s[(i)- 1+ _s_offset]*vt[(i)- 1+(j- 1)*ldvt+ _vt_offset];
Dummy.label("Dbdt03",30);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",n,n,-one,u,_u_offset,ldu,work,(n+1)- 1+ _work_offset,1,zero,work,_work_offset,1);
work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]+d[(j)- 1+ _d_offset];
if (j < n)  {
    work[(j+1)- 1+ _work_offset] = work[(j+1)- 1+ _work_offset]+e[(j)- 1+ _e_offset];
bnorm = Math.max(bnorm, Math.abs(d[(j)- 1+ _d_offset])+Math.abs(e[(j)- 1+ _e_offset])) ;
}              // Close if()
else  {
  bnorm = Math.max(bnorm, Math.abs(d[(j)- 1+ _d_offset])) ;
}              //  Close else.
resid.val = Math.max(resid.val, Dasum.dasum(n,work,_work_offset,1)) ;
Dummy.label("Dbdt03",40);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  // *
// *        B is diagonal.
// *
{
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = 1; i <= n; i++) {
work[(n+i)- 1+ _work_offset] = s[(i)- 1+ _s_offset]*vt[(i)- 1+(j- 1)*ldvt+ _vt_offset];
Dummy.label("Dbdt03",50);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",n,n,-one,u,_u_offset,ldu,work,(n+1)- 1+ _work_offset,1,zero,work,_work_offset,1);
work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]+d[(j)- 1+ _d_offset];
resid.val = Math.max(resid.val, Dasum.dasum(n,work,_work_offset,1)) ;
Dummy.label("Dbdt03",60);
}              //  Close for() loop. 
}
j = Idamax.idamax(n,d,_d_offset,1);
bnorm = Math.abs(d[(j)- 1+ _d_offset]);
}              //  Close else.
// *
// *     Compute norm(B - U * S * V') / ( n * norm(B) * EPS )
// *
eps = Dlamch.dlamch("Precision");
// *
if (bnorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  if (bnorm >= resid.val)  {
    resid.val = (resid.val/bnorm)/((double)(n)*eps);
}              // Close if()
else  {
  if (bnorm < one)  {
    resid.val = (Math.min(resid.val, (double)(n)*bnorm) /bnorm)/((double)(n)*eps);
}              // Close if()
else  {
  resid.val = Math.min(resid.val/bnorm, (double)(n)) /((double)(n)*eps);
}              //  Close else.
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dbdt03",999999);
// *
// *     End of DBDT03
// *
Dummy.label("Dbdt03",999999);
return;
   }
} // End class.
