/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkbd {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKBD checks the singular value decomposition (SVD) routines.
// *
// *  DGEBRD reduces a real general m by n matrix A to upper or lower
// *  bidiagonal form B by an orthogonal transformation:  Q' * A * P = B
// *  (or A = Q * B * P').  The matrix B is upper bidiagonal if m >= n
// *  and lower bidiagonal if m < n.
// *
// *  DORGBR generates the orthogonal matrices Q and P' from DGEBRD.
// *  Note that Q and P are not necessarily square.
// *
// *  DBDSQR computes the singular value decomposition of the bidiagonal
// *  matrix B as B = U S V'.  It is called three times to compute
// *     1)  B = U S1 V', where S1 is the diagonal matrix of singular
// *         values and the columns of the matrices U and V are the left
// *         and right singular vectors, respectively, of B.
// *     2)  Same as 1), but the singular values are stored in S2 and the
// *         singular vectors are not computed.
// *     3)  A = (UQ) S (P'V'), the SVD of the original matrix A.
// *  In addition, DBDSQR has an option to apply the left orthogonal matrix
// *  U to a matrix X, useful in least squares applications.
// *
// *  For each pair of matrix dimensions (M,N) and each selected matrix
// *  type, an M by N matrix A and an M by NRHS matrix X are generated.
// *  The problem dimensions are as follows
// *     A:          M x N
// *     Q:          M x min(M,N) (but M x M if NRHS > 0)
// *     P:          min(M,N) x N
// *     B:          min(M,N) x min(M,N)
// *     U, V:       min(M,N) x min(M,N)
// *     S1, S2      diagonal, order min(M,N)
// *     X:          M x NRHS
// *
// *  For each generated matrix, 14 tests are performed:
// *
// *  Test DGEBRD and DORGBR
// *
// *  (1)   | A - Q B PT | / ( |A| max(M,N) ulp ), PT = P'
// *
// *  (2)   | I - Q' Q | / ( M ulp )
// *
// *  (3)   | I - PT PT' | / ( N ulp )
// *
// *  Test DBDSQR on bidiagonal matrix B
// *
// *  (4)   | B - U S1 VT | / ( |B| min(M,N) ulp ), VT = V'
// *
// *  (5)   | Y - U Z | / ( |Y| max(min(M,N),k) ulp ), where Y = Q' X
// *                                                   and   Z = U' Y.
// *  (6)   | I - U' U | / ( min(M,N) ulp )
// *
// *  (7)   | I - VT VT' | / ( min(M,N) ulp )
// *
// *  (8)   S1 contains min(M,N) nonnegative values in decreasing order.
// *        (Return 0 if true, 1/ULP if false.)
// *
// *  (9)   | S1 - S2 | / ( |S1| ulp ), where S2 is computed without
// *                                    computing U and V.
// *
// *  (10)  0 if the true singular values of B are within THRESH of
// *        those in S1.  2*THRESH if they are not.  (Tested using
// *        DSVDCH)
// *
// *  Test DBDSQR on matrix A
// *
// *  (11)  | A - (QU) S (VT PT) | / ( |A| max(M,N) ulp )
// *
// *  (12)  | X - (QU) Z | / ( |X| max(M,k) ulp )
// *
// *  (13)  | I - (QU)'(QU) | / ( M ulp )
// *
// *  (14)  | I - (VT PT) (PT'VT') | / ( N ulp )
// *
// *  The possible matrix types are
// *
// *  (1)  The zero matrix.
// *  (2)  The identity matrix.
// *
// *  (3)  A diagonal matrix with evenly spaced entries
// *       1, ..., ULP  and random signs.
// *       (ULP = (first number larger than 1) - 1 )
// *  (4)  A diagonal matrix with geometrically spaced entries
// *       1, ..., ULP  and random signs.
// *  (5)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *       and random signs.
// *
// *  (6)  Same as (3), but multiplied by SQRT( overflow threshold )
// *  (7)  Same as (3), but multiplied by SQRT( underflow threshold )
// *
// *  (8)  A matrix of the form  U D V, where U and V are orthogonal and
// *       D has evenly spaced entries 1, ..., ULP with random signs
// *       on the diagonal.
// *
// *  (9)  A matrix of the form  U D V, where U and V are orthogonal and
// *       D has geometrically spaced entries 1, ..., ULP with random
// *       signs on the diagonal.
// *
// *  (10) A matrix of the form  U D V, where U and V are orthogonal and
// *       D has "clustered" entries 1, ULP,..., ULP with random
// *       signs on the diagonal.
// *
// *  (11) Same as (8), but multiplied by SQRT( overflow threshold )
// *  (12) Same as (8), but multiplied by SQRT( underflow threshold )
// *
// *  (13) Rectangular matrix with random entries chosen from (-1,1).
// *  (14) Same as (13), but multiplied by SQRT( overflow threshold )
// *  (15) Same as (13), but multiplied by SQRT( underflow threshold )
// *
// *  Special case:
// *  (16) A bidiagonal matrix with random entries chosen from a
// *       logarithmic distribution on [ulp^2,ulp^(-2)]  (I.e., each
// *       entry is  e^x, where x is chosen uniformly on
// *       [ 2 log(ulp), -2 log(ulp) ] .)  For *this* type:
// *       (a) DGEBRD is not called to reduce it to bidiagonal form.
// *       (b) the bidiagonal is  min(M,N) x min(M,N); if M<N, the
// *           matrix will be lower bidiagonal, otherwise upper.
// *       (c) only tests 5--8 and 14 are performed.
// *
// *  A subset of the full set of matrix types may be selected through
// *  the logical array DOTYPE.
// *
// *  Arguments
// *  ==========
// *
// *  NSIZES  (input) INTEGER
// *          The number of values of M and N contained in the vectors
// *          MVAL and NVAL.  The matrix sizes are used in pairs (M,N).
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix column dimension N.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DCHKBD
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrices are in A and B.
// *          This is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size (m,n), a matrix
// *          of type j will be generated.  If NTYPES is smaller than the
// *          maximum number of types defined (PARAMETER MAXTYP), then
// *          types NTYPES+1 through MAXTYP will not be generated.  If
// *          NTYPES is larger than MAXTYP, DOTYPE(MAXTYP+1) through
// *          DOTYPE(NTYPES) will be ignored.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns in the "right-hand side" matrices X, Y,
// *          and Z, used in testing DBDSQR.  If NRHS = 0, then the
// *          operations on the right-hand side will not be tested.
// *          NRHS must be at least 0.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The values of ISEED are changed on exit, and can be
// *          used in the next call to DCHKBD to continue the same random
// *          number sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.  Note that the
// *          expected value of the test ratios is O(1), so THRESH should
// *          be a reasonably small multiple of 1, e.g., 10 or 100.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (LDA,NMAX)
// *          where NMAX is the maximum value of N in NVAL.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,MMAX),
// *          where MMAX is the maximum value of M in MVAL.
// *
// *  BD      (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MVAL(j),NVAL(j))))
// *
// *  BE      (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MVAL(j),NVAL(j))))
// *
// *  S1      (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MVAL(j),NVAL(j))))
// *
// *  S2      (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MVAL(j),NVAL(j))))
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the arrays X, Y, and Z.
// *          LDX >= max(1,MMAX)
// *
// *  Y       (workspace) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *
// *  Z       (workspace) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDQ,MMAX)
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= max(1,MMAX).
// *
// *  PT      (workspace) DOUBLE PRECISION array, dimension (LDPT,NMAX)
// *
// *  LDPT    (input) INTEGER
// *          The leading dimension of the arrays PT, U, and V.
// *          LDPT >= max(1, max(min(MVAL(j),NVAL(j)))).
// *
// *  U       (workspace) DOUBLE PRECISION array, dimension
// *                      (LDPT,max(min(MVAL(j),NVAL(j))))
// *
// *  V       (workspace) DOUBLE PRECISION array, dimension
// *                      (LDPT,max(min(MVAL(j),NVAL(j))))
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          3(M+N) and  M(M + max(M,N,k) + 1) + N*min(M,N)  for all
// *          pairs  (M,N)=(MM(j),NN(j))
// *
// *  NOUT    (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *
// *  INFO    (output) INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some MM(j) < 0
// *           -3: Some NN(j) < 0
// *           -4: NTYPES < 0
// *           -6: NRHS  < 0
// *           -8: THRESH < 0
// *          -11: LDA < 1 or LDA < MMAX, where MMAX is max( MM(j) ).
// *          -17: LDB < 1 or LDB < MMAX.
// *          -21: LDQ < 1 or LDQ < MMAX.
// *          -23: LDPT< 1 or LDPT< MNMAX.
// *          -27: LWORK too small.
// *          If  DLATMR, SLATMS, DGEBRD, DORGBR, or DBDSQR,
// *              returns an error code, the
// *              absolute value of it is returned.
// *
// *-----------------------------------------------------------------------
// *
// *     Some Local Variables and Parameters:
// *     ---- ----- --------- --- ----------
// *
// *     ZERO, ONE       Real 0 and 1.
// *     MAXTYP          The number of types defined.
// *     NTEST           The number of tests performed, or which can
// *                     be performed so far, for the current matrix.
// *     MMAX            Largest value in NN.
// *     NMAX            Largest value in NN.
// *     MNMIN           min(MM(j), NN(j)) (the dimension of the bidiagonal
// *                     matrix.)
// *     MNMAX           The maximum value of MNMIN for j=1,...,NSIZES.
// *     NFAIL           The number of tests which have exceeded THRESH
// *     COND, IMODE     Values to be passed to the matrix generators.
// *     ANORM           Norm of A; passed to matrix generators.
// *
// *     OVFL, UNFL      Overflow and underflow thresholds.
// *     RTOVFL, RTUNFL  Square roots of the previous 2 values.
// *     ULP, ULPINV     Finest relative precision and its inverse.
// *
// *             The following four arrays decode JTYPE:
// *     KTYPE(j)        The general type (1-10) for type "j".
// *     KMODE(j)        The MODE value to be passed to the matrix
// *                     generator for type "j".
// *     KMAGN(j)        The order of magnitude ( O(1),
// *                     O(overflow^(1/2) ), O(underflow^(1/2) )
// *
// * ======================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double half= 0.5e0;
static int maxtyp= 16;
// *     ..
// *     .. Local Scalars ..
static boolean badmm= false;
static boolean badnn= false;
static boolean bidiag= false;
static String uplo= new String(" ");
static String path= new String("   ");
static int i= 0;
static intW iinfo= new intW(0);
static int imode= 0;
static int itype= 0;
static int j= 0;
static int jcol= 0;
static int jsize= 0;
static int jtype= 0;
static int log2ui= 0;
static int m= 0;
static int minwrk= 0;
static int mmax= 0;
static int mnmax= 0;
static int mnmin= 0;
static int mq= 0;
static int mtypes= 0;
static int n= 0;
static int nfail= 0;
static int nmax= 0;
static int ntest= 0;
static double amninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtovfl= 0.0;
static double rtunfl= 0.0;
static double temp1= 0.0;
static double temp2= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ioldsd= new int[(4)];
static int [] iwork= new int[(1)];
static double [] dumma= new double[(1)];
static double [] result= new double[(14)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 4, 4, 4, 4, 4 , 6, 6, 6, 6, 6 , 9, 9, 9 , 10 
};
static int [] kmagn = {1, 1 
, 1, 1, 1 , 2 , 3 , 1, 1, 1 , 2 
, 3 , 1 , 2 , 3 , 0 
};
static int [] kmode = {0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 4 , 4 
, 0 , 0 , 0 , 0 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dchkbd (int nsizes,
int [] mval, int _mval_offset,
int [] nval, int _nval_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int nrhs,
int [] iseed, int _iseed_offset,
double thresh,
double [] a, int _a_offset,
int lda,
double [] bd, int _bd_offset,
double [] be, int _be_offset,
double [] s1, int _s1_offset,
double [] s2, int _s2_offset,
double [] x, int _x_offset,
int ldx,
double [] y, int _y_offset,
double [] z, int _z_offset,
double [] q, int _q_offset,
int ldq,
double [] pt, int _pt_offset,
int ldpt,
double [] u, int _u_offset,
double [] vt, int _vt_offset,
double [] work, int _work_offset,
int lwork,
int nout,
intW info)  {

info.val = 0;
// *
badmm = false;
badnn = false;
mmax = 1;
nmax = 1;
mnmax = 1;
minwrk = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
mmax = (int)(Math.max(mmax, mval[(j)- 1+ _mval_offset]) );
if (mval[(j)- 1+ _mval_offset] < 0)  
    badmm = true;
nmax = (int)(Math.max(nmax, nval[(j)- 1+ _nval_offset]) );
if (nval[(j)- 1+ _nval_offset] < 0)  
    badnn = true;
mnmax = (int)(Math.max(mnmax, Math.min(mval[(j)- 1+ _mval_offset], nval[(j)- 1+ _nval_offset]) ) );
minwrk = (int)(Math.max((minwrk) > (3*(mval[(j)- 1+ _mval_offset]+nval[(j)- 1+ _nval_offset])) ? (minwrk) : (3*(mval[(j)- 1+ _mval_offset]+nval[(j)- 1+ _nval_offset])), mval[(j)- 1+ _mval_offset]*(mval[(j)- 1+ _mval_offset]+Math.max((mval[(j)- 1+ _mval_offset]) > (nval[(j)- 1+ _nval_offset]) ? (mval[(j)- 1+ _mval_offset]) : (nval[(j)- 1+ _nval_offset]), nrhs)+1)+nval[(j)- 1+ _nval_offset]*Math.min(nval[(j)- 1+ _nval_offset], mval[(j)- 1+ _mval_offset]) ));
Dummy.label("Dchkbd",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badmm)  {
    info.val = -2;
}              // Close else if()
else if (badnn)  {
    info.val = -3;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -4;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -6;
}              // Close else if()
else if (lda < mmax)  {
    info.val = -11;
}              // Close else if()
else if (ldx < mmax)  {
    info.val = -17;
}              // Close else if()
else if (ldq < mmax)  {
    info.val = -21;
}              // Close else if()
else if (ldpt < mnmax)  {
    info.val = -23;
}              // Close else if()
else if (minwrk > lwork)  {
    info.val = -27;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DCHKBD",-info.val);
Dummy.go_to("Dchkbd",999999);
}              // Close if()
// *
// *     Initialize constants
// *
{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "BD".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nfail = 0;
ntest = 0;
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = Dlamch.dlamch("Overflow");
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Precision");
ulpinv = one/ulp;
log2ui = (int)(Math.log(ulpinv)/Math.log(two));
rtunfl = Math.sqrt(unfl.val);
rtovfl = Math.sqrt(ovfl.val);
eigtest_infoc.infot = 0;
// *
// *     Loop over sizes, types
// *
{
forloop180:
for (jsize = 1; jsize <= nsizes; jsize++) {
m = mval[(jsize)- 1+ _mval_offset];
n = nval[(jsize)- 1+ _nval_offset];
mnmin = (int)(Math.min(m, n) );
amninv = one/Math.max((m) > (n) ? (m) : (n), 1);
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop170:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop170;
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Dchkbd",20);
}              //  Close for() loop. 
}
// *
{
forloop30:
for (j = 1; j <= 14; j++) {
result[(j)- 1] = -one;
Dummy.label("Dchkbd",30);
}              //  Close for() loop. 
}
// *
uplo = " ";
// *
// *           Compute "A"
// *
// *           Control parameters:
// *
// *           KMAGN  KMODE        KTYPE
// *       =1  O(1)   clustered 1  zero
// *       =2  large  clustered 2  identity
// *       =3  small  exponential  (none)
// *       =4         arithmetic   diagonal, (w/ eigenvalues)
// *       =5         random       symmetric, w/ eigenvalues
// *       =6                      nonsymmetric, w/ singular values
// *       =7                      random diagonal
// *       =8                      random symmetric
// *       =9                      random nonsymmetric
// *       =10                     random bidiagonal (log. distrib.)
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Dchkbd",100);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Dchkbd",40);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Dchkbd",50);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Dchkbd",60);
// *
label40:
   Dummy.label("Dchkbd",40);
anorm = one;
Dummy.go_to("Dchkbd",70);
// *
label50:
   Dummy.label("Dchkbd",50);
anorm = (rtovfl*ulp)*amninv;
Dummy.go_to("Dchkbd",70);
// *
label60:
   Dummy.label("Dchkbd",60);
anorm = rtunfl*Math.max(m, n) *ulpinv;
Dummy.go_to("Dchkbd",70);
// *
label70:
   Dummy.label("Dchkbd",70);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
cond = ulpinv;
// *
bidiag = false;
if (itype == 1)  {
    // *
// *              Zero matrix
// *
iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
{
forloop80:
for (jcol = 1; jcol <= mnmin; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Dchkbd",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(mnmin,mnmin,"S",iseed,_iseed_offset,"N",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              Symmetric, eigenvalues specified
// *
Dlatms.dlatms(mnmin,mnmin,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,m,n,"N",a,_a_offset,lda,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 6)  {
    // *
// *              Nonsymmetric, singular values specified
// *
Dlatms.dlatms(m,n,"S",iseed,_iseed_offset,"N",work,_work_offset,imode,cond,anorm,m,n,"N",a,_a_offset,lda,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random entries
// *
Dlatmr.dlatmr(mnmin,mnmin,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(mnmin+1)- 1+ _work_offset,1,one,work,(2*mnmin+1)- 1+ _work_offset,1,one,"N",iwork,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,0,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              Symmetric, random entries
// *
Dlatmr.dlatmr(mnmin,mnmin,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(mnmin+1)- 1+ _work_offset,1,one,work,(m+mnmin+1)- 1+ _work_offset,1,one,"N",iwork,0,m,n,zero,anorm,"NO",a,_a_offset,lda,iwork,0,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              Nonsymmetric, random entries
// *
Dlatmr.dlatmr(m,n,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(mnmin+1)- 1+ _work_offset,1,one,work,(m+mnmin+1)- 1+ _work_offset,1,one,"N",iwork,0,m,n,zero,anorm,"NO",a,_a_offset,lda,iwork,0,iinfo);
// *
}              // Close else if()
else if (itype == 10)  {
    // *
// *              Bidiagonal, random entries
// *
temp1 = -two*Math.log(ulp);
{
forloop90:
for (j = 1; j <= mnmin; j++) {
bd[(j)- 1+ _bd_offset] = Math.exp(temp1*Dlarnd.dlarnd(2,iseed,_iseed_offset));
if (j < mnmin)  
    be[(j)- 1+ _be_offset] = Math.exp(temp1*Dlarnd.dlarnd(2,iseed,_iseed_offset));
Dummy.label("Dchkbd",90);
}              //  Close for() loop. 
}
// *
iinfo.val = 0;
bidiag = true;
if (m >= n)  {
    uplo = "U";
}              // Close if()
else  {
  uplo = "L";
}              //  Close else.
}              // Close else if()
else  {
  iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val == 0)  {
    // *
// *              Generate Right-Hand Side
// *
if (bidiag)  {
    Dlatmr.dlatmr(mnmin,nrhs,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(mnmin+1)- 1+ _work_offset,1,one,work,(2*mnmin+1)- 1+ _work_offset,1,one,"N",iwork,0,mnmin,nrhs,zero,one,"NO",y,_y_offset,ldx,iwork,0,iinfo);
}              // Close if()
else  {
  Dlatmr.dlatmr(m,nrhs,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(m+1)- 1+ _work_offset,1,one,work,(2*m+1)- 1+ _work_offset,1,one,"N",iwork,0,m,nrhs,zero,one,"NO",x,_x_offset,ldx,iwork,0,iinfo);
}              //  Close else.
}              // Close if()
// *
// *           Error Exit
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkbd",999999);
}              // Close if()
// *
label100:
   Dummy.label("Dchkbd",100);
// *
// *           Call DGEBRD and DORGBR to compute B, Q, and P, do tests.
// *
if (!bidiag)  {
    // *
// *              Compute transformations to reduce A to bidiagonal form:
// *              B := Q' * A * P.
// *
Dlacpy.dlacpy(" ",m,n,a,_a_offset,lda,q,_q_offset,ldq);
Dgebrd.dgebrd(m,n,q,_q_offset,ldq,bd,_bd_offset,be,_be_offset,work,_work_offset,work,(mnmin+1)- 1+ _work_offset,work,(2*mnmin+1)- 1+ _work_offset,lwork-2*mnmin,iinfo);
// *
// *              Check error code from DGEBRD.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("DGEBRD") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkbd",999999);
}              // Close if()
// *
Dlacpy.dlacpy(" ",m,n,q,_q_offset,ldq,pt,_pt_offset,ldpt);
if (m >= n)  {
    uplo = "U";
}              // Close if()
else  {
  uplo = "L";
}              //  Close else.
// *
// *              Generate Q
// *
mq = m;
if (nrhs <= 0)  
    mq = mnmin;
Dorgbr.dorgbr("Q",m,mq,n,q,_q_offset,ldq,work,_work_offset,work,(2*mnmin+1)- 1+ _work_offset,lwork-2*mnmin,iinfo);
// *
// *              Check error code from DORGBR.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("DORGBR(Q)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkbd",999999);
}              // Close if()
// *
// *              Generate P'
// *
Dorgbr.dorgbr("P",mnmin,n,m,pt,_pt_offset,ldpt,work,(mnmin+1)- 1+ _work_offset,work,(2*mnmin+1)- 1+ _work_offset,lwork-2*mnmin,iinfo);
// *
// *              Check error code from DORGBR.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("DORGBR(P)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkbd",999999);
}              // Close if()
// *
// *              Apply Q' to an M by NRHS matrix X:  Y := Q' * X.
// *
Dgemm.dgemm("Transpose","No transpose",m,nrhs,m,one,q,_q_offset,ldq,x,_x_offset,ldx,zero,y,_y_offset,ldx);
// *
// *              Test 1:  Check the decomposition A := Q * B * PT
// *                   2:  Check the orthogonality of Q
// *                   3:  Check the orthogonality of PT
// *
dbdt01_adapter(m,n,1,a,_a_offset,lda,q,_q_offset,ldq,bd,_bd_offset,be,_be_offset,pt,_pt_offset,ldpt,work,_work_offset,result,(1)- 1);
dort01_adapter("Columns",m,mq,q,_q_offset,ldq,work,_work_offset,lwork,result,(2)- 1);
dort01_adapter("Rows",mnmin,n,pt,_pt_offset,ldpt,work,_work_offset,lwork,result,(3)- 1);
}              // Close if()
// *
// *           Use DBDSQR to form the SVD of the bidiagonal matrix B:
// *           B := U * S1 * VT, and compute Z = U' * Y.
// *
Dcopy.dcopy(mnmin,bd,_bd_offset,1,s1,_s1_offset,1);
if (mnmin > 0)  
    Dcopy.dcopy(mnmin-1,be,_be_offset,1,work,_work_offset,1);
Dlacpy.dlacpy(" ",m,nrhs,y,_y_offset,ldx,z,_z_offset,ldx);
Dlaset.dlaset("Full",mnmin,mnmin,zero,one,u,_u_offset,ldpt);
Dlaset.dlaset("Full",mnmin,mnmin,zero,one,vt,_vt_offset,ldpt);
// *
Dbdsqr.dbdsqr(uplo,mnmin,mnmin,mnmin,nrhs,s1,_s1_offset,work,_work_offset,vt,_vt_offset,ldpt,u,_u_offset,ldpt,z,_z_offset,ldx,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
// *           Check error code from DBDSQR.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("DBDSQR(vects)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkbd",999999);
}              // Close if()
else  {
  result[(4)- 1] = ulpinv;
Dummy.go_to("Dchkbd",150);
}              //  Close else.
}              // Close if()
// *
// *           Use DBDSQR to compute only the singular values of the
// *           bidiagonal matrix B;  U, VT, and Z should not be modified.
// *
Dcopy.dcopy(mnmin,bd,_bd_offset,1,s2,_s2_offset,1);
if (mnmin > 0)  
    Dcopy.dcopy(mnmin-1,be,_be_offset,1,work,_work_offset,1);
// *
Dbdsqr.dbdsqr(uplo,mnmin,0,0,0,s2,_s2_offset,work,_work_offset,vt,_vt_offset,ldpt,u,_u_offset,ldpt,z,_z_offset,ldx,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
// *           Check error code from DBDSQR.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKBD: "  + ("DBDSQR(values)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkbd",999999);
}              // Close if()
else  {
  result[(9)- 1] = ulpinv;
Dummy.go_to("Dchkbd",150);
}              //  Close else.
}              // Close if()
// *
// *           Test 4:  Check the decomposition B := U * S1 * VT
// *                5:  Check the computation Z := U' * Y
// *                6:  Check the orthogonality of U
// *                7:  Check the orthogonality of VT
// *
dbdt03_adapter(uplo,mnmin,1,bd,_bd_offset,be,_be_offset,u,_u_offset,ldpt,s1,_s1_offset,vt,_vt_offset,ldpt,work,_work_offset,result,(4)- 1);
dbdt02_adapter(mnmin,nrhs,y,_y_offset,ldx,z,_z_offset,ldx,u,_u_offset,ldpt,work,_work_offset,result,(5)- 1);
dort01_adapter("Columns",mnmin,mnmin,u,_u_offset,ldpt,work,_work_offset,lwork,result,(6)- 1);
dort01_adapter("Rows",mnmin,mnmin,vt,_vt_offset,ldpt,work,_work_offset,lwork,result,(7)- 1);
// *
// *           Test 8:  Check that the singular values are sorted in
// *                    non-increasing order and are non-negative
// *
result[(8)- 1] = zero;
{
forloop110:
for (i = 1; i <= mnmin-1; i++) {
if (s1[(i)- 1+ _s1_offset] < s1[(i+1)- 1+ _s1_offset])  
    result[(8)- 1] = ulpinv;
if (s1[(i)- 1+ _s1_offset] < zero)  
    result[(8)- 1] = ulpinv;
Dummy.label("Dchkbd",110);
}              //  Close for() loop. 
}
if (mnmin >= 1)  {
    if (s1[(mnmin)- 1+ _s1_offset] < zero)  
    result[(8)- 1] = ulpinv;
}              // Close if()
// *
// *           Test 9:  Compare DBDSQR with and without singular vectors
// *
temp2 = zero;
// *
{
forloop120:
for (j = 1; j <= mnmin; j++) {
temp1 = Math.abs(s1[(j)- 1+ _s1_offset]-s2[(j)- 1+ _s2_offset])/Math.max(Math.sqrt(unfl.val)*Math.max(s1[(1)- 1+ _s1_offset], one) , ulp*Math.max(Math.abs(s1[(j)- 1+ _s1_offset]), Math.abs(s2[(j)- 1+ _s2_offset])) ) ;
temp2 = Math.max(temp1, temp2) ;
Dummy.label("Dchkbd",120);
}              //  Close for() loop. 
}
// *
result[(9)- 1] = temp2;
// *
// *           Test 10:  Sturm sequence test of singular values
// *                     Go up by factors of two until it succeeds
// *
temp1 = thresh*(half-ulp);
// *
{
forloop130:
for (j = 0; j <= log2ui; j++) {
Dsvdch.dsvdch(mnmin,bd,_bd_offset,be,_be_offset,s1,_s1_offset,temp1,iinfo);
if (iinfo.val == 0)  
    Dummy.go_to("Dchkbd",140);
temp1 = temp1*two;
Dummy.label("Dchkbd",130);
}              //  Close for() loop. 
}
// *
label140:
   Dummy.label("Dchkbd",140);
result[(10)- 1] = temp1;
// *
// *           Use DBDSQR to form the decomposition A := (QU) S (VT PT)
// *           from the bidiagonal form A := Q B PT.
// *
if (!bidiag)  {
    Dcopy.dcopy(mnmin,bd,_bd_offset,1,s2,_s2_offset,1);
if (mnmin > 0)  
    Dcopy.dcopy(mnmin-1,be,_be_offset,1,work,_work_offset,1);
// *
Dbdsqr.dbdsqr(uplo,mnmin,n,m,nrhs,s2,_s2_offset,work,_work_offset,pt,_pt_offset,ldpt,q,_q_offset,ldq,y,_y_offset,ldx,work,(mnmin+1)- 1+ _work_offset,iinfo);
// *
// *              Test 11:  Check the decomposition A := Q*U * S2 * VT*PT
// *                   12:  Check the computation Z := U' * Q' * X
// *                   13:  Check the orthogonality of Q*U
// *                   14:  Check the orthogonality of VT*PT
// *
dbdt01_adapter(m,n,0,a,_a_offset,lda,q,_q_offset,ldq,s2,_s2_offset,dumma,0,pt,_pt_offset,ldpt,work,_work_offset,result,(11)- 1);
dbdt02_adapter(m,nrhs,x,_x_offset,ldx,y,_y_offset,ldx,q,_q_offset,ldq,work,_work_offset,result,(12)- 1);
dort01_adapter("Columns",m,mq,q,_q_offset,ldq,work,_work_offset,lwork,result,(13)- 1);
dort01_adapter("Rows",mnmin,n,pt,_pt_offset,ldpt,work,_work_offset,lwork,result,(14)- 1);
}              // Close if()
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
label150:
   Dummy.label("Dchkbd",150);
{
forloop160:
for (j = 1; j <= 14; j++) {
if (result[(j)- 1] >= thresh)  {
    if (nfail == 0)  
    Dlahd2.dlahd2(nout,path);
System.out.println(" M="  + (m) + " "  + ", N="  + (n) + " "  + ", type "  + (jtype) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (j) + " "  + ","  + (result[(j)- 1]) + " "  + ","  + " NULL " + " "  + ","  + " test("  + " NULL " + " "  + ")="  + " NULL " + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkbd",160);
}              //  Close for() loop. 
}
if (!bidiag)  {
    ntest = ntest+14;
}              // Close if()
else  {
  ntest = ntest+5;
}              //  Close else.
// *
Dummy.label("Dchkbd",170);
}              //  Close for() loop. 
}
Dummy.label("Dchkbd",180);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Alasum.alasum(path,nout,nfail,ntest,0);
// *
Dummy.go_to("Dchkbd",999999);
// *
// *     End of DCHKBD
// *
// *
Dummy.label("Dchkbd",999999);
return;
   }
// adapter for dbdt01
private static void dbdt01_adapter(int arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,int arg10 ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dbdt01.dbdt01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8, arg8_offset,arg9, arg9_offset,arg10,arg11, arg11_offset,_f2j_tmp12);

arg12[arg12_offset] = _f2j_tmp12.val;
}

// adapter for dort01
private static void dort01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dort01.dort01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dbdt03
private static void dbdt03_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dbdt03.dbdt03(arg0,arg1,arg2,arg3, arg3_offset,arg4, arg4_offset,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

// adapter for dbdt02
private static void dbdt02_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset )
{
doubleW _f2j_tmp9 = new doubleW(arg9[arg9_offset]);

Dbdt02.dbdt02(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,_f2j_tmp9);

arg9[arg9_offset] = _f2j_tmp9.val;
}

} // End class.
