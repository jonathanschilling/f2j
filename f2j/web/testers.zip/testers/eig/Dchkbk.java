/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkbk {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKBK tests DGEBAK, a routine for backward transformation of
// *  the computed right or left eigenvectors if the orginal matrix
// *  was preprocessed by balance subroutine DGEBAL.
// *
// *  Arguments
// *  =========
// *
// *  NIN     (input) INTEGER
// *          The logical unit number for input.  NIN > 0.
// *
// *  NOUT    (input) INTEGER
// *          The logical unit number for output.  NOUT > 0.
// *
// * ======================================================================
// *
// *     .. Parameters ..
static int lde= 20;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ihi= 0;
static int ilo= 0;
static intW info= new intW(0);
static int j= 0;
static int knt= 0;
static int n= 0;
static int ninfo= 0;
static double eps= 0.0;
static double rmax= 0.0;
static double safmin= 0.0;
static double vmax= 0.0;
static double x= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] lmax= new int[(2)];
static double [] e= new double[(lde) * (lde)];
static double [] ein= new double[(lde) * (lde)];
static double [] scale= new double[(lde)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dchkbk (int nin,
int nout)  {

  EasyIn _f2j_in = new EasyIn();
lmax[(1)- 1] = 0;
lmax[(2)- 1] = 0;
ninfo = 0;
knt = 0;
rmax = zero;
eps = Dlamch.dlamch("E");
safmin = Dlamch.dlamch("S");
// *
label10:
   Dummy.label("Dchkbk",10);
// *
n = _f2j_in.readInt();
ilo = _f2j_in.readInt();
ihi = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dchkbk",60);
// *
for(i = 1; i <= n; i++)
scale[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
e[(i)- 1+(j- 1)*lde] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkbk",20);
}              //  Close for() loop. 
}
// *
{
forloop30:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
ein[(i)- 1+(j- 1)*lde] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkbk",30);
}              //  Close for() loop. 
}
// *
knt = knt+1;
Dgebak.dgebak("B","R",n,ilo,ihi,scale,0,n,e,0,lde,info);
// *
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(1)- 1] = knt;
}              // Close if()
// *
vmax = zero;
{
forloop50:
for (i = 1; i <= n; i++) {
{
forloop40:
for (j = 1; j <= n; j++) {
x = Math.abs(e[(i)- 1+(j- 1)*lde]-ein[(i)- 1+(j- 1)*lde])/eps;
if (Math.abs(e[(i)- 1+(j- 1)*lde]) > safmin)  
    x = x/Math.abs(e[(i)- 1+(j- 1)*lde]);
vmax = Math.max(vmax, x) ;
Dummy.label("Dchkbk",40);
}              //  Close for() loop. 
}
Dummy.label("Dchkbk",50);
}              //  Close for() loop. 
}
// *
if (vmax > rmax)  {
    lmax[(2)- 1] = knt;
rmax = vmax;
}              // Close if()
// *
Dummy.go_to("Dchkbk",10);
// *
label60:
   Dummy.label("Dchkbk",60);
// *
System.out.println(" " + ".. test output of DGEBAK .. " );
// *
System.out.println(" " + "value of largest test error             = "  + (rmax) + " " );
System.out.println(" " + "example number where info is not zero   = "  + (lmax[(1)- 1]) + " " );
System.out.println(" " + "example number having largest error     = "  + (lmax[(2)- 1]) + " " );
System.out.println(" " + "number of examples where info is not 0  = "  + (ninfo) + " " );
System.out.println(" " + "total number of examples tested         = "  + (knt) + " " );
// *
Dummy.go_to("Dchkbk",999999);
// *
// *     End of DCHKBK
// *
Dummy.label("Dchkbk",999999);
return;
   }
} // End class.
