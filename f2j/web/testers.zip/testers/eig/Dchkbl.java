/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkbl {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKBL tests DGEBAL, a routine for balancing a general real
// *  matrix and isolating some of its eigenvalues.
// *
// *  Arguments
// *  =========
// *
// *  NIN     (input) INTEGER
// *          The logical unit number for input.  NIN > 0.
// *
// *  NOUT    (input) INTEGER
// *          The logical unit number for output.  NOUT > 0.
// *
// * ======================================================================
// *
// *     .. Parameters ..
static int lda= 20;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW ihi= new intW(0);
static int ihiin= 0;
static intW ilo= new intW(0);
static int iloin= 0;
static intW info= new intW(0);
static int j= 0;
static int knt= 0;
static int n= 0;
static int ninfo= 0;
static double anorm= 0.0;
static double rmax= 0.0;
static double vmax= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] lmax= new int[(3)];
static double [] a= new double[(lda) * (lda)];
static double [] ain= new double[(lda) * (lda)];
static double [] dummy= new double[(1)];
static double [] scale= new double[(lda)];
static double [] scalin= new double[(lda)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dchkbl (int nin,
int nout)  {

  EasyIn _f2j_in = new EasyIn();
lmax[(1)- 1] = 0;
lmax[(2)- 1] = 0;
lmax[(3)- 1] = 0;
ninfo = 0;
knt = 0;
rmax = zero;
// *
label10:
   Dummy.label("Dchkbl",10);
// *
n = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dchkbl",70);
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
a[(i)- 1+(j- 1)*lda] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkbl",20);
}              //  Close for() loop. 
}
// *
iloin = _f2j_in.readInt();
ihiin = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop30:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
ain[(i)- 1+(j- 1)*lda] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkbl",30);
}              //  Close for() loop. 
}
for(i = 1; i <= n; i++)
scalin[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *
anorm = Dlange.dlange("M",n,n,a,0,lda,dummy,0);
knt = knt+1;
// *
Dgebal.dgebal("B",n,a,0,lda,ilo,ihi,scale,0,info);
// *
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(1)- 1] = knt;
}              // Close if()
// *
if (ilo.val != iloin || ihi.val != ihiin)  {
    ninfo = ninfo+1;
lmax[(2)- 1] = knt;
}              // Close if()
// *
vmax = zero;
{
forloop50:
for (i = 1; i <= n; i++) {
{
forloop40:
for (j = 1; j <= n; j++) {
vmax = Math.max(vmax, Math.abs(a[(i)- 1+(j- 1)*lda]-ain[(i)- 1+(j- 1)*lda])) ;
Dummy.label("Dchkbl",40);
}              //  Close for() loop. 
}
Dummy.label("Dchkbl",50);
}              //  Close for() loop. 
}
// *
{
forloop60:
for (i = 1; i <= n; i++) {
vmax = Math.max(vmax, Math.abs(scale[(i)- 1]-scalin[(i)- 1])) ;
Dummy.label("Dchkbl",60);
}              //  Close for() loop. 
}
// *
vmax = vmax/anorm/Dlamch.dlamch("E");
// *
if (vmax > rmax)  {
    lmax[(3)- 1] = knt;
rmax = vmax;
}              // Close if()
// *
Dummy.go_to("Dchkbl",10);
// *
label70:
   Dummy.label("Dchkbl",70);
// *
System.out.println(" " + ".. test output of DGEBAL .. " );
// *
System.out.println(" " + "value of largest test error             = "  + (rmax) + " " );
System.out.println(" " + "example number where info is not zero   = "  + (lmax[(1)- 1]) + " " );
System.out.println(" " + "example number where ILO or IHI wrong   = "  + (lmax[(2)- 1]) + " " );
System.out.println(" " + "example number having largest error     = "  + (lmax[(3)- 1]) + " " );
System.out.println(" " + "number of examples where info is not 0  = "  + (ninfo) + " " );
System.out.println(" " + "total number of examples tested         = "  + (knt) + " " );
// *
Dummy.go_to("Dchkbl",999999);
// *
// *     End of DCHKBL
// *
Dummy.label("Dchkbl",999999);
return;
   }
} // End class.
