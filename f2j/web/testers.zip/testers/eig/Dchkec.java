/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkec {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKEC tests eigen- condition estimation routines
// *         DLALN2, SLASY2, SLANV2, SLAQTR, SLAEXC,
// *         DTRSYL, STREXC, STRSNA, STRSEN
// *
// *  In all cases, the routine runs through a fixed set of numerical
// *  examples, subjects them to various tests, and compares the test
// *  results to a threshold THRESH. In addition, DTREXC, STRSNA and STRSEN
// *  are tested by reading in precomputed examples from a file (on input
// *  unit NIN).  Output is written to output unit NOUT.
// *
// *  Arguments
// *  =========
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          Threshold for residual tests.  A computed test ratio passes
// *          the threshold if it is less than THRESH.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NIN     (input) INTEGER
// *          The logical unit number for input.
// *
// *  NOUT    (input) INTEGER
// *          The logical unit number for output.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean ok= false;
static String path= new String("   ");
static intW klaexc= new intW(0);
static intW klaln2= new intW(0);
static intW klanv2= new intW(0);
static intW klaqtr= new intW(0);
static intW klasy2= new intW(0);
static intW ktrexc= new intW(0);
static intW ktrsen= new intW(0);
static intW ktrsna= new intW(0);
static intW ktrsyl= new intW(0);
static intW llaexc= new intW(0);
static intW llaln2= new intW(0);
static intW llanv2= new intW(0);
static intW llaqtr= new intW(0);
static intW llasy2= new intW(0);
static intW ltrexc= new intW(0);
static intW ltrsyl= new intW(0);
static intW nlanv2= new intW(0);
static intW nlaqtr= new intW(0);
static intW nlasy2= new intW(0);
static int ntests= 0;
static intW ntrsyl= new intW(0);
static double eps= 0.0;
static doubleW rlaexc= new doubleW(0.0);
static doubleW rlaln2= new doubleW(0.0);
static doubleW rlanv2= new doubleW(0.0);
static doubleW rlaqtr= new doubleW(0.0);
static doubleW rlasy2= new doubleW(0.0);
static doubleW rtrexc= new doubleW(0.0);
static doubleW rtrsyl= new doubleW(0.0);
static double sfmin= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] ltrsen= new int[(3)];
static int [] ltrsna= new int[(3)];
static int [] nlaexc= new int[(2)];
static int [] nlaln2= new int[(2)];
static int [] ntrexc= new int[(3)];
static int [] ntrsen= new int[(3)];
static int [] ntrsna= new int[(3)];
static double [] rtrsen= new double[(3)];
static double [] rtrsna= new double[(3)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dchkec (double thresh,
boolean tsterr,
int nin,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "EC".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
eps = Dlamch.dlamch("P");
sfmin = Dlamch.dlamch("S");
// *
// *     Print header information
// *
System.out.println(" Tests of the Nonsymmetric eigenproblem condition estim"  + "ation routines"  + "\n"  + " DLALN2, SLASY2, SLANV2, SLAEXC, DTRS"  + "YL, DTREXC, STRSNA, STRSEN, DLAQTR"  + "\n" );
System.out.println(" Relative machine precision (EPS) = "  + (eps) + " "  + "\n"  + " Safe "  + "minimum (SFMIN)             = "  + (sfmin) + " "  + "\n" );
System.out.println(" Routines pass computational tests if test ratio is les"  + "s than"  + (thresh) + " "  + "\n\n" );
// *
// *     Test error exits if TSTERR is .TRUE.
// *
if (tsterr)  
    Derrec.derrec(path,nout);
// *
ok = true;
Dget31.dget31(rlaln2,llaln2,nlaln2,0,klaln2);
if (rlaln2.val > thresh || nlaln2[(1)- 1] != 0)  {
    ok = false;
System.out.println(" Error in DLALN2: RMAX ="  + (rlaln2.val) + " "  + "\n"  + " LMAX = "  + (llaln2.val) + " "  + " N"  + "INFO="  + (nlaln2) + " "  + " KNT="  + (klaln2.val) + " " );
}              // Close if()
// *
Dget32.dget32(rlasy2,llasy2,nlasy2,klasy2);
if (rlasy2.val > thresh)  {
    ok = false;
System.out.println(" Error in DLASY2: RMAX ="  + (rlasy2.val) + " "  + "\n"  + " LMAX = "  + (llasy2.val) + " "  + " N"  + "INFO="  + (nlasy2.val) + " "  + " KNT="  + (klasy2.val) + " " );
}              // Close if()
// *
Dget33.dget33(rlanv2,llanv2,nlanv2,klanv2);
if (rlanv2.val > thresh || nlanv2.val != 0)  {
    ok = false;
System.out.println(" Error in DLANV2: RMAX ="  + (rlanv2.val) + " "  + "\n"  + " LMAX = "  + (llanv2.val) + " "  + " N"  + "INFO="  + (nlanv2.val) + " "  + " KNT="  + (klanv2.val) + " " );
}              // Close if()
// *
Dget34.dget34(rlaexc,llaexc,nlaexc,0,klaexc);
if (rlaexc.val > thresh || nlaexc[(2)- 1] != 0)  {
    ok = false;
System.out.println(" Error in DLAEXC: RMAX ="  + (rlaexc.val) + " "  + "\n"  + " LMAX = "  + (llaexc.val) + " "  + " N"  + "INFO="  + (nlaexc) + " "  + " KNT="  + (klaexc.val) + " " );
}              // Close if()
// *
Dget35.dget35(rtrsyl,ltrsyl,ntrsyl,ktrsyl);
if (rtrsyl.val > thresh)  {
    ok = false;
System.out.println(" Error in DTRSYL: RMAX ="  + (rtrsyl.val) + " "  + "\n"  + " LMAX = "  + (ltrsyl.val) + " "  + " N"  + "INFO="  + (ntrsyl.val) + " "  + " KNT="  + (ktrsyl.val) + " " );
}              // Close if()
// *
Dget36.dget36(rtrexc,ltrexc,ntrexc,0,ktrexc,nin);
if (rtrexc.val > thresh || ntrexc[(3)- 1] > 0)  {
    ok = false;
System.out.println(" Error in DTREXC: RMAX ="  + (rtrexc.val) + " "  + "\n"  + " LMAX = "  + (ltrexc.val) + " "  + " N"  + "INFO="  + (ntrexc) + " "  + " KNT="  + (ktrexc.val) + " " );
}              // Close if()
// *
Dget37.dget37(rtrsna,0,ltrsna,0,ntrsna,0,ktrsna,nin);
if (rtrsna[(1)- 1] > thresh || rtrsna[(2)- 1] > thresh || ntrsna[(1)- 1] != 0 || ntrsna[(2)- 1] != 0 || ntrsna[(3)- 1] != 0)  {
    ok = false;
System.out.println(" Error in DTRSNA: RMAX ="  + (rtrsna) + " "  + "\n"  + " LMAX = "  + (ltrsna) + " "  + " NINFO="  + (ntrsna) + " "  + " KNT="  + (ktrsna.val) + " " );
}              // Close if()
// *
Dget38.dget38(rtrsen,0,ltrsen,0,ntrsen,0,ktrsen,nin);
if (rtrsen[(1)- 1] > thresh || rtrsen[(2)- 1] > thresh || ntrsen[(1)- 1] != 0 || ntrsen[(2)- 1] != 0 || ntrsen[(3)- 1] != 0)  {
    ok = false;
System.out.println(" Error in DTRSEN: RMAX ="  + (rtrsen) + " "  + "\n"  + " LMAX = "  + (ltrsen) + " "  + " NINFO="  + (ntrsen) + " "  + " KNT="  + (ktrsen.val) + " " );
}              // Close if()
// *
Dget39.dget39(rlaqtr,llaqtr,nlaqtr,klaqtr);
if (rlaqtr.val > thresh)  {
    ok = false;
System.out.println(" Error in DLAQTR: RMAX ="  + (rlaqtr.val) + " "  + "\n"  + " LMAX = "  + (llaqtr.val) + " "  + " N"  + "INFO="  + (nlaqtr.val) + " "  + " KNT="  + (klaqtr.val) + " " );
}              // Close if()
// *
ntests = klaln2.val+klasy2.val+klanv2.val+klaexc.val+ktrsyl.val+ktrexc.val+ktrsna.val+ktrsen.val+klaqtr.val;
if (ok)  
    System.out.println("\n"  + " " + "All tests for "  + (path) + " "  + " routines passed the thresh"  + "old ("  + (ntests) + " "  + " tests run)" );
// *
Dummy.go_to("Dchkec",999999);
// *
// *     End of DCHKEC
// *
Dummy.label("Dchkec",999999);
return;
   }
} // End class.
