/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkee {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *  Purpose
// *  =======
// *
// *  DCHKEE tests the DOUBLE PRECISION LAPACK subroutines for the matrix
// *  eigenvalue problem.  The test paths in this version are
// *
// *  NEP (Nonsymmetric Eigenvalue Problem):
// *      Test DGEHRD, DORGHR, DHSEQR, DTREVC, DHSEIN, and DORMHR
// *
// *  SEP (Symmetric Eigenvalue Problem):
// *      Test DSYTRD, DORGTR, DSTEQR, DSTERF, DSTEIN, DSTEDC,
// *      and drivers DSYEV(X), DSBEV(X), DSPEV(X), DSTEV(X),
// *                  DSYEVD,   DSBEVD,   DSPEVD,   DSTEVD
// *
// *  SVD (Singular Value Decomposition):
// *      Test DGEBRD, DORGBR, and DBDSQR
// *      and the driver routine DGESVD
// *
// *  DEV (Nonsymmetric Eigenvalue/eigenvector Driver):
// *      Test DGEEV
// *
// *  DES (Nonsymmetric Schur form Driver):
// *      Test DGEES
// *
// *  DVX (Nonsymmetric Eigenvalue/eigenvector Expert Driver):
// *      Test DGEEVX
// *
// *  DSX (Nonsymmetric Schur form Expert Driver):
// *      Test DGEESX
// *
// *  DGG (Generalized Nonsymmetric Eigenvalue Problem):
// *      Test DGGHRD, DGGBAL, DGGBAK, DHGEQZ, and DTGEVC
// *      and the driver routines DGEGS and DGEGV
// *
// *  DSG (Symmetric Generalized Eigenvalue Problem):
// *      Test DSYGST, DSYGV, DSPGST, DSPGV, DSBGST, and DSBGV
// *
// *  DSB (Symmetric Band Eigenvalue Problem):
// *      Test DSBTRD
// *
// *  DBB (Band Singular Value Decomposition):
// *      Test DGBBRD
// *
// *  DEC (Eigencondition estimation):
// *      Test DLALN2, DLASY2, DLAEQU, DLAEXC, DTRSYL, DTREXC, DTRSNA,
// *      DTRSEN, and DLAQTR
// *
// *  DBL (Balancing a general matrix)
// *      Test DGEBAL
// *
// *  DBK (Back transformation on a balanced matrix)
// *      Test DGEBAK
// *
// *  DGL (Balancing a matrix pair)
// *      Test DGGBAL
// *
// *  DGK (Back transformation on a matrix pair)
// *      Test DGGBAK
// *
// *  GLM (Generalized Linear Regression Model):
// *      Tests DGGGLM
// *
// *  GQR (Generalized QR and RQ factorizations):
// *      Tests DGGQRF and DGGRQF
// *
// *  GSV (Generalized Singular Value Decomposition):
// *      Tests DGGSVD, DGGSVP, DTGSJA, DLAGS2, DLAPLL, and DLAPMT
// *
// *  LSE (Constrained Linear Least Squares):
// *      Tests DGGLSE
// *
// *  Each test path has a different set of inputs, but the data sets for
// *  the driver routines xEV, xES, xVX, and xSX can be concatenated in a
// *  single input file.  The first line of input should contain one of the
// *  3-character path names in columns 1-3.  The number of remaining lines
// *  depends on what is found on the first line.
// *
// *  The number of matrix types used in testing is often controllable from
// *  the input file.  The number of matrix types for each path, and the
// *  test routine that describes them, is as follows:
// *
// *  Path name(s)  Types    Test routine
// *
// *  DHS or NEP      21     DCHKHS
// *  DST or SEP      21     DCHKST (routines)
// *                  18     DDRVST (drivers)
// *  DBD or SVD      16     DCHKBD (routines)
// *                   5     DDRVBD (drivers)
// *  DEV             21     DDRVEV
// *  DES             21     DDRVES
// *  DVX             21     DDRVVX
// *  DSX             21     DDRVSX
// *  DGG             26     DCHKGG (routines)
// *                  26     DDRVGG (drivers)
// *  DSG             21     DDRVSG
// *  DSB             15     DCHKSB
// *  DBB             15     DCHKBB
// *  DEC              -     DCHKEC
// *  DBL              -     DCHKBL
// *  DBK              -     DCHKBK
// *  DGL              -     DCHKGL
// *  DGK              -     DCHKGK
// *  GLM              8     DCKGLM
// *  GQR              8     DCKGQR
// *  GSV              8     DCKGSV
// *  LSE              8     DCKLSE
// *
// *-----------------------------------------------------------------------
// *
// *  NEP input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of N.
// *
// *  line 3:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix dimension N.
// *
// *  line 4:  NPARMS, INTEGER
// *           Number of values of the parameters NB, NBMIN, NX, NS, and
// *           MAXB.
// *
// *  line 5:  NBVAL, INTEGER array, dimension (NPARMS)
// *           The values for the blocksize NB.
// *
// *  line 6:  NBMIN, INTEGER array, dimension (NPARMS)
// *           The values for the minimum blocksize NBMIN.
// *
// *  line 7:  NXVAL, INTEGER array, dimension (NPARMS)
// *           The values for the crossover point NX.
// *
// *  line 8:  NSVAL, INTEGER array, dimension (NPARMS)
// *           The values for the number of shifts.
// *
// *  line 9:  MXBVAL, INTEGER array, dimension (NPARMS)
// *           The values for MAXB, used in determining minimum blocksize.
// *
// *  line 10: THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.  To have all of the test
// *           ratios printed, use THRESH = 0.0 .
// *
// *  line 11: NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 11 was 2:
// *
// *  line 12: INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 12-EOF:  The remaining lines occur in sets of 1 or 2 and allow
// *           the user to specify the matrix types.  Each line contains
// *           a 3-character path name in columns 1-3, and the number
// *           of matrix types must be the first nonblank item in columns
// *           4-80.  If the number of matrix types is at least 1 but is
// *           less than the maximum number of possible types, a second
// *           line will be read to get the numbers of the matrix types to
// *           be used.  For example,
// *  NEP 21
// *           requests all of the matrix types for the nonsymmetric
// *           eigenvalue problem, while
// *  NEP  4
// *  9 10 11 12
// *           requests only matrices of type 9, 10, 11, and 12.
// *
// *           The valid 3-character path names are 'NEP' or 'DHS' for the
// *           nonsymmetric eigenvalue routines.
// *
// *-----------------------------------------------------------------------
// *
// *  SEP or DSG input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of N.
// *
// *  line 3:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix dimension N.
// *
// *  line 4:  NPARMS, INTEGER
// *           Number of values of the parameters NB, NBMIN, and NX.
// *
// *  line 5:  NBVAL, INTEGER array, dimension (NPARMS)
// *           The values for the blocksize NB.
// *
// *  line 6:  NBMIN, INTEGER array, dimension (NPARMS)
// *           The values for the minimum blocksize NBMIN.
// *
// *  line 7:  NXVAL, INTEGER array, dimension (NPARMS)
// *           The values for the crossover point NX.
// *
// *  line 8:  THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 9:  TSTCHK, LOGICAL
// *           Flag indicating whether or not to test the LAPACK routines.
// *
// *  line 10: TSTDRV, LOGICAL
// *           Flag indicating whether or not to test the driver routines.
// *
// *  line 11: TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 12: NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 12 was 2:
// *
// *  line 13: INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 13-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path names are 'SEP' or 'DST' for the
// *           symmetric eigenvalue routines and driver routines, and
// *           'DSG' for the routines for the symmetric generalized
// *           eigenvalue problem.
// *
// *-----------------------------------------------------------------------
// *
// *  SVD input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension (NN)
// *           The values for the matrix row dimension M.
// *
// *  line 4:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix column dimension N.
// *
// *  line 5:  NPARMS, INTEGER
// *           Number of values of the parameter NB, NBMIN, NX, and NRHS.
// *
// *  line 6:  NBVAL, INTEGER array, dimension (NPARMS)
// *           The values for the blocksize NB.
// *
// *  line 7:  NBMIN, INTEGER array, dimension (NPARMS)
// *           The values for the minimum blocksize NBMIN.
// *
// *  line 8:  NXVAL, INTEGER array, dimension (NPARMS)
// *           The values for the crossover point NX.
// *
// *  line 9:  NSVAL, INTEGER array, dimension (NPARMS)
// *           The values for the number of right hand sides NRHS.
// *
// *  line 10: THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 11: TSTCHK, LOGICAL
// *           Flag indicating whether or not to test the LAPACK routines.
// *
// *  line 12: TSTDRV, LOGICAL
// *           Flag indicating whether or not to test the driver routines.
// *
// *  line 13: TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 14: NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 14 was 2:
// *
// *  line 15: INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 15-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path names are 'SVD' or 'DBD' for both the
// *           SVD routines and the SVD driver routines.
// *
// *-----------------------------------------------------------------------
// *
// *  DEV and DES data files:
// *
// *  line 1:  'DEV' or 'DES' in columns 1 to 3.
// *
// *  line 2:  NSIZES, INTEGER
// *           Number of sizes of matrices to use. Should be at least 0
// *           and at most 20. If NSIZES = 0, no testing is done
// *           (although the remaining  3 lines are still read).
// *
// *  line 3:  NN, INTEGER array, dimension(NSIZES)
// *           Dimensions of matrices to be tested.
// *
// *  line 4:  NB, NBMIN, NX, NS, NBCOL, INTEGERs
// *           These integer parameters determine how blocking is done
// *           (see ILAENV for details)
// *           NB     : block size
// *           NBMIN  : minimum block size
// *           NX     : minimum dimension for blocking
// *           NS     : number of shifts in xHSEQR
// *           NBCOL  : minimum column dimension for blocking
// *
// *  line 5:  THRESH, REAL
// *           The test threshold against which computed residuals are
// *           compared. Should generally be in the range from 10. to 20.
// *           If it is 0., all test case data will be printed.
// *
// *  line 6:  TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits.
// *
// *  line 7:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 7 was 2:
// *
// *  line 8:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 9 and following:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'DEV' to test DGEEV, or
// *           'DES' to test DGEES.
// *
// *-----------------------------------------------------------------------
// *
// *  The DVX data has two parts. The first part is identical to DEV,
// *  and the second part consists of test matrices with precomputed
// *  solutions.
// *
// *  line 1:  'DVX' in columns 1-3.
// *
// *  line 2:  NSIZES, INTEGER
// *           If NSIZES = 0, no testing of randomly generated examples
// *           is done, but any precomputed examples are tested.
// *
// *  line 3:  NN, INTEGER array, dimension(NSIZES)
// *
// *  line 4:  NB, NBMIN, NX, NS, NBCOL, INTEGERs
// *
// *  line 5:  THRESH, REAL
// *
// *  line 6:  TSTERR, LOGICAL
// *
// *  line 7:  NEWSD, INTEGER
// *
// *  If line 7 was 2:
// *
// *  line 8:  INTEGER array, dimension (4)
// *
// *  lines 9 and following: The first line contains 'DVX' in columns 1-3
// *           followed by the number of matrix types, possibly with
// *           a second line to specify certain matrix types.
// *           If the number of matrix types = 0, no testing of randomly
// *           generated examples is done, but any precomputed examples
// *           are tested.
// *
// *  remaining lines : Each matrix is stored on 1+2*N lines, where N is
// *           its dimension. The first line contains the dimension (a
// *           single integer). The next N lines contain the matrix, one
// *           row per line. The last N lines correspond to each
// *           eigenvalue. Each of these last N lines contains 4 real
// *           values: the real part of the eigenvalue, the imaginary
// *           part of the eigenvalue, the reciprocal condition number of
// *           the eigenvalues, and the reciprocal condition number of the
// *           eigenvector.  The end of data is indicated by dimension N=0.
// *           Even if no data is to be tested, there must be at least one
// *           line containing N=0.
// *
// *-----------------------------------------------------------------------
// *
// *  The DSX data is like DVX. The first part is identical to DEV, and the
// *  second part consists of test matrices with precomputed solutions.
// *
// *  line 1:  'DSX' in columns 1-3.
// *
// *  line 2:  NSIZES, INTEGER
// *           If NSIZES = 0, no testing of randomly generated examples
// *           is done, but any precomputed examples are tested.
// *
// *  line 3:  NN, INTEGER array, dimension(NSIZES)
// *
// *  line 4:  NB, NBMIN, NX, NS, NBCOL, INTEGERs
// *
// *  line 5:  THRESH, REAL
// *
// *  line 6:  TSTERR, LOGICAL
// *
// *  line 7:  NEWSD, INTEGER
// *
// *  If line 7 was 2:
// *
// *  line 8:  INTEGER array, dimension (4)
// *
// *  lines 9 and following: The first line contains 'DSX' in columns 1-3
// *           followed by the number of matrix types, possibly with
// *           a second line to specify certain matrix types.
// *           If the number of matrix types = 0, no testing of randomly
// *           generated examples is done, but any precomputed examples
// *           are tested.
// *
// *  remaining lines : Each matrix is stored on 3+N lines, where N is its
// *           dimension. The first line contains the dimension N and the
// *           dimension M of an invariant subspace. The second line
// *           contains M integers, identifying the eigenvalues in the
// *           invariant subspace (by their position in a list of
// *           eigenvalues ordered by increasing real part). The next N
// *           lines contain the matrix. The last line contains the
// *           reciprocal condition number for the average of the selected
// *           eigenvalues, and the reciprocal condition number for the
// *           corresponding right invariant subspace. The end of data is
// *           indicated by a line containing N=0 and M=0. Even if no data
// *           is to be tested, there must be at least one line containing
// *           N=0 and M=0.
// *
// *-----------------------------------------------------------------------
// *
// *  DGG input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of N.
// *
// *  line 3:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix dimension N.
// *
// *  line 4:  NPARMS, INTEGER
// *           Number of values of the parameters NB, NBMIN, NS, MAXB, and
// *           NBCOL.
// *
// *  line 5:  NBVAL, INTEGER array, dimension (NPARMS)
// *           The values for the blocksize NB.
// *
// *  line 6:  NBMIN, INTEGER array, dimension (NPARMS)
// *           The values for NBMIN, the minimum row dimension for blocks.
// *
// *  line 7:  NSVAL, INTEGER array, dimension (NPARMS)
// *           The values for the number of shifts.
// *
// *  line 8:  MXBVAL, INTEGER array, dimension (NPARMS)
// *           The values for MAXB, used in determining minimum blocksize.
// *
// *  line 9:  NBCOL, INTEGER array, dimension (NPARMS)
// *           The values for NBCOL, the minimum column dimension for
// *           blocks.
// *
// *  line 10: THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 11: TSTCHK, LOGICAL
// *           Flag indicating whether or not to test the LAPACK routines.
// *
// *  line 12: TSTDRV, LOGICAL
// *           Flag indicating whether or not to test the driver routines.
// *
// *  line 13: TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 14: NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 14 was 2:
// *
// *  line 15: INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 15-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'DGG' for the generalized
// *           eigenvalue problem routines and driver routines.
// *
// *-----------------------------------------------------------------------
// *
// *  DSB input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of N.
// *
// *  line 3:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix dimension N.
// *
// *  line 4:  NK, INTEGER
// *           Number of values of K.
// *
// *  line 5:  KVAL, INTEGER array, dimension (NK)
// *           The values for the matrix dimension K.
// *
// *  line 6:  THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 7:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 7 was 2:
// *
// *  line 8:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 8-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'DSB'.
// *
// *-----------------------------------------------------------------------
// *
// *  DBB input file:
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension (NN)
// *           The values for the matrix row dimension M.
// *
// *  line 4:  NVAL, INTEGER array, dimension (NN)
// *           The values for the matrix column dimension N.
// *
// *  line 4:  NK, INTEGER
// *           Number of values of K.
// *
// *  line 5:  KVAL, INTEGER array, dimension (NK)
// *           The values for the matrix bandwidth K.
// *
// *  line 6:  NPARMS, INTEGER
// *           Number of values of the parameter NRHS
// *
// *  line 7:  NSVAL, INTEGER array, dimension (NPARMS)
// *           The values for the number of right hand sides NRHS.
// *
// *  line 8:  THRESH
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 9:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 9 was 2:
// *
// *  line 10: INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 10-EOF:  Lines specifying matrix types, as for SVD.
// *           The 3-character path name is 'DBB'.
// *
// *-----------------------------------------------------------------------
// *
// *  DEC input file:
// *
// *  line  2: THRESH, REAL
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  lines  3-EOF:
// *
// *  Input for testing the eigencondition routines consists of a set of
// *  specially constructed test cases and their solutions.  The data
// *  format is not intended to be modified by the user.
// *
// *-----------------------------------------------------------------------
// *
// *  DBL and DBK input files:
// *
// *  line 1:  'DBL' in columns 1-3 to test DGEBAL, or 'DBK' in
// *           columns 1-3 to test DGEBAK.
// *
// *  The remaining lines consist of specially constructed test cases.
// *
// *-----------------------------------------------------------------------
// *
// *  DGL and DGK input files:
// *
// *  line 1:  'DGL' in columns 1-3 to test DGGBAL, or 'DGK' in
// *           columns 1-3 to test DGGBAK.
// *
// *  The remaining lines consist of specially constructed test cases.
// *
// *-----------------------------------------------------------------------
// *
// *  GLM data file:
// *
// *  line 1:  'GLM' in columns 1 to 3.
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M, P, and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension(NN)
// *           Values of M (row dimension).
// *
// *  line 4:  PVAL, INTEGER array, dimension(NN)
// *           Values of P (row dimension).
// *
// *  line 5:  NVAL, INTEGER array, dimension(NN)
// *           Values of N (column dimension), note M <= N <= M+P.
// *
// *  line 6:  THRESH, REAL
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 7:  TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 8:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 8 was 2:
// *
// *  line 9:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 9-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'GLM' for the generalized
// *           linear regression model routines.
// *
// *-----------------------------------------------------------------------
// *
// *  GQR data file:
// *
// *  line 1:  'GQR' in columns 1 to 3.
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M, P, and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension(NN)
// *           Values of M.
// *
// *  line 4:  PVAL, INTEGER array, dimension(NN)
// *           Values of P.
// *
// *  line 5:  NVAL, INTEGER array, dimension(NN)
// *           Values of N.
// *
// *  line 6:  THRESH, REAL
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 7:  TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 8:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 8 was 2:
// *
// *  line 9:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 9-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'GQR' for the generalized
// *           QR and RQ routines.
// *
// *-----------------------------------------------------------------------
// *
// *  GSV data file:
// *
// *  line 1:  'GSV' in columns 1 to 3.
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M, P, and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension(NN)
// *           Values of M (row dimension).
// *
// *  line 4:  PVAL, INTEGER array, dimension(NN)
// *           Values of P (row dimension).
// *
// *  line 5:  NVAL, INTEGER array, dimension(NN)
// *           Values of N (column dimension).
// *
// *  line 6:  THRESH, REAL
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 7:  TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 8:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 8 was 2:
// *
// *  line 9:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 9-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'GSV' for the generalized
// *           SVD routines.
// *
// *-----------------------------------------------------------------------
// *
// *  LSE data file:
// *
// *  line 1:  'LSE' in columns 1 to 3.
// *
// *  line 2:  NN, INTEGER
// *           Number of values of M, P, and N.
// *
// *  line 3:  MVAL, INTEGER array, dimension(NN)
// *           Values of M.
// *
// *  line 4:  PVAL, INTEGER array, dimension(NN)
// *           Values of P.
// *
// *  line 5:  NVAL, INTEGER array, dimension(NN)
// *           Values of N, note P <= N <= P+M.
// *
// *  line 6:  THRESH, REAL
// *           Threshold value for the test ratios.  Information will be
// *           printed about each test for which the test ratio is greater
// *           than or equal to the threshold.
// *
// *  line 7:  TSTERR, LOGICAL
// *           Flag indicating whether or not to test the error exits for
// *           the LAPACK routines and driver routines.
// *
// *  line 8:  NEWSD, INTEGER
// *           A code indicating how to set the random number seed.
// *           = 0:  Set the seed to a default value before each run
// *           = 1:  Initialize the seed to a default value only before the
// *                 first run
// *           = 2:  Like 1, but use the seed values on the next line
// *
// *  If line 8 was 2:
// *
// *  line 9:  INTEGER array, dimension (4)
// *           Four integer values for the random number seed.
// *
// *  lines 9-EOF:  Lines specifying matrix types, as for NEP.
// *           The 3-character path name is 'GSV' for the generalized
// *           SVD routines.
// *
// *-----------------------------------------------------------------------
// *
// *  NMAX is currently set to 132 and must be at least 12 for some of the
// *  precomputed examples, and LWORK = NMAX*(5*NMAX+5)+1 in the parameter
// *  statements below.  For SVD, we assume NRHS may be as big as N.  The
// *  parameter NEED is set to 14 to allow for 14 N-by-N matrices for DGG.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 132;
static int need= 14;
static int lwork= nmax*(5*nmax+5)+1;
static int liwork= nmax*(nmax+20);
static int maxin= 20;
static int maxt= 30;
static int nin= 5;
static int nout= 6;
// *     ..
// *     .. Local Scalars ..
static boolean dbb= false;
static boolean dbk= false;
static boolean dbl= false;
static boolean des= false;
static boolean dev= false;
static boolean dgg= false;
static boolean dgk= false;
static boolean dgl= false;
static boolean dsb= false;
static boolean dsx= false;
static boolean dvx= false;
static boolean fatal= false;
static boolean glm= false;
static boolean gqr= false;
static boolean gsv= false;
static boolean lse= false;
static boolean nep= false;
static boolean sep= false;
static boolean svd= false;
static boolean tstchk= false;
static boolean tstdif= false;
static boolean tstdrv= false;
static boolean tsterr= false;
static String c1= new String(" ");
static String c3= new String("   ");
static String path= new String("   ");
static String vname= new String("      ");
static String line= new String("                                                                                ");
static int i= 0;
static int i1= 0;
static int ic= 0;
static intW info= new intW(0);
static int itmp= 0;
static int k= 0;
static int lenp= 0;
static int maxtyp= 0;
static int newsd= 0;
static int nk= 0;
static int nn= 0;
static int nparms= 0;
static int nrhs= 0;
static int ntypes= 0;
static double eps= 0.0;
static double s1= 0.0;
static double s2= 0.0;
static double thresh= 0.0;
static double thrshn= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] dotype= new boolean[(maxt)];
static boolean [] logwrk= new boolean[(nmax)];
static int [] iseed= new int[(4)];
static int [] iwork= new int[(liwork)];
static int [] kval= new int[(maxin)];
static int [] mval= new int[(maxin)];
static int [] mxbval= new int[(maxin)];
static int [] nbcol= new int[(maxin)];
static int [] nbmin= new int[(maxin)];
static int [] nbval= new int[(maxin)];
static int [] nsval= new int[(maxin)];
static int [] nval= new int[(maxin)];
static int [] nxval= new int[(maxin)];
static int [] pval= new int[(maxin)];
static double [] a= new double[(nmax*nmax) * (need)];
static double [] b= new double[(nmax*nmax) * (5)];
static double [] d= new double[(nmax) * (12)];
static double [] result= new double[(105)];
static double [] taua= new double[(nmax)];
static double [] taub= new double[(nmax)];
static double [] work= new double[(lwork)];
static double [] x= new double[(5*nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Arrays in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String intstr = new String("0123456789");
static int [] ioldsd = {0 
, 0 , 0 , 1 };
// *     ..
// *     .. Executable Statements ..
// *

public static void main (String [] args)  {

  EasyIn _f2j_in = new EasyIn();
s1 = Dsecnd.dsecnd();
fatal = false;
eigtest_infoc.nout_nunit = nout;
// *
// *     Return to here to read multiple sets of data
// *
label10:
   Dummy.label("Dchkee",10);
// *
// *     Read the first line and set the 3-character test path
// *
try {
line = _f2j_in.readchars(80);
_f2j_in.skipRemaining();
} catch (java.io.IOException e) {
Dummy.go_to("Dchkee",370);
}
path = line.substring((1)-1,3);
nep = path.regionMatches(true,0,"NEP",0,3) || path.regionMatches(true,0,"DHS",0,3);
sep = path.regionMatches(true,0,"SEP",0,3) || path.regionMatches(true,0,"DST",0,3) || path.regionMatches(true,0,"DSG",0,3);
svd = path.regionMatches(true,0,"SVD",0,3) || path.regionMatches(true,0,"DBD",0,3);
dev = path.regionMatches(true,0,"DEV",0,3);
des = path.regionMatches(true,0,"DES",0,3);
dvx = path.regionMatches(true,0,"DVX",0,3);
dsx = path.regionMatches(true,0,"DSX",0,3);
dgg = path.regionMatches(true,0,"DGG",0,3);
dsb = path.regionMatches(true,0,"DSB",0,3);
dbb = path.regionMatches(true,0,"DBB",0,3);
glm = path.regionMatches(true,0,"GLM",0,3);
gqr = path.regionMatches(true,0,"GQR",0,3) || path.regionMatches(true,0,"GRQ",0,3);
gsv = path.regionMatches(true,0,"GSV",0,3);
lse = path.regionMatches(true,0,"LSE",0,3);
dbl = path.regionMatches(true,0,"DBL",0,3);
dbk = path.regionMatches(true,0,"DBK",0,3);
dgl = path.regionMatches(true,0,"DGL",0,3);
dgk = path.regionMatches(true,0,"DGK",0,3);
// *
// *     Report values of parameters.
// *
if (path.trim().equalsIgnoreCase("   ".trim()))  {
    Dummy.go_to("Dchkee",10);
}              // Close if()
else if (nep)  {
    System.out.println(" Tests of the Nonsymmetric Eigenvalue Problem routines" );
}              // Close else if()
else if (sep)  {
    System.out.println(" Tests of the Symmetric Eigenvalue Problem routines" );
}              // Close else if()
else if (svd)  {
    System.out.println(" Tests of the Singular Value Decomposition routines" );
}              // Close else if()
else if (dev)  {
    System.out.println("\n"  + " Tests of the Nonsymmetric Eigenvalue Problem Driver"  + "\n"  + "    DGEEV (eigenvalues and eigevectors)" );
}              // Close else if()
else if (des)  {
    System.out.println("\n"  + " Tests of the Nonsymmetric Eigenvalue Problem Driver"  + "\n"  + "    DGEES (Schur form)" );
}              // Close else if()
else if (dvx)  {
    System.out.println("\n"  + " Tests of the Nonsymmetric Eigenvalue Problem Expert"  + " Driver"  + "\n"  + "    DGEEVX (eigenvalues, eigenvectors and"  + " condition numbers)" );
}              // Close else if()
else if (dsx)  {
    System.out.println("\n"  + " Tests of the Nonsymmetric Eigenvalue Problem Expert"  + " Driver"  + "\n"  + "    DGEESX (Schur form and condition"  + " numbers)" );
}              // Close else if()
else if (dgg)  {
    System.out.println("\n"  + " Tests of the Generalized Nonsymmetric Eigenvalue "  + "Problem routines" );
}              // Close else if()
else if (dsb)  {
    System.out.println(" Tests of DSBTRD"  + "\n"  + " (reduction of a symmetric band "  + "matrix to tridiagonal form)" );
}              // Close else if()
else if (dbb)  {
    System.out.println(" Tests of DGBBRD"  + "\n"  + " (reduction of a general band "  + "matrix to real bidiagonal form)" );
}              // Close else if()
else if (glm)  {
    System.out.println("\n"  + " Tests of the Generalized Linear Regression Model "  + "routines" );
}              // Close else if()
else if (gqr)  {
    System.out.println("\n"  + " Tests of the Generalized QR and RQ routines" );
}              // Close else if()
else if (gsv)  {
    System.out.println("\n"  + " Tests of the Generalized Singular Value"  + " Decomposition routines" );
}              // Close else if()
else if (lse)  {
    System.out.println("\n"  + " Tests of the Linear Least Squares routines" );
}              // Close else if()
else if (dbl)  {
    // *
// *        DGEBAL:  Balancing
// *
Dchkbl.dchkbl(nin,nout);
Dummy.go_to("Dchkee",10);
}              // Close else if()
else if (dbk)  {
    // *
// *        DGEBAK:  Back transformation
// *
Dchkbk.dchkbk(nin,nout);
Dummy.go_to("Dchkee",10);
}              // Close else if()
else if (dgl)  {
    // *
// *        DGGBAL:  Balancing
// *
Dchkgl.dchkgl(nin,nout);
Dummy.go_to("Dchkee",10);
}              // Close else if()
else if (dgk)  {
    // *
// *        DGGBAK:  Back transformation
// *
Dchkgk.dchkgk(nin,nout);
Dummy.go_to("Dchkee",10);
}              // Close else if()
else if (path.regionMatches(true,0,"DEC",0,3))  {
    // *
// *        DEC:  Eigencondition estimation
// *
thresh = _f2j_in.readDouble();
_f2j_in.skipRemaining();
tsterr = false;
Dchkec.dchkec(thresh,tsterr,nin,nout);
Dummy.go_to("Dchkee",10);
}              // Close else if()
else  {
  System.out.println(" " + (path) + " "  + ":  Unrecognized path name" );
Dummy.go_to("Dchkee",10);
}              //  Close else.
System.out.println("\n"  + " LAPACK VERSION 2.0, released September 30, 1994 " );
System.out.println("\n"  + " The following parameter values will be used:" );
// *
// *     Read the number of values of M, P, and N.
// *
nn = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nn < 1)  {
    System.out.println(" Invalid input value: "  + ("   NN ") + " "  + "="  + (nn) + " "  + "; must be >="  + (1) + " " );
nn = 0;
fatal = true;
}              // Close if()
else if (nn > maxin)  {
    System.out.println(" Invalid input value: "  + ("   NN ") + " "  + "="  + (nn) + " "  + "; must be <="  + (maxin) + " " );
nn = 0;
fatal = true;
}              // Close else if()
// *
// *     Read the values of M
// *
for(i = 1; i <= nn; i++)
mval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (svd)  {
    vname = "    M ";
}              // Close if()
else  {
  vname = "    N ";
}              //  Close else.
{
forloop20:
for (i = 1; i <= nn; i++) {
if (mval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (vname) + " "  + "="  + (mval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (mval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + (vname) + " "  + "="  + (mval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",20);
}              //  Close for() loop. 
}
System.out.print(("M:    ") + " ");
for(i = 1; i <= nn; i++)
  System.out.print(mval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the values of P
// *
if (glm || gqr || gsv || lse)  {
    for(i = 1; i <= nn; i++)
pval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop30:
for (i = 1; i <= nn; i++) {
if (pval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" P  ") + " "  + "="  + (pval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (pval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + (" P  ") + " "  + "="  + (pval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",30);
}              //  Close for() loop. 
}
System.out.print(("P:    ") + " ");
for(i = 1; i <= nn; i++)
  System.out.print(pval[(i)- 1] + " ");

System.out.println();
}              // Close if()
// *
// *     Read the values of N
// *
if (svd || dbb || glm || gqr || gsv || lse)  {
    for(i = 1; i <= nn; i++)
nval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop40:
for (i = 1; i <= nn; i++) {
if (nval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("    N ") + " "  + "="  + (nval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("    N ") + " "  + "="  + (nval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop50:
for (i = 1; i <= nn; i++) {
nval[(i)- 1] = mval[(i)- 1];
Dummy.label("Dchkee",50);
}              //  Close for() loop. 
}
}              //  Close else.
System.out.print(("N:    ") + " ");
for(i = 1; i <= nn; i++)
  System.out.print(nval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the number of values of K, followed by the values of K
// *
if (dsb || dbb)  {
    nk = _f2j_in.readInt();
_f2j_in.skipRemaining();
for(i = 1; i <= nk; i++)
kval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop60:
for (i = 1; i <= nk; i++) {
if (kval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("    K ") + " "  + "="  + (kval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (kval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("    K ") + " "  + "="  + (kval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",60);
}              //  Close for() loop. 
}
System.out.print(("K:    ") + " ");
for(i = 1; i <= nk; i++)
  System.out.print(kval[(i)- 1] + " ");

System.out.println();
}              // Close if()
// *
if (dev || des || dvx || dsx)  {
    // *
// *        For the nonsymmetric driver routines, only one set of
// *        parameters is allowed.
// *
nbval[(1)- 1] = _f2j_in.readInt();
nbmin[(1)- 1] = _f2j_in.readInt();
nxval[(1)- 1] = _f2j_in.readInt();
nsval[(1)- 1] = _f2j_in.readInt();
mxbval[(1)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nbval[(1)- 1] < 1)  {
    System.out.println(" Invalid input value: "  + ("   NB ") + " "  + "="  + (nbval[(1)- 1]) + " "  + "; must be >="  + (1) + " " );
fatal = true;
}              // Close if()
else if (nbmin[(1)- 1] < 1)  {
    System.out.println(" Invalid input value: "  + ("NBMIN ") + " "  + "="  + (nbmin[(1)- 1]) + " "  + "; must be >="  + (1) + " " );
fatal = true;
}              // Close else if()
else if (nxval[(1)- 1] < 1)  {
    System.out.println(" Invalid input value: "  + ("   NX ") + " "  + "="  + (nxval[(1)- 1]) + " "  + "; must be >="  + (1) + " " );
fatal = true;
}              // Close else if()
else if (nsval[(1)- 1] < 2)  {
    System.out.println(" Invalid input value: "  + ("   NS ") + " "  + "="  + (nsval[(1)- 1]) + " "  + "; must be >="  + (2) + " " );
fatal = true;
}              // Close else if()
else if (mxbval[(1)- 1] < 1)  {
    System.out.println(" Invalid input value: "  + (" MAXB ") + " "  + "="  + (mxbval[(1)- 1]) + " "  + "; must be >="  + (1) + " " );
fatal = true;
}              // Close else if()
Xlaenv.xlaenv(1,nbval[(1)- 1]);
Xlaenv.xlaenv(2,nbmin[(1)- 1]);
Xlaenv.xlaenv(3,nxval[(1)- 1]);
Xlaenv.xlaenv(4,nsval[(1)- 1]);
Xlaenv.xlaenv(8,mxbval[(1)- 1]);
System.out.println("    " + ("NB:   ") + " "  + (nbval[(1)- 1]) + " "  + "\n"  + "          " + " NULL " + " " );
System.out.println("    " + ("NBMIN:") + " "  + (nbmin[(1)- 1]) + " "  + "\n"  + "          " + " NULL " + " " );
System.out.println("    " + ("NX:   ") + " "  + (nxval[(1)- 1]) + " "  + "\n"  + "          " + " NULL " + " " );
System.out.println("    " + ("NS:   ") + " "  + (nsval[(1)- 1]) + " "  + "\n"  + "          " + " NULL " + " " );
System.out.println("    " + ("MAXB: ") + " "  + (mxbval[(1)- 1]) + " "  + "\n"  + "          " + " NULL " + " " );
}              // Close if()
else if (!dsb && !glm && !gqr && !gsv && !lse)  {
    // *
// *        For the other paths, the number of parameters can be varied
// *        from the input file.  Read the number of parameter values.
// *
nparms = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nparms < 1)  {
    System.out.println(" Invalid input value: "  + ("NPARMS") + " "  + "="  + (nparms) + " "  + "; must be >="  + (1) + " " );
nparms = 0;
fatal = true;
}              // Close if()
else if (nparms > maxin)  {
    System.out.println(" Invalid input value: "  + ("NPARMS") + " "  + "="  + (nparms) + " "  + "; must be <="  + (maxin) + " " );
nparms = 0;
fatal = true;
}              // Close else if()
// *
// *        Read the values of NB
// *
if (!dbb)  {
    for(i = 1; i <= nparms; i++)
nbval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop70:
for (i = 1; i <= nparms; i++) {
if (nbval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("   NB ") + " "  + "="  + (nbval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nbval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("   NB ") + " "  + "="  + (nbval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",70);
}              //  Close for() loop. 
}
System.out.print(("NB:   ") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(nbval[(i)- 1] + " ");

System.out.println();
}              // Close if()
// *
// *        Read the values of NBMIN
// *
if (nep || sep || svd || dgg)  {
    for(i = 1; i <= nparms; i++)
nbmin[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop80:
for (i = 1; i <= nparms; i++) {
if (nbmin[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("NBMIN ") + " "  + "="  + (nbmin[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nbmin[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("NBMIN ") + " "  + "="  + (nbmin[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",80);
}              //  Close for() loop. 
}
System.out.print(("NBMIN:") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(nbmin[(i)- 1] + " ");

System.out.println();
}              // Close if()
else  {
  {
forloop90:
for (i = 1; i <= nparms; i++) {
nbmin[(i)- 1] = 1;
Dummy.label("Dchkee",90);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Read the values of NX
// *
if (nep || sep || svd)  {
    for(i = 1; i <= nparms; i++)
nxval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop100:
for (i = 1; i <= nparms; i++) {
if (nxval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("   NX ") + " "  + "="  + (nxval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nxval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("   NX ") + " "  + "="  + (nxval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",100);
}              //  Close for() loop. 
}
System.out.print(("NX:   ") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(nxval[(i)- 1] + " ");

System.out.println();
}              // Close if()
else  {
  {
forloop110:
for (i = 1; i <= nparms; i++) {
nxval[(i)- 1] = 1;
Dummy.label("Dchkee",110);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Read the values of NSHIFT (if NEP or DGG) or NRHS (if SVD
// *        or DBB).
// *
if (nep || svd || dbb || dgg)  {
    for(i = 1; i <= nparms; i++)
nsval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop120:
for (i = 1; i <= nparms; i++) {
if (nsval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("   NS ") + " "  + "="  + (nsval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nsval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("   NS ") + " "  + "="  + (nsval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",120);
}              //  Close for() loop. 
}
System.out.print(("NS:   ") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(nsval[(i)- 1] + " ");

System.out.println();
}              // Close if()
else  {
  {
forloop130:
for (i = 1; i <= nparms; i++) {
nsval[(i)- 1] = 1;
Dummy.label("Dchkee",130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Read the values for MAXB.
// *
if (nep || dgg)  {
    for(i = 1; i <= nparms; i++)
mxbval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop140:
for (i = 1; i <= nparms; i++) {
if (mxbval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" MAXB ") + " "  + "="  + (mxbval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (mxbval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + (" MAXB ") + " "  + "="  + (mxbval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",140);
}              //  Close for() loop. 
}
System.out.print(("MAXB: ") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(mxbval[(i)- 1] + " ");

System.out.println();
}              // Close if()
else  {
  {
forloop150:
for (i = 1; i <= nparms; i++) {
mxbval[(i)- 1] = 1;
Dummy.label("Dchkee",150);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Read the values for NBCOL.
// *
if (dgg)  {
    for(i = 1; i <= nparms; i++)
nbcol[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop160:
for (i = 1; i <= nparms; i++) {
if (nbcol[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("NBCOL ") + " "  + "="  + (nbcol[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nbcol[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + ("NBCOL ") + " "  + "="  + (nbcol[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkee",160);
}              //  Close for() loop. 
}
System.out.print(("NBCOL:") + " ");
for(i = 1; i <= nparms; i++)
  System.out.print(nbcol[(i)- 1] + " ");

System.out.println();
}              // Close if()
else  {
  {
forloop170:
for (i = 1; i <= nparms; i++) {
nbcol[(i)- 1] = 1;
Dummy.label("Dchkee",170);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close else if()
// *
// *     Calculate and print the machine dependent constants.
// *
System.out.println();
eps = Dlamch.dlamch("Underflow threshold");
System.out.println(" Relative machine "  + ("underflow") + " "  + " is taken to be"  + (eps) + " " );
eps = Dlamch.dlamch("Overflow threshold");
System.out.println(" Relative machine "  + ("overflow ") + " "  + " is taken to be"  + (eps) + " " );
eps = Dlamch.dlamch("Epsilon");
System.out.println(" Relative machine "  + ("precision") + " "  + " is taken to be"  + (eps) + " " );
// *
// *     Read the threshold value for the test ratios.
// *
thresh = _f2j_in.readDouble();
_f2j_in.skipRemaining();
System.out.println("\n"  + " Routines pass computational tests if test ratio is "  + "less than"  + (thresh) + " "  + "\n" );
if (sep || svd || dgg)  {
    // *
// *        Read the flag that indicates whether to test LAPACK routines.
// *
tstchk = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *
// *        Read the flag that indicates whether to test driver routines.
// *
tstdrv = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
}              // Close if()
// *
// *     Read the flag that indicates whether to test the error exits.
// *
tsterr = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *
// *     Read the code describing how to set the random number seed.
// *
newsd = _f2j_in.readInt();
_f2j_in.skipRemaining();
// *
// *     If NEWSD = 2, read another line with 4 integers for the seed.
// *
if (newsd == 2)  
    for(i = 1; i <= 4; i++)
ioldsd[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
// *
{
forloop180:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = ioldsd[(i)- 1];
Dummy.label("Dchkee",180);
}              //  Close for() loop. 
}
// *
if (fatal)  {
    System.out.println("\n"  + " Execution not attempted due to input errors" );
System.exit(1);
}              // Close if()
// *
// *     Read the input lines indicating the test path and its parameters.
// *     The first three characters indicate the test path, and the number
// *     of test matrix types must be the first nonblank item in columns
// *     4-80.
// *
label190:
   Dummy.label("Dchkee",190);
try {
line = _f2j_in.readchars(80);
_f2j_in.skipRemaining();
} catch (java.io.IOException e) {
Dummy.go_to("Dchkee",370);
}
c3 = line.substring((1)-1,3);
lenp =  80 ;
i = 3;
itmp = 0;
i1 = 0;
label200:
   Dummy.label("Dchkee",200);
i = i+1;
if (i > lenp)  {
    if (i1 > 0)  {
    Dummy.go_to("Dchkee",230);
}              // Close if()
else  {
  ntypes = maxt;
Dummy.go_to("Dchkee",230);
}              //  Close else.
}              // Close if()
if (!line.substring((i)-1,i).trim().equalsIgnoreCase(" ".trim()) && !line.substring((i)-1,i).trim().equalsIgnoreCase(",".trim()))  {
    i1 = i;
c1 = line.substring((i1)-1,i1);
// *
// *        Check that a valid integer was read
// *
{
forloop210:
for (k = 1; k <= 10; k++) {
if (c1.trim().equalsIgnoreCase(intstr.substring((k)-1,k).trim()))  {
    ic = k-1;
Dummy.go_to("Dchkee",220);
}              // Close if()
Dummy.label("Dchkee",210);
}              //  Close for() loop. 
}
System.out.println("\n\n"  + " *** Invalid integer value in column "  + (i) + " "  + " of input"  + " line:"  + "\n"  + (line) + " " );
Dummy.go_to("Dchkee",190);
label220:
   Dummy.label("Dchkee",220);
itmp = 10*itmp+ic;
Dummy.go_to("Dchkee",200);
}              // Close if()
else if (i1 > 0)  {
    Dummy.go_to("Dchkee",230);
}              // Close else if()
else  {
  Dummy.go_to("Dchkee",200);
}              //  Close else.
label230:
   Dummy.label("Dchkee",230);
ntypes = itmp;
// *
// *     Skip the tests if NTYPES is <= 0.
// *
if (!(dev || des || dvx || dsx) && ntypes <= 0)  {
    System.out.println("\n\n"  + " " + (c3) + " "  + " routines were not tested" );
Dummy.go_to("Dchkee",190);
}              // Close if()
// *
// *     Reset the random number seed.
// *
if (newsd == 0)  {
    {
forloop240:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",240);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (c3.regionMatches(true,0,"DHS",0,3) || c3.regionMatches(true,0,"NEP",0,3))  {
    // *
// *        -------------------------------------
// *        NEP:  Nonsymmetric Eigenvalue Problem
// *        -------------------------------------
// *        Vary the parameters
// *           NB    = block size
// *           NBMIN = minimum block size
// *           NX    = crossover point
// *           NS    = number of shifts
// *           MAXB  = minimum submatrix size
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
if (tsterr)  
    Derrhs.derrhs("DHSEQR",nout);
{
forloop260:
for (i = 1; i <= nparms; i++) {
Xlaenv.xlaenv(1,nbval[(i)- 1]);
Xlaenv.xlaenv(2,nbmin[(i)- 1]);
Xlaenv.xlaenv(3,nxval[(i)- 1]);
Xlaenv.xlaenv(4,nsval[(i)- 1]);
Xlaenv.xlaenv(8,mxbval[(i)- 1]);
// *
if (newsd == 0)  {
    {
forloop250:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",250);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NB ="  + (nbval[(i)- 1]) + " "  + ", NBMIN ="  + (nbmin[(i)- 1]) + " "  + ", NX ="  + (nxval[(i)- 1]) + " "  + ", NS ="  + (nsval[(i)- 1]) + " "  + ", MAXB ="  + (mxbval[(i)- 1]) + " " );
Dchkhs.dchkhs(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),nmax,a,(1)- 1+(6- 1)* (nmax*nmax),a,(1)- 1+(7- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,a,(1)- 1+(8- 1)* (nmax*nmax),a,(1)- 1+(9- 1)* (nmax*nmax),a,(1)- 1+(10- 1)* (nmax*nmax),a,(1)- 1+(11- 1)* (nmax*nmax),a,(1)- 1+(12- 1)* (nmax*nmax),d,(1)- 1+(5- 1)*nmax,work,0,lwork,iwork,0,logwrk,0,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKHS") + " "  + " = "  + (info.val) + " " );
Dummy.label("Dchkee",260);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (c3.regionMatches(true,0,"DST",0,3) || c3.regionMatches(true,0,"SEP",0,3))  {
    // *
// *        ----------------------------------
// *        SEP:  Symmetric Eigenvalue Problem
// *        ----------------------------------
// *        Vary the parameters
// *           NB    = block size
// *           NBMIN = minimum block size
// *           NX    = crossover point
// *
maxtyp = 15;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
if (tsterr)  
    Derrst.derrst("DST",nout);
{
forloop280:
for (i = 1; i <= nparms; i++) {
Xlaenv.xlaenv(1,nbval[(i)- 1]);
Xlaenv.xlaenv(2,nbmin[(i)- 1]);
Xlaenv.xlaenv(3,nxval[(i)- 1]);
// *
if (newsd == 0)  {
    {
forloop270:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",270);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NB ="  + (nbval[(i)- 1]) + " "  + ", NBMIN ="  + (nbmin[(i)- 1]) + " "  + ", NX ="  + (nxval[(i)- 1]) + " " );
if (tstchk)  {
    Dchkst.dchkst(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,d,(1)- 1+(7- 1)*nmax,d,(1)- 1+(8- 1)*nmax,d,(1)- 1+(9- 1)*nmax,d,(1)- 1+(10- 1)*nmax,d,(1)- 1+(11- 1)*nmax,a,(1)- 1+(3- 1)* (nmax*nmax),nmax,a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),d,(1)- 1+(12- 1)*nmax,a,(1)- 1+(6- 1)* (nmax*nmax),work,0,lwork,iwork,0,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKST") + " "  + " = "  + (info.val) + " " );
}              // Close if()
if (tstdrv)  {
    Ddrvst.ddrvst(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,d,(1)- 1+(8- 1)*nmax,d,(1)- 1+(9- 1)*nmax,d,(1)- 1+(10- 1)*nmax,a,(1)- 1+(2- 1)* (nmax*nmax),nmax,a,(1)- 1+(3- 1)* (nmax*nmax),d,(1)- 1+(12- 1)*nmax,a,(1)- 1+(4- 1)* (nmax*nmax),work,0,lwork,iwork,0,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DDRVST") + " "  + " = "  + (info.val) + " " );
}              // Close if()
Dummy.label("Dchkee",280);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DSG",0,3))  {
    // *
// *        ----------------------------------------------
// *        DSG:  Symmetric Generalized Eigenvalue Problem
// *        ----------------------------------------------
// *        Vary the parameters
// *           NB    = block size
// *           NBMIN = minimum block size
// *           NX    = crossover point
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
{
forloop300:
for (i = 1; i <= nparms; i++) {
Xlaenv.xlaenv(1,nbval[(i)- 1]);
Xlaenv.xlaenv(2,nbmin[(i)- 1]);
Xlaenv.xlaenv(3,nxval[(i)- 1]);
// *
if (newsd == 0)  {
    {
forloop290:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",290);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NB ="  + (nbval[(i)- 1]) + " "  + ", NBMIN ="  + (nbmin[(i)- 1]) + " "  + ", NX ="  + (nxval[(i)- 1]) + " " );
if (tstchk)  {
    Ddrvsg.ddrvsg(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),nmax,d,(1)- 1+(3- 1)*nmax,a,(1)- 1+(3- 1)* (nmax*nmax),nmax,a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),a,(1)- 1+(6- 1)* (nmax*nmax),a,(1)- 1+(7- 1)* (nmax*nmax),work,0,lwork,iwork,0,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DDRVSG") + " "  + " = "  + (info.val) + " " );
}              // Close if()
Dummy.label("Dchkee",300);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DBD",0,3) || c3.regionMatches(true,0,"SVD",0,3))  {
    // *
// *        ----------------------------------
// *        SVD:  Singular Value Decomposition
// *        ----------------------------------
// *        Vary the parameters
// *           NB    = block size
// *           NBMIN = minimum block size
// *           NX    = crossover point
// *           NRHS  = number of right hand sides
// *
maxtyp = 16;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
// *
// *        Test the error exits
// *
if (tsterr && tstchk)  
    Derrbd.derrbd("DBDSQR",nout);
if (tsterr && tstdrv)  
    Derred.derred("DBDSQR",nout);
// *
{
forloop320:
for (i = 1; i <= nparms; i++) {
nrhs = nsval[(i)- 1];
Xlaenv.xlaenv(1,nbval[(i)- 1]);
Xlaenv.xlaenv(2,nbmin[(i)- 1]);
Xlaenv.xlaenv(3,nxval[(i)- 1]);
if (newsd == 0)  {
    {
forloop310:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",310);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NB ="  + (nbval[(i)- 1]) + " "  + ", NBMIN ="  + (nbmin[(i)- 1]) + " "  + ", NX ="  + (nxval[(i)- 1]) + " "  + ", NRHS ="  + (nrhs) + " " );
if (tstchk)  {
    Dchkbd.dchkbd(nn,mval,0,nval,0,maxtyp,dotype,0,nrhs,iseed,0,thresh,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,a,(1)- 1+(2- 1)* (nmax*nmax),nmax,a,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),nmax,a,(1)- 1+(6- 1)* (nmax*nmax),nmax,a,(1)- 1+(7- 1)* (nmax*nmax),a,(1)- 1+(8- 1)* (nmax*nmax),work,0,lwork,nout,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKBD") + " "  + " = "  + (info.val) + " " );
}              // Close if()
if (tstdrv)  
    Ddrvbd.ddrvbd(nn,mval,0,nval,0,maxtyp,dotype,0,iseed,0,thresh,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),nmax,a,(1)- 1+(3- 1)* (nmax*nmax),nmax,a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),a,(1)- 1+(6- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,work,0,lwork,nout,info);
Dummy.label("Dchkee",320);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DEV",0,3))  {
    // *
// *        --------------------------------------------
// *        DEV:  Nonsymmetric Eigenvalue Problem Driver
// *              DGEEV (eigenvalues and eigenvectors)
// *        --------------------------------------------
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
if (ntypes <= 0)  {
    System.out.println("\n\n"  + " " + (c3) + " "  + " routines were not tested" );
}              // Close if()
else  {
  if (tsterr)  
    Derred.derred(c3,nout);
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
Ddrvev.ddrvev(nn,nval,0,ntypes,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,a,(1)- 1+(3- 1)* (nmax*nmax),nmax,a,(1)- 1+(4- 1)* (nmax*nmax),nmax,a,(1)- 1+(5- 1)* (nmax*nmax),nmax,result,0,work,0,lwork,iwork,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DGEEV") + " "  + " = "  + (info.val) + " " );
}              //  Close else.
System.out.println("\n"  + " " + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-" );
Dummy.go_to("Dchkee",10);
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DES",0,3))  {
    // *
// *        --------------------------------------------
// *        DES:  Nonsymmetric Eigenvalue Problem Driver
// *              DGEES (Schur form)
// *        --------------------------------------------
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
if (ntypes <= 0)  {
    System.out.println("\n\n"  + " " + (c3) + " "  + " routines were not tested" );
}              // Close if()
else  {
  if (tsterr)  
    Derred.derred(c3,nout);
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
Ddrves.ddrves(nn,nval,0,ntypes,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,a,(1)- 1+(4- 1)* (nmax*nmax),nmax,result,0,work,0,lwork,iwork,0,logwrk,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DGEES") + " "  + " = "  + (info.val) + " " );
}              //  Close else.
System.out.println("\n"  + " " + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-" );
Dummy.go_to("Dchkee",10);
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DVX",0,3))  {
    // *
// *        --------------------------------------------------------------
// *        DVX:  Nonsymmetric Eigenvalue Problem Expert Driver
// *              DGEEVX (eigenvalues, eigenvectors and condition numbers)
// *        --------------------------------------------------------------
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
if (ntypes <= 0)  {
    System.out.println("\n\n"  + " " + (c3) + " "  + " routines were not tested" );
}              // Close if()
else  {
  if (tsterr)  
    Derred.derred(c3,nout);
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
Ddrvvx.ddrvvx(nn,nval,0,ntypes,dotype,0,iseed,0,thresh,nin,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,a,(1)- 1+(3- 1)* (nmax*nmax),nmax,a,(1)- 1+(4- 1)* (nmax*nmax),nmax,a,(1)- 1+(5- 1)* (nmax*nmax),nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,d,(1)- 1+(7- 1)*nmax,d,(1)- 1+(8- 1)*nmax,d,(1)- 1+(9- 1)*nmax,d,(1)- 1+(10- 1)*nmax,d,(1)- 1+(11- 1)*nmax,d,(1)- 1+(12- 1)*nmax,result,0,work,0,lwork,iwork,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DGEEVX") + " "  + " = "  + (info.val) + " " );
}              //  Close else.
System.out.println("\n"  + " " + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-" );
Dummy.go_to("Dchkee",10);
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DSX",0,3))  {
    // *
// *        ---------------------------------------------------
// *        DSX:  Nonsymmetric Eigenvalue Problem Expert Driver
// *              DGEESX (Schur form and condition numbers)
// *        ---------------------------------------------------
// *
maxtyp = 21;
ntypes = (int)(Math.min(maxtyp, ntypes) );
if (ntypes <= 0)  {
    System.out.println("\n\n"  + " " + (c3) + " "  + " routines were not tested" );
}              // Close if()
else  {
  if (tsterr)  
    Derred.derred(c3,nout);
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
Ddrvsx.ddrvsx(nn,nval,0,ntypes,dotype,0,iseed,0,thresh,nin,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,a,(1)- 1+(4- 1)* (nmax*nmax),nmax,a,(1)- 1+(5- 1)* (nmax*nmax),result,0,work,0,lwork,iwork,0,logwrk,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DGEESX") + " "  + " = "  + (info.val) + " " );
}              //  Close else.
System.out.println("\n"  + " " + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-"  + "-" );
Dummy.go_to("Dchkee",10);
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DGG",0,3))  {
    // *
// *        -------------------------------------------------
// *        DGG:  Generalized Nonsymmetric Eigenvalue Problem
// *        -------------------------------------------------
// *        Vary the parameters
// *           NB    = block size
// *           NBMIN = minimum block size
// *           NS    = number of shifts
// *           MAXB  = minimum submatrix size
// *           NBCOL = minimum column dimension for blocks
// *
maxtyp = 26;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
if (tstchk && tsterr)  
    Derrgg.derrgg(c3,nout);
{
forloop340:
for (i = 1; i <= nparms; i++) {
Xlaenv.xlaenv(1,nbval[(i)- 1]);
Xlaenv.xlaenv(2,nbmin[(i)- 1]);
Xlaenv.xlaenv(4,nsval[(i)- 1]);
Xlaenv.xlaenv(8,mxbval[(i)- 1]);
Xlaenv.xlaenv(5,nbcol[(i)- 1]);
// *
if (newsd == 0)  {
    {
forloop330:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",330);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NB ="  + (nbval[(i)- 1]) + " "  + ", NBMIN ="  + (nbmin[(i)- 1]) + " "  + ", NS ="  + (nsval[(i)- 1]) + " "  + ", MAXB ="  + (mxbval[(i)- 1]) + " "  + ", NBCOL ="  + (nbcol[(i)- 1]) + " " );
tstdif = false;
thrshn = 10.e0;
if (tstchk)  {
    Dchkgg.dchkgg(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,tstdif,thrshn,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),a,(1)- 1+(6- 1)* (nmax*nmax),a,(1)- 1+(7- 1)* (nmax*nmax),a,(1)- 1+(8- 1)* (nmax*nmax),a,(1)- 1+(9- 1)* (nmax*nmax),nmax,a,(1)- 1+(10- 1)* (nmax*nmax),a,(1)- 1+(11- 1)* (nmax*nmax),a,(1)- 1+(12- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,a,(1)- 1+(13- 1)* (nmax*nmax),a,(1)- 1+(14- 1)* (nmax*nmax),work,0,lwork,logwrk,0,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKGG") + " "  + " = "  + (info.val) + " " );
}              // Close if()
if (tstdrv)  {
    Ddrvgg.ddrvgg(nn,nval,0,maxtyp,dotype,0,iseed,0,thresh,thrshn,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),a,(1)- 1+(5- 1)* (nmax*nmax),a,(1)- 1+(6- 1)* (nmax*nmax),a,(1)- 1+(7- 1)* (nmax*nmax),nmax,a,(1)- 1+(8- 1)* (nmax*nmax),d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,d,(1)- 1+(3- 1)*nmax,d,(1)- 1+(4- 1)*nmax,d,(1)- 1+(5- 1)*nmax,d,(1)- 1+(6- 1)*nmax,a,(1)- 1+(13- 1)* (nmax*nmax),a,(1)- 1+(14- 1)* (nmax*nmax),work,0,lwork,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DDRVGG") + " "  + " = "  + (info.val) + " " );
}              // Close if()
Dummy.label("Dchkee",340);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DSB",0,3))  {
    // *
// *        ------------------------------
// *        DSB:  Symmetric Band Reduction
// *        ------------------------------
// *
maxtyp = 15;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
if (tsterr)  
    Derrst.derrst("DSB",nout);
Dchksb.dchksb(nn,nval,0,nk,kval,0,maxtyp,dotype,0,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,a,(1)- 1+(2- 1)* (nmax*nmax),nmax,work,0,lwork,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKSB") + " "  + " = "  + (info.val) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"DBB",0,3))  {
    // *
// *        ------------------------------
// *        DBB:  General Band Reduction
// *        ------------------------------
// *
maxtyp = 15;
ntypes = (int)(Math.min(maxtyp, ntypes) );
Alareq.alareq(c3,ntypes,dotype,0,maxtyp,nin,nout);
{
forloop360:
for (i = 1; i <= nparms; i++) {
nrhs = nsval[(i)- 1];
// *
if (newsd == 0)  {
    {
forloop350:
for (k = 1; k <= 4; k++) {
iseed[(k)- 1] = ioldsd[(k)- 1];
Dummy.label("Dchkee",350);
}              //  Close for() loop. 
}
}              // Close if()
System.out.println("\n\n"  + " " + (c3) + " "  + ":  NRHS ="  + (nrhs) + " " );
Dchkbb.dchkbb(nn,mval,0,nval,0,nk,kval,0,maxtyp,dotype,0,nrhs,iseed,0,thresh,nout,a,(1)- 1+(1- 1)* (nmax*nmax),nmax,a,(1)- 1+(2- 1)* (nmax*nmax),2*nmax,d,(1)- 1+(1- 1)*nmax,d,(1)- 1+(2- 1)*nmax,a,(1)- 1+(4- 1)* (nmax*nmax),nmax,a,(1)- 1+(5- 1)* (nmax*nmax),nmax,a,(1)- 1+(6- 1)* (nmax*nmax),nmax,a,(1)- 1+(7- 1)* (nmax*nmax),work,0,lwork,result,0,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCHKBB") + " "  + " = "  + (info.val) + " " );
Dummy.label("Dchkee",360);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"GLM",0,3))  {
    // *
// *        -----------------------------------------
// *        GLM:  Generalized Linear Regression Model
// *        -----------------------------------------
// *
if (tsterr)  
    Derrgg.derrgg("GLM",nout);
Dckglm.dckglm(nn,mval,0,pval,0,nval,0,ntypes,iseed,0,thresh,nmax,a,(1)- 1+(1- 1)* (nmax*nmax),a,(1)- 1+(2- 1)* (nmax*nmax),b,(1)- 1+(1- 1)* (nmax*nmax),b,(1)- 1+(2- 1)* (nmax*nmax),x,0,work,0,d,(1)- 1+(1- 1)*nmax,nin,nout,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCKGLM") + " "  + " = "  + (info.val) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"GQR",0,3))  {
    // *
// *        ------------------------------------------
// *        GQR:  Generalized QR and RQ factorizations
// *        ------------------------------------------
// *
if (tsterr)  
    Derrgg.derrgg("GQR",nout);
Dckgqr.dckgqr(nn,mval,0,nn,pval,0,nn,nval,0,ntypes,iseed,0,thresh,nmax,a,(1)- 1+(1- 1)* (nmax*nmax),a,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),taua,0,b,(1)- 1+(1- 1)* (nmax*nmax),b,(1)- 1+(2- 1)* (nmax*nmax),b,(1)- 1+(3- 1)* (nmax*nmax),b,(1)- 1+(4- 1)* (nmax*nmax),b,(1)- 1+(5- 1)* (nmax*nmax),taub,0,work,0,d,(1)- 1+(1- 1)*nmax,nin,nout,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCKGQR") + " "  + " = "  + (info.val) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"GSV",0,3))  {
    // *
// *        ----------------------------------------------
// *        GSV:  Generalized Singular Value Decomposition
// *        ----------------------------------------------
// *
if (tsterr)  
    Derrgg.derrgg("GSV",nout);
Dckgsv.dckgsv(nn,mval,0,pval,0,nval,0,ntypes,iseed,0,thresh,nmax,a,(1)- 1+(1- 1)* (nmax*nmax),a,(1)- 1+(2- 1)* (nmax*nmax),b,(1)- 1+(1- 1)* (nmax*nmax),b,(1)- 1+(2- 1)* (nmax*nmax),a,(1)- 1+(3- 1)* (nmax*nmax),b,(1)- 1+(3- 1)* (nmax*nmax),a,(1)- 1+(4- 1)* (nmax*nmax),taua,0,taub,0,b,(1)- 1+(4- 1)* (nmax*nmax),iwork,0,work,0,d,(1)- 1+(1- 1)*nmax,nin,nout,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCKGSV") + " "  + " = "  + (info.val) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"LSE",0,3))  {
    // *
// *        --------------------------------------
// *        LSE:  Constrained Linear Least Squares
// *        --------------------------------------
// *
if (tsterr)  
    Derrgg.derrgg("LSE",nout);
Dcklse.dcklse(nn,mval,0,pval,0,nval,0,ntypes,iseed,0,thresh,nmax,a,(1)- 1+(1- 1)* (nmax*nmax),a,(1)- 1+(2- 1)* (nmax*nmax),b,(1)- 1+(1- 1)* (nmax*nmax),b,(1)- 1+(2- 1)* (nmax*nmax),x,0,work,0,d,(1)- 1+(1- 1)*nmax,nin,nout,info);
if (info.val != 0)  
    System.out.println(" *** Error code from "  + ("DCKLSE") + " "  + " = "  + (info.val) + " " );
// *
}              // Close else if()
else  {
  System.out.println();
System.out.println();
System.out.println(" " + (c3) + " "  + ":  Unrecognized path name" );
}              //  Close else.
Dummy.go_to("Dchkee",190);
label370:
   Dummy.label("Dchkee",370);
System.out.println("\n\n"  + " End of tests" );
s2 = Dsecnd.dsecnd();
System.out.println(" Total time used = "  + (s2-s1) + " "  + " seconds"  + "\n" );
// *
// *
// *     End of DCHKEE
// *
Dummy.label("Dchkee",999999);
return;
   }
} // End class.
