/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkgk {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKGK tests DGGBAK, a routine for backward balancing  of
// *  a matrix pair (A, B).
// *
// *  Arguments
// *  =========
// *
// *  NIN     (input) INTEGER
// *          The logical unit number for input.  NIN > 0.
// *
// *  NOUT    (input) INTEGER
// *          The logical unit number for output.  NOUT > 0.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int lda= 50;
static int ldb= 50;
static int ldvl= 50;
static int ldvr= 50;
static int lde= 50;
static int ldf= 50;
static int ldwork= 50;
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW ihi= new intW(0);
static intW ilo= new intW(0);
static intW info= new intW(0);
static int j= 0;
static int knt= 0;
static int m= 0;
static int n= 0;
static int ninfo= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double rmax= 0.0;
static double vmax= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] lmax= new int[(4)];
static double [] a= new double[(lda) * (lda)];
static double [] af= new double[(lda) * (lda)];
static double [] b= new double[(ldb) * (ldb)];
static double [] bf= new double[(ldb) * (ldb)];
static double [] e= new double[(lde) * (lde)];
static double [] f= new double[(ldf) * (ldf)];
static double [] lscale= new double[(lda)];
static double [] rscale= new double[(lda)];
static double [] vl= new double[(ldvl) * (ldvl)];
static double [] vlf= new double[(ldvl) * (ldvl)];
static double [] vr= new double[(ldvr) * (ldvr)];
static double [] vrf= new double[(ldvr) * (ldvr)];
static double [] work= new double[(ldwork) * (ldwork)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialization
// *

public static void dchkgk (int nin,
int nout)  {

  EasyIn _f2j_in = new EasyIn();
lmax[(1)- 1] = 0;
lmax[(2)- 1] = 0;
lmax[(3)- 1] = 0;
lmax[(4)- 1] = 0;
ninfo = 0;
knt = 0;
rmax = zero;
// *
eps = Dlamch.dlamch("Precision");
// *
label10:
   Dummy.label("Dchkgk",10);
n = _f2j_in.readInt();
m = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dchkgk",100);
// *
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
a[(i)- 1+(j- 1)*lda] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgk",20);
}              //  Close for() loop. 
}
// *
{
forloop30:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
b[(i)- 1+(j- 1)*ldb] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgk",30);
}              //  Close for() loop. 
}
// *
{
forloop40:
for (i = 1; i <= n; i++) {
for(j = 1; j <= m; j++)
vl[(i)- 1+(j- 1)*ldvl] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgk",40);
}              //  Close for() loop. 
}
// *
{
forloop50:
for (i = 1; i <= n; i++) {
for(j = 1; j <= m; j++)
vr[(i)- 1+(j- 1)*ldvr] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgk",50);
}              //  Close for() loop. 
}
// *
knt = knt+1;
// *
anorm = Dlange.dlange("M",n,n,a,0,lda,work,0);
bnorm = Dlange.dlange("M",n,n,b,0,ldb,work,0);
// *
Dlacpy.dlacpy("FULL",n,n,a,0,lda,af,0,lda);
Dlacpy.dlacpy("FULL",n,n,b,0,ldb,bf,0,ldb);
// *
Dggbal.dggbal("B",n,a,0,lda,b,0,ldb,ilo,ihi,lscale,0,rscale,0,work,0,info);
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(1)- 1] = knt;
}              // Close if()
// *
Dlacpy.dlacpy("FULL",n,m,vl,0,ldvl,vlf,0,ldvl);
Dlacpy.dlacpy("FULL",n,m,vr,0,ldvr,vrf,0,ldvr);
// *
Dggbak.dggbak("B","L",n,ilo.val,ihi.val,lscale,0,rscale,0,m,vl,0,ldvl,info);
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(2)- 1] = knt;
}              // Close if()
// *
Dggbak.dggbak("B","R",n,ilo.val,ihi.val,lscale,0,rscale,0,m,vr,0,ldvr,info);
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(3)- 1] = knt;
}              // Close if()
// *
// *     Test of DGGBAK
// *
// *     Check tilde(VL)'*A*tilde(VR) - VL'*tilde(A)*VR
// *     where tilde(A) denotes the transformed matrix.
// *
Dgemm.dgemm("N","N",n,m,n,one,af,0,lda,vr,0,ldvr,zero,work,0,ldwork);
Dgemm.dgemm("T","N",m,m,n,one,vl,0,ldvl,work,0,ldwork,zero,e,0,lde);
// *
Dgemm.dgemm("N","N",n,m,n,one,a,0,lda,vrf,0,ldvr,zero,work,0,ldwork);
Dgemm.dgemm("T","N",m,m,n,one,vlf,0,ldvl,work,0,ldwork,zero,f,0,ldf);
// *
vmax = zero;
{
forloop70:
for (j = 1; j <= m; j++) {
{
forloop60:
for (i = 1; i <= m; i++) {
vmax = Math.max(vmax, Math.abs(e[(i)- 1+(j- 1)*lde]-f[(i)- 1+(j- 1)*ldf])) ;
Dummy.label("Dchkgk",60);
}              //  Close for() loop. 
}
Dummy.label("Dchkgk",70);
}              //  Close for() loop. 
}
vmax = vmax/(eps*Math.max(anorm, bnorm) );
if (vmax > rmax)  {
    lmax[(4)- 1] = knt;
rmax = vmax;
}              // Close if()
// *
// *     Check tilde(VL)'*B*tilde(VR) - VL'*tilde(B)*VR
// *
Dgemm.dgemm("N","N",n,m,n,one,bf,0,ldb,vr,0,ldvr,zero,work,0,ldwork);
Dgemm.dgemm("T","N",m,m,n,one,vl,0,ldvl,work,0,ldwork,zero,e,0,lde);
// *
Dgemm.dgemm("N","N",n,m,n,one,b,0,ldb,vrf,0,ldvr,zero,work,0,ldwork);
Dgemm.dgemm("T","N",m,m,n,one,vlf,0,ldvl,work,0,ldwork,zero,f,0,ldf);
// *
vmax = zero;
{
forloop90:
for (j = 1; j <= m; j++) {
{
forloop80:
for (i = 1; i <= m; i++) {
vmax = Math.max(vmax, Math.abs(e[(i)- 1+(j- 1)*lde]-f[(i)- 1+(j- 1)*ldf])) ;
Dummy.label("Dchkgk",80);
}              //  Close for() loop. 
}
Dummy.label("Dchkgk",90);
}              //  Close for() loop. 
}
vmax = vmax/(eps*Math.max(anorm, bnorm) );
if (vmax > rmax)  {
    lmax[(4)- 1] = knt;
rmax = vmax;
}              // Close if()
// *
Dummy.go_to("Dchkgk",10);
// *
label100:
   Dummy.label("Dchkgk",100);
// *
System.out.println(" " + ".. test output of DGGBAK .. " );
// *
System.out.println(" value of largest test error                  ="  + (rmax) + " " );
System.out.println(" example number where DGGBAL info is not 0    ="  + (lmax[(1)- 1]) + " " );
System.out.println(" example number where DGGBAK(L) info is not 0 ="  + (lmax[(2)- 1]) + " " );
System.out.println(" example number where DGGBAK(R) info is not 0 ="  + (lmax[(3)- 1]) + " " );
System.out.println(" example number having largest error          ="  + (lmax[(4)- 1]) + " " );
System.out.println(" number of examples where info is not 0       ="  + (ninfo) + " " );
System.out.println(" total number of examples tested              ="  + (knt) + " " );
// *
Dummy.go_to("Dchkgk",999999);
// *
// *     End of DCHKGK
// *
Dummy.label("Dchkgk",999999);
return;
   }
} // End class.
