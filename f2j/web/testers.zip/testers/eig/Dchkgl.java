/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkgl {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKGL tests DGGBAL, a routine for balancing a matrix pair (A, B).
// *
// *  Arguments
// *  =========
// *
// *  NIN     (input) INTEGER
// *          The logical unit number for input.  NIN > 0.
// *
// *  NOUT    (input) INTEGER
// *          The logical unit number for output.  NOUT > 0.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int lda= 20;
static int ldb= 20;
static int lwork= 6*lda;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW ihi= new intW(0);
static int ihiin= 0;
static intW ilo= new intW(0);
static int iloin= 0;
static intW info= new intW(0);
static int j= 0;
static int knt= 0;
static int n= 0;
static int ninfo= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double rmax= 0.0;
static double vmax= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] lmax= new int[(5)];
static double [] a= new double[(lda) * (lda)];
static double [] ain= new double[(lda) * (lda)];
static double [] b= new double[(ldb) * (ldb)];
static double [] bin= new double[(ldb) * (ldb)];
static double [] lscale= new double[(lda)];
static double [] lsclin= new double[(lda)];
static double [] rscale= new double[(lda)];
static double [] rsclin= new double[(lda)];
static double [] work= new double[(lwork)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dchkgl (int nin,
int nout)  {

  EasyIn _f2j_in = new EasyIn();
lmax[(1)- 1] = 0;
lmax[(2)- 1] = 0;
lmax[(3)- 1] = 0;
ninfo = 0;
knt = 0;
rmax = zero;
// *
eps = Dlamch.dlamch("Precision");
// *
label10:
   Dummy.label("Dchkgl",10);
// *
n = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dchkgl",90);
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
a[(i)- 1+(j- 1)*lda] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgl",20);
}              //  Close for() loop. 
}
// *
{
forloop30:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
b[(i)- 1+(j- 1)*ldb] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgl",30);
}              //  Close for() loop. 
}
// *
iloin = _f2j_in.readInt();
ihiin = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop40:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
ain[(i)- 1+(j- 1)*lda] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgl",40);
}              //  Close for() loop. 
}
{
forloop50:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
bin[(i)- 1+(j- 1)*ldb] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dchkgl",50);
}              //  Close for() loop. 
}
// *
for(i = 1; i <= n; i++)
lsclin[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
for(i = 1; i <= n; i++)
rsclin[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *
anorm = Dlange.dlange("M",n,n,a,0,lda,work,0);
bnorm = Dlange.dlange("M",n,n,b,0,ldb,work,0);
// *
knt = knt+1;
// *
Dggbal.dggbal("B",n,a,0,lda,b,0,ldb,ilo,ihi,lscale,0,rscale,0,work,0,info);
// *
if (info.val != 0)  {
    ninfo = ninfo+1;
lmax[(1)- 1] = knt;
}              // Close if()
// *
if (ilo.val != iloin || ihi.val != ihiin)  {
    ninfo = ninfo+1;
lmax[(2)- 1] = knt;
}              // Close if()
// *
vmax = zero;
{
forloop70:
for (i = 1; i <= n; i++) {
{
forloop60:
for (j = 1; j <= n; j++) {
vmax = Math.max(vmax, Math.abs(a[(i)- 1+(j- 1)*lda]-ain[(i)- 1+(j- 1)*lda])) ;
vmax = Math.max(vmax, Math.abs(b[(i)- 1+(j- 1)*ldb]-bin[(i)- 1+(j- 1)*ldb])) ;
Dummy.label("Dchkgl",60);
}              //  Close for() loop. 
}
Dummy.label("Dchkgl",70);
}              //  Close for() loop. 
}
// *
{
forloop80:
for (i = 1; i <= n; i++) {
vmax = Math.max(vmax, Math.abs(lscale[(i)- 1]-lsclin[(i)- 1])) ;
vmax = Math.max(vmax, Math.abs(rscale[(i)- 1]-rsclin[(i)- 1])) ;
Dummy.label("Dchkgl",80);
}              //  Close for() loop. 
}
// *
vmax = vmax/(eps*Math.max(anorm, bnorm) );
// *
if (vmax > rmax)  {
    lmax[(3)- 1] = knt;
rmax = vmax;
}              // Close if()
// *
Dummy.go_to("Dchkgl",10);
// *
label90:
   Dummy.label("Dchkgl",90);
// *
System.out.println(" " + ".. test output of DGGBAL .. " );
// *
System.out.println(" " + "value of largest test error            = "  + (rmax) + " " );
System.out.println(" " + "example number where info is not zero  = "  + (lmax[(1)- 1]) + " " );
System.out.println(" " + "example number where ILO or IHI wrong  = "  + (lmax[(2)- 1]) + " " );
System.out.println(" " + "example number having largest error    = "  + (lmax[(3)- 1]) + " " );
System.out.println(" " + "number of examples where info is not 0 = "  + (ninfo) + " " );
System.out.println(" " + "total number of examples tested        = "  + (knt) + " " );
// *
Dummy.go_to("Dchkgl",999999);
// *
// *     End of DCHKGL
// *
Dummy.label("Dchkgl",999999);
return;
   }
} // End class.
