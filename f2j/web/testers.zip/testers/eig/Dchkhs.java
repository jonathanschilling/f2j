/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkhs {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DCHKHS  checks the nonsymmetric eigenvalue problem routines.
// *
// *             DGEHRD factors A as  U H U' , where ' means transpose,
// *             H is hessenberg, and U is an orthogonal matrix.
// *
// *             DORGHR generates the orthogonal matrix U.
// *
// *             DORMHR multiplies a matrix by the orthogonal matrix U.
// *
// *             DHSEQR factors H as  Z T Z' , where Z is orthogonal and
// *             T is "quasi-triangular", and the eigenvalue vector W.
// *
// *             DTREVC computes the left and right eigenvector matrices
// *             L and R for T.
// *
// *             DHSEIN computes the left and right eigenvector matrices
// *             Y and X for H, using inverse iteration.
// *
// *     When DCHKHS is called, a number of matrix "sizes" ("n's") and a
// *     number of matrix "types" are specified.  For each size ("n")
// *     and each type of matrix, one matrix will be generated and used
// *     to test the nonsymmetric eigenroutines.  For each matrix, 14
// *     tests will be performed:
// *
// *     (1)     | A - U H U**T | / ( |A| n ulp )
// *
// *     (2)     | I - UU**T | / ( n ulp )
// *
// *     (3)     | H - Z T Z**T | / ( |H| n ulp )
// *
// *     (4)     | I - ZZ**T | / ( n ulp )
// *
// *     (5)     | A - UZ H (UZ)**T | / ( |A| n ulp )
// *
// *     (6)     | I - UZ (UZ)**T | / ( n ulp )
// *
// *     (7)     | T(Z computed) - T(Z not computed) | / ( |T| ulp )
// *
// *     (8)     | W(Z computed) - W(Z not computed) | / ( |W| ulp )
// *
// *     (9)     | TR - RW | / ( |T| |R| ulp )
// *
// *     (10)    | L**H T - W**H L | / ( |T| |L| ulp )
// *
// *     (11)    | HX - XW | / ( |H| |X| ulp )
// *
// *     (12)    | Y**H H - W**H Y | / ( |H| |Y| ulp )
// *
// *     (13)    | AX - XW | / ( |A| |X| ulp )
// *
// *     (14)    | Y**H A - W**H Y | / ( |A| |Y| ulp )
// *
// *     The "sizes" are specified by an array NN(1:NSIZES); the value of
// *     each element NN(j) specifies one size.
// *     The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *     if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *     Currently, the list of possible types is:
// *
// *     (1)  The zero matrix.
// *     (2)  The identity matrix.
// *     (3)  A (transposed) Jordan block, with 1's on the diagonal.
// *
// *     (4)  A diagonal matrix with evenly spaced entries
// *          1, ..., ULP  and random signs.
// *          (ULP = (first number larger than 1) - 1 )
// *     (5)  A diagonal matrix with geometrically spaced entries
// *          1, ..., ULP  and random signs.
// *     (6)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *          and random signs.
// *
// *     (7)  Same as (4), but multiplied by SQRT( overflow threshold )
// *     (8)  Same as (4), but multiplied by SQRT( underflow threshold )
// *
// *     (9)  A matrix of the form  U' T U, where U is orthogonal and
// *          T has evenly spaced entries 1, ..., ULP with random signs
// *          on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (10) A matrix of the form  U' T U, where U is orthogonal and
// *          T has geometrically spaced entries 1, ..., ULP with random
// *          signs on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (11) A matrix of the form  U' T U, where U is orthogonal and
// *          T has "clustered" entries 1, ULP,..., ULP with random
// *          signs on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (12) A matrix of the form  U' T U, where U is orthogonal and
// *          T has real or complex conjugate paired eigenvalues randomly
// *          chosen from ( ULP, 1 ) and random O(1) entries in the upper
// *          triangle.
// *
// *     (13) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has evenly spaced entries 1, ..., ULP
// *          with random signs on the diagonal and random O(1) entries
// *          in the upper triangle.
// *
// *     (14) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has geometrically spaced entries
// *          1, ..., ULP with random signs on the diagonal and random
// *          O(1) entries in the upper triangle.
// *
// *     (15) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has "clustered" entries 1, ULP,..., ULP
// *          with random signs on the diagonal and random O(1) entries
// *          in the upper triangle.
// *
// *     (16) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has real or complex conjugate paired
// *          eigenvalues randomly chosen from ( ULP, 1 ) and random
// *          O(1) entries in the upper triangle.
// *
// *     (17) Same as (16), but multiplied by SQRT( overflow threshold )
// *     (18) Same as (16), but multiplied by SQRT( underflow threshold )
// *
// *     (19) Nonsymmetric matrix with random entries chosen from (-1,1).
// *     (20) Same as (19), but multiplied by SQRT( overflow threshold )
// *     (21) Same as (19), but multiplied by SQRT( underflow threshold )
// *
// *  Arguments
// *  ==========
// *
// *  NSIZES - INTEGER
// *           The number of sizes of matrices to use.  If it is zero,
// *           DCHKHS does nothing.  It must be at least zero.
// *           Not modified.
// *
// *  NN     - INTEGER array, dimension (NSIZES)
// *           An array containing the sizes to be used for the matrices.
// *           Zero values will be skipped.  The values must be at least
// *           zero.
// *           Not modified.
// *
// *  NTYPES - INTEGER
// *           The number of elements in DOTYPE.   If it is zero, DCHKHS
// *           does nothing.  It must be at least zero.  If it is MAXTYP+1
// *           and NSIZES is 1, then an additional type, MAXTYP+1 is
// *           defined, which is to use whatever matrix is in A.  This
// *           is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *           DOTYPE(MAXTYP+1) is .TRUE. .
// *           Not modified.
// *
// *  DOTYPE - LOGICAL array, dimension (NTYPES)
// *           If DOTYPE(j) is .TRUE., then for each size in NN a
// *           matrix of that size and of type j will be generated.
// *           If NTYPES is smaller than the maximum number of types
// *           defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *           MAXTYP will not be generated.  If NTYPES is larger
// *           than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *           will be ignored.
// *           Not modified.
// *
// *  ISEED  - INTEGER array, dimension (4)
// *           On entry ISEED specifies the seed of the random number
// *           generator. The array elements should be between 0 and 4095;
// *           if not they will be reduced mod 4096.  Also, ISEED(4) must
// *           be odd.  The random number generator uses a linear
// *           congruential sequence limited to small integers, and so
// *           should produce machine independent random numbers. The
// *           values of ISEED are changed on exit, and can be used in the
// *           next call to DCHKHS to continue the same random number
// *           sequence.
// *           Modified.
// *
// *  THRESH - DOUBLE PRECISION
// *           A test will count as "failed" if the "error", computed as
// *           described above, exceeds THRESH.  Note that the error
// *           is scaled to be O(1), so THRESH should be a reasonably
// *           small multiple of 1, e.g., 10 or 100.  In particular,
// *           it should not depend on the precision (single vs. double)
// *           or the size of the matrix.  It must be at least zero.
// *           Not modified.
// *
// *  NOUNIT - INTEGER
// *           The FORTRAN unit number for printing out error messages
// *           (e.g., if a routine returns IINFO not equal to 0.)
// *           Not modified.
// *
// *  A      - DOUBLE PRECISION array, dimension (LDA,max(NN))
// *           Used to hold the matrix whose eigenvalues are to be
// *           computed.  On exit, A contains the last matrix actually
// *           used.
// *           Modified.
// *
// *  LDA    - INTEGER
// *           The leading dimension of A, H, T1 and T2.  It must be at
// *           least 1 and at least max( NN ).
// *           Not modified.
// *
// *  H      - DOUBLE PRECISION array, dimension (LDA,max(NN))
// *           The upper hessenberg matrix computed by DGEHRD.  On exit,
// *           H contains the Hessenberg form of the matrix in A.
// *           Modified.
// *
// *  T1     - DOUBLE PRECISION array, dimension (LDA,max(NN))
// *           The Schur (="quasi-triangular") matrix computed by DHSEQR
// *           if Z is computed.  On exit, T1 contains the Schur form of
// *           the matrix in A.
// *           Modified.
// *
// *  T2     - DOUBLE PRECISION array, dimension (LDA,max(NN))
// *           The Schur matrix computed by DHSEQR when Z is not computed.
// *           This should be identical to T1.
// *           Modified.
// *
// *  LDU    - INTEGER
// *           The leading dimension of U, Z, UZ and UU.  It must be at
// *           least 1 and at least max( NN ).
// *           Not modified.
// *
// *  U      - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The orthogonal matrix computed by DGEHRD.
// *           Modified.
// *
// *  Z      - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The orthogonal matrix computed by DHSEQR.
// *           Modified.
// *
// *  UZ     - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The product of U times Z.
// *           Modified.
// *
// *  WR1    - DOUBLE PRECISION array, dimension (max(NN))
// *  WI1    - DOUBLE PRECISION array, dimension (max(NN))
// *           The real and imaginary parts of the eigenvalues of A,
// *           as computed when Z is computed.
// *           On exit, WR1 + WI1*i are the eigenvalues of the matrix in A.
// *           Modified.
// *
// *  WR3    - DOUBLE PRECISION array, dimension (max(NN))
// *  WI3    - DOUBLE PRECISION array, dimension (max(NN))
// *           Like WR1, WI1, these arrays contain the eigenvalues of A,
// *           but those computed when DHSEQR only computes the
// *           eigenvalues, i.e., not the Schur vectors and no more of the
// *           Schur form than is necessary for computing the
// *           eigenvalues.
// *           Modified.
// *
// *  EVECTL - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The (upper triangular) left eigenvector matrix for the
// *           matrix in T1.  For complex conjugate pairs, the real part
// *           is stored in one row and the imaginary part in the next.
// *           Modified.
// *
// *  EVEZTR - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The (upper triangular) right eigenvector matrix for the
// *           matrix in T1.  For complex conjugate pairs, the real part
// *           is stored in one column and the imaginary part in the next.
// *           Modified.
// *
// *  EVECTY - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The left eigenvector matrix for the
// *           matrix in H.  For complex conjugate pairs, the real part
// *           is stored in one row and the imaginary part in the next.
// *           Modified.
// *
// *  EVECTX - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           The right eigenvector matrix for the
// *           matrix in H.  For complex conjugate pairs, the real part
// *           is stored in one column and the imaginary part in the next.
// *           Modified.
// *
// *  UU     - DOUBLE PRECISION array, dimension (LDU,max(NN))
// *           Details of the orthogonal matrix computed by DGEHRD.
// *           Modified.
// *
// *  TAU    - DOUBLE PRECISION array, dimension(max(NN))
// *           Further details of the orthogonal matrix computed by DGEHRD.
// *           Modified.
// *
// *  WORK   - DOUBLE PRECISION array, dimension (NWORK)
// *           Workspace.
// *           Modified.
// *
// *  NWORK  - INTEGER
// *           The number of entries in WORK.  NWORK >= 4*NN(j)*NN(j) + 2.
// *
// *  IWORK  - INTEGER array, dimension (max(NN))
// *           Workspace.
// *           Modified.
// *
// *  SELECT - LOGICAL array, dimension (max(NN))
// *           Workspace.
// *           Modified.
// *
// *  RESULT - DOUBLE PRECISION array, dimension (14)
// *           The values computed by the fourteen tests described above.
// *           The values are currently limited to 1/ulp, to avoid
// *           overflow.
// *           Modified.
// *
// *  INFO   - INTEGER
// *           If 0, then everything ran OK.
// *            -1: NSIZES < 0
// *            -2: Some NN(j) < 0
// *            -3: NTYPES < 0
// *            -6: THRESH < 0
// *            -9: LDA < 1 or LDA < NMAX, where NMAX is max( NN(j) ).
// *           -14: LDU < 1 or LDU < NMAX.
// *           -28: NWORK too small.
// *           If  DLATMR, SLATMS, or SLATME returns an error code, the
// *               absolute value of it is returned.
// *           If 1, then DHSEQR could not find all the shifts.
// *           If 2, then the EISPACK code (for small blocks) failed.
// *           If >2, then 30*N iterations were not enough to find an
// *               eigenvalue or to decompose the problem.
// *           Modified.
// *
// *-----------------------------------------------------------------------
// *
// *     Some Local Variables and Parameters:
// *     ---- ----- --------- --- ----------
// *
// *     ZERO, ONE       Real 0 and 1.
// *     MAXTYP          The number of types defined.
// *     MTEST           The number of tests defined: care must be taken
// *                     that (1) the size of RESULT, (2) the number of
// *                     tests actually performed, and (3) MTEST agree.
// *     NTEST           The number of tests performed on this matrix
// *                     so far.  This should be less than MTEST, and
// *                     equal to it by the last test.  It will be less
// *                     if any of the routines being tested indicates
// *                     that it could not compute the matrices that
// *                     would be tested.
// *     NMAX            Largest value in NN.
// *     NMATS           The number of matrices generated so far.
// *     NERRS           The number of tests which have exceeded THRESH
// *                     so far (computed by DLAFTS).
// *     COND, CONDS,
// *     IMODE           Values to be passed to the matrix generators.
// *     ANORM           Norm of A; passed to matrix generators.
// *
// *     OVFL, UNFL      Overflow and underflow thresholds.
// *     ULP, ULPINV     Finest relative precision and its inverse.
// *     RTOVFL, RTUNFL,
// *     RTULP, RTULPI   Square roots of the previous 4 values.
// *
// *             The following four arrays decode JTYPE:
// *     KTYPE(j)        The general type (1-10) for type "j".
// *     KMODE(j)        The MODE value to be passed to the matrix
// *                     generator for type "j".
// *     KMAGN(j)        The order of magnitude ( O(1),
// *                     O(overflow^(1/2) ), O(underflow^(1/2) )
// *     KCONDS(j)       Selects whether CONDS is to be 1 or
// *                     1/sqrt(ulp).  (0 means irrelevant.)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static int maxtyp= 21;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static int i= 0;
static int ihi= 0;
static intW iinfo= new intW(0);
static int ilo= 0;
static int imode= 0;
static intW in= new intW(0);
static int itype= 0;
static int j= 0;
static int jcol= 0;
static int jsize= 0;
static int jtype= 0;
static int mtypes= 0;
static int n= 0;
static int n1= 0;
static intW nerrs= new intW(0);
static int nmats= 0;
static int nmax= 0;
static int ntest= 0;
static int ntestt= 0;
static double aninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static double conds= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtovfl= 0.0;
static double rtulp= 0.0;
static double rtulpi= 0.0;
static double rtunfl= 0.0;
static double temp1= 0.0;
static double temp2= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static String [] adumma= new String[(1)];
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
static double [] dumma= new double[(6)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 3 , 4, 4, 4, 4, 4 , 6, 6, 6, 6 , 6, 6, 6, 6, 6, 6 
, 9, 9, 9 };
static int [] kmagn = {1, 1, 1 
, 1 , 1 , 1 , 2 , 3 
, 1, 1, 1, 1 , 1 , 1 , 1 , 1 
, 2 , 3 , 1 , 2 , 3 
};
static int [] kmode = {0, 0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 5 , 4 
, 3 , 1 , 5 , 5 , 5 
, 4 , 3 , 1 };
static int [] kconds = {0, 0, 0 
, 0, 0, 0, 0, 0 , 1, 1, 1, 1 , 2, 2, 2, 2, 2, 2 , 0, 0, 0 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dchkhs (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] h, int _h_offset,
double [] t1, int _t1_offset,
double [] t2, int _t2_offset,
double [] u, int _u_offset,
int ldu,
double [] z, int _z_offset,
double [] uz, int _uz_offset,
double [] wr1, int _wr1_offset,
double [] wi1, int _wi1_offset,
double [] wr3, int _wr3_offset,
double [] wi3, int _wi3_offset,
double [] evectl, int _evectl_offset,
double [] evectr, int _evectr_offset,
double [] evecty, int _evecty_offset,
double [] evectx, int _evectx_offset,
double [] uu, int _uu_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int nwork,
int [] iwork, int _iwork_offset,
boolean [] select, int _select_offset,
double [] result, int _result_offset,
intW info)  {

ntestt = 0;
info.val = 0;
// *
badnn = false;
nmax = 0;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Dchkhs",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (thresh < zero)  {
    info.val = -6;
}              // Close else if()
else if (lda <= 1 || lda < nmax)  {
    info.val = -9;
}              // Close else if()
else if (ldu <= 1 || ldu < nmax)  {
    info.val = -14;
}              // Close else if()
else if (4*nmax*nmax+2 > nwork)  {
    info.val = -28;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DCHKHS",-info.val);
Dummy.go_to("Dchkhs",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Dchkhs",999999);
// *
// *     More important constants
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = Dlamch.dlamch("Overflow");
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
ulpinv = one/ulp;
rtunfl = Math.sqrt(unfl.val);
rtovfl = Math.sqrt(ovfl.val);
rtulp = Math.sqrt(ulp);
rtulpi = one/rtulp;
// *
// *     Loop over sizes, types
// *
nerrs.val = 0;
nmats = 0;
// *
{
forloop200:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
n1 = (int)(Math.max(1, n) );
aninv = one/(double)(n1);
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop190:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop190;
nmats = nmats+1;
ntest = 0;
// *
// *           Save ISEED in case of an error.
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Dchkhs",20);
}              //  Close for() loop. 
}
// *
// *           Initialize RESULT
// *
{
forloop30:
for (j = 1; j <= 14; j++) {
result[(j)- 1+ _result_offset] = zero;
Dummy.label("Dchkhs",30);
}              //  Close for() loop. 
}
// *
// *           Compute "A"
// *
// *           Control parameters:
// *
// *           KMAGN  KCONDS  KMODE        KTYPE
// *       =1  O(1)   1       clustered 1  zero
// *       =2  large  large   clustered 2  identity
// *       =3  small          exponential  Jordan
// *       =4                 arithmetic   diagonal, (w/ eigenvalues)
// *       =5                 random log   symmetric, w/ eigenvalues
// *       =6                 random       general, w/ eigenvalues
// *       =7                              random diagonal
// *       =8                              random symmetric
// *       =9                              random general
// *       =10                             random triangular
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Dchkhs",100);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Dchkhs",40);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Dchkhs",50);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Dchkhs",60);
// *
label40:
   Dummy.label("Dchkhs",40);
anorm = one;
Dummy.go_to("Dchkhs",70);
// *
label50:
   Dummy.label("Dchkhs",50);
anorm = (rtovfl*ulp)*aninv;
Dummy.go_to("Dchkhs",70);
// *
label60:
   Dummy.label("Dchkhs",60);
anorm = rtunfl*n*ulpinv;
Dummy.go_to("Dchkhs",70);
// *
label70:
   Dummy.label("Dchkhs",70);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
cond = ulpinv;
// *
// *           Special Matrices
// *
if (itype == 1)  {
    // *
// *              Zero
// *
iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
{
forloop80:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Dchkhs",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 3)  {
    // *
// *              Jordan Block
// *
{
forloop90:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
if (jcol > 1)  
    a[(jcol)- 1+(jcol-1- 1)*lda+ _a_offset] = one;
Dummy.label("Dchkhs",90);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              Symmetric, eigenvalues specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 6)  {
    // *
// *              General, eigenvalues specified
// *
if (kconds[(jtype)- 1] == 1)  {
    conds = one;
}              // Close if()
else if (kconds[(jtype)- 1] == 2)  {
    conds = rtulpi;
}              // Close else if()
else  {
  conds = zero;
}              //  Close else.
// *
adumma[(1)- 1] = " ";
Dlatme.dlatme(n,"S",iseed,_iseed_offset,work,_work_offset,imode,cond,one,adumma,0,"T","T","T",work,(n+1)- 1+ _work_offset,4,conds,n,n,anorm,a,_a_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              Symmetric, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              General, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 10)  {
    // *
// *              Triangular, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else  {
  // *
iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",999999);
}              // Close if()
// *
label100:
   Dummy.label("Dchkhs",100);
// *
// *           Call DGEHRD to compute H and U, do tests.
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,h,_h_offset,lda);
// *
ntest = 1;
// *
ilo = 1;
ihi = n;
// *
Dgehrd.dgehrd(n,ilo,ihi,h,_h_offset,lda,work,_work_offset,work,(n+1)- 1+ _work_offset,nwork-n,iinfo);
// *
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DCHKHS: "  + ("DGEHRD") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
// *
{
forloop120:
for (j = 1; j <= n-1; j++) {
uu[(j+1)- 1+(j- 1)*ldu+ _uu_offset] = zero;
{
forloop110:
for (i = j+2; i <= n; i++) {
u[(i)- 1+(j- 1)*ldu+ _u_offset] = h[(i)- 1+(j- 1)*lda+ _h_offset];
uu[(i)- 1+(j- 1)*ldu+ _uu_offset] = h[(i)- 1+(j- 1)*lda+ _h_offset];
h[(i)- 1+(j- 1)*lda+ _h_offset] = zero;
Dummy.label("Dchkhs",110);
}              //  Close for() loop. 
}
Dummy.label("Dchkhs",120);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,work,_work_offset,1,tau,_tau_offset,1);
Dorghr.dorghr(n,ilo,ihi,u,_u_offset,ldu,work,_work_offset,work,(n+1)- 1+ _work_offset,nwork-n,iinfo);
ntest = 2;
// *
Dhst01.dhst01(n,ilo,ihi,a,_a_offset,lda,h,_h_offset,lda,u,_u_offset,ldu,work,_work_offset,nwork,result,(1)- 1+ _result_offset);
// *
// *           Call DHSEQR to compute T1, T2 and Z, do tests.
// *
// *           Eigenvalues only (WR3,WI3)
// *
Dlacpy.dlacpy(" ",n,n,h,_h_offset,lda,t2,_t2_offset,lda);
ntest = 3;
result[(3)- 1+ _result_offset] = ulpinv;
// *
Dhseqr.dhseqr("E","N",n,ilo,ihi,t2,_t2_offset,lda,wr3,_wr3_offset,wi3,_wi3_offset,uz,_uz_offset,ldu,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DHSEQR(E)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
if (iinfo.val <= n+2)  {
    info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
}              // Close if()
// *
// *           Eigenvalues (WR1,WI1) and Full Schur Form (T2)
// *
Dlacpy.dlacpy(" ",n,n,h,_h_offset,lda,t2,_t2_offset,lda);
// *
Dhseqr.dhseqr("S","N",n,ilo,ihi,t2,_t2_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,uz,_uz_offset,ldu,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0 && iinfo.val <= n+2)  {
    System.out.println(" DCHKHS: "  + ("DHSEQR(S)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
// *
// *           Eigenvalues (WR1,WI1), Schur Form (T1), and Schur vectors
// *           (UZ)
// *
Dlacpy.dlacpy(" ",n,n,h,_h_offset,lda,t1,_t1_offset,lda);
Dlacpy.dlacpy(" ",n,n,u,_u_offset,ldu,uz,_uz_offset,lda);
// *
Dhseqr.dhseqr("S","V",n,ilo,ihi,t1,_t1_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,uz,_uz_offset,ldu,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0 && iinfo.val <= n+2)  {
    System.out.println(" DCHKHS: "  + ("DHSEQR(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
// *
// *           Compute Z = U' UZ
// *
Dgemm.dgemm("T","N",n,n,n,one,u,_u_offset,ldu,uz,_uz_offset,ldu,zero,z,_z_offset,ldu);
ntest = 8;
// *
// *           Do Tests 3: | H - Z T Z' | / ( |H| n ulp )
// *                and 4: | I - Z Z' | / ( n ulp )
// *
Dhst01.dhst01(n,ilo,ihi,h,_h_offset,lda,t1,_t1_offset,lda,z,_z_offset,ldu,work,_work_offset,nwork,result,(3)- 1+ _result_offset);
// *
// *           Do Tests 5: | A - UZ T (UZ)' | / ( |A| n ulp )
// *                and 6: | I - UZ (UZ)' | / ( n ulp )
// *
Dhst01.dhst01(n,ilo,ihi,a,_a_offset,lda,t1,_t1_offset,lda,uz,_uz_offset,ldu,work,_work_offset,nwork,result,(5)- 1+ _result_offset);
// *
// *           Do Test 7: | T2 - T1 | / ( |T| n ulp )
// *
dget10_adapter(n,n,t2,_t2_offset,lda,t1,_t1_offset,lda,work,_work_offset,result,(7)- 1+ _result_offset);
// *
// *           Do Test 8: | W3 - W1 | / ( max(|W1|,|W3|) ulp )
// *
temp1 = zero;
temp2 = zero;
{
forloop130:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(wr1[(j)- 1+ _wr1_offset])+Math.abs(wi1[(j)- 1+ _wi1_offset])) ? (temp1) : (Math.abs(wr1[(j)- 1+ _wr1_offset])+Math.abs(wi1[(j)- 1+ _wi1_offset])), Math.abs(wr3[(j)- 1+ _wr3_offset])+Math.abs(wi3[(j)- 1+ _wi3_offset]));
temp2 = Math.max(temp2, Math.abs(wr1[(j)- 1+ _wr1_offset]-wr3[(j)- 1+ _wr3_offset])+Math.abs(wr1[(j)- 1+ _wr1_offset]-wr3[(j)- 1+ _wr3_offset])) ;
Dummy.label("Dchkhs",130);
}              //  Close for() loop. 
}
// *
result[(8)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
// *           Compute the Left and Right Eigenvectors of T
// *
// *           Compute the Right eigenvector Matrix:
// *
ntest = 9;
result[(9)- 1+ _result_offset] = ulpinv;
{
forloop140:
for (j = 1; j <= n; j++) {
select[(j)- 1+ _select_offset] = true;
Dummy.label("Dchkhs",140);
}              //  Close for() loop. 
}
Dtrevc.dtrevc("Right","All",select,_select_offset,n,t1,_t1_offset,lda,dumma,0,ldu,evectr,_evectr_offset,ldu,n,in,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DTREVC(R)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
// *
// *           Test 9:  | TR - RW | / ( |T| |R| ulp )
// *
Dget22.dget22("N","N","N",n,t1,_t1_offset,lda,evectr,_evectr_offset,ldu,wr1,_wr1_offset,wi1,_wi1_offset,work,_work_offset,dumma,(1)- 1);
result[(9)- 1+ _result_offset] = dumma[(1)- 1];
if (dumma[(2)- 1] > thresh)  {
    System.out.println(" DCHKHS: "  + ("Right") + " "  + " Eigenvectors from "  + ("DTREVC") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(2)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
// *
// *           Compute the Left eigenvector Matrix:
// *
ntest = 10;
result[(10)- 1+ _result_offset] = ulpinv;
{
forloop150:
for (j = 1; j <= n; j++) {
select[(j)- 1+ _select_offset] = true;
Dummy.label("Dchkhs",150);
}              //  Close for() loop. 
}
Dtrevc.dtrevc("Left","All",select,_select_offset,n,t1,_t1_offset,lda,evectl,_evectl_offset,ldu,dumma,0,ldu,n,in,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DTREVC(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkhs",180);
}              // Close if()
// *
// *           Test 10:  | LT - WL | / ( |T| |L| ulp )
// *
Dget22.dget22("Trans","N","Conj",n,t1,_t1_offset,lda,evectl,_evectl_offset,ldu,wr1,_wr1_offset,wi1,_wi1_offset,work,_work_offset,dumma,(3)- 1);
result[(10)- 1+ _result_offset] = dumma[(3)- 1];
if (dumma[(4)- 1] > thresh)  {
    System.out.println(" DCHKHS: "  + ("Left") + " "  + " Eigenvectors from "  + ("DTREVC") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(4)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
// *
// *           Call DHSEIN for Right eigenvectors of H, do test 11
// *
ntest = 11;
result[(11)- 1+ _result_offset] = ulpinv;
{
forloop160:
for (j = 1; j <= n; j++) {
select[(j)- 1+ _select_offset] = true;
Dummy.label("Dchkhs",160);
}              //  Close for() loop. 
}
// *
Dhsein.dhsein("Right","Qr","Ninitv",select,_select_offset,n,h,_h_offset,lda,wr3,_wr3_offset,wi3,_wi3_offset,dumma,0,ldu,evectx,_evectx_offset,ldu,n1,in,work,_work_offset,iwork,_iwork_offset,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DHSEIN(R)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  
    Dummy.go_to("Dchkhs",180);
}              // Close if()
else  {
  // *
// *              Test 11:  | HX - XW | / ( |H| |X| ulp )
// *
// *                        (from inverse iteration)
// *
Dget22.dget22("N","N","N",n,h,_h_offset,lda,evectx,_evectx_offset,ldu,wr3,_wr3_offset,wi3,_wi3_offset,work,_work_offset,dumma,(1)- 1);
if (dumma[(1)- 1] < ulpinv)  
    result[(11)- 1+ _result_offset] = dumma[(1)- 1]*aninv;
if (dumma[(2)- 1] > thresh)  {
    System.out.println(" DCHKHS: "  + ("Right") + " "  + " Eigenvectors from "  + ("DHSEIN") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(2)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
}              //  Close else.
// *
// *           Call DHSEIN for Left eigenvectors of H, do test 12
// *
ntest = 12;
result[(12)- 1+ _result_offset] = ulpinv;
{
forloop170:
for (j = 1; j <= n; j++) {
select[(j)- 1+ _select_offset] = true;
Dummy.label("Dchkhs",170);
}              //  Close for() loop. 
}
// *
Dhsein.dhsein("Left","Qr","Ninitv",select,_select_offset,n,h,_h_offset,lda,wr3,_wr3_offset,wi3,_wi3_offset,evecty,_evecty_offset,ldu,dumma,0,ldu,n1,in,work,_work_offset,iwork,_iwork_offset,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DHSEIN(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  
    Dummy.go_to("Dchkhs",180);
}              // Close if()
else  {
  // *
// *              Test 12:  | YH - WY | / ( |H| |Y| ulp )
// *
// *                        (from inverse iteration)
// *
Dget22.dget22("C","N","C",n,h,_h_offset,lda,evecty,_evecty_offset,ldu,wr3,_wr3_offset,wi3,_wi3_offset,work,_work_offset,dumma,(3)- 1);
if (dumma[(3)- 1] < ulpinv)  
    result[(12)- 1+ _result_offset] = dumma[(3)- 1]*aninv;
if (dumma[(4)- 1] > thresh)  {
    System.out.println(" DCHKHS: "  + ("Left") + " "  + " Eigenvectors from "  + ("DHSEIN") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(4)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
}              //  Close else.
// *
// *           Call DORMHR for Right eigenvectors of A, do test 13
// *
ntest = 13;
result[(13)- 1+ _result_offset] = ulpinv;
// *
Dormhr.dormhr("Left","No transpose",n,n,ilo,ihi,uu,_uu_offset,ldu,tau,_tau_offset,evectx,_evectx_offset,ldu,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DORMHR(R)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  
    Dummy.go_to("Dchkhs",180);
}              // Close if()
else  {
  // *
// *              Test 13:  | AX - XW | / ( |A| |X| ulp )
// *
// *                        (from inverse iteration)
// *
Dget22.dget22("N","N","N",n,a,_a_offset,lda,evectx,_evectx_offset,ldu,wr3,_wr3_offset,wi3,_wi3_offset,work,_work_offset,dumma,(1)- 1);
if (dumma[(1)- 1] < ulpinv)  
    result[(13)- 1+ _result_offset] = dumma[(1)- 1]*aninv;
}              //  Close else.
// *
// *           Call DORMHR for Left eigenvectors of A, do test 14
// *
ntest = 14;
result[(14)- 1+ _result_offset] = ulpinv;
// *
Dormhr.dormhr("Left","No transpose",n,n,ilo,ihi,uu,_uu_offset,ldu,tau,_tau_offset,evecty,_evecty_offset,ldu,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKHS: "  + ("DORMHR(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  
    Dummy.go_to("Dchkhs",180);
}              // Close if()
else  {
  // *
// *              Test 14:  | YA - WY | / ( |A| |Y| ulp )
// *
// *                        (from inverse iteration)
// *
Dget22.dget22("C","N","C",n,a,_a_offset,lda,evecty,_evecty_offset,ldu,wr3,_wr3_offset,wi3,_wi3_offset,work,_work_offset,dumma,(3)- 1);
if (dumma[(3)- 1] < ulpinv)  
    result[(14)- 1+ _result_offset] = dumma[(3)- 1]*aninv;
}              //  Close else.
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
label180:
   Dummy.label("Dchkhs",180);
// *
ntestt = ntestt+ntest;
Dlafts.dlafts("DHS",n,n,jtype,ntest,result,_result_offset,ioldsd,0,thresh,nounit,nerrs);
// *
Dummy.label("Dchkhs",190);
}              //  Close for() loop. 
}
Dummy.label("Dchkhs",200);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Dlasum.dlasum("DHS",nounit,nerrs.val,ntestt);
// *
Dummy.go_to("Dchkhs",999999);
// *
// *
// *     End of DCHKHS
// *
Dummy.label("Dchkhs",999999);
return;
   }
// adapter for dget10
private static void dget10_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget10.dget10(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
