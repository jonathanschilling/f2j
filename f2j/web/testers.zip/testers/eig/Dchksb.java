/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchksb {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKSB tests the reduction of a symmetric band matrix to tridiagonal
// *  form, used with the symmetric eigenvalue problem.
// *
// *  DSBTRD factors a symmetric band matrix A as  U S U' , where ' means
// *  transpose, S is symmetric tridiagonal, and U is orthogonal.
// *  DSBTRD can use either just the lower or just the upper triangle
// *  of A; DCHKSB checks both cases.
// *
// *  When DCHKSB is called, a number of matrix "sizes" ("n's"), a number
// *  of bandwidths ("k's"), and a number of matrix "types" are
// *  specified.  For each size ("n"), each bandwidth ("k") less than or
// *  equal to "n", and each type of matrix, one matrix will be generated
// *  and used to test the symmetric banded reduction routine.  For each
// *  matrix, a number of tests will be performed:
// *
// *  (1)     | A - V S V' | / ( |A| n ulp )  computed by DSBTRD with
// *                                          UPLO='U'
// *
// *  (2)     | I - UU' | / ( n ulp )
// *
// *  (3)     | A - V S V' | / ( |A| n ulp )  computed by DSBTRD with
// *                                          UPLO='L'
// *
// *  (4)     | I - UU' | / ( n ulp )
// *
// *  The "sizes" are specified by an array NN(1:NSIZES); the value of
// *  each element NN(j) specifies one size.
// *  The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *  if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *  Currently, the list of possible types is:
// *
// *  (1)  The zero matrix.
// *  (2)  The identity matrix.
// *
// *  (3)  A diagonal matrix with evenly spaced entries
// *       1, ..., ULP  and random signs.
// *       (ULP = (first number larger than 1) - 1 )
// *  (4)  A diagonal matrix with geometrically spaced entries
// *       1, ..., ULP  and random signs.
// *  (5)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *       and random signs.
// *
// *  (6)  Same as (4), but multiplied by SQRT( overflow threshold )
// *  (7)  Same as (4), but multiplied by SQRT( underflow threshold )
// *
// *  (8)  A matrix of the form  U' D U, where U is orthogonal and
// *       D has evenly spaced entries 1, ..., ULP with random signs
// *       on the diagonal.
// *
// *  (9)  A matrix of the form  U' D U, where U is orthogonal and
// *       D has geometrically spaced entries 1, ..., ULP with random
// *       signs on the diagonal.
// *
// *  (10) A matrix of the form  U' D U, where U is orthogonal and
// *       D has "clustered" entries 1, ULP,..., ULP with random
// *       signs on the diagonal.
// *
// *  (11) Same as (8), but multiplied by SQRT( overflow threshold )
// *  (12) Same as (8), but multiplied by SQRT( underflow threshold )
// *
// *  (13) Symmetric matrix with random entries chosen from (-1,1).
// *  (14) Same as (13), but multiplied by SQRT( overflow threshold )
// *  (15) Same as (13), but multiplied by SQRT( underflow threshold )
// *
// *  Arguments
// *  =========
// *
// *  NSIZES  (input) INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DCHKSB does nothing.  It must be at least zero.
// *
// *  NN      (input) INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *
// *  NWDTHS  (input) INTEGER
// *          The number of bandwidths to use.  If it is zero,
// *          DCHKSB does nothing.  It must be at least zero.
// *
// *  KK      (input) INTEGER array, dimension (NWDTHS)
// *          An array containing the bandwidths to be used for the band
// *          matrices.  The values must be at least zero.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DCHKSB
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DCHKSB to continue the same random number
// *          sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *
// *  A       (input/workspace) DOUBLE PRECISION array, dimension
// *                            (LDA, max(NN))
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least 2 (not 1!)
// *          and at least max( KK )+1.
// *
// *  SD      (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *          Used to hold the diagonal of the tridiagonal matrix computed
// *          by DSBTRD.
// *
// *  SE      (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *          Used to hold the off-diagonal of the tridiagonal matrix
// *          computed by DSBTRD.
// *
// *  U       (workspace) DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          Used to hold the orthogonal matrix computed by DSBTRD.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U.  It must be at least 1
// *          and at least max( NN ).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          max( LDA+1, max(NN)+1 )*max(NN).
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (4)
// *          The values computed by the tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *
// *  INFO    (output) INTEGER
// *          If 0, then everything ran OK.
// *
// *-----------------------------------------------------------------------
// *
// *       Some Local Variables and Parameters:
// *       ---- ----- --------- --- ----------
// *       ZERO, ONE       Real 0 and 1.
// *       MAXTYP          The number of types defined.
// *       NTEST           The number of tests performed, or which can
// *                       be performed so far, for the current matrix.
// *       NTESTT          The total number of tests performed so far.
// *       NMAX            Largest value in NN.
// *       NMATS           The number of matrices generated so far.
// *       NERRS           The number of tests which have exceeded THRESH
// *                       so far.
// *       COND, IMODE     Values to be passed to the matrix generators.
// *       ANORM           Norm of A; passed to matrix generators.
// *
// *       OVFL, UNFL      Overflow and underflow thresholds.
// *       ULP, ULPINV     Finest relative precision and its inverse.
// *       RTOVFL, RTUNFL  Square roots of the previous 2 values.
// *               The following four arrays decode JTYPE:
// *       KTYPE(j)        The general type (1-10) for type "j".
// *       KMODE(j)        The MODE value to be passed to the matrix
// *                       generator for type "j".
// *       KMAGN(j)        The order of magnitude ( O(1),
// *                       O(overflow^(1/2) ), O(underflow^(1/2) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double ten= 10.0e0;
static double half= one/two;
static int maxtyp= 15;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static boolean badnnb= false;
static int i= 0;
static intW iinfo= new intW(0);
static int imode= 0;
static int itype= 0;
static int j= 0;
static int jc= 0;
static int jcol= 0;
static int jr= 0;
static int jsize= 0;
static int jtype= 0;
static int jwidth= 0;
static int k= 0;
static int kmax= 0;
static int mtypes= 0;
static int n= 0;
static int nerrs= 0;
static int nmats= 0;
static int nmax= 0;
static int ntest= 0;
static int ntestt= 0;
static double aninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static double ovfl= 0.0;
static double rtovfl= 0.0;
static double rtunfl= 0.0;
static double temp1= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 4, 4, 4, 4, 4 , 5, 5, 5, 5, 5 , 8, 8, 8 };
static int [] kmagn = {1, 1 
, 1 , 1 , 1 , 2 , 3 
, 1 , 1 , 1 , 2 , 3 
, 1 , 2 , 3 };
static int [] kmode = {0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 4 , 4 
, 0 , 0 , 0 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dchksb (int nsizes,
int [] nn, int _nn_offset,
int nwdths,
int [] kk, int _kk_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] sd, int _sd_offset,
double [] se, int _se_offset,
double [] u, int _u_offset,
int ldu,
double [] work, int _work_offset,
int lwork,
double [] result, int _result_offset,
intW info)  {

ntestt = 0;
info.val = 0;
// *
// *     Important constants
// *
badnn = false;
nmax = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Dchksb",10);
}              //  Close for() loop. 
}
// *
badnnb = false;
kmax = 0;
{
forloop20:
for (j = 1; j <= nsizes; j++) {
kmax = (int)(Math.max(kmax, kk[(j)- 1+ _kk_offset]) );
if (kk[(j)- 1+ _kk_offset] < 0)  
    badnnb = true;
Dummy.label("Dchksb",20);
}              //  Close for() loop. 
}
kmax = (int)(Math.min(nmax-1, kmax) );
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (nwdths < 0)  {
    info.val = -3;
}              // Close else if()
else if (badnnb)  {
    info.val = -4;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -5;
}              // Close else if()
else if (lda < kmax+1)  {
    info.val = -11;
}              // Close else if()
else if (ldu < nmax)  {
    info.val = -15;
}              // Close else if()
else if ((Math.max(lda, nmax) +1)*nmax > lwork)  {
    info.val = -17;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DCHKSB",-info.val);
Dummy.go_to("Dchksb",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (nsizes == 0 || ntypes == 0 || nwdths == 0)  
    Dummy.go_to("Dchksb",999999);
// *
// *     More Important constants
// *
unfl = Dlamch.dlamch("Safe minimum");
ovfl = one/unfl;
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
ulpinv = one/ulp;
rtunfl = Math.sqrt(unfl);
rtovfl = Math.sqrt(ovfl);
// *
// *     Loop over sizes, types
// *
nerrs = 0;
nmats = 0;
// *
{
forloop190:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
aninv = one/(double)(Math.max(1, n) );
// *
{
forloop180:
for (jwidth = 1; jwidth <= nwdths; jwidth++) {
k = kk[(jwidth)- 1+ _kk_offset];
if (k > n)  
    continue forloop180;
k = (int)(Math.max(0, Math.min(n-1, k) ) );
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop170:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop170;
nmats = nmats+1;
ntest = 0;
// *
{
forloop30:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Dchksb",30);
}              //  Close for() loop. 
}
// *
// *              Compute "A".
// *              Store as "Upper"; later, we will copy to other format.
// *
// *              Control parameters:
// *
// *                  KMAGN  KMODE        KTYPE
// *              =1  O(1)   clustered 1  zero
// *              =2  large  clustered 2  identity
// *              =3  small  exponential  (none)
// *              =4         arithmetic   diagonal, (w/ eigenvalues)
// *              =5         random log   symmetric, w/ eigenvalues
// *              =6         random       (none)
// *              =7                      random diagonal
// *              =8                      random symmetric
// *              =9                      positive definite
// *              =10                     diagonally dominant tridiagonal
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Dchksb",100);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *              Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Dchksb",40);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Dchksb",50);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Dchksb",60);
// *
label40:
   Dummy.label("Dchksb",40);
anorm = one;
Dummy.go_to("Dchksb",70);
// *
label50:
   Dummy.label("Dchksb",50);
anorm = (rtovfl*ulp)*aninv;
Dummy.go_to("Dchksb",70);
// *
label60:
   Dummy.label("Dchksb",60);
anorm = rtunfl*n*ulpinv;
Dummy.go_to("Dchksb",70);
// *
label70:
   Dummy.label("Dchksb",70);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
if (jtype <= 15)  {
    cond = ulpinv;
}              // Close if()
else  {
  cond = ulpinv*aninv/ten;
}              //  Close else.
// *
// *              Special Matrices -- Identity & Jordan block
// *
// *                 Zero
// *
if (itype == 1)  {
    iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *                 Identity
// *
{
forloop80:
for (jcol = 1; jcol <= n; jcol++) {
a[(k+1)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Dchksb",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *                 Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"Q",a,(k+1)- 1+(1- 1)*lda+ _a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *                 Symmetric, eigenvalues specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,k,k,"Q",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *                 Diagonal, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"Q",a,(k+1)- 1+(1- 1)*lda+ _a_offset,lda,idumma,0,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *                 Symmetric, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,k,k,zero,anorm,"Q",a,_a_offset,lda,idumma,0,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *                 Positive definite, eigenvalues specified.
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"P",work,_work_offset,imode,cond,anorm,k,k,"Q",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 10)  {
    // *
// *                 Positive definite tridiagonal, eigenvalues specified.
// *
if (n > 1)  
    k = (int)(Math.max(1, k) );
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"P",work,_work_offset,imode,cond,anorm,1,1,"Q",a,(k)- 1+(1- 1)*lda+ _a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
{
forloop90:
for (i = 2; i <= n; i++) {
temp1 = Math.abs(a[(k)- 1+(i- 1)*lda+ _a_offset])/Math.sqrt(Math.abs(a[(k+1)- 1+(i-1- 1)*lda+ _a_offset]*a[(k+1)- 1+(i- 1)*lda+ _a_offset]));
if (temp1 > half)  {
    a[(k)- 1+(i- 1)*lda+ _a_offset] = half*Math.sqrt(Math.abs(a[(k+1)- 1+(i-1- 1)*lda+ _a_offset]*a[(k+1)- 1+(i- 1)*lda+ _a_offset]));
}              // Close if()
Dummy.label("Dchksb",90);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else  {
  // *
iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKSB: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchksb",999999);
}              // Close if()
// *
label100:
   Dummy.label("Dchksb",100);
// *
// *              Call DSBTRD to compute S and U from upper triangle.
// *
Dlacpy.dlacpy(" ",k+1,n,a,_a_offset,lda,work,_work_offset,lda);
// *
ntest = 1;
Dsbtrd.dsbtrd("V","U",n,k,work,_work_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,work,(lda*n+1)- 1+ _work_offset,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKSB: "  + ("DSBTRD(U)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchksb",999999);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchksb",150);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 1 and 2
// *
Dsbt21.dsbt21("Upper",n,k,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,work,_work_offset,result,(1)- 1+ _result_offset);
// *
// *              Convert A from Upper-Triangle-Only storage to
// *              Lower-Triangle-Only storage.
// *
{
forloop120:
for (jc = 1; jc <= n; jc++) {
{
forloop110:
for (jr = 0; jr <= Math.min(k, n-jc) ; jr++) {
a[(jr+1)- 1+(jc- 1)*lda+ _a_offset] = a[(k+1-jr)- 1+(jc+jr- 1)*lda+ _a_offset];
Dummy.label("Dchksb",110);
}              //  Close for() loop. 
}
Dummy.label("Dchksb",120);
}              //  Close for() loop. 
}
{
forloop140:
for (jc = n+1-k; jc <= n; jc++) {
{
forloop130:
for (jr = (int)(Math.min(k, n-jc) +1); jr <= k; jr++) {
a[(jr+1)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dchksb",130);
}              //  Close for() loop. 
}
Dummy.label("Dchksb",140);
}              //  Close for() loop. 
}
// *
// *              Call DSBTRD to compute S and U from lower triangle
// *
Dlacpy.dlacpy(" ",k+1,n,a,_a_offset,lda,work,_work_offset,lda);
// *
ntest = 3;
Dsbtrd.dsbtrd("V","L",n,k,work,_work_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,work,(lda*n+1)- 1+ _work_offset,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKSB: "  + ("DSBTRD(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchksb",999999);
}              // Close if()
else  {
  result[(3)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchksb",150);
}              //  Close else.
}              // Close if()
ntest = 4;
// *
// *              Do tests 3 and 4
// *
Dsbt21.dsbt21("Lower",n,k,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,work,_work_offset,result,(3)- 1+ _result_offset);
// *
// *              End of Loop -- Check for RESULT(j) > THRESH
// *
label150:
   Dummy.label("Dchksb",150);
ntestt = ntestt+ntest;
// *
// *              Print out tests which fail.
// *
{
forloop160:
for (jr = 1; jr <= ntest; jr++) {
if (result[(jr)- 1+ _result_offset] >= thresh)  {
    // *
// *                    If this is the first test to fail,
// *                    print a header to the data file.
// *
if (nerrs == 0)  {
    System.out.println("\n"  + " " + ("DSB") + " "  + " -- Real Symmetric Banded Tridiagonal Reduction Routines" );
System.out.println(" Matrix types (see DCHKSB for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.                        "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2=Identity matrix.                    "  + "  6=Diagonal: large, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entries.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=Diagonal: geometr. spaced entries." );
System.out.println(" Dense "  + ("Symmetric") + " "  + " Banded Matrices:"  + "\n"  + "  8=Evenly spaced eigenvals.            "  + " 12=Small, evenly spaced eigenvals."  + "\n"  + "  9=Geometrically spaced eigenvals.     "  + " 13=Matrix with random O(1) entries."  + "\n"  + " 10=Clustered eigenvalues.              "  + " 14=Matrix with large random entries."  + "\n"  + " 11=Large, evenly spaced eigenvals.     "  + " 15=Matrix with small random entries." );
System.out.print(("orthogonal") + " " + ("\'") + " " + ("transpose") + " ");
for(j = 1; j <= 4; j++)
  System.out.print(" ");

System.out.println();
}              // Close if()
nerrs = nerrs+1;
System.out.println(" N="  + (n) + " "  + ", K="  + (k) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (jtype) + " "  + ","  + (jr) + " "  + ","  + (result[(jr)- 1+ _result_offset]) + " "  + ","  + " type "  + " NULL " + " "  + ", test("  + " NULL " + " "  + ")="  + " NULL " + " " );
}              // Close if()
Dummy.label("Dchksb",160);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchksb",170);
}              //  Close for() loop. 
}
Dummy.label("Dchksb",180);
}              //  Close for() loop. 
}
Dummy.label("Dchksb",190);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Dlasum.dlasum("DSB",nounit,nerrs,ntestt);
Dummy.go_to("Dchksb",999999);
// *
// *
// *
// *
// *
// *     End of DCHKSB
// *
Dummy.label("Dchksb",999999);
return;
   }
} // End class.
