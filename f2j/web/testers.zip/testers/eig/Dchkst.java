/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkst {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKST  checks the symmetric eigenvalue problem routines.
// *
// *     DSYTRD factors A as  U S U' , where ' means transpose,
// *     S is symmetric tridiagonal, and U is orthogonal.
// *     DSYTRD can use either just the lower or just the upper triangle
// *     of A; DCHKST checks both cases.
// *     U is represented as a product of Householder
// *     transformations, whose vectors are stored in the first
// *     n-1 columns of V, and whose scale factors are in TAU.
// *
// *     DSPTRD does the same as DSYTRD, except that A and V are stored
// *     in "packed" format.
// *
// *     DORGTR constructs the matrix U from the contents of V and TAU.
// *
// *     DOPGTR constructs the matrix U from the contents of VP and TAU.
// *
// *     DSTEQR factors S as  Z D1 Z' , where Z is the orthogonal
// *     matrix of eigenvectors and D1 is a diagonal matrix with
// *     the eigenvalues on the diagonal.  D2 is the matrix of
// *     eigenvalues computed when Z is not computed.
// *
// *     DSTERF computes D3, the matrix of eigenvalues, by the
// *     PWK method, which does not yield eigenvectors.
// *
// *     DPTEQR factors S as  Z4 D4 Z4' , for a
// *     symmetric positive definite tridiagonal matrix.
// *     D5 is the matrix of eigenvalues computed when Z is not
// *     computed.
// *
// *     DSTEBZ computes selected eigenvalues.  WA1, WA2, and
// *     WA3 will denote eigenvalues computed to high
// *     absolute accuracy, with different range options.
// *     WR will denote eigenvalues computed to high relative
// *     accuracy.
// *
// *     DSTEIN computes Y, the eigenvectors of S, given the
// *     eigenvalues.
// *
// *     DSTEDC factors S as Z D1 Z' , where Z is the orthogonal
// *     matrix of eigenvectors and D1 is a diagonal matrix with
// *     the eigenvalues on the diagonal ('I' option). It may also
// *     update an input orthogonal matrix, usually the output
// *     from DSYTRD/DORGTR or DSPTRD/DOPGTR ('V' option). It may
// *     also just compute eigenvalues ('N' option).
// *
// *  When DCHKST is called, a number of matrix "sizes" ("n's") and a
// *  number of matrix "types" are specified.  For each size ("n")
// *  and each type of matrix, one matrix will be generated and used
// *  to test the symmetric eigenroutines.  For each matrix, a number
// *  of tests will be performed:
// *
// *  (1)     | A - V S V' | / ( |A| n ulp )  computed by DSYTRD with
// *                                          UPLO='U'
// *
// *  (2)     | I - UV' | / ( n ulp )         test of DORGTR w/ UPLO='U'
// *
// *  (3)     | A - V S V' | / ( |A| n ulp )  computed by DSYTRD with
// *                                          UPLO='L'
// *
// *  (4)     | I - UV' | / ( n ulp )         test of DORGTR w/ UPLO='L'
// *
// *  (5-8)   Same, but for DSPTRD and DOPGTR.
// *
// *  (9)     | S - Z D Z' | / ( |S| n ulp )
// *
// *  (10)    | I - ZZ' | / ( n ulp )
// *
// *  (11)    | D1 - D2 | / ( |D1| ulp )
// *
// *  (12)    | D1 - D3 | / ( |D1| ulp )
// *
// *  (13)    0 if the true eigenvalues of S are within THRESH of
// *          those in D1.  2*THRESH if they are not.  (Tested using
// *          DSTECH)
// *
// *  For S positive definite,
// *
// *  (14)    | S - Z4 D4 Z4' | / ( |S| n ulp )
// *
// *  (15)    | I - Z4 Z4' | / ( n ulp )
// *
// *  (16)    | D4 - D5 | / ( 100 |D4| ulp )
// *
// *  When S is also diagonally dominant by the factor gamma < 1,
// *
// *  (17)    max | D4(i) - WR(i) | / ( |D4(i)| omega ) ,
// *           i
// *          omega = 2 (2n-1) ULP (1 + 8 gamma**2) / (1 - gamma)**4
// *
// *  (18)    | WA1 - D3 | / ( |D3| ulp )
// *
// *  (19)    ( max { min | WA2(i)-WA3(j) | } +
// *             i     j
// *            max { min | WA3(i)-WA2(j) | } ) / ( |D3| ulp )
// *             i     j
// *
// *  (20)    | S - Y WA1 Y' | / ( |S| n ulp )
// *
// *  (21)    | I - Y Y' | / ( n ulp )
// *
// *  (22)    | S - Z D Z' | / ( |S| n ulp ) for DSTEDC('I')
// *
// *  (23)    | I - ZZ' | / ( n ulp ) for DSTEDC('I')
// *
// *  (24)    | S - Z D Z' | / ( |S| n ulp ) for DSTEDC('V')
// *
// *  (25)    | I - ZZ' | / ( n ulp ) for DSTEDC('V')
// *
// *  (26)    | D1 - D2 | / ( |D1| ulp ) for DSTEDC('V') and SSTEDC('N')
// *
// *  The "sizes" are specified by an array NN(1:NSIZES); the value of
// *  each element NN(j) specifies one size.
// *  The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *  if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *  Currently, the list of possible types is:
// *
// *  (1)  The zero matrix.
// *  (2)  The identity matrix.
// *
// *  (3)  A diagonal matrix with evenly spaced entries
// *       1, ..., ULP  and random signs.
// *       (ULP = (first number larger than 1) - 1 )
// *  (4)  A diagonal matrix with geometrically spaced entries
// *       1, ..., ULP  and random signs.
// *  (5)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *       and random signs.
// *
// *  (6)  Same as (4), but multiplied by SQRT( overflow threshold )
// *  (7)  Same as (4), but multiplied by SQRT( underflow threshold )
// *
// *  (8)  A matrix of the form  U' D U, where U is orthogonal and
// *       D has evenly spaced entries 1, ..., ULP with random signs
// *       on the diagonal.
// *
// *  (9)  A matrix of the form  U' D U, where U is orthogonal and
// *       D has geometrically spaced entries 1, ..., ULP with random
// *       signs on the diagonal.
// *
// *  (10) A matrix of the form  U' D U, where U is orthogonal and
// *       D has "clustered" entries 1, ULP,..., ULP with random
// *       signs on the diagonal.
// *
// *  (11) Same as (8), but multiplied by SQRT( overflow threshold )
// *  (12) Same as (8), but multiplied by SQRT( underflow threshold )
// *
// *  (13) Symmetric matrix with random entries chosen from (-1,1).
// *  (14) Same as (13), but multiplied by SQRT( overflow threshold )
// *  (15) Same as (13), but multiplied by SQRT( underflow threshold )
// *  (16) Same as (8), but diagonal elements are all positive.
// *  (17) Same as (9), but diagonal elements are all positive.
// *  (18) Same as (10), but diagonal elements are all positive.
// *  (19) Same as (16), but multiplied by SQRT( overflow threshold )
// *  (20) Same as (16), but multiplied by SQRT( underflow threshold )
// *  (21) A diagonally dominant tridiagonal matrix with geometrically
// *       spaced diagonal entries 1, ..., ULP.
// *
// *  Arguments
// *  =========
// *
// *  NSIZES  (input) INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DCHKST does nothing.  It must be at least zero.
// *
// *  NN      (input) INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DCHK22
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DCHKST to continue the same random number
// *          sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *
// *  A       (input/workspace/output) DOUBLE PRECISION array of
// *                                  dimension ( LDA , max(NN) )
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.  On exit, A contains the last matrix actually
// *          used.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at
// *          least 1 and at least max( NN ).
// *
// *  AP      (workspace) DOUBLE PRECISION array of
// *                      dimension( max(NN)*max(NN+1)/2 )
// *          The matrix A stored in packed format.
// *
// *  SD      (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The diagonal of the tridiagonal matrix computed by DSYTRD.
// *          On exit, SD and SE contain the tridiagonal form of the
// *          matrix in A.
// *
// *  SE      (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The off-diagonal of the tridiagonal matrix computed by
// *          DSYTRD.  On exit, SD and SE contain the tridiagonal form of
// *          the matrix in A.
// *
// *  D1      (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The eigenvalues of A, as computed by DSTEQR simlutaneously
// *          with Z.  On exit, the eigenvalues in D1 correspond with the
// *          matrix in A.
// *
// *  D2      (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The eigenvalues of A, as computed by DSTEQR if Z is not
// *          computed.  On exit, the eigenvalues in D2 correspond with
// *          the matrix in A.
// *
// *  D3      (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The eigenvalues of A, as computed by DSTERF.  On exit, the
// *          eigenvalues in D3 correspond with the matrix in A.
// *
// *  U       (workspace/output) DOUBLE PRECISION array of
// *                             dimension( LDU, max(NN) ).
// *          The orthogonal matrix computed by DSYTRD + DORGTR.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U, Z, and V.  It must be at least 1
// *          and at least max( NN ).
// *
// *  V       (workspace/output) DOUBLE PRECISION array of
// *                             dimension( LDU, max(NN) ).
// *          The Housholder vectors computed by DSYTRD in reducing A to
// *          tridiagonal form.  The vectors computed with UPLO='U' are
// *          in the upper triangle, and the vectors computed with UPLO='L'
// *          are in the lower triangle.  (As described in DSYTRD, the
// *          sub- and superdiagonal are not set to 1, although the
// *          true Householder vector has a 1 in that position.  The
// *          routines that use V, such as DORGTR, set those entries to
// *          1 before using them, and then restore them later.)
// *
// *  VP      (workspace) DOUBLE PRECISION array of
// *                      dimension( max(NN)*max(NN+1)/2 )
// *          The matrix V stored in packed format.
// *
// *  TAU     (workspace/output) DOUBLE PRECISION array of
// *                             dimension( max(NN) )
// *          The Householder factors computed by DSYTRD in reducing A
// *          to tridiagonal form.
// *
// *  Z       (workspace/output) DOUBLE PRECISION array of
// *                             dimension( LDU, max(NN) ).
// *          The orthogonal matrix of eigenvectors computed by DSTEQR,
// *          DPTEQR, and DSTEIN.
// *
// *  WORK    (workspace) DOUBLE PRECISION array of
// *                      dimension( LWORK )
// *          Workspace.
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          1 + 4 * Nmax + 2 * Nmax * lg Nmax + 3 * Nmax**2
// *          where Nmax = max( NN(j), 2 ) and lg = log base 2.
// *
// *  IWORK   (workspace) INTEGER array,
// *             dimension (6 + 6*Nmax + 5 * Nmax * lg Nmax )
// *          where Nmax = max( NN(j), 2 ) and lg = log base 2.
// *          Workspace.
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (26)
// *          The values computed by the tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *
// *  INFO    (output) INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some NN(j) < 0
// *           -3: NTYPES < 0
// *           -5: THRESH < 0
// *           -9: LDA < 1 or LDA < NMAX, where NMAX is max( NN(j) ).
// *          -23: LDU < 1 or LDU < NMAX.
// *          -29: LWORK too small.
// *          If  DLATMR, SLATMS, DSYTRD, DORGTR, DSTEQR, SSTERF,
// *              or DORMC2 returns an error code, the
// *              absolute value of it is returned.
// *
// *-----------------------------------------------------------------------
// *
// *       Some Local Variables and Parameters:
// *       ---- ----- --------- --- ----------
// *       ZERO, ONE       Real 0 and 1.
// *       MAXTYP          The number of types defined.
// *       NTEST           The number of tests performed, or which can
// *                       be performed so far, for the current matrix.
// *       NTESTT          The total number of tests performed so far.
// *       NBLOCK          Blocksize as returned by ENVIR.
// *       NMAX            Largest value in NN.
// *       NMATS           The number of matrices generated so far.
// *       NERRS           The number of tests which have exceeded THRESH
// *                       so far.
// *       COND, IMODE     Values to be passed to the matrix generators.
// *       ANORM           Norm of A; passed to matrix generators.
// *
// *       OVFL, UNFL      Overflow and underflow thresholds.
// *       ULP, ULPINV     Finest relative precision and its inverse.
// *       RTOVFL, RTUNFL  Square roots of the previous 2 values.
// *               The following four arrays decode JTYPE:
// *       KTYPE(j)        The general type (1-10) for type "j".
// *       KMODE(j)        The MODE value to be passed to the matrix
// *                       generator for type "j".
// *       KMAGN(j)        The order of magnitude ( O(1),
// *                       O(overflow^(1/2) ), O(underflow^(1/2) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double eight= 8.0e0;
static double ten= 10.0e0;
static double hun= 100.0e0;
static double half= one/two;
static int maxtyp= 21;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static int i= 0;
static intW iinfo= new intW(0);
static int il= 0;
static int imode= 0;
static int itemp= 0;
static int itype= 0;
static int iu= 0;
static int j= 0;
static int jc= 0;
static int jr= 0;
static int jsize= 0;
static int jtype= 0;
static int lgn= 0;
static int liwedc= 0;
static int log2ui= 0;
static int lwedc= 0;
static intW m= new intW(0);
static intW m2= new intW(0);
static intW m3= new intW(0);
static int mtypes= 0;
static int n= 0;
static int nap= 0;
static int nblock= 0;
static int nerrs= 0;
static int nmats= 0;
static int nmax= 0;
static intW nsplit= new intW(0);
static int ntest= 0;
static int ntestt= 0;
static double abstol= 0.0;
static double aninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtovfl= 0.0;
static double rtunfl= 0.0;
static double temp1= 0.0;
static double temp2= 0.0;
static double temp3= 0.0;
static double temp4= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
static double vl= 0.0;
static double vu= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
static int [] iseed2= new int[(4)];
static double [] dumma= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 4 , 4 , 4 , 4 
, 4 , 5 , 5 , 5 , 5 
, 5 , 8 , 8 , 8 , 9 
, 9 , 9 , 9 , 9 , 10 
};
static int [] kmagn = {1 
, 1 , 1 , 1 , 1 , 2 
, 3 , 1 , 1 , 1 , 2 
, 3 , 1 , 2 , 3 , 1 
, 1 , 1 , 2 , 3 , 1 
};
static int [] kmode = {0 
, 0 , 4 , 3 , 1 , 4 
, 4 , 4 , 3 , 1 , 4 
, 4 , 0 , 0 , 0 , 4 
, 3 , 1 , 4 , 4 , 3 
};
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dchkst (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] ap, int _ap_offset,
double [] sd, int _sd_offset,
double [] se, int _se_offset,
double [] d1, int _d1_offset,
double [] d2, int _d2_offset,
double [] d3, int _d3_offset,
double [] d4, int _d4_offset,
double [] d5, int _d5_offset,
double [] wa1, int _wa1_offset,
double [] wa2, int _wa2_offset,
double [] wa3, int _wa3_offset,
double [] wr, int _wr_offset,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
double [] vp, int _vp_offset,
double [] tau, int _tau_offset,
double [] z, int _z_offset,
double [] work, int _work_offset,
int lwork,
int [] iwork, int _iwork_offset,
double [] result, int _result_offset,
intW info)  {

ntestt = 0;
info.val = 0;
// *
// *     Important constants
// *
badnn = false;
nmax = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Dchkst",10);
}              //  Close for() loop. 
}
// *
nblock = Ilaenv.ilaenv(1,"DSYTRD","L",nmax,-1,-1,-1);
nblock = (int)(Math.min(nmax, Math.max(1, nblock) ) );
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < nmax)  {
    info.val = -9;
}              // Close else if()
else if (ldu < nmax)  {
    info.val = -23;
}              // Close else if()
else if (2*Math.pow(Math.max(2, nmax) , 2) > lwork)  {
    info.val = -29;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DCHKST",-info.val);
Dummy.go_to("Dchkst",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Dchkst",999999);
// *
// *     More Important constants
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = one/unfl.val;
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
ulpinv = one/ulp;
log2ui = (int)(Math.log(ulpinv)/Math.log(two));
rtunfl = Math.sqrt(unfl.val);
rtovfl = Math.sqrt(ovfl.val);
// *
// *     Loop over sizes, types
// *
{
forloop20:
for (i = 1; i <= 4; i++) {
iseed2[(i)- 1] = iseed[(i)- 1+ _iseed_offset];
Dummy.label("Dchkst",20);
}              //  Close for() loop. 
}
nerrs = 0;
nmats = 0;
// *
{
forloop250:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
if (n > 0)  {
    lgn = (int)(Math.log((double)(n))/Math.log(two));
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
lwedc = (int)(1+4*n+2*n*lgn+3*Math.pow(n, 2));
liwedc = 6+6*n+5*n*lgn;
}              // Close if()
else  {
  lwedc = 8;
liwedc = 12;
}              //  Close else.
nap = (n*(n+1))/2;
aninv = one/(double)(Math.max(1, n) );
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop240:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop240;
nmats = nmats+1;
ntest = 0;
// *
{
forloop30:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Dchkst",30);
}              //  Close for() loop. 
}
// *
// *           Compute "A"
// *
// *           Control parameters:
// *
// *               KMAGN  KMODE        KTYPE
// *           =1  O(1)   clustered 1  zero
// *           =2  large  clustered 2  identity
// *           =3  small  exponential  (none)
// *           =4         arithmetic   diagonal, (w/ eigenvalues)
// *           =5         random log   symmetric, w/ eigenvalues
// *           =6         random       (none)
// *           =7                      random diagonal
// *           =8                      random symmetric
// *           =9                      positive definite
// *           =10                     diagonally dominant tridiagonal
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Dchkst",100);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Dchkst",40);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Dchkst",50);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Dchkst",60);
// *
label40:
   Dummy.label("Dchkst",40);
anorm = one;
Dummy.go_to("Dchkst",70);
// *
label50:
   Dummy.label("Dchkst",50);
anorm = (rtovfl*ulp)*aninv;
Dummy.go_to("Dchkst",70);
// *
label60:
   Dummy.label("Dchkst",60);
anorm = rtunfl*n*ulpinv;
Dummy.go_to("Dchkst",70);
// *
label70:
   Dummy.label("Dchkst",70);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
if (jtype <= 15)  {
    cond = ulpinv;
}              // Close if()
else  {
  cond = ulpinv*aninv/ten;
}              //  Close else.
// *
// *           Special Matrices -- Identity & Jordan block
// *
// *              Zero
// *
if (itype == 1)  {
    iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
{
forloop80:
for (jc = 1; jc <= n; jc++) {
a[(jc)- 1+(jc- 1)*lda+ _a_offset] = anorm;
Dummy.label("Dchkst",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              Symmetric, eigenvalues specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              Symmetric, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              Positive definite, eigenvalues specified.
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"P",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 10)  {
    // *
// *              Positive definite tridiagonal, eigenvalues specified.
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"P",work,_work_offset,imode,cond,anorm,1,1,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
{
forloop90:
for (i = 2; i <= n; i++) {
temp1 = Math.abs(a[(i-1)- 1+(i- 1)*lda+ _a_offset])/Math.sqrt(Math.abs(a[(i-1)- 1+(i-1- 1)*lda+ _a_offset]*a[(i)- 1+(i- 1)*lda+ _a_offset]));
if (temp1 > half)  {
    a[(i-1)- 1+(i- 1)*lda+ _a_offset] = half*Math.sqrt(Math.abs(a[(i-1)- 1+(i-1- 1)*lda+ _a_offset]*a[(i)- 1+(i- 1)*lda+ _a_offset]));
a[(i)- 1+(i-1- 1)*lda+ _a_offset] = a[(i-1)- 1+(i- 1)*lda+ _a_offset];
}              // Close if()
Dummy.label("Dchkst",90);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else  {
  // *
iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dchkst",999999);
}              // Close if()
// *
label100:
   Dummy.label("Dchkst",100);
// *
// *           Call DSYTRD and DORGTR to compute S and U from
// *           upper triangle.
// *
Dlacpy.dlacpy("U",n,n,a,_a_offset,lda,v,_v_offset,ldu);
// *
ntest = 1;
Dsytrd.dsytrd("U",n,v,_v_offset,ldu,sd,_sd_offset,se,_se_offset,tau,_tau_offset,work,_work_offset,lwork,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSYTRD(U)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
Dlacpy.dlacpy("U",n,n,v,_v_offset,ldu,u,_u_offset,ldu);
// *
ntest = 2;
Dorgtr.dorgtr("U",n,u,_u_offset,ldu,tau,_tau_offset,work,_work_offset,lwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DORGTR(U)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do tests 1 and 2
// *
Dsyt21.dsyt21(2,"Upper",n,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(1)- 1+ _result_offset);
Dsyt21.dsyt21(3,"Upper",n,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(2)- 1+ _result_offset);
// *
// *           Call DSYTRD and DORGTR to compute S and U from
// *           lower triangle, do tests.
// *
Dlacpy.dlacpy("L",n,n,a,_a_offset,lda,v,_v_offset,ldu);
// *
ntest = 3;
Dsytrd.dsytrd("L",n,v,_v_offset,ldu,sd,_sd_offset,se,_se_offset,tau,_tau_offset,work,_work_offset,lwork,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSYTRD(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(3)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
Dlacpy.dlacpy("L",n,n,v,_v_offset,ldu,u,_u_offset,ldu);
// *
ntest = 4;
Dorgtr.dorgtr("L",n,u,_u_offset,ldu,tau,_tau_offset,work,_work_offset,lwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DORGTR(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(4)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
Dsyt21.dsyt21(2,"Lower",n,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(3)- 1+ _result_offset);
Dsyt21.dsyt21(3,"Lower",n,1,a,_a_offset,lda,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(4)- 1+ _result_offset);
// *
// *           Store the upper triangle of A in AP
// *
i = 0;
{
forloop120:
for (jc = 1; jc <= n; jc++) {
{
forloop110:
for (jr = 1; jr <= jc; jr++) {
i = i+1;
ap[(i)- 1+ _ap_offset] = a[(jr)- 1+(jc- 1)*lda+ _a_offset];
Dummy.label("Dchkst",110);
}              //  Close for() loop. 
}
Dummy.label("Dchkst",120);
}              //  Close for() loop. 
}
// *
// *           Call DSPTRD and DOPGTR to compute S and U from AP
// *
Dcopy.dcopy(nap,ap,_ap_offset,1,vp,_vp_offset,1);
// *
ntest = 5;
Dsptrd.dsptrd("U",n,vp,_vp_offset,sd,_sd_offset,se,_se_offset,tau,_tau_offset,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSPTRD(U)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(5)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
ntest = 6;
Dopgtr.dopgtr("U",n,vp,_vp_offset,tau,_tau_offset,u,_u_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DOPGTR(U)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(6)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do tests 5 and 6
// *
Dspt21.dspt21(2,"Upper",n,1,ap,_ap_offset,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,vp,_vp_offset,tau,_tau_offset,work,_work_offset,result,(5)- 1+ _result_offset);
Dspt21.dspt21(3,"Upper",n,1,ap,_ap_offset,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,vp,_vp_offset,tau,_tau_offset,work,_work_offset,result,(6)- 1+ _result_offset);
// *
// *           Store the lower triangle of A in AP
// *
i = 0;
{
forloop140:
for (jc = 1; jc <= n; jc++) {
{
forloop130:
for (jr = jc; jr <= n; jr++) {
i = i+1;
ap[(i)- 1+ _ap_offset] = a[(jr)- 1+(jc- 1)*lda+ _a_offset];
Dummy.label("Dchkst",130);
}              //  Close for() loop. 
}
Dummy.label("Dchkst",140);
}              //  Close for() loop. 
}
// *
// *           Call DSPTRD and DOPGTR to compute S and U from AP
// *
Dcopy.dcopy(nap,ap,_ap_offset,1,vp,_vp_offset,1);
// *
ntest = 7;
Dsptrd.dsptrd("L",n,vp,_vp_offset,sd,_sd_offset,se,_se_offset,tau,_tau_offset,iinfo);
// *
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSPTRD(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(7)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
ntest = 8;
Dopgtr.dopgtr("L",n,vp,_vp_offset,tau,_tau_offset,u,_u_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DOPGTR(L)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(8)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
Dspt21.dspt21(2,"Lower",n,1,ap,_ap_offset,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,vp,_vp_offset,tau,_tau_offset,work,_work_offset,result,(7)- 1+ _result_offset);
Dspt21.dspt21(3,"Lower",n,1,ap,_ap_offset,sd,_sd_offset,se,_se_offset,u,_u_offset,ldu,vp,_vp_offset,tau,_tau_offset,work,_work_offset,result,(8)- 1+ _result_offset);
// *
// *           Call DSTEQR to compute D1, D2, and Z, do tests.
// *
// *           Compute D1 and Z
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d1,_d1_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldu);
// *
ntest = 9;
Dsteqr.dsteqr("V",n,d1,_d1_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEQR(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(9)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Compute D2
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d2,_d2_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
// *
ntest = 11;
Dsteqr.dsteqr("N",n,d2,_d2_offset,work,_work_offset,work,(n+1)- 1+ _work_offset,ldu,work,(n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEQR(N)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(11)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Compute D3 (using PWK method)
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d3,_d3_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
// *
ntest = 12;
Dsterf.dsterf(n,d3,_d3_offset,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTERF") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(12)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do Tests 9 and 10
// *
Dstt21.dstt21(n,0,sd,_sd_offset,se,_se_offset,d1,_d1_offset,dumma,0,z,_z_offset,ldu,work,_work_offset,result,(9)- 1+ _result_offset);
// *
// *           Do Tests 11 and 12
// *
temp1 = zero;
temp2 = zero;
temp3 = zero;
temp4 = zero;
// *
{
forloop150:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d2[(j)- 1+ _d2_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d2[(j)- 1+ _d2_offset])) ;
temp3 = Math.max((temp3) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp3) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp4 = Math.max(temp4, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Dchkst",150);
}              //  Close for() loop. 
}
// *
result[(11)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
result[(12)- 1+ _result_offset] = temp4/Math.max(unfl.val, ulp*Math.max(temp3, temp4) ) ;
// *
// *           Do Test 13 -- Sturm Sequence Test of Eigenvalues
// *                         Go up by factors of two until it succeeds
// *
ntest = 13;
temp1 = thresh*(half-ulp);
// *
{
forloop160:
for (j = 0; j <= log2ui; j++) {
Dstech.dstech(n,sd,_sd_offset,se,_se_offset,d1,_d1_offset,temp1,work,_work_offset,iinfo);
if (iinfo.val == 0)  
    Dummy.go_to("Dchkst",170);
temp1 = temp1*two;
Dummy.label("Dchkst",160);
}              //  Close for() loop. 
}
// *
label170:
   Dummy.label("Dchkst",170);
result[(13)- 1+ _result_offset] = temp1;
// *
// *           For positive definite matrices ( JTYPE.GT.15 ) call DPTEQR
// *           and do tests 14, 15, and 16 .
// *
if (jtype > 15)  {
    // *
// *              Compute D4 and Z4
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d4,_d4_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldu);
// *
ntest = 14;
Dpteqr.dpteqr("V",n,d4,_d4_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DPTEQR(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(14)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *              Do Tests 14 and 15
// *
Dstt21.dstt21(n,0,sd,_sd_offset,se,_se_offset,d4,_d4_offset,dumma,0,z,_z_offset,ldu,work,_work_offset,result,(14)- 1+ _result_offset);
// *
// *              Compute D5
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d5,_d5_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
// *
ntest = 16;
Dpteqr.dpteqr("N",n,d5,_d5_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DPTEQR(N)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(16)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *              Do Test 16
// *
temp1 = zero;
temp2 = zero;
{
forloop180:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d4[(j)- 1+ _d4_offset])) ? (temp1) : (Math.abs(d4[(j)- 1+ _d4_offset])), Math.abs(d5[(j)- 1+ _d5_offset]));
temp2 = Math.max(temp2, Math.abs(d4[(j)- 1+ _d4_offset]-d5[(j)- 1+ _d5_offset])) ;
Dummy.label("Dchkst",180);
}              //  Close for() loop. 
}
// *
result[(16)- 1+ _result_offset] = temp2/Math.max(unfl.val, hun*ulp*Math.max(temp1, temp2) ) ;
}              // Close if()
else  {
  result[(14)- 1+ _result_offset] = zero;
result[(15)- 1+ _result_offset] = zero;
result[(16)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *           Call DSTEBZ with different options and do tests 17-18.
// *
// *              If S is positive definite and diagonally dominant,
// *              ask for all eigenvalues with high relative accuracy.
// *
vl = zero;
vu = zero;
il = 0;
iu = 0;
if (jtype == 21)  {
    ntest = 17;
abstol = unfl.val+unfl.val;
Dstebz.dstebz("A","E",n,vl,vu,il,iu,abstol,sd,_sd_offset,se,_se_offset,m,nsplit,wr,_wr_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEBZ(A,rel)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(17)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *              Do test 17
// *
temp2 = two*(two*n-one)*ulp*(one+eight*Math.pow(half, 2))/Math.pow((one-half), 4);
// *
temp1 = zero;
{
forloop190:
for (j = 1; j <= n; j++) {
temp1 = Math.max(temp1, Math.abs(d4[(j)- 1+ _d4_offset]-wr[(n-j+1)- 1+ _wr_offset])/(abstol+Math.abs(d4[(j)- 1+ _d4_offset]))) ;
Dummy.label("Dchkst",190);
}              //  Close for() loop. 
}
// *
result[(17)- 1+ _result_offset] = temp1/temp2;
}              // Close if()
else  {
  result[(17)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *           Now ask for all eigenvalues with high absolute accuracy.
// *
ntest = 18;
abstol = unfl.val+unfl.val;
Dstebz.dstebz("A","E",n,vl,vu,il,iu,abstol,sd,_sd_offset,se,_se_offset,m,nsplit,wa1,_wa1_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEBZ(A)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(18)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do test 18
// *
temp1 = zero;
temp2 = zero;
{
forloop200:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d3[(j)- 1+ _d3_offset])) ? (temp1) : (Math.abs(d3[(j)- 1+ _d3_offset])), Math.abs(wa1[(j)- 1+ _wa1_offset]));
temp2 = Math.max(temp2, Math.abs(d3[(j)- 1+ _d3_offset]-wa1[(j)- 1+ _wa1_offset])) ;
Dummy.label("Dchkst",200);
}              //  Close for() loop. 
}
// *
result[(18)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
// *           Choose random values for IL and IU, and ask for the
// *           IL-th through IU-th eigenvalues.
// *
ntest = 19;
if (n <= 1)  {
    il = 1;
iu = n;
}              // Close if()
else  {
  il = (int)(1+(n-1)*Dlarnd.dlarnd(1,iseed2,0));
iu = (int)(1+(n-1)*Dlarnd.dlarnd(1,iseed2,0));
if (iu < il)  {
    itemp = iu;
iu = il;
il = itemp;
}              // Close if()
}              //  Close else.
// *
Dstebz.dstebz("I","E",n,vl,vu,il,iu,abstol,sd,_sd_offset,se,_se_offset,m2,nsplit,wa2,_wa2_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEBZ(I)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(19)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Determine the values VL and VU of the IL-th and IU-th
// *           eigenvalues and ask for all eigenvalues in this range.
// *
if (n > 0)  {
    if (il != 1)  {
    vl = wa1[(il)- 1+ _wa1_offset]-Math.max((half*(wa1[(il)- 1+ _wa1_offset]-wa1[(il-1)- 1+ _wa1_offset])) > (ulp*anorm) ? (half*(wa1[(il)- 1+ _wa1_offset]-wa1[(il-1)- 1+ _wa1_offset])) : (ulp*anorm), two*rtunfl);
}              // Close if()
else  {
  vl = wa1[(1)- 1+ _wa1_offset]-Math.max((half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) > (ulp*anorm) ? (half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) : (ulp*anorm), two*rtunfl);
}              //  Close else.
if (iu != n)  {
    vu = wa1[(iu)- 1+ _wa1_offset]+Math.max((half*(wa1[(iu+1)- 1+ _wa1_offset]-wa1[(iu)- 1+ _wa1_offset])) > (ulp*anorm) ? (half*(wa1[(iu+1)- 1+ _wa1_offset]-wa1[(iu)- 1+ _wa1_offset])) : (ulp*anorm), two*rtunfl);
}              // Close if()
else  {
  vu = wa1[(n)- 1+ _wa1_offset]+Math.max((half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) > (ulp*anorm) ? (half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) : (ulp*anorm), two*rtunfl);
}              //  Close else.
}              // Close if()
else  {
  vl = zero;
vu = one;
}              //  Close else.
// *
Dstebz.dstebz("V","E",n,vl,vu,il,iu,abstol,sd,_sd_offset,se,_se_offset,m3,nsplit,wa3,_wa3_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEBZ(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(19)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
if (m3.val == 0 && n != 0)  {
    result[(19)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              // Close if()
// *
// *           Do test 19
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(n)- 1+ _wa1_offset]), Math.abs(wa1[(1)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
// *
result[(19)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
// *           Call DSTEIN to compute eigenvectors corresponding to
// *           eigenvalues in WA1.  (First call DSTEBZ again, to make sure
// *           it returns these eigenvalues in the correct order.)
// *
ntest = 21;
Dstebz.dstebz("A","B",n,vl,vu,il,iu,abstol,sd,_sd_offset,se,_se_offset,m,nsplit,wa1,_wa1_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEBZ(A,B)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(20)- 1+ _result_offset] = ulpinv;
result[(21)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
Dstein.dstein(n,sd,_sd_offset,se,_se_offset,m.val,wa1,_wa1_offset,iwork,(1)- 1+ _iwork_offset,iwork,(n+1)- 1+ _iwork_offset,z,_z_offset,ldu,work,_work_offset,iwork,(2*n+1)- 1+ _iwork_offset,iwork,(3*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEIN") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(20)- 1+ _result_offset] = ulpinv;
result[(21)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do tests 20 and 21
// *
Dstt21.dstt21(n,0,sd,_sd_offset,se,_se_offset,wa1,_wa1_offset,dumma,0,z,_z_offset,ldu,work,_work_offset,result,(20)- 1+ _result_offset);
// *
// *           Call DSTEDC(I) to compute D1 and Z, do tests.
// *
// *           Compute D1 and Z
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d1,_d1_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldu);
// *
ntest = 22;
Dstedc.dstedc("I",n,d1,_d1_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,lwedc-n,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEDC(I)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(22)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do Tests 22 and 23
// *
Dstt21.dstt21(n,0,sd,_sd_offset,se,_se_offset,d1,_d1_offset,dumma,0,z,_z_offset,ldu,work,_work_offset,result,(22)- 1+ _result_offset);
// *
// *           Call DSTEDC(V) to compute D1 and Z, do tests.
// *
// *           Compute D1 and Z
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d1,_d1_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldu);
// *
ntest = 24;
Dstedc.dstedc("V",n,d1,_d1_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,lwedc-n,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEDC(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(24)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do Tests 24 and 25
// *
Dstt21.dstt21(n,0,sd,_sd_offset,se,_se_offset,d1,_d1_offset,dumma,0,z,_z_offset,ldu,work,_work_offset,result,(24)- 1+ _result_offset);
// *
// *           Call DSTEDC(N) to compute D2, do tests.
// *
// *           Compute D2
// *
Dcopy.dcopy(n,sd,_sd_offset,1,d2,_d2_offset,1);
if (n > 0)  
    Dcopy.dcopy(n-1,se,_se_offset,1,work,_work_offset,1);
Dlaset.dlaset("Full",n,n,zero,one,z,_z_offset,ldu);
// *
ntest = 26;
Dstedc.dstedc("N",n,d2,_d2_offset,work,_work_offset,z,_z_offset,ldu,work,(n+1)- 1+ _work_offset,lwedc-n,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DCHKST: "  + ("DSTEDC(N)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Dchkst",999999);
}              // Close if()
else  {
  result[(26)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Dchkst",220);
}              //  Close else.
}              // Close if()
// *
// *           Do Test 26
// *
temp1 = zero;
temp2 = zero;
// *
{
forloop210:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d2[(j)- 1+ _d2_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d2[(j)- 1+ _d2_offset])) ;
Dummy.label("Dchkst",210);
}              //  Close for() loop. 
}
// *
result[(26)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
label220:
   Dummy.label("Dchkst",220);
ntestt = ntestt+ntest;
// *
// *           Print out tests which fail.
// *
{
forloop230:
for (jr = 1; jr <= ntest; jr++) {
if (result[(jr)- 1+ _result_offset] >= thresh)  {
    // *
// *                 If this is the first test to fail,
// *                 print a header to the data file.
// *
if (nerrs == 0)  {
    System.out.println("\n"  + " " + ("DST") + " "  + " -- Real Symmetric eigenvalue problem" );
System.out.println(" Matrix types (see DCHKST for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.                        "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2=Identity matrix.                    "  + "  6=Diagonal: large, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entries.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=Diagonal: geometr. spaced entries." );
System.out.println(" Dense "  + ("Symmetric") + " "  + " Matrices:"  + "\n"  + "  8=Evenly spaced eigenvals.            "  + " 12=Small, evenly spaced eigenvals."  + "\n"  + "  9=Geometrically spaced eigenvals.     "  + " 13=Matrix with random O(1) entries."  + "\n"  + " 10=Clustered eigenvalues.              "  + " 14=Matrix with large random entries."  + "\n"  + " 11=Large, evenly spaced eigenvals.     "  + " 15=Matrix with small random entries." );
System.out.println(" 16=Positive definite, evenly spaced eigenvalues"  + "\n"  + " 17=Positive definite, geometrically spaced eigenvlaues"  + "\n"  + " 18=Positive definite, clustered eigenvalues"  + "\n"  + " 19=Positive definite, small evenly spaced eigenvalues"  + "\n"  + " 20=Positive definite, large evenly spaced eigenvalues"  + "\n"  + " 21=Diagonally dominant tridiagonal, geometrically"  + " spaced eigenvalues" );
// *
// *                    Tests performed
// *
System.out.print(("orthogonal") + " " + ("\'=transpose") + " ");
for(j = 1; j <= 4; j++)
  System.out.print(" ");

System.out.println();
System.out.print("");
for(j = 1; j <= 6; j++)
  System.out.print(" ");

System.out.println();
System.out.print("");
for(j = 1; j <= 4; j++)
  System.out.print(" ");

System.out.println();
System.out.print("");
for(j = 1; j <= 4; j++)
  System.out.print(" ");

System.out.println();
}              // Close if()
nerrs = nerrs+1;
System.out.println(" N="  + (n) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (jtype) + " "  + ","  + (jr) + " "  + ","  + (result[(jr)- 1+ _result_offset]) + " "  + ","  + " type "  + " NULL " + " "  + ", test("  + " NULL " + " "  + ")="  + " NULL " + " " );
}              // Close if()
Dummy.label("Dchkst",230);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchkst",240);
}              //  Close for() loop. 
}
Dummy.label("Dchkst",250);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Dlasum.dlasum("DST",nounit,nerrs,ntestt);
Dummy.go_to("Dchkst",999999);
// *
// *
// *
// *
// *
// *     End of DCHKST
// *
Dummy.label("Dchkst",999999);
return;
   }
} // End class.
