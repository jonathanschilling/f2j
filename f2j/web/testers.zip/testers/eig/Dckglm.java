/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dckglm {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCKGLM tests DGGGLM - subroutine for solving generalized linear
// *                        model problem.
// *
// *  Arguments
// *  =========
// *
// *  NN      (input) INTEGER
// *          The number of values of N, M and P contained in the vectors
// *          NVAL, MVAL and PVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension M.
// *
// *  PVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension P.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix row dimension N.
// *
// *  NMATS   (input) INTEGER
// *          The number of matrix types to be tested for each combination
// *          of matrix dimensions.  If NMATS >= NTYPES (the maximum
// *          number of matrix types), then all the different types are
// *          generated for testing.  If NMATS < NTYPES, another input line
// *          is read to get the numbers of the matrix types to be used.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator.  The array
// *          elements should be between 0 and 4095, otherwise they will be
// *          reduced mod 4096, and ISEED(4) must be odd.
// *          On exit, the next seed in the random number sequence after
// *          all the test matrices have been generated.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESID >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for M or N, used in dimensioning
// *          the work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  BF      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (4*NMAX)
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  NIN     (input) INTEGER
// *          The unit number for input.
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  INFO    (output) INTEGER
// *          = 0 :  successful exit
// *          > 0 :  If DLATMS returns an error code, the absolute value
// *                 of it is returned.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntypes= 8;
// *     ..
// *     .. Local Scalars ..
static boolean firstt= false;
static StringW dista= new StringW(" ");
static StringW distb= new StringW(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static intW iinfo= new intW(0);
static int ik= 0;
static int imat= 0;
static intW kla= new intW(0);
static intW klb= new intW(0);
static intW kua= new intW(0);
static intW kub= new intW(0);
static int lda= 0;
static int ldb= 0;
static int lwork= 0;
static int m= 0;
static intW modea= new intW(0);
static intW modeb= new intW(0);
static int n= 0;
static int nfail= 0;
static int nrun= 0;
static int p= 0;
static doubleW anorm= new doubleW(0.0);
static doubleW bnorm= new doubleW(0.0);
static doubleW cndnma= new doubleW(0.0);
static doubleW cndnmb= new doubleW(0.0);
static doubleW resid= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static boolean [] dotype= new boolean[(ntypes)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants.
// *

public static void dckglm (int nn,
int [] mval, int _mval_offset,
int [] pval, int _pval_offset,
int [] nval, int _nval_offset,
int nmats,
int [] iseed, int _iseed_offset,
double thresh,
int nmax,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
double [] x, int _x_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int nin,
int nout,
intW info)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "GLM".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
info.val = 0;
nrun = 0;
nfail = 0;
firstt = true;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
lda = nmax;
ldb = nmax;
lwork = nmax*nmax;
// *
// *     Check for valid input values.
// *
{
forloop10:
for (ik = 1; ik <= nn; ik++) {
m = mval[(ik)- 1+ _mval_offset];
p = pval[(ik)- 1+ _pval_offset];
n = nval[(ik)- 1+ _nval_offset];
if (m > n || n > m+p)  {
    if (firstt)  {
    System.out.println();
firstt = false;
}              // Close if()
System.out.println(" *** Invalid input  for GLM:  M = "  + (m) + " "  + ", P = "  + (p) + " "  + ", N = "  + (n) + " "  + ";"  + "\n"  + "     must satisfy M <= N <= M+P  "  + "(this set of values will be skipped)" );
}              // Close if()
Dummy.label("Dckglm",10);
}              //  Close for() loop. 
}
firstt = true;
// *
// *     Do for each value of M in MVAL.
// *
{
forloop40:
for (ik = 1; ik <= nn; ik++) {
m = mval[(ik)- 1+ _mval_offset];
p = pval[(ik)- 1+ _pval_offset];
n = nval[(ik)- 1+ _nval_offset];
if (m > n || n > m+p)  
    continue forloop40;
// *
{
forloop30:
for (imat = 1; imat <= ntypes; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1])  
    continue forloop30;
// *
// *           Set up parameters with DLATB9 and generate test
// *           matrices A and B with DLATMS.
// *
Dlatb9.dlatb9(path,imat,m,p,n,type,kla,kua,klb,kub,anorm,bnorm,modea,modeb,cndnma,cndnmb,dista,distb);
// *
Dlatms.dlatms(n,m,dista.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modea.val,cndnma.val,anorm.val,kla.val,kua.val,"No packing",a,_a_offset,lda,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGLM INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
Dlatms.dlatms(n,p,distb.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modeb.val,cndnmb.val,bnorm.val,klb.val,kub.val,"No packing",b,_b_offset,ldb,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGLM INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
// *           Generate random left hand side vector of GLM
// *
{
forloop20:
for (i = 1; i <= n; i++) {
x[(i)- 1+ _x_offset] = Dlarnd.dlarnd(2,iseed,_iseed_offset);
Dummy.label("Dckglm",20);
}              //  Close for() loop. 
}
// *
Dglmts.dglmts(n,m,p,a,_a_offset,af,_af_offset,lda,b,_b_offset,bf,_bf_offset,ldb,x,_x_offset,x,(nmax+1)- 1+ _x_offset,x,(2*nmax+1)- 1+ _x_offset,x,(3*nmax+1)- 1+ _x_offset,work,_work_offset,lwork,rwork,_rwork_offset,resid);
// *
// *           Print information about the tests that did not
// *           pass the threshold.
// *
if (resid.val >= thresh)  {
    if (nfail == 0 && firstt)  {
    firstt = false;
Alahdg.alahdg(nout,path);
}              // Close if()
System.out.println(" N="  + (n) + " "  + " M="  + (m) + " "  + ", P="  + (p) + " "  + ", type "  + (imat) + " "  + ", test "  + (1) + " "  + ", ratio="  + (resid.val) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+1;
// *
Dummy.label("Dckglm",30);
}              //  Close for() loop. 
}
Dummy.label("Dckglm",40);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,0);
// *
Dummy.go_to("Dckglm",999999);
// *
// *     End of DCKGLM
// *
Dummy.label("Dckglm",999999);
return;
   }
} // End class.
