/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dckgqr {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCKGQR tests
// *  DGGQRF: GQR factorization for N-by-M matrix A and N-by-P matrix B,
// *  DGGRQF: GRQ factorization for M-by-N matrix A and P-by-N matrix B.
// *
// *  Arguments
// *  =========
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row(column) dimension M.
// *
// *  NP      (input) INTEGER
// *          The number of values of P contained in the vector PVAL.
// *
// *  PVAL    (input) INTEGER array, dimension (NP)
// *          The values of the matrix row(column) dimension P.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column(row) dimension N.
// *
// *  NMATS   (input) INTEGER
// *          The number of matrix types to be tested for each combination
// *          of matrix dimensions.  If NMATS >= NTYPES (the maximum
// *          number of matrix types), then all the different types are
// *          generated for testing.  If NMATS < NTYPES, another input line
// *          is read to get the numbers of the matrix types to be used.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator.  The array
// *          elements should be between 0 and 4095, otherwise they will be
// *          reduced mod 4096, and ISEED(4) must be odd.
// *          On exit, the next seed in the random number sequence after
// *          all the test matrices have been generated.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for M or N, used in dimensioning
// *          the work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AQ      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AR      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  TAUA    (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  BF      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  BZ      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  BT      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  BWK     (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  TAUB    (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  NIN     (input) INTEGER
// *          The unit number for input.
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  INFO    (output) INTEGER
// *          = 0 :  successful exit
// *          > 0 :  If DLATMS returns an error code, the absolute value
// *                 of it is returned.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntests= 7;
static int ntypes= 8;
// *     ..
// *     .. Local Scalars ..
static boolean firstt= false;
static StringW dista= new StringW(" ");
static StringW distb= new StringW(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static intW iinfo= new intW(0);
static int im= 0;
static int imat= 0;
static int in= 0;
static int ip= 0;
static intW kla= new intW(0);
static intW klb= new intW(0);
static intW kua= new intW(0);
static intW kub= new intW(0);
static int lda= 0;
static int ldb= 0;
static int lwork= 0;
static int m= 0;
static intW modea= new intW(0);
static intW modeb= new intW(0);
static int n= 0;
static int nfail= 0;
static int nrun= 0;
static int nt= 0;
static int p= 0;
static doubleW anorm= new doubleW(0.0);
static doubleW bnorm= new doubleW(0.0);
static doubleW cndnma= new doubleW(0.0);
static doubleW cndnmb= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static boolean [] dotype= new boolean[(ntypes)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants.
// *

public static void dckgqr (int nm,
int [] mval, int _mval_offset,
int np,
int [] pval, int _pval_offset,
int nn,
int [] nval, int _nval_offset,
int nmats,
int [] iseed, int _iseed_offset,
double thresh,
int nmax,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] aq, int _aq_offset,
double [] ar, int _ar_offset,
double [] taua, int _taua_offset,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
double [] bz, int _bz_offset,
double [] bt, int _bt_offset,
double [] bwk, int _bwk_offset,
double [] taub, int _taub_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int nin,
int nout,
intW info)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "GQR".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
info.val = 0;
nrun = 0;
nfail = 0;
firstt = true;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
lda = nmax;
ldb = nmax;
lwork = nmax*nmax;
// *
// *     Do for each value of M in MVAL.
// *
{
forloop60:
for (im = 1; im <= nm; im++) {
m = mval[(im)- 1+ _mval_offset];
// *
// *        Do for each value of P in PVAL.
// *
{
forloop50:
for (ip = 1; ip <= np; ip++) {
p = pval[(ip)- 1+ _pval_offset];
// *
// *           Do for each value of N in NVAL.
// *
{
forloop40:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
// *
{
forloop30:
for (imat = 1; imat <= ntypes; imat++) {
// *
// *                 Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1])  
    continue forloop30;
// *
// *                 Test DGGRQF
// *
// *                 Set up parameters with DLATB9 and generate test
// *                 matrices A and B with DLATMS.
// *
Dlatb9.dlatb9("GRQ",imat,m,p,n,type,kla,kua,klb,kub,anorm,bnorm,modea,modeb,cndnma,cndnmb,dista,distb);
// *
// *                 Generate M by N matrix A
// *
Dlatms.dlatms(m,n,dista.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modea.val,cndnma.val,anorm.val,kla.val,kua.val,"No packing",a,_a_offset,lda,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGQR:    INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
// *                 Generate P by N matrix B
// *
Dlatms.dlatms(p,n,distb.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modeb.val,cndnmb.val,bnorm.val,klb.val,kub.val,"No packing",b,_b_offset,ldb,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGQR:    INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
nt = 4;
// *
Dgrqts.dgrqts(m,p,n,a,_a_offset,af,_af_offset,aq,_aq_offset,ar,_ar_offset,lda,taua,_taua_offset,b,_b_offset,bf,_bf_offset,bz,_bz_offset,bt,_bt_offset,bwk,_bwk_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,rwork,_rwork_offset,result,0);
// *
// *                 Print information about the tests that did not
// *                 pass the threshold.
// *
{
forloop10:
for (i = 1; i <= nt; i++) {
if (result[(i)- 1] >= thresh)  {
    if (nfail == 0 && firstt)  {
    firstt = false;
Alahdg.alahdg(nout,"GRQ");
}              // Close if()
System.out.println(" M="  + (m) + " "  + " P="  + (p) + " "  + ", N="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (i) + " "  + ", ratio="  + (result[(i)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dckgqr",10);
}              //  Close for() loop. 
}
nrun = nrun+nt;
// *
// *                 Test DGGQRF
// *
// *                 Set up parameters with DLATB9 and generate test
// *                 matrices A and B with DLATMS.
// *
Dlatb9.dlatb9("GQR",imat,m,p,n,type,kla,kua,klb,kub,anorm,bnorm,modea,modeb,cndnma,cndnmb,dista,distb);
// *
// *                 Generate N-by-M matrix  A
// *
Dlatms.dlatms(n,m,dista.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modea.val,cndnma.val,anorm.val,kla.val,kua.val,"No packing",a,_a_offset,lda,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGQR:    INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
// *                 Generate N-by-P matrix  B
// *
Dlatms.dlatms(n,p,distb.val,iseed,_iseed_offset,type.val,rwork,_rwork_offset,modea.val,cndnma.val,bnorm.val,klb.val,kub.val,"No packing",b,_b_offset,ldb,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DLATMS in DCKGQR:    INFO = "  + (iinfo.val) + " " );
info.val = (int)(Math.abs(iinfo.val));
continue forloop30;
}              // Close if()
// *
nt = 4;
// *
Dgqrts.dgqrts(n,m,p,a,_a_offset,af,_af_offset,aq,_aq_offset,ar,_ar_offset,lda,taua,_taua_offset,b,_b_offset,bf,_bf_offset,bz,_bz_offset,bt,_bt_offset,bwk,_bwk_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,rwork,_rwork_offset,result,0);
// *
// *                 Print information about the tests that did not
// *                 pass the threshold.
// *
{
forloop20:
for (i = 1; i <= nt; i++) {
if (result[(i)- 1] >= thresh)  {
    if (nfail == 0 && firstt)  {
    firstt = false;
Alahdg.alahdg(nout,path);
}              // Close if()
System.out.println(" N="  + (n) + " "  + " M="  + (m) + " "  + ", P="  + (p) + " "  + ", type "  + (imat) + " "  + ", test "  + (i) + " "  + ", ratio="  + (result[(i)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dckgqr",20);
}              //  Close for() loop. 
}
nrun = nrun+nt;
// *
Dummy.label("Dckgqr",30);
}              //  Close for() loop. 
}
Dummy.label("Dckgqr",40);
}              //  Close for() loop. 
}
Dummy.label("Dckgqr",50);
}              //  Close for() loop. 
}
Dummy.label("Dckgqr",60);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,0);
// *
Dummy.go_to("Dckgqr",999999);
// *
// *     End of DCKGQR
// *
Dummy.label("Dckgqr",999999);
return;
   }
} // End class.
