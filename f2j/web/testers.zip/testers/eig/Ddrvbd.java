/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Ddrvbd {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVBD checks the singular value decomposition (SVD) driver DGESVD.
// *  DGESVD factors A = U diag(S) VT, where U and VT are orthogonal
// *  and diag(S) is diagonal with the entries of the array S on its
// *  diagonal. The entries of S are the singular values, nonnegative and
// *  stored in decreasing order.  U and VT can be optionally not computed,
// *  overwritten on A, or computed partially.
// *
// *  A is M by N. Let MNMIN = min( M, N ). S has dimension MNMIN.
// *  U can be M by M or M by MNMIN. VT can be N by N or MNMIN by N.
// *
// *  When DDRVBD is called, a number of matrix "sizes" (M's and N's)
// *  and a number of matrix "types" are specified.  For each size (M,N)
// *  and each type of matrix, and for the minimal workspace as well as
// *  workspace adequate to permit blocking, an  M x N  matrix "A" will be
// *  generated and used to test the SVD routines.  For each matrix, A will
// *  be factored as A = U diag(S) VT and the following 6 tests computed:
// *
// *  (1)   | A - U diag(S) VT | / ( |A| max(M,N) ulp )
// *
// *  (2)   | I - U'U | / ( M ulp )
// *
// *  (3)   | I - VT VT' | / ( N ulp )
// *
// *  (4)   S contains MNMIN nonnegative values in decreasing order.
// *        (Return 0 if true, 1/ULP if false.)
// *
// *  (5)   | U - Upartial | / ( M ulp ) where Upartial is a partially
// *        computed U.
// *
// *  (6)   | VT - VTpartial | / ( N ulp ) where VTpartial is a partially
// *        computed VT.
// *
// *  (7)   | S - Spartial | / ( MNMIN ulp |S| ) where Spartial is the
// *        vector of singular values from the partial SVD
// *
// *  The "sizes" are specified by the arrays MM(1:NSIZES) and
// *  NN(1:NSIZES); the value of each element pair (MM(j),NN(j))
// *  specifies one size.  The "types" are specified by a logical array
// *  DOTYPE( 1:NTYPES ); if DOTYPE(j) is .TRUE., then matrix type "j"
// *  will be generated.
// *  Currently, the list of possible types is:
// *
// *  (1)  The zero matrix.
// *  (2)  The identity matrix.
// *  (3)  A matrix of the form  U D V, where U and V are orthogonal and
// *       D has evenly spaced entries 1, ..., ULP with random signs
// *       on the diagonal.
// *  (4)  Same as (3), but multiplied by the underflow-threshold / ULP.
// *  (5)  Same as (3), but multiplied by the overflow-threshold * ULP.
// *
// *  Arguments
// *  ==========
// *
// *  NSIZES  (input) INTEGER
// *          The number of matrix sizes (M,N) contained in the vectors
// *          MM and NN.
// *
// *  MM      (input) INTEGER array, dimension (NSIZES)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER array, dimension (NSIZES)
// *          The values of the matrix column dimension N.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DDRVBD
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrices are in A and B.
// *          This is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size (m,n), a matrix
// *          of type j will be generated.  If NTYPES is smaller than the
// *          maximum number of types defined (PARAMETER MAXTYP), then
// *          types NTYPES+1 through MAXTYP will not be generated.  If
// *          NTYPES is larger than MAXTYP, DOTYPE(MAXTYP+1) through
// *          DOTYPE(NTYPES) will be ignored.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator.  The array
// *          elements should be between 0 and 4095; if not they will be
// *          reduced mod 4096.  Also, ISEED(4) must be odd.
// *          On exit, ISEED is changed and can be used in the next call to
// *          DDRVBD to continue the same random number sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  The test
// *          ratios are scaled to be O(1), so THRESH should be a small
// *          multiple of 1, e.g., 10 or 100.  To have every test ratio
// *          printed, use THRESH = 0.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (LDA,NMAX)
// *          where NMAX is the maximum value of N in NN.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,MMAX),
// *          where MMAX is the maximum value of M in MM.
// *
// *  U       (workspace) DOUBLE PRECISION array, dimension (LDU,MMAX)
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= max(1,MMAX).
// *
// *  VT      (workspace) DOUBLE PRECISION array, dimension (LDVT,NMAX)
// *
// *  LDVT    (input) INTEGER
// *          The leading dimension of the array VT.  LDVT >= max(1,NMAX).
// *
// *  ASAV    (workspace) DOUBLE PRECISION array, dimension (LDA,NMAX)
// *
// *  USAV    (workspace) DOUBLE PRECISION array, dimension (LDU,MMAX)
// *
// *  VTSAV   (workspace) DOUBLE PRECISION array, dimension (LDVT,NMAX)
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MM,NN)))
// *
// *  SSAV    (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MM,NN)))
// *
// *  E       (workspace) DOUBLE PRECISION array, dimension
// *                      (max(min(MM,NN)))
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          max(3*MN+MX,5*MN-4)+2*MN**2 for all pairs
// *          pairs  (MN,MX)=( min(MM(j),NN(j), max(MM(j),NN(j)) )
// *
// *  NOUT    (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *
// *  INFO    (output) INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some MM(j) < 0
// *           -3: Some NN(j) < 0
// *           -4: NTYPES < 0
// *           -7: THRESH < 0
// *          -10: LDA < 1 or LDA < MMAX, where MMAX is max( MM(j) ).
// *          -12: LDU < 1 or LDU < MMAX.
// *          -14: LDVT < 1 or LDVT < NMAX, where NMAX is max( NN(j) ).
// *          -21: LWORK too small.
// *          If  DLATMS, or DGESVD returns an error code, the
// *              absolute value of it is returned.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static int maxtyp= 5;
// *     ..
// *     .. Local Scalars ..
static boolean badmm= false;
static boolean badnn= false;
static String jobu= new String(" ");
static String jobvt= new String(" ");
static String path= new String("   ");
static int i= 0;
static intW iinfo= new intW(0);
static int iju= 0;
static int ijvt= 0;
static int iws= 0;
static int iwtmp= 0;
static int j= 0;
static int jsize= 0;
static int jtype= 0;
static int lswork= 0;
static int m= 0;
static int minwrk= 0;
static int mmax= 0;
static int mnmax= 0;
static int mnmin= 0;
static int mtypes= 0;
static int n= 0;
static int nfail= 0;
static int nmax= 0;
static int ntest= 0;
static double anorm= 0.0;
static doubleW dif= new doubleW(0.0);
static double div= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ioldsd= new int[(4)];
static double [] result= new double[(7)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String [] cjob = {"N" 
, "O" , "S" , "A" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void ddrvbd (int nsizes,
int [] mm, int _mm_offset,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
double [] a, int _a_offset,
int lda,
double [] u, int _u_offset,
int ldu,
double [] vt, int _vt_offset,
int ldvt,
double [] asav, int _asav_offset,
double [] usav, int _usav_offset,
double [] vtsav, int _vtsav_offset,
double [] s, int _s_offset,
double [] ssav, int _ssav_offset,
double [] e, int _e_offset,
double [] work, int _work_offset,
int lwork,
int nout,
intW info)  {

info.val = 0;
badmm = false;
badnn = false;
mmax = 1;
nmax = 1;
mnmax = 1;
minwrk = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
mmax = (int)(Math.max(mmax, mm[(j)- 1+ _mm_offset]) );
if (mm[(j)- 1+ _mm_offset] < 0)  
    badmm = true;
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
mnmax = (int)(Math.max(mnmax, Math.min(mm[(j)- 1+ _mm_offset], nn[(j)- 1+ _nn_offset]) ) );
minwrk = (int)(Math.max(minwrk, Math.max(3*Math.min(mm[(j)- 1+ _mm_offset], nn[(j)- 1+ _nn_offset]) +Math.max(mm[(j)- 1+ _mm_offset], nn[(j)- 1+ _nn_offset]) , 5*Math.min(mm[(j)- 1+ _mm_offset], nn[(j)- 1+ _nn_offset]-4) ) +2*Math.pow(Math.min(mm[(j)- 1+ _mm_offset], nn[(j)- 1+ _nn_offset]) , 2)) );
Dummy.label("Ddrvbd",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badmm)  {
    info.val = -2;
}              // Close else if()
else if (badnn)  {
    info.val = -3;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, mmax) )  {
    info.val = -10;
}              // Close else if()
else if (ldu < Math.max(1, mmax) )  {
    info.val = -12;
}              // Close else if()
else if (ldvt < Math.max(1, nmax) )  {
    info.val = -14;
}              // Close else if()
else if (minwrk > lwork)  {
    info.val = -21;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DDRVBD",-info.val);
Dummy.go_to("Ddrvbd",999999);
}              // Close if()
// *
// *     Initialize constants
// *
{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "BD".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nfail = 0;
ntest = 0;
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = one/unfl.val;
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Precision");
ulpinv = one/ulp;
eigtest_infoc.infot = 0;
// *
// *     Loop over sizes, types
// *
{
forloop120:
for (jsize = 1; jsize <= nsizes; jsize++) {
m = mm[(jsize)- 1+ _mm_offset];
n = nn[(jsize)- 1+ _nn_offset];
mnmin = (int)(Math.min(m, n) );
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop110:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop110;
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Ddrvbd",20);
}              //  Close for() loop. 
}
// *
// *           Compute "A"
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Ddrvbd",30);
// *
if (jtype == 1)  {
    // *
// *              Zero matrix
// *
Dlaset.dlaset("Full",m,n,zero,zero,a,_a_offset,lda);
// *
}              // Close if()
else if (jtype == 2)  {
    // *
// *              Identity matrix
// *
Dlaset.dlaset("Full",m,n,zero,one,a,_a_offset,lda);
// *
}              // Close else if()
else  {
  // *
// *              (Scaled) random matrix
// *
if (jtype == 3)  
    anorm = one;
if (jtype == 4)  
    anorm = unfl.val/ulp;
if (jtype == 5)  
    anorm = ovfl.val*ulp;
Dlatms.dlatms(m,n,"U",iseed,_iseed_offset,"N",s,_s_offset,4,(double)(mnmin),anorm,m-1,n-1,"N",a,_a_offset,lda,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVBD: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvbd",999999);
}              // Close if()
}              //  Close else.
// *
label30:
   Dummy.label("Ddrvbd",30);
Dlacpy.dlacpy("F",m,n,a,_a_offset,lda,asav,_asav_offset,lda);
// *
// *           Do for minimal and adequate (for blocking) workspace
// *
iwtmp = (int)(Math.max(3*Math.min(m, n) +Math.max(m, n) , 5*Math.min(m, n) -4) );
{
forloop100:
for (iws = 1; iws <= 4; iws++) {
lswork = iwtmp+(iws-1)*(lwork-iwtmp)/3;
lswork = (int)(Math.min(lswork, lwork) );
lswork = (int)(Math.max(lswork, 1) );
if (iws == 4)  
    lswork = lwork;
// *
{
forloop40:
for (j = 1; j <= 7; j++) {
result[(j)- 1] = -one;
Dummy.label("Ddrvbd",40);
}              //  Close for() loop. 
}
// *
// *              Factorize A
// *
if (iws > 1)  
    Dlacpy.dlacpy("F",m,n,asav,_asav_offset,lda,a,_a_offset,lda);
eigtest_srnamc.srnamt = "DGESVD";
Dgesvd.dgesvd("A","A",m,n,a,_a_offset,lda,ssav,_ssav_offset,usav,_usav_offset,ldu,vtsav,_vtsav_offset,ldvt,work,_work_offset,lswork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVBD: "  + ("GESVD") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "M="  + (m) + " "  + ", N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", LSWORK="  + (lswork) + " "  + "\n"  + "         " + "ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvbd",999999);
}              // Close if()
// *
// *              Do tests 1--4
// *
dbdt01_adapter(m,n,0,asav,_asav_offset,lda,usav,_usav_offset,ldu,ssav,_ssav_offset,e,_e_offset,vtsav,_vtsav_offset,ldvt,work,_work_offset,result,(1)- 1);
dort01_adapter("Columns",mnmin,m,usav,_usav_offset,ldu,work,_work_offset,lwork,result,(2)- 1);
dort01_adapter("Rows",mnmin,n,vtsav,_vtsav_offset,ldvt,work,_work_offset,lwork,result,(3)- 1);
result[(4)- 1] = zero;
{
forloop50:
for (i = 1; i <= mnmin-1; i++) {
if (ssav[(i)- 1+ _ssav_offset] < ssav[(i+1)- 1+ _ssav_offset])  
    result[(4)- 1] = ulpinv;
if (ssav[(i)- 1+ _ssav_offset] < zero)  
    result[(4)- 1] = ulpinv;
Dummy.label("Ddrvbd",50);
}              //  Close for() loop. 
}
if (mnmin >= 1)  {
    if (ssav[(mnmin)- 1+ _ssav_offset] < zero)  
    result[(4)- 1] = ulpinv;
}              // Close if()
// *
// *              Do partial SVDs, comparing to SSAV, USAV, and VTSAV
// *
result[(5)- 1] = zero;
result[(6)- 1] = zero;
result[(7)- 1] = zero;
{
forloop80:
for (iju = 0; iju <= 3; iju++) {
{
forloop70:
for (ijvt = 0; ijvt <= 3; ijvt++) {
if ((iju == 3 && ijvt == 3) || (iju == 1 && ijvt == 1))  
    continue forloop70;
jobu = cjob[(iju+1)- 1];
jobvt = cjob[(ijvt+1)- 1];
Dlacpy.dlacpy("F",m,n,asav,_asav_offset,lda,a,_a_offset,lda);
eigtest_srnamc.srnamt = "DGESVD";
Dgesvd.dgesvd(jobu,jobvt,m,n,a,_a_offset,lda,s,_s_offset,u,_u_offset,ldu,vt,_vt_offset,ldvt,work,_work_offset,lswork,iinfo);
// *
// *                    Compare U
// *
dif.val = zero;
if (m > 0 && n > 0)  {
    if (iju == 1)  {
    Dort03.dort03("C",m,mnmin,m,mnmin,usav,_usav_offset,ldu,a,_a_offset,lda,work,_work_offset,lwork,dif,iinfo);
}              // Close if()
else if (iju == 2)  {
    Dort03.dort03("C",m,mnmin,m,mnmin,usav,_usav_offset,ldu,u,_u_offset,ldu,work,_work_offset,lwork,dif,iinfo);
}              // Close else if()
else if (iju == 3)  {
    Dort03.dort03("C",m,m,m,mnmin,usav,_usav_offset,ldu,u,_u_offset,ldu,work,_work_offset,lwork,dif,iinfo);
}              // Close else if()
}              // Close if()
result[(5)- 1] = Math.max(result[(5)- 1], dif.val) ;
// *
// *                    Compare VT
// *
dif.val = zero;
if (m > 0 && n > 0)  {
    if (ijvt == 1)  {
    Dort03.dort03("R",n,mnmin,n,mnmin,vtsav,_vtsav_offset,ldvt,a,_a_offset,lda,work,_work_offset,lwork,dif,iinfo);
}              // Close if()
else if (ijvt == 2)  {
    Dort03.dort03("R",n,mnmin,n,mnmin,vtsav,_vtsav_offset,ldvt,vt,_vt_offset,ldvt,work,_work_offset,lwork,dif,iinfo);
}              // Close else if()
else if (ijvt == 3)  {
    Dort03.dort03("R",n,n,n,mnmin,vtsav,_vtsav_offset,ldvt,vt,_vt_offset,ldvt,work,_work_offset,lwork,dif,iinfo);
}              // Close else if()
}              // Close if()
result[(6)- 1] = Math.max(result[(6)- 1], dif.val) ;
// *
// *                    Compare S
// *
dif.val = zero;
div = Math.max((double)(mnmin)*ulp*s[(1)- 1+ _s_offset], unfl.val) ;
{
forloop60:
for (i = 1; i <= mnmin-1; i++) {
if (ssav[(i)- 1+ _ssav_offset] < ssav[(i+1)- 1+ _ssav_offset])  
    dif.val = ulpinv;
if (ssav[(i)- 1+ _ssav_offset] < zero)  
    dif.val = ulpinv;
dif.val = Math.max(dif.val, Math.abs(ssav[(i)- 1+ _ssav_offset]-s[(i)- 1+ _s_offset])/div) ;
Dummy.label("Ddrvbd",60);
}              //  Close for() loop. 
}
result[(7)- 1] = Math.max(result[(7)- 1], dif.val) ;
Dummy.label("Ddrvbd",70);
}              //  Close for() loop. 
}
Dummy.label("Ddrvbd",80);
}              //  Close for() loop. 
}
// *
// *              End of Loop -- Check for RESULT(j) > THRESH
// *
{
forloop90:
for (j = 1; j <= 7; j++) {
if (result[(j)- 1] >= thresh)  {
    if (nfail == 0)  {
    System.out.println(" SVD -- Real Singular Value Decomposition Driver "  + "\n"  + " Matrix types (see DDRVBD for details):"  + "\n\n"  + " 1 = Zero matrix"  + "\n"  + " 2 = Identity matrix"  + "\n"  + " 3 = Evenly spaced singular values near 1"  + "\n"  + " 4 = Evenly spaced singular values near underflow"  + "\n"  + " 5 = Evenly spaced singular values near overflow"  + "\n\n"  + " Tests performed: ( A is dense, U and V are orthogonal,"  + "\n"  + "                   " + " S is an array, and Upartial, VTpartial, and"  + "\n"  + "                   " + " Spartial are partially computed U, VT and S),"  + "\n" );
System.out.println(" 1 = | A - U diag(S) VT | / ( |A| max(M,N) ulp ) "  + "\n"  + " 2 = | I - U**T U | / ( M ulp ) "  + "\n"  + " 3 = | I - VT VT**T | / ( N ulp ) "  + "\n"  + " 4 = 0 if S contains min(M,N) nonnegative values in"  + " decreasing order, else 1/ulp"  + "\n"  + " 5 = | U - Upartial | / ( M ulp )"  + "\n"  + " 6 = | VT - VTpartial | / ( N ulp )"  + "\n"  + " 7 = | S - Spartial | / ( min(M,N) ulp |S| )"  + "\n\n" );
}              // Close if()
System.out.println(" M="  + (m) + " "  + ", N="  + (n) + " "  + ", type "  + (jtype) + " "  + ", IWS="  + (iws) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (j) + " "  + ","  + (result[(j)- 1]) + " "  + ","  + " NULL " + " "  + ","  + " test("  + " NULL " + " "  + ")="  + " NULL " + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvbd",90);
}              //  Close for() loop. 
}
ntest = ntest+7;
// *
Dummy.label("Ddrvbd",100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvbd",110);
}              //  Close for() loop. 
}
Dummy.label("Ddrvbd",120);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Alasvm.alasvm(path,nout,nfail,ntest,0);
// *
// *
Dummy.go_to("Ddrvbd",999999);
// *
// *     End of DDRVBD
// *
Dummy.label("Ddrvbd",999999);
return;
   }
// adapter for dbdt01
private static void dbdt01_adapter(int arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,int arg10 ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dbdt01.dbdt01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8, arg8_offset,arg9, arg9_offset,arg10,arg11, arg11_offset,_f2j_tmp12);

arg12[arg12_offset] = _f2j_tmp12.val;
}

// adapter for dort01
private static void dort01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dort01.dort01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
