/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Ddrvev {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DDRVEV  checks the nonsymmetric eigenvalue problem driver DGEEV.
// *
// *     When DDRVEV is called, a number of matrix "sizes" ("n's") and a
// *     number of matrix "types" are specified.  For each size ("n")
// *     and each type of matrix, one matrix will be generated and used
// *     to test the nonsymmetric eigenroutines.  For each matrix, 7
// *     tests will be performed:
// *
// *     (1)     | A * VR - VR * W | / ( n |A| ulp )
// *
// *       Here VR is the matrix of unit right eigenvectors.
// *       W is a block diagonal matrix, with a 1x1 block for each
// *       real eigenvalue and a 2x2 block for each complex conjugate
// *       pair.  If eigenvalues j and j+1 are a complex conjugate pair,
// *       so WR(j) = WR(j+1) = wr and WI(j) = - WI(j+1) = wi, then the
// *       2 x 2 block corresponding to the pair will be:
// *
// *               (  wr  wi  )
// *               ( -wi  wr  )
// *
// *       Such a block multiplying an n x 2 matrix  ( ur ui ) on the
// *       right will be the same as multiplying  ur + i*ui  by  wr + i*wi.
// *
// *     (2)     | A**H * VL - VL * W**H | / ( n |A| ulp )
// *
// *       Here VL is the matrix of unit left eigenvectors, A**H is the
// *       conjugate transpose of A, and W is as above.
// *
// *     (3)     | |VR(i)| - 1 | / ulp and whether largest component real
// *
// *       VR(i) denotes the i-th column of VR.
// *
// *     (4)     | |VL(i)| - 1 | / ulp and whether largest component real
// *
// *       VL(i) denotes the i-th column of VL.
// *
// *     (5)     W(full) = W(partial)
// *
// *       W(full) denotes the eigenvalues computed when both VR and VL
// *       are also computed, and W(partial) denotes the eigenvalues
// *       computed when only W, only W and VR, or only W and VL are
// *       computed.
// *
// *     (6)     VR(full) = VR(partial)
// *
// *       VR(full) denotes the right eigenvectors computed when both VR
// *       and VL are computed, and VR(partial) denotes the result
// *       when only VR is computed.
// *
// *      (7)     VL(full) = VL(partial)
// *
// *       VL(full) denotes the left eigenvectors computed when both VR
// *       and VL are also computed, and VL(partial) denotes the result
// *       when only VL is computed.
// *
// *     The "sizes" are specified by an array NN(1:NSIZES); the value of
// *     each element NN(j) specifies one size.
// *     The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *     if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *     Currently, the list of possible types is:
// *
// *     (1)  The zero matrix.
// *     (2)  The identity matrix.
// *     (3)  A (transposed) Jordan block, with 1's on the diagonal.
// *
// *     (4)  A diagonal matrix with evenly spaced entries
// *          1, ..., ULP  and random signs.
// *          (ULP = (first number larger than 1) - 1 )
// *     (5)  A diagonal matrix with geometrically spaced entries
// *          1, ..., ULP  and random signs.
// *     (6)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *          and random signs.
// *
// *     (7)  Same as (4), but multiplied by a constant near
// *          the overflow threshold
// *     (8)  Same as (4), but multiplied by a constant near
// *          the underflow threshold
// *
// *     (9)  A matrix of the form  U' T U, where U is orthogonal and
// *          T has evenly spaced entries 1, ..., ULP with random signs
// *          on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (10) A matrix of the form  U' T U, where U is orthogonal and
// *          T has geometrically spaced entries 1, ..., ULP with random
// *          signs on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (11) A matrix of the form  U' T U, where U is orthogonal and
// *          T has "clustered" entries 1, ULP,..., ULP with random
// *          signs on the diagonal and random O(1) entries in the upper
// *          triangle.
// *
// *     (12) A matrix of the form  U' T U, where U is orthogonal and
// *          T has real or complex conjugate paired eigenvalues randomly
// *          chosen from ( ULP, 1 ) and random O(1) entries in the upper
// *          triangle.
// *
// *     (13) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has evenly spaced entries 1, ..., ULP
// *          with random signs on the diagonal and random O(1) entries
// *          in the upper triangle.
// *
// *     (14) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has geometrically spaced entries
// *          1, ..., ULP with random signs on the diagonal and random
// *          O(1) entries in the upper triangle.
// *
// *     (15) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has "clustered" entries 1, ULP,..., ULP
// *          with random signs on the diagonal and random O(1) entries
// *          in the upper triangle.
// *
// *     (16) A matrix of the form  X' T X, where X has condition
// *          SQRT( ULP ) and T has real or complex conjugate paired
// *          eigenvalues randomly chosen from ( ULP, 1 ) and random
// *          O(1) entries in the upper triangle.
// *
// *     (17) Same as (16), but multiplied by a constant
// *          near the overflow threshold
// *     (18) Same as (16), but multiplied by a constant
// *          near the underflow threshold
// *
// *     (19) Nonsymmetric matrix with random entries chosen from (-1,1).
// *          If N is at least 4, all entries in first two rows and last
// *          row, and first column and last two columns are zero.
// *     (20) Same as (19), but multiplied by a constant
// *          near the overflow threshold
// *     (21) Same as (19), but multiplied by a constant
// *          near the underflow threshold
// *
// *  Arguments
// *  ==========
// *
// *  NSIZES  (input) INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DDRVEV does nothing.  It must be at least zero.
// *
// *  NN      (input) INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DDRVEV
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DDRVEV to continue the same random number
// *          sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns INFO not equal to 0.)
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.  On exit, A contains the last matrix actually used.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A, and H. LDA must be at
// *          least 1 and at least max(NN).
// *
// *  H       (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          Another copy of the test matrix A, modified by DGEEV.
// *
// *  WR      (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  WI      (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *          The real and imaginary parts of the eigenvalues of A.
// *          On exit, WR + WI*i are the eigenvalues of the matrix in A.
// *
// *  WR1     (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  WI1     (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *          Like WR, WI, these arrays contain the eigenvalues of A,
// *          but those computed when DGEEV only computes a partial
// *          eigendecomposition, i.e. not the eigenvalues and left
// *          and right eigenvectors.
// *
// *  VL      (workspace) DOUBLE PRECISION array, dimension (LDVL, max(NN))
// *          VL holds the computed left eigenvectors.
// *
// *  LDVL    (input) INTEGER
// *          Leading dimension of VL. Must be at least max(1,max(NN)).
// *
// *  VR      (workspace) DOUBLE PRECISION array, dimension (LDVR, max(NN))
// *          VR holds the computed right eigenvectors.
// *
// *  LDVR    (input) INTEGER
// *          Leading dimension of VR. Must be at least max(1,max(NN)).
// *
// *  LRE     (workspace) DOUBLE PRECISION array, dimension (LDLRE,max(NN))
// *          LRE holds the computed right or left eigenvectors.
// *
// *  LDLRE   (input) INTEGER
// *          Leading dimension of LRE. Must be at least max(1,max(NN)).
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (7)
// *          The values computed by the seven tests described above.
// *          The values are currently limited to 1/ulp, to avoid overflow.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (NWORK)
// *
// *  NWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          5*NN(j)+2*NN(j)**2 for all j.
// *
// *  IWORK   (workspace) INTEGER array, dimension (max(NN))
// *
// *  INFO    (output) INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some NN(j) < 0
// *           -3: NTYPES < 0
// *           -6: THRESH < 0
// *           -9: LDA < 1 or LDA < NMAX, where NMAX is max( NN(j) ).
// *          -16: LDVL < 1 or LDVL < NMAX, where NMAX is max( NN(j) ).
// *          -18: LDVR < 1 or LDVR < NMAX, where NMAX is max( NN(j) ).
// *          -20: LDLRE < 1 or LDLRE < NMAX, where NMAX is max( NN(j) ).
// *          -23: NWORK too small.
// *          If  DLATMR, SLATMS, SLATME or DGEEV returns an error code,
// *              the absolute value of it is returned.
// *
// *-----------------------------------------------------------------------
// *
// *     Some Local Variables and Parameters:
// *     ---- ----- --------- --- ----------
// *
// *     ZERO, ONE       Real 0 and 1.
// *     MAXTYP          The number of types defined.
// *     NMAX            Largest value in NN.
// *     NERRS           The number of tests which have exceeded THRESH
// *     COND, CONDS,
// *     IMODE           Values to be passed to the matrix generators.
// *     ANORM           Norm of A; passed to matrix generators.
// *
// *     OVFL, UNFL      Overflow and underflow thresholds.
// *     ULP, ULPINV     Finest relative precision and its inverse.
// *     RTULP, RTULPI   Square roots of the previous 4 values.
// *
// *             The following four arrays decode JTYPE:
// *     KTYPE(j)        The general type (1-10) for type "j".
// *     KMODE(j)        The MODE value to be passed to the matrix
// *                     generator for type "j".
// *     KMAGN(j)        The order of magnitude ( O(1),
// *                     O(overflow^(1/2) ), O(underflow^(1/2) )
// *     KCONDS(j)       Selectw whether CONDS is to be 1 or
// *                     1/sqrt(ulp).  (0 means irrelevant.)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static int maxtyp= 21;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static String path= new String("   ");
static intW iinfo= new intW(0);
static int imode= 0;
static int itype= 0;
static int iwk= 0;
static int j= 0;
static int jcol= 0;
static int jj= 0;
static int jsize= 0;
static int jtype= 0;
static int mtypes= 0;
static int n= 0;
static int nerrs= 0;
static int nfail= 0;
static int nmax= 0;
static int nnwork= 0;
static int ntest= 0;
static int ntestf= 0;
static int ntestt= 0;
static double anorm= 0.0;
static double cond= 0.0;
static double conds= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtulp= 0.0;
static double rtulpi= 0.0;
static double tnrm= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
static double vmx= 0.0;
static double vrmx= 0.0;
static double vtst= 0.0;
// *     ..
// *     .. Local Arrays ..
static String [] adumma= new String[(1)];
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
static double [] dum= new double[(1)];
static double [] res= new double[(2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 3 , 4, 4, 4, 4, 4 , 6, 6, 6, 6 , 6, 6, 6, 6, 6, 6 
, 9, 9, 9 };
static int [] kmagn = {1, 1, 1 
, 1 , 1 , 1 , 2 , 3 
, 1, 1, 1, 1 , 1 , 1 , 1 , 1 
, 2 , 3 , 1 , 2 , 3 
};
static int [] kmode = {0, 0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 5 , 4 
, 3 , 1 , 5 , 5 , 5 
, 4 , 3 , 1 };
static int [] kconds = {0, 0, 0 
, 0, 0, 0, 0, 0 , 1, 1, 1, 1 , 2, 2, 2, 2, 2, 2 , 0, 0, 0 };
// *     ..
// *     .. Executable Statements ..
// *

public static void ddrvev (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] h, int _h_offset,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] wr1, int _wr1_offset,
double [] wi1, int _wi1_offset,
double [] vl, int _vl_offset,
int ldvl,
double [] vr, int _vr_offset,
int ldvr,
double [] lre, int _lre_offset,
int ldlre,
double [] result, int _result_offset,
double [] work, int _work_offset,
int nwork,
int [] iwork, int _iwork_offset,
intW info)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "EV".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
// *
// *     Check for errors
// *
ntestt = 0;
ntestf = 0;
info.val = 0;
// *
// *     Important constants
// *
badnn = false;
nmax = 0;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Ddrvev",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (thresh < zero)  {
    info.val = -6;
}              // Close else if()
else if (nounit <= 0)  {
    info.val = -7;
}              // Close else if()
else if (lda < 1 || lda < nmax)  {
    info.val = -9;
}              // Close else if()
else if (ldvl < 1 || ldvl < nmax)  {
    info.val = -16;
}              // Close else if()
else if (ldvr < 1 || ldvr < nmax)  {
    info.val = -18;
}              // Close else if()
else if (ldlre < 1 || ldlre < nmax)  {
    info.val = -20;
}              // Close else if()
else if (5*nmax+2*Math.pow(nmax, 2) > nwork)  {
    info.val = -23;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DDRVEV",-info.val);
Dummy.go_to("Ddrvev",999999);
}              // Close if()
// *
// *     Quick return if nothing to do
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Ddrvev",999999);
// *
// *     More Important constants
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = one/unfl.val;
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Precision");
ulpinv = one/ulp;
rtulp = Math.sqrt(ulp);
rtulpi = one/rtulp;
// *
// *     Loop over sizes, types
// *
nerrs = 0;
// *
{
forloop270:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop260:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop260;
// *
// *           Save ISEED in case of an error.
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Ddrvev",20);
}              //  Close for() loop. 
}
// *
// *           Compute "A"
// *
// *           Control parameters:
// *
// *           KMAGN  KCONDS  KMODE        KTYPE
// *       =1  O(1)   1       clustered 1  zero
// *       =2  large  large   clustered 2  identity
// *       =3  small          exponential  Jordan
// *       =4                 arithmetic   diagonal, (w/ eigenvalues)
// *       =5                 random log   symmetric, w/ eigenvalues
// *       =6                 random       general, w/ eigenvalues
// *       =7                              random diagonal
// *       =8                              random symmetric
// *       =9                              random general
// *       =10                             random triangular
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Ddrvev",90);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Ddrvev",30);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Ddrvev",40);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Ddrvev",50);
// *
label30:
   Dummy.label("Ddrvev",30);
anorm = one;
Dummy.go_to("Ddrvev",60);
// *
label40:
   Dummy.label("Ddrvev",40);
anorm = ovfl.val*ulp;
Dummy.go_to("Ddrvev",60);
// *
label50:
   Dummy.label("Ddrvev",50);
anorm = unfl.val*ulpinv;
Dummy.go_to("Ddrvev",60);
// *
label60:
   Dummy.label("Ddrvev",60);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
cond = ulpinv;
// *
// *           Special Matrices -- Identity & Jordan block
// *
// *              Zero
// *
if (itype == 1)  {
    iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
{
forloop70:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Ddrvev",70);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 3)  {
    // *
// *              Jordan Block
// *
{
forloop80:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
if (jcol > 1)  
    a[(jcol)- 1+(jcol-1- 1)*lda+ _a_offset] = one;
Dummy.label("Ddrvev",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              Symmetric, eigenvalues specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 6)  {
    // *
// *              General, eigenvalues specified
// *
if (kconds[(jtype)- 1] == 1)  {
    conds = one;
}              // Close if()
else if (kconds[(jtype)- 1] == 2)  {
    conds = rtulpi;
}              // Close else if()
else  {
  conds = zero;
}              //  Close else.
// *
adumma[(1)- 1] = " ";
Dlatme.dlatme(n,"S",iseed,_iseed_offset,work,_work_offset,imode,cond,one,adumma,0,"T","T","T",work,(n+1)- 1+ _work_offset,4,conds,n,n,anorm,a,_a_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              Symmetric, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              General, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
if (n >= 4)  {
    Dlaset.dlaset("Full",2,n,zero,zero,a,_a_offset,lda);
Dlaset.dlaset("Full",n-3,1,zero,zero,a,(3)- 1+(1- 1)*lda+ _a_offset,lda);
Dlaset.dlaset("Full",n-3,2,zero,zero,a,(3)- 1+(n-1- 1)*lda+ _a_offset,lda);
Dlaset.dlaset("Full",1,n,zero,zero,a,(n)- 1+(1- 1)*lda+ _a_offset,lda);
}              // Close if()
// *
}              // Close else if()
else if (itype == 10)  {
    // *
// *              Triangular, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"N",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else  {
  // *
iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DDRVEV: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvev",999999);
}              // Close if()
// *
label90:
   Dummy.label("Ddrvev",90);
// *
// *           Test for minimal and generous workspace
// *
{
forloop250:
for (iwk = 1; iwk <= 2; iwk++) {
if (iwk == 1)  {
    nnwork = 4*n;
}              // Close if()
else  {
  nnwork = (int)(5*n+2*Math.pow(n, 2));
}              //  Close else.
nnwork = (int)(Math.max(nnwork, 1) );
// *
// *              Initialize RESULT
// *
{
forloop100:
for (j = 1; j <= 7; j++) {
result[(j)- 1+ _result_offset] = -one;
Dummy.label("Ddrvev",100);
}              //  Close for() loop. 
}
// *
// *              Compute eigenvalues and eigenvectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeev.dgeev("V","V",n,h,_h_offset,lda,wr,_wr_offset,wi,_wi_offset,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,work,_work_offset,nnwork,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DDRVEV: "  + ("DGEEV1") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvev",220);
}              // Close if()
// *
// *              Do Test (1)
// *
Dget22.dget22("N","N","N",n,a,_a_offset,lda,vr,_vr_offset,ldvr,wr,_wr_offset,wi,_wi_offset,work,_work_offset,res,0);
result[(1)- 1+ _result_offset] = res[(1)- 1];
// *
// *              Do Test (2)
// *
Dget22.dget22("T","N","T",n,a,_a_offset,lda,vl,_vl_offset,ldvl,wr,_wr_offset,wi,_wi_offset,work,_work_offset,res,0);
result[(2)- 1+ _result_offset] = res[(1)- 1];
// *
// *              Do Test (3)
// *
{
forloop120:
for (j = 1; j <= n; j++) {
tnrm = one;
if (wi[(j)- 1+ _wi_offset] == zero)  {
    tnrm = Dnrm2.dnrm2(n,vr,(1)- 1+(j- 1)*ldvr+ _vr_offset,1);
}              // Close if()
else if (wi[(j)- 1+ _wi_offset] > zero)  {
    tnrm = Dlapy2.dlapy2(Dnrm2.dnrm2(n,vr,(1)- 1+(j- 1)*ldvr+ _vr_offset,1),Dnrm2.dnrm2(n,vr,(1)- 1+(j+1- 1)*ldvr+ _vr_offset,1));
}              // Close else if()
result[(3)- 1+ _result_offset] = Math.max(result[(3)- 1+ _result_offset], Math.min(ulpinv, Math.abs(tnrm-one)/ulp) ) ;
if (wi[(j)- 1+ _wi_offset] > zero)  {
    vmx = zero;
vrmx = zero;
{
forloop110:
for (jj = 1; jj <= n; jj++) {
vtst = Dlapy2.dlapy2(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset],vr[(jj)- 1+(j+1- 1)*ldvr+ _vr_offset]);
if (vtst > vmx)  
    vmx = vtst;
if (vr[(jj)- 1+(j+1- 1)*ldvr+ _vr_offset] == zero && Math.abs(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset]) > vrmx)  
    vrmx = Math.abs(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset]);
Dummy.label("Ddrvev",110);
}              //  Close for() loop. 
}
if (vrmx/vmx < one-two*ulp)  
    result[(3)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Ddrvev",120);
}              //  Close for() loop. 
}
// *
// *              Do Test (4)
// *
{
forloop140:
for (j = 1; j <= n; j++) {
tnrm = one;
if (wi[(j)- 1+ _wi_offset] == zero)  {
    tnrm = Dnrm2.dnrm2(n,vl,(1)- 1+(j- 1)*ldvl+ _vl_offset,1);
}              // Close if()
else if (wi[(j)- 1+ _wi_offset] > zero)  {
    tnrm = Dlapy2.dlapy2(Dnrm2.dnrm2(n,vl,(1)- 1+(j- 1)*ldvl+ _vl_offset,1),Dnrm2.dnrm2(n,vl,(1)- 1+(j+1- 1)*ldvl+ _vl_offset,1));
}              // Close else if()
result[(4)- 1+ _result_offset] = Math.max(result[(4)- 1+ _result_offset], Math.min(ulpinv, Math.abs(tnrm-one)/ulp) ) ;
if (wi[(j)- 1+ _wi_offset] > zero)  {
    vmx = zero;
vrmx = zero;
{
forloop130:
for (jj = 1; jj <= n; jj++) {
vtst = Dlapy2.dlapy2(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset],vl[(jj)- 1+(j+1- 1)*ldvl+ _vl_offset]);
if (vtst > vmx)  
    vmx = vtst;
if (vl[(jj)- 1+(j+1- 1)*ldvl+ _vl_offset] == zero && Math.abs(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset]) > vrmx)  
    vrmx = Math.abs(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset]);
Dummy.label("Ddrvev",130);
}              //  Close for() loop. 
}
if (vrmx/vmx < one-two*ulp)  
    result[(4)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Ddrvev",140);
}              //  Close for() loop. 
}
// *
// *              Compute eigenvalues only, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeev.dgeev("N","N",n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,dum,0,1,dum,0,1,work,_work_offset,nnwork,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DDRVEV: "  + ("DGEEV2") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvev",220);
}              // Close if()
// *
// *              Do Test (5)
// *
{
forloop150:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Ddrvev",150);
}              //  Close for() loop. 
}
// *
// *              Compute eigenvalues and right eigenvectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeev.dgeev("N","V",n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,dum,0,1,lre,_lre_offset,ldlre,work,_work_offset,nnwork,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DDRVEV: "  + ("DGEEV3") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvev",220);
}              // Close if()
// *
// *              Do Test (5) again
// *
{
forloop160:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Ddrvev",160);
}              //  Close for() loop. 
}
// *
// *              Do Test (6)
// *
{
forloop180:
for (j = 1; j <= n; j++) {
{
forloop170:
for (jj = 1; jj <= n; jj++) {
if (vr[(j)- 1+(jj- 1)*ldvr+ _vr_offset] != lre[(j)- 1+(jj- 1)*ldlre+ _lre_offset])  
    result[(6)- 1+ _result_offset] = ulpinv;
Dummy.label("Ddrvev",170);
}              //  Close for() loop. 
}
Dummy.label("Ddrvev",180);
}              //  Close for() loop. 
}
// *
// *              Compute eigenvalues and left eigenvectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeev.dgeev("V","N",n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,lre,_lre_offset,ldlre,dum,0,1,work,_work_offset,nnwork,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DDRVEV: "  + ("DGEEV4") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvev",220);
}              // Close if()
// *
// *              Do Test (5) again
// *
{
forloop190:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Ddrvev",190);
}              //  Close for() loop. 
}
// *
// *              Do Test (7)
// *
{
forloop210:
for (j = 1; j <= n; j++) {
{
forloop200:
for (jj = 1; jj <= n; jj++) {
if (vl[(j)- 1+(jj- 1)*ldvl+ _vl_offset] != lre[(j)- 1+(jj- 1)*ldlre+ _lre_offset])  
    result[(7)- 1+ _result_offset] = ulpinv;
Dummy.label("Ddrvev",200);
}              //  Close for() loop. 
}
Dummy.label("Ddrvev",210);
}              //  Close for() loop. 
}
// *
// *              End of Loop -- Check for RESULT(j) > THRESH
// *
label220:
   Dummy.label("Ddrvev",220);
// *
ntest = 0;
nfail = 0;
{
forloop230:
for (j = 1; j <= 7; j++) {
if (result[(j)- 1+ _result_offset] >= zero)  
    ntest = ntest+1;
if (result[(j)- 1+ _result_offset] >= thresh)  
    nfail = nfail+1;
Dummy.label("Ddrvev",230);
}              //  Close for() loop. 
}
// *
if (nfail > 0)  
    ntestf = ntestf+1;
if (ntestf == 1)  {
    System.out.println("\n"  + " " + (path) + " "  + " -- Real Eigenvalue-Eigenvector Decomposition"  + " Driver"  + "\n"  + " Matrix types (see DDRVEV for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: geometr. spaced entries."  + "\n"  + "  2=Identity matrix.                    "  + "  6=Diagona"  + "l: clustered entries."  + "\n"  + "  3=Transposed Jordan block.  "  + "          "  + "  7=Diagonal: large, evenly spaced."  + "\n"  + "  "  + "4=Diagonal: evenly spaced entries.    "  + "  8=Diagonal: s"  + "mall, evenly spaced." );
System.out.println(" Dense, Non-Symmetric Matrices:"  + "\n"  + "  9=Well-cond., ev"  + "enly spaced eigenvals."  + " 14=Ill-cond., geomet. spaced e"  + "igenals."  + "\n"  + " 10=Well-cond., geom. spaced eigenvals. "  + " 15=Ill-conditioned, clustered e.vals."  + "\n"  + " 11=Well-cond"  + "itioned, clustered e.vals. "  + " 16=Ill-cond., random comp"  + "lex "  + "\n"  + " 12=Well-cond., random complex "  + "      " + "   "  + " 17=Ill-cond., large rand. complx "  + "\n"  + " 13=Ill-condi"  + "tioned, evenly spaced.     "  + " 18=Ill-cond., small rand."  + " complx " );
System.out.println(" 19=Matrix with random O(1) entries.    "  + " 21=Matrix "  + "with small random entries."  + "\n"  + " 20=Matrix with large ran"  + "dom entries.   "  + "\n" );
System.out.println(" Tests performed with test threshold ="  + (thresh) + " "  + "\n\n"  + " 1 = | A VR - VR W | / ( n |A| ulp ) "  + "\n"  + " 2 = | transpose(A) VL - VL W | / ( n |A| ulp ) "  + "\n"  + " 3 = | |VR(i)| - 1 | / ulp "  + "\n"  + " 4 = | |VL(i)| - 1 | / ulp "  + "\n"  + " 5 = 0 if W same no matter if VR or VL computed,"  + " 1/ulp otherwise"  + "\n"  + " 6 = 0 if VR same no matter if VL computed,"  + "  1/ulp otherwise"  + "\n"  + " 7 = 0 if VL same no matter if VR computed,"  + "  1/ulp otherwise"  + "\n" );
ntestf = 2;
}              // Close if()
// *
{
forloop240:
for (j = 1; j <= 7; j++) {
if (result[(j)- 1+ _result_offset] >= thresh)  {
    System.out.println(" N="  + (n) + " "  + ", IWK="  + (iwk) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (jtype) + " "  + ","  + (j) + " "  + ","  + (result[(j)- 1+ _result_offset]) + " "  + ","  + " type "  + " NULL " + " "  + ", test("  + " NULL " + " "  + ")="  + " NULL " + " " );
}              // Close if()
Dummy.label("Ddrvev",240);
}              //  Close for() loop. 
}
// *
nerrs = nerrs+nfail;
ntestt = ntestt+ntest;
// *
Dummy.label("Ddrvev",250);
}              //  Close for() loop. 
}
Dummy.label("Ddrvev",260);
}              //  Close for() loop. 
}
Dummy.label("Ddrvev",270);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Dlasum.dlasum(path,nounit,nerrs,ntestt);
// *
// *
// *
Dummy.go_to("Ddrvev",999999);
// *
// *     End of DDRVEV
// *
Dummy.label("Ddrvev",999999);
return;
   }
} // End class.
