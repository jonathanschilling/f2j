/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Ddrvgg {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVGG  checks the nonsymmetric generalized eigenvalue driver
// *  routines.
// *                                T          T        T
// *  DGEGS factors A and B as Q S Z  and Q T Z , where   means
// *  transpose, T is upper triangular, S is in generalized Schur form
// *  (block upper triangular, with 1x1 and 2x2 blocks on the diagonal,
// *  the 2x2 blocks corresponding to complex conjugate pairs of
// *  generalized eigenvalues), and Q and Z are orthogonal.  It also
// *  computes the generalized eigenvalues (alpha(1),beta(1)), ...,
// *  (alpha(n),beta(n)), where alpha(j)=S(j,j) and beta(j)=P(j,j) --
// *  thus, w(j) = alpha(j)/beta(j) is a root of the generalized
// *  eigenvalue problem
// *
// *      det( A - w(j) B ) = 0
// *
// *  and m(j) = beta(j)/alpha(j) is a root of the essentially equivalent
// *  problem
// *
// *      det( m(j) A - B ) = 0
// *
// *  DGEGV computes the generalized eigenvalues (alpha(1),beta(1)), ...,
// *  (alpha(n),beta(n)), the matrix L whose columns contain the
// *  generalized left eigenvectors l, and the matrix R whose columns
// *  contain the generalized right eigenvectors r for the pair (A,B).
// *
// *  When DDRVGG is called, a number of matrix "sizes" ("n's") and a
// *  number of matrix "types" are specified.  For each size ("n")
// *  and each type of matrix, one matrix will be generated and used
// *  to test the nonsymmetric eigenroutines.  For each matrix, 7
// *  tests will be performed and compared with the threshhold THRESH:
// *
// *  Results from DGEGS:
// *
// *                   T
// *  (1)   | A - Q S Z  | / ( |A| n ulp )
// *
// *                   T
// *  (2)   | B - Q T Z  | / ( |B| n ulp )
// *
// *                T
// *  (3)   | I - QQ  | / ( n ulp )
// *
// *                T
// *  (4)   | I - ZZ  | / ( n ulp )
// *
// *  (5)   maximum over j of D(j)  where:
// *
// *  if alpha(j) is real:
// *                      |alpha(j) - S(j,j)|        |beta(j) - T(j,j)|
// *            D(j) = ------------------------ + -----------------------
// *                   max(|alpha(j)|,|S(j,j)|)   max(|beta(j)|,|T(j,j)|)
// *
// *  if alpha(j) is complex:
// *                                  | det( s S - w T ) |
// *            D(j) = ---------------------------------------------------
// *                   ulp max( s norm(S), |w| norm(T) )*norm( s S - w T )
// *
// *            and S and T are here the 2 x 2 diagonal blocks of S and T
// *            corresponding to the j-th eigenvalue.
// *
// *  Results from DGEGV:
// *
// *  (6)   max over all left eigenvalue/-vector pairs (beta/alpha,l) of
// *
// *     | l**H * (beta A - alpha B) | / ( ulp max( |beta A|, |alpha B| ) )
// *
// *        where l**H is the conjugate tranpose of l.
// *
// *  (7)   max over all right eigenvalue/-vector pairs (beta/alpha,r) of
// *
// *        | (beta A - alpha B) r | / ( ulp max( |beta A|, |alpha B| ) )
// *
// *  Test Matrices
// *  ---- --------
// *
// *  The sizes of the test matrices are specified by an array
// *  NN(1:NSIZES); the value of each element NN(j) specifies one size.
// *  The "types" are specified by a logical array DOTYPE( 1:NTYPES ); if
// *  DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *  Currently, the list of possible types is:
// *
// *  (1)  ( 0, 0 )         (a pair of zero matrices)
// *
// *  (2)  ( I, 0 )         (an identity and a zero matrix)
// *
// *  (3)  ( 0, I )         (an identity and a zero matrix)
// *
// *  (4)  ( I, I )         (a pair of identity matrices)
// *
// *          t   t
// *  (5)  ( J , J  )       (a pair of transposed Jordan blocks)
// *
// *                                      t                ( I   0  )
// *  (6)  ( X, Y )         where  X = ( J   0  )  and Y = (      t )
// *                                   ( 0   I  )          ( 0   J  )
// *                        and I is a k x k identity and J a (k+1)x(k+1)
// *                        Jordan block; k=(N-1)/2
// *
// *  (7)  ( D, I )         where D is diag( 0, 1,..., N-1 ) (a diagonal
// *                        matrix with those diagonal entries.)
// *  (8)  ( I, D )
// *
// *  (9)  ( big*D, small*I ) where "big" is near overflow and small=1/big
// *
// *  (10) ( small*D, big*I )
// *
// *  (11) ( big*I, small*D )
// *
// *  (12) ( small*I, big*D )
// *
// *  (13) ( big*D, big*I )
// *
// *  (14) ( small*D, small*I )
// *
// *  (15) ( D1, D2 )        where D1 is diag( 0, 0, 1, ..., N-3, 0 ) and
// *                         D2 is diag( 0, N-3, N-4,..., 1, 0, 0 )
// *            t   t
// *  (16) Q ( J , J ) Z     where Q and Z are random orthogonal matrices.
// *
// *  (17) Q ( T1, T2 ) Z    where T1 and T2 are upper triangular matrices
// *                         with random O(1) entries above the diagonal
// *                         and diagonal entries diag(T1) =
// *                         ( 0, 0, 1, ..., N-3, 0 ) and diag(T2) =
// *                         ( 0, N-3, N-4,..., 1, 0, 0 )
// *
// *  (18) Q ( T1, T2 ) Z    diag(T1) = ( 0, 0, 1, 1, s, ..., s, 0 )
// *                         diag(T2) = ( 0, 1, 0, 1,..., 1, 0 )
// *                         s = machine precision.
// *
// *  (19) Q ( T1, T2 ) Z    diag(T1)=( 0,0,1,1, 1-d, ..., 1-(N-5)*d=s, 0 )
// *                         diag(T2) = ( 0, 1, 0, 1, ..., 1, 0 )
// *
// *                                                         N-5
// *  (20) Q ( T1, T2 ) Z    diag(T1)=( 0, 0, 1, 1, a, ..., a   =s, 0 )
// *                         diag(T2) = ( 0, 1, 0, 1, ..., 1, 0, 0 )
// *
// *  (21) Q ( T1, T2 ) Z    diag(T1)=( 0, 0, 1, r1, r2, ..., r(N-4), 0 )
// *                         diag(T2) = ( 0, 1, 0, 1, ..., 1, 0, 0 )
// *                         where r1,..., r(N-4) are random.
// *
// *  (22) Q ( big*T1, small*T2 ) Z    diag(T1) = ( 0, 0, 1, ..., N-3, 0 )
// *                                   diag(T2) = ( 0, 1, ..., 1, 0, 0 )
// *
// *  (23) Q ( small*T1, big*T2 ) Z    diag(T1) = ( 0, 0, 1, ..., N-3, 0 )
// *                                   diag(T2) = ( 0, 1, ..., 1, 0, 0 )
// *
// *  (24) Q ( small*T1, small*T2 ) Z  diag(T1) = ( 0, 0, 1, ..., N-3, 0 )
// *                                   diag(T2) = ( 0, 1, ..., 1, 0, 0 )
// *
// *  (25) Q ( big*T1, big*T2 ) Z      diag(T1) = ( 0, 0, 1, ..., N-3, 0 )
// *                                   diag(T2) = ( 0, 1, ..., 1, 0, 0 )
// *
// *  (26) Q ( T1, T2 ) Z     where T1 and T2 are random upper-triangular
// *                          matrices.
// *
// *  Arguments
// *  =========
// *
// *  NSIZES  (input) INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DDRVGG does nothing.  It must be at least zero.
// *
// *  NN      (input) INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *
// *  NTYPES  (input) INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DDRVGG
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DDRVGG to continue the same random number
// *          sequence.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error is
// *          scaled to be O(1), so THRESH should be a reasonably small
// *          multiple of 1, e.g., 10 or 100.  In particular, it should
// *          not depend on the precision (single vs. double) or the size
// *          of the matrix.  It must be at least zero.
// *
// *  THRSHN  (input) DOUBLE PRECISION
// *          Threshhold for reporting eigenvector normalization error.
// *          If the normalization of any eigenvector differs from 1 by
// *          more than THRSHN*ulp, then a special error message will be
// *          printed.  (This is handled separately from the other tests,
// *          since only a compiler or programming error should cause an
// *          error message, at least if THRSHN is at least 5--10.)
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *
// *  A       (input/workspace) DOUBLE PRECISION array, dimension
// *                            (LDA, max(NN))
// *          Used to hold the original A matrix.  Used as input only
// *          if NTYPES=MAXTYP+1, DOTYPE(1:MAXTYP)=.FALSE., and
// *          DOTYPE(MAXTYP+1)=.TRUE.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A, B, S, T, S2, and T2.
// *          It must be at least 1 and at least max( NN ).
// *
// *  B       (input/workspace) DOUBLE PRECISION array, dimension
// *                            (LDA, max(NN))
// *          Used to hold the original B matrix.  Used as input only
// *          if NTYPES=MAXTYP+1, DOTYPE(1:MAXTYP)=.FALSE., and
// *          DOTYPE(MAXTYP+1)=.TRUE.
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          The Schur form matrix computed from A by DGEGS.  On exit, S
// *          contains the Schur form matrix corresponding to the matrix
// *          in A.
// *
// *  T       (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          The upper triangular matrix computed from B by DGEGS.
// *
// *  S2      (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          The matrix computed from A by DGEGV.  This will be the
// *          Schur form of some matrix related to A, but will not, in
// *          general, be the same as S.
// *
// *  T2      (workspace) DOUBLE PRECISION array, dimension (LDA, max(NN))
// *          The matrix computed from B by DGEGV.  This will be the
// *          Schur form of some matrix related to B, but will not, in
// *          general, be the same as T.
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDQ, max(NN))
// *          The (left) orthogonal matrix computed by DGEGS.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of Q, Z, VL, and VR.  It must
// *          be at least 1 and at least max( NN ).
// *
// *  Z       (workspace) DOUBLE PRECISION array of
// *                             dimension( LDQ, max(NN) )
// *          The (right) orthogonal matrix computed by DGEGS.
// *
// *  ALPHR1  (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  ALPHI1  (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  BETA1   (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *
// *          The generalized eigenvalues of (A,B) computed by DGEGS.
// *          ( ALPHR1(k)+ALPHI1(k)*i ) / BETA1(k) is the k-th
// *          generalized eigenvalue of the matrices in A and B.
// *
// *  ALPHR2  (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  ALPHI2  (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *  BETA2   (workspace) DOUBLE PRECISION array, dimension (max(NN))
// *
// *          The generalized eigenvalues of (A,B) computed by DGEGV.
// *          ( ALPHR2(k)+ALPHI2(k)*i ) / BETA2(k) is the k-th
// *          generalized eigenvalue of the matrices in A and B.
// *
// *  VL      (workspace) DOUBLE PRECISION array, dimension (LDQ, max(NN))
// *          The (block lower triangular) left eigenvector matrix for
// *          the matrices in A and B.  (See DTGEVC for the format.)
// *
// *  VR      (workspace) DOUBLE PRECISION array, dimension (LDQ, max(NN))
// *          The (block upper triangular) right eigenvector matrix for
// *          the matrices in A and B.  (See DTGEVC for the format.)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          2*N + MAX( 6*N, N*(NB+1), (k+1)*(2*k+N+1) ), where
// *          "k" is the sum of the blocksize and number-of-shifts for
// *          DHGEQZ, and NB is the greatest of the blocksizes for
// *          DGEQRF, DORMQR, and DORGQR.  (The blocksizes and the
// *          number-of-shifts are retrieved through calls to ILAENV.)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (15)
// *          The values computed by the tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0:  if INFO = -i, the i-th argument had an illegal value.
// *          > 0:  A routine returned an error code.  INFO is the
// *                absolute value of the INFO value returned.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static int maxtyp= 26;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static boolean ilabad= false;
static int i1= 0;
static int iadd= 0;
static intW iinfo= new intW(0);
static int in= 0;
static int j= 0;
static int jc= 0;
static int jr= 0;
static int jsize= 0;
static int jtype= 0;
static int lwkopt= 0;
static int mtypes= 0;
static int n= 0;
static int n1= 0;
static int nb= 0;
static int nbz= 0;
static int nerrs= 0;
static int nmats= 0;
static int nmax= 0;
static int ns= 0;
static int ntest= 0;
static int ntestt= 0;
static doubleW safmax= new doubleW(0.0);
static doubleW safmin= new doubleW(0.0);
static double temp1= 0.0;
static doubleW temp2= new doubleW(0.0);
static double ulp= 0.0;
static double ulpinv= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] ioldsd= new int[(4)];
static double [] dumma= new double[(4)];
static double [] rmagn= new double[(3 - 0 + 1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] kclass = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 
, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 , 3 };
static int [] kz1 = {0 
, 1 , 2 , 1 , 3 , 3 
};
static int [] kz2 = {0 
, 0 , 1 , 2 , 1 , 1 
};
static int [] kadd = {0 
, 0 , 0 , 0 , 3 , 2 
};
static int [] katype = {0 
, 1 , 0 , 1 , 2 , 3 
, 4 , 1 , 4 , 4 , 1 
, 1 , 4 , 4 , 4 , 2 
, 4 , 5 , 8 , 7 , 9 
, 4, 4, 4, 4 , 0 };
static int [] kbtype = {0 
, 0 , 1 , 1 , 2 , -3 
, 1 , 4 , 1 , 1 , 4 
, 4 , 1 , 1 , -4 , 2 
, -4 , 8, 8, 8, 8, 8, 8, 8, 8 , 0 };
static int [] kazero = {1, 1, 1, 1, 1, 1 
, 2 , 1 , 2, 2 , 1, 1 , 2, 2 
, 3 , 1 , 3 , 5, 5, 5, 5 , 3, 3, 3, 3 
, 1 };
static int [] kbzero = {1, 1, 1, 1, 1, 1 
, 1 , 2 , 1, 1 , 2, 2 , 1, 1 
, 4 , 1 , 4 , 6, 6, 6, 6 , 4, 4, 4, 4 
, 1 };
static int [] kamagn = {1, 1, 1, 1, 1, 1, 1, 1 
, 2 , 3 , 2 , 3 , 2 
, 3 , 1, 1, 1, 1, 1, 1, 1 , 2 , 3 , 3 
, 2 , 1 };
static int [] kbmagn = {1, 1, 1, 1, 1, 1, 1, 1 
, 3 , 2 , 3 , 2 , 2 
, 3 , 1, 1, 1, 1, 1, 1, 1 , 3 , 2 , 3 
, 2 , 1 };
static int [] ktrian = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 
, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
static int [] iasign = {0, 0, 0, 0, 0, 0 
, 2 , 0 , 2, 2 , 0, 0 , 2, 2, 2 
, 0 , 2 , 0, 0, 0 , 2, 2, 2, 2, 2 , 0 
};
static int [] ibsign = {0, 0, 0, 0, 0, 0, 0 
, 2 , 0, 0 , 2, 2 , 0, 0 , 2 
, 0 , 2 , 0, 0, 0, 0, 0, 0, 0, 0, 0 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void ddrvgg (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
double thrshn,
int nounit,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
double [] s, int _s_offset,
double [] t, int _t_offset,
double [] s2, int _s2_offset,
double [] t2, int _t2_offset,
double [] q, int _q_offset,
int ldq,
double [] z, int _z_offset,
double [] alphr1, int _alphr1_offset,
double [] alphi1, int _alphi1_offset,
double [] beta1, int _beta1_offset,
double [] alphr2, int _alphr2_offset,
double [] alphi2, int _alphi2_offset,
double [] beta2, int _beta2_offset,
double [] vl, int _vl_offset,
double [] vr, int _vr_offset,
double [] work, int _work_offset,
int lwork,
double [] result, int _result_offset,
intW info)  {

info.val = 0;
// *
badnn = false;
nmax = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Ddrvgg",10);
}              //  Close for() loop. 
}
// *
// *     Maximum blocksize and shift -- we assume that blocksize and number
// *     of shifts are monotone increasing functions of N.
// *
nb = (int)(Math.max(Math.max(Math.max(1, Ilaenv.ilaenv(1,"DGEQRF"," ",nmax,nmax,-1,-1)), Ilaenv.ilaenv(1,"DORMQR","LT",nmax,nmax,nmax,-1)), Ilaenv.ilaenv(1,"DORGQR"," ",nmax,nmax,nmax,-1)) );
nbz = Ilaenv.ilaenv(1,"DHGEQZ","SII",nmax,1,nmax,0);
ns = Ilaenv.ilaenv(4,"DHGEQZ","SII",nmax,1,nmax,0);
i1 = nbz+ns;
lwkopt = (int)(2*nmax+Math.max((6*nmax) > (nmax*(nb+1)) ? (6*nmax) : (nmax*(nb+1)), (2*i1+nmax+1)*(i1+1)));
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (thresh < zero)  {
    info.val = -6;
}              // Close else if()
else if (lda <= 1 || lda < nmax)  {
    info.val = -10;
}              // Close else if()
else if (ldq <= 1 || ldq < nmax)  {
    info.val = -19;
}              // Close else if()
else if (lwkopt > lwork)  {
    info.val = -30;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DDRVGG",-info.val);
Dummy.go_to("Ddrvgg",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Ddrvgg",999999);
// *
safmin.val = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
safmin.val = safmin.val/ulp;
safmax.val = one/safmin.val;
Dlabad.dlabad(safmin,safmax);
ulpinv = one/ulp;
// *
// *     The values RMAGN(2:3) depend on N, see below.
// *
rmagn[(0)] = zero;
rmagn[(1)] = one;
// *
// *     Loop over sizes, types
// *
ntestt = 0;
nerrs = 0;
nmats = 0;
// *
{
forloop170:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
n1 = (int)(Math.max(1, n) );
rmagn[(2)] = safmax.val*ulp/(double)(n1);
rmagn[(3)] = safmin.val*ulpinv*n1;
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop160:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop160;
nmats = nmats+1;
ntest = 0;
// *
// *           Save ISEED in case of an error.
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Ddrvgg",20);
}              //  Close for() loop. 
}
// *
// *           Initialize RESULT
// *
{
forloop30:
for (j = 1; j <= 15; j++) {
result[(j)- 1+ _result_offset] = zero;
Dummy.label("Ddrvgg",30);
}              //  Close for() loop. 
}
// *
// *           Compute A and B
// *
// *           Description of control parameters:
// *
// *           KZLASS: =1 means w/o rotation, =2 means w/ rotation,
// *                   =3 means random.
// *           KATYPE: the "type" to be passed to DLATM4 for computing A.
// *           KAZERO: the pattern of zeros on the diagonal for A:
// *                   =1: ( xxx ), =2: (0, xxx ) =3: ( 0, 0, xxx, 0 ),
// *                   =4: ( 0, xxx, 0, 0 ), =5: ( 0, 0, 1, xxx, 0 ),
// *                   =6: ( 0, 1, 0, xxx, 0 ).  (xxx means a string of
// *                   non-zero entries.)
// *           KAMAGN: the magnitude of the matrix: =0: zero, =1: O(1),
// *                   =2: large, =3: small.
// *           IASIGN: 1 if the diagonal elements of A are to be
// *                   multiplied by a random magnitude 1 number, =2 if
// *                   randomly chosen diagonal blocks are to be rotated
// *                   to form 2x2 blocks.
// *           KBTYPE, KBZERO, KBMAGN, IBSIGN: the same, but for B.
// *           KTRIAN: =0: don't fill in the upper triangle, =1: do.
// *           KZ1, KZ2, KADD: used to implement KAZERO and KBZERO.
// *           RMAGN: used to implement KAMAGN and KBMAGN.
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Ddrvgg",110);
iinfo.val = 0;
if (kclass[(jtype)- 1] < 3)  {
    // *
// *              Generate A (w/o rotation)
// *
if (Math.abs(katype[(jtype)- 1]) == 3)  {
    in = 2*((n-1)/2)+1;
if (in != n)  
    Dlaset.dlaset("Full",n,n,zero,zero,a,_a_offset,lda);
}              // Close if()
else  {
  in = n;
}              //  Close else.
Dlatm4.dlatm4(katype[(jtype)- 1],in,kz1[(kazero[(jtype)- 1])- 1],kz2[(kazero[(jtype)- 1])- 1],iasign[(jtype)- 1],rmagn[(kamagn[(jtype)- 1])],ulp,rmagn[(ktrian[(jtype)- 1]*kamagn[(jtype)- 1])],2,iseed,_iseed_offset,a,_a_offset,lda);
iadd = kadd[(kazero[(jtype)- 1])- 1];
if (iadd > 0 && iadd <= n)  
    a[(iadd)- 1+(iadd- 1)*lda+ _a_offset] = one;
// *
// *              Generate B (w/o rotation)
// *
if (Math.abs(kbtype[(jtype)- 1]) == 3)  {
    in = 2*((n-1)/2)+1;
if (in != n)  
    Dlaset.dlaset("Full",n,n,zero,zero,b,_b_offset,lda);
}              // Close if()
else  {
  in = n;
}              //  Close else.
Dlatm4.dlatm4(kbtype[(jtype)- 1],in,kz1[(kbzero[(jtype)- 1])- 1],kz2[(kbzero[(jtype)- 1])- 1],ibsign[(jtype)- 1],rmagn[(kbmagn[(jtype)- 1])],one,rmagn[(ktrian[(jtype)- 1]*kbmagn[(jtype)- 1])],2,iseed,_iseed_offset,b,_b_offset,lda);
iadd = kadd[(kbzero[(jtype)- 1])- 1];
if (iadd != 0 && iadd <= n)  
    b[(iadd)- 1+(iadd- 1)*lda+ _b_offset] = one;
// *
if (kclass[(jtype)- 1] == 2 && n > 0)  {
    // *
// *                 Include rotations
// *
// *                 Generate Q, Z as Householder transformations times
// *                 a diagonal matrix.
// *
{
forloop50:
for (jc = 1; jc <= n-1; jc++) {
{
forloop40:
for (jr = jc; jr <= n; jr++) {
q[(jr)- 1+(jc- 1)*ldq+ _q_offset] = Dlarnd.dlarnd(3,iseed,_iseed_offset);
z[(jr)- 1+(jc- 1)*ldq+ _z_offset] = Dlarnd.dlarnd(3,iseed,_iseed_offset);
Dummy.label("Ddrvgg",40);
}              //  Close for() loop. 
}
dlarfg_adapter(n+1-jc,q,(jc)- 1+(jc- 1)*ldq+ _q_offset,q,(jc+1)- 1+(jc- 1)*ldq+ _q_offset,1,work,(jc)- 1+ _work_offset);
work[(2*n+jc)- 1+ _work_offset] = ((q[(jc)- 1+(jc- 1)*ldq+ _q_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
q[(jc)- 1+(jc- 1)*ldq+ _q_offset] = one;
dlarfg_adapter(n+1-jc,z,(jc)- 1+(jc- 1)*ldq+ _z_offset,z,(jc+1)- 1+(jc- 1)*ldq+ _z_offset,1,work,(n+jc)- 1+ _work_offset);
work[(3*n+jc)- 1+ _work_offset] = ((z[(jc)- 1+(jc- 1)*ldq+ _z_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
z[(jc)- 1+(jc- 1)*ldq+ _z_offset] = one;
Dummy.label("Ddrvgg",50);
}              //  Close for() loop. 
}
q[(n)- 1+(n- 1)*ldq+ _q_offset] = one;
work[(n)- 1+ _work_offset] = zero;
work[(3*n)- 1+ _work_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
z[(n)- 1+(n- 1)*ldq+ _z_offset] = one;
work[(2*n)- 1+ _work_offset] = zero;
work[(4*n)- 1+ _work_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
// *
// *                 Apply the diagonal matrices
// *
{
forloop70:
for (jc = 1; jc <= n; jc++) {
{
forloop60:
for (jr = 1; jr <= n; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = work[(2*n+jr)- 1+ _work_offset]*work[(3*n+jc)- 1+ _work_offset]*a[(jr)- 1+(jc- 1)*lda+ _a_offset];
b[(jr)- 1+(jc- 1)*lda+ _b_offset] = work[(2*n+jr)- 1+ _work_offset]*work[(3*n+jc)- 1+ _work_offset]*b[(jr)- 1+(jc- 1)*lda+ _b_offset];
Dummy.label("Ddrvgg",60);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgg",70);
}              //  Close for() loop. 
}
Dorm2r.dorm2r("L","N",n,n,n-1,q,_q_offset,ldq,work,_work_offset,a,_a_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  
    Dummy.go_to("Ddrvgg",100);
Dorm2r.dorm2r("R","T",n,n,n-1,z,_z_offset,ldq,work,(n+1)- 1+ _work_offset,a,_a_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  
    Dummy.go_to("Ddrvgg",100);
Dorm2r.dorm2r("L","N",n,n,n-1,q,_q_offset,ldq,work,_work_offset,b,_b_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  
    Dummy.go_to("Ddrvgg",100);
Dorm2r.dorm2r("R","T",n,n,n-1,z,_z_offset,ldq,work,(n+1)- 1+ _work_offset,b,_b_offset,lda,work,(2*n+1)- 1+ _work_offset,iinfo);
if (iinfo.val != 0)  
    Dummy.go_to("Ddrvgg",100);
}              // Close if()
}              // Close if()
else  {
  // *
// *              Random matrices
// *
{
forloop90:
for (jc = 1; jc <= n; jc++) {
{
forloop80:
for (jr = 1; jr <= n; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = rmagn[(kamagn[(jtype)- 1])]*Dlarnd.dlarnd(2,iseed,_iseed_offset);
b[(jr)- 1+(jc- 1)*lda+ _b_offset] = rmagn[(kbmagn[(jtype)- 1])]*Dlarnd.dlarnd(2,iseed,_iseed_offset);
Dummy.label("Ddrvgg",80);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgg",90);
}              //  Close for() loop. 
}
}              //  Close else.
// *
label100:
   Dummy.label("Ddrvgg",100);
// *
if (iinfo.val != 0)  {
    System.out.println(" DDRVGG: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvgg",999999);
}              // Close if()
// *
label110:
   Dummy.label("Ddrvgg",110);
// *
// *           Call DGEGS to compute H, T, Q, Z, alpha, and beta.
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,s,_s_offset,lda);
Dlacpy.dlacpy(" ",n,n,b,_b_offset,lda,t,_t_offset,lda);
ntest = 1;
result[(1)- 1+ _result_offset] = ulpinv;
// *
Dgegs.dgegs("V","V",n,s,_s_offset,lda,t,_t_offset,lda,alphr1,_alphr1_offset,alphi1,_alphi1_offset,beta1,_beta1_offset,q,_q_offset,ldq,z,_z_offset,ldq,work,_work_offset,lwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVGG: "  + ("DGEGS") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvgg",140);
}              // Close if()
// *
ntest = 4;
// *
// *           Do tests 1--4
// *
dget51_adapter(1,n,a,_a_offset,lda,s,_s_offset,lda,q,_q_offset,ldq,z,_z_offset,ldq,work,_work_offset,result,(1)- 1+ _result_offset);
dget51_adapter(1,n,b,_b_offset,lda,t,_t_offset,lda,q,_q_offset,ldq,z,_z_offset,ldq,work,_work_offset,result,(2)- 1+ _result_offset);
dget51_adapter(3,n,b,_b_offset,lda,t,_t_offset,lda,q,_q_offset,ldq,q,_q_offset,ldq,work,_work_offset,result,(3)- 1+ _result_offset);
dget51_adapter(3,n,b,_b_offset,lda,t,_t_offset,lda,z,_z_offset,ldq,z,_z_offset,ldq,work,_work_offset,result,(4)- 1+ _result_offset);
// *
// *           Do test 5: compare eigenvalues with diagonals.
// *           Also check Schur form of A.
// *
temp1 = zero;
// *
{
forloop120:
for (j = 1; j <= n; j++) {
ilabad = false;
if (alphi1[(j)- 1+ _alphi1_offset] == zero)  {
    temp2.val = (Math.abs(alphr1[(j)- 1+ _alphr1_offset]-s[(j)- 1+(j- 1)*lda+ _s_offset])/Math.max((safmin.val) > (Math.abs(alphr1[(j)- 1+ _alphr1_offset])) ? (safmin.val) : (Math.abs(alphr1[(j)- 1+ _alphr1_offset])), Math.abs(s[(j)- 1+(j- 1)*lda+ _s_offset]))+Math.abs(beta1[(j)- 1+ _beta1_offset]-t[(j)- 1+(j- 1)*lda+ _t_offset])/Math.max((safmin.val) > (Math.abs(beta1[(j)- 1+ _beta1_offset])) ? (safmin.val) : (Math.abs(beta1[(j)- 1+ _beta1_offset])), Math.abs(t[(j)- 1+(j- 1)*lda+ _t_offset])))/ulp;
if (j < n)  {
    if (s[(j+1)- 1+(j- 1)*lda+ _s_offset] != zero)  
    ilabad = true;
}              // Close if()
if (j > 1)  {
    if (s[(j)- 1+(j-1- 1)*lda+ _s_offset] != zero)  
    ilabad = true;
}              // Close if()
}              // Close if()
else  {
  if (alphi1[(j)- 1+ _alphi1_offset] > zero)  {
    i1 = j;
}              // Close if()
else  {
  i1 = j-1;
}              //  Close else.
if (i1 <= 0 || i1 >= n)  {
    ilabad = true;
}              // Close if()
else if (i1 < n-1)  {
    if (s[(i1+2)- 1+(i1+1- 1)*lda+ _s_offset] != zero)  
    ilabad = true;
}              // Close else if()
else if (i1 > 1)  {
    if (s[(i1)- 1+(i1-1- 1)*lda+ _s_offset] != zero)  
    ilabad = true;
}              // Close else if()
if (!ilabad)  {
    Dget53.dget53(s,(i1)- 1+(i1- 1)*lda+ _s_offset,lda,t,(i1)- 1+(i1- 1)*lda+ _t_offset,lda,beta1[(j)- 1+ _beta1_offset],alphr1[(j)- 1+ _alphr1_offset],alphi1[(j)- 1+ _alphi1_offset],temp2,iinfo);
if (iinfo.val >= 3)  {
    System.out.println(" DDRVGG: DGET53 returned INFO="  + (iinfo.val) + " "  + " for eigenvalue "  + (j) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
}              // Close if()
}              // Close if()
else  {
  temp2.val = ulpinv;
}              //  Close else.
}              //  Close else.
temp1 = Math.max(temp1, temp2.val) ;
if (ilabad)  {
    System.out.println(" DDRVGG: S not in Schur form at eigenvalue "  + (j) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
Dummy.label("Ddrvgg",120);
}              //  Close for() loop. 
}
result[(5)- 1+ _result_offset] = temp1;
// *
// *           Call DGEGV to compute S2, T2, VL, and VR, do tests.
// *
// *           Eigenvalues and Eigenvectors
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,s2,_s2_offset,lda);
Dlacpy.dlacpy(" ",n,n,b,_b_offset,lda,t2,_t2_offset,lda);
ntest = 6;
result[(6)- 1+ _result_offset] = ulpinv;
// *
Dgegv.dgegv("V","V",n,s2,_s2_offset,lda,t2,_t2_offset,lda,alphr2,_alphr2_offset,alphi2,_alphi2_offset,beta2,_beta2_offset,vl,_vl_offset,ldq,vr,_vr_offset,ldq,work,_work_offset,lwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVGG: "  + ("DGEGV") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvgg",140);
}              // Close if()
// *
ntest = 7;
// *
// *           Do Tests 6 and 7
// *
Dget52.dget52(true,n,a,_a_offset,lda,b,_b_offset,lda,vl,_vl_offset,ldq,alphr2,_alphr2_offset,alphi2,_alphi2_offset,beta2,_beta2_offset,work,_work_offset,dumma,(1)- 1);
result[(6)- 1+ _result_offset] = dumma[(1)- 1];
if (dumma[(2)- 1] > thrshn)  {
    System.out.println(" DDRVGG: "  + ("Left") + " "  + " Eigenvectors from "  + ("DGEGV") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(2)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
// *
Dget52.dget52(false,n,a,_a_offset,lda,b,_b_offset,lda,vr,_vr_offset,ldq,alphr2,_alphr2_offset,alphi2,_alphi2_offset,beta2,_beta2_offset,work,_work_offset,dumma,(1)- 1);
result[(7)- 1+ _result_offset] = dumma[(1)- 1];
if (dumma[(2)- 1] > thresh)  {
    System.out.println(" DDRVGG: "  + ("Right") + " "  + " Eigenvectors from "  + ("DGEGV") + " "  + " incorrectly "  + "normalized."  + "\n"  + " Bits of error="  + (dumma[(2)- 1]) + " "  + ","  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
// *
// *           Check form of Complex eigenvalues.
// *
{
forloop130:
for (j = 1; j <= n; j++) {
ilabad = false;
if (alphi2[(j)- 1+ _alphi2_offset] > zero)  {
    if (j == n)  {
    ilabad = true;
}              // Close if()
else if (alphi2[(j+1)- 1+ _alphi2_offset] >= zero)  {
    ilabad = true;
}              // Close else if()
}              // Close if()
else if (alphi2[(j)- 1+ _alphi2_offset] < zero)  {
    if (j == 1)  {
    ilabad = true;
}              // Close if()
else if (alphi2[(j-1)- 1+ _alphi2_offset] <= zero)  {
    ilabad = true;
}              // Close else if()
}              // Close else if()
if (ilabad)  {
    System.out.println(" DDRVGG: S not in Schur form at eigenvalue "  + (j) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
Dummy.label("Ddrvgg",130);
}              //  Close for() loop. 
}
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
label140:
   Dummy.label("Ddrvgg",140);
// *
ntestt = ntestt+ntest;
// *
// *           Print out tests which fail.
// *
{
forloop150:
for (jr = 1; jr <= ntest; jr++) {
if (result[(jr)- 1+ _result_offset] >= thresh)  {
    // *
// *                 If this is the first test to fail,
// *                 print a header to the data file.
// *
if (nerrs == 0)  {
    System.out.println("\n"  + " " + ("DGG") + " "  + " -- Real Generalized eigenvalue problem driver" );
// *
// *                    Matrix types
// *
System.out.println(" Matrix types (see DDRVGG for details): " );
System.out.println(" Special Matrices:"  + "                       " + "(J\'=transposed Jordan block)"  + "\n"  + "   1=(0,0)  2=(I,0)  3=(0,I)  4=(I,I)  5=(J\',J\')  "  + "6=(diag(J\',I), diag(I,J\'))"  + "\n"  + " Diagonal Matrices:  ( "  + "D=diag(0,1,2,...) )"  + "\n"  + "   7=(D,I)   9=(large*D, small*I"  + ")  11=(large*I, small*D)  13=(large*D, large*I)"  + "\n"  + "   8=(I,D)  10=(small*D, large*I)  12=(small*I, large*D) "  + " 14=(small*D, small*I)"  + "\n"  + "  15=(D, reversed D)" );
System.out.println(" Matrices Rotated by Random "  + ("Orthogonal") + " "  + " Matrices U, V:"  + "\n"  + "  16=Transposed Jordan Blocks             19=geometric "  + "alpha, beta=0,1"  + "\n"  + "  17=arithm. alpha&beta             "  + "      20=arithmetic alpha, beta=0,1"  + "\n"  + "  18=clustered "  + "alpha, beta=0,1            21=random alpha, beta=0,1"  + "\n"  + " Large & Small Matrices:"  + "\n"  + "  22=(large, small)   "  + "23=(small,large)    24=(small,small)    25=(large,large)"  + "\n"  + "  26=random O(1) matrices." );
// *
// *                    Tests performed
// *
System.out.print(("orthogonal") + " " + ("\'") + " " + ("transpose") + " ");
for(j = 1; j <= 5; j++)
  System.out.print(" ");

System.out.println();
// *
}              // Close if()
nerrs = nerrs+1;
if (result[(jr)- 1+ _result_offset] < 10000.0e0)  {
    System.out.println(" Matrix order="  + (n) + " "  + ", type="  + (jtype) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (jr) + " "  + ","  + (result[(jr)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ","  + " result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              // Close if()
else  {
  System.out.println(" Matrix order="  + (n) + " "  + ", type="  + (jtype) + " "  + ", seed="  + (ioldsd) + " "  + ","  + (jr) + " "  + ","  + (result[(jr)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ","  + " result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              //  Close else.
}              // Close if()
Dummy.label("Ddrvgg",150);
}              //  Close for() loop. 
}
// *
Dummy.label("Ddrvgg",160);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgg",170);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Alasvm.alasvm("DGG",nounit,nerrs,ntestt,0);
Dummy.go_to("Ddrvgg",999999);
// *
// *
// *
// *
// *
// *
// *
// *
// *
// *
// *     End of DDRVGG
// *
Dummy.label("Ddrvgg",999999);
return;
   }
// adapter for dlarfg
private static void dlarfg_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset )
{
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp4 = new doubleW(arg4[arg4_offset]);

Dlarfg.dlarfg(arg0,_f2j_tmp1,arg2, arg2_offset,arg3,_f2j_tmp4);

arg1[arg1_offset] = _f2j_tmp1.val;
arg4[arg4_offset] = _f2j_tmp4.val;
}

// adapter for dget51
private static void dget51_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dget51.dget51(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

} // End class.
