/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Ddrvsg {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *       DDRVSG checks the real symmetric generalized eigenproblem
// *       drivers.
// *
// *               DSYGV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric-definite generalized
// *               eigenproblem.
// *
// *               DSPGV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric-definite generalized
// *               eigenproblem in packed storage.
// *
// *               DSBGV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric-definite banded
// *               generalized eigenproblem.
// *
// *       When DDRVSG is called, a number of matrix "sizes" ("n's") and a
// *       number of matrix "types" are specified.  For each size ("n")
// *       and each type of matrix, one matrix A of the given type will be
// *       generated; a random well-conditioned matrix B is also generated
// *       and the pair (A,B) is used to test the drivers.
// *
// *       For each pair (A,B), the following tests are performed:
// *
// *       (1) DSYGV with ITYPE = 1 and UPLO ='U':
// *
// *               | A Z - B Z D | / ( |A| |Z| n ulp )
// *
// *       (2) as (1) but calling DSPGV
// *       (3) as (1) but calling DSBGV
// *       (4) as (1) but with UPLO = 'L'
// *       (5) as (4) but calling DSPGV
// *       (6) as (4) but calling DSBGV
// *
// *       (7) DSYGV with ITYPE = 2 and UPLO ='U':
// *
// *               | A B Z - Z D | / ( |A| |Z| n ulp )
// *
// *       (8) as (7) but calling DSPGV
// *       (9) as (7) but with UPLO = 'L'
// *       (10) as (9) but calling DSPGV
// *
// *       (11) DSYGV with ITYPE = 3 and UPLO ='U':
// *
// *               | B A Z - Z D | / ( |A| |Z| n ulp )
// *
// *       (12) as (11) but calling DSPGV
// *       (13) as (11) but with UPLO = 'L'
// *       (14) as (13) but calling DSPGV
// *
// *       The "sizes" are specified by an array NN(1:NSIZES); the value of
// *       each element NN(j) specifies one size.
// *       The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *       if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *       This type is used for the matrix A which has half-bandwidth KA.
// *       B is generated as a well-conditioned positive definite matrix
// *       with half-bandwidth KB (<= KA).
// *       Currently, the list of possible types for A is:
// *
// *       (1)  The zero matrix.
// *       (2)  The identity matrix.
// *
// *       (3)  A diagonal matrix with evenly spaced entries
// *            1, ..., ULP  and random signs.
// *            (ULP = (first number larger than 1) - 1 )
// *       (4)  A diagonal matrix with geometrically spaced entries
// *            1, ..., ULP  and random signs.
// *       (5)  A diagonal matrix with "clustered" entries 1, ULP, ..., ULP
// *            and random signs.
// *
// *       (6)  Same as (4), but multiplied by SQRT( overflow threshold )
// *       (7)  Same as (4), but multiplied by SQRT( underflow threshold )
// *
// *       (8)  A matrix of the form  U* D U, where U is orthogonal and
// *            D has evenly spaced entries 1, ..., ULP with random signs
// *            on the diagonal.
// *
// *       (9)  A matrix of the form  U* D U, where U is orthogonal and
// *            D has geometrically spaced entries 1, ..., ULP with random
// *            signs on the diagonal.
// *
// *       (10) A matrix of the form  U* D U, where U is orthogonal and
// *            D has "clustered" entries 1, ULP,..., ULP with random
// *            signs on the diagonal.
// *
// *       (11) Same as (8), but multiplied by SQRT( overflow threshold )
// *       (12) Same as (8), but multiplied by SQRT( underflow threshold )
// *
// *       (13) symmetric matrix with random entries chosen from (-1,1).
// *       (14) Same as (13), but multiplied by SQRT( overflow threshold )
// *       (15) Same as (13), but multiplied by SQRT( underflow threshold )
// *
// *       (16) Same as (8), but with KA = 1 and KB = 1
// *       (17) Same as (8), but with KA = 2 and KB = 1
// *       (18) Same as (8), but with KA = 2 and KB = 2
// *       (19) Same as (8), but with KA = 3 and KB = 1
// *       (20) Same as (8), but with KA = 3 and KB = 2
// *       (21) Same as (8), but with KA = 3 and KB = 3
// *
// *  Arguments
// *  =========
// *
// *  NSIZES  INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DDRVSG does nothing.  It must be at least zero.
// *          Not modified.
// *
// *  NN      INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *          Not modified.
// *
// *  NTYPES  INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DDRVSG
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *          Not modified.
// *
// *  DOTYPE  LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *          Not modified.
// *
// *  ISEED   INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DDRVSG to continue the same random number
// *          sequence.
// *          Modified.
// *
// *  THRESH  DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *          Not modified.
// *
// *  NOUNIT  INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *          Not modified.
// *
// *  A       DOUBLE PRECISION array, dimension (LDA , max(NN))
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.  On exit, A contains the last matrix actually
// *          used.
// *          Modified.
// *
// *  LDA     INTEGER
// *          The leading dimension of A.  It must be at
// *          least 1 and at least max( NN ).
// *          Not modified.
// *
// *  B       DOUBLE PRECISION array, dimension (LDB , max(NN))
// *          Used to hold the symmetric positive definite matrix for
// *          the generailzed problem.
// *          On exit, B contains the last matrix actually
// *          used.
// *          Modified.
// *
// *  LDB     INTEGER
// *          The leading dimension of B.  It must be at
// *          least 1 and at least max( NN ).
// *          Not modified.
// *
// *  D       DOUBLE PRECISION array, dimension (max(NN))
// *          The eigenvalues of A. On exit, the eigenvalues in D
// *          correspond with the matrix in A.
// *          Modified.
// *
// *  U       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          Workspace.
// *          Modified.
// *
// *  LDU     INTEGER
// *          The leading dimension of U, BB, V, Z and UZ.  It must be at
// *          least 1 and at least max( NN ).
// *          Not modified.
// *
// *  BB      DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          Workspace.
// *          Modified.
// *
// *  V       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          Workspace.
// *          Modified.
// *
// *  Z       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          The matrix of eigenvectors.
// *          Modified.
// *
// *  UZ      DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          Workspace.
// *          Modified.
// *
// *  WORK    DOUBLE PRECISION array, dimension (NWORK)
// *          Workspace.
// *          Modified.
// *
// *  NWORK   INTEGER
// *          The number of entries in WORK.  This must be at least
// *          2*max( NN(j), 3 )**2.
// *          Not modified.
// *
// *  IWORK   INTEGER array, dimension (max(NN))
// *          Workspace.
// *          Modified.
// *
// *  RESULT  DOUBLE PRECISION array, dimension (14)
// *          The values computed by the 14 tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *          Modified.
// *
// *  INFO    INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some NN(j) < 0
// *           -3: NTYPES < 0
// *           -5: THRESH < 0
// *           -9: LDA < 1 or LDA < NMAX, where NMAX is max( NN(j) ).
// *          -16: LDU < 1 or LDU < NMAX.
// *          -21: NWORK too small.
// *          If  DLATMR, SLATMS, DSYGV, DSPGV or DSBGV
// *              returns an error code, the
// *              absolute value of it is returned.
// *          Modified.
// *
// *-----------------------------------------------------------------------
// *
// *       Some Local Variables and Parameters:
// *       ---- ----- --------- --- ----------
// *       ZERO, ONE       Real 0 and 1.
// *       MAXTYP          The number of types defined.
// *       NTEST           The number of tests that have been run
// *                       on this matrix.
// *       NTESTT          The total number of tests for this call.
// *       NMAX            Largest value in NN.
// *       NMATS           The number of matrices generated so far.
// *       NERRS           The number of tests which have exceeded THRESH
// *                       so far (computed by DLAFTS).
// *       COND, IMODE     Values to be passed to the matrix generators.
// *       ANORM           Norm of A; passed to matrix generators.
// *
// *       OVFL, UNFL      Overflow and underflow thresholds.
// *       ULP, ULPINV     Finest relative precision and its inverse.
// *       RTOVFL, RTUNFL  Square roots of the previous 2 values.
// *               The following four arrays decode JTYPE:
// *       KTYPE(j)        The general type (1-10) for type "j".
// *       KMODE(j)        The MODE value to be passed to the matrix
// *                       generator for type "j".
// *       KMAGN(j)        The order of magnitude ( O(1),
// *                       O(overflow^(1/2) ), O(underflow^(1/2) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double ten= 10.0e0;
static int maxtyp= 21;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static String uplo= new String(" ");
static int i= 0;
static int ibtype= 0;
static int ibuplo= 0;
static intW iinfo= new intW(0);
static int ij= 0;
static int imode= 0;
static int itype= 0;
static int j= 0;
static int jcol= 0;
static int jsize= 0;
static int jtype= 0;
static int ka= 0;
static int ka9= 0;
static int kb= 0;
static int kb9= 0;
static int mtypes= 0;
static int n= 0;
static intW nerrs= new intW(0);
static int nmats= 0;
static int nmax= 0;
static int ntest= 0;
static int ntestt= 0;
static double aninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtovfl= 0.0;
static double rtunfl= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 4, 4, 4, 4, 4 , 5, 5, 5, 5, 5 , 8, 8, 8 , 9, 9, 9, 9, 9, 9 
};
static int [] kmagn = {1, 1 
, 1 , 1 , 1 , 2 , 3 
, 1 , 1 , 1 , 2 , 3 
, 1 , 2 , 3 , 1, 1, 1, 1, 1, 1 };
static int [] kmode = {0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 4 , 4 
, 0 , 0 , 0 , 4, 4, 4, 4, 4, 4 };
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Check for errors
// *

public static void ddrvsg (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] d, int _d_offset,
double [] u, int _u_offset,
int ldu,
double [] bb, int _bb_offset,
double [] v, int _v_offset,
double [] z, int _z_offset,
double [] uz, int _uz_offset,
double [] work, int _work_offset,
int nwork,
int [] iwork, int _iwork_offset,
double [] result, int _result_offset,
intW info)  {

ntestt = 0;
info.val = 0;
// *
badnn = false;
nmax = 0;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Ddrvsg",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda <= 1 || lda < nmax)  {
    info.val = -9;
}              // Close else if()
else if (ldu <= 1 || ldu < nmax)  {
    info.val = -16;
}              // Close else if()
else if (2*Math.pow(Math.max(nmax, 3) , 2) > nwork)  {
    info.val = -21;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DDRVSG",-info.val);
Dummy.go_to("Ddrvsg",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Ddrvsg",999999);
// *
// *     More Important constants
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = Dlamch.dlamch("Overflow");
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
ulpinv = one/ulp;
rtunfl = Math.sqrt(unfl.val);
rtovfl = Math.sqrt(ovfl.val);
// *
// *     Loop over sizes, types
// *
nerrs.val = 0;
nmats = 0;
// *
{
forloop240:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
aninv = one/(double)(Math.max(1, n) );
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
ka9 = 0;
kb9 = 0;
{
forloop230:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop230;
nmats = nmats+1;
ntest = 0;
// *
{
forloop20:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Ddrvsg",20);
}              //  Close for() loop. 
}
// *
// *           2)      Compute "A"
// *
// *                   Control parameters:
// *
// *               KMAGN  KMODE        KTYPE
// *           =1  O(1)   clustered 1  zero
// *           =2  large  clustered 2  identity
// *           =3  small  exponential  (none)
// *           =4         arithmetic   diagonal, w/ eigenvalues
// *           =5         random log   hermitian, w/ eigenvalues
// *           =6         random       (none)
// *           =7                      random diagonal
// *           =8                      random hermitian
// *           =9                      banded, w/ eigenvalues
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Ddrvsg",80);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Ddrvsg",30);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Ddrvsg",40);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Ddrvsg",50);
// *
label30:
   Dummy.label("Ddrvsg",30);
anorm = one;
Dummy.go_to("Ddrvsg",60);
// *
label40:
   Dummy.label("Ddrvsg",40);
anorm = (rtovfl*ulp)*aninv;
Dummy.go_to("Ddrvsg",60);
// *
label50:
   Dummy.label("Ddrvsg",50);
anorm = rtunfl*n*ulpinv;
Dummy.go_to("Ddrvsg",60);
// *
label60:
   Dummy.label("Ddrvsg",60);
// *
iinfo.val = 0;
cond = ulpinv;
// *
// *           Special Matrices -- Identity & Jordan block
// *
if (itype == 1)  {
    // *
// *              Zero
// *
ka = 0;
kb = 0;
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
ka = 0;
kb = 0;
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
{
forloop70:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Ddrvsg",70);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
ka = 0;
kb = 0;
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              symmetric, eigenvalues specified
// *
ka = (int)(Math.max(0, n-1) );
kb = ka;
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random eigenvalues
// *
ka = 0;
kb = 0;
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              symmetric, random eigenvalues
// *
ka = (int)(Math.max(0, n-1) );
kb = ka;
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"H",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              symmetric banded, eigenvalues specified
// *
// *              The following values are used for the half-bandwidths:
// *
// *                ka = 1   kb = 1
// *                ka = 2   kb = 1
// *                ka = 2   kb = 2
// *                ka = 3   kb = 1
// *                ka = 3   kb = 2
// *                ka = 3   kb = 3
// *
kb9 = kb9+1;
if (kb9 > ka9)  {
    ka9 = ka9+1;
kb9 = 1;
}              // Close if()
ka = (int)(Math.max(0, Math.min(n-1, ka9) ) );
kb = (int)(Math.max(0, Math.min(n-1, kb9) ) );
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,ka,ka,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else  {
  // *
iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DDRVSG: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvsg",999999);
}              // Close if()
// *
label80:
   Dummy.label("Ddrvsg",80);
// *
// *           3) Call DSYGV, DSPGV and DSBGV to compute S and U, do tests.
// *
// *               loop over the three generalized problems
// *                 IBTYPE = 1: A*x = (lambda)*B*x
// *                 IBTYPE = 2: A*B*x = (lambda)*x
// *                 IBTYPE = 3: B*A*x = (lambda)*x
// *
{
forloop220:
for (ibtype = 1; ibtype <= 3; ibtype++) {
// *
// *              loop over the setting UPLO
// *
{
forloop210:
for (ibuplo = 1; ibuplo <= 2; ibuplo++) {
if (ibuplo == 1)  
    uplo = "U";
if (ibuplo == 2)  
    uplo = "L";
// *
// *                 Generate random well-conditioned positive definite
// *                 matrix B, of bandwidth not greater than that of A.
// *
Dlatms.dlatms(n,n,"U",iseed,_iseed_offset,"P",work,_work_offset,5,ten,one,kb,kb,uplo,b,_b_offset,ldb,work,(n+1)- 1+ _work_offset,iinfo);
// *
ntest = ntest+1;
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,z,_z_offset,ldu);
Dlacpy.dlacpy(uplo,n,n,b,_b_offset,ldb,bb,_bb_offset,ldb);
// *
Dsygv.dsygv(ibtype,"V",uplo,n,z,_z_offset,ldu,bb,_bb_offset,ldb,d,_d_offset,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVSG: "  + ("DSYGV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvsg",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvsg",90);
}              //  Close else.
}              // Close if()
// *
// *                 Do Test
// *
Dsgt01.dsgt01(ibtype,uplo,n,a,_a_offset,lda,b,_b_offset,ldb,z,_z_offset,ldu,d,_d_offset,uz,_uz_offset,result,(ntest)- 1+ _result_offset);
// *
label90:
   Dummy.label("Ddrvsg",90);
ntest = ntest+1;
// *
// *                 Copy the matrices into packed storage.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    ij = 1;
{
forloop110:
for (j = 1; j <= n; j++) {
{
forloop100:
for (i = 1; i <= j; i++) {
uz[(ij)- 1+ _uz_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
u[(ij)- 1+ _u_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset];
ij = ij+1;
Dummy.label("Ddrvsg",100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  ij = 1;
{
forloop130:
for (j = 1; j <= n; j++) {
{
forloop120:
for (i = j; i <= n; i++) {
uz[(ij)- 1+ _uz_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
u[(ij)- 1+ _u_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset];
ij = ij+1;
Dummy.label("Ddrvsg",120);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dspgv.dspgv(ibtype,"V",uplo,n,uz,_uz_offset,u,_u_offset,d,_d_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVSG: "  + ("DSPGV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvsg",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvsg",140);
}              //  Close else.
}              // Close if()
// *
// *                 Do Test
// *
Dsgt01.dsgt01(ibtype,uplo,n,a,_a_offset,lda,b,_b_offset,ldb,z,_z_offset,ldu,d,_d_offset,uz,_uz_offset,result,(ntest)- 1+ _result_offset);
// *
label140:
   Dummy.label("Ddrvsg",140);
if (ibtype == 1)  {
    ntest = ntest+1;
// *
// *                    Copy the matrices into band storage.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop170:
for (j = 1; j <= n; j++) {
{
forloop150:
for (i = (int)(Math.max(1, j-ka) ); i <= j; i++) {
v[(ka+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvsg",150);
}              //  Close for() loop. 
}
{
forloop160:
for (i = (int)(Math.max(1, j-kb) ); i <= j; i++) {
bb[(kb+1+i-j)- 1+(j- 1)*ldb+ _bb_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Ddrvsg",160);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",170);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop200:
for (j = 1; j <= n; j++) {
{
forloop180:
for (i = j; i <= Math.min(n, j+ka) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvsg",180);
}              //  Close for() loop. 
}
{
forloop190:
for (i = j; i <= Math.min(n, j+kb) ; i++) {
bb[(1+i-j)- 1+(j- 1)*ldb+ _bb_offset] = b[(i)- 1+(j- 1)*ldb+ _b_offset];
Dummy.label("Ddrvsg",190);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",200);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbgv.dsbgv("V",uplo,n,ka,kb,v,_v_offset,ldu,bb,_bb_offset,ldb,d,_d_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVSG: "  + ("DSBGV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvsg",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
continue forloop210;
}              //  Close else.
}              // Close if()
// *
// *                    Do Test
// *
Dsgt01.dsgt01(ibtype,uplo,n,a,_a_offset,lda,b,_b_offset,ldb,z,_z_offset,ldu,d,_d_offset,uz,_uz_offset,result,(ntest)- 1+ _result_offset);
}              // Close if()
// *
Dummy.label("Ddrvsg",210);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",220);
}              //  Close for() loop. 
}
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
ntestt = ntestt+ntest;
Dlafts.dlafts("DSG",n,n,jtype,ntest,result,_result_offset,ioldsd,0,thresh,nounit,nerrs);
Dummy.label("Ddrvsg",230);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsg",240);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Dlasum.dlasum("DSG",nounit,nerrs.val,ntestt);
// *
Dummy.go_to("Ddrvsg",999999);
// *
// *     End of DDRVSG
// *
Dummy.label("Ddrvsg",999999);
return;
   }
} // End class.
