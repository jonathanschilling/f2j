/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Ddrvst {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *       DDRVST  checks the symmetric eigenvalue problem drivers.
// *
// *               DSTEV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric tridiagonal matrix.
// *
// *               DSTEVX computes selected eigenvalues and, optionally,
// *               eigenvectors of a real symmetric tridiagonal matrix.
// *
// *               DSYEV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix.
// *
// *               DSYEVX computes selected eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix.
// *
// *               DSPEV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix in packed
// *               storage.
// *
// *               DSPEVX computes selected eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix in packed
// *               storage.
// *
// *               DSBEV computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric band matrix.
// *
// *               DSBEVX computes selected eigenvalues and, optionally,
// *               eigenvectors of a real symmetric band matrix.
// *
// *               DSYEVD computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix using
// *               a divide and conquer algorithm.
// *
// *               DSPEVD computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric matrix in packed
// *               storage, using a divide and conquer algorithm.
// *
// *               DSBEVD computes all eigenvalues and, optionally,
// *               eigenvectors of a real symmetric band matrix,
// *               using a divide and conquer algorithm.
// *
// *       When DDRVST is called, a number of matrix "sizes" ("n's") and a
// *       number of matrix "types" are specified.  For each size ("n")
// *       and each type of matrix, one matrix will be generated and used
// *       to test the appropriate drivers.  For each matrix and each
// *       driver routine called, the following tests will be performed:
// *
// *       (1)     | A - Z D Z' | / ( |A| n ulp )
// *
// *       (2)     | I - Z Z' | / ( n ulp )
// *
// *       (3)     | D1 - D2 | / ( |D1| ulp )
// *
// *       where Z is the matrix of eigenvectors returned when the
// *       eigenvector option is given and D1 and D2 are the eigenvalues
// *       returned with and without the eigenvector option.
// *
// *       The "sizes" are specified by an array NN(1:NSIZES); the value of
// *       each element NN(j) specifies one size.
// *       The "types" are specified by a logical array DOTYPE( 1:NTYPES );
// *       if DOTYPE(j) is .TRUE., then matrix type "j" will be generated.
// *       Currently, the list of possible types is:
// *
// *       (1)  The zero matrix.
// *       (2)  The identity matrix.
// *
// *       (3)  A diagonal matrix with evenly spaced eigenvalues
// *            1, ..., ULP  and random signs.
// *            (ULP = (first number larger than 1) - 1 )
// *       (4)  A diagonal matrix with geometrically spaced eigenvalues
// *            1, ..., ULP  and random signs.
// *       (5)  A diagonal matrix with "clustered" eigenvalues
// *            1, ULP, ..., ULP and random signs.
// *
// *       (6)  Same as (4), but multiplied by SQRT( overflow threshold )
// *       (7)  Same as (4), but multiplied by SQRT( underflow threshold )
// *
// *       (8)  A matrix of the form  U' D U, where U is orthogonal and
// *            D has evenly spaced entries 1, ..., ULP with random signs
// *            on the diagonal.
// *
// *       (9)  A matrix of the form  U' D U, where U is orthogonal and
// *            D has geometrically spaced entries 1, ..., ULP with random
// *            signs on the diagonal.
// *
// *       (10) A matrix of the form  U' D U, where U is orthogonal and
// *            D has "clustered" entries 1, ULP,..., ULP with random
// *            signs on the diagonal.
// *
// *       (11) Same as (8), but multiplied by SQRT( overflow threshold )
// *       (12) Same as (8), but multiplied by SQRT( underflow threshold )
// *
// *       (13) Symmetric matrix with random entries chosen from (-1,1).
// *       (14) Same as (13), but multiplied by SQRT( overflow threshold )
// *       (15) Same as (13), but multiplied by SQRT( underflow threshold )
// *       (16) A band matrix with half bandwidth randomly chosen between
// *            0 and N-1, with evenly spaced eigenvalues 1, ..., ULP
// *            with random signs.
// *       (17) Same as (16), but multiplied by SQRT( overflow threshold )
// *       (18) Same as (16), but multiplied by SQRT( underflow threshold )
// *
// *  Arguments
// *  =========
// *
// *  NSIZES  INTEGER
// *          The number of sizes of matrices to use.  If it is zero,
// *          DDRVST does nothing.  It must be at least zero.
// *          Not modified.
// *
// *  NN      INTEGER array, dimension (NSIZES)
// *          An array containing the sizes to be used for the matrices.
// *          Zero values will be skipped.  The values must be at least
// *          zero.
// *          Not modified.
// *
// *  NTYPES  INTEGER
// *          The number of elements in DOTYPE.   If it is zero, DDRVST
// *          does nothing.  It must be at least zero.  If it is MAXTYP+1
// *          and NSIZES is 1, then an additional type, MAXTYP+1 is
// *          defined, which is to use whatever matrix is in A.  This
// *          is only useful if DOTYPE(1:MAXTYP) is .FALSE. and
// *          DOTYPE(MAXTYP+1) is .TRUE. .
// *          Not modified.
// *
// *  DOTYPE  LOGICAL array, dimension (NTYPES)
// *          If DOTYPE(j) is .TRUE., then for each size in NN a
// *          matrix of that size and of type j will be generated.
// *          If NTYPES is smaller than the maximum number of types
// *          defined (PARAMETER MAXTYP), then types NTYPES+1 through
// *          MAXTYP will not be generated.  If NTYPES is larger
// *          than MAXTYP, DOTYPE(MAXTYP+1) through DOTYPE(NTYPES)
// *          will be ignored.
// *          Not modified.
// *
// *  ISEED   INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator. The array elements should be between 0 and 4095;
// *          if not they will be reduced mod 4096.  Also, ISEED(4) must
// *          be odd.  The random number generator uses a linear
// *          congruential sequence limited to small integers, and so
// *          should produce machine independent random numbers. The
// *          values of ISEED are changed on exit, and can be used in the
// *          next call to DDRVST to continue the same random number
// *          sequence.
// *          Modified.
// *
// *  THRESH  DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *          Not modified.
// *
// *  NOUNIT  INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns IINFO not equal to 0.)
// *          Not modified.
// *
// *  A       DOUBLE PRECISION array, dimension (LDA , max(NN))
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.  On exit, A contains the last matrix actually
// *          used.
// *          Modified.
// *
// *  LDA     INTEGER
// *          The leading dimension of A.  It must be at
// *          least 1 and at least max( NN ).
// *          Not modified.
// *
// *  D1      DOUBLE PRECISION array, dimension (max(NN))
// *          The eigenvalues of A, as computed by DSTEQR simlutaneously
// *          with Z.  On exit, the eigenvalues in D1 correspond with the
// *          matrix in A.
// *          Modified.
// *
// *  D2      DOUBLE PRECISION array, dimension (max(NN))
// *          The eigenvalues of A, as computed by DSTEQR if Z is not
// *          computed.  On exit, the eigenvalues in D2 correspond with
// *          the matrix in A.
// *          Modified.
// *
// *  D3      DOUBLE PRECISION array, dimension (max(NN))
// *          The eigenvalues of A, as computed by DSTERF.  On exit, the
// *          eigenvalues in D3 correspond with the matrix in A.
// *          Modified.
// *
// *  D4      DOUBLE PRECISION array, dimension
// *
// *  WA1     DOUBLE PRECISION array, dimension
// *
// *  WA2     DOUBLE PRECISION array, dimension
// *
// *  WA3     DOUBLE PRECISION array, dimension
// *
// *  U       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          The orthogonal matrix computed by DSYTRD + DORGTR.
// *          Modified.
// *
// *  LDU     INTEGER
// *          The leading dimension of U, Z, and V.  It must be at
// *          least 1 and at least max( NN ).
// *          Not modified.
// *
// *  V       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          The Housholder vectors computed by DSYTRD in reducing A to
// *          tridiagonal form.
// *          Modified.
// *
// *  TAU     DOUBLE PRECISION array, dimension (max(NN))
// *          The Householder factors computed by DSYTRD in reducing A
// *          to tridiagonal form.
// *          Modified.
// *
// *  Z       DOUBLE PRECISION array, dimension (LDU, max(NN))
// *          The orthogonal matrix of eigenvectors computed by DSTEQR,
// *          DPTEQR, and DSTEIN.
// *          Modified.
// *
// *  WORK    DOUBLE PRECISION array, dimension (NWORK)
// *          Workspace.
// *          Modified.
// *
// *  NWORK   INTEGER
// *          The number of entries in WORK.  This must be at least
// *          1 + 4 * Nmax + 2 * Nmax * lg Nmax + 4 * Nmax**2
// *          where Nmax = max( NN(j), 2 ) and lg = log base 2.
// *          Not modified.
// *
// *  IWORK   INTEGER array,
// *             dimension (6 + 6*Nmax + 5 * Nmax * lg Nmax )
// *          where Nmax = max( NN(j), 2 ) and lg = log base 2.
// *          Workspace.
// *          Modified.
// *
// *  RESULT  DOUBLE PRECISION array, dimension (105)
// *          The values computed by the tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *          Modified.
// *
// *  INFO    INTEGER
// *          If 0, then everything ran OK.
// *           -1: NSIZES < 0
// *           -2: Some NN(j) < 0
// *           -3: NTYPES < 0
// *           -5: THRESH < 0
// *           -9: LDA < 1 or LDA < NMAX, where NMAX is max( NN(j) ).
// *          -16: LDU < 1 or LDU < NMAX.
// *          -21: NWORK too small.
// *          If  DLATMR, SLATMS, DSYTRD, DORGTR, DSTEQR, SSTERF,
// *              or DORMTR returns an error code, the
// *              absolute value of it is returned.
// *          Modified.
// *
// *-----------------------------------------------------------------------
// *
// *       Some Local Variables and Parameters:
// *       ---- ----- --------- --- ----------
// *       ZERO, ONE       Real 0 and 1.
// *       MAXTYP          The number of types defined.
// *       NTEST           The number of tests performed, or which can
// *                       be performed so far, for the current matrix.
// *       NTESTT          The total number of tests performed so far.
// *       NMAX            Largest value in NN.
// *       NMATS           The number of matrices generated so far.
// *       NERRS           The number of tests which have exceeded THRESH
// *                       so far (computed by DLAFTS).
// *       COND, IMODE     Values to be passed to the matrix generators.
// *       ANORM           Norm of A; passed to matrix generators.
// *
// *       OVFL, UNFL      Overflow and underflow thresholds.
// *       ULP, ULPINV     Finest relative precision and its inverse.
// *       RTOVFL, RTUNFL  Square roots of the previous 2 values.
// *               The following four arrays decode JTYPE:
// *       KTYPE(j)        The general type (1-10) for type "j".
// *       KMODE(j)        The MODE value to be passed to the matrix
// *                       generator for type "j".
// *       KMAGN(j)        The order of magnitude ( O(1),
// *                       O(overflow^(1/2) ), O(underflow^(1/2) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double ten= 10.0e0;
static double half= 0.5e0;
static int maxtyp= 18;
// *     ..
// *     .. Local Scalars ..
static boolean badnn= false;
static String uplo= new String(" ");
static int i= 0;
static int idiag= 0;
static int ihbw= 0;
static intW iinfo= new intW(0);
static int il= 0;
static int imode= 0;
static int indx= 0;
static int irow= 0;
static int itemp= 0;
static int itype= 0;
static int iu= 0;
static int iuplo= 0;
static int j= 0;
static int j1= 0;
static int j2= 0;
static int jcol= 0;
static int jsize= 0;
static int jtype= 0;
static int kd= 0;
static int lgn= 0;
static int liwedc= 0;
static int lwedc= 0;
static intW m= new intW(0);
static intW m2= new intW(0);
static intW m3= new intW(0);
static int mtypes= 0;
static int n= 0;
static intW nerrs= new intW(0);
static int nmats= 0;
static int nmax= 0;
static int ntest= 0;
static int ntestt= 0;
static double abstol= 0.0;
static double aninv= 0.0;
static double anorm= 0.0;
static double cond= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double rtovfl= 0.0;
static double rtunfl= 0.0;
static double temp1= 0.0;
static double temp2= 0.0;
static double temp3= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static doubleW unfl= new doubleW(0.0);
static double vl= 0.0;
static double vu= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] idumma= new int[(1)];
static int [] ioldsd= new int[(4)];
static int [] iseed2= new int[(4)];
static int [] iseed3= new int[(4)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] ktype = {1 
, 2 , 4, 4, 4, 4, 4 , 5, 5, 5, 5, 5 , 8, 8, 8 , 9, 9, 9 
};
static int [] kmagn = {1, 1 
, 1 , 1 , 1 , 2 , 3 
, 1 , 1 , 1 , 2 , 3 
, 1 , 2 , 3 , 1 , 2 
, 3 };
static int [] kmode = {0, 0 
, 4 , 3 , 1 , 4 , 4 
, 4 , 3 , 1 , 4 , 4 
, 0 , 0 , 0 , 4 , 4 
, 4 };
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Check for errors
// *

public static void ddrvst (int nsizes,
int [] nn, int _nn_offset,
int ntypes,
boolean [] dotype, int _dotype_offset,
int [] iseed, int _iseed_offset,
double thresh,
int nounit,
double [] a, int _a_offset,
int lda,
double [] d1, int _d1_offset,
double [] d2, int _d2_offset,
double [] d3, int _d3_offset,
double [] d4, int _d4_offset,
double [] wa1, int _wa1_offset,
double [] wa2, int _wa2_offset,
double [] wa3, int _wa3_offset,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
double [] tau, int _tau_offset,
double [] z, int _z_offset,
double [] work, int _work_offset,
int nwork,
int [] iwork, int _iwork_offset,
double [] result, int _result_offset,
intW info)  {

ntestt = 0;
info.val = 0;
// *
badnn = false;
nmax = 1;
{
forloop10:
for (j = 1; j <= nsizes; j++) {
nmax = (int)(Math.max(nmax, nn[(j)- 1+ _nn_offset]) );
if (nn[(j)- 1+ _nn_offset] < 0)  
    badnn = true;
Dummy.label("Ddrvst",10);
}              //  Close for() loop. 
}
// *
// *     Check for errors
// *
if (nsizes < 0)  {
    info.val = -1;
}              // Close if()
else if (badnn)  {
    info.val = -2;
}              // Close else if()
else if (ntypes < 0)  {
    info.val = -3;
}              // Close else if()
else if (lda < nmax)  {
    info.val = -9;
}              // Close else if()
else if (ldu < nmax)  {
    info.val = -16;
}              // Close else if()
else if (2*Math.pow(Math.max(2, nmax) , 2) > nwork)  {
    info.val = -21;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DDRVST",-info.val);
Dummy.go_to("Ddrvst",999999);
}              // Close if()
// *
// *     Quick return if nothing to do
// *
if (nsizes == 0 || ntypes == 0)  
    Dummy.go_to("Ddrvst",999999);
// *
// *     More Important constants
// *
unfl.val = Dlamch.dlamch("Safe minimum");
ovfl.val = Dlamch.dlamch("Overflow");
Dlabad.dlabad(unfl,ovfl);
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
ulpinv = one/ulp;
rtunfl = Math.sqrt(unfl.val);
rtovfl = Math.sqrt(ovfl.val);
// *
// *     Loop over sizes, types
// *
{
forloop20:
for (i = 1; i <= 4; i++) {
iseed2[(i)- 1] = iseed[(i)- 1+ _iseed_offset];
iseed3[(i)- 1] = iseed[(i)- 1+ _iseed_offset];
Dummy.label("Ddrvst",20);
}              //  Close for() loop. 
}
// *
nerrs.val = 0;
nmats = 0;
// *
{
forloop1520:
for (jsize = 1; jsize <= nsizes; jsize++) {
n = nn[(jsize)- 1+ _nn_offset];
if (n > 0)  {
    lgn = (int)(Math.log((double)(n))/Math.log(two));
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
if (Math.pow(2, lgn) < n)  
    lgn = lgn+1;
lwedc = (int)(1+4*n+2*n*lgn+4*Math.pow(n, 2));
liwedc = 6+6*n+5*n*lgn;
}              // Close if()
else  {
  lwedc = 9;
liwedc = 12;
}              //  Close else.
aninv = one/(double)(Math.max(1, n) );
// *
if (nsizes != 1)  {
    mtypes = (int)(Math.min(maxtyp, ntypes) );
}              // Close if()
else  {
  mtypes = (int)(Math.min(maxtyp+1, ntypes) );
}              //  Close else.
// *
{
forloop1510:
for (jtype = 1; jtype <= mtypes; jtype++) {
if (!dotype[(jtype)- 1+ _dotype_offset])  
    continue forloop1510;
nmats = nmats+1;
ntest = 0;
// *
{
forloop30:
for (j = 1; j <= 4; j++) {
ioldsd[(j)- 1] = iseed[(j)- 1+ _iseed_offset];
Dummy.label("Ddrvst",30);
}              //  Close for() loop. 
}
// *
// *           2)      Compute "A"
// *
// *                   Control parameters:
// *
// *               KMAGN  KMODE        KTYPE
// *           =1  O(1)   clustered 1  zero
// *           =2  large  clustered 2  identity
// *           =3  small  exponential  (none)
// *           =4         arithmetic   diagonal, (w/ eigenvalues)
// *           =5         random log   symmetric, w/ eigenvalues
// *           =6         random       (none)
// *           =7                      random diagonal
// *           =8                      random symmetric
// *           =9                      band symmetric, w/ eigenvalues
// *
if (mtypes > maxtyp)  
    Dummy.go_to("Ddrvst",110);
// *
itype = ktype[(jtype)- 1];
imode = kmode[(jtype)- 1];
// *
// *           Compute norm
// *
if (kmagn[(jtype)- 1] == 1) 
  Dummy.go_to("Ddrvst",40);
else if (kmagn[(jtype)- 1] == 2) 
  Dummy.go_to("Ddrvst",50);
else if (kmagn[(jtype)- 1] == 3) 
  Dummy.go_to("Ddrvst",60);
// *
label40:
   Dummy.label("Ddrvst",40);
anorm = one;
Dummy.go_to("Ddrvst",70);
// *
label50:
   Dummy.label("Ddrvst",50);
anorm = (rtovfl*ulp)*aninv;
Dummy.go_to("Ddrvst",70);
// *
label60:
   Dummy.label("Ddrvst",60);
anorm = rtunfl*n*ulpinv;
Dummy.go_to("Ddrvst",70);
// *
label70:
   Dummy.label("Ddrvst",70);
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
iinfo.val = 0;
cond = ulpinv;
// *
// *           Special Matrices -- Identity & Jordan block
// *
// *                   Zero
// *
if (itype == 1)  {
    iinfo.val = 0;
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *              Identity
// *
{
forloop80:
for (jcol = 1; jcol <= n; jcol++) {
a[(jcol)- 1+(jcol- 1)*lda+ _a_offset] = anorm;
Dummy.label("Ddrvst",80);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (itype == 4)  {
    // *
// *              Diagonal Matrix, [Eigen]values Specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,0,0,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 5)  {
    // *
// *              Symmetric, eigenvalues specified
// *
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,n,n,"N",a,_a_offset,lda,work,(n+1)- 1+ _work_offset,iinfo);
// *
}              // Close else if()
else if (itype == 7)  {
    // *
// *              Diagonal, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,0,0,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 8)  {
    // *
// *              Symmetric, random eigenvalues
// *
Dlatmr.dlatmr(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,6,one,one,"T","N",work,(n+1)- 1+ _work_offset,1,one,work,(2*n+1)- 1+ _work_offset,1,one,"N",idumma,0,n,n,zero,anorm,"NO",a,_a_offset,lda,iwork,_iwork_offset,iinfo);
// *
}              // Close else if()
else if (itype == 9)  {
    // *
// *              Symmetric banded, eigenvalues specified
// *
ihbw = (int)((n-1)*Dlarnd.dlarnd(1,iseed3,0));
Dlatms.dlatms(n,n,"S",iseed,_iseed_offset,"S",work,_work_offset,imode,cond,anorm,ihbw,ihbw,"Z",u,_u_offset,ldu,work,(n+1)- 1+ _work_offset,iinfo);
// *
// *              Store as dense matrix for most routines.
// *
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
{
forloop100:
for (idiag = -ihbw; idiag <= ihbw; idiag++) {
irow = ihbw-idiag+1;
j1 = (int)(Math.max(1, idiag) );
j2 = (int)(Math.min(n, n+idiag) );
{
forloop90:
for (j = j1; j <= j2; j++) {
i = j-idiag;
a[(i)- 1+(j- 1)*lda+ _a_offset] = u[(irow)- 1+(j- 1)*ldu+ _u_offset];
Dummy.label("Ddrvst",90);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",100);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  iinfo.val = 1;
}              //  Close else.
// *
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("Generator") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Ddrvst",999999);
}              // Close if()
// *
label110:
   Dummy.label("Ddrvst",110);
// *
abstol = unfl.val+unfl.val;
if (n <= 1)  {
    il = 1;
iu = n;
}              // Close if()
else  {
  il = (int)(1+(n-1)*Dlarnd.dlarnd(1,iseed2,0));
iu = (int)(1+(n-1)*Dlarnd.dlarnd(1,iseed2,0));
if (il > iu)  {
    itemp = il;
il = iu;
iu = itemp;
}              // Close if()
}              //  Close else.
// *
// *           3)      If matrix is tridiagonal, call DSTEV and SSTEVX.
// *
if (jtype <= 7)  {
    ntest = 1;
{
forloop120:
for (i = 1; i <= n; i++) {
d1[(i)- 1+ _d1_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",120);
}              //  Close for() loop. 
}
{
forloop130:
for (i = 1; i <= n-1; i++) {
d2[(i)- 1+ _d2_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",130);
}              //  Close for() loop. 
}
Dstev.dstev("V",n,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEV(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = ulpinv;
result[(2)- 1+ _result_offset] = ulpinv;
result[(3)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",180);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 1 and 2.
// *
{
forloop140:
for (i = 1; i <= n; i++) {
d3[(i)- 1+ _d3_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",140);
}              //  Close for() loop. 
}
{
forloop150:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",150);
}              //  Close for() loop. 
}
Dstt21.dstt21(n,0,d3,_d3_offset,d4,_d4_offset,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,result,(1)- 1+ _result_offset);
// *
ntest = 3;
{
forloop160:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",160);
}              //  Close for() loop. 
}
Dstev.dstev("N",n,d3,_d3_offset,d4,_d4_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEV(N)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(3)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",180);
}              //  Close else.
}              // Close if()
// *
// *              Do test 3.
// *
temp1 = zero;
temp2 = zero;
{
forloop170:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",170);
}              //  Close for() loop. 
}
result[(3)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label180:
   Dummy.label("Ddrvst",180);
// *
ntest = 4;
{
forloop190:
for (i = 1; i <= n; i++) {
d1[(i)- 1+ _d1_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",190);
}              //  Close for() loop. 
}
{
forloop200:
for (i = 1; i <= n-1; i++) {
d2[(i)- 1+ _d2_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",200);
}              //  Close for() loop. 
}
Dstevx.dstevx("V","A",n,d1,_d1_offset,d2,_d2_offset,vl,vu,il,iu,abstol,m,wa1,_wa1_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(V,A)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(4)- 1+ _result_offset] = ulpinv;
result[(5)- 1+ _result_offset] = ulpinv;
result[(6)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",250);
}              //  Close else.
}              // Close if()
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
// *
// *              Do tests 4 and 5.
// *
{
forloop210:
for (i = 1; i <= n; i++) {
d3[(i)- 1+ _d3_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",210);
}              //  Close for() loop. 
}
{
forloop220:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",220);
}              //  Close for() loop. 
}
Dstt21.dstt21(n,0,d3,_d3_offset,d4,_d4_offset,wa1,_wa1_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,result,(4)- 1+ _result_offset);
// *
ntest = 6;
{
forloop230:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",230);
}              //  Close for() loop. 
}
Dstevx.dstevx("N","A",n,d3,_d3_offset,d4,_d4_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(N,A)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(6)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",250);
}              //  Close else.
}              // Close if()
// *
// *              Do test 6.
// *
temp1 = zero;
temp2 = zero;
{
forloop240:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(wa1[(j)- 1+ _wa1_offset])) ? (temp1) : (Math.abs(wa1[(j)- 1+ _wa1_offset])), Math.abs(wa2[(j)- 1+ _wa2_offset]));
temp2 = Math.max(temp2, Math.abs(wa1[(j)- 1+ _wa1_offset]-wa2[(j)- 1+ _wa2_offset])) ;
Dummy.label("Ddrvst",240);
}              //  Close for() loop. 
}
result[(6)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label250:
   Dummy.label("Ddrvst",250);
// *
ntest = 7;
{
forloop260:
for (i = 1; i <= n; i++) {
d1[(i)- 1+ _d1_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",260);
}              //  Close for() loop. 
}
{
forloop270:
for (i = 1; i <= n-1; i++) {
d2[(i)- 1+ _d2_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",270);
}              //  Close for() loop. 
}
Dstevx.dstevx("V","I",n,d1,_d1_offset,d2,_d2_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(V,I)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(7)- 1+ _result_offset] = ulpinv;
result[(8)- 1+ _result_offset] = ulpinv;
result[(9)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",310);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 7 and 8.
// *
{
forloop280:
for (i = 1; i <= n; i++) {
d3[(i)- 1+ _d3_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",280);
}              //  Close for() loop. 
}
{
forloop290:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",290);
}              //  Close for() loop. 
}
Dstt22.dstt22(n,m2.val,0,d3,_d3_offset,d4,_d4_offset,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,(int) ( Math.max(1, m2.val) ),result,(7)- 1+ _result_offset);
// *
ntest = 9;
{
forloop300:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",300);
}              //  Close for() loop. 
}
Dstevx.dstevx("N","I",n,d3,_d3_offset,d4,_d4_offset,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(N,I)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(9)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",310);
}              //  Close else.
}              // Close if()
// *
// *              Do test 9.
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
result[(9)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, ulp*temp3) ;
// *
label310:
   Dummy.label("Ddrvst",310);
// *
ntest = 10;
if (n > 0)  {
    if (il != 1)  {
    vl = wa1[(il)- 1+ _wa1_offset]-Math.max((half*(wa1[(il)- 1+ _wa1_offset]-wa1[(il-1)- 1+ _wa1_offset])) > (ten*ulp*temp3) ? (half*(wa1[(il)- 1+ _wa1_offset]-wa1[(il-1)- 1+ _wa1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else  {
  vl = wa1[(1)- 1+ _wa1_offset]-Math.max((half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) > (ten*ulp*temp3) ? (half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              //  Close else.
if (iu != n)  {
    vu = wa1[(iu)- 1+ _wa1_offset]+Math.max((half*(wa1[(iu+1)- 1+ _wa1_offset]-wa1[(iu)- 1+ _wa1_offset])) > (ten*ulp*temp3) ? (half*(wa1[(iu+1)- 1+ _wa1_offset]-wa1[(iu)- 1+ _wa1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else  {
  vu = wa1[(n)- 1+ _wa1_offset]+Math.max((half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) > (ten*ulp*temp3) ? (half*(wa1[(n)- 1+ _wa1_offset]-wa1[(1)- 1+ _wa1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              //  Close else.
}              // Close if()
else  {
  vl = zero;
vu = one;
}              //  Close else.
// *
{
forloop320:
for (i = 1; i <= n; i++) {
d1[(i)- 1+ _d1_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",320);
}              //  Close for() loop. 
}
{
forloop330:
for (i = 1; i <= n-1; i++) {
d2[(i)- 1+ _d2_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",330);
}              //  Close for() loop. 
}
// *
Dstevx.dstevx("V","V",n,d1,_d1_offset,d2,_d2_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(V,V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(10)- 1+ _result_offset] = ulpinv;
result[(11)- 1+ _result_offset] = ulpinv;
result[(12)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",370);
}              //  Close else.
}              // Close if()
// *
if (m2.val == 0 && n > 0)  {
    result[(10)- 1+ _result_offset] = ulpinv;
result[(11)- 1+ _result_offset] = ulpinv;
result[(12)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",370);
}              // Close if()
// *
// *              Do tests 10 and 11.
// *
{
forloop340:
for (i = 1; i <= n; i++) {
d3[(i)- 1+ _d3_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",340);
}              //  Close for() loop. 
}
{
forloop350:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",350);
}              //  Close for() loop. 
}
Dstt22.dstt22(n,m2.val,0,d3,_d3_offset,d4,_d4_offset,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,(int) ( Math.max(1, m2.val) ),result,(10)- 1+ _result_offset);
// *
ntest = 12;
{
forloop360:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",360);
}              //  Close for() loop. 
}
Dstevx.dstevx("N","V",n,d3,_d3_offset,d4,_d4_offset,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVX(N,V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(12)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",370);
}              //  Close else.
}              // Close if()
// *
// *              Do test 12.
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
result[(12)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label370:
   Dummy.label("Ddrvst",370);
// *
ntest = 13;
{
forloop380:
for (i = 1; i <= n; i++) {
d1[(i)- 1+ _d1_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",380);
}              //  Close for() loop. 
}
{
forloop390:
for (i = 1; i <= n-1; i++) {
d2[(i)- 1+ _d2_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",390);
}              //  Close for() loop. 
}
Dstevd.dstevd("V",n,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVD(V)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(13)- 1+ _result_offset] = ulpinv;
result[(14)- 1+ _result_offset] = ulpinv;
result[(15)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",440);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 13 and 14.
// *
{
forloop400:
for (i = 1; i <= n; i++) {
d3[(i)- 1+ _d3_offset] = a[(i)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",400);
}              //  Close for() loop. 
}
{
forloop410:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",410);
}              //  Close for() loop. 
}
Dstt21.dstt21(n,0,d3,_d3_offset,d4,_d4_offset,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,work,_work_offset,result,(13)- 1+ _result_offset);
// *
ntest = 15;
{
forloop420:
for (i = 1; i <= n-1; i++) {
d4[(i)- 1+ _d4_offset] = a[(i+1)- 1+(i- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",420);
}              //  Close for() loop. 
}
Dstevd.dstevd("N",n,d3,_d3_offset,d4,_d4_offset,z,_z_offset,ldu,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSTEVD(N)") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(15)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",440);
}              //  Close else.
}              // Close if()
// *
// *              Do test 15.
// *
temp1 = zero;
temp2 = zero;
{
forloop430:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",430);
}              //  Close for() loop. 
}
result[(15)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label440:
   Dummy.label("Ddrvst",440);
// *
}              // Close if()
else  {
  // *
{
forloop450:
for (i = 1; i <= 15; i++) {
result[(i)- 1+ _result_offset] = zero;
Dummy.label("Ddrvst",450);
}              //  Close for() loop. 
}
ntest = 15;
}              //  Close else.
// *
// *           Perform remaining tests storing upper or lower triangular
// *           part of matrix.
// *
{
forloop1500:
for (iuplo = 0; iuplo <= 1; iuplo++) {
if (iuplo == 0)  {
    uplo = "L";
}              // Close if()
else  {
  uplo = "U";
}              //  Close else.
// *
// *              4)      Call DSYEV and SSYEVX.
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,v,_v_offset,ldu);
// *
ntest = ntest+1;
Dsyev.dsyev("V",uplo,n,a,_a_offset,ldu,d1,_d1_offset,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",470);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 16 and 17 (or 61 and 62).
// *
Dsyt21.dsyt21(1,uplo,n,0,v,_v_offset,ldu,d1,_d1_offset,d2,_d2_offset,a,_a_offset,ldu,z,_z_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
ntest = ntest+2;
Dsyev.dsyev("N",uplo,n,a,_a_offset,ldu,d3,_d3_offset,work,_work_offset,nwork,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEV(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",470);
}              //  Close else.
}              // Close if()
// *
// *              Do test 18 (or 63).
// *
temp1 = zero;
temp2 = zero;
{
forloop460:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",460);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label470:
   Dummy.label("Ddrvst",470);
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
ntest = ntest+1;
// *
if (n > 0)  {
    temp3 = Math.max(Math.abs(d1[(1)- 1+ _d1_offset]), Math.abs(d1[(n)- 1+ _d1_offset])) ;
if (il != 1)  {
    vl = d1[(il)- 1+ _d1_offset]-Math.max((half*(d1[(il)- 1+ _d1_offset]-d1[(il-1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(il)- 1+ _d1_offset]-d1[(il-1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else if (n > 0)  {
    vl = d1[(1)- 1+ _d1_offset]-Math.max((half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close else if()
if (iu != n)  {
    vu = d1[(iu)- 1+ _d1_offset]+Math.max((half*(d1[(iu+1)- 1+ _d1_offset]-d1[(iu)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(iu+1)- 1+ _d1_offset]-d1[(iu)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else if (n > 0)  {
    vu = d1[(n)- 1+ _d1_offset]+Math.max((half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close else if()
}              // Close if()
else  {
  temp3 = zero;
vl = zero;
vu = one;
}              //  Close else.
// *
Dsyevx.dsyevx("V","A",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m,wa1,_wa1_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(V,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",490);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 19 and 20 (or 64 and 65).
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,ldu,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
Dsyevx.dsyevx("N","A",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(N,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",490);
}              //  Close else.
}              // Close if()
// *
// *              Do test 21 (or 66).
// *
temp1 = zero;
temp2 = zero;
{
forloop480:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(wa1[(j)- 1+ _wa1_offset])) ? (temp1) : (Math.abs(wa1[(j)- 1+ _wa1_offset])), Math.abs(wa2[(j)- 1+ _wa2_offset]));
temp2 = Math.max(temp2, Math.abs(wa1[(j)- 1+ _wa1_offset]-wa2[(j)- 1+ _wa2_offset])) ;
Dummy.label("Ddrvst",480);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label490:
   Dummy.label("Ddrvst",490);
// *
ntest = ntest+1;
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
Dsyevx.dsyevx("V","I",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(V,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",500);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 22 and 23 (or 67 and 68)
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
Dsyevx.dsyevx("N","I",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(N,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",500);
}              //  Close else.
}              // Close if()
// *
// *              Do test 24 (or 69)
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, ulp*temp3) ;
label500:
   Dummy.label("Ddrvst",500);
// *
ntest = ntest+1;
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
Dsyevx.dsyevx("V","V",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(V,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",510);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 25 and 26 (or 70 and 71).
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
Dsyevx.dsyevx("N","V",uplo,n,a,_a_offset,ldu,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,nwork,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVX(N,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",510);
}              //  Close else.
}              // Close if()
// *
if (m3.val == 0 && n > 0)  {
    result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",510);
}              // Close if()
// *
// *              Do test 27 (or 72).
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label510:
   Dummy.label("Ddrvst",510);
// *
// *              5)      Call DSPEV and SSPEVX.
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
// *              Load array WORK with the upper or lower triangular
// *              part of the matrix in packed form.
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop530:
for (j = 1; j <= n; j++) {
{
forloop520:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",520);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",530);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop550:
for (j = 1; j <= n; j++) {
{
forloop540:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",540);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",550);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
Dspev.dspev("V",uplo,n,work,_work_offset,d1,_d1_offset,z,_z_offset,ldu,v,_v_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",610);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 28 and 29 (or 73 and 74).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,lda,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop570:
for (j = 1; j <= n; j++) {
{
forloop560:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",560);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",570);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop590:
for (j = 1; j <= n; j++) {
{
forloop580:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",580);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",590);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+2;
Dspev.dspev("N",uplo,n,work,_work_offset,d3,_d3_offset,z,_z_offset,ldu,v,_v_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEV(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",610);
}              //  Close else.
}              // Close if()
// *
// *              Do test 30 (or 75)
// *
temp1 = zero;
temp2 = zero;
{
forloop600:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",600);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
// *              Load array WORK with the upper or lower triangular part
// *              of the matrix in packed form.
// *
label610:
   Dummy.label("Ddrvst",610);
if (iuplo == 1)  {
    indx = 1;
{
forloop630:
for (j = 1; j <= n; j++) {
{
forloop620:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",620);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",630);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop650:
for (j = 1; j <= n; j++) {
{
forloop640:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",640);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",650);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
// *
if (n > 0)  {
    temp3 = Math.max(Math.abs(d1[(1)- 1+ _d1_offset]), Math.abs(d1[(n)- 1+ _d1_offset])) ;
if (il != 1)  {
    vl = d1[(il)- 1+ _d1_offset]-Math.max((half*(d1[(il)- 1+ _d1_offset]-d1[(il-1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(il)- 1+ _d1_offset]-d1[(il-1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else if (n > 0)  {
    vl = d1[(1)- 1+ _d1_offset]-Math.max((half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close else if()
if (iu != n)  {
    vu = d1[(iu)- 1+ _d1_offset]+Math.max((half*(d1[(iu+1)- 1+ _d1_offset]-d1[(iu)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(iu+1)- 1+ _d1_offset]-d1[(iu)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close if()
else if (n > 0)  {
    vu = d1[(n)- 1+ _d1_offset]+Math.max((half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) > (ten*ulp*temp3) ? (half*(d1[(n)- 1+ _d1_offset]-d1[(1)- 1+ _d1_offset])) : (ten*ulp*temp3), ten*rtunfl);
}              // Close else if()
}              // Close if()
else  {
  temp3 = zero;
vl = zero;
vu = one;
}              //  Close else.
// *
Dspevx.dspevx("V","A",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m,wa1,_wa1_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(V,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",710);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 31 and 32 (or 76 and 77).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,ldu,wa1,_wa1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop670:
for (j = 1; j <= n; j++) {
{
forloop660:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",660);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",670);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop690:
for (j = 1; j <= n; j++) {
{
forloop680:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",680);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",690);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dspevx.dspevx("N","A",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(N,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",710);
}              //  Close else.
}              // Close if()
// *
// *              Do test 33 (or 78).
// *
temp1 = zero;
temp2 = zero;
{
forloop700:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(wa1[(j)- 1+ _wa1_offset])) ? (temp1) : (Math.abs(wa1[(j)- 1+ _wa1_offset])), Math.abs(wa2[(j)- 1+ _wa2_offset]));
temp2 = Math.max(temp2, Math.abs(wa1[(j)- 1+ _wa1_offset]-wa2[(j)- 1+ _wa2_offset])) ;
Dummy.label("Ddrvst",700);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label710:
   Dummy.label("Ddrvst",710);
if (iuplo == 1)  {
    indx = 1;
{
forloop730:
for (j = 1; j <= n; j++) {
{
forloop720:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",720);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",730);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop750:
for (j = 1; j <= n; j++) {
{
forloop740:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",740);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",750);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
// *
Dspevx.dspevx("V","I",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(V,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",800);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 34 and 35 (or 79 and 80).
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop770:
for (j = 1; j <= n; j++) {
{
forloop760:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",760);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",770);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop790:
for (j = 1; j <= n; j++) {
{
forloop780:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",780);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",790);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dspevx.dspevx("N","I",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(N,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",800);
}              //  Close else.
}              // Close if()
// *
if (m3.val == 0 && n > 0)  {
    result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",800);
}              // Close if()
// *
// *              Do test 36 (or 81).
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label800:
   Dummy.label("Ddrvst",800);
if (iuplo == 1)  {
    indx = 1;
{
forloop820:
for (j = 1; j <= n; j++) {
{
forloop810:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",810);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",820);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop840:
for (j = 1; j <= n; j++) {
{
forloop830:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",830);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",840);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
// *
Dspevx.dspevx("V","V",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(V,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",890);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 37 and 38 (or 82 and 83).
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop860:
for (j = 1; j <= n; j++) {
{
forloop850:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",850);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",860);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop880:
for (j = 1; j <= n; j++) {
{
forloop870:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",870);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",880);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dspevx.dspevx("N","V",uplo,n,work,_work_offset,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,v,_v_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVX(N,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",890);
}              //  Close else.
}              // Close if()
// *
if (m3.val == 0 && n > 0)  {
    result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",890);
}              // Close if()
// *
// *              Do test 39 (or 84).
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label890:
   Dummy.label("Ddrvst",890);
// *
// *              6)      Call DSBEV and SSBEVX.
// *
if (jtype <= 7)  {
    kd = 1;
}              // Close if()
else if (jtype >= 8 && jtype <= 15)  {
    kd = (int)(Math.max(n-1, 0) );
}              // Close else if()
else  {
  kd = ihbw;
}              //  Close else.
// *
// *              Load array V with the upper or lower triangular part
// *              of the matrix in band form.
// *
if (iuplo == 1)  {
    {
forloop910:
for (j = 1; j <= n; j++) {
{
forloop900:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",900);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",910);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop930:
for (j = 1; j <= n; j++) {
{
forloop920:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",920);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",930);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
Dsbev.dsbev("V",uplo,n,kd,v,_v_offset,ldu,d1,_d1_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEV(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",990);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 40 and 41 (or 85 and 86).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,lda,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
if (iuplo == 1)  {
    {
forloop950:
for (j = 1; j <= n; j++) {
{
forloop940:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",940);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",950);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop970:
for (j = 1; j <= n; j++) {
{
forloop960:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",960);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",970);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+2;
Dsbev.dsbev("N",uplo,n,kd,v,_v_offset,ldu,d3,_d3_offset,z,_z_offset,ldu,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEV(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",990);
}              //  Close else.
}              // Close if()
// *
// *              Do test 42 (or 87).
// *
temp1 = zero;
temp2 = zero;
{
forloop980:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",980);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
// *              Load array V with the upper or lower triangular part
// *              of the matrix in band form.
// *
label990:
   Dummy.label("Ddrvst",990);
if (iuplo == 1)  {
    {
forloop1010:
for (j = 1; j <= n; j++) {
{
forloop1000:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1000);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1010);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1030:
for (j = 1; j <= n; j++) {
{
forloop1020:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1020);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1030);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
Dsbevx.dsbevx("V","A",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(V,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1090);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 43 and 44 (or 88 and 89).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    {
forloop1050:
for (j = 1; j <= n; j++) {
{
forloop1040:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1040);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1050);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1070:
for (j = 1; j <= n; j++) {
{
forloop1060:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1060);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1070);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbevx.dsbevx("N","A",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(N,A,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1090);
}              //  Close else.
}              // Close if()
// *
// *              Do test 45 (or 90).
// *
temp1 = zero;
temp2 = zero;
{
forloop1080:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(wa2[(j)- 1+ _wa2_offset])) ? (temp1) : (Math.abs(wa2[(j)- 1+ _wa2_offset])), Math.abs(wa3[(j)- 1+ _wa3_offset]));
temp2 = Math.max(temp2, Math.abs(wa2[(j)- 1+ _wa2_offset]-wa3[(j)- 1+ _wa3_offset])) ;
Dummy.label("Ddrvst",1080);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label1090:
   Dummy.label("Ddrvst",1090);
ntest = ntest+1;
if (iuplo == 1)  {
    {
forloop1110:
for (j = 1; j <= n; j++) {
{
forloop1100:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1130:
for (j = 1; j <= n; j++) {
{
forloop1120:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1120);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbevx.dsbevx("V","I",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(V,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1180);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 46 and 47 (or 91 and 92).
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    {
forloop1150:
for (j = 1; j <= n; j++) {
{
forloop1140:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1140);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1150);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1170:
for (j = 1; j <= n; j++) {
{
forloop1160:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1160);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1170);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbevx.dsbevx("N","I",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(N,I,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1180);
}              //  Close else.
}              // Close if()
// *
// *              Do test 48 (or 93).
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label1180:
   Dummy.label("Ddrvst",1180);
ntest = ntest+1;
if (iuplo == 1)  {
    {
forloop1200:
for (j = 1; j <= n; j++) {
{
forloop1190:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1190);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1200);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1220:
for (j = 1; j <= n; j++) {
{
forloop1210:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1210);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1220);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbevx.dsbevx("V","V",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m2,wa2,_wa2_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(V,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1270);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 49 and 50 (or 94 and 95).
// *
Dsyt22.dsyt22(1,uplo,n,m2.val,0,a,_a_offset,ldu,wa2,_wa2_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
ntest = ntest+2;
// *
if (iuplo == 1)  {
    {
forloop1240:
for (j = 1; j <= n; j++) {
{
forloop1230:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1230);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1240);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1260:
for (j = 1; j <= n; j++) {
{
forloop1250:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1250);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1260);
}              //  Close for() loop. 
}
}              //  Close else.
// *
Dsbevx.dsbevx("N","V",uplo,n,kd,v,_v_offset,ldu,u,_u_offset,ldu,vl,vu,il,iu,abstol,m3,wa3,_wa3_offset,z,_z_offset,ldu,work,_work_offset,iwork,_iwork_offset,iwork,(5*n+1)- 1+ _iwork_offset,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVX(N,V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1270);
}              //  Close else.
}              // Close if()
// *
if (m3.val == 0 && n > 0)  {
    result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1270);
}              // Close if()
// *
// *              Do test 51 (or 96).
// *
temp1 = Dsxt1.dsxt1(1,wa2,_wa2_offset,m2.val,wa3,_wa3_offset,m3.val,abstol,ulp,unfl.val);
temp2 = Dsxt1.dsxt1(1,wa3,_wa3_offset,m3.val,wa2,_wa2_offset,m2.val,abstol,ulp,unfl.val);
if (n > 0)  {
    temp3 = Math.max(Math.abs(wa1[(1)- 1+ _wa1_offset]), Math.abs(wa1[(n)- 1+ _wa1_offset])) ;
}              // Close if()
else  {
  temp3 = zero;
}              //  Close else.
result[(ntest)- 1+ _result_offset] = (temp1+temp2)/Math.max(unfl.val, temp3*ulp) ;
// *
label1270:
   Dummy.label("Ddrvst",1270);
// *
// *              7)      Call DSYEVD
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,v,_v_offset,ldu);
// *
ntest = ntest+1;
Dsyevd.dsyevd("V",uplo,n,a,_a_offset,ldu,d1,_d1_offset,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVD(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1290);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 52 and 53 (or 97 and 98).
// *
Dsyt21.dsyt21(1,uplo,n,0,v,_v_offset,ldu,d1,_d1_offset,d2,_d2_offset,a,_a_offset,ldu,z,_z_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
ntest = ntest+2;
Dsyevd.dsyevd("N",uplo,n,a,_a_offset,ldu,d3,_d3_offset,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSYEVD(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1290);
}              //  Close else.
}              // Close if()
// *
// *              Do test 54 (or 99).
// *
temp1 = zero;
temp2 = zero;
{
forloop1280:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",1280);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label1290:
   Dummy.label("Ddrvst",1290);
// *
// *              8)      Call DSPEVD.
// *
Dlacpy.dlacpy(" ",n,n,v,_v_offset,ldu,a,_a_offset,lda);
// *
// *              Load array WORK with the upper or lower triangular
// *              part of the matrix in packed form.
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop1310:
for (j = 1; j <= n; j++) {
{
forloop1300:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",1300);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1310);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop1330:
for (j = 1; j <= n; j++) {
{
forloop1320:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",1320);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1330);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
Dspevd.dspevd("V",uplo,n,work,_work_offset,d1,_d1_offset,z,_z_offset,ldu,work,(indx)- 1+ _work_offset,lwedc-indx+1,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVD(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1390);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 55 and 56 (or 100 and 101).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,lda,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
if (iuplo == 1)  {
    indx = 1;
{
forloop1350:
for (j = 1; j <= n; j++) {
{
forloop1340:
for (i = 1; i <= j; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",1340);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1350);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  indx = 1;
{
forloop1370:
for (j = 1; j <= n; j++) {
{
forloop1360:
for (i = j; i <= n; i++) {
work[(indx)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
indx = indx+1;
Dummy.label("Ddrvst",1360);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1370);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+2;
Dspevd.dspevd("N",uplo,n,work,_work_offset,d3,_d3_offset,z,_z_offset,ldu,work,(indx)- 1+ _work_offset,lwedc-indx+1,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSPEVD(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1390);
}              //  Close else.
}              // Close if()
// *
// *              Do test 57 (or 102).
// *
temp1 = zero;
temp2 = zero;
{
forloop1380:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",1380);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
label1390:
   Dummy.label("Ddrvst",1390);
// *
// *              9)      Call DSBEVD.
// *
if (jtype <= 7)  {
    kd = 1;
}              // Close if()
else if (jtype >= 8 && jtype <= 15)  {
    kd = (int)(Math.max(n-1, 0) );
}              // Close else if()
else  {
  kd = ihbw;
}              //  Close else.
// *
// *              Load array V with the upper or lower triangular part
// *              of the matrix in band form.
// *
if (iuplo == 1)  {
    {
forloop1410:
for (j = 1; j <= n; j++) {
{
forloop1400:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1400);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1410);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1430:
for (j = 1; j <= n; j++) {
{
forloop1420:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1420);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1430);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+1;
Dsbevd.dsbevd("V",uplo,n,kd,v,_v_offset,ldu,d1,_d1_offset,z,_z_offset,ldu,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVD(V,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
result[(ntest+1)- 1+ _result_offset] = ulpinv;
result[(ntest+2)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1490);
}              //  Close else.
}              // Close if()
// *
// *              Do tests 58 and 59 (or 103 and 104).
// *
Dsyt21.dsyt21(1,uplo,n,0,a,_a_offset,lda,d1,_d1_offset,d2,_d2_offset,z,_z_offset,ldu,v,_v_offset,ldu,tau,_tau_offset,work,_work_offset,result,(ntest)- 1+ _result_offset);
// *
if (iuplo == 1)  {
    {
forloop1450:
for (j = 1; j <= n; j++) {
{
forloop1440:
for (i = (int)(Math.max(1, j-kd) ); i <= j; i++) {
v[(kd+1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1440);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1450);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop1470:
for (j = 1; j <= n; j++) {
{
forloop1460:
for (i = j; i <= Math.min(n, j+kd) ; i++) {
v[(1+i-j)- 1+(j- 1)*ldu+ _v_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Ddrvst",1460);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1470);
}              //  Close for() loop. 
}
}              //  Close else.
// *
ntest = ntest+2;
Dsbevd.dsbevd("N",uplo,n,kd,v,_v_offset,ldu,d3,_d3_offset,z,_z_offset,ldu,work,_work_offset,lwedc,iwork,_iwork_offset,liwedc,iinfo);
if (iinfo.val != 0)  {
    System.out.println(" DDRVST: "  + ("DSBEVD(N,"+uplo+")") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (ioldsd) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
info.val = (int)(Math.abs(iinfo.val));
if (iinfo.val < 0)  {
    Dummy.go_to("Ddrvst",999999);
}              // Close if()
else  {
  result[(ntest)- 1+ _result_offset] = ulpinv;
Dummy.go_to("Ddrvst",1490);
}              //  Close else.
}              // Close if()
// *
// *              Do test 60 (or 105).
// *
temp1 = zero;
temp2 = zero;
{
forloop1480:
for (j = 1; j <= n; j++) {
temp1 = Math.max((temp1) > (Math.abs(d1[(j)- 1+ _d1_offset])) ? (temp1) : (Math.abs(d1[(j)- 1+ _d1_offset])), Math.abs(d3[(j)- 1+ _d3_offset]));
temp2 = Math.max(temp2, Math.abs(d1[(j)- 1+ _d1_offset]-d3[(j)- 1+ _d3_offset])) ;
Dummy.label("Ddrvst",1480);
}              //  Close for() loop. 
}
result[(ntest)- 1+ _result_offset] = temp2/Math.max(unfl.val, ulp*Math.max(temp1, temp2) ) ;
// *
label1490:
   Dummy.label("Ddrvst",1490);
// *
Dummy.label("Ddrvst",1500);
}              //  Close for() loop. 
}
// *
// *           End of Loop -- Check for RESULT(j) > THRESH
// *
ntestt = ntestt+ntest;
Dlafts.dlafts("DST",n,n,jtype,ntest,result,_result_offset,ioldsd,0,thresh,nounit,nerrs);
// *
Dummy.label("Ddrvst",1510);
}              //  Close for() loop. 
}
Dummy.label("Ddrvst",1520);
}              //  Close for() loop. 
}
// *
// *     Summary
// *
Alasvm.alasvm("DST",nounit,nerrs.val,ntestt,0);
// *
// *
Dummy.go_to("Ddrvst",999999);
// *
// *     End of DDRVST
// *
Dummy.label("Ddrvst",999999);
return;
   }
} // End class.
