/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrbd {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRBD tests the error exits for DGEBRD, DORGBR, DORMBR, and DBDSQR.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
static int lw= nmax;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static int nt= 0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nmax) * (nmax)];
static double [] d= new double[(nmax)];
static double [] e= new double[(nmax)];
static double [] tp= new double[(nmax)];
static double [] tq= new double[(nmax)];
static double [] u= new double[(nmax) * (nmax)];
static double [] v= new double[(nmax) * (nmax)];
static double [] w= new double[(lw)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrbd (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrbd",10);
}              //  Close for() loop. 
}
Dummy.label("Derrbd",20);
}              //  Close for() loop. 
}
eigtest_infoc.ok.val = true;
nt = 0;
// *
// *     Test error exits of the SVD routines.
// *
if (c2.regionMatches(true,0,"BD",0,2))  {
    // *
// *        DGEBRD
// *
eigtest_srnamc.srnamt = "DGEBRD";
eigtest_infoc.infot = 1;
Dgebrd.dgebrd(-1,0,a,0,1,d,0,e,0,tq,0,tp,0,w,0,1,info);
Chkxer.chkxer("DGEBRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgebrd.dgebrd(0,-1,a,0,1,d,0,e,0,tq,0,tp,0,w,0,1,info);
Chkxer.chkxer("DGEBRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgebrd.dgebrd(2,1,a,0,1,d,0,e,0,tq,0,tp,0,w,0,2,info);
Chkxer.chkxer("DGEBRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dgebrd.dgebrd(2,1,a,0,2,d,0,e,0,tq,0,tp,0,w,0,1,info);
Chkxer.chkxer("DGEBRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+4;
// *
// *        DGEBD2
// *
eigtest_srnamc.srnamt = "DGEBD2";
eigtest_infoc.infot = 1;
Dgebd2.dgebd2(-1,0,a,0,1,d,0,e,0,tq,0,tp,0,w,0,info);
Chkxer.chkxer("DGEBD2",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgebd2.dgebd2(0,-1,a,0,1,d,0,e,0,tq,0,tp,0,w,0,info);
Chkxer.chkxer("DGEBD2",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgebd2.dgebd2(2,1,a,0,1,d,0,e,0,tq,0,tp,0,w,0,info);
Chkxer.chkxer("DGEBD2",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DORGBR
// *
eigtest_srnamc.srnamt = "DORGBR";
eigtest_infoc.infot = 1;
Dorgbr.dorgbr("/",0,0,0,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dorgbr.dorgbr("Q",-1,0,0,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorgbr.dorgbr("Q",0,-1,0,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorgbr.dorgbr("Q",0,1,0,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorgbr.dorgbr("Q",1,0,1,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorgbr.dorgbr("P",1,0,0,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorgbr.dorgbr("P",0,1,1,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dorgbr.dorgbr("Q",0,0,-1,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dorgbr.dorgbr("Q",2,1,1,a,0,1,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dorgbr.dorgbr("Q",2,2,1,a,0,2,tq,0,w,0,1,info);
Chkxer.chkxer("DORGBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *        DORMBR
// *
eigtest_srnamc.srnamt = "DORMBR";
eigtest_infoc.infot = 1;
Dormbr.dormbr("/","L","T",0,0,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dormbr.dormbr("Q","/","T",0,0,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dormbr.dormbr("Q","L","/",0,0,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dormbr.dormbr("Q","L","T",-1,0,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormbr.dormbr("Q","L","T",0,-1,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dormbr.dormbr("Q","L","T",0,0,-1,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormbr.dormbr("Q","L","T",2,0,0,a,0,1,tq,0,u,0,2,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormbr.dormbr("Q","R","T",0,2,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormbr.dormbr("P","L","T",2,0,2,a,0,1,tq,0,u,0,2,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormbr.dormbr("P","R","T",0,2,2,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dormbr.dormbr("Q","R","T",2,0,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dormbr.dormbr("Q","L","T",0,2,0,a,0,1,tq,0,u,0,1,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dormbr.dormbr("Q","R","T",2,0,0,a,0,1,tq,0,u,0,2,w,0,1,info);
Chkxer.chkxer("DORMBR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+13;
// *
// *        DBDSQR
// *
eigtest_srnamc.srnamt = "DBDSQR";
eigtest_infoc.infot = 1;
Dbdsqr.dbdsqr("/",0,0,0,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dbdsqr.dbdsqr("U",-1,0,0,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dbdsqr.dbdsqr("U",0,-1,0,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dbdsqr.dbdsqr("U",0,0,-1,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dbdsqr.dbdsqr("U",0,0,0,-1,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dbdsqr.dbdsqr("U",2,1,0,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dbdsqr.dbdsqr("U",0,0,2,0,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dbdsqr.dbdsqr("U",2,0,0,1,d,0,e,0,v,0,1,u,0,1,a,0,1,w,0,info);
Chkxer.chkxer("DBDSQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
}              // Close if()
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits"  + " ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
// *
Dummy.go_to("Derrbd",999999);
// *
// *     End of DERRBD
// *
Dummy.label("Derrbd",999999);
return;
   }
} // End class.
