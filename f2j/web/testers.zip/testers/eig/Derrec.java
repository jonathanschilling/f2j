/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrec {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERREC tests the error exits for the routines for eigen- condition
// *  estimation for DOUBLE PRECISION matrices:
// *     DTRSYL, STREXC, STRSNA and STRSEN.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static intW m= new intW(0);
static int nt= 0;
static doubleW scale= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static boolean [] sel= new boolean[(nmax)];
static int [] iwork= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax) * (nmax)];
static double [] c= new double[(nmax) * (nmax)];
static double [] s= new double[(nmax)];
static double [] sep= new double[(nmax)];
static double [] wi= new double[(nmax)];
static double [] work= new double[(nmax)];
static double [] wr= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrec (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
eigtest_infoc.ok.val = true;
nt = 0;
// *
// *     Initialize A, B and SEL
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = zero;
b[(i)- 1+(j- 1)*nmax] = zero;
Dummy.label("Derrec",10);
}              //  Close for() loop. 
}
Dummy.label("Derrec",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(i- 1)*nmax] = one;
sel[(i)- 1] = true;
Dummy.label("Derrec",30);
}              //  Close for() loop. 
}
// *
// *     Test DTRSYL
// *
eigtest_srnamc.srnamt = "DTRSYL";
eigtest_infoc.infot = 1;
Dtrsyl.dtrsyl("X","N",1,0,0,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dtrsyl.dtrsyl("N","X",1,0,0,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dtrsyl.dtrsyl("N","N",0,0,0,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtrsyl.dtrsyl("N","N",1,-1,0,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dtrsyl.dtrsyl("N","N",1,0,-1,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dtrsyl.dtrsyl("N","N",1,2,0,a,0,1,b,0,1,c,0,2,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dtrsyl.dtrsyl("N","N",1,0,2,a,0,1,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dtrsyl.dtrsyl("N","N",1,2,0,a,0,2,b,0,1,c,0,1,scale,info);
Chkxer.chkxer("DTRSYL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test DTREXC
// *
eigtest_srnamc.srnamt = "DTREXC";
eigtest_infoc.infot = 1;
Dtrexc.dtrexc("X",1,a,0,1,b,0,1,new intW(1),new intW(1),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dtrexc.dtrexc("N",0,a,0,1,b,0,1,new intW(1),new intW(1),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtrexc.dtrexc("N",2,a,0,1,b,0,1,new intW(1),new intW(2),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dtrexc.dtrexc("V",2,a,0,2,b,0,1,new intW(1),new intW(2),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dtrexc.dtrexc("V",1,a,0,1,b,0,1,new intW(0),new intW(1),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dtrexc.dtrexc("V",1,a,0,1,b,0,1,new intW(2),new intW(1),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dtrexc.dtrexc("V",1,a,0,1,b,0,1,new intW(1),new intW(0),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dtrexc.dtrexc("V",1,a,0,1,b,0,1,new intW(1),new intW(2),work,0,info);
Chkxer.chkxer("DTREXC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test DTRSNA
// *
eigtest_srnamc.srnamt = "DTRSNA";
eigtest_infoc.infot = 1;
Dtrsna.dtrsna("X","A",sel,0,0,a,0,1,b,0,1,c,0,1,s,0,sep,0,1,m,work,0,1,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dtrsna.dtrsna("B","X",sel,0,0,a,0,1,b,0,1,c,0,1,s,0,sep,0,1,m,work,0,1,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtrsna.dtrsna("B","A",sel,0,-1,a,0,1,b,0,1,c,0,1,s,0,sep,0,1,m,work,0,1,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dtrsna.dtrsna("V","A",sel,0,2,a,0,1,b,0,1,c,0,1,s,0,sep,0,2,m,work,0,2,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dtrsna.dtrsna("B","A",sel,0,2,a,0,2,b,0,1,c,0,2,s,0,sep,0,2,m,work,0,2,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dtrsna.dtrsna("B","A",sel,0,2,a,0,2,b,0,2,c,0,1,s,0,sep,0,2,m,work,0,2,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dtrsna.dtrsna("B","A",sel,0,1,a,0,1,b,0,1,c,0,1,s,0,sep,0,0,m,work,0,1,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dtrsna.dtrsna("B","S",sel,0,2,a,0,2,b,0,2,c,0,2,s,0,sep,0,1,m,work,0,2,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 16;
Dtrsna.dtrsna("B","A",sel,0,2,a,0,2,b,0,2,c,0,2,s,0,sep,0,2,m,work,0,1,iwork,0,info);
Chkxer.chkxer("DTRSNA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *     Test DTRSEN
// *
sel[(1)- 1] = false;
eigtest_srnamc.srnamt = "DTRSEN";
eigtest_infoc.infot = 1;
dtrsen_adapter("X","N",sel,0,0,a,0,1,b,0,1,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
dtrsen_adapter("N","X",sel,0,0,a,0,1,b,0,1,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
dtrsen_adapter("N","N",sel,0,-1,a,0,1,b,0,1,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
dtrsen_adapter("N","N",sel,0,2,a,0,1,b,0,1,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,2,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
dtrsen_adapter("N","V",sel,0,2,a,0,2,b,0,1,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 15;
dtrsen_adapter("N","V",sel,0,2,a,0,2,b,0,2,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,0,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 15;
dtrsen_adapter("E","V",sel,0,3,a,0,3,b,0,3,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 15;
dtrsen_adapter("V","V",sel,0,3,a,0,3,b,0,3,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,3,iwork,0,2,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 17;
dtrsen_adapter("E","V",sel,0,2,a,0,2,b,0,2,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,1,iwork,0,0,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 17;
dtrsen_adapter("V","V",sel,0,3,a,0,3,b,0,3,wr,0,wi,0,m,s,(1)- 1,sep,(1)- 1,work,0,4,iwork,0,1,info);
Chkxer.chkxer("DTRSEN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error ex"  + "its ***" );
}              //  Close else.
// *
Dummy.go_to("Derrec",999999);
// *
// *     End of DERREC
// *
Dummy.label("Derrec",999999);
return;
   }
// adapter for dtrsen
private static void dtrsen_adapter(String arg0 ,String arg1 ,boolean [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,intW arg10 ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset ,double [] arg13 , int arg13_offset ,int arg14 ,int [] arg15 , int arg15_offset ,int arg16 ,intW arg17 )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dtrsen.dtrsen(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9, arg9_offset,arg10,_f2j_tmp11,_f2j_tmp12,arg13, arg13_offset,arg14,arg15, arg15_offset,arg16,arg17);

arg11[arg11_offset] = _f2j_tmp11.val;
arg12[arg12_offset] = _f2j_tmp12.val;
}

} // End class.
