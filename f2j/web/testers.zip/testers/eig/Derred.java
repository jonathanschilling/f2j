/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derred {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRED tests the error exits for the eigenvalue driver routines for
// *  DOUBLE PRECISION matrices:
// *
// *  PATH  driver   description
// *  ----  ------   -----------
// *  SEV   DGEEV    find eigenvalues/eigenvectors for nonsymmetric A
// *  SES   DGEES    find eigenvalues/Schur form for nonsymmetric A
// *  SVX   DGEEVX   SGEEV + balancing and condition estimation
// *  SSX   DGEESX   SGEES + balancing and condition estimation
// *  DBD   DGESVD   compute SVD of an M-by-N matrix A
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW ihi= new intW(0);
static intW ilo= new intW(0);
static intW info= new intW(0);
static int j= 0;
static int nt= 0;
static intW sdim= new intW(0);
static doubleW abnrm= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static boolean [] b= new boolean[(nmax)];
static int [] iw= new int[(2*nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] s= new double[(nmax)];
static double [] u= new double[(nmax) * (nmax)];
static double [] vl= new double[(nmax) * (nmax)];
static double [] vr= new double[(nmax) * (nmax)];
static double [] vt= new double[(nmax) * (nmax)];
static double [] w= new double[(4*nmax)];
static double [] wi= new double[(nmax)];
static double [] wr= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Arrays in Common ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derred (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Initialize A
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = zero;
Dummy.label("Derred",10);
}              //  Close for() loop. 
}
Dummy.label("Derred",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(i- 1)*nmax] = one;
Dummy.label("Derred",30);
}              //  Close for() loop. 
}
eigtest_infoc.ok.val = true;
nt = 0;
// *
if (c2.regionMatches(true,0,"EV",0,2))  {
    // *
// *        Test DGEEV
// *
eigtest_srnamc.srnamt = "DGEEV ";
eigtest_infoc.infot = 1;
Dgeev.dgeev("X","N",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,w,0,1,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgeev.dgeev("N","X",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,w,0,1,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgeev.dgeev("N","N",-1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,w,0,1,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgeev.dgeev("N","N",2,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,w,0,6,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dgeev.dgeev("V","N",2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,w,0,8,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dgeev.dgeev("N","V",2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,w,0,8,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dgeev.dgeev("V","V",1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,w,0,3,info);
Chkxer.chkxer("DGEEV ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
}              // Close if()
else if (c2.regionMatches(true,0,"ES",0,2))  {
    // *
// *        Test DGEES
// *
eigtest_srnamc.srnamt = "DGEES ";
eigtest_infoc.infot = 1;
Dgees.dgees("X","N", new Dslect() ,0,a,0,1,sdim,wr,0,wi,0,vl,0,1,w,0,1,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgees.dgees("N","X", new Dslect() ,0,a,0,1,sdim,wr,0,wi,0,vl,0,1,w,0,1,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgees.dgees("N","S", new Dslect() ,-1,a,0,1,sdim,wr,0,wi,0,vl,0,1,w,0,1,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dgees.dgees("N","S", new Dslect() ,2,a,0,1,sdim,wr,0,wi,0,vl,0,1,w,0,6,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dgees.dgees("V","S", new Dslect() ,2,a,0,2,sdim,wr,0,wi,0,vl,0,1,w,0,6,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dgees.dgees("N","S", new Dslect() ,1,a,0,1,sdim,wr,0,wi,0,vl,0,1,w,0,2,b,0,info);
Chkxer.chkxer("DGEES ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"VX",0,2))  {
    // *
// *        Test DGEEVX
// *
eigtest_srnamc.srnamt = "DGEEVX";
eigtest_infoc.infot = 1;
Dgeevx.dgeevx("X","N","N","N",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgeevx.dgeevx("N","X","N","N",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgeevx.dgeevx("N","N","X","N",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgeevx.dgeevx("N","N","N","X",0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgeevx.dgeevx("N","N","N","N",-1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dgeevx.dgeevx("N","N","N","N",2,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dgeevx.dgeevx("N","V","N","N",2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,6,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dgeevx.dgeevx("N","N","V","N",2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,6,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 21;
Dgeevx.dgeevx("N","N","N","N",1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 21;
Dgeevx.dgeevx("N","V","N","N",1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,2,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 21;
Dgeevx.dgeevx("N","N","V","V",1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,ilo,ihi,s,0,abnrm,r1,0,r2,0,w,0,3,iw,0,info);
Chkxer.chkxer("DGEEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+11;
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SX",0,2))  {
    // *
// *        Test DGEESX
// *
eigtest_srnamc.srnamt = "DGEESX";
eigtest_infoc.infot = 1;
dgeesx_adapter("X","N", new Dslect() ,"N",0,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,1,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
dgeesx_adapter("N","X", new Dslect() ,"N",0,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,1,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
dgeesx_adapter("N","N", new Dslect() ,"X",0,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,1,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
dgeesx_adapter("N","N", new Dslect() ,"N",-1,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,1,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
dgeesx_adapter("N","N", new Dslect() ,"N",2,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,6,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
dgeesx_adapter("V","N", new Dslect() ,"N",2,a,0,2,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,6,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 16;
dgeesx_adapter("N","N", new Dslect() ,"N",1,a,0,1,sdim,wr,0,wi,0,vl,0,1,r1,(1)- 1,r2,(1)- 1,w,0,2,iw,0,1,b,0,info);
Chkxer.chkxer("DGEESX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"BD",0,2))  {
    // *
// *        Test DGESVD
// *
eigtest_srnamc.srnamt = "DGESVD";
eigtest_infoc.infot = 1;
Dgesvd.dgesvd("X","N",0,0,a,0,1,s,0,u,0,1,vt,0,1,w,0,1,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgesvd.dgesvd("N","X",0,0,a,0,1,s,0,u,0,1,vt,0,1,w,0,1,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgesvd.dgesvd("O","O",0,0,a,0,1,s,0,u,0,1,vt,0,1,w,0,1,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgesvd.dgesvd("N","N",-1,0,a,0,1,s,0,u,0,1,vt,0,1,w,0,1,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgesvd.dgesvd("N","N",0,-1,a,0,1,s,0,u,0,1,vt,0,1,w,0,1,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dgesvd.dgesvd("N","N",2,1,a,0,1,s,0,u,0,1,vt,0,1,w,0,5,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dgesvd.dgesvd("A","N",2,1,a,0,2,s,0,u,0,1,vt,0,1,w,0,5,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dgesvd.dgesvd("N","A",1,2,a,0,1,s,0,u,0,1,vt,0,1,w,0,5,info);
Chkxer.chkxer("DGESVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
}              // Close else if()
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (eigtest_srnamc.srnamt) + " "  + " passed the tests of the error exits ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + " NULL " + " "  + " failed the tests of the error exits ***" );
}              //  Close else.
// *
Dummy.go_to("Derred",999999);
// *
// *     End of DERRED
Dummy.label("Derred",999999);
return;
   }
// adapter for dgeesx
private static void dgeesx_adapter(String arg0 ,String arg1 ,Object arg2 ,String arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,intW arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,double [] arg10 , int arg10_offset ,int arg11 ,double [] arg12 , int arg12_offset ,double [] arg13 , int arg13_offset ,double [] arg14 , int arg14_offset ,int arg15 ,int [] arg16 , int arg16_offset ,int arg17 ,boolean [] arg18 , int arg18_offset ,intW arg19 )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);
doubleW _f2j_tmp13 = new doubleW(arg13[arg13_offset]);

Dgeesx.dgeesx(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6,arg7,arg8, arg8_offset,arg9, arg9_offset,arg10, arg10_offset,arg11,_f2j_tmp12,_f2j_tmp13,arg14, arg14_offset,arg15,arg16, arg16_offset,arg17,arg18, arg18_offset,arg19);

arg12[arg12_offset] = _f2j_tmp12.val;
arg13[arg13_offset] = _f2j_tmp13.val;
}

} // End class.
