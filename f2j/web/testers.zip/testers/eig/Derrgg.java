/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrgg {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRGG tests the error exits for DGGGLM, SGGHRD, SGGLSE, SGGQRF,
// *  DGGRQF, SGGSVD, SGGSVP, DHGEQZ, DTGEVC, and STGSJA.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 3;
static int lw= 6*nmax;
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static intW dummyk= new intW(0);
static intW dummyl= new intW(0);
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static intW m= new intW(0);
static intW ncycle= new intW(0);
static int nt= 0;
static double tola= 0.0;
static double tolb= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] sel= new boolean[(nmax)];
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax) * (nmax)];
static double [] q= new double[(nmax) * (nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] r3= new double[(nmax)];
static double [] tau= new double[(nmax)];
static double [] u= new double[(nmax) * (nmax)];
static double [] v= new double[(nmax) * (nmax)];
static double [] w= new double[(lw)];
static double [] z= new double[(nmax) * (nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrgg (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = zero;
b[(i)- 1+(j- 1)*nmax] = zero;
Dummy.label("Derrgg",10);
}              //  Close for() loop. 
}
Dummy.label("Derrgg",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(i- 1)*nmax] = one;
b[(i)- 1+(i- 1)*nmax] = one;
Dummy.label("Derrgg",30);
}              //  Close for() loop. 
}
eigtest_infoc.ok.val = true;
tola = 1.0e0;
tolb = 1.0e0;
nt = 0;
// *
// *     Test error exits for the GG path.
// *
if (c2.regionMatches(true,0,"GG",0,2))  {
    // *
// *        DGGHRD
// *
eigtest_srnamc.srnamt = "DGGHRD";
eigtest_infoc.infot = 1;
Dgghrd.dgghrd("/","N",0,1,0,a,0,1,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgghrd.dgghrd("N","/",0,1,0,a,0,1,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgghrd.dgghrd("N","N",-1,0,0,a,0,1,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgghrd.dgghrd("N","N",0,0,0,a,0,1,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgghrd.dgghrd("N","N",0,1,1,a,0,1,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dgghrd.dgghrd("N","N",2,1,1,a,0,1,b,0,2,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dgghrd.dgghrd("N","N",2,1,1,a,0,2,b,0,1,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dgghrd.dgghrd("V","N",2,1,1,a,0,2,b,0,2,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dgghrd.dgghrd("N","V",2,1,1,a,0,2,b,0,2,q,0,1,z,0,1,info);
Chkxer.chkxer("DGGHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *        DHGEQZ
// *
eigtest_srnamc.srnamt = "DHGEQZ";
eigtest_infoc.infot = 1;
Dhgeqz.dhgeqz("/","N","N",0,1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dhgeqz.dhgeqz("E","/","N",0,1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dhgeqz.dhgeqz("E","N","/",0,1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dhgeqz.dhgeqz("E","N","N",-1,0,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dhgeqz.dhgeqz("E","N","N",0,0,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dhgeqz.dhgeqz("E","N","N",0,1,1,a,0,1,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dhgeqz.dhgeqz("E","N","N",2,1,1,a,0,1,b,0,2,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dhgeqz.dhgeqz("E","N","N",2,1,1,a,0,2,b,0,1,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 15;
Dhgeqz.dhgeqz("E","V","N",2,1,1,a,0,2,b,0,2,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 17;
Dhgeqz.dhgeqz("E","N","V",2,1,1,a,0,2,b,0,2,r1,0,r2,0,r3,0,q,0,1,z,0,1,w,0,lw,info);
Chkxer.chkxer("DHGEQZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *        DTGEVC
// *
eigtest_srnamc.srnamt = "DTGEVC";
eigtest_infoc.infot = 1;
Dtgevc.dtgevc("/","A",sel,0,0,a,0,1,b,0,1,q,0,1,z,0,1,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dtgevc.dtgevc("R","/",sel,0,0,a,0,1,b,0,1,q,0,1,z,0,1,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtgevc.dtgevc("R","A",sel,0,-1,a,0,1,b,0,1,q,0,1,z,0,1,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dtgevc.dtgevc("R","A",sel,0,2,a,0,1,b,0,2,q,0,1,z,0,2,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dtgevc.dtgevc("R","A",sel,0,2,a,0,2,b,0,1,q,0,1,z,0,2,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dtgevc.dtgevc("L","A",sel,0,2,a,0,2,b,0,2,q,0,1,z,0,1,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dtgevc.dtgevc("R","A",sel,0,2,a,0,2,b,0,2,q,0,1,z,0,1,0,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dtgevc.dtgevc("R","A",sel,0,2,a,0,2,b,0,2,q,0,1,z,0,2,1,m,w,0,info);
Chkxer.chkxer("DTGEVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test error exits for the GSV path.
// *
}              // Close if()
else if (path.regionMatches(true,0,"GSV",0,3))  {
    // *
// *        DGGSVD
// *
eigtest_srnamc.srnamt = "DGGSVD";
eigtest_infoc.infot = 1;
Dggsvd.dggsvd("/","N","N",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggsvd.dggsvd("N","/","N",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggsvd.dggsvd("N","N","/",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dggsvd.dggsvd("N","N","N",-1,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dggsvd.dggsvd("N","N","N",0,-1,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dggsvd.dggsvd("N","N","N",0,0,-1,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dggsvd.dggsvd("N","N","N",0,0,0,dummyk,dummyl,a,0,0,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dggsvd.dggsvd("N","N","N",0,0,0,dummyk,dummyl,a,0,1,b,0,0,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 16;
Dggsvd.dggsvd("U","N","N",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,0,v,0,1,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 18;
Dggsvd.dggsvd("N","V","N",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,0,q,0,1,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 20;
Dggsvd.dggsvd("N","N","Q",0,0,0,dummyk,dummyl,a,0,1,b,0,1,r1,0,r2,0,u,0,1,v,0,1,q,0,0,w,0,iw,0,info);
Chkxer.chkxer("DGGSVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+11;
// *
// *        DGGSVP
// *
eigtest_srnamc.srnamt = "DGGSVP";
eigtest_infoc.infot = 1;
Dggsvp.dggsvp("/","N","N",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggsvp.dggsvp("N","/","N",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggsvp.dggsvp("N","N","/",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dggsvp.dggsvp("N","N","N",-1,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dggsvp.dggsvp("N","N","N",0,-1,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dggsvp.dggsvp("N","N","N",0,0,-1,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dggsvp.dggsvp("N","N","N",0,0,0,a,0,0,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dggsvp.dggsvp("N","N","N",0,0,0,a,0,1,b,0,0,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 16;
Dggsvp.dggsvp("U","N","N",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,0,v,0,1,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 18;
Dggsvp.dggsvp("N","V","N",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,0,q,0,1,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 20;
Dggsvp.dggsvp("N","N","Q",0,0,0,a,0,1,b,0,1,tola,tolb,dummyk,dummyl,u,0,1,v,0,1,q,0,0,iw,0,tau,0,w,0,info);
Chkxer.chkxer("DGGSVP",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+11;
// *
// *        DTGSJA
// *
eigtest_srnamc.srnamt = "DTGSJA";
eigtest_infoc.infot = 1;
Dtgsja.dtgsja("/","N","N",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dtgsja.dtgsja("N","/","N",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dtgsja.dtgsja("N","N","/",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtgsja.dtgsja("N","N","N",-1,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dtgsja.dtgsja("N","N","N",0,-1,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dtgsja.dtgsja("N","N","N",0,0,-1,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dtgsja.dtgsja("N","N","N",0,0,0,dummyk.val,dummyl.val,a,0,0,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dtgsja.dtgsja("N","N","N",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,0,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 18;
Dtgsja.dtgsja("U","N","N",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,0,v,0,1,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 20;
Dtgsja.dtgsja("N","V","N",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,0,q,0,1,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 22;
Dtgsja.dtgsja("N","N","Q",0,0,0,dummyk.val,dummyl.val,a,0,1,b,0,1,tola,tolb,r1,0,r2,0,u,0,1,v,0,1,q,0,0,w,0,ncycle,info);
Chkxer.chkxer("DTGSJA",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+11;
// *
// *     Test error exits for the GLM path.
// *
}              // Close else if()
else if (path.regionMatches(true,0,"GLM",0,3))  {
    // *
// *        DGGGLM
// *
eigtest_srnamc.srnamt = "DGGGLM";
eigtest_infoc.infot = 1;
Dggglm.dggglm(-1,0,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggglm.dggglm(0,-1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggglm.dggglm(0,1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggglm.dggglm(0,0,-1,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggglm.dggglm(1,0,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dggglm.dggglm(0,0,0,a,0,0,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dggglm.dggglm(0,0,0,a,0,1,b,0,0,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dggglm.dggglm(1,1,1,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,1,info);
Chkxer.chkxer("DGGGLM",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test error exits for the LSE path.
// *
}              // Close else if()
else if (path.regionMatches(true,0,"LSE",0,3))  {
    // *
// *        DGGLSE
// *
eigtest_srnamc.srnamt = "DGGLSE";
eigtest_infoc.infot = 1;
Dgglse.dgglse(-1,0,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgglse.dgglse(0,-1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgglse.dgglse(0,0,-1,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgglse.dgglse(0,0,1,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgglse.dgglse(0,1,0,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgglse.dgglse(0,0,0,a,0,0,b,0,1,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dgglse.dgglse(0,0,0,a,0,1,b,0,0,r1,0,r2,0,r3,0,w,0,lw,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dgglse.dgglse(1,1,1,a,0,1,b,0,1,r1,0,r2,0,r3,0,w,0,1,info);
Chkxer.chkxer("DGGLSE",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test error exits for the GQR path.
// *
}              // Close else if()
else if (path.regionMatches(true,0,"GQR",0,3))  {
    // *
// *        DGGQRF
// *
eigtest_srnamc.srnamt = "DGGQRF";
eigtest_infoc.infot = 1;
Dggqrf.dggqrf(-1,0,0,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggqrf.dggqrf(0,-1,0,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggqrf.dggqrf(0,0,-1,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dggqrf.dggqrf(0,0,0,a,0,0,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dggqrf.dggqrf(0,0,0,a,0,1,r1,0,b,0,0,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dggqrf.dggqrf(1,1,2,a,0,1,r1,0,b,0,1,r2,0,w,0,1,info);
Chkxer.chkxer("DGGQRF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
// *
// *        DGGRQF
// *
eigtest_srnamc.srnamt = "DGGRQF";
eigtest_infoc.infot = 1;
Dggrqf.dggrqf(-1,0,0,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dggrqf.dggrqf(0,-1,0,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dggrqf.dggrqf(0,0,-1,a,0,1,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dggrqf.dggrqf(0,0,0,a,0,0,r1,0,b,0,1,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dggrqf.dggrqf(0,0,0,a,0,1,r1,0,b,0,0,r2,0,w,0,lw,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dggrqf.dggrqf(1,1,2,a,0,1,r1,0,b,0,1,r2,0,w,0,1,info);
Chkxer.chkxer("DGGRQF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
}              // Close else if()
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
// *
Dummy.go_to("Derrgg",999999);
// *
// *     End of DERRGG
// *
Dummy.label("Derrgg",999999);
return;
   }
} // End class.
