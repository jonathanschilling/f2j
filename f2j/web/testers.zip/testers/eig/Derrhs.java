/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrhs {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRHS tests the error exits for DGEBAK, SGEBAL, SGEHRD, DORGHR,
// *  DORMHR, DHSEQR, SHSEIN, and DTREVC.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 3;
static int lw= (nmax+2)*(nmax+2)+nmax;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW ihi= new intW(0);
static intW ilo= new intW(0);
static intW info= new intW(0);
static int j= 0;
static intW m= new intW(0);
static int nt= 0;
// *     ..
// *     .. Local Arrays ..
static boolean [] sel= new boolean[(nmax)];
static int [] ifaill= new int[(nmax)];
static int [] ifailr= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] c= new double[(nmax) * (nmax)];
static double [] s= new double[(nmax)];
static double [] tau= new double[(nmax)];
static double [] vl= new double[(nmax) * (nmax)];
static double [] vr= new double[(nmax) * (nmax)];
static double [] w= new double[(lw)];
static double [] wi= new double[(nmax)];
static double [] wr= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrhs (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrhs",10);
}              //  Close for() loop. 
}
wi[(j)- 1] = (double)(j);
sel[(j)- 1] = true;
Dummy.label("Derrhs",20);
}              //  Close for() loop. 
}
eigtest_infoc.ok.val = true;
nt = 0;
// *
// *     Test error exits of the nonsymmetric eigenvalue routines.
// *
if (c2.regionMatches(true,0,"HS",0,2))  {
    // *
// *        DGEBAL
// *
eigtest_srnamc.srnamt = "DGEBAL";
eigtest_infoc.infot = 1;
Dgebal.dgebal("/",0,a,0,1,ilo,ihi,s,0,info);
Chkxer.chkxer("DGEBAL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgebal.dgebal("N",-1,a,0,1,ilo,ihi,s,0,info);
Chkxer.chkxer("DGEBAL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgebal.dgebal("N",2,a,0,1,ilo,ihi,s,0,info);
Chkxer.chkxer("DGEBAL",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DGEBAK
// *
eigtest_srnamc.srnamt = "DGEBAK";
eigtest_infoc.infot = 1;
Dgebak.dgebak("/","R",0,1,0,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgebak.dgebak("N","/",0,1,0,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgebak.dgebak("N","R",-1,1,0,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgebak.dgebak("N","R",0,0,0,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dgebak.dgebak("N","R",0,2,0,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgebak.dgebak("N","R",2,2,1,s,0,0,a,0,2,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgebak.dgebak("N","R",0,1,1,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dgebak.dgebak("N","R",0,1,0,s,0,-1,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dgebak.dgebak("N","R",2,1,2,s,0,0,a,0,1,info);
Chkxer.chkxer("DGEBAK",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *        DGEHRD
// *
eigtest_srnamc.srnamt = "DGEHRD";
eigtest_infoc.infot = 1;
Dgehrd.dgehrd(-1,1,1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgehrd.dgehrd(0,0,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dgehrd.dgehrd(0,2,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgehrd.dgehrd(1,1,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dgehrd.dgehrd(0,1,1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dgehrd.dgehrd(2,1,1,a,0,1,tau,0,w,0,2,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dgehrd.dgehrd(2,1,2,a,0,2,tau,0,w,0,1,info);
Chkxer.chkxer("DGEHRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
// *        DORGHR
// *
eigtest_srnamc.srnamt = "DORGHR";
eigtest_infoc.infot = 1;
Dorghr.dorghr(-1,1,1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dorghr.dorghr(0,0,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dorghr.dorghr(0,2,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorghr.dorghr(1,1,0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dorghr.dorghr(0,1,1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dorghr.dorghr(2,1,1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dorghr.dorghr(3,1,3,a,0,3,tau,0,w,0,1,info);
Chkxer.chkxer("DORGHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
// *        DORMHR
// *
eigtest_srnamc.srnamt = "DORMHR";
eigtest_infoc.infot = 1;
Dormhr.dormhr("/","N",0,0,1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dormhr.dormhr("L","/",0,0,1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dormhr.dormhr("L","N",-1,0,1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dormhr.dormhr("L","N",0,-1,1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormhr.dormhr("L","N",0,0,0,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormhr.dormhr("L","N",0,0,2,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormhr.dormhr("L","N",1,2,2,1,a,0,1,tau,0,c,0,1,w,0,2,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormhr.dormhr("R","N",2,1,2,1,a,0,1,tau,0,c,0,2,w,0,2,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dormhr.dormhr("L","N",1,1,1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dormhr.dormhr("L","N",0,1,1,1,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dormhr.dormhr("R","N",1,0,1,1,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormhr.dormhr("L","N",2,1,1,1,a,0,1,tau,0,c,0,2,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dormhr.dormhr("R","N",1,2,1,1,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dormhr.dormhr("L","N",2,1,1,1,a,0,2,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dormhr.dormhr("L","N",1,2,1,1,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dormhr.dormhr("R","N",2,1,1,1,a,0,1,tau,0,c,0,2,w,0,1,info);
Chkxer.chkxer("DORMHR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+16;
// *
// *        DHSEQR
// *
eigtest_srnamc.srnamt = "DHSEQR";
eigtest_infoc.infot = 1;
Dhseqr.dhseqr("/","N",0,1,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dhseqr.dhseqr("E","/",0,1,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dhseqr.dhseqr("E","N",-1,1,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dhseqr.dhseqr("E","N",0,0,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dhseqr.dhseqr("E","N",0,2,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dhseqr.dhseqr("E","N",1,1,0,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dhseqr.dhseqr("E","N",1,1,2,a,0,1,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dhseqr.dhseqr("E","N",2,1,2,a,0,1,wr,0,wi,0,c,0,2,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dhseqr.dhseqr("E","V",2,1,2,a,0,2,wr,0,wi,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DHSEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *        DHSEIN
// *
eigtest_srnamc.srnamt = "DHSEIN";
eigtest_infoc.infot = 1;
Dhsein.dhsein("/","N","N",sel,0,0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,0,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dhsein.dhsein("R","/","N",sel,0,0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,0,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dhsein.dhsein("R","N","/",sel,0,0,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,0,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dhsein.dhsein("R","N","N",sel,0,-1,a,0,1,wr,0,wi,0,vl,0,1,vr,0,1,0,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dhsein.dhsein("R","N","N",sel,0,2,a,0,1,wr,0,wi,0,vl,0,1,vr,0,2,4,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dhsein.dhsein("L","N","N",sel,0,2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,4,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dhsein.dhsein("R","N","N",sel,0,2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,1,4,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 14;
Dhsein.dhsein("R","N","N",sel,0,2,a,0,2,wr,0,wi,0,vl,0,1,vr,0,2,1,m,w,0,ifaill,0,ifailr,0,info);
Chkxer.chkxer("DHSEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *        DTREVC
// *
eigtest_srnamc.srnamt = "DTREVC";
eigtest_infoc.infot = 1;
Dtrevc.dtrevc("/","A",sel,0,0,a,0,1,vl,0,1,vr,0,1,0,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dtrevc.dtrevc("L","/",sel,0,0,a,0,1,vl,0,1,vr,0,1,0,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dtrevc.dtrevc("L","A",sel,0,-1,a,0,1,vl,0,1,vr,0,1,0,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dtrevc.dtrevc("L","A",sel,0,2,a,0,1,vl,0,2,vr,0,1,4,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dtrevc.dtrevc("L","A",sel,0,2,a,0,2,vl,0,1,vr,0,1,4,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dtrevc.dtrevc("R","A",sel,0,2,a,0,2,vl,0,1,vr,0,1,4,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dtrevc.dtrevc("L","A",sel,0,2,a,0,2,vl,0,2,vr,0,1,1,m,w,0,info);
Chkxer.chkxer("DTREVC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
}              // Close if()
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits"  + " ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
// *
Dummy.go_to("Derrhs",999999);
// *
// *     End of DERRHS
// *
Dummy.label("Derrhs",999999);
return;
   }
} // End class.
