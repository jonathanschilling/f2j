/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrst {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRST tests the error exits for DSYTRD, DORGTR, DORMTR, DSPTRD,
// *  DOPGTR, DOPMTR, DSTEQR, SSTERF, SSTEBZ, SSTEIN, DPTEQR, DSBTRD,
// *  DSYEV, SSYEVX, SSYEVD, DSBEV, SSBEVX, SSBEVD,
// *  DSPEV, SSPEVX, SSPEVD, DSTEV, SSTEVX, SSTEVD, and SSTEDC.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 3;
static int liw= 3*nmax;
static int lw= 4*nmax;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static int il= 0;
static intW info= new intW(0);
static int iu= 0;
static int j= 0;
static int kd= 0;
static intW m= new intW(0);
static intW nsplit= new intW(0);
static int nt= 0;
static double tol= 0.0;
static double vl= 0.0;
static double vu= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] i1= new int[(nmax)];
static int [] i2= new int[(nmax)];
static int [] i3= new int[(nmax)];
static int [] iw= new int[(liw)];
static double [] a= new double[(nmax) * (nmax)];
static double [] c= new double[(nmax) * (nmax)];
static double [] d= new double[(nmax)];
static double [] e= new double[(nmax)];
static double [] q= new double[(nmax) * (nmax)];
static double [] tau= new double[(nmax)];
static double [] w= new double[(lw)];
static double [] x= new double[(nmax)];
static double [] z= new double[(nmax) * (nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrst (String path,
int nunit)  {

eigtest_infoc.nout_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrst",10);
}              //  Close for() loop. 
}
Dummy.label("Derrst",20);
}              //  Close for() loop. 
}
eigtest_infoc.ok.val = true;
nt = 0;
// *
// *     Test error exits for the ST path.
// *
if (c2.regionMatches(true,0,"ST",0,2))  {
    // *
// *        DSYTRD
// *
eigtest_srnamc.srnamt = "DSYTRD";
eigtest_infoc.infot = 1;
Dsytrd.dsytrd("/",0,a,0,1,d,0,e,0,tau,0,w,0,1,info);
Chkxer.chkxer("DSYTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsytrd.dsytrd("U",-1,a,0,1,d,0,e,0,tau,0,w,0,1,info);
Chkxer.chkxer("DSYTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dsytrd.dsytrd("U",2,a,0,1,d,0,e,0,tau,0,w,0,1,info);
Chkxer.chkxer("DSYTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DORGTR
// *
eigtest_srnamc.srnamt = "DORGTR";
eigtest_infoc.infot = 1;
Dorgtr.dorgtr("/",0,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dorgtr.dorgtr("U",-1,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dorgtr.dorgtr("U",2,a,0,1,tau,0,w,0,1,info);
Chkxer.chkxer("DORGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dorgtr.dorgtr("U",3,a,0,3,tau,0,w,0,1,info);
Chkxer.chkxer("DORGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+4;
// *
// *        DORMTR
// *
eigtest_srnamc.srnamt = "DORMTR";
eigtest_infoc.infot = 1;
Dormtr.dormtr("/","U","N",0,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dormtr.dormtr("L","/","N",0,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dormtr.dormtr("L","U","/",0,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dormtr.dormtr("L","U","N",-1,0,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dormtr.dormtr("L","U","N",0,-1,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dormtr.dormtr("L","U","N",2,0,a,0,1,tau,0,c,0,2,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dormtr.dormtr("R","U","N",0,2,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dormtr.dormtr("L","U","N",2,0,a,0,2,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dormtr.dormtr("L","U","N",0,2,a,0,1,tau,0,c,0,1,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dormtr.dormtr("R","U","N",2,0,a,0,1,tau,0,c,0,2,w,0,1,info);
Chkxer.chkxer("DORMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *        DSPTRD
// *
eigtest_srnamc.srnamt = "DSPTRD";
eigtest_infoc.infot = 1;
Dsptrd.dsptrd("/",0,a,0,d,0,e,0,tau,0,info);
Chkxer.chkxer("DSPTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsptrd.dsptrd("U",-1,a,0,d,0,e,0,tau,0,info);
Chkxer.chkxer("DSPTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+2;
// *
// *        DOPGTR
// *
eigtest_srnamc.srnamt = "DOPGTR";
eigtest_infoc.infot = 1;
Dopgtr.dopgtr("/",0,a,0,tau,0,z,0,1,w,0,info);
Chkxer.chkxer("DOPGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dopgtr.dopgtr("U",-1,a,0,tau,0,z,0,1,w,0,info);
Chkxer.chkxer("DOPGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dopgtr.dopgtr("U",2,a,0,tau,0,z,0,1,w,0,info);
Chkxer.chkxer("DOPGTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DOPMTR
// *
eigtest_srnamc.srnamt = "DOPMTR";
eigtest_infoc.infot = 1;
Dopmtr.dopmtr("/","U","N",0,0,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dopmtr.dopmtr("L","/","N",0,0,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dopmtr.dopmtr("L","U","/",0,0,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dopmtr.dopmtr("L","U","N",-1,0,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dopmtr.dopmtr("L","U","N",0,-1,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dopmtr.dopmtr("L","U","N",2,0,a,0,tau,0,c,0,1,w,0,info);
Chkxer.chkxer("DOPMTR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
// *
// *        DPTEQR
// *
eigtest_srnamc.srnamt = "DPTEQR";
eigtest_infoc.infot = 1;
Dpteqr.dpteqr("/",0,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DPTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dpteqr.dpteqr("N",-1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DPTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dpteqr.dpteqr("V",2,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DPTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DSTEBZ
// *
eigtest_srnamc.srnamt = "DSTEBZ";
eigtest_infoc.infot = 1;
Dstebz.dstebz("/","E",0,vl,vu,il,iu,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dstebz.dstebz("A","/",0,vl,vu,il,iu,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dstebz.dstebz("A","E",-1,vl,vu,il,iu,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dstebz.dstebz("V","E",0,0.0e0,0.0e0,il,iu,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dstebz.dstebz("I","E",0,vl,vu,0,0,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dstebz.dstebz("I","E",1,vl,vu,1,0,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dstebz.dstebz("I","E",0,vl,vu,1,1,tol,d,0,e,0,m,nsplit,x,0,i1,0,i2,0,w,0,iw,0,info);
Chkxer.chkxer("DSTEBZ",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
// *        DSTEIN
// *
eigtest_srnamc.srnamt = "DSTEIN";
eigtest_infoc.infot = 1;
Dstein.dstein(-1,d,0,e,0,0,x,0,i1,0,i2,0,z,0,1,w,0,iw,0,i3,0,info);
Chkxer.chkxer("DSTEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dstein.dstein(0,d,0,e,0,-1,x,0,i1,0,i2,0,z,0,1,w,0,iw,0,i3,0,info);
Chkxer.chkxer("DSTEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dstein.dstein(0,d,0,e,0,1,x,0,i1,0,i2,0,z,0,1,w,0,iw,0,i3,0,info);
Chkxer.chkxer("DSTEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dstein.dstein(2,d,0,e,0,0,x,0,i1,0,i2,0,z,0,1,w,0,iw,0,i3,0,info);
Chkxer.chkxer("DSTEIN",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+4;
// *
// *        DSTEQR
// *
eigtest_srnamc.srnamt = "DSTEQR";
eigtest_infoc.infot = 1;
Dsteqr.dsteqr("/",0,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsteqr.dsteqr("N",-1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dsteqr.dsteqr("V",2,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEQR",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DSTERF
// *
eigtest_srnamc.srnamt = "DSTERF";
eigtest_infoc.infot = 1;
Dsterf.dsterf(-1,d,0,e,0,info);
Chkxer.chkxer("DSTERF",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+1;
// *
// *        DSTEDC
// *
eigtest_srnamc.srnamt = "DSTEDC";
eigtest_infoc.infot = 1;
Dstedc.dstedc("/",0,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dstedc.dstedc("N",-1,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dstedc.dstedc("V",2,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstedc.dstedc("V",2,d,0,e,0,z,0,2,w,0,-1,iw,0,1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstedc.dstedc("I",2,d,0,e,0,z,0,2,w,0,1,iw,0,1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstedc.dstedc("V",2,d,0,e,0,z,0,2,w,0,1,iw,0,1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dstedc.dstedc("V",2,d,0,e,0,z,0,2,w,0,1000,iw,0,-1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dstedc.dstedc("I",2,d,0,e,0,z,0,2,w,0,1000,iw,0,1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dstedc.dstedc("V",2,d,0,e,0,z,0,2,w,0,1000,iw,0,1,info);
Chkxer.chkxer("DSTEDC",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *        DSTEVD
// *
eigtest_srnamc.srnamt = "DSTEVD";
eigtest_infoc.infot = 1;
Dstevd.dstevd("/",0,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dstevd.dstevd("N",-1,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dstevd.dstevd("V",2,d,0,e,0,z,0,1,w,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstevd.dstevd("V",2,d,0,e,0,z,0,2,w,0,-1,iw,0,1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstevd.dstevd("V",2,d,0,e,0,z,0,2,w,0,1,iw,0,1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dstevd.dstevd("V",2,d,0,e,0,z,0,2,w,0,1000,iw,0,-1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dstevd.dstevd("V",2,d,0,e,0,z,0,2,w,0,1000,iw,0,1,info);
Chkxer.chkxer("DSTEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
// *        DSTEV
// *
eigtest_srnamc.srnamt = "DSTEV";
eigtest_infoc.infot = 1;
Dstev.dstev("/",0,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dstev.dstev("N",-1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dstev.dstev("V",2,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSTEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+3;
// *
// *        DSTEVX
// *
eigtest_srnamc.srnamt = "DSTEVX";
eigtest_infoc.infot = 1;
Dstevx.dstevx("/","A",0,d,0,e,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dstevx.dstevx("V","/",0,d,0,e,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dstevx.dstevx("V","A",-1,d,0,e,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dstevx.dstevx("V","V",1,d,0,e,0,0.0e0,0.0e0,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dstevx.dstevx("V","I",1,d,0,e,0,0.0e0,0.0e0,0,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dstevx.dstevx("V","I",2,d,0,e,0,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 14;
Dstevx.dstevx("V","I",1,d,0,e,0,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,0,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSTEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+7;
// *
// *        DSYEVD
// *
eigtest_srnamc.srnamt = "DSYEVD";
eigtest_infoc.infot = 1;
Dsyevd.dsyevd("/","U",0,a,0,1,w,0,x,0,lw,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsyevd.dsyevd("N","/",0,a,0,1,w,0,x,0,lw,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsyevd.dsyevd("N","U",-1,a,0,1,w,0,x,0,lw,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dsyevd.dsyevd("N","U",2,a,0,1,w,0,x,0,lw,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dsyevd.dsyevd("N","U",1,a,0,2,w,0,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dsyevd.dsyevd("N","U",2,a,0,2,w,0,x,0,1,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dsyevd.dsyevd("V","U",2,a,0,2,w,0,x,0,1,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dsyevd.dsyevd("N","U",1,a,0,2,w,0,x,0,1000,iw,0,-1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dsyevd.dsyevd("N","U",2,a,0,2,w,0,x,0,1000,iw,0,0,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dsyevd.dsyevd("V","U",2,a,0,2,w,0,x,0,1000,iw,0,1,info);
Chkxer.chkxer("DSYEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *        DSYEV
// *
eigtest_srnamc.srnamt = "DSYEV";
eigtest_infoc.infot = 1;
Dsyev.dsyev("/","U",0,a,0,1,w,0,x,0,lw,info);
Chkxer.chkxer("DSYEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsyev.dsyev("N","/",0,a,0,1,w,0,x,0,lw,info);
Chkxer.chkxer("DSYEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsyev.dsyev("N","U",-1,a,0,1,w,0,x,0,lw,info);
Chkxer.chkxer("DSYEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dsyev.dsyev("N","U",2,a,0,1,w,0,x,0,lw,info);
Chkxer.chkxer("DSYEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dsyev.dsyev("N","U",2,a,0,2,w,0,x,0,0,info);
Chkxer.chkxer("DSYEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+5;
// *
// *        DSYEVX
// *
eigtest_srnamc.srnamt = "DSYEVX";
eigtest_infoc.infot = 1;
Dsyevx.dsyevx("/","A","U",0,a,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsyevx.dsyevx("V","/","U",0,a,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsyevx.dsyevx("V","A","/",-1,a,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
eigtest_infoc.infot = 4;
Dsyevx.dsyevx("V","A","U",-1,a,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dsyevx.dsyevx("V","A","U",2,a,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dsyevx.dsyevx("V","V","U",1,a,0,1,0.0e0,0.0e0,il,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dsyevx.dsyevx("V","I","U",1,a,0,1,0.0e0,0.0e0,0,iu,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dsyevx.dsyevx("V","I","U",2,a,0,2,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,1,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 15;
Dsyevx.dsyevx("V","I","U",1,a,0,1,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,0,x,0,lw,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 17;
Dsyevx.dsyevx("V","I","U",1,a,0,1,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,1,x,0,0,iw,0,i1,0,info);
Chkxer.chkxer("DSYEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+10;
// *
// *        DSPEVD
// *
eigtest_srnamc.srnamt = "DSPEVD";
eigtest_infoc.infot = 1;
Dspevd.dspevd("/","U",0,a,0,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dspevd.dspevd("N","/",0,a,0,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dspevd.dspevd("N","U",-1,a,0,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dspevd.dspevd("V","U",2,a,0,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dspevd.dspevd("N","U",2,a,0,w,0,z,0,2,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dspevd.dspevd("N","U",2,a,0,w,0,z,0,2,x,0,1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dspevd.dspevd("V","U",2,a,0,w,0,z,0,2,x,0,1,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dspevd.dspevd("N","U",1,a,0,w,0,z,0,2,x,0,1000,iw,0,-1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dspevd.dspevd("N","U",2,a,0,w,0,z,0,2,x,0,1000,iw,0,0,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dspevd.dspevd("V","U",2,a,0,w,0,z,0,2,x,0,1000,iw,0,1,info);
Chkxer.chkxer("DSPEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+9;
// *
// *        DSPEV
// *
eigtest_srnamc.srnamt = "DSPEV";
eigtest_infoc.infot = 1;
Dspev.dspev("/","U",0,a,0,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSPEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dspev.dspev("N","/",0,a,0,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSPEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dspev.dspev("N","U",-1,a,0,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSPEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dspev.dspev("V","U",2,a,0,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSPEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+4;
// *
// *        DSPEVX
// *
eigtest_srnamc.srnamt = "DSPEVX";
eigtest_infoc.infot = 1;
Dspevx.dspevx("/","A","U",0,a,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dspevx.dspevx("V","/","U",0,a,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dspevx.dspevx("V","A","/",-1,a,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
eigtest_infoc.infot = 4;
Dspevx.dspevx("V","A","U",-1,a,0,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dspevx.dspevx("V","V","U",1,a,0,0.0e0,0.0e0,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 8;
Dspevx.dspevx("V","I","U",1,a,0,0.0e0,0.0e0,0,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dspevx.dspevx("V","I","U",2,a,0,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 14;
Dspevx.dspevx("V","I","U",1,a,0,0.0e0,0.0e0,2,1,tol,m,w,0,z,0,0,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSPEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+8;
// *
// *     Test error exits for the SB path.
// *
}              // Close if()
else if (c2.regionMatches(true,0,"SB",0,2))  {
    // *
// *        DSBTRD
// *
eigtest_srnamc.srnamt = "DSBTRD";
eigtest_infoc.infot = 1;
Dsbtrd.dsbtrd("/","U",0,0,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsbtrd.dsbtrd("N","/",0,0,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsbtrd.dsbtrd("N","U",-1,0,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dsbtrd.dsbtrd("N","U",0,-1,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dsbtrd.dsbtrd("N","U",1,1,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 10;
Dsbtrd.dsbtrd("V","U",2,0,a,0,1,d,0,e,0,z,0,1,w,0,info);
Chkxer.chkxer("DSBTRD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
// *
// *        DSBEVD
// *
eigtest_srnamc.srnamt = "DSBEVD";
eigtest_infoc.infot = 1;
Dsbevd.dsbevd("/","U",0,kd,a,0,1,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsbevd.dsbevd("N","/",0,kd,a,0,1,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsbevd.dsbevd("N","U",-1,kd,a,0,1,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dsbevd.dsbevd("N","U",1,-1,a,0,1,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dsbevd.dsbevd("N","U",2,1,a,0,1,w,0,z,0,1,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dsbevd.dsbevd("N","U",2,1,a,0,5,w,0,z,0,0,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dsbevd.dsbevd("N","U",1,1,a,0,5,w,0,z,0,2,x,0,-1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dsbevd.dsbevd("N","U",2,1,a,0,5,w,0,z,0,2,x,0,0,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dsbevd.dsbevd("V","U",2,1,a,0,5,w,0,z,0,2,x,0,1,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dsbevd.dsbevd("N","U",1,1,a,0,5,w,0,z,0,2,x,0,1000,iw,0,-1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dsbevd.dsbevd("N","U",2,1,a,0,5,w,0,z,0,2,x,0,1000,iw,0,0,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dsbevd.dsbevd("V","U",2,1,a,0,5,w,0,z,0,2,x,0,1000,iw,0,1,info);
Chkxer.chkxer("DSBEVD",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+12;
// *
// *        DSBEV
// *
eigtest_srnamc.srnamt = "DSBEV";
eigtest_infoc.infot = 1;
Dsbev.dsbev("/","U",0,kd,a,0,1,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsbev.dsbev("N","/",0,kd,a,0,1,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsbev.dsbev("N","U",-1,kd,a,0,1,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 4;
Dsbev.dsbev("N","U",2,-1,a,0,1,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 6;
Dsbev.dsbev("N","U",2,1,a,0,1,w,0,z,0,1,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dsbev.dsbev("N","U",2,1,a,0,5,w,0,z,0,0,x,0,info);
Chkxer.chkxer("DSBEV",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+6;
// *
// *        DSBEVX
// *
eigtest_srnamc.srnamt = "DSBEVX";
eigtest_infoc.infot = 1;
Dsbevx.dsbevx("/","A","U",0,kd,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 2;
Dsbevx.dsbevx("V","/","U",0,kd,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 3;
Dsbevx.dsbevx("V","A","/",-1,kd,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
eigtest_infoc.infot = 4;
Dsbevx.dsbevx("V","A","U",-1,kd,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 5;
Dsbevx.dsbevx("V","A","U",2,-1,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 7;
Dsbevx.dsbevx("V","A","U",2,1,a,0,1,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 9;
Dsbevx.dsbevx("V","A","U",2,1,a,0,5,q,0,1,vl,vu,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 11;
Dsbevx.dsbevx("V","V","U",1,1,a,0,5,q,0,1,0.0e0,0.0e0,il,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 12;
Dsbevx.dsbevx("V","I","U",1,1,a,0,5,q,0,1,0.0e0,0.0e0,0,iu,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 13;
Dsbevx.dsbevx("V","I","U",1,1,a,0,5,q,0,1,0.0e0,0.0e0,1,2,tol,m,w,0,z,0,1,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
eigtest_infoc.infot = 18;
Dsbevx.dsbevx("V","I","U",1,1,a,0,5,q,0,1,0.0e0,0.0e0,1,1,tol,m,w,0,z,0,0,x,0,iw,0,i1,0,info);
Chkxer.chkxer("DSBEVX",eigtest_infoc.infot,eigtest_infoc.nout_nunit,eigtest_infoc.lerr,eigtest_infoc.ok);
nt = nt+11;
}              // Close else if()
// *
// *     Print a summary line.
// *
if (eigtest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits"  + " ("  + (nt) + " "  + " tests done)" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
// *
Dummy.go_to("Derrst",999999);
// *
// *     End of DERRST
// *
Dummy.label("Derrst",999999);
return;
   }
} // End class.
