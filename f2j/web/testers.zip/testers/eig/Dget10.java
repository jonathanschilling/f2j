/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget10 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET10 compares two matrices A and B and computes the ratio
// *  RESULT = norm( A - B ) / ( norm(A) * M * EPS )
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrices A and B.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m by n matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,N)
// *          The m by n matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION
// *          RESULT = norm( A - B ) / ( norm(A) * M * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double unfl= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dget10 (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
doubleW result)  {

if (m <= 0 || n <= 0)  {
    result.val = zero;
Dummy.go_to("Dget10",999999);
}              // Close if()
// *
unfl = Dlamch.dlamch("Safe minimum");
eps = Dlamch.dlamch("Precision");
// *
wnorm = zero;
{
forloop10:
for (j = 1; j <= n; j++) {
Dcopy.dcopy(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1,work,_work_offset,1);
Daxpy.daxpy(m,-one,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,_work_offset,1);
wnorm = Math.max(wnorm, Dasum.dasum(n,work,_work_offset,1)) ;
Dummy.label("Dget10",10);
}              //  Close for() loop. 
}
// *
anorm = Math.max(Dlange.dlange("1",m,n,a,_a_offset,lda,work,_work_offset), unfl) ;
// *
if (anorm > wnorm)  {
    result.val = (wnorm/anorm)/(m*eps);
}              // Close if()
else  {
  if (anorm < one)  {
    result.val = (Math.min(wnorm, m*anorm) /anorm)/(m*eps);
}              // Close if()
else  {
  result.val = Math.min(wnorm/anorm, (double)(m)) /(m*eps);
}              //  Close else.
}              //  Close else.
// *
Dummy.go_to("Dget10",999999);
// *
// *     End of DGET10
// *
Dummy.label("Dget10",999999);
return;
   }
} // End class.
