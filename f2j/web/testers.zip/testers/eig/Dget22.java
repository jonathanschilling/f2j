/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget22 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET22 does an eigenvector check.
// *
// *  The basic test is:
// *
// *     RESULT(1) = | A E  -  E W | / ( |A| |E| ulp )
// *
// *  using the 1-norm.  It also tests the normalization of E:
// *
// *     RESULT(2) = max | m-norm(E(j)) - 1 | / ( n ulp )
// *                  j
// *
// *  where E(j) is the j-th eigenvector, and m-norm is the max-norm of a
// *  vector.  If an eigenvector is complex, as determined from WI(j)
// *  nonzero, then the max-norm of the vector ( er + i*ei ) is the maximum
// *  of
// *     |er(1)| + |ei(1)|, ... , |er(n)| + |ei(n)|
// *
// *  W is a block diagonal matrix, with a 1 by 1 block for each real
// *  eigenvalue and a 2 by 2 block for each complex conjugate pair.
// *  If eigenvalues j and j+1 are a complex conjugate pair, so that
// *  WR(j) = WR(j+1) = wr and WI(j) = - WI(j+1) = wi, then the 2 by 2
// *  block corresponding to the pair will be:
// *
// *     (  wr  wi  )
// *     ( -wi  wr  )
// *
// *  Such a block multiplying an n by 2 matrix ( ur ui ) on the right
// *  will be the same as multiplying  ur + i*ui  by  wr + i*wi.
// *
// *  To handle various schemes for storage of left eigenvectors, there are
// *  options to use A-transpose instead of A, E-transpose instead of E,
// *  and/or W-transpose instead of W.
// *
// *  Arguments
// *  ==========
// *
// *  TRANSA  (input) CHARACTER*1
// *          Specifies whether or not A is transposed.
// *          = 'N':  No transpose
// *          = 'T':  Transpose
// *          = 'C':  Conjugate transpose (= Transpose)
// *
// *  TRANSE  (input) CHARACTER*1
// *          Specifies whether or not E is transposed.
// *          = 'N':  No transpose, eigenvectors are in columns of E
// *          = 'T':  Transpose, eigenvectors are in rows of E
// *          = 'C':  Conjugate transpose (= Transpose)
// *
// *  TRANSW  (input) CHARACTER*1
// *          Specifies whether or not W is transposed.
// *          = 'N':  No transpose
// *          = 'T':  Transpose, use -WI(j) instead of WI(j)
// *          = 'C':  Conjugate transpose, use -WI(j) instead of WI(j)
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The matrix whose eigenvectors are in E.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  E       (input) DOUBLE PRECISION array, dimension (LDE,N)
// *          The matrix of eigenvectors. If TRANSE = 'N', the eigenvectors
// *          are stored in the columns of E, if TRANSE = 'T' or 'C', the
// *          eigenvectors are stored in the rows of E.
// *
// *  LDE     (input) INTEGER
// *          The leading dimension of the array E.  LDE >= max(1,N).
// *
// *  WR      (input) DOUBLE PRECISION array, dimension (N)
// *  WI      (input) DOUBLE PRECISION array, dimension (N)
// *          The real and imaginary parts of the eigenvalues of A.
// *          Purely real eigenvalues are indicated by WI(j) = 0.
// *          Complex conjugate pairs are indicated by WR(j)=WR(j+1) and
// *          WI(j) = - WI(j+1) non-zero; the real part is assumed to be
// *          stored in the j-th row/column and the imaginary part in
// *          the (j+1)-th row/column.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N*(N+1))
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          RESULT(1) = | A E  -  E W | / ( |A| |E| ulp )
// *          RESULT(2) = max | m-norm(E(j)) - 1 | / ( n ulp )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static String norma= new String(" ");
static String norme= new String(" ");
static int iecol= 0;
static int ierow= 0;
static int ince= 0;
static int ipair= 0;
static int itrnse= 0;
static int j= 0;
static int jcol= 0;
static int jvec= 0;
static double anorm= 0.0;
static double enorm= 0.0;
static double enrmax= 0.0;
static double enrmin= 0.0;
static double errnrm= 0.0;
static double temp1= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] wmat= new double[(2) * (2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize RESULT (in case N=0)
// *

public static void dget22 (String transa,
String transe,
String transw,
int n,
double [] a, int _a_offset,
int lda,
double [] e, int _e_offset,
int lde,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
if (n <= 0)  
    Dummy.go_to("Dget22",999999);
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Precision");
// *
itrnse = 0;
ince = 1;
norma = "O";
norme = "O";
// *
if ((transa.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) || (transa.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    norma = "I";
}              // Close if()
if ((transe.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) || (transe.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    norme = "I";
itrnse = 1;
ince = lde;
}              // Close if()
// *
// *     Check normalization of E
// *
enrmin = one/ulp;
enrmax = zero;
if (itrnse == 0)  {
    // *
// *        Eigenvectors are column vectors.
// *
ipair = 0;
{
forloop30:
for (jvec = 1; jvec <= n; jvec++) {
temp1 = zero;
if (ipair == 0 && jvec < n && wi[(jvec)- 1+ _wi_offset] != zero)  
    ipair = 1;
if (ipair == 1)  {
    // *
// *              Complex eigenvector
// *
{
forloop10:
for (j = 1; j <= n; j++) {
temp1 = Math.max(temp1, Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])+Math.abs(e[(j)- 1+(jvec+1- 1)*lde+ _e_offset])) ;
Dummy.label("Dget22",10);
}              //  Close for() loop. 
}
enrmin = Math.min(enrmin, temp1) ;
enrmax = Math.max(enrmax, temp1) ;
ipair = 2;
}              // Close if()
else if (ipair == 2)  {
    ipair = 0;
}              // Close else if()
else  {
  // *
// *              Real eigenvector
// *
{
forloop20:
for (j = 1; j <= n; j++) {
temp1 = Math.max(temp1, Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])) ;
Dummy.label("Dget22",20);
}              //  Close for() loop. 
}
enrmin = Math.min(enrmin, temp1) ;
enrmax = Math.max(enrmax, temp1) ;
ipair = 0;
}              //  Close else.
Dummy.label("Dget22",30);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *        Eigenvectors are row vectors.
// *
{
forloop40:
for (jvec = 1; jvec <= n; jvec++) {
work[(jvec)- 1+ _work_offset] = zero;
Dummy.label("Dget22",40);
}              //  Close for() loop. 
}
// *
{
forloop60:
for (j = 1; j <= n; j++) {
ipair = 0;
{
forloop50:
for (jvec = 1; jvec <= n; jvec++) {
if (ipair == 0 && jvec < n && wi[(jvec)- 1+ _wi_offset] != zero)  
    ipair = 1;
if (ipair == 1)  {
    work[(jvec)- 1+ _work_offset] = Math.max(work[(jvec)- 1+ _work_offset], Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])+Math.abs(e[(j)- 1+(jvec+1- 1)*lde+ _e_offset])) ;
work[(jvec+1)- 1+ _work_offset] = work[(jvec)- 1+ _work_offset];
}              // Close if()
else if (ipair == 2)  {
    ipair = 0;
}              // Close else if()
else  {
  work[(jvec)- 1+ _work_offset] = Math.max(work[(jvec)- 1+ _work_offset], Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])) ;
ipair = 0;
}              //  Close else.
Dummy.label("Dget22",50);
}              //  Close for() loop. 
}
Dummy.label("Dget22",60);
}              //  Close for() loop. 
}
// *
{
forloop70:
for (jvec = 1; jvec <= n; jvec++) {
enrmin = Math.min(enrmin, work[(jvec)- 1+ _work_offset]) ;
enrmax = Math.max(enrmax, work[(jvec)- 1+ _work_offset]) ;
Dummy.label("Dget22",70);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Norm of A:
// *
anorm = Math.max(Dlange.dlange(norma,n,n,a,_a_offset,lda,work,_work_offset), unfl) ;
// *
// *     Norm of E:
// *
enorm = Math.max(Dlange.dlange(norme,n,n,e,_e_offset,lde,work,_work_offset), ulp) ;
// *
// *     Norm of error:
// *
// *     Error =  AE - EW
// *
Dlaset.dlaset("Full",n,n,zero,zero,work,_work_offset,n);
// *
ipair = 0;
ierow = 1;
iecol = 1;
// *
{
forloop80:
for (jcol = 1; jcol <= n; jcol++) {
if (itrnse == 1)  {
    ierow = jcol;
}              // Close if()
else  {
  iecol = jcol;
}              //  Close else.
// *
if (ipair == 0 && wi[(jcol)- 1+ _wi_offset] != zero)  
    ipair = 1;
// *
if (ipair == 1)  {
    wmat[(1)- 1+(1- 1)*2] = wr[(jcol)- 1+ _wr_offset];
wmat[(2)- 1+(1- 1)*2] = -wi[(jcol)- 1+ _wi_offset];
wmat[(1)- 1+(2- 1)*2] = wi[(jcol)- 1+ _wi_offset];
wmat[(2)- 1+(2- 1)*2] = wr[(jcol)- 1+ _wr_offset];
Dgemm.dgemm(transe,transw,n,2,2,one,e,(ierow)- 1+(iecol- 1)*lde+ _e_offset,lde,wmat,0,2,zero,work,(n*(jcol-1)+1)- 1+ _work_offset,n);
ipair = 2;
}              // Close if()
else if (ipair == 2)  {
    ipair = 0;
// *
}              // Close else if()
else  {
  // *
Daxpy.daxpy(n,wr[(jcol)- 1+ _wr_offset],e,(ierow)- 1+(iecol- 1)*lde+ _e_offset,ince,work,(n*(jcol-1)+1)- 1+ _work_offset,1);
ipair = 0;
}              //  Close else.
// *
Dummy.label("Dget22",80);
}              //  Close for() loop. 
}
// *
Dgemm.dgemm(transa,transe,n,n,n,one,a,_a_offset,lda,e,_e_offset,lde,-one,work,_work_offset,n);
// *
errnrm = Dlange.dlange("One",n,n,work,_work_offset,n,work,(n*n+1)- 1+ _work_offset)/enorm;
// *
// *     Compute RESULT(1) (avoiding under/overflow)
// *
if (anorm > errnrm)  {
    result[(1)- 1+ _result_offset] = (errnrm/anorm)/ulp;
}              // Close if()
else  {
  if (anorm < one)  {
    result[(1)- 1+ _result_offset] = (Math.min(errnrm, anorm) /anorm)/ulp;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = Math.min(errnrm/anorm, one) /ulp;
}              //  Close else.
}              //  Close else.
// *
// *     Compute RESULT(2) : the normalization error in E.
// *
result[(2)- 1+ _result_offset] = Math.max(Math.abs(enrmax-one), Math.abs(enrmin-one)) /((double)(n)*ulp);
// *
Dummy.go_to("Dget22",999999);
// *
// *     End of DGET22
// *
Dummy.label("Dget22",999999);
return;
   }
} // End class.
