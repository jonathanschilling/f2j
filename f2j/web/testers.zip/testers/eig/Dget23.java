/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget23 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DGET23  checks the nonsymmetric eigenvalue problem driver SGEEVX.
// *     If COMP = .FALSE., the first 8 of the following tests will be
// *     performed on the input matrix A, and also test 9 if LWORK is
// *     sufficiently large.
// *     if COMP is .TRUE. all 11 tests will be performed.
// *
// *     (1)     | A * VR - VR * W | / ( n |A| ulp )
// *
// *       Here VR is the matrix of unit right eigenvectors.
// *       W is a block diagonal matrix, with a 1x1 block for each
// *       real eigenvalue and a 2x2 block for each complex conjugate
// *       pair.  If eigenvalues j and j+1 are a complex conjugate pair,
// *       so WR(j) = WR(j+1) = wr and WI(j) = - WI(j+1) = wi, then the
// *       2 x 2 block corresponding to the pair will be:
// *
// *               (  wr  wi  )
// *               ( -wi  wr  )
// *
// *       Such a block multiplying an n x 2 matrix  ( ur ui ) on the
// *       right will be the same as multiplying  ur + i*ui  by  wr + i*wi.
// *
// *     (2)     | A**H * VL - VL * W**H | / ( n |A| ulp )
// *
// *       Here VL is the matrix of unit left eigenvectors, A**H is the
// *       conjugate transpose of A, and W is as above.
// *
// *     (3)     | |VR(i)| - 1 | / ulp and largest component real
// *
// *       VR(i) denotes the i-th column of VR.
// *
// *     (4)     | |VL(i)| - 1 | / ulp and largest component real
// *
// *       VL(i) denotes the i-th column of VL.
// *
// *     (5)     0 if W(full) = W(partial), 1/ulp otherwise
// *
// *       W(full) denotes the eigenvalues computed when VR, VL, RCONDV
// *       and RCONDE are also computed, and W(partial) denotes the
// *       eigenvalues computed when only some of VR, VL, RCONDV, and
// *       RCONDE are computed.
// *
// *     (6)     0 if VR(full) = VR(partial), 1/ulp otherwise
// *
// *       VR(full) denotes the right eigenvectors computed when VL, RCONDV
// *       and RCONDE are computed, and VR(partial) denotes the result
// *       when only some of VL and RCONDV are computed.
// *
// *     (7)     0 if VL(full) = VL(partial), 1/ulp otherwise
// *
// *       VL(full) denotes the left eigenvectors computed when VR, RCONDV
// *       and RCONDE are computed, and VL(partial) denotes the result
// *       when only some of VR and RCONDV are computed.
// *
// *     (8)     0 if SCALE, ILO, IHI, ABNRM (full) =
// *                  SCALE, ILO, IHI, ABNRM (partial)
// *             1/ulp otherwise
// *
// *       SCALE, ILO, IHI and ABNRM describe how the matrix is balanced.
// *       (full) is when VR, VL, RCONDE and RCONDV are also computed, and
// *       (partial) is when some are not computed.
// *
// *     (9)     0 if RCONDV(full) = RCONDV(partial), 1/ulp otherwise
// *
// *       RCONDV(full) denotes the reciprocal condition numbers of the
// *       right eigenvectors computed when VR, VL and RCONDE are also
// *       computed. RCONDV(partial) denotes the reciprocal condition
// *       numbers when only some of VR, VL and RCONDE are computed.
// *
// *    (10)     |RCONDV - RCDVIN| / cond(RCONDV)
// *
// *       RCONDV is the reciprocal right eigenvector condition number
// *       computed by DGEEVX and RCDVIN (the precomputed true value)
// *       is supplied as input. cond(RCONDV) is the condition number of
// *       RCONDV, and takes errors in computing RCONDV into account, so
// *       that the resulting quantity should be O(ULP). cond(RCONDV) is
// *       essentially given by norm(A)/RCONDE.
// *
// *    (11)     |RCONDE - RCDEIN| / cond(RCONDE)
// *
// *       RCONDE is the reciprocal eigenvalue condition number
// *       computed by DGEEVX and RCDEIN (the precomputed true value)
// *       is supplied as input.  cond(RCONDE) is the condition number
// *       of RCONDE, and takes errors in computing RCONDE into account,
// *       so that the resulting quantity should be O(ULP). cond(RCONDE)
// *       is essentially given by norm(A)/RCONDV.
// *
// *  Arguments
// *  =========
// *
// *  COMP    (input) LOGICAL
// *          COMP describes which input tests to perform:
// *            = .FALSE. if the computed condition numbers are not to
// *                      be tested against RCDVIN and RCDEIN
// *            = .TRUE.  if they are to be compared
// *
// *  BALANC  (input) CHARACTER
// *          Describes the balancing option to be tested.
// *            = 'N' for no permuting or diagonal scaling
// *            = 'P' for permuting but no diagonal scaling
// *            = 'S' for no permuting but diagonal scaling
// *            = 'B' for permuting and diagonal scaling
// *
// *  JTYPE   (input) INTEGER
// *          Type of input matrix. Used to label output if error occurs.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *
// *  ISEED   (input) INTEGER array, dimension (4)
// *          If COMP = .FALSE., the random number generator seed
// *          used to produce matrix.
// *          If COMP = .TRUE., ISEED(1) = the number of the example.
// *          Used to label output if error occurs.
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns INFO not equal to 0.)
// *
// *  N       (input) INTEGER
// *          The dimension of A. N must be at least 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A, and H. LDA must be at
// *          least 1 and at least N.
// *
// *  H       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *          Another copy of the test matrix A, modified by DGEEVX.
// *
// *  WR      (workspace) DOUBLE PRECISION array, dimension (N)
// *  WI      (workspace) DOUBLE PRECISION array, dimension (N)
// *          The real and imaginary parts of the eigenvalues of A.
// *          On exit, WR + WI*i are the eigenvalues of the matrix in A.
// *
// *  WR1     (workspace) DOUBLE PRECISION array, dimension (N)
// *  WI1     (workspace) DOUBLE PRECISION array, dimension (N)
// *          Like WR, WI, these arrays contain the eigenvalues of A,
// *          but those computed when DGEEVX only computes a partial
// *          eigendecomposition, i.e. not the eigenvalues and left
// *          and right eigenvectors.
// *
// *  VL      (workspace) DOUBLE PRECISION array, dimension (LDVL,N)
// *          VL holds the computed left eigenvectors.
// *
// *  LDVL    (input) INTEGER
// *          Leading dimension of VL. Must be at least max(1,N).
// *
// *  VR      (workspace) DOUBLE PRECISION array, dimension (LDVR,N)
// *          VR holds the computed right eigenvectors.
// *
// *  LDVR    (input) INTEGER
// *          Leading dimension of VR. Must be at least max(1,N).
// *
// *  LRE     (workspace) DOUBLE PRECISION array, dimension (LDLRE,N)
// *          LRE holds the computed right or left eigenvectors.
// *
// *  LDLRE   (input) INTEGER
// *          Leading dimension of LRE. Must be at least max(1,N).
// *
// *  RCONDV  (workspace) DOUBLE PRECISION array, dimension (N)
// *          RCONDV holds the computed reciprocal condition numbers
// *          for eigenvectors.
// *
// *  RCNDV1  (workspace) DOUBLE PRECISION array, dimension (N)
// *          RCNDV1 holds more computed reciprocal condition numbers
// *          for eigenvectors.
// *
// *  RCDVIN  (input) DOUBLE PRECISION array, dimension (N)
// *          When COMP = .TRUE. RCDVIN holds the precomputed reciprocal
// *          condition numbers for eigenvectors to be compared with
// *          RCONDV.
// *
// *  RCONDE  (workspace) DOUBLE PRECISION array, dimension (N)
// *          RCONDE holds the computed reciprocal condition numbers
// *          for eigenvalues.
// *
// *  RCNDE1  (workspace) DOUBLE PRECISION array, dimension (N)
// *          RCNDE1 holds more computed reciprocal condition numbers
// *          for eigenvalues.
// *
// *  RCDEIN  (input) DOUBLE PRECISION array, dimension (N)
// *          When COMP = .TRUE. RCDEIN holds the precomputed reciprocal
// *          condition numbers for eigenvalues to be compared with
// *          RCONDE.
// *
// *  SCALE   (workspace) DOUBLE PRECISION array, dimension (N)
// *          Holds information describing balancing of matrix.
// *
// *  SCALE1  (workspace) DOUBLE PRECISION array, dimension (N)
// *          Holds information describing balancing of matrix.
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (11)
// *          The values computed by the 11 tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK.  This must be at least
// *          3*N, and 6*N+N**2 if tests 9, 10 or 11 are to be performed.
// *
// *  IWORK   (workspace) INTEGER array, dimension (2*N)
// *
// *  INFO    (output) INTEGER
// *          If 0,  successful exit.
// *          If <0, input parameter -INFO had an incorrect value.
// *          If >0, DGEEVX returned an error code, the absolute
// *                 value of which is returned.
// *
// *  =====================================================================
// *
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double epsin= 5.9605e-8;
// *     ..
// *     .. Local Scalars ..
static boolean balok= false;
static boolean nobal= false;
static String sense= new String(" ");
static int i= 0;
static intW ihi= new intW(0);
static intW ihi1= new intW(0);
static intW iinfo= new intW(0);
static intW ilo= new intW(0);
static intW ilo1= new intW(0);
static int isens= 0;
static int isensm= 0;
static int j= 0;
static int jj= 0;
static int kmin= 0;
static doubleW abnrm= new doubleW(0.0);
static doubleW abnrm1= new doubleW(0.0);
static double eps= 0.0;
static double smlnum= 0.0;
static double tnrm= 0.0;
static double tol= 0.0;
static double tolin= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static double v= 0.0;
static double vimin= 0.0;
static double vmax= 0.0;
static double vmx= 0.0;
static double vrmin= 0.0;
static double vrmx= 0.0;
static double vtst= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] dum= new double[(1)];
static double [] res= new double[(2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static String [] sens = {"N" 
, "V" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dget23 (boolean comp,
String balanc,
int jtype,
double thresh,
int [] iseed, int _iseed_offset,
int nounit,
int n,
double [] a, int _a_offset,
int lda,
double [] h, int _h_offset,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] wr1, int _wr1_offset,
double [] wi1, int _wi1_offset,
double [] vl, int _vl_offset,
int ldvl,
double [] vr, int _vr_offset,
int ldvr,
double [] lre, int _lre_offset,
int ldlre,
double [] rcondv, int _rcondv_offset,
double [] rcndv1, int _rcndv1_offset,
double [] rcdvin, int _rcdvin_offset,
double [] rconde, int _rconde_offset,
double [] rcnde1, int _rcnde1_offset,
double [] rcdein, int _rcdein_offset,
double [] scale, int _scale_offset,
double [] scale1, int _scale1_offset,
double [] result, int _result_offset,
double [] work, int _work_offset,
int lwork,
int [] iwork, int _iwork_offset,
intW info)  {

nobal = (balanc.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
balok = nobal || (balanc.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) || (balanc.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (balanc.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
info.val = 0;
if (!balok)  {
    info.val = -2;
}              // Close if()
else if (thresh < zero)  {
    info.val = -4;
}              // Close else if()
else if (nounit <= 0)  {
    info.val = -6;
}              // Close else if()
else if (n < 0)  {
    info.val = -7;
}              // Close else if()
else if (lda < 1 || lda < n)  {
    info.val = -9;
}              // Close else if()
else if (ldvl < 1 || ldvl < n)  {
    info.val = -16;
}              // Close else if()
else if (ldvr < 1 || ldvr < n)  {
    info.val = -18;
}              // Close else if()
else if (ldlre < 1 || ldlre < n)  {
    info.val = -20;
}              // Close else if()
else if (lwork < 3*n || (comp && lwork < 6*n+n*n))  {
    info.val = -31;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGET23",-info.val);
Dummy.go_to("Dget23",999999);
}              // Close if()
// *
// *     Quick return if nothing to do
// *
{
forloop10:
for (i = 1; i <= 11; i++) {
result[(i)- 1+ _result_offset] = -one;
Dummy.label("Dget23",10);
}              //  Close for() loop. 
}
// *
if (n == 0)  
    Dummy.go_to("Dget23",999999);
// *
// *     More Important constants
// *
ulp = Dlamch.dlamch("Precision");
smlnum = Dlamch.dlamch("S");
ulpinv = one/ulp;
// *
// *     Compute eigenvalues and eigenvectors, and test them
// *
if (lwork >= 6*n+n*n)  {
    sense = "B";
isensm = 2;
}              // Close if()
else  {
  sense = "E";
isensm = 1;
}              //  Close else.
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeevx.dgeevx(balanc,"V","V",sense,n,h,_h_offset,lda,wr,_wr_offset,wi,_wi_offset,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,ilo,ihi,scale,_scale_offset,abnrm,rconde,_rconde_offset,rcondv,_rcondv_offset,work,_work_offset,lwork,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET23: "  + ("DGEEVX1") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", BALANC = "  + (balanc) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET23: "  + ("DGEEVX1") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget23",999999);
}              // Close if()
// *
// *     Do Test (1)
// *
Dget22.dget22("N","N","N",n,a,_a_offset,lda,vr,_vr_offset,ldvr,wr,_wr_offset,wi,_wi_offset,work,_work_offset,res,0);
result[(1)- 1+ _result_offset] = res[(1)- 1];
// *
// *     Do Test (2)
// *
Dget22.dget22("T","N","T",n,a,_a_offset,lda,vl,_vl_offset,ldvl,wr,_wr_offset,wi,_wi_offset,work,_work_offset,res,0);
result[(2)- 1+ _result_offset] = res[(1)- 1];
// *
// *     Do Test (3)
// *
{
forloop30:
for (j = 1; j <= n; j++) {
tnrm = one;
if (wi[(j)- 1+ _wi_offset] == zero)  {
    tnrm = Dnrm2.dnrm2(n,vr,(1)- 1+(j- 1)*ldvr+ _vr_offset,1);
}              // Close if()
else if (wi[(j)- 1+ _wi_offset] > zero)  {
    tnrm = Dlapy2.dlapy2(Dnrm2.dnrm2(n,vr,(1)- 1+(j- 1)*ldvr+ _vr_offset,1),Dnrm2.dnrm2(n,vr,(1)- 1+(j+1- 1)*ldvr+ _vr_offset,1));
}              // Close else if()
result[(3)- 1+ _result_offset] = Math.max(result[(3)- 1+ _result_offset], Math.min(ulpinv, Math.abs(tnrm-one)/ulp) ) ;
if (wi[(j)- 1+ _wi_offset] > zero)  {
    vmx = zero;
vrmx = zero;
{
forloop20:
for (jj = 1; jj <= n; jj++) {
vtst = Dlapy2.dlapy2(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset],vr[(jj)- 1+(j+1- 1)*ldvr+ _vr_offset]);
if (vtst > vmx)  
    vmx = vtst;
if (vr[(jj)- 1+(j+1- 1)*ldvr+ _vr_offset] == zero && Math.abs(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset]) > vrmx)  
    vrmx = Math.abs(vr[(jj)- 1+(j- 1)*ldvr+ _vr_offset]);
Dummy.label("Dget23",20);
}              //  Close for() loop. 
}
if (vrmx/vmx < one-two*ulp)  
    result[(3)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Dget23",30);
}              //  Close for() loop. 
}
// *
// *     Do Test (4)
// *
{
forloop50:
for (j = 1; j <= n; j++) {
tnrm = one;
if (wi[(j)- 1+ _wi_offset] == zero)  {
    tnrm = Dnrm2.dnrm2(n,vl,(1)- 1+(j- 1)*ldvl+ _vl_offset,1);
}              // Close if()
else if (wi[(j)- 1+ _wi_offset] > zero)  {
    tnrm = Dlapy2.dlapy2(Dnrm2.dnrm2(n,vl,(1)- 1+(j- 1)*ldvl+ _vl_offset,1),Dnrm2.dnrm2(n,vl,(1)- 1+(j+1- 1)*ldvl+ _vl_offset,1));
}              // Close else if()
result[(4)- 1+ _result_offset] = Math.max(result[(4)- 1+ _result_offset], Math.min(ulpinv, Math.abs(tnrm-one)/ulp) ) ;
if (wi[(j)- 1+ _wi_offset] > zero)  {
    vmx = zero;
vrmx = zero;
{
forloop40:
for (jj = 1; jj <= n; jj++) {
vtst = Dlapy2.dlapy2(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset],vl[(jj)- 1+(j+1- 1)*ldvl+ _vl_offset]);
if (vtst > vmx)  
    vmx = vtst;
if (vl[(jj)- 1+(j+1- 1)*ldvl+ _vl_offset] == zero && Math.abs(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset]) > vrmx)  
    vrmx = Math.abs(vl[(jj)- 1+(j- 1)*ldvl+ _vl_offset]);
Dummy.label("Dget23",40);
}              //  Close for() loop. 
}
if (vrmx/vmx < one-two*ulp)  
    result[(4)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Dget23",50);
}              //  Close for() loop. 
}
// *
// *     Test for all options of computing condition numbers
// *
{
forloop200:
for (isens = 1; isens <= isensm; isens++) {
// *
sense = sens[(isens)- 1];
// *
// *        Compute eigenvalues only, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeevx.dgeevx(balanc,"N","N",sense,n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,dum,0,1,dum,0,1,ilo1,ihi1,scale1,_scale1_offset,abnrm1,rcnde1,_rcnde1_offset,rcndv1,_rcndv1_offset,work,_work_offset,lwork,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET23: "  + ("DGEEVX2") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", BALANC = "  + (balanc) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET23: "  + ("DGEEVX2") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget23",190);
}              // Close if()
// *
// *        Do Test (5)
// *
{
forloop60:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",60);
}              //  Close for() loop. 
}
// *
// *        Do Test (8)
// *
if (!nobal)  {
    {
forloop70:
for (j = 1; j <= n; j++) {
if (scale[(j)- 1+ _scale_offset] != scale1[(j)- 1+ _scale1_offset])  
    result[(8)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",70);
}              //  Close for() loop. 
}
if (ilo.val != ilo1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (ihi.val != ihi1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (abnrm.val != abnrm1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
}              // Close if()
// *
// *        Do Test (9)
// *
if (isens == 2 && n > 1)  {
    {
forloop80:
for (j = 1; j <= n; j++) {
if (rcondv[(j)- 1+ _rcondv_offset] != rcndv1[(j)- 1+ _rcndv1_offset])  
    result[(9)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",80);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Compute eigenvalues and right eigenvectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeevx.dgeevx(balanc,"N","V",sense,n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,dum,0,1,lre,_lre_offset,ldlre,ilo1,ihi1,scale1,_scale1_offset,abnrm1,rcnde1,_rcnde1_offset,rcndv1,_rcndv1_offset,work,_work_offset,lwork,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET23: "  + ("DGEEVX3") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", BALANC = "  + (balanc) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET23: "  + ("DGEEVX3") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget23",190);
}              // Close if()
// *
// *        Do Test (5) again
// *
{
forloop90:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",90);
}              //  Close for() loop. 
}
// *
// *        Do Test (6)
// *
{
forloop110:
for (j = 1; j <= n; j++) {
{
forloop100:
for (jj = 1; jj <= n; jj++) {
if (vr[(j)- 1+(jj- 1)*ldvr+ _vr_offset] != lre[(j)- 1+(jj- 1)*ldlre+ _lre_offset])  
    result[(6)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",100);
}              //  Close for() loop. 
}
Dummy.label("Dget23",110);
}              //  Close for() loop. 
}
// *
// *        Do Test (8) again
// *
if (!nobal)  {
    {
forloop120:
for (j = 1; j <= n; j++) {
if (scale[(j)- 1+ _scale_offset] != scale1[(j)- 1+ _scale1_offset])  
    result[(8)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",120);
}              //  Close for() loop. 
}
if (ilo.val != ilo1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (ihi.val != ihi1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (abnrm.val != abnrm1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
}              // Close if()
// *
// *        Do Test (9) again
// *
if (isens == 2 && n > 1)  {
    {
forloop130:
for (j = 1; j <= n; j++) {
if (rcondv[(j)- 1+ _rcondv_offset] != rcndv1[(j)- 1+ _rcndv1_offset])  
    result[(9)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",130);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Compute eigenvalues and left eigenvectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeevx.dgeevx(balanc,"V","N",sense,n,h,_h_offset,lda,wr1,_wr1_offset,wi1,_wi1_offset,lre,_lre_offset,ldlre,dum,0,1,ilo1,ihi1,scale1,_scale1_offset,abnrm1,rcnde1,_rcnde1_offset,rcndv1,_rcndv1_offset,work,_work_offset,lwork,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET23: "  + ("DGEEVX4") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", BALANC = "  + (balanc) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET23: "  + ("DGEEVX4") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget23",190);
}              // Close if()
// *
// *        Do Test (5) again
// *
{
forloop140:
for (j = 1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] != wr1[(j)- 1+ _wr1_offset] || wi[(j)- 1+ _wi_offset] != wi1[(j)- 1+ _wi1_offset])  
    result[(5)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",140);
}              //  Close for() loop. 
}
// *
// *        Do Test (7)
// *
{
forloop160:
for (j = 1; j <= n; j++) {
{
forloop150:
for (jj = 1; jj <= n; jj++) {
if (vl[(j)- 1+(jj- 1)*ldvl+ _vl_offset] != lre[(j)- 1+(jj- 1)*ldlre+ _lre_offset])  
    result[(7)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",150);
}              //  Close for() loop. 
}
Dummy.label("Dget23",160);
}              //  Close for() loop. 
}
// *
// *        Do Test (8) again
// *
if (!nobal)  {
    {
forloop170:
for (j = 1; j <= n; j++) {
if (scale[(j)- 1+ _scale_offset] != scale1[(j)- 1+ _scale1_offset])  
    result[(8)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",170);
}              //  Close for() loop. 
}
if (ilo.val != ilo1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (ihi.val != ihi1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
if (abnrm.val != abnrm1.val)  
    result[(8)- 1+ _result_offset] = ulpinv;
}              // Close if()
// *
// *        Do Test (9) again
// *
if (isens == 2 && n > 1)  {
    {
forloop180:
for (j = 1; j <= n; j++) {
if (rcondv[(j)- 1+ _rcondv_offset] != rcndv1[(j)- 1+ _rcndv1_offset])  
    result[(9)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget23",180);
}              //  Close for() loop. 
}
}              // Close if()
// *
label190:
   Dummy.label("Dget23",190);
// *
Dummy.label("Dget23",200);
}              //  Close for() loop. 
}
// *
// *     If COMP, compare condition numbers to precomputed ones
// *
if (comp)  {
    Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeevx.dgeevx("N","V","V","B",n,h,_h_offset,lda,wr,_wr_offset,wi,_wi_offset,vl,_vl_offset,ldvl,vr,_vr_offset,ldvr,ilo,ihi,scale,_scale_offset,abnrm,rconde,_rconde_offset,rcondv,_rcondv_offset,work,_work_offset,lwork,iwork,_iwork_offset,iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ulpinv;
System.out.println(" DGET23: "  + ("DGEEVX5") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget23",250);
}              // Close if()
// *
// *        Sort eigenvalues and condition numbers lexicographically
// *        to compare with inputs
// *
{
forloop220:
for (i = 1; i <= n-1; i++) {
kmin = i;
vrmin = wr[(i)- 1+ _wr_offset];
vimin = wi[(i)- 1+ _wi_offset];
{
forloop210:
for (j = i+1; j <= n; j++) {
if (wr[(j)- 1+ _wr_offset] < vrmin)  {
    kmin = j;
vrmin = wr[(j)- 1+ _wr_offset];
vimin = wi[(j)- 1+ _wi_offset];
}              // Close if()
Dummy.label("Dget23",210);
}              //  Close for() loop. 
}
wr[(kmin)- 1+ _wr_offset] = wr[(i)- 1+ _wr_offset];
wi[(kmin)- 1+ _wi_offset] = wi[(i)- 1+ _wi_offset];
wr[(i)- 1+ _wr_offset] = vrmin;
wi[(i)- 1+ _wi_offset] = vimin;
vrmin = rconde[(kmin)- 1+ _rconde_offset];
rconde[(kmin)- 1+ _rconde_offset] = rconde[(i)- 1+ _rconde_offset];
rconde[(i)- 1+ _rconde_offset] = vrmin;
vrmin = rcondv[(kmin)- 1+ _rcondv_offset];
rcondv[(kmin)- 1+ _rcondv_offset] = rcondv[(i)- 1+ _rcondv_offset];
rcondv[(i)- 1+ _rcondv_offset] = vrmin;
Dummy.label("Dget23",220);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvectors
// *        taking their condition numbers into account
// *
result[(10)- 1+ _result_offset] = zero;
eps = Math.max(epsin, ulp) ;
v = Math.max((double)(n)*eps*abnrm.val, smlnum) ;
if (abnrm.val == zero)  
    v = one;
{
forloop230:
for (i = 1; i <= n; i++) {
if (v > rcondv[(i)- 1+ _rcondv_offset]*rconde[(i)- 1+ _rconde_offset])  {
    tol = rcondv[(i)- 1+ _rcondv_offset];
}              // Close if()
else  {
  tol = v/rconde[(i)- 1+ _rconde_offset];
}              //  Close else.
if (v > rcdvin[(i)- 1+ _rcdvin_offset]*rcdein[(i)- 1+ _rcdein_offset])  {
    tolin = rcdvin[(i)- 1+ _rcdvin_offset];
}              // Close if()
else  {
  tolin = v/rcdein[(i)- 1+ _rcdein_offset];
}              //  Close else.
tol = Math.max(tol, smlnum/eps) ;
tolin = Math.max(tolin, smlnum/eps) ;
if (eps*(rcdvin[(i)- 1+ _rcdvin_offset]-tolin) > rcondv[(i)- 1+ _rcondv_offset]+tol)  {
    vmax = one/eps;
}              // Close if()
else if (rcdvin[(i)- 1+ _rcdvin_offset]-tolin > rcondv[(i)- 1+ _rcondv_offset]+tol)  {
    vmax = (rcdvin[(i)- 1+ _rcdvin_offset]-tolin)/(rcondv[(i)- 1+ _rcondv_offset]+tol);
}              // Close else if()
else if (rcdvin[(i)- 1+ _rcdvin_offset]+tolin < eps*(rcondv[(i)- 1+ _rcondv_offset]-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (rcdvin[(i)- 1+ _rcdvin_offset]+tolin < rcondv[(i)- 1+ _rcondv_offset]-tol)  {
    vmax = (rcondv[(i)- 1+ _rcondv_offset]-tol)/(rcdvin[(i)- 1+ _rcdvin_offset]+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
result[(10)- 1+ _result_offset] = Math.max(result[(10)- 1+ _result_offset], vmax) ;
Dummy.label("Dget23",230);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvalues
// *        taking their condition numbers into account
// *
result[(11)- 1+ _result_offset] = zero;
{
forloop240:
for (i = 1; i <= n; i++) {
if (v > rcondv[(i)- 1+ _rcondv_offset])  {
    tol = one;
}              // Close if()
else  {
  tol = v/rcondv[(i)- 1+ _rcondv_offset];
}              //  Close else.
if (v > rcdvin[(i)- 1+ _rcdvin_offset])  {
    tolin = one;
}              // Close if()
else  {
  tolin = v/rcdvin[(i)- 1+ _rcdvin_offset];
}              //  Close else.
tol = Math.max(tol, smlnum/eps) ;
tolin = Math.max(tolin, smlnum/eps) ;
if (eps*(rcdein[(i)- 1+ _rcdein_offset]-tolin) > rconde[(i)- 1+ _rconde_offset]+tol)  {
    vmax = one/eps;
}              // Close if()
else if (rcdein[(i)- 1+ _rcdein_offset]-tolin > rconde[(i)- 1+ _rconde_offset]+tol)  {
    vmax = (rcdein[(i)- 1+ _rcdein_offset]-tolin)/(rconde[(i)- 1+ _rconde_offset]+tol);
}              // Close else if()
else if (rcdein[(i)- 1+ _rcdein_offset]+tolin < eps*(rconde[(i)- 1+ _rconde_offset]-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (rcdein[(i)- 1+ _rcdein_offset]+tolin < rconde[(i)- 1+ _rconde_offset]-tol)  {
    vmax = (rconde[(i)- 1+ _rconde_offset]-tol)/(rcdein[(i)- 1+ _rcdein_offset]+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
result[(11)- 1+ _result_offset] = Math.max(result[(11)- 1+ _result_offset], vmax) ;
Dummy.label("Dget23",240);
}              //  Close for() loop. 
}
label250:
   Dummy.label("Dget23",250);
// *
}              // Close if()
// *
// *
Dummy.go_to("Dget23",999999);
// *
// *     End of DGET23
// *
Dummy.label("Dget23",999999);
return;
   }
} // End class.
