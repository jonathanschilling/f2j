/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget24 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DGET24 checks the nonsymmetric eigenvalue (Schur form) problem
// *     expert driver DGEESX.
// *
// *     If COMP = .FALSE., the first 13 of the following tests will be
// *     be performed on the input matrix A, and also tests 14 and 15
// *     if LWORK is sufficiently large.
// *     If COMP = .TRUE., all 17 test will be performed.
// *
// *     (1)     0 if T is in Schur form, 1/ulp otherwise
// *            (no sorting of eigenvalues)
// *
// *     (2)     | A - VS T VS' | / ( n |A| ulp )
// *
// *       Here VS is the matrix of Schur eigenvectors, and T is in Schur
// *       form  (no sorting of eigenvalues).
// *
// *     (3)     | I - VS VS' | / ( n ulp ) (no sorting of eigenvalues).
// *
// *     (4)     0     if WR+sqrt(-1)*WI are eigenvalues of T
// *             1/ulp otherwise
// *             (no sorting of eigenvalues)
// *
// *     (5)     0     if T(with VS) = T(without VS),
// *             1/ulp otherwise
// *             (no sorting of eigenvalues)
// *
// *     (6)     0     if eigenvalues(with VS) = eigenvalues(without VS),
// *             1/ulp otherwise
// *             (no sorting of eigenvalues)
// *
// *     (7)     0 if T is in Schur form, 1/ulp otherwise
// *             (with sorting of eigenvalues)
// *
// *     (8)     | A - VS T VS' | / ( n |A| ulp )
// *
// *       Here VS is the matrix of Schur eigenvectors, and T is in Schur
// *       form  (with sorting of eigenvalues).
// *
// *     (9)     | I - VS VS' | / ( n ulp ) (with sorting of eigenvalues).
// *
// *     (10)    0     if WR+sqrt(-1)*WI are eigenvalues of T
// *             1/ulp otherwise
// *             If workspace sufficient, also compare WR, WI with and
// *             without reciprocal condition numbers
// *             (with sorting of eigenvalues)
// *
// *     (11)    0     if T(with VS) = T(without VS),
// *             1/ulp otherwise
// *             If workspace sufficient, also compare T with and without
// *             reciprocal condition numbers
// *             (with sorting of eigenvalues)
// *
// *     (12)    0     if eigenvalues(with VS) = eigenvalues(without VS),
// *             1/ulp otherwise
// *             If workspace sufficient, also compare VS with and without
// *             reciprocal condition numbers
// *             (with sorting of eigenvalues)
// *
// *     (13)    if sorting worked and SDIM is the number of
// *             eigenvalues which were SELECTed
// *             If workspace sufficient, also compare SDIM with and
// *             without reciprocal condition numbers
// *
// *     (14)    if RCONDE the same no matter if VS and/or RCONDV computed
// *
// *     (15)    if RCONDV the same no matter if VS and/or RCONDE computed
// *
// *     (16)  |RCONDE - RCDEIN| / cond(RCONDE)
// *
// *        RCONDE is the reciprocal average eigenvalue condition number
// *        computed by DGEESX and RCDEIN (the precomputed true value)
// *        is supplied as input.  cond(RCONDE) is the condition number
// *        of RCONDE, and takes errors in computing RCONDE into account,
// *        so that the resulting quantity should be O(ULP). cond(RCONDE)
// *        is essentially given by norm(A)/RCONDV.
// *
// *     (17)  |RCONDV - RCDVIN| / cond(RCONDV)
// *
// *        RCONDV is the reciprocal right invariant subspace condition
// *        number computed by DGEESX and RCDVIN (the precomputed true
// *        value) is supplied as input. cond(RCONDV) is the condition
// *        number of RCONDV, and takes errors in computing RCONDV into
// *        account, so that the resulting quantity should be O(ULP).
// *        cond(RCONDV) is essentially given by norm(A)/RCONDE.
// *
// *  Arguments
// *  =========
// *
// *  COMP    (input) LOGICAL
// *          COMP describes which input tests to perform:
// *            = .FALSE. if the computed condition numbers are not to
// *                      be tested against RCDVIN and RCDEIN
// *            = .TRUE.  if they are to be compared
// *
// *  JTYPE   (input) INTEGER
// *          Type of input matrix. Used to label output if error occurs.
// *
// *  ISEED   (input) INTEGER array, dimension (4)
// *          If COMP = .FALSE., the random number generator seed
// *          used to produce matrix.
// *          If COMP = .TRUE., ISEED(1) = the number of the example.
// *          Used to label output if error occurs.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          A test will count as "failed" if the "error", computed as
// *          described above, exceeds THRESH.  Note that the error
// *          is scaled to be O(1), so THRESH should be a reasonably
// *          small multiple of 1, e.g., 10 or 100.  In particular,
// *          it should not depend on the precision (single vs. double)
// *          or the size of the matrix.  It must be at least zero.
// *
// *  NOUNIT  (input) INTEGER
// *          The FORTRAN unit number for printing out error messages
// *          (e.g., if a routine returns INFO not equal to 0.)
// *
// *  N       (input) INTEGER
// *          The dimension of A. N must be at least 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA, N)
// *          Used to hold the matrix whose eigenvalues are to be
// *          computed.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A, and H. LDA must be at
// *          least 1 and at least N.
// *
// *  H       (workspace) DOUBLE PRECISION array, dimension (LDA, N)
// *          Another copy of the test matrix A, modified by DGEESX.
// *
// *  HT      (workspace) DOUBLE PRECISION array, dimension (LDA, N)
// *          Yet another copy of the test matrix A, modified by DGEESX.
// *
// *  WR      (workspace) DOUBLE PRECISION array, dimension (N)
// *  WI      (workspace) DOUBLE PRECISION array, dimension (N)
// *          The real and imaginary parts of the eigenvalues of A.
// *          On exit, WR + WI*i are the eigenvalues of the matrix in A.
// *
// *  WRT     (workspace) DOUBLE PRECISION array, dimension (N)
// *  WIT     (workspace) DOUBLE PRECISION array, dimension (N)
// *          Like WR, WI, these arrays contain the eigenvalues of A,
// *          but those computed when DGEESX only computes a partial
// *          eigendecomposition, i.e. not Schur vectors
// *
// *  WRTMP   (workspace) DOUBLE PRECISION array, dimension (N)
// *  WITMP   (workspace) DOUBLE PRECISION array, dimension (N)
// *          Like WR, WI, these arrays contain the eigenvalues of A,
// *          but sorted by increasing real part.
// *
// *  VS      (workspace) DOUBLE PRECISION array, dimension (LDVS, N)
// *          VS holds the computed Schur vectors.
// *
// *  LDVS    (input) INTEGER
// *          Leading dimension of VS. Must be at least max(1, N).
// *
// *  VS1     (workspace) DOUBLE PRECISION array, dimension (LDVS, N)
// *          VS1 holds another copy of the computed Schur vectors.
// *
// *  RCDEIN  (input) DOUBLE PRECISION
// *          When COMP = .TRUE. RCDEIN holds the precomputed reciprocal
// *          condition number for the average of selected eigenvalues.
// *
// *  RCDVIN  (input) DOUBLE PRECISION
// *          When COMP = .TRUE. RCDVIN holds the precomputed reciprocal
// *          condition number for the selected right invariant subspace.
// *
// *  NSLCT   (input) INTEGER
// *          When COMP = .TRUE. the number of selected eigenvalues
// *          corresponding to the precomputed values RCDEIN and RCDVIN.
// *
// *  ISLCT   (input) INTEGER array, dimension (NSLCT)
// *          When COMP = .TRUE. ISLCT selects the eigenvalues of the
// *          input matrix corresponding to the precomputed values RCDEIN
// *          and RCDVIN. For I=1, ... ,NSLCT, if ISLCT(I) = J, then the
// *          eigenvalue with the J-th largest real part is selected.
// *          Not referenced if COMP = .FALSE.
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (17)
// *          The values computed by the 17 tests described above.
// *          The values are currently limited to 1/ulp, to avoid
// *          overflow.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The number of entries in WORK to be passed to DGEESX. This
// *          must be at least 3*N, and N+N**2 if tests 14--16 are to
// *          be performed.
// *
// *  IWORK   (workspace) INTEGER array, dimension (N*N)
// *
// *  BWORK   (workspace) LOGICAL array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          If 0,  successful exit.
// *          If <0, input parameter -INFO had an incorrect value.
// *          If >0, DGEESX returned an error code, the absolute
// *                 value of which is returned.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double epsin= 5.9605e-8;
// *     ..
// *     .. Local Scalars ..
static String sort= new String(" ");
static int i= 0;
static intW iinfo= new intW(0);
static int isort= 0;
static int itmp= 0;
static int j= 0;
static int kmin= 0;
static int knteig= 0;
static int liwork= 0;
static int rsub= 0;
static intW sdim= new intW(0);
static intW sdim1= new intW(0);
static double anorm= 0.0;
static double eps= 0.0;
static doubleW rcnde1= new doubleW(0.0);
static doubleW rcndv1= new doubleW(0.0);
static doubleW rconde= new doubleW(0.0);
static doubleW rcondv= new doubleW(0.0);
static double smlnum= 0.0;
static double tmp= 0.0;
static double tol= 0.0;
static double tolin= 0.0;
static double ulp= 0.0;
static double ulpinv= 0.0;
static double v= 0.0;
static double vimin= 0.0;
static double vrmin= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] ipnt= new int[(20)];
// *     ..
// *     .. Arrays in Common ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Check for errors
// *

public static void dget24 (boolean comp,
int jtype,
double thresh,
int [] iseed, int _iseed_offset,
int nounit,
int n,
double [] a, int _a_offset,
int lda,
double [] h, int _h_offset,
double [] ht, int _ht_offset,
double [] wr, int _wr_offset,
double [] wi, int _wi_offset,
double [] wrt, int _wrt_offset,
double [] wit, int _wit_offset,
double [] wrtmp, int _wrtmp_offset,
double [] witmp, int _witmp_offset,
double [] vs, int _vs_offset,
int ldvs,
double [] vs1, int _vs1_offset,
double rcdein,
double rcdvin,
int nslct,
int [] islct, int _islct_offset,
double [] result, int _result_offset,
double [] work, int _work_offset,
int lwork,
int [] iwork, int _iwork_offset,
boolean [] bwork, int _bwork_offset,
intW info)  {

info.val = 0;
if (thresh < zero)  {
    info.val = -3;
}              // Close if()
else if (nounit <= 0)  {
    info.val = -5;
}              // Close else if()
else if (n < 0)  {
    info.val = -6;
}              // Close else if()
else if (lda < 1 || lda < n)  {
    info.val = -8;
}              // Close else if()
else if (ldvs < 1 || ldvs < n)  {
    info.val = -18;
}              // Close else if()
else if (lwork < 3*n)  {
    info.val = -26;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DGET24",-info.val);
Dummy.go_to("Dget24",999999);
}              // Close if()
// *
// *     Quick return if nothing to do
// *
{
forloop10:
for (i = 1; i <= 17; i++) {
result[(i)- 1+ _result_offset] = -one;
Dummy.label("Dget24",10);
}              //  Close for() loop. 
}
// *
if (n == 0)  
    Dummy.go_to("Dget24",999999);
// *
// *     Important constants
// *
smlnum = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Precision");
ulpinv = one/ulp;
// *
// *     Perform tests (1)-(13)
// *
eigtest_sslct.selopt = 0;
liwork = n*n;
{
forloop120:
for (isort = 0; isort <= 1; isort++) {
if (isort == 0)  {
    sort = "N";
rsub = 0;
}              // Close if()
else  {
  sort = "S";
rsub = 6;
}              //  Close else.
// *
// *        Compute Schur form and Schur vectors, and test them
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,h,_h_offset,lda);
Dgeesx.dgeesx("V",sort, new Dslect() ,"N",n,h,_h_offset,lda,sdim,wr,_wr_offset,wi,_wi_offset,vs,_vs_offset,ldvs,rconde,rcondv,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(1+rsub)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX1") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX1") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",999999);
}              // Close if()
if (isort == 0)  {
    Dcopy.dcopy(n,wr,_wr_offset,1,wrtmp,_wrtmp_offset,1);
Dcopy.dcopy(n,wi,_wi_offset,1,witmp,_witmp_offset,1);
}              // Close if()
// *
// *        Do Test (1) or Test (7)
// *
result[(1+rsub)- 1+ _result_offset] = zero;
{
forloop30:
for (j = 1; j <= n-2; j++) {
{
forloop20:
for (i = j+2; i <= n; i++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != zero)  
    result[(1+rsub)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",20);
}              //  Close for() loop. 
}
Dummy.label("Dget24",30);
}              //  Close for() loop. 
}
{
forloop40:
for (i = 1; i <= n-2; i++) {
if (h[(i+1)- 1+(i- 1)*lda+ _h_offset] != zero && h[(i+2)- 1+(i+1- 1)*lda+ _h_offset] != zero)  
    result[(1+rsub)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",40);
}              //  Close for() loop. 
}
{
forloop50:
for (i = 1; i <= n-1; i++) {
if (h[(i+1)- 1+(i- 1)*lda+ _h_offset] != zero)  {
    if (h[(i)- 1+(i- 1)*lda+ _h_offset] != h[(i+1)- 1+(i+1- 1)*lda+ _h_offset] || h[(i)- 1+(i+1- 1)*lda+ _h_offset] == zero || ((h[(i+1)- 1+(i- 1)*lda+ _h_offset]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((h[(i)- 1+(i+1- 1)*lda+ _h_offset]) >= 0 ? Math.abs(one) : -Math.abs(one)))  
    result[(1+rsub)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Dget24",50);
}              //  Close for() loop. 
}
// *
// *        Test (2) or (8): Compute norm(A - Q*H*Q') / (norm(A) * N * ULP)
// *
// *        Copy A to VS1, used as workspace
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,vs1,_vs1_offset,ldvs);
// *
// *        Compute Q*H and store in HT.
// *
Dgemm.dgemm("No transpose","No transpose",n,n,n,one,vs,_vs_offset,ldvs,h,_h_offset,lda,zero,ht,_ht_offset,lda);
// *
// *        Compute A - Q*H*Q'
// *
Dgemm.dgemm("No transpose","Transpose",n,n,n,-one,ht,_ht_offset,lda,vs,_vs_offset,ldvs,one,vs1,_vs1_offset,ldvs);
// *
anorm = Math.max(Dlange.dlange("1",n,n,a,_a_offset,lda,work,_work_offset), smlnum) ;
wnorm = Dlange.dlange("1",n,n,vs1,_vs1_offset,ldvs,work,_work_offset);
// *
if (anorm > wnorm)  {
    result[(2+rsub)- 1+ _result_offset] = (wnorm/anorm)/(n*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result[(2+rsub)- 1+ _result_offset] = (Math.min(wnorm, n*anorm) /anorm)/(n*ulp);
}              // Close if()
else  {
  result[(2+rsub)- 1+ _result_offset] = Math.min(wnorm/anorm, (double)(n)) /(n*ulp);
}              //  Close else.
}              //  Close else.
// *
// *        Test (3) or (9):  Compute norm( I - Q'*Q ) / ( N * ULP )
// *
dort01_adapter("Columns",n,n,vs,_vs_offset,ldvs,work,_work_offset,lwork,result,(3+rsub)- 1+ _result_offset);
// *
// *        Do Test (4) or Test (10)
// *
result[(4+rsub)- 1+ _result_offset] = zero;
{
forloop60:
for (i = 1; i <= n; i++) {
if (h[(i)- 1+(i- 1)*lda+ _h_offset] != wr[(i)- 1+ _wr_offset])  
    result[(4+rsub)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",60);
}              //  Close for() loop. 
}
if (n > 1)  {
    if (h[(2)- 1+(1- 1)*lda+ _h_offset] == zero && wi[(1)- 1+ _wi_offset] != zero)  
    result[(4+rsub)- 1+ _result_offset] = ulpinv;
if (h[(n)- 1+(n-1- 1)*lda+ _h_offset] == zero && wi[(n)- 1+ _wi_offset] != zero)  
    result[(4+rsub)- 1+ _result_offset] = ulpinv;
}              // Close if()
{
forloop70:
for (i = 1; i <= n-1; i++) {
if (h[(i+1)- 1+(i- 1)*lda+ _h_offset] != zero)  {
    tmp = Math.sqrt(Math.abs(h[(i+1)- 1+(i- 1)*lda+ _h_offset]))*Math.sqrt(Math.abs(h[(i)- 1+(i+1- 1)*lda+ _h_offset]));
result[(4+rsub)- 1+ _result_offset] = Math.max(result[(4+rsub)- 1+ _result_offset], Math.abs(wi[(i)- 1+ _wi_offset]-tmp)/Math.max(ulp*tmp, smlnum) ) ;
result[(4+rsub)- 1+ _result_offset] = Math.max(result[(4+rsub)- 1+ _result_offset], Math.abs(wi[(i+1)- 1+ _wi_offset]+tmp)/Math.max(ulp*tmp, smlnum) ) ;
}              // Close if()
else if (i > 1)  {
    if (h[(i+1)- 1+(i- 1)*lda+ _h_offset] == zero && h[(i)- 1+(i-1- 1)*lda+ _h_offset] == zero && wi[(i)- 1+ _wi_offset] != zero)  
    result[(4+rsub)- 1+ _result_offset] = ulpinv;
}              // Close else if()
Dummy.label("Dget24",70);
}              //  Close for() loop. 
}
// *
// *        Do Test (5) or Test (11)
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("N",sort, new Dslect() ,"N",n,ht,_ht_offset,lda,sdim,wrt,_wrt_offset,wit,_wit_offset,vs,_vs_offset,ldvs,rconde,rcondv,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(5+rsub)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX2") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX2") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
result[(5+rsub)- 1+ _result_offset] = zero;
{
forloop90:
for (j = 1; j <= n; j++) {
{
forloop80:
for (i = 1; i <= n; i++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(5+rsub)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",80);
}              //  Close for() loop. 
}
Dummy.label("Dget24",90);
}              //  Close for() loop. 
}
// *
// *        Do Test (6) or Test (12)
// *
result[(6+rsub)- 1+ _result_offset] = zero;
{
forloop100:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(6+rsub)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",100);
}              //  Close for() loop. 
}
// *
// *        Do Test (13)
// *
if (isort == 1)  {
    result[(13)- 1+ _result_offset] = zero;
knteig = 0;
{
forloop110:
for (i = 1; i <= n; i++) {
if (Dslect.dslect(wr[(i)- 1+ _wr_offset],wi[(i)- 1+ _wi_offset]) || Dslect.dslect(wr[(i)- 1+ _wr_offset],-wi[(i)- 1+ _wi_offset]))  
    knteig = knteig+1;
if (i < n)  {
    if ((Dslect.dslect(wr[(i+1)- 1+ _wr_offset],wi[(i+1)- 1+ _wi_offset]) || Dslect.dslect(wr[(i+1)- 1+ _wr_offset],-wi[(i+1)- 1+ _wi_offset])) && (!(Dslect.dslect(wr[(i)- 1+ _wr_offset],wi[(i)- 1+ _wi_offset]) || Dslect.dslect(wr[(i)- 1+ _wr_offset],-wi[(i)- 1+ _wi_offset]))) && iinfo.val != n+2)  
    result[(13)- 1+ _result_offset] = ulpinv;
}              // Close if()
Dummy.label("Dget24",110);
}              //  Close for() loop. 
}
if (sdim.val != knteig)  
    result[(13)- 1+ _result_offset] = ulpinv;
}              // Close if()
// *
Dummy.label("Dget24",120);
}              //  Close for() loop. 
}
// *
// *     If there is enough workspace, perform tests (14) and (15)
// *     as well as (10) through (13)
// *
if (lwork >= n+(n*n)/2)  {
    // *
// *        Compute both RCONDE and RCONDV with VS
// *
sort = "S";
result[(14)- 1+ _result_offset] = zero;
result[(15)- 1+ _result_offset] = zero;
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("V",sort, new Dslect() ,"B",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rconde,rcondv,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(14)- 1+ _result_offset] = ulpinv;
result[(15)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX3") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX3") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop140:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop130:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",130);
}              //  Close for() loop. 
}
Dummy.label("Dget24",140);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
// *        Compute both RCONDE and RCONDV without VS, and compare
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("N",sort, new Dslect() ,"B",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rcnde1,rcndv1,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(14)- 1+ _result_offset] = ulpinv;
result[(15)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX4") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX4") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform tests (14) and (15)
// *
if (rcnde1.val != rconde.val)  
    result[(14)- 1+ _result_offset] = ulpinv;
if (rcndv1.val != rcondv.val)  
    result[(15)- 1+ _result_offset] = ulpinv;
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop160:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop150:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",150);
}              //  Close for() loop. 
}
Dummy.label("Dget24",160);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
// *        Compute RCONDE with VS, and compare
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("V",sort, new Dslect() ,"E",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rcnde1,rcndv1,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(14)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX5") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX5") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform test (14)
// *
if (rcnde1.val != rconde.val)  
    result[(14)- 1+ _result_offset] = ulpinv;
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop180:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop170:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",170);
}              //  Close for() loop. 
}
Dummy.label("Dget24",180);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
// *        Compute RCONDE without VS, and compare
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("N",sort, new Dslect() ,"E",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rcnde1,rcndv1,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(14)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX6") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX6") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform test (14)
// *
if (rcnde1.val != rconde.val)  
    result[(14)- 1+ _result_offset] = ulpinv;
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop200:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop190:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",190);
}              //  Close for() loop. 
}
Dummy.label("Dget24",200);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
// *        Compute RCONDV with VS, and compare
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("V",sort, new Dslect() ,"V",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rcnde1,rcndv1,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(15)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX7") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX7") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform test (15)
// *
if (rcndv1.val != rcondv.val)  
    result[(15)- 1+ _result_offset] = ulpinv;
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop220:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop210:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",210);
}              //  Close for() loop. 
}
Dummy.label("Dget24",220);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
// *        Compute RCONDV without VS, and compare
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("N",sort, new Dslect() ,"V",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rcnde1,rcndv1,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(15)- 1+ _result_offset] = ulpinv;
if (jtype != 22)  {
    System.out.println(" DGET24: "  + ("DGEESX8") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", JTYPE="  + (jtype) + " "  + ", ISEED=("  + (iseed) + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ","  + " NULL " + " "  + ")" );
}              // Close if()
else  {
  System.out.println(" DGET24: "  + ("DGEESX8") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
}              //  Close else.
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",250);
}              // Close if()
// *
// *        Perform test (15)
// *
if (rcndv1.val != rcondv.val)  
    result[(15)- 1+ _result_offset] = ulpinv;
// *
// *        Perform tests (10), (11), (12), and (13)
// *
{
forloop240:
for (i = 1; i <= n; i++) {
if (wr[(i)- 1+ _wr_offset] != wrt[(i)- 1+ _wrt_offset] || wi[(i)- 1+ _wi_offset] != wit[(i)- 1+ _wit_offset])  
    result[(10)- 1+ _result_offset] = ulpinv;
{
forloop230:
for (j = 1; j <= n; j++) {
if (h[(i)- 1+(j- 1)*lda+ _h_offset] != ht[(i)- 1+(j- 1)*lda+ _ht_offset])  
    result[(11)- 1+ _result_offset] = ulpinv;
if (vs[(i)- 1+(j- 1)*ldvs+ _vs_offset] != vs1[(i)- 1+(j- 1)*ldvs+ _vs1_offset])  
    result[(12)- 1+ _result_offset] = ulpinv;
Dummy.label("Dget24",230);
}              //  Close for() loop. 
}
Dummy.label("Dget24",240);
}              //  Close for() loop. 
}
if (sdim.val != sdim1.val)  
    result[(13)- 1+ _result_offset] = ulpinv;
// *
}              // Close if()
// *
label250:
   Dummy.label("Dget24",250);
// *
// *     If there are precomputed reciprocal condition numbers, compare
// *     computed values with them.
// *
if (comp)  {
    // *
// *        First set up SELOPT, SELDIM, SELVAL, SELWR, and SELWI so that
// *        the logical function DSLECT selects the eigenvalues specified
// *        by NSLCT and ISLCT.
// *
eigtest_sslct.seldim = n;
eigtest_sslct.selopt = 1;
eps = Math.max(ulp, epsin) ;
{
forloop260:
for (i = 1; i <= n; i++) {
ipnt[(i)- 1] = i;
eigtest_sslct.selval[(i)- 1] = false;
eigtest_sslct.selwr[(i)- 1] = wrtmp[(i)- 1+ _wrtmp_offset];
eigtest_sslct.selwi[(i)- 1] = witmp[(i)- 1+ _witmp_offset];
Dummy.label("Dget24",260);
}              //  Close for() loop. 
}
{
forloop280:
for (i = 1; i <= n-1; i++) {
kmin = i;
vrmin = wrtmp[(i)- 1+ _wrtmp_offset];
vimin = witmp[(i)- 1+ _witmp_offset];
{
forloop270:
for (j = i+1; j <= n; j++) {
if (wrtmp[(j)- 1+ _wrtmp_offset] < vrmin)  {
    kmin = j;
vrmin = wrtmp[(j)- 1+ _wrtmp_offset];
vimin = witmp[(j)- 1+ _witmp_offset];
}              // Close if()
Dummy.label("Dget24",270);
}              //  Close for() loop. 
}
wrtmp[(kmin)- 1+ _wrtmp_offset] = wrtmp[(i)- 1+ _wrtmp_offset];
witmp[(kmin)- 1+ _witmp_offset] = witmp[(i)- 1+ _witmp_offset];
wrtmp[(i)- 1+ _wrtmp_offset] = vrmin;
witmp[(i)- 1+ _witmp_offset] = vimin;
itmp = ipnt[(i)- 1];
ipnt[(i)- 1] = ipnt[(kmin)- 1];
ipnt[(kmin)- 1] = itmp;
Dummy.label("Dget24",280);
}              //  Close for() loop. 
}
{
forloop290:
for (i = 1; i <= nslct; i++) {
eigtest_sslct.selval[(ipnt[(islct[(i)- 1+ _islct_offset])- 1])- 1] = true;
Dummy.label("Dget24",290);
}              //  Close for() loop. 
}
// *
// *        Compute condition numbers
// *
Dlacpy.dlacpy("F",n,n,a,_a_offset,lda,ht,_ht_offset,lda);
Dgeesx.dgeesx("N","S", new Dslect() ,"B",n,ht,_ht_offset,lda,sdim1,wrt,_wrt_offset,wit,_wit_offset,vs1,_vs1_offset,ldvs,rconde,rcondv,work,_work_offset,lwork,iwork,_iwork_offset,liwork,bwork,_bwork_offset,iinfo);
if (iinfo.val != 0 && iinfo.val != n+2)  {
    result[(16)- 1+ _result_offset] = ulpinv;
result[(17)- 1+ _result_offset] = ulpinv;
System.out.println(" DGET24: "  + ("DGEESX9") + " "  + " returned INFO="  + (iinfo.val) + " "  + "."  + "\n"  + "         " + "N="  + (n) + " "  + ", INPUT EXAMPLE NUMBER = "  + (iseed[(1)- 1+ _iseed_offset]) + " " );
info.val = (int)(Math.abs(iinfo.val));
Dummy.go_to("Dget24",300);
}              // Close if()
// *
// *        Compare condition number for average of selected eigenvalues
// *        taking its condition number into account
// *
anorm = Dlange.dlange("1",n,n,a,_a_offset,lda,work,_work_offset);
v = Math.max((double)(n)*eps*anorm, smlnum) ;
if (anorm == zero)  
    v = one;
if (v > rcondv.val)  {
    tol = one;
}              // Close if()
else  {
  tol = v/rcondv.val;
}              //  Close else.
if (v > rcdvin)  {
    tolin = one;
}              // Close if()
else  {
  tolin = v/rcdvin;
}              //  Close else.
tol = Math.max(tol, smlnum/eps) ;
tolin = Math.max(tolin, smlnum/eps) ;
if (eps*(rcdein-tolin) > rconde.val+tol)  {
    result[(16)- 1+ _result_offset] = ulpinv;
}              // Close if()
else if (rcdein-tolin > rconde.val+tol)  {
    result[(16)- 1+ _result_offset] = (rcdein-tolin)/(rconde.val+tol);
}              // Close else if()
else if (rcdein+tolin < eps*(rconde.val-tol))  {
    result[(16)- 1+ _result_offset] = ulpinv;
}              // Close else if()
else if (rcdein+tolin < rconde.val-tol)  {
    result[(16)- 1+ _result_offset] = (rconde.val-tol)/(rcdein+tolin);
}              // Close else if()
else  {
  result[(16)- 1+ _result_offset] = one;
}              //  Close else.
// *
// *        Compare condition numbers for right invariant subspace
// *        taking its condition number into account
// *
if (v > rcondv.val*rconde.val)  {
    tol = rcondv.val;
}              // Close if()
else  {
  tol = v/rconde.val;
}              //  Close else.
if (v > rcdvin*rcdein)  {
    tolin = rcdvin;
}              // Close if()
else  {
  tolin = v/rcdein;
}              //  Close else.
tol = Math.max(tol, smlnum/eps) ;
tolin = Math.max(tolin, smlnum/eps) ;
if (eps*(rcdvin-tolin) > rcondv.val+tol)  {
    result[(17)- 1+ _result_offset] = ulpinv;
}              // Close if()
else if (rcdvin-tolin > rcondv.val+tol)  {
    result[(17)- 1+ _result_offset] = (rcdvin-tolin)/(rcondv.val+tol);
}              // Close else if()
else if (rcdvin+tolin < eps*(rcondv.val-tol))  {
    result[(17)- 1+ _result_offset] = ulpinv;
}              // Close else if()
else if (rcdvin+tolin < rcondv.val-tol)  {
    result[(17)- 1+ _result_offset] = (rcondv.val-tol)/(rcdvin+tolin);
}              // Close else if()
else  {
  result[(17)- 1+ _result_offset] = one;
}              //  Close else.
// *
label300:
   Dummy.label("Dget24",300);
// *
}              // Close if()
// *
// *
Dummy.go_to("Dget24",999999);
// *
// *     End of DGET24
// *
Dummy.label("Dget24",999999);
return;
   }
// adapter for dort01
private static void dort01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dort01.dort01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
