/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget31 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET31 tests DLALN2, a routine for solving
// *
// *     (ca A - w D)X = sB
// *
// *  where A is an NA by NA matrix (NA=1 or 2 only), w is a real (NW=1) or
// *  complex (NW=2) constant, ca is a real constant, D is an NA by NA real
// *  diagonal matrix, and B is an NA by NW matrix (when NW=2 the second
// *  column of B contains the imaginary part of the solution).  The code
// *  returns X and s, where s is a scale factor, less than or equal to 1,
// *  which is chosen to avoid overflow in X.
// *
// *  If any singular values of ca A-w D are less than another input
// *  parameter SMIN, they are perturbed up to SMIN.
// *
// *  The test condition is that the scaled residual
// *
// *      norm( (ca A-w D)*X - s*B ) /
// *            ( max( ulp*norm(ca A-w D), SMIN )*norm(X) )
// *
// *  should be on the order of 1.  Here, ulp is the machine precision.
// *  Also, it is verified that SCALE is less than or equal to 1, and that
// *  XNORM = infinity-norm(X).
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER array, dimension (3)
// *          NINFO(1) = number of examples with INFO less than 0
// *          NINFO(2) = number of examples with INFO greater than 0
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double three= 3.0e0;
static double four= 4.0e0;
static double seven= 7.0e0;
static double ten= 10.0e0;
static double twnone= 21.0e0;
// *     ..
// *     .. Local Scalars ..
static int ia= 0;
static int ib= 0;
static int ica= 0;
static int id1= 0;
static int id2= 0;
static intW info= new intW(0);
static int ismin= 0;
static int itrans= 0;
static int iwi= 0;
static int iwr= 0;
static int na= 0;
static int nw= 0;
static doubleW bignum= new doubleW(0.0);
static double ca= 0.0;
static double d1= 0.0;
static double d2= 0.0;
static double den= 0.0;
static double eps= 0.0;
static double res= 0.0;
static doubleW scale= new doubleW(0.0);
static double smin= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double tmp= 0.0;
static double unfl= 0.0;
static double wi= 0.0;
static double wr= 0.0;
static doubleW xnorm= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(2) * (2)];
static double [] b= new double[(2) * (2)];
static double [] vab= new double[(3)];
static double [] vca= new double[(5)];
static double [] vdd= new double[(4)];
static double [] vsmin= new double[(4)];
static double [] vwi= new double[(4)];
static double [] vwr= new double[(4)];
static double [] x= new double[(2) * (2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static boolean [] ltrans = {false 
, true };
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget31 (doubleW rmax,
intW lmax,
int [] ninfo, int _ninfo_offset,
intW knt)  {

eps = Dlamch.dlamch("P");
unfl = Dlamch.dlamch("U");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
vsmin[(1)- 1] = smlnum.val;
vsmin[(2)- 1] = eps;
vsmin[(3)- 1] = one/(ten*ten);
vsmin[(4)- 1] = one/eps;
vab[(1)- 1] = Math.sqrt(smlnum.val);
vab[(2)- 1] = one;
vab[(3)- 1] = Math.sqrt(bignum.val);
vwr[(1)- 1] = zero;
vwr[(2)- 1] = half;
vwr[(3)- 1] = two;
vwr[(4)- 1] = one;
vwi[(1)- 1] = smlnum.val;
vwi[(2)- 1] = eps;
vwi[(3)- 1] = one;
vwi[(4)- 1] = two;
vdd[(1)- 1] = Math.sqrt(smlnum.val);
vdd[(2)- 1] = one;
vdd[(3)- 1] = two;
vdd[(4)- 1] = Math.sqrt(bignum.val);
vca[(1)- 1] = zero;
vca[(2)- 1] = Math.sqrt(smlnum.val);
vca[(3)- 1] = eps;
vca[(4)- 1] = half;
vca[(5)- 1] = one;
// *
knt.val = 0;
ninfo[(1)- 1+ _ninfo_offset] = 0;
ninfo[(2)- 1+ _ninfo_offset] = 0;
lmax.val = 0;
rmax.val = zero;
// *
// *     Begin test loop
// *
{
forloop190:
for (id1 = 1; id1 <= 4; id1++) {
d1 = vdd[(id1)- 1];
{
forloop180:
for (id2 = 1; id2 <= 4; id2++) {
d2 = vdd[(id2)- 1];
{
forloop170:
for (ica = 1; ica <= 5; ica++) {
ca = vca[(ica)- 1];
{
forloop160:
for (itrans = 0; itrans <= 1; itrans++) {
{
forloop150:
for (ismin = 1; ismin <= 4; ismin++) {
smin = vsmin[(ismin)- 1];
// *
na = 1;
nw = 1;
{
forloop30:
for (ia = 1; ia <= 3; ia++) {
a[(1)- 1+(1- 1)*2] = vab[(ia)- 1];
{
forloop20:
for (ib = 1; ib <= 3; ib++) {
b[(1)- 1+(1- 1)*2] = vab[(ib)- 1];
{
forloop10:
for (iwr = 1; iwr <= 4; iwr++) {
if (d1 == one && d2 == one && ca == one)  {
    wr = vwr[(iwr)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wr = vwr[(iwr)- 1];
}              //  Close else.
wi = zero;
Dlaln2.dlaln2(ltrans[(itrans)],na,nw,smin,ca,a,0,2,d1,d2,b,0,2,wr,wi,x,0,2,scale,xnorm,info);
if (info.val < 0)  
    ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
if (info.val > 0)  
    ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
res = Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(1- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
if (info.val == 0)  {
    den = Math.max(eps*(Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(1- 1)*2])), smlnum.val) ;
}              // Close if()
else  {
  den = Math.max(smin*Math.abs(x[(1)- 1+(1- 1)*2]), smlnum.val) ;
}              //  Close else.
res = res/den;
if (Math.abs(x[(1)- 1+(1- 1)*2]) < unfl && Math.abs(b[(1)- 1+(1- 1)*2]) <= smlnum.val*Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1))  
    res = zero;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-Math.abs(x[(1)- 1+(1- 1)*2]))/Math.max(smlnum.val, xnorm.val) /eps;
if (info.val != 0 && info.val != 1)  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget31",10);
}              //  Close for() loop. 
}
Dummy.label("Dget31",20);
}              //  Close for() loop. 
}
Dummy.label("Dget31",30);
}              //  Close for() loop. 
}
// *
na = 1;
nw = 2;
{
forloop70:
for (ia = 1; ia <= 3; ia++) {
a[(1)- 1+(1- 1)*2] = vab[(ia)- 1];
{
forloop60:
for (ib = 1; ib <= 3; ib++) {
b[(1)- 1+(1- 1)*2] = vab[(ib)- 1];
b[(1)- 1+(2- 1)*2] = -half*vab[(ib)- 1];
{
forloop50:
for (iwr = 1; iwr <= 4; iwr++) {
if (d1 == one && d2 == one && ca == one)  {
    wr = vwr[(iwr)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wr = vwr[(iwr)- 1];
}              //  Close else.
{
forloop40:
for (iwi = 1; iwi <= 4; iwi++) {
if (d1 == one && d2 == one && ca == one)  {
    wi = vwi[(iwi)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wi = vwi[(iwi)- 1];
}              //  Close else.
Dlaln2.dlaln2(ltrans[(itrans)],na,nw,smin,ca,a,0,2,d1,d2,b,0,2,wr,wi,x,0,2,scale,xnorm,info);
if (info.val < 0)  
    ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
if (info.val > 0)  
    ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
res = Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(1- 1)*2]+wi*d1*x[(1)- 1+(2- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
res = res+Math.abs(-wi*d1*x[(1)- 1+(1- 1)*2]+(ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(2- 1)*2]-scale.val*b[(1)- 1+(2- 1)*2]);
if (info.val == 0)  {
    den = Math.max(eps*(Math.max(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1), Math.abs(d1*wi)) *(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(1)- 1+(2- 1)*2]))), smlnum.val) ;
}              // Close if()
else  {
  den = Math.max(smin*(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(1)- 1+(2- 1)*2])), smlnum.val) ;
}              //  Close else.
res = res/den;
if (Math.abs(x[(1)- 1+(1- 1)*2]) < unfl && Math.abs(x[(1)- 1+(2- 1)*2]) < unfl && Math.abs(b[(1)- 1+(1- 1)*2]) <= smlnum.val*Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1))  
    res = zero;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-Math.abs(x[(1)- 1+(1- 1)*2])-Math.abs(x[(1)- 1+(2- 1)*2]))/Math.max(smlnum.val, xnorm.val) /eps;
if (info.val != 0 && info.val != 1)  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget31",40);
}              //  Close for() loop. 
}
Dummy.label("Dget31",50);
}              //  Close for() loop. 
}
Dummy.label("Dget31",60);
}              //  Close for() loop. 
}
Dummy.label("Dget31",70);
}              //  Close for() loop. 
}
// *
na = 2;
nw = 1;
{
forloop100:
for (ia = 1; ia <= 3; ia++) {
a[(1)- 1+(1- 1)*2] = vab[(ia)- 1];
a[(1)- 1+(2- 1)*2] = -three*vab[(ia)- 1];
a[(2)- 1+(1- 1)*2] = -seven*vab[(ia)- 1];
a[(2)- 1+(2- 1)*2] = twnone*vab[(ia)- 1];
{
forloop90:
for (ib = 1; ib <= 3; ib++) {
b[(1)- 1+(1- 1)*2] = vab[(ib)- 1];
b[(2)- 1+(1- 1)*2] = -two*vab[(ib)- 1];
{
forloop80:
for (iwr = 1; iwr <= 4; iwr++) {
if (d1 == one && d2 == one && ca == one)  {
    wr = vwr[(iwr)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wr = vwr[(iwr)- 1];
}              //  Close else.
wi = zero;
Dlaln2.dlaln2(ltrans[(itrans)],na,nw,smin,ca,a,0,2,d1,d2,b,0,2,wr,wi,x,0,2,scale,xnorm,info);
if (info.val < 0)  
    ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
if (info.val > 0)  
    ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
if (itrans == 1)  {
    tmp = a[(1)- 1+(2- 1)*2];
a[(1)- 1+(2- 1)*2] = a[(2)- 1+(1- 1)*2];
a[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
res = Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(1- 1)*2]+ca*a[(1)- 1+(2- 1)*2]*x[(2)- 1+(1- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
res = res+Math.abs(ca*a[(2)- 1+(1- 1)*2]*x[(1)- 1+(1- 1)*2]+(ca*a[(2)- 1+(2- 1)*2]-wr*d2)*x[(2)- 1+(1- 1)*2]-scale.val*b[(2)- 1+(1- 1)*2]);
if (info.val == 0)  {
    den = Math.max(eps*(Math.max(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2]), Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)) *Math.max(Math.abs(x[(1)- 1+(1- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])) ), smlnum.val) ;
}              // Close if()
else  {
  den = Math.max(eps*(Math.max(smin/eps, Math.max(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2]), Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)) ) *Math.max(Math.abs(x[(1)- 1+(1- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])) ), smlnum.val) ;
}              //  Close else.
res = res/den;
if (Math.abs(x[(1)- 1+(1- 1)*2]) < unfl && Math.abs(x[(2)- 1+(1- 1)*2]) < unfl && Math.abs(b[(1)- 1+(1- 1)*2])+Math.abs(b[(2)- 1+(1- 1)*2]) <= smlnum.val*(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2])+Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)))  
    res = zero;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-Math.max(Math.abs(x[(1)- 1+(1- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])) )/Math.max(smlnum.val, xnorm.val) /eps;
if (info.val != 0 && info.val != 1)  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget31",80);
}              //  Close for() loop. 
}
Dummy.label("Dget31",90);
}              //  Close for() loop. 
}
Dummy.label("Dget31",100);
}              //  Close for() loop. 
}
// *
na = 2;
nw = 2;
{
forloop140:
for (ia = 1; ia <= 3; ia++) {
a[(1)- 1+(1- 1)*2] = vab[(ia)- 1]*two;
a[(1)- 1+(2- 1)*2] = -three*vab[(ia)- 1];
a[(2)- 1+(1- 1)*2] = -seven*vab[(ia)- 1];
a[(2)- 1+(2- 1)*2] = twnone*vab[(ia)- 1];
{
forloop130:
for (ib = 1; ib <= 3; ib++) {
b[(1)- 1+(1- 1)*2] = vab[(ib)- 1];
b[(2)- 1+(1- 1)*2] = -two*vab[(ib)- 1];
b[(1)- 1+(2- 1)*2] = four*vab[(ib)- 1];
b[(2)- 1+(2- 1)*2] = -seven*vab[(ib)- 1];
{
forloop120:
for (iwr = 1; iwr <= 4; iwr++) {
if (d1 == one && d2 == one && ca == one)  {
    wr = vwr[(iwr)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wr = vwr[(iwr)- 1];
}              //  Close else.
{
forloop110:
for (iwi = 1; iwi <= 4; iwi++) {
if (d1 == one && d2 == one && ca == one)  {
    wi = vwi[(iwi)- 1]*a[(1)- 1+(1- 1)*2];
}              // Close if()
else  {
  wi = vwi[(iwi)- 1];
}              //  Close else.
Dlaln2.dlaln2(ltrans[(itrans)],na,nw,smin,ca,a,0,2,d1,d2,b,0,2,wr,wi,x,0,2,scale,xnorm,info);
if (info.val < 0)  
    ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
if (info.val > 0)  
    ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
if (itrans == 1)  {
    tmp = a[(1)- 1+(2- 1)*2];
a[(1)- 1+(2- 1)*2] = a[(2)- 1+(1- 1)*2];
a[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
res = Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(1- 1)*2]+ca*a[(1)- 1+(2- 1)*2]*x[(2)- 1+(1- 1)*2]+wi*d1*x[(1)- 1+(2- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
res = res+Math.abs((ca*a[(1)- 1+(1- 1)*2]-wr*d1)*x[(1)- 1+(2- 1)*2]+ca*a[(1)- 1+(2- 1)*2]*x[(2)- 1+(2- 1)*2]-wi*d1*x[(1)- 1+(1- 1)*2]-scale.val*b[(1)- 1+(2- 1)*2]);
res = res+Math.abs(ca*a[(2)- 1+(1- 1)*2]*x[(1)- 1+(1- 1)*2]+(ca*a[(2)- 1+(2- 1)*2]-wr*d2)*x[(2)- 1+(1- 1)*2]+wi*d2*x[(2)- 1+(2- 1)*2]-scale.val*b[(2)- 1+(1- 1)*2]);
res = res+Math.abs(ca*a[(2)- 1+(1- 1)*2]*x[(1)- 1+(2- 1)*2]+(ca*a[(2)- 1+(2- 1)*2]-wr*d2)*x[(2)- 1+(2- 1)*2]-wi*d2*x[(2)- 1+(1- 1)*2]-scale.val*b[(2)- 1+(2- 1)*2]);
if (info.val == 0)  {
    den = Math.max(eps*(Math.max(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2])+Math.abs(wi*d1), Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)+Math.abs(wi*d2)) *Math.max(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(2)- 1+(1- 1)*2]), Math.abs(x[(1)- 1+(2- 1)*2])+Math.abs(x[(2)- 1+(2- 1)*2])) ), smlnum.val) ;
}              // Close if()
else  {
  den = Math.max(eps*(Math.max(smin/eps, Math.max(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2])+Math.abs(wi*d1), Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)+Math.abs(wi*d2)) ) *Math.max(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(2)- 1+(1- 1)*2]), Math.abs(x[(1)- 1+(2- 1)*2])+Math.abs(x[(2)- 1+(2- 1)*2])) ), smlnum.val) ;
}              //  Close else.
res = res/den;
if (Math.abs(x[(1)- 1+(1- 1)*2]) < unfl && Math.abs(x[(2)- 1+(1- 1)*2]) < unfl && Math.abs(x[(1)- 1+(2- 1)*2]) < unfl && Math.abs(x[(2)- 1+(2- 1)*2]) < unfl && Math.abs(b[(1)- 1+(1- 1)*2])+Math.abs(b[(2)- 1+(1- 1)*2]) <= smlnum.val*(Math.abs(ca*a[(1)- 1+(1- 1)*2]-wr*d1)+Math.abs(ca*a[(1)- 1+(2- 1)*2])+Math.abs(ca*a[(2)- 1+(1- 1)*2])+Math.abs(ca*a[(2)- 1+(2- 1)*2]-wr*d2)+Math.abs(wi*d2)+Math.abs(wi*d1)))  
    res = zero;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-Math.max(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(1)- 1+(2- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])+Math.abs(x[(2)- 1+(2- 1)*2])) )/Math.max(smlnum.val, xnorm.val) /eps;
if (info.val != 0 && info.val != 1)  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget31",110);
}              //  Close for() loop. 
}
Dummy.label("Dget31",120);
}              //  Close for() loop. 
}
Dummy.label("Dget31",130);
}              //  Close for() loop. 
}
Dummy.label("Dget31",140);
}              //  Close for() loop. 
}
Dummy.label("Dget31",150);
}              //  Close for() loop. 
}
Dummy.label("Dget31",160);
}              //  Close for() loop. 
}
Dummy.label("Dget31",170);
}              //  Close for() loop. 
}
Dummy.label("Dget31",180);
}              //  Close for() loop. 
}
Dummy.label("Dget31",190);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget31",999999);
// *
// *     End of DGET31
// *
Dummy.label("Dget31",999999);
return;
   }
} // End class.
