/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget32 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET32 tests DLASY2, a routine for solving
// *
// *          op(TL)*X + ISGN*X*op(TR) = SCALE*B
// *
// *  where TL is N1 by N1, TR is N2 by N2, and N1,N2 =1 or 2 only.
// *  X and B are N1 by N2, op() is an optional transpose, an
// *  ISGN = 1 or -1. SCALE is chosen less than or equal to 1 to
// *  avoid overflow in X.
// *
// *  The test condition is that the scaled residual
// *
// *  norm( op(TL)*X + ISGN*X*op(TR) = SCALE*B )
// *       / ( max( ulp*norm(TL), ulp*norm(TR)) * norm(X), SMLNUM )
// *
// *  should be on the order of 1. Here, ulp is the machine precision.
// *  Also, it is verified that SCALE is less than or equal to 1, and
// *  that XNORM = infinity-norm(X).
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER
// *          Number of examples returned with INFO.NE.0.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double four= 4.0e0;
static double eight= 8.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean ltranl= false;
static boolean ltranr= false;
static int ib= 0;
static int ib1= 0;
static int ib2= 0;
static int ib3= 0;
static intW info= new intW(0);
static int isgn= 0;
static int itl= 0;
static int itlscl= 0;
static int itr= 0;
static int itranl= 0;
static int itranr= 0;
static int itrscl= 0;
static int n1= 0;
static int n2= 0;
static doubleW bignum= new doubleW(0.0);
static double den= 0.0;
static double eps= 0.0;
static double res= 0.0;
static doubleW scale= new doubleW(0.0);
static double sgn= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double tmp= 0.0;
static double tnrm= 0.0;
static doubleW xnorm= new doubleW(0.0);
static double xnrm= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] b= new double[(2) * (2)];
static double [] tl= new double[(2) * (2)];
static double [] tr= new double[(2) * (2)];
static double [] val= new double[(3)];
static double [] x= new double[(2) * (2)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] itval = {8 
, 4 , 2 , 1 , 4 , 8 
, 1 , 2 , 2 , 1 , 8 
, 4 , 1 , 2 , 4 , 8 
, 9 , 4 , 2 , 1 , 4 
, 9 , 1 , 2 , 2 , 1 
, 9 , 4 , 1 , 2 , 4 
, 9 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget32 (doubleW rmax,
intW lmax,
intW ninfo,
intW knt)  {

eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
val[(1)- 1] = Math.sqrt(smlnum.val);
val[(2)- 1] = one;
val[(3)- 1] = Math.sqrt(bignum.val);
// *
knt.val = 0;
ninfo.val = 0;
lmax.val = 0;
rmax.val = zero;
// *
// *     Begin test loop
// *
{
forloop230:
for (itranl = 0; itranl <= 1; itranl++) {
{
forloop220:
for (itranr = 0; itranr <= 1; itranr++) {
{
int _isgn_inc = 2;
forloop210:
for (isgn = -1; (_isgn_inc < 0) ? isgn >= 1 : isgn <= 1; isgn += _isgn_inc) {
sgn = (double)(isgn);
ltranl = itranl == 1;
ltranr = itranr == 1;
// *
n1 = 1;
n2 = 1;
{
forloop30:
for (itl = 1; itl <= 3; itl++) {
{
forloop20:
for (itr = 1; itr <= 3; itr++) {
{
forloop10:
for (ib = 1; ib <= 3; ib++) {
tl[(1)- 1+(1- 1)*2] = val[(itl)- 1];
tr[(1)- 1+(1- 1)*2] = val[(itr)- 1];
b[(1)- 1+(1- 1)*2] = val[(ib)- 1];
knt.val = knt.val+1;
Dlasy2.dlasy2(ltranl,ltranr,isgn,n1,n2,tl,0,2,tr,0,2,b,0,2,scale,x,0,2,xnorm,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
res = Math.abs((tl[(1)- 1+(1- 1)*2]+sgn*tr[(1)- 1+(1- 1)*2])*x[(1)- 1+(1- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
if (info.val == 0)  {
    den = Math.max(eps*((Math.abs(tr[(1)- 1+(1- 1)*2])+Math.abs(tl[(1)- 1+(1- 1)*2]))*Math.abs(x[(1)- 1+(1- 1)*2])), smlnum.val) ;
}              // Close if()
else  {
  den = smlnum.val*Math.max(Math.abs(x[(1)- 1+(1- 1)*2]), one) ;
}              //  Close else.
res = res/den;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-Math.abs(x[(1)- 1+(1- 1)*2]))/Math.max(smlnum.val, xnorm.val) /eps;
if (info.val != 0 && info.val != 1)  
    res = res+one/eps;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget32",10);
}              //  Close for() loop. 
}
Dummy.label("Dget32",20);
}              //  Close for() loop. 
}
Dummy.label("Dget32",30);
}              //  Close for() loop. 
}
// *
n1 = 2;
n2 = 1;
{
forloop80:
for (itl = 1; itl <= 8; itl++) {
{
forloop70:
for (itlscl = 1; itlscl <= 3; itlscl++) {
{
forloop60:
for (itr = 1; itr <= 3; itr++) {
{
forloop50:
for (ib1 = 1; ib1 <= 3; ib1++) {
{
forloop40:
for (ib2 = 1; ib2 <= 3; ib2++) {
b[(1)- 1+(1- 1)*2] = val[(ib1)- 1];
b[(2)- 1+(1- 1)*2] = -four*val[(ib2)- 1];
tl[(1)- 1+(1- 1)*2] = itval[(1)+(((1)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(2)- 1+(1- 1)*2] = itval[(2)+(((1)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(1)- 1+(2- 1)*2] = itval[(1)+(((2)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(2)- 1+(2- 1)*2] = itval[(2)+(((2)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tr[(1)- 1+(1- 1)*2] = val[(itr)- 1];
knt.val = knt.val+1;
Dlasy2.dlasy2(ltranl,ltranr,isgn,n1,n2,tl,0,2,tr,0,2,b,0,2,scale,x,0,2,xnorm,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
if (ltranl)  {
    tmp = tl[(1)- 1+(2- 1)*2];
tl[(1)- 1+(2- 1)*2] = tl[(2)- 1+(1- 1)*2];
tl[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
res = Math.abs((tl[(1)- 1+(1- 1)*2]+sgn*tr[(1)- 1+(1- 1)*2])*x[(1)- 1+(1- 1)*2]+tl[(1)- 1+(2- 1)*2]*x[(2)- 1+(1- 1)*2]-scale.val*b[(1)- 1+(1- 1)*2]);
res = res+Math.abs((tl[(2)- 1+(2- 1)*2]+sgn*tr[(1)- 1+(1- 1)*2])*x[(2)- 1+(1- 1)*2]+tl[(2)- 1+(1- 1)*2]*x[(1)- 1+(1- 1)*2]-scale.val*b[(2)- 1+(1- 1)*2]);
tnrm = Math.abs(tr[(1)- 1+(1- 1)*2])+Math.abs(tl[(1)- 1+(1- 1)*2])+Math.abs(tl[(1)- 1+(2- 1)*2])+Math.abs(tl[(2)- 1+(1- 1)*2])+Math.abs(tl[(2)- 1+(2- 1)*2]);
xnrm = Math.max(Math.abs(x[(1)- 1+(1- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])) ;
den = Math.max((smlnum.val) > (smlnum.val*xnrm) ? (smlnum.val) : (smlnum.val*xnrm), (tnrm*eps)*xnrm);
res = res/den;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-xnrm)/Math.max(smlnum.val, xnorm.val) /eps;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget32",40);
}              //  Close for() loop. 
}
Dummy.label("Dget32",50);
}              //  Close for() loop. 
}
Dummy.label("Dget32",60);
}              //  Close for() loop. 
}
Dummy.label("Dget32",70);
}              //  Close for() loop. 
}
Dummy.label("Dget32",80);
}              //  Close for() loop. 
}
// *
n1 = 1;
n2 = 2;
{
forloop130:
for (itr = 1; itr <= 8; itr++) {
{
forloop120:
for (itrscl = 1; itrscl <= 3; itrscl++) {
{
forloop110:
for (itl = 1; itl <= 3; itl++) {
{
forloop100:
for (ib1 = 1; ib1 <= 3; ib1++) {
{
forloop90:
for (ib2 = 1; ib2 <= 3; ib2++) {
b[(1)- 1+(1- 1)*2] = val[(ib1)- 1];
b[(1)- 1+(2- 1)*2] = -two*val[(ib2)- 1];
tr[(1)- 1+(1- 1)*2] = itval[(1)+(((1)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(2)- 1+(1- 1)*2] = itval[(2)+(((1)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(1)- 1+(2- 1)*2] = itval[(1)+(((2)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(2)- 1+(2- 1)*2] = itval[(2)+(((2)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tl[(1)- 1+(1- 1)*2] = val[(itl)- 1];
knt.val = knt.val+1;
Dlasy2.dlasy2(ltranl,ltranr,isgn,n1,n2,tl,0,2,tr,0,2,b,0,2,scale,x,0,2,xnorm,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
if (ltranr)  {
    tmp = tr[(1)- 1+(2- 1)*2];
tr[(1)- 1+(2- 1)*2] = tr[(2)- 1+(1- 1)*2];
tr[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
tnrm = Math.abs(tl[(1)- 1+(1- 1)*2])+Math.abs(tr[(1)- 1+(1- 1)*2])+Math.abs(tr[(1)- 1+(2- 1)*2])+Math.abs(tr[(2)- 1+(2- 1)*2])+Math.abs(tr[(2)- 1+(1- 1)*2]);
xnrm = Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(1)- 1+(2- 1)*2]);
res = Math.abs(((tl[(1)- 1+(1- 1)*2]+sgn*tr[(1)- 1+(1- 1)*2]))*(x[(1)- 1+(1- 1)*2])+(sgn*tr[(2)- 1+(1- 1)*2])*(x[(1)- 1+(2- 1)*2])-(scale.val*b[(1)- 1+(1- 1)*2]));
res = res+Math.abs(((tl[(1)- 1+(1- 1)*2]+sgn*tr[(2)- 1+(2- 1)*2]))*(x[(1)- 1+(2- 1)*2])+(sgn*tr[(1)- 1+(2- 1)*2])*(x[(1)- 1+(1- 1)*2])-(scale.val*b[(1)- 1+(2- 1)*2]));
den = Math.max((smlnum.val) > (smlnum.val*xnrm) ? (smlnum.val) : (smlnum.val*xnrm), (tnrm*eps)*xnrm);
res = res/den;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-xnrm)/Math.max(smlnum.val, xnorm.val) /eps;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget32",90);
}              //  Close for() loop. 
}
Dummy.label("Dget32",100);
}              //  Close for() loop. 
}
Dummy.label("Dget32",110);
}              //  Close for() loop. 
}
Dummy.label("Dget32",120);
}              //  Close for() loop. 
}
Dummy.label("Dget32",130);
}              //  Close for() loop. 
}
// *
n1 = 2;
n2 = 2;
{
forloop200:
for (itr = 1; itr <= 8; itr++) {
{
forloop190:
for (itrscl = 1; itrscl <= 3; itrscl++) {
{
forloop180:
for (itl = 1; itl <= 8; itl++) {
{
forloop170:
for (itlscl = 1; itlscl <= 3; itlscl++) {
{
forloop160:
for (ib1 = 1; ib1 <= 3; ib1++) {
{
forloop150:
for (ib2 = 1; ib2 <= 3; ib2++) {
{
forloop140:
for (ib3 = 1; ib3 <= 3; ib3++) {
b[(1)- 1+(1- 1)*2] = val[(ib1)- 1];
b[(2)- 1+(1- 1)*2] = -four*val[(ib2)- 1];
b[(1)- 1+(2- 1)*2] = -two*val[(ib3)- 1];
b[(2)- 1+(2- 1)*2] = eight*Math.min((val[(ib1)- 1]) < (val[(ib2)- 1]) ? (val[(ib1)- 1]) : (val[(ib2)- 1]), val[(ib3)- 1]);
tr[(1)- 1+(1- 1)*2] = itval[(1)+(((1)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(2)- 1+(1- 1)*2] = itval[(2)+(((1)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(1)- 1+(2- 1)*2] = itval[(1)+(((2)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tr[(2)- 1+(2- 1)*2] = itval[(2)+(((2)+((itr) * 2)) *2) - 7]*val[(itrscl)- 1];
tl[(1)- 1+(1- 1)*2] = itval[(1)+(((1)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(2)- 1+(1- 1)*2] = itval[(2)+(((1)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(1)- 1+(2- 1)*2] = itval[(1)+(((2)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
tl[(2)- 1+(2- 1)*2] = itval[(2)+(((2)+((itl) * 2)) *2) - 7]*val[(itlscl)- 1];
knt.val = knt.val+1;
Dlasy2.dlasy2(ltranl,ltranr,isgn,n1,n2,tl,0,2,tr,0,2,b,0,2,scale,x,0,2,xnorm,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
if (ltranr)  {
    tmp = tr[(1)- 1+(2- 1)*2];
tr[(1)- 1+(2- 1)*2] = tr[(2)- 1+(1- 1)*2];
tr[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
if (ltranl)  {
    tmp = tl[(1)- 1+(2- 1)*2];
tl[(1)- 1+(2- 1)*2] = tl[(2)- 1+(1- 1)*2];
tl[(2)- 1+(1- 1)*2] = tmp;
}              // Close if()
tnrm = Math.abs(tr[(1)- 1+(1- 1)*2])+Math.abs(tr[(2)- 1+(1- 1)*2])+Math.abs(tr[(1)- 1+(2- 1)*2])+Math.abs(tr[(2)- 1+(2- 1)*2])+Math.abs(tl[(1)- 1+(1- 1)*2])+Math.abs(tl[(2)- 1+(1- 1)*2])+Math.abs(tl[(1)- 1+(2- 1)*2])+Math.abs(tl[(2)- 1+(2- 1)*2]);
xnrm = Math.max(Math.abs(x[(1)- 1+(1- 1)*2])+Math.abs(x[(1)- 1+(2- 1)*2]), Math.abs(x[(2)- 1+(1- 1)*2])+Math.abs(x[(2)- 1+(2- 1)*2])) ;
res = Math.abs(((tl[(1)- 1+(1- 1)*2]+sgn*tr[(1)- 1+(1- 1)*2]))*(x[(1)- 1+(1- 1)*2])+(sgn*tr[(2)- 1+(1- 1)*2])*(x[(1)- 1+(2- 1)*2])+(tl[(1)- 1+(2- 1)*2])*(x[(2)- 1+(1- 1)*2])-(scale.val*b[(1)- 1+(1- 1)*2]));
res = res+Math.abs((tl[(1)- 1+(1- 1)*2])*(x[(1)- 1+(2- 1)*2])+(sgn*tr[(1)- 1+(2- 1)*2])*(x[(1)- 1+(1- 1)*2])+(sgn*tr[(2)- 1+(2- 1)*2])*(x[(1)- 1+(2- 1)*2])+(tl[(1)- 1+(2- 1)*2])*(x[(2)- 1+(2- 1)*2])-(scale.val*b[(1)- 1+(2- 1)*2]));
res = res+Math.abs((tl[(2)- 1+(1- 1)*2])*(x[(1)- 1+(1- 1)*2])+(sgn*tr[(1)- 1+(1- 1)*2])*(x[(2)- 1+(1- 1)*2])+(sgn*tr[(2)- 1+(1- 1)*2])*(x[(2)- 1+(2- 1)*2])+(tl[(2)- 1+(2- 1)*2])*(x[(2)- 1+(1- 1)*2])-(scale.val*b[(2)- 1+(1- 1)*2]));
res = res+Math.abs(((tl[(2)- 1+(2- 1)*2]+sgn*tr[(2)- 1+(2- 1)*2]))*(x[(2)- 1+(2- 1)*2])+(sgn*tr[(1)- 1+(2- 1)*2])*(x[(2)- 1+(1- 1)*2])+(tl[(2)- 1+(1- 1)*2])*(x[(1)- 1+(2- 1)*2])-(scale.val*b[(2)- 1+(2- 1)*2]));
den = Math.max((smlnum.val) > (smlnum.val*xnrm) ? (smlnum.val) : (smlnum.val*xnrm), (tnrm*eps)*xnrm);
res = res/den;
if (scale.val > one)  
    res = res+one/eps;
res = res+Math.abs(xnorm.val-xnrm)/Math.max(smlnum.val, xnorm.val) /eps;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget32",140);
}              //  Close for() loop. 
}
Dummy.label("Dget32",150);
}              //  Close for() loop. 
}
Dummy.label("Dget32",160);
}              //  Close for() loop. 
}
Dummy.label("Dget32",170);
}              //  Close for() loop. 
}
Dummy.label("Dget32",180);
}              //  Close for() loop. 
}
Dummy.label("Dget32",190);
}              //  Close for() loop. 
}
Dummy.label("Dget32",200);
}              //  Close for() loop. 
}
Dummy.label("Dget32",210);
}              //  Close for() loop. 
}
Dummy.label("Dget32",220);
}              //  Close for() loop. 
}
Dummy.label("Dget32",230);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget32",999999);
// *
// *     End of DGET32
// *
Dummy.label("Dget32",999999);
return;
   }
} // End class.
