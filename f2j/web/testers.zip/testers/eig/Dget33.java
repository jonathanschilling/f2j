/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget33 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET33 tests DLANV2, a routine for putting 2 by 2 blocks into
// *  standard form.  In other words, it computes a two by two rotation
// *  [[C,S];[-S,C]] where in
// *
// *     [ C S ][T(1,1) T(1,2)][ C -S ] = [ T11 T12 ]
// *     [-S C ][T(2,1) T(2,2)][ S  C ]   [ T21 T22 ]
// *
// *  either
// *     1) T21=0 (real eigenvalues), or
// *     2) T11=T22 and T21*T12<0 (complex conjugate eigenvalues).
// *  We also  verify that the residual is small.
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER
// *          Number of examples returned with INFO .NE. 0.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double four= 4.0e0;
// *     ..
// *     .. Local Scalars ..
static int i1= 0;
static int i2= 0;
static int i3= 0;
static int i4= 0;
static int im1= 0;
static int im2= 0;
static int im3= 0;
static int im4= 0;
static int j1= 0;
static int j2= 0;
static int j3= 0;
static doubleW bignum= new doubleW(0.0);
static doubleW cs= new doubleW(0.0);
static double eps= 0.0;
static double res= 0.0;
static doubleW smlnum= new doubleW(0.0);
static doubleW sn= new doubleW(0.0);
static double sum= 0.0;
static double tnrm= 0.0;
static doubleW wi1= new doubleW(0.0);
static doubleW wi2= new doubleW(0.0);
static doubleW wr1= new doubleW(0.0);
static doubleW wr2= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] q= new double[(2) * (2)];
static double [] t= new double[(2) * (2)];
static double [] t1= new double[(2) * (2)];
static double [] t2= new double[(2) * (2)];
static double [] val= new double[(4)];
static double [] vm= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget33 (doubleW rmax,
intW lmax,
intW ninfo,
intW knt)  {

eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
val[(1)- 1] = one;
val[(2)- 1] = one+two*eps;
val[(3)- 1] = two;
val[(4)- 1] = two-four*eps;
vm[(1)- 1] = smlnum.val;
vm[(2)- 1] = one;
vm[(3)- 1] = bignum.val;
// *
knt.val = 0;
ninfo.val = 0;
lmax.val = 0;
rmax.val = zero;
// *
// *     Begin test loop
// *
{
forloop150:
for (i1 = 1; i1 <= 4; i1++) {
{
forloop140:
for (i2 = 1; i2 <= 4; i2++) {
{
forloop130:
for (i3 = 1; i3 <= 4; i3++) {
{
forloop120:
for (i4 = 1; i4 <= 4; i4++) {
{
forloop110:
for (im1 = 1; im1 <= 3; im1++) {
{
forloop100:
for (im2 = 1; im2 <= 3; im2++) {
{
forloop90:
for (im3 = 1; im3 <= 3; im3++) {
{
forloop80:
for (im4 = 1; im4 <= 3; im4++) {
t[(1)- 1+(1- 1)*2] = val[(i1)- 1]*vm[(im1)- 1];
t[(1)- 1+(2- 1)*2] = val[(i2)- 1]*vm[(im2)- 1];
t[(2)- 1+(1- 1)*2] = -val[(i3)- 1]*vm[(im3)- 1];
t[(2)- 1+(2- 1)*2] = val[(i4)- 1]*vm[(im4)- 1];
tnrm = Math.max(Math.max(Math.max(Math.abs(t[(1)- 1+(1- 1)*2]), Math.abs(t[(1)- 1+(2- 1)*2])), Math.abs(t[(2)- 1+(1- 1)*2])), Math.abs(t[(2)- 1+(2- 1)*2])) ;
t1[(1)- 1+(1- 1)*2] = t[(1)- 1+(1- 1)*2];
t1[(1)- 1+(2- 1)*2] = t[(1)- 1+(2- 1)*2];
t1[(2)- 1+(1- 1)*2] = t[(2)- 1+(1- 1)*2];
t1[(2)- 1+(2- 1)*2] = t[(2)- 1+(2- 1)*2];
q[(1)- 1+(1- 1)*2] = one;
q[(1)- 1+(2- 1)*2] = zero;
q[(2)- 1+(1- 1)*2] = zero;
q[(2)- 1+(2- 1)*2] = one;
// *
dlanv2_adapter(t,(1)- 1+(1- 1)*2,t,(1)- 1+(2- 1)*2,t,(2)- 1+(1- 1)*2,t,(2)- 1+(2- 1)*2,wr1,wi1,wr2,wi2,cs,sn);
{
forloop10:
for (j1 = 1; j1 <= 2; j1++) {
res = q[(j1)- 1+(1- 1)*2]*cs.val+q[(j1)- 1+(2- 1)*2]*sn.val;
q[(j1)- 1+(2- 1)*2] = -q[(j1)- 1+(1- 1)*2]*sn.val+q[(j1)- 1+(2- 1)*2]*cs.val;
q[(j1)- 1+(1- 1)*2] = res;
Dummy.label("Dget33",10);
}              //  Close for() loop. 
}
// *
res = zero;
res = res+Math.abs(Math.pow(q[(1)- 1+(1- 1)*2], 2)+Math.pow(q[(1)- 1+(2- 1)*2], 2)-one)/eps;
res = res+Math.abs(Math.pow(q[(2)- 1+(2- 1)*2], 2)+Math.pow(q[(2)- 1+(1- 1)*2], 2)-one)/eps;
res = res+Math.abs(q[(1)- 1+(1- 1)*2]*q[(2)- 1+(1- 1)*2]+q[(1)- 1+(2- 1)*2]*q[(2)- 1+(2- 1)*2])/eps;
{
forloop40:
for (j1 = 1; j1 <= 2; j1++) {
{
forloop30:
for (j2 = 1; j2 <= 2; j2++) {
t2[(j1)- 1+(j2- 1)*2] = zero;
{
forloop20:
for (j3 = 1; j3 <= 2; j3++) {
t2[(j1)- 1+(j2- 1)*2] = t2[(j1)- 1+(j2- 1)*2]+t1[(j1)- 1+(j3- 1)*2]*q[(j3)- 1+(j2- 1)*2];
Dummy.label("Dget33",20);
}              //  Close for() loop. 
}
Dummy.label("Dget33",30);
}              //  Close for() loop. 
}
Dummy.label("Dget33",40);
}              //  Close for() loop. 
}
{
forloop70:
for (j1 = 1; j1 <= 2; j1++) {
{
forloop60:
for (j2 = 1; j2 <= 2; j2++) {
sum = t[(j1)- 1+(j2- 1)*2];
{
forloop50:
for (j3 = 1; j3 <= 2; j3++) {
sum = sum-q[(j3)- 1+(j1- 1)*2]*t2[(j3)- 1+(j2- 1)*2];
Dummy.label("Dget33",50);
}              //  Close for() loop. 
}
res = res+Math.abs(sum)/eps/tnrm;
Dummy.label("Dget33",60);
}              //  Close for() loop. 
}
Dummy.label("Dget33",70);
}              //  Close for() loop. 
}
if (t[(2)- 1+(1- 1)*2] != zero && (t[(1)- 1+(1- 1)*2] != t[(2)- 1+(2- 1)*2] || ((t[(1)- 1+(2- 1)*2]) >= 0 ? Math.abs(one) : -Math.abs(one))*((t[(2)- 1+(1- 1)*2]) >= 0 ? Math.abs(one) : -Math.abs(one)) > zero))  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget33",80);
}              //  Close for() loop. 
}
Dummy.label("Dget33",90);
}              //  Close for() loop. 
}
Dummy.label("Dget33",100);
}              //  Close for() loop. 
}
Dummy.label("Dget33",110);
}              //  Close for() loop. 
}
Dummy.label("Dget33",120);
}              //  Close for() loop. 
}
Dummy.label("Dget33",130);
}              //  Close for() loop. 
}
Dummy.label("Dget33",140);
}              //  Close for() loop. 
}
Dummy.label("Dget33",150);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget33",999999);
// *
// *     End of DGET33
// *
Dummy.label("Dget33",999999);
return;
   }
// adapter for dlanv2
private static void dlanv2_adapter(double [] arg0 , int arg0_offset ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,doubleW arg4 ,doubleW arg5 ,doubleW arg6 ,doubleW arg7 ,doubleW arg8 ,doubleW arg9 )
{
doubleW _f2j_tmp0 = new doubleW(arg0[arg0_offset]);
doubleW _f2j_tmp1 = new doubleW(arg1[arg1_offset]);
doubleW _f2j_tmp2 = new doubleW(arg2[arg2_offset]);
doubleW _f2j_tmp3 = new doubleW(arg3[arg3_offset]);

Dlanv2.dlanv2(_f2j_tmp0,_f2j_tmp1,_f2j_tmp2,_f2j_tmp3,arg4,arg5,arg6,arg7,arg8,arg9);

arg0[arg0_offset] = _f2j_tmp0.val;
arg1[arg1_offset] = _f2j_tmp1.val;
arg2[arg2_offset] = _f2j_tmp2.val;
arg3[arg3_offset] = _f2j_tmp3.val;
}

} // End class.
