/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget34 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET34 tests DLAEXC, a routine for swapping adjacent blocks (either
// *  1 by 1 or 2 by 2) on the diagonal of a matrix in real Schur form.
// *  Thus, DLAEXC computes an orthogonal matrix Q such that
// *
// *      Q' * [ A B ] * Q  = [ C1 B1 ]
// *           [ 0 C ]        [ 0  A1 ]
// *
// *  where C1 is similar to C and A1 is similar to A.  Both A and C are
// *  assumed to be in standard form (equal diagonal entries and
// *  offdiagonal with differing signs) and A1 and C1 are returned with the
// *  same properties.
// *
// *  The test code verifies these last last assertions, as well as that
// *  the residual in the above equation is small.
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER array, dimension (2)
// *          NINFO(J) is the number of examples where INFO=J occurred.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double half= 0.5e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double three= 3.0e0;
static int lwork= 32;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ia= 0;
static int ia11= 0;
static int ia12= 0;
static int ia21= 0;
static int ia22= 0;
static int iam= 0;
static int ib= 0;
static int ic= 0;
static int ic11= 0;
static int ic12= 0;
static int ic21= 0;
static int ic22= 0;
static int icm= 0;
static intW info= new intW(0);
static int j= 0;
static doubleW bignum= new doubleW(0.0);
static double eps= 0.0;
static double res= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double tnrm= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] q= new double[(4) * (4)];
static double [] result= new double[(2)];
static double [] t= new double[(4) * (4)];
static double [] t1= new double[(4) * (4)];
static double [] val= new double[(9)];
static double [] vm= new double[(2)];
static double [] work= new double[(lwork)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget34 (doubleW rmax,
intW lmax,
int [] ninfo, int _ninfo_offset,
intW knt)  {

eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
val[(1)- 1] = zero;
val[(2)- 1] = Math.sqrt(smlnum.val);
val[(3)- 1] = one;
val[(4)- 1] = two;
val[(5)- 1] = Math.sqrt(bignum.val);
val[(6)- 1] = -Math.sqrt(smlnum.val);
val[(7)- 1] = -one;
val[(8)- 1] = -two;
val[(9)- 1] = -Math.sqrt(bignum.val);
vm[(1)- 1] = one;
vm[(2)- 1] = one+two*eps;
Dcopy.dcopy(16,val,(4)- 1,0,t,(1)- 1+(1- 1)*4,1);
// *
ninfo[(1)- 1+ _ninfo_offset] = 0;
ninfo[(2)- 1+ _ninfo_offset] = 0;
knt.val = 0;
lmax.val = 0;
rmax.val = zero;
// *
// *     Begin test loop
// *
{
forloop40:
for (ia = 1; ia <= 9; ia++) {
{
forloop30:
for (iam = 1; iam <= 2; iam++) {
{
forloop20:
for (ib = 1; ib <= 9; ib++) {
{
forloop10:
for (ic = 1; ic <= 9; ic++) {
t[(1)- 1+(1- 1)*4] = val[(ia)- 1]*vm[(iam)- 1];
t[(2)- 1+(2- 1)*4] = val[(ic)- 1];
t[(1)- 1+(2- 1)*4] = val[(ib)- 1];
t[(2)- 1+(1- 1)*4] = zero;
tnrm = Math.max((Math.abs(t[(1)- 1+(1- 1)*4])) > (Math.abs(t[(2)- 1+(2- 1)*4])) ? (Math.abs(t[(1)- 1+(1- 1)*4])) : (Math.abs(t[(2)- 1+(2- 1)*4])), Math.abs(t[(1)- 1+(2- 1)*4]));
Dcopy.dcopy(16,t,0,1,t1,0,1);
Dcopy.dcopy(16,val,(1)- 1,0,q,0,1);
Dcopy.dcopy(4,val,(3)- 1,0,q,0,5);
Dlaexc.dlaexc(true,2,t,0,4,q,0,4,1,1,1,work,0,info);
if (info.val != 0)  
    ninfo[(info.val)- 1+ _ninfo_offset] = ninfo[(info.val)- 1+ _ninfo_offset]+1;
Dhst01.dhst01(2,1,2,t1,0,4,t,0,4,q,0,4,work,0,lwork,result,0);
res = result[(1)- 1]+result[(2)- 1];
if (info.val != 0)  
    res = res+one/eps;
if (t[(1)- 1+(1- 1)*4] != t1[(2)- 1+(2- 1)*4])  
    res = res+one/eps;
if (t[(2)- 1+(2- 1)*4] != t1[(1)- 1+(1- 1)*4])  
    res = res+one/eps;
if (t[(2)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget34",10);
}              //  Close for() loop. 
}
Dummy.label("Dget34",20);
}              //  Close for() loop. 
}
Dummy.label("Dget34",30);
}              //  Close for() loop. 
}
Dummy.label("Dget34",40);
}              //  Close for() loop. 
}
// *
{
forloop110:
for (ia = 1; ia <= 5; ia++) {
{
forloop100:
for (iam = 1; iam <= 2; iam++) {
{
forloop90:
for (ib = 1; ib <= 5; ib++) {
{
forloop80:
for (ic11 = 1; ic11 <= 5; ic11++) {
{
forloop70:
for (ic12 = 2; ic12 <= 5; ic12++) {
{
forloop60:
for (ic21 = 2; ic21 <= 4; ic21++) {
{
int _ic22_inc = 2;
forloop50:
for (ic22 = -1; (_ic22_inc < 0) ? ic22 >= 1 : ic22 <= 1; ic22 += _ic22_inc) {
t[(1)- 1+(1- 1)*4] = val[(ia)- 1]*vm[(iam)- 1];
t[(1)- 1+(2- 1)*4] = val[(ib)- 1];
t[(1)- 1+(3- 1)*4] = -two*val[(ib)- 1];
t[(2)- 1+(1- 1)*4] = zero;
t[(2)- 1+(2- 1)*4] = val[(ic11)- 1];
t[(2)- 1+(3- 1)*4] = val[(ic12)- 1];
t[(3)- 1+(1- 1)*4] = zero;
t[(3)- 1+(2- 1)*4] = -val[(ic21)- 1];
t[(3)- 1+(3- 1)*4] = val[(ic11)- 1]*(double)(ic22);
tnrm = Math.max(Math.max(Math.max(Math.max(Math.max(Math.max(Math.abs(t[(1)- 1+(1- 1)*4]), Math.abs(t[(1)- 1+(2- 1)*4])), Math.abs(t[(1)- 1+(3- 1)*4])), Math.abs(t[(2)- 1+(2- 1)*4])), Math.abs(t[(2)- 1+(3- 1)*4])), Math.abs(t[(3)- 1+(2- 1)*4])), Math.abs(t[(3)- 1+(3- 1)*4])) ;
Dcopy.dcopy(16,t,0,1,t1,0,1);
Dcopy.dcopy(16,val,(1)- 1,0,q,0,1);
Dcopy.dcopy(4,val,(3)- 1,0,q,0,5);
Dlaexc.dlaexc(true,3,t,0,4,q,0,4,1,1,2,work,0,info);
if (info.val != 0)  
    ninfo[(info.val)- 1+ _ninfo_offset] = ninfo[(info.val)- 1+ _ninfo_offset]+1;
Dhst01.dhst01(3,1,3,t1,0,4,t,0,4,q,0,4,work,0,lwork,result,0);
res = result[(1)- 1]+result[(2)- 1];
if (info.val == 0)  {
    if (t1[(1)- 1+(1- 1)*4] != t[(3)- 1+(3- 1)*4])  
    res = res+one/eps;
if (t[(3)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
if (t[(3)- 1+(2- 1)*4] != zero)  
    res = res+one/eps;
if (t[(2)- 1+(1- 1)*4] != 0 && (t[(1)- 1+(1- 1)*4] != t[(2)- 1+(2- 1)*4] || ((t[(1)- 1+(2- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((t[(2)- 1+(1- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one))))  
    res = res+one/eps;
}              // Close if()
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget34",50);
}              //  Close for() loop. 
}
Dummy.label("Dget34",60);
}              //  Close for() loop. 
}
Dummy.label("Dget34",70);
}              //  Close for() loop. 
}
Dummy.label("Dget34",80);
}              //  Close for() loop. 
}
Dummy.label("Dget34",90);
}              //  Close for() loop. 
}
Dummy.label("Dget34",100);
}              //  Close for() loop. 
}
Dummy.label("Dget34",110);
}              //  Close for() loop. 
}
// *
{
forloop180:
for (ia11 = 1; ia11 <= 5; ia11++) {
{
forloop170:
for (ia12 = 2; ia12 <= 5; ia12++) {
{
forloop160:
for (ia21 = 2; ia21 <= 4; ia21++) {
{
int _ia22_inc = 2;
forloop150:
for (ia22 = -1; (_ia22_inc < 0) ? ia22 >= 1 : ia22 <= 1; ia22 += _ia22_inc) {
{
forloop140:
for (icm = 1; icm <= 2; icm++) {
{
forloop130:
for (ib = 1; ib <= 5; ib++) {
{
forloop120:
for (ic = 1; ic <= 5; ic++) {
t[(1)- 1+(1- 1)*4] = val[(ia11)- 1];
t[(1)- 1+(2- 1)*4] = val[(ia12)- 1];
t[(1)- 1+(3- 1)*4] = -two*val[(ib)- 1];
t[(2)- 1+(1- 1)*4] = -val[(ia21)- 1];
t[(2)- 1+(2- 1)*4] = val[(ia11)- 1]*(double)(ia22);
t[(2)- 1+(3- 1)*4] = val[(ib)- 1];
t[(3)- 1+(1- 1)*4] = zero;
t[(3)- 1+(2- 1)*4] = zero;
t[(3)- 1+(3- 1)*4] = val[(ic)- 1]*vm[(icm)- 1];
tnrm = Math.max(Math.max(Math.max(Math.max(Math.max(Math.max(Math.abs(t[(1)- 1+(1- 1)*4]), Math.abs(t[(1)- 1+(2- 1)*4])), Math.abs(t[(1)- 1+(3- 1)*4])), Math.abs(t[(2)- 1+(2- 1)*4])), Math.abs(t[(2)- 1+(3- 1)*4])), Math.abs(t[(3)- 1+(2- 1)*4])), Math.abs(t[(3)- 1+(3- 1)*4])) ;
Dcopy.dcopy(16,t,0,1,t1,0,1);
Dcopy.dcopy(16,val,(1)- 1,0,q,0,1);
Dcopy.dcopy(4,val,(3)- 1,0,q,0,5);
Dlaexc.dlaexc(true,3,t,0,4,q,0,4,1,2,1,work,0,info);
if (info.val != 0)  
    ninfo[(info.val)- 1+ _ninfo_offset] = ninfo[(info.val)- 1+ _ninfo_offset]+1;
Dhst01.dhst01(3,1,3,t1,0,4,t,0,4,q,0,4,work,0,lwork,result,0);
res = result[(1)- 1]+result[(2)- 1];
if (info.val == 0)  {
    if (t1[(3)- 1+(3- 1)*4] != t[(1)- 1+(1- 1)*4])  
    res = res+one/eps;
if (t[(2)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
if (t[(3)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
if (t[(3)- 1+(2- 1)*4] != 0 && (t[(2)- 1+(2- 1)*4] != t[(3)- 1+(3- 1)*4] || ((t[(2)- 1+(3- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((t[(3)- 1+(2- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one))))  
    res = res+one/eps;
}              // Close if()
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget34",120);
}              //  Close for() loop. 
}
Dummy.label("Dget34",130);
}              //  Close for() loop. 
}
Dummy.label("Dget34",140);
}              //  Close for() loop. 
}
Dummy.label("Dget34",150);
}              //  Close for() loop. 
}
Dummy.label("Dget34",160);
}              //  Close for() loop. 
}
Dummy.label("Dget34",170);
}              //  Close for() loop. 
}
Dummy.label("Dget34",180);
}              //  Close for() loop. 
}
// *
{
forloop300:
for (ia11 = 1; ia11 <= 5; ia11++) {
{
forloop290:
for (ia12 = 2; ia12 <= 5; ia12++) {
{
forloop280:
for (ia21 = 2; ia21 <= 4; ia21++) {
{
int _ia22_inc = 2;
forloop270:
for (ia22 = -1; (_ia22_inc < 0) ? ia22 >= 1 : ia22 <= 1; ia22 += _ia22_inc) {
{
forloop260:
for (ib = 1; ib <= 5; ib++) {
{
forloop250:
for (ic11 = 3; ic11 <= 4; ic11++) {
{
forloop240:
for (ic12 = 3; ic12 <= 4; ic12++) {
{
forloop230:
for (ic21 = 3; ic21 <= 4; ic21++) {
{
int _ic22_inc = 2;
forloop220:
for (ic22 = -1; (_ic22_inc < 0) ? ic22 >= 1 : ic22 <= 1; ic22 += _ic22_inc) {
{
forloop210:
for (icm = 5; icm <= 7; icm++) {
iam = 1;
t[(1)- 1+(1- 1)*4] = val[(ia11)- 1]*vm[(iam)- 1];
t[(1)- 1+(2- 1)*4] = val[(ia12)- 1]*vm[(iam)- 1];
t[(1)- 1+(3- 1)*4] = -two*val[(ib)- 1];
t[(1)- 1+(4- 1)*4] = half*val[(ib)- 1];
t[(2)- 1+(1- 1)*4] = -t[(1)- 1+(2- 1)*4]*val[(ia21)- 1];
t[(2)- 1+(2- 1)*4] = val[(ia11)- 1]*(double)(ia22)*vm[(iam)- 1];
t[(2)- 1+(3- 1)*4] = val[(ib)- 1];
t[(2)- 1+(4- 1)*4] = three*val[(ib)- 1];
t[(3)- 1+(1- 1)*4] = zero;
t[(3)- 1+(2- 1)*4] = zero;
t[(3)- 1+(3- 1)*4] = val[(ic11)- 1]*Math.abs(val[(icm)- 1]);
t[(3)- 1+(4- 1)*4] = val[(ic12)- 1]*Math.abs(val[(icm)- 1]);
t[(4)- 1+(1- 1)*4] = zero;
t[(4)- 1+(2- 1)*4] = zero;
t[(4)- 1+(3- 1)*4] = -t[(3)- 1+(4- 1)*4]*val[(ic21)- 1]*Math.abs(val[(icm)- 1]);
t[(4)- 1+(4- 1)*4] = val[(ic11)- 1]*(double)(ic22)*Math.abs(val[(icm)- 1]);
tnrm = zero;
{
forloop200:
for (i = 1; i <= 4; i++) {
{
forloop190:
for (j = 1; j <= 4; j++) {
tnrm = Math.max(tnrm, Math.abs(t[(i)- 1+(j- 1)*4])) ;
Dummy.label("Dget34",190);
}              //  Close for() loop. 
}
Dummy.label("Dget34",200);
}              //  Close for() loop. 
}
Dcopy.dcopy(16,t,0,1,t1,0,1);
Dcopy.dcopy(16,val,(1)- 1,0,q,0,1);
Dcopy.dcopy(4,val,(3)- 1,0,q,0,5);
Dlaexc.dlaexc(true,4,t,0,4,q,0,4,1,2,2,work,0,info);
if (info.val != 0)  
    ninfo[(info.val)- 1+ _ninfo_offset] = ninfo[(info.val)- 1+ _ninfo_offset]+1;
Dhst01.dhst01(4,1,4,t1,0,4,t,0,4,q,0,4,work,0,lwork,result,0);
res = result[(1)- 1]+result[(2)- 1];
if (info.val == 0)  {
    if (t[(3)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
if (t[(4)- 1+(1- 1)*4] != zero)  
    res = res+one/eps;
if (t[(3)- 1+(2- 1)*4] != zero)  
    res = res+one/eps;
if (t[(4)- 1+(2- 1)*4] != zero)  
    res = res+one/eps;
if (t[(2)- 1+(1- 1)*4] != 0 && (t[(1)- 1+(1- 1)*4] != t[(2)- 1+(2- 1)*4] || ((t[(1)- 1+(2- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((t[(2)- 1+(1- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one))))  
    res = res+one/eps;
if (t[(4)- 1+(3- 1)*4] != 0 && (t[(3)- 1+(3- 1)*4] != t[(4)- 1+(4- 1)*4] || ((t[(3)- 1+(4- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((t[(4)- 1+(3- 1)*4]) >= 0 ? Math.abs(one) : -Math.abs(one))))  
    res = res+one/eps;
}              // Close if()
knt.val = knt.val+1;
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget34",210);
}              //  Close for() loop. 
}
Dummy.label("Dget34",220);
}              //  Close for() loop. 
}
Dummy.label("Dget34",230);
}              //  Close for() loop. 
}
Dummy.label("Dget34",240);
}              //  Close for() loop. 
}
Dummy.label("Dget34",250);
}              //  Close for() loop. 
}
Dummy.label("Dget34",260);
}              //  Close for() loop. 
}
Dummy.label("Dget34",270);
}              //  Close for() loop. 
}
Dummy.label("Dget34",280);
}              //  Close for() loop. 
}
Dummy.label("Dget34",290);
}              //  Close for() loop. 
}
Dummy.label("Dget34",300);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget34",999999);
// *
// *     End of DGET34
// *
Dummy.label("Dget34",999999);
return;
   }
} // End class.
