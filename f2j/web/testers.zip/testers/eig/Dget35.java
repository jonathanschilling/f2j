/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget35 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET35 tests DTRSYL, a routine for solving the Sylvester matrix
// *  equation
// *
// *     op(A)*X + ISGN*X*op(B) = scale*C,
// *
// *  A and B are assumed to be in Schur canonical form, op() represents an
// *  optional transpose, and ISGN can be -1 or +1.  Scale is an output
// *  less than or equal to 1, chosen to avoid overflow in X.
// *
// *  The test code verifies that the following residual is order 1:
// *
// *     norm(op(A)*X + ISGN*X*op(B) - scale*C) /
// *         (EPS*max(norm(A),norm(B))*norm(X))
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER
// *          Number of examples where INFO is nonzero.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double four= 4.0e0;
// *     ..
// *     .. Local Scalars ..
static String trana= new String(" ");
static String tranb= new String(" ");
static int i= 0;
static int ima= 0;
static int imb= 0;
static int imlda1= 0;
static int imlda2= 0;
static int imldb1= 0;
static int imloff= 0;
static intW info= new intW(0);
static int isgn= 0;
static int itrana= 0;
static int itranb= 0;
static int j= 0;
static int m= 0;
static int n= 0;
static doubleW bignum= new doubleW(0.0);
static double cnrm= 0.0;
static double eps= 0.0;
static double res= 0.0;
static double res1= 0.0;
static double rmul= 0.0;
static doubleW scale= new doubleW(0.0);
static doubleW smlnum= new doubleW(0.0);
static double tnrm= 0.0;
static double xnrm= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(6) * (6)];
static double [] b= new double[(6) * (6)];
static double [] c= new double[(6) * (6)];
static double [] cc= new double[(6) * (6)];
static double [] dum= new double[(1)];
static double [] vm1= new double[(3)];
static double [] vm2= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] idim = {1 
, 2 , 3 , 4 , 3 , 3 
, 6 , 4 };
static int [] ival = {1 
, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 1 , 2 , 0, 0, 0, 0 , -2 
, 0 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 1 , 0, 0, 0, 0, 0 , 5 
, 1 , 2 , 0, 0, 0 , -8 , -2 
, 1 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 3 , 4 , 0, 0, 0, 0 
, -5 , 3 , 0, 0, 0, 0 , 1 , 2 
, 1 , 4 , 0, 0 , -3 , -9 
, -1 , 1 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 1 , 0, 0, 0, 0, 0 
, 2 , 3 , 0, 0, 0, 0 , 5 , 6 
, 7 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 1 , 0, 0, 0, 0, 0 , 1 
, 3 , -4 , 0, 0, 0 , 2 , 5 
, 2 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 1 , 2 , 0, 0, 0, 0 
, -2 , 0 , 0, 0, 0, 0 , 5 , 6 
, 3 , 4 , 0, 0 , -1 , -9 
, -5 , 2 , 0, 0 , 8, 8, 8, 8 , 5 
, 6 , 9, 9, 9, 9 , -7 , 5 , 1 
, 0, 0, 0, 0, 0 , 1 , 5 , 2 , 0, 0, 0 
, 2 , -21 , 5 , 0, 0, 0 , 1 
, 2 , 3 , 4 , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget35 (doubleW rmax,
intW lmax,
intW ninfo,
intW knt)  {

eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")*four/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
vm1[(1)- 1] = Math.sqrt(smlnum.val);
vm1[(2)- 1] = one;
vm1[(3)- 1] = Math.sqrt(bignum.val);
vm2[(1)- 1] = one;
vm2[(2)- 1] = one+two*eps;
vm2[(3)- 1] = two;
// *
knt.val = 0;
ninfo.val = 0;
lmax.val = 0;
rmax.val = zero;
// *
// *     Begin test loop
// *
{
forloop150:
for (itrana = 1; itrana <= 2; itrana++) {
{
forloop140:
for (itranb = 1; itranb <= 2; itranb++) {
{
int _isgn_inc = 2;
forloop130:
for (isgn = -1; (_isgn_inc < 0) ? isgn >= 1 : isgn <= 1; isgn += _isgn_inc) {
{
forloop120:
for (ima = 1; ima <= 8; ima++) {
{
forloop110:
for (imlda1 = 1; imlda1 <= 3; imlda1++) {
{
forloop100:
for (imlda2 = 1; imlda2 <= 3; imlda2++) {
{
forloop90:
for (imloff = 1; imloff <= 2; imloff++) {
{
forloop80:
for (imb = 1; imb <= 8; imb++) {
{
forloop70:
for (imldb1 = 1; imldb1 <= 3; imldb1++) {
if (itrana == 1)  
    trana = "N";
if (itrana == 2)  
    trana = "T";
if (itranb == 1)  
    tranb = "N";
if (itranb == 2)  
    tranb = "T";
m = idim[(ima)- 1];
n = idim[(imb)- 1];
tnrm = zero;
{
forloop20:
for (i = 1; i <= m; i++) {
{
forloop10:
for (j = 1; j <= m; j++) {
a[(i)- 1+(j- 1)*6] = (double)(ival[(i)+(((j)+((ima) * 6)) *6) - 43]);
if (Math.abs(i-j) <= 1)  {
    a[(i)- 1+(j- 1)*6] = a[(i)- 1+(j- 1)*6]*vm1[(imlda1)- 1];
a[(i)- 1+(j- 1)*6] = a[(i)- 1+(j- 1)*6]*vm2[(imlda2)- 1];
}              // Close if()
else  {
  a[(i)- 1+(j- 1)*6] = a[(i)- 1+(j- 1)*6]*vm1[(imloff)- 1];
}              //  Close else.
tnrm = Math.max(tnrm, Math.abs(a[(i)- 1+(j- 1)*6])) ;
Dummy.label("Dget35",10);
}              //  Close for() loop. 
}
Dummy.label("Dget35",20);
}              //  Close for() loop. 
}
{
forloop40:
for (i = 1; i <= n; i++) {
{
forloop30:
for (j = 1; j <= n; j++) {
b[(i)- 1+(j- 1)*6] = (double)(ival[(i)+(((j)+((imb) * 6)) *6) - 43]);
if (Math.abs(i-j) <= 1)  {
    b[(i)- 1+(j- 1)*6] = b[(i)- 1+(j- 1)*6]*vm1[(imldb1)- 1];
}              // Close if()
else  {
  b[(i)- 1+(j- 1)*6] = b[(i)- 1+(j- 1)*6]*vm1[(imloff)- 1];
}              //  Close else.
tnrm = Math.max(tnrm, Math.abs(b[(i)- 1+(j- 1)*6])) ;
Dummy.label("Dget35",30);
}              //  Close for() loop. 
}
Dummy.label("Dget35",40);
}              //  Close for() loop. 
}
cnrm = zero;
{
forloop60:
for (i = 1; i <= m; i++) {
{
forloop50:
for (j = 1; j <= n; j++) {
c[(i)- 1+(j- 1)*6] = Math.sin((double)(i*j));
cnrm = Math.max(cnrm, c[(i)- 1+(j- 1)*6]) ;
cc[(i)- 1+(j- 1)*6] = c[(i)- 1+(j- 1)*6];
Dummy.label("Dget35",50);
}              //  Close for() loop. 
}
Dummy.label("Dget35",60);
}              //  Close for() loop. 
}
knt.val = knt.val+1;
Dtrsyl.dtrsyl(trana,tranb,isgn,m,n,a,0,6,b,0,6,c,0,6,scale,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
xnrm = Dlange.dlange("M",m,n,c,0,6,dum,0);
rmul = one;
if (xnrm > one && tnrm > one)  {
    if (xnrm > bignum.val/tnrm)  {
    rmul = one/Math.max(xnrm, tnrm) ;
}              // Close if()
}              // Close if()
Dgemm.dgemm(trana,"N",m,n,m,rmul,a,0,6,c,0,6,-scale.val*rmul,cc,0,6);
Dgemm.dgemm("N",tranb,m,n,n,(double)(isgn)*rmul,c,0,6,b,0,6,one,cc,0,6);
res1 = Dlange.dlange("M",m,n,cc,0,6,dum,0);
res = res1/Math.max((smlnum.val) > (smlnum.val*xnrm) ? (smlnum.val) : (smlnum.val*xnrm), ((rmul*tnrm)*eps)*xnrm);
if (res > rmax.val)  {
    lmax.val = knt.val;
rmax.val = res;
}              // Close if()
Dummy.label("Dget35",70);
}              //  Close for() loop. 
}
Dummy.label("Dget35",80);
}              //  Close for() loop. 
}
Dummy.label("Dget35",90);
}              //  Close for() loop. 
}
Dummy.label("Dget35",100);
}              //  Close for() loop. 
}
Dummy.label("Dget35",110);
}              //  Close for() loop. 
}
Dummy.label("Dget35",120);
}              //  Close for() loop. 
}
Dummy.label("Dget35",130);
}              //  Close for() loop. 
}
Dummy.label("Dget35",140);
}              //  Close for() loop. 
}
Dummy.label("Dget35",150);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget35",999999);
// *
// *     End of DGET35
// *
Dummy.label("Dget35",999999);
return;
   }
} // End class.
