/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget36 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET36 tests DTREXC, a routine for moving blocks (either 1 by 1 or
// *  2 by 2) on the diagonal of a matrix in real Schur form.  Thus, DLAEXC
// *  computes an orthogonal matrix Q such that
// *
// *     Q' * T1 * Q  = T2
// *
// *  and where one of the diagonal blocks of T1 (the one at row IFST) has
// *  been moved to position ILST.
// *
// *  The test code verifies that the residual Q'*T1*Q-T2 is small, that T2
// *  is in Schur form, and that the final position of the IFST block is
// *  ILST (within +-1).
// *
// *  The test matrices are read from a file with logical unit number NIN.
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER array, dimension (3)
// *          NINFO(J) is the number of examples where INFO=J.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  NIN     (input) INTEGER
// *          Input logical unit number.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static int ldt= 10;
static int lwork= 2*ldt*ldt;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ifst= 0;
static intW ifst1= new intW(0);
static intW ifst2= new intW(0);
static int ifstsv= 0;
static int ilst= 0;
static intW ilst1= new intW(0);
static intW ilst2= new intW(0);
static int ilstsv= 0;
static intW info1= new intW(0);
static intW info2= new intW(0);
static int j= 0;
static int loc= 0;
static int n= 0;
static double eps= 0.0;
static double res= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] q= new double[(ldt) * (ldt)];
static double [] result= new double[(2)];
static double [] t1= new double[(ldt) * (ldt)];
static double [] t2= new double[(ldt) * (ldt)];
static double [] tmp= new double[(ldt) * (ldt)];
static double [] work= new double[(lwork)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dget36 (doubleW rmax,
intW lmax,
int [] ninfo, int _ninfo_offset,
intW knt,
int nin)  {

  EasyIn _f2j_in = new EasyIn();
eps = Dlamch.dlamch("P");
rmax.val = zero;
lmax.val = 0;
knt.val = 0;
ninfo[(1)- 1+ _ninfo_offset] = 0;
ninfo[(2)- 1+ _ninfo_offset] = 0;
ninfo[(3)- 1+ _ninfo_offset] = 0;
// *
// *     Read input data until N=0
// *
label10:
   Dummy.label("Dget36",10);
n = _f2j_in.readInt();
ifst = _f2j_in.readInt();
ilst = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dget36",999999);
knt.val = knt.val+1;
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
tmp[(i)- 1+(j- 1)*ldt] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dget36",20);
}              //  Close for() loop. 
}
Dlacpy.dlacpy("F",n,n,tmp,0,ldt,t1,0,ldt);
Dlacpy.dlacpy("F",n,n,tmp,0,ldt,t2,0,ldt);
ifstsv = ifst;
ilstsv = ilst;
ifst1.val = ifst;
ilst1.val = ilst;
ifst2.val = ifst;
ilst2.val = ilst;
res = zero;
// *
// *     Test without accumulating Q
// *
Dlaset.dlaset("Full",n,n,zero,one,q,0,ldt);
Dtrexc.dtrexc("N",n,t1,0,ldt,q,0,ldt,ifst1,ilst1,work,0,info1);
{
forloop40:
for (i = 1; i <= n; i++) {
{
forloop30:
for (j = 1; j <= n; j++) {
if (i == j && q[(i)- 1+(j- 1)*ldt] != one)  
    res = res+one/eps;
if (i != j && q[(i)- 1+(j- 1)*ldt] != zero)  
    res = res+one/eps;
Dummy.label("Dget36",30);
}              //  Close for() loop. 
}
Dummy.label("Dget36",40);
}              //  Close for() loop. 
}
// *
// *     Test with accumulating Q
// *
Dlaset.dlaset("Full",n,n,zero,one,q,0,ldt);
Dtrexc.dtrexc("V",n,t2,0,ldt,q,0,ldt,ifst2,ilst2,work,0,info2);
// *
// *     Compare T1 with T2
// *
{
forloop60:
for (i = 1; i <= n; i++) {
{
forloop50:
for (j = 1; j <= n; j++) {
if (t1[(i)- 1+(j- 1)*ldt] != t2[(i)- 1+(j- 1)*ldt])  
    res = res+one/eps;
Dummy.label("Dget36",50);
}              //  Close for() loop. 
}
Dummy.label("Dget36",60);
}              //  Close for() loop. 
}
if (ifst1.val != ifst2.val)  
    res = res+one/eps;
if (ilst1.val != ilst2.val)  
    res = res+one/eps;
if (info1.val != info2.val)  
    res = res+one/eps;
// *
// *     Test for successful reordering of T2
// *
if (info2.val != 0)  {
    ninfo[(info2.val)- 1+ _ninfo_offset] = ninfo[(info2.val)- 1+ _ninfo_offset]+1;
}              // Close if()
else  {
  if (Math.abs(ifst2.val-ifstsv) > 1)  
    res = res+one/eps;
if (Math.abs(ilst2.val-ilstsv) > 1)  
    res = res+one/eps;
}              //  Close else.
// *
// *     Test for small residual, and orthogonality of Q
// *
Dhst01.dhst01(n,1,n,tmp,0,ldt,t2,0,ldt,q,0,ldt,work,0,lwork,result,0);
res = res+result[(1)- 1]+result[(2)- 1];
// *
// *     Test for T2 being in Schur form
// *
loc = 1;
label70:
   Dummy.label("Dget36",70);
if (t2[(loc+1)- 1+(loc- 1)*ldt] != zero)  {
    // *
// *        2 by 2 block
// *
if (t2[(loc)- 1+(loc+1- 1)*ldt] == zero || t2[(loc)- 1+(loc- 1)*ldt] != t2[(loc+1)- 1+(loc+1- 1)*ldt] || ((t2[(loc)- 1+(loc+1- 1)*ldt]) >= 0 ? Math.abs(one) : -Math.abs(one)) == ((t2[(loc+1)- 1+(loc- 1)*ldt]) >= 0 ? Math.abs(one) : -Math.abs(one)))  
    res = res+one/eps;
{
forloop80:
for (i = loc+2; i <= n; i++) {
if (t2[(i)- 1+(loc- 1)*ldt] != zero)  
    res = res+one/res;
if (t2[(i)- 1+(loc+1- 1)*ldt] != zero)  
    res = res+one/res;
Dummy.label("Dget36",80);
}              //  Close for() loop. 
}
loc = loc+2;
}              // Close if()
else  {
  // *
// *        1 by 1 block
// *
{
forloop90:
for (i = loc+1; i <= n; i++) {
if (t2[(i)- 1+(loc- 1)*ldt] != zero)  
    res = res+one/res;
Dummy.label("Dget36",90);
}              //  Close for() loop. 
}
loc = loc+1;
}              //  Close else.
if (loc < n)  
    Dummy.go_to("Dget36",70);
if (res > rmax.val)  {
    rmax.val = res;
lmax.val = knt.val;
}              // Close if()
Dummy.go_to("Dget36",10);
// *
// *     End of DGET36
// *
Dummy.label("Dget36",999999);
return;
   }
} // End class.
