/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget37 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET37 tests DTRSNA, a routine for estimating condition numbers of
// *  eigenvalues and/or right eigenvectors of a matrix.
// *
// *  The test matrices are read from a file with logical unit number NIN.
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION array, dimension (3)
// *          Value of the largest test ratio.
// *          RMAX(1) = largest ratio comparing different calls to DTRSNA
// *          RMAX(2) = largest error in reciprocal condition
// *                    numbers taking their conditioning into account
// *          RMAX(3) = largest error in reciprocal condition
// *                    numbers not taking their conditioning into
// *                    account (may be larger than RMAX(2))
// *
// *  LMAX    (output) INTEGER array, dimension (3)
// *          LMAX(i) is example number where largest test ratio
// *          RMAX(i) is achieved. Also:
// *          If DGEHRD returns INFO nonzero on example i, LMAX(1)=i
// *          If DHSEQR returns INFO nonzero on example i, LMAX(2)=i
// *          If DTRSNA returns INFO nonzero on example i, LMAX(3)=i
// *
// *  NINFO   (output) INTEGER array, dimension (3)
// *          NINFO(1) = 1 if DGEHRD returned INFO nonzero
// *          NINFO(2) = 1 if DHSEQR returned INFO nonzero
// *          NINFO(3) = 1 if DTRSNA returned INFO nonzero
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  NIN     (input) INTEGER
// *          Input logical unit number
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double epsin= 5.9605e-8;
static int ldt= 20;
static int lwork= 2*ldt*(10+ldt);
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int icmp= 0;
static int ifnd= 0;
static intW info= new intW(0);
static int iscl= 0;
static int j= 0;
static int kmin= 0;
static intW m= new intW(0);
static int n= 0;
static doubleW bignum= new doubleW(0.0);
static double eps= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double tnrm= 0.0;
static double tol= 0.0;
static double tolin= 0.0;
static double v= 0.0;
static double vimin= 0.0;
static double vmax= 0.0;
static double vmul= 0.0;
static double vrmin= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] select= new boolean[(ldt)];
static int [] iwork= new int[(2*ldt)];
static int [] lcmp= new int[(3)];
static double [] dum= new double[(1)];
static double [] le= new double[(ldt) * (ldt)];
static double [] re= new double[(ldt) * (ldt)];
static double [] s= new double[(ldt)];
static double [] sep= new double[(ldt)];
static double [] sepin= new double[(ldt)];
static double [] septmp= new double[(ldt)];
static double [] sin= new double[(ldt)];
static double [] stmp= new double[(ldt)];
static double [] t= new double[(ldt) * (ldt)];
static double [] tmp= new double[(ldt) * (ldt)];
static double [] val= new double[(3)];
static double [] wi= new double[(ldt)];
static double [] wiin= new double[(ldt)];
static double [] witmp= new double[(ldt)];
static double [] work= new double[(lwork)];
static double [] wr= new double[(ldt)];
static double [] wrin= new double[(ldt)];
static double [] wrtmp= new double[(ldt)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dget37 (double [] rmax, int _rmax_offset,
int [] lmax, int _lmax_offset,
int [] ninfo, int _ninfo_offset,
intW knt,
int nin)  {

  EasyIn _f2j_in = new EasyIn();
eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     EPSIN = 2**(-24) = precision to which input data computed
// *
eps = Math.max(eps, epsin) ;
rmax[(1)- 1+ _rmax_offset] = zero;
rmax[(2)- 1+ _rmax_offset] = zero;
rmax[(3)- 1+ _rmax_offset] = zero;
lmax[(1)- 1+ _lmax_offset] = 0;
lmax[(2)- 1+ _lmax_offset] = 0;
lmax[(3)- 1+ _lmax_offset] = 0;
knt.val = 0;
ninfo[(1)- 1+ _ninfo_offset] = 0;
ninfo[(2)- 1+ _ninfo_offset] = 0;
ninfo[(3)- 1+ _ninfo_offset] = 0;
// *
val[(1)- 1] = Math.sqrt(smlnum.val);
val[(2)- 1] = one;
val[(3)- 1] = Math.sqrt(bignum.val);
// *
// *     Read input data until N=0.  Assume input eigenvalues are sorted
// *     lexicographically (increasing by real part, then decreasing by
// *     imaginary part)
// *
label10:
   Dummy.label("Dget37",10);
n = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dget37",999999);
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
tmp[(i)- 1+(j- 1)*ldt] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dget37",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n; i++) {
wrin[(i)- 1] = _f2j_in.readDouble();
wiin[(i)- 1] = _f2j_in.readDouble();
sin[(i)- 1] = _f2j_in.readDouble();
sepin[(i)- 1] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dget37",30);
}              //  Close for() loop. 
}
tnrm = Dlange.dlange("M",n,n,tmp,0,ldt,work,0);
// *
// *     Begin test
// *
{
forloop240:
for (iscl = 1; iscl <= 3; iscl++) {
// *
// *        Scale input matrix
// *
knt.val = knt.val+1;
Dlacpy.dlacpy("F",n,n,tmp,0,ldt,t,0,ldt);
vmul = val[(iscl)- 1];
{
forloop40:
for (i = 1; i <= n; i++) {
Dscal.dscal(n,vmul,t,(1)- 1+(i- 1)*ldt,1);
Dummy.label("Dget37",40);
}              //  Close for() loop. 
}
if (tnrm == zero)  
    vmul = one;
// *
// *        Compute eigenvalues and eigenvectors
// *
Dgehrd.dgehrd(n,1,n,t,0,ldt,work,(1)- 1,work,(n+1)- 1,lwork-n,info);
if (info.val != 0)  {
    lmax[(1)- 1+ _lmax_offset] = knt.val;
ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop60:
for (j = 1; j <= n-2; j++) {
{
forloop50:
for (i = j+2; i <= n; i++) {
t[(i)- 1+(j- 1)*ldt] = zero;
Dummy.label("Dget37",50);
}              //  Close for() loop. 
}
Dummy.label("Dget37",60);
}              //  Close for() loop. 
}
// *
// *        Compute Schur form
// *
Dhseqr.dhseqr("S","N",n,1,n,t,0,ldt,wr,0,wi,0,dum,0,1,work,0,lwork,info);
if (info.val != 0)  {
    lmax[(2)- 1+ _lmax_offset] = knt.val;
ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
// *
// *        Compute eigenvectors
// *
Dtrevc.dtrevc("Both","All",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,n,m,work,0,info);
// *
// *        Compute condition numbers
// *
Dtrsna.dtrsna("Both","All",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,s,0,sep,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
// *
// *        Sort eigenvalues and condition numbers lexicographically
// *        to compare with inputs
// *
Dcopy.dcopy(n,wr,0,1,wrtmp,0,1);
Dcopy.dcopy(n,wi,0,1,witmp,0,1);
Dcopy.dcopy(n,s,0,1,stmp,0,1);
Dcopy.dcopy(n,sep,0,1,septmp,0,1);
Dscal.dscal(n,one/vmul,septmp,0,1);
{
forloop80:
for (i = 1; i <= n-1; i++) {
kmin = i;
vrmin = wrtmp[(i)- 1];
vimin = witmp[(i)- 1];
{
forloop70:
for (j = i+1; j <= n; j++) {
if (wrtmp[(j)- 1] < vrmin)  {
    kmin = j;
vrmin = wrtmp[(j)- 1];
vimin = witmp[(j)- 1];
}              // Close if()
Dummy.label("Dget37",70);
}              //  Close for() loop. 
}
wrtmp[(kmin)- 1] = wrtmp[(i)- 1];
witmp[(kmin)- 1] = witmp[(i)- 1];
wrtmp[(i)- 1] = vrmin;
witmp[(i)- 1] = vimin;
vrmin = stmp[(kmin)- 1];
stmp[(kmin)- 1] = stmp[(i)- 1];
stmp[(i)- 1] = vrmin;
vrmin = septmp[(kmin)- 1];
septmp[(kmin)- 1] = septmp[(i)- 1];
septmp[(i)- 1] = vrmin;
Dummy.label("Dget37",80);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvalues
// *        taking their condition numbers into account
// *
v = Math.max(two*(double)(n)*eps*tnrm, smlnum.val) ;
if (tnrm == zero)  
    v = one;
{
forloop90:
for (i = 1; i <= n; i++) {
if (v > septmp[(i)- 1])  {
    tol = one;
}              // Close if()
else  {
  tol = v/septmp[(i)- 1];
}              //  Close else.
if (v > sepin[(i)- 1])  {
    tolin = one;
}              // Close if()
else  {
  tolin = v/sepin[(i)- 1];
}              //  Close else.
tol = Math.max(tol, smlnum.val/eps) ;
tolin = Math.max(tolin, smlnum.val/eps) ;
if (eps*(sin[(i)- 1]-tolin) > stmp[(i)- 1]+tol)  {
    vmax = one/eps;
}              // Close if()
else if (sin[(i)- 1]-tolin > stmp[(i)- 1]+tol)  {
    vmax = (sin[(i)- 1]-tolin)/(stmp[(i)- 1]+tol);
}              // Close else if()
else if (sin[(i)- 1]+tolin < eps*(stmp[(i)- 1]-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (sin[(i)- 1]+tolin < stmp[(i)- 1]-tol)  {
    vmax = (stmp[(i)- 1]-tol)/(sin[(i)- 1]+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(2)- 1+ _rmax_offset])  {
    rmax[(2)- 1+ _rmax_offset] = vmax;
lmax[(2)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget37",90);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvectors
// *        taking their condition numbers into account
// *
{
forloop100:
for (i = 1; i <= n; i++) {
if (v > septmp[(i)- 1]*stmp[(i)- 1])  {
    tol = septmp[(i)- 1];
}              // Close if()
else  {
  tol = v/stmp[(i)- 1];
}              //  Close else.
if (v > sepin[(i)- 1]*sin[(i)- 1])  {
    tolin = sepin[(i)- 1];
}              // Close if()
else  {
  tolin = v/sin[(i)- 1];
}              //  Close else.
tol = Math.max(tol, smlnum.val/eps) ;
tolin = Math.max(tolin, smlnum.val/eps) ;
if (eps*(sepin[(i)- 1]-tolin) > septmp[(i)- 1]+tol)  {
    vmax = one/eps;
}              // Close if()
else if (sepin[(i)- 1]-tolin > septmp[(i)- 1]+tol)  {
    vmax = (sepin[(i)- 1]-tolin)/(septmp[(i)- 1]+tol);
}              // Close else if()
else if (sepin[(i)- 1]+tolin < eps*(septmp[(i)- 1]-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (sepin[(i)- 1]+tolin < septmp[(i)- 1]-tol)  {
    vmax = (septmp[(i)- 1]-tol)/(sepin[(i)- 1]+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(2)- 1+ _rmax_offset])  {
    rmax[(2)- 1+ _rmax_offset] = vmax;
lmax[(2)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget37",100);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvalues
// *        without taking their condition numbers into account
// *
{
forloop110:
for (i = 1; i <= n; i++) {
if (sin[(i)- 1] <= (double)(2*n)*eps && stmp[(i)- 1] <= (double)(2*n)*eps)  {
    vmax = one;
}              // Close if()
else if (eps*sin[(i)- 1] > stmp[(i)- 1])  {
    vmax = one/eps;
}              // Close else if()
else if (sin[(i)- 1] > stmp[(i)- 1])  {
    vmax = sin[(i)- 1]/stmp[(i)- 1];
}              // Close else if()
else if (sin[(i)- 1] < eps*stmp[(i)- 1])  {
    vmax = one/eps;
}              // Close else if()
else if (sin[(i)- 1] < stmp[(i)- 1])  {
    vmax = stmp[(i)- 1]/sin[(i)- 1];
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(3)- 1+ _rmax_offset])  {
    rmax[(3)- 1+ _rmax_offset] = vmax;
lmax[(3)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget37",110);
}              //  Close for() loop. 
}
// *
// *        Compare condition numbers for eigenvectors
// *        without taking their condition numbers into account
// *
{
forloop120:
for (i = 1; i <= n; i++) {
if (sepin[(i)- 1] <= v && septmp[(i)- 1] <= v)  {
    vmax = one;
}              // Close if()
else if (eps*sepin[(i)- 1] > septmp[(i)- 1])  {
    vmax = one/eps;
}              // Close else if()
else if (sepin[(i)- 1] > septmp[(i)- 1])  {
    vmax = sepin[(i)- 1]/septmp[(i)- 1];
}              // Close else if()
else if (sepin[(i)- 1] < eps*septmp[(i)- 1])  {
    vmax = one/eps;
}              // Close else if()
else if (sepin[(i)- 1] < septmp[(i)- 1])  {
    vmax = septmp[(i)- 1]/sepin[(i)- 1];
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(3)- 1+ _rmax_offset])  {
    rmax[(3)- 1+ _rmax_offset] = vmax;
lmax[(3)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget37",120);
}              //  Close for() loop. 
}
// *
// *        Compute eigenvalue condition numbers only and compare
// *
vmax = zero;
dum[(1)- 1] = -one;
Dcopy.dcopy(n,dum,0,0,stmp,0,1);
Dcopy.dcopy(n,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Eigcond","All",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop130:
for (i = 1; i <= n; i++) {
if (stmp[(i)- 1] != s[(i)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",130);
}              //  Close for() loop. 
}
// *
// *        Compute eigenvector condition numbers only and compare
// *
Dcopy.dcopy(n,dum,0,0,stmp,0,1);
Dcopy.dcopy(n,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Veccond","All",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop140:
for (i = 1; i <= n; i++) {
if (stmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != sep[(i)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",140);
}              //  Close for() loop. 
}
// *
// *        Compute all condition numbers using SELECT and compare
// *
{
forloop150:
for (i = 1; i <= n; i++) {
select[(i)- 1] = true;
Dummy.label("Dget37",150);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,dum,0,0,stmp,0,1);
Dcopy.dcopy(n,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Bothcond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop160:
for (i = 1; i <= n; i++) {
if (septmp[(i)- 1] != sep[(i)- 1])  
    vmax = one/eps;
if (stmp[(i)- 1] != s[(i)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",160);
}              //  Close for() loop. 
}
// *
// *        Compute eigenvalue condition numbers using SELECT and compare
// *
Dcopy.dcopy(n,dum,0,0,stmp,0,1);
Dcopy.dcopy(n,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Eigcond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop170:
for (i = 1; i <= n; i++) {
if (stmp[(i)- 1] != s[(i)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",170);
}              //  Close for() loop. 
}
// *
// *        Compute eigenvector condition numbers using SELECT and compare
// *
Dcopy.dcopy(n,dum,0,0,stmp,0,1);
Dcopy.dcopy(n,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Veccond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop180:
for (i = 1; i <= n; i++) {
if (stmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != sep[(i)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",180);
}              //  Close for() loop. 
}
if (vmax > rmax[(1)- 1+ _rmax_offset])  {
    rmax[(1)- 1+ _rmax_offset] = vmax;
lmax[(1)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Select first real and first complex eigenvalue
// *
if (wi[(1)- 1] == zero)  {
    lcmp[(1)- 1] = 1;
ifnd = 0;
{
forloop190:
for (i = 2; i <= n; i++) {
if (ifnd == 1 || wi[(i)- 1] == zero)  {
    select[(i)- 1] = false;
}              // Close if()
else  {
  ifnd = 1;
lcmp[(2)- 1] = i;
lcmp[(3)- 1] = i+1;
Dcopy.dcopy(n,re,(1)- 1+(i- 1)*ldt,1,re,(1)- 1+(2- 1)*ldt,1);
Dcopy.dcopy(n,re,(1)- 1+(i+1- 1)*ldt,1,re,(1)- 1+(3- 1)*ldt,1);
Dcopy.dcopy(n,le,(1)- 1+(i- 1)*ldt,1,le,(1)- 1+(2- 1)*ldt,1);
Dcopy.dcopy(n,le,(1)- 1+(i+1- 1)*ldt,1,le,(1)- 1+(3- 1)*ldt,1);
}              //  Close else.
Dummy.label("Dget37",190);
}              //  Close for() loop. 
}
if (ifnd == 0)  {
    icmp = 1;
}              // Close if()
else  {
  icmp = 3;
}              //  Close else.
}              // Close if()
else  {
  lcmp[(1)- 1] = 1;
lcmp[(2)- 1] = 2;
ifnd = 0;
{
forloop200:
for (i = 3; i <= n; i++) {
if (ifnd == 1 || wi[(i)- 1] != zero)  {
    select[(i)- 1] = false;
}              // Close if()
else  {
  lcmp[(3)- 1] = i;
ifnd = 1;
Dcopy.dcopy(n,re,(1)- 1+(i- 1)*ldt,1,re,(1)- 1+(3- 1)*ldt,1);
Dcopy.dcopy(n,le,(1)- 1+(i- 1)*ldt,1,le,(1)- 1+(3- 1)*ldt,1);
}              //  Close else.
Dummy.label("Dget37",200);
}              //  Close for() loop. 
}
if (ifnd == 0)  {
    icmp = 2;
}              // Close if()
else  {
  icmp = 3;
}              //  Close else.
}              //  Close else.
// *
// *        Compute all selected condition numbers
// *
Dcopy.dcopy(icmp,dum,0,0,stmp,0,1);
Dcopy.dcopy(icmp,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Bothcond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop210:
for (i = 1; i <= icmp; i++) {
j = lcmp[(i)- 1];
if (septmp[(i)- 1] != sep[(j)- 1])  
    vmax = one/eps;
if (stmp[(i)- 1] != s[(j)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",210);
}              //  Close for() loop. 
}
// *
// *        Compute selected eigenvalue condition numbers
// *
Dcopy.dcopy(icmp,dum,0,0,stmp,0,1);
Dcopy.dcopy(icmp,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Eigcond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop220:
for (i = 1; i <= icmp; i++) {
j = lcmp[(i)- 1];
if (stmp[(i)- 1] != s[(j)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",220);
}              //  Close for() loop. 
}
// *
// *        Compute selected eigenvector condition numbers
// *
Dcopy.dcopy(icmp,dum,0,0,stmp,0,1);
Dcopy.dcopy(icmp,dum,0,0,septmp,0,1);
Dtrsna.dtrsna("Veccond","Some",select,0,n,t,0,ldt,le,0,ldt,re,0,ldt,stmp,0,septmp,0,n,m,work,0,n,iwork,0,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget37",999999);
}              // Close if()
{
forloop230:
for (i = 1; i <= icmp; i++) {
j = lcmp[(i)- 1];
if (stmp[(i)- 1] != dum[(1)- 1])  
    vmax = one/eps;
if (septmp[(i)- 1] != sep[(j)- 1])  
    vmax = one/eps;
Dummy.label("Dget37",230);
}              //  Close for() loop. 
}
if (vmax > rmax[(1)- 1+ _rmax_offset])  {
    rmax[(1)- 1+ _rmax_offset] = vmax;
lmax[(1)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget37",240);
}              //  Close for() loop. 
}
Dummy.go_to("Dget37",10);
// *
// *     End of DGET37
// *
Dummy.label("Dget37",999999);
return;
   }
} // End class.
