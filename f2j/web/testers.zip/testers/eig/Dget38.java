/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget38 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET38 tests DTRSEN, a routine for estimating condition numbers of a
// *  cluster of eigenvalues and/or its associated right invariant subspace
// *
// *  The test matrices are read from a file with logical unit number NIN.
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION array, dimension (3)
// *          Values of the largest test ratios.
// *          RMAX(1) = largest residuals from DHST01 or comparing
// *                    different calls to DTRSEN
// *          RMAX(2) = largest error in reciprocal condition
// *                    numbers taking their conditioning into account
// *          RMAX(3) = largest error in reciprocal condition
// *                    numbers not taking their conditioning into
// *                    account (may be larger than RMAX(2))
// *
// *  LMAX    (output) INTEGER array, dimension (3)
// *          LMAX(i) is example number where largest test ratio
// *          RMAX(i) is achieved. Also:
// *          If DGEHRD returns INFO nonzero on example i, LMAX(1)=i
// *          If DHSEQR returns INFO nonzero on example i, LMAX(2)=i
// *          If DTRSEN returns INFO nonzero on example i, LMAX(3)=i
// *
// *  NINFO   (output) INTEGER array, dimension (3)
// *          NINFO(1) = 1 if DGEHRD returned INFO nonzero
// *          NINFO(2) = 1 if DHSEQR returned INFO nonzero
// *          NINFO(3) = 1 if DTRSEN returned INFO nonzero
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  NIN     (input) INTEGER
// *          Input logical unit number.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double epsin= 5.9605e-8;
static int ldt= 20;
static int lwork= 2*ldt*(10+ldt);
static int liwork= ldt*ldt;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int iscl= 0;
static int itmp= 0;
static int j= 0;
static int kmin= 0;
static intW m= new intW(0);
static int n= 0;
static int ndim= 0;
static doubleW bignum= new doubleW(0.0);
static double eps= 0.0;
static doubleW s= new doubleW(0.0);
static doubleW sep= new doubleW(0.0);
static double sepin= 0.0;
static doubleW septmp= new doubleW(0.0);
static double sin= 0.0;
static doubleW smlnum= new doubleW(0.0);
static doubleW stmp= new doubleW(0.0);
static double tnrm= 0.0;
static double tol= 0.0;
static double tolin= 0.0;
static double v= 0.0;
static double vimin= 0.0;
static double vmax= 0.0;
static double vmul= 0.0;
static double vrmin= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] select= new boolean[(ldt)];
static int [] ipnt= new int[(ldt)];
static int [] iselec= new int[(ldt)];
static int [] iwork= new int[(liwork)];
static double [] q= new double[(ldt) * (ldt)];
static double [] qsav= new double[(ldt) * (ldt)];
static double [] qtmp= new double[(ldt) * (ldt)];
static double [] result= new double[(2)];
static double [] t= new double[(ldt) * (ldt)];
static double [] tmp= new double[(ldt) * (ldt)];
static double [] tsav= new double[(ldt) * (ldt)];
static double [] tsav1= new double[(ldt) * (ldt)];
static double [] ttmp= new double[(ldt) * (ldt)];
static double [] val= new double[(3)];
static double [] wi= new double[(ldt)];
static double [] witmp= new double[(ldt)];
static double [] work= new double[(lwork)];
static double [] wr= new double[(ldt)];
static double [] wrtmp= new double[(ldt)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dget38 (double [] rmax, int _rmax_offset,
int [] lmax, int _lmax_offset,
int [] ninfo, int _ninfo_offset,
intW knt,
int nin)  {

  EasyIn _f2j_in = new EasyIn();
eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S")/eps;
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     EPSIN = 2**(-24) = precision to which input data computed
// *
eps = Math.max(eps, epsin) ;
rmax[(1)- 1+ _rmax_offset] = zero;
rmax[(2)- 1+ _rmax_offset] = zero;
rmax[(3)- 1+ _rmax_offset] = zero;
lmax[(1)- 1+ _lmax_offset] = 0;
lmax[(2)- 1+ _lmax_offset] = 0;
lmax[(3)- 1+ _lmax_offset] = 0;
knt.val = 0;
ninfo[(1)- 1+ _ninfo_offset] = 0;
ninfo[(2)- 1+ _ninfo_offset] = 0;
ninfo[(3)- 1+ _ninfo_offset] = 0;
// *
val[(1)- 1] = Math.sqrt(smlnum.val);
val[(2)- 1] = one;
val[(3)- 1] = Math.sqrt(Math.sqrt(bignum.val));
// *
// *     Read input data until N=0.  Assume input eigenvalues are sorted
// *     lexicographically (increasing by real part, then decreasing by
// *     imaginary part)
// *
label10:
   Dummy.label("Dget38",10);
n = _f2j_in.readInt();
ndim = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (n == 0)  
    Dummy.go_to("Dget38",999999);
for(i = 1; i <= ndim; i++)
iselec[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop20:
for (i = 1; i <= n; i++) {
for(j = 1; j <= n; j++)
tmp[(i)- 1+(j- 1)*ldt] = _f2j_in.readDouble();
_f2j_in.skipRemaining();
Dummy.label("Dget38",20);
}              //  Close for() loop. 
}
sin = _f2j_in.readDouble();
sepin = _f2j_in.readDouble();
_f2j_in.skipRemaining();
// *
tnrm = Dlange.dlange("M",n,n,tmp,0,ldt,work,0);
{
forloop160:
for (iscl = 1; iscl <= 3; iscl++) {
// *
// *        Scale input matrix
// *
knt.val = knt.val+1;
Dlacpy.dlacpy("F",n,n,tmp,0,ldt,t,0,ldt);
vmul = val[(iscl)- 1];
{
forloop30:
for (i = 1; i <= n; i++) {
Dscal.dscal(n,vmul,t,(1)- 1+(i- 1)*ldt,1);
Dummy.label("Dget38",30);
}              //  Close for() loop. 
}
if (tnrm == zero)  
    vmul = one;
Dlacpy.dlacpy("F",n,n,t,0,ldt,tsav,0,ldt);
// *
// *        Compute Schur form
// *
Dgehrd.dgehrd(n,1,n,t,0,ldt,work,(1)- 1,work,(n+1)- 1,lwork-n,info);
if (info.val != 0)  {
    lmax[(1)- 1+ _lmax_offset] = knt.val;
ninfo[(1)- 1+ _ninfo_offset] = ninfo[(1)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
// *
// *        Generate orthogonal matrix
// *
Dlacpy.dlacpy("L",n,n,t,0,ldt,q,0,ldt);
Dorghr.dorghr(n,1,n,q,0,ldt,work,(1)- 1,work,(n+1)- 1,lwork-n,info);
// *
// *        Compute Schur form
// *
Dhseqr.dhseqr("S","V",n,1,n,t,0,ldt,wr,0,wi,0,q,0,ldt,work,0,lwork,info);
if (info.val != 0)  {
    lmax[(2)- 1+ _lmax_offset] = knt.val;
ninfo[(2)- 1+ _ninfo_offset] = ninfo[(2)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
// *
// *        Sort, select eigenvalues
// *
{
forloop40:
for (i = 1; i <= n; i++) {
ipnt[(i)- 1] = i;
select[(i)- 1] = false;
Dummy.label("Dget38",40);
}              //  Close for() loop. 
}
Dcopy.dcopy(n,wr,0,1,wrtmp,0,1);
Dcopy.dcopy(n,wi,0,1,witmp,0,1);
{
forloop60:
for (i = 1; i <= n-1; i++) {
kmin = i;
vrmin = wrtmp[(i)- 1];
vimin = witmp[(i)- 1];
{
forloop50:
for (j = i+1; j <= n; j++) {
if (wrtmp[(j)- 1] < vrmin)  {
    kmin = j;
vrmin = wrtmp[(j)- 1];
vimin = witmp[(j)- 1];
}              // Close if()
Dummy.label("Dget38",50);
}              //  Close for() loop. 
}
wrtmp[(kmin)- 1] = wrtmp[(i)- 1];
witmp[(kmin)- 1] = witmp[(i)- 1];
wrtmp[(i)- 1] = vrmin;
witmp[(i)- 1] = vimin;
itmp = ipnt[(i)- 1];
ipnt[(i)- 1] = ipnt[(kmin)- 1];
ipnt[(kmin)- 1] = itmp;
Dummy.label("Dget38",60);
}              //  Close for() loop. 
}
{
forloop70:
for (i = 1; i <= ndim; i++) {
select[(ipnt[(iselec[(i)- 1])- 1])- 1] = true;
Dummy.label("Dget38",70);
}              //  Close for() loop. 
}
// *
// *        Compute condition numbers
// *
Dlacpy.dlacpy("F",n,n,q,0,ldt,qsav,0,ldt);
Dlacpy.dlacpy("F",n,n,t,0,ldt,tsav1,0,ldt);
Dtrsen.dtrsen("B","V",select,0,n,t,0,ldt,q,0,ldt,wrtmp,0,witmp,0,m,s,sep,work,0,lwork,iwork,0,liwork,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
septmp.val = sep.val/vmul;
stmp.val = s.val;
// *
// *        Compute residuals
// *
Dhst01.dhst01(n,1,n,tsav,0,ldt,t,0,ldt,q,0,ldt,work,0,lwork,result,0);
vmax = Math.max(result[(1)- 1], result[(2)- 1]) ;
if (vmax > rmax[(1)- 1+ _rmax_offset])  {
    rmax[(1)- 1+ _rmax_offset] = vmax;
lmax[(1)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Compare condition number for eigenvalue cluster
// *        taking its condition number into account
// *
v = Math.max(two*(double)(n)*eps*tnrm, smlnum.val) ;
if (tnrm == zero)  
    v = one;
if (v > septmp.val)  {
    tol = one;
}              // Close if()
else  {
  tol = v/septmp.val;
}              //  Close else.
if (v > sepin)  {
    tolin = one;
}              // Close if()
else  {
  tolin = v/sepin;
}              //  Close else.
tol = Math.max(tol, smlnum.val/eps) ;
tolin = Math.max(tolin, smlnum.val/eps) ;
if (eps*(sin-tolin) > stmp.val+tol)  {
    vmax = one/eps;
}              // Close if()
else if (sin-tolin > stmp.val+tol)  {
    vmax = (sin-tolin)/(stmp.val+tol);
}              // Close else if()
else if (sin+tolin < eps*(stmp.val-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (sin+tolin < stmp.val-tol)  {
    vmax = (stmp.val-tol)/(sin+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(2)- 1+ _rmax_offset])  {
    rmax[(2)- 1+ _rmax_offset] = vmax;
lmax[(2)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Compare condition numbers for invariant subspace
// *        taking its condition number into account
// *
if (v > septmp.val*stmp.val)  {
    tol = septmp.val;
}              // Close if()
else  {
  tol = v/stmp.val;
}              //  Close else.
if (v > sepin*sin)  {
    tolin = sepin;
}              // Close if()
else  {
  tolin = v/sin;
}              //  Close else.
tol = Math.max(tol, smlnum.val/eps) ;
tolin = Math.max(tolin, smlnum.val/eps) ;
if (eps*(sepin-tolin) > septmp.val+tol)  {
    vmax = one/eps;
}              // Close if()
else if (sepin-tolin > septmp.val+tol)  {
    vmax = (sepin-tolin)/(septmp.val+tol);
}              // Close else if()
else if (sepin+tolin < eps*(septmp.val-tol))  {
    vmax = one/eps;
}              // Close else if()
else if (sepin+tolin < septmp.val-tol)  {
    vmax = (septmp.val-tol)/(sepin+tolin);
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(2)- 1+ _rmax_offset])  {
    rmax[(2)- 1+ _rmax_offset] = vmax;
lmax[(2)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Compare condition number for eigenvalue cluster
// *        without taking its condition number into account
// *
if (sin <= (double)(2*n)*eps && stmp.val <= (double)(2*n)*eps)  {
    vmax = one;
}              // Close if()
else if (eps*sin > stmp.val)  {
    vmax = one/eps;
}              // Close else if()
else if (sin > stmp.val)  {
    vmax = sin/stmp.val;
}              // Close else if()
else if (sin < eps*stmp.val)  {
    vmax = one/eps;
}              // Close else if()
else if (sin < stmp.val)  {
    vmax = stmp.val/sin;
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(3)- 1+ _rmax_offset])  {
    rmax[(3)- 1+ _rmax_offset] = vmax;
lmax[(3)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Compare condition numbers for invariant subspace
// *        without taking its condition number into account
// *
if (sepin <= v && septmp.val <= v)  {
    vmax = one;
}              // Close if()
else if (eps*sepin > septmp.val)  {
    vmax = one/eps;
}              // Close else if()
else if (sepin > septmp.val)  {
    vmax = sepin/septmp.val;
}              // Close else if()
else if (sepin < eps*septmp.val)  {
    vmax = one/eps;
}              // Close else if()
else if (sepin < septmp.val)  {
    vmax = septmp.val/sepin;
}              // Close else if()
else  {
  vmax = one;
}              //  Close else.
if (vmax > rmax[(3)- 1+ _rmax_offset])  {
    rmax[(3)- 1+ _rmax_offset] = vmax;
lmax[(3)- 1+ _lmax_offset] = knt.val;
}              // Close if()
// *
// *        Compute eigenvalue condition number only and compare
// *        Update Q
// *
vmax = zero;
Dlacpy.dlacpy("F",n,n,tsav1,0,ldt,ttmp,0,ldt);
Dlacpy.dlacpy("F",n,n,qsav,0,ldt,qtmp,0,ldt);
septmp.val = -one;
stmp.val = -one;
Dtrsen.dtrsen("E","V",select,0,n,ttmp,0,ldt,qtmp,0,ldt,wrtmp,0,witmp,0,m,stmp,septmp,work,0,lwork,iwork,0,liwork,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
if (s.val != stmp.val)  
    vmax = one/eps;
if (-one != septmp.val)  
    vmax = one/eps;
{
forloop90:
for (i = 1; i <= n; i++) {
{
forloop80:
for (j = 1; j <= n; j++) {
if (ttmp[(i)- 1+(j- 1)*ldt] != t[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
if (qtmp[(i)- 1+(j- 1)*ldt] != q[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
Dummy.label("Dget38",80);
}              //  Close for() loop. 
}
Dummy.label("Dget38",90);
}              //  Close for() loop. 
}
// *
// *        Compute invariant subspace condition number only and compare
// *        Update Q
// *
Dlacpy.dlacpy("F",n,n,tsav1,0,ldt,ttmp,0,ldt);
Dlacpy.dlacpy("F",n,n,qsav,0,ldt,qtmp,0,ldt);
septmp.val = -one;
stmp.val = -one;
Dtrsen.dtrsen("V","V",select,0,n,ttmp,0,ldt,qtmp,0,ldt,wrtmp,0,witmp,0,m,stmp,septmp,work,0,lwork,iwork,0,liwork,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
if (-one != stmp.val)  
    vmax = one/eps;
if (sep.val != septmp.val)  
    vmax = one/eps;
{
forloop110:
for (i = 1; i <= n; i++) {
{
forloop100:
for (j = 1; j <= n; j++) {
if (ttmp[(i)- 1+(j- 1)*ldt] != t[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
if (qtmp[(i)- 1+(j- 1)*ldt] != q[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
Dummy.label("Dget38",100);
}              //  Close for() loop. 
}
Dummy.label("Dget38",110);
}              //  Close for() loop. 
}
// *
// *        Compute eigenvalue condition number only and compare
// *        Do not update Q
// *
Dlacpy.dlacpy("F",n,n,tsav1,0,ldt,ttmp,0,ldt);
Dlacpy.dlacpy("F",n,n,qsav,0,ldt,qtmp,0,ldt);
septmp.val = -one;
stmp.val = -one;
Dtrsen.dtrsen("E","N",select,0,n,ttmp,0,ldt,qtmp,0,ldt,wrtmp,0,witmp,0,m,stmp,septmp,work,0,lwork,iwork,0,liwork,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
if (s.val != stmp.val)  
    vmax = one/eps;
if (-one != septmp.val)  
    vmax = one/eps;
{
forloop130:
for (i = 1; i <= n; i++) {
{
forloop120:
for (j = 1; j <= n; j++) {
if (ttmp[(i)- 1+(j- 1)*ldt] != t[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
if (qtmp[(i)- 1+(j- 1)*ldt] != qsav[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
Dummy.label("Dget38",120);
}              //  Close for() loop. 
}
Dummy.label("Dget38",130);
}              //  Close for() loop. 
}
// *
// *        Compute invariant subspace condition number only and compare
// *        Do not update Q
// *
Dlacpy.dlacpy("F",n,n,tsav1,0,ldt,ttmp,0,ldt);
Dlacpy.dlacpy("F",n,n,qsav,0,ldt,qtmp,0,ldt);
septmp.val = -one;
stmp.val = -one;
Dtrsen.dtrsen("V","N",select,0,n,ttmp,0,ldt,qtmp,0,ldt,wrtmp,0,witmp,0,m,stmp,septmp,work,0,lwork,iwork,0,liwork,info);
if (info.val != 0)  {
    lmax[(3)- 1+ _lmax_offset] = knt.val;
ninfo[(3)- 1+ _ninfo_offset] = ninfo[(3)- 1+ _ninfo_offset]+1;
Dummy.go_to("Dget38",999999);
}              // Close if()
if (-one != stmp.val)  
    vmax = one/eps;
if (sep.val != septmp.val)  
    vmax = one/eps;
{
forloop150:
for (i = 1; i <= n; i++) {
{
forloop140:
for (j = 1; j <= n; j++) {
if (ttmp[(i)- 1+(j- 1)*ldt] != t[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
if (qtmp[(i)- 1+(j- 1)*ldt] != qsav[(i)- 1+(j- 1)*ldt])  
    vmax = one/eps;
Dummy.label("Dget38",140);
}              //  Close for() loop. 
}
Dummy.label("Dget38",150);
}              //  Close for() loop. 
}
if (vmax > rmax[(1)- 1+ _rmax_offset])  {
    rmax[(1)- 1+ _rmax_offset] = vmax;
lmax[(1)- 1+ _lmax_offset] = knt.val;
}              // Close if()
Dummy.label("Dget38",160);
}              //  Close for() loop. 
}
Dummy.go_to("Dget38",10);
// *
// *     End of DGET38
// *
Dummy.label("Dget38",999999);
return;
   }
} // End class.
