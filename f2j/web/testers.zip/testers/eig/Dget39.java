/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget39 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET39 tests DLAQTR, a routine for solving the real or
// *  special complex quasi upper triangular system
// *
// *       op(T)*p = scale*c,
// *  or
// *       op(T + iB)*(p+iq) = scale*(c+id),
// *
// *  in real arithmetic. T is upper quasi-triangular.
// *  If it is complex, then the first diagonal block of T must be
// *  1 by 1, B has the special structure
// *
// *                 B = [ b(1) b(2) ... b(n) ]
// *                     [       w            ]
// *                     [           w        ]
// *                     [              .     ]
// *                     [                 w  ]
// *
// *  op(A) = A or A', where A' denotes the conjugate transpose of
// *  the matrix A.
// *
// *  On input, X = [ c ].  On output, X = [ p ].
// *                [ d ]                  [ q ]
// *
// *  Scale is an output less than or equal to 1, chosen to avoid
// *  overflow in X.
// *  This subroutine is specially designed for the condition number
// *  estimation in the eigenproblem routine DTRSNA.
// *
// *  The test code verifies that the following residual is order 1:
// *
// *       ||(T+i*B)*(x1+i*x2) - scale*(d1+i*d2)||
// *     -----------------------------------------
// *         max(ulp*(||T||+||B||)*(||x1||+||x2||),
// *             (||T||+||B||)*smlnum/ulp,
// *             smlnum)
// *
// *  (The (||T||+||B||)*smlnum/ulp term accounts for possible
// *   (gradual or nongradual) underflow in x1 and x2.)
// *
// *  Arguments
// *  ==========
// *
// *  RMAX    (output) DOUBLE PRECISION
// *          Value of the largest test ratio.
// *
// *  LMAX    (output) INTEGER
// *          Example number where largest test ratio achieved.
// *
// *  NINFO   (output) INTEGER
// *          Number of examples where INFO is nonzero.
// *
// *  KNT     (output) INTEGER
// *          Total number of examples tested.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ldt= 10;
static int ldt2= 2*ldt;
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int ivm1= 0;
static int ivm2= 0;
static int ivm3= 0;
static int ivm4= 0;
static int ivm5= 0;
static int j= 0;
static int k= 0;
static int n= 0;
static int ndim= 0;
static doubleW bignum= new doubleW(0.0);
static double domin= 0.0;
static double dumm= 0.0;
static double eps= 0.0;
static double norm= 0.0;
static double normtb= 0.0;
static double resid= 0.0;
static doubleW scale= new doubleW(0.0);
static doubleW smlnum= new doubleW(0.0);
static double w= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Local Arrays ..
static double [] b= new double[(ldt)];
static double [] d= new double[(ldt2)];
static double [] dum= new double[(1)];
static double [] t= new double[(ldt) * (ldt)];
static double [] vm1= new double[(5)];
static double [] vm2= new double[(5)];
static double [] vm3= new double[(5)];
static double [] vm4= new double[(5)];
static double [] vm5= new double[(3)];
static double [] work= new double[(ldt)];
static double [] x= new double[(ldt2)];
static double [] y= new double[(ldt2)];
// *     ..
// *     .. Data statements ..
static int [] idim = {4 
, 5, 5, 5, 5, 5 };
static int [] ival = {3 
, 0, 0, 0, 0 , 1 , 1 , -1 , 0 
, 0 , 3 , 2 , 1 , 0 
, 0 , 4 , 3 , 2 , 2 
, 0 , 0, 0, 0, 0, 0 , 1 , 0, 0, 0, 0 , 2 
, 2 , 0, 0, 0 , 3 , 3 , 4 
, 0 , 0 , 4 , 2 , 2 
, 3 , 0 , 1, 1, 1, 1 , 5 , 1 
, 0, 0, 0, 0 , 2 , 4 , -2 , 0 
, 0 , 3 , 3 , 4 , 0 
, 0 , 4 , 2 , 2 , 3 
, 0 , 1, 1, 1, 1, 1 , 1 , 0, 0, 0, 0 , 2 
, 1 , -1 , 0 , 0 , 9 
, 8 , 1 , 0 , 0 , 4 
, 9 , 1 , 2 , -1 , 2, 2, 2, 2, 2 
, 9 , 0, 0, 0, 0 , 6 , 4 , 0 
, 0 , 0 , 3 , 2 , 1 
, 1 , 0 , 5 , 1 , -1 
, 1 , 0 , 2, 2, 2, 2, 2 , 4 , 0, 0, 0, 0 
, 2 , 2 , 0 , 0 , 0 
, 1 , 4 , 4 , 0 , 0 
, 2 , 4 , 2 , 2 , -1 
, 2, 2, 2, 2, 2 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine parameters
// *

public static void dget39 (doubleW rmax,
intW lmax,
intW ninfo,
intW knt)  {

eps = Dlamch.dlamch("P");
smlnum.val = Dlamch.dlamch("S");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Set up test case parameters
// *
vm1[(1)- 1] = one;
vm1[(2)- 1] = Math.sqrt(smlnum.val);
vm1[(3)- 1] = Math.sqrt(vm1[(2)- 1]);
vm1[(4)- 1] = Math.sqrt(bignum.val);
vm1[(5)- 1] = Math.sqrt(vm1[(4)- 1]);
// *
vm2[(1)- 1] = one;
vm2[(2)- 1] = Math.sqrt(smlnum.val);
vm2[(3)- 1] = Math.sqrt(vm2[(2)- 1]);
vm2[(4)- 1] = Math.sqrt(bignum.val);
vm2[(5)- 1] = Math.sqrt(vm2[(4)- 1]);
// *
vm3[(1)- 1] = one;
vm3[(2)- 1] = Math.sqrt(smlnum.val);
vm3[(3)- 1] = Math.sqrt(vm3[(2)- 1]);
vm3[(4)- 1] = Math.sqrt(bignum.val);
vm3[(5)- 1] = Math.sqrt(vm3[(4)- 1]);
// *
vm4[(1)- 1] = one;
vm4[(2)- 1] = Math.sqrt(smlnum.val);
vm4[(3)- 1] = Math.sqrt(vm4[(2)- 1]);
vm4[(4)- 1] = Math.sqrt(bignum.val);
vm4[(5)- 1] = Math.sqrt(vm4[(4)- 1]);
// *
vm5[(1)- 1] = one;
vm5[(2)- 1] = eps;
vm5[(3)- 1] = Math.sqrt(smlnum.val);
// *
// *     Initalization
// *
knt.val = 0;
rmax.val = zero;
ninfo.val = 0;
smlnum.val = smlnum.val/eps;
// *
// *     Begin test loop
// *
{
forloop140:
for (ivm5 = 1; ivm5 <= 3; ivm5++) {
{
forloop130:
for (ivm4 = 1; ivm4 <= 5; ivm4++) {
{
forloop120:
for (ivm3 = 1; ivm3 <= 5; ivm3++) {
{
forloop110:
for (ivm2 = 1; ivm2 <= 5; ivm2++) {
{
forloop100:
for (ivm1 = 1; ivm1 <= 5; ivm1++) {
{
forloop90:
for (ndim = 1; ndim <= 6; ndim++) {
// *
n = idim[(ndim)- 1];
{
forloop20:
for (i = 1; i <= n; i++) {
{
forloop10:
for (j = 1; j <= n; j++) {
t[(i)- 1+(j- 1)*ldt] = (double)(ival[(i)+(((j)+((ndim) * 5)) *5) - 31])*vm1[(ivm1)- 1];
if (i >= j)  
    t[(i)- 1+(j- 1)*ldt] = t[(i)- 1+(j- 1)*ldt]*vm5[(ivm5)- 1];
Dummy.label("Dget39",10);
}              //  Close for() loop. 
}
Dummy.label("Dget39",20);
}              //  Close for() loop. 
}
// *
w = one*vm2[(ivm2)- 1];
// *
{
forloop30:
for (i = 1; i <= n; i++) {
b[(i)- 1] = Math.cos((double)(i))*vm3[(ivm3)- 1];
Dummy.label("Dget39",30);
}              //  Close for() loop. 
}
// *
{
forloop40:
for (i = 1; i <= 2*n; i++) {
d[(i)- 1] = Math.sin((double)(i))*vm4[(ivm4)- 1];
Dummy.label("Dget39",40);
}              //  Close for() loop. 
}
// *
norm = Dlange.dlange("1",n,n,t,0,ldt,work,0);
k = Idamax.idamax(n,b,0,1);
normtb = norm+Math.abs(b[(k)- 1])+Math.abs(w);
// *
Dcopy.dcopy(n,d,0,1,x,0,1);
knt.val = knt.val+1;
Dlaqtr.dlaqtr(false,true,n,t,0,ldt,dum,0,dumm,scale,x,0,work,0,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
// *
// *                       || T*x - scale*d || /
// *                         max(ulp*||T||*||x||,smlnum/ulp*||T||,smlnum)
// *
Dcopy.dcopy(n,d,0,1,y,0,1);
Dgemv.dgemv("No transpose",n,n,one,t,0,ldt,x,0,1,-scale.val,y,0,1);
xnorm = Dasum.dasum(n,x,0,1);
resid = Dasum.dasum(n,y,0,1);
domin = Math.max((smlnum.val) > ((smlnum.val/eps)*norm) ? (smlnum.val) : ((smlnum.val/eps)*norm), (norm*eps)*xnorm);
resid = resid/domin;
if (resid > rmax.val)  {
    rmax.val = resid;
lmax.val = knt.val;
}              // Close if()
// *
Dcopy.dcopy(n,d,0,1,x,0,1);
knt.val = knt.val+1;
Dlaqtr.dlaqtr(true,true,n,t,0,ldt,dum,0,dumm,scale,x,0,work,0,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
// *
// *                       || T*x - scale*d || /
// *                         max(ulp*||T||*||x||,smlnum/ulp*||T||,smlnum)
// *
Dcopy.dcopy(n,d,0,1,y,0,1);
Dgemv.dgemv("Transpose",n,n,one,t,0,ldt,x,0,1,-scale.val,y,0,1);
xnorm = Dasum.dasum(n,x,0,1);
resid = Dasum.dasum(n,y,0,1);
domin = Math.max((smlnum.val) > ((smlnum.val/eps)*norm) ? (smlnum.val) : ((smlnum.val/eps)*norm), (norm*eps)*xnorm);
resid = resid/domin;
if (resid > rmax.val)  {
    rmax.val = resid;
lmax.val = knt.val;
}              // Close if()
// *
Dcopy.dcopy(2*n,d,0,1,x,0,1);
knt.val = knt.val+1;
Dlaqtr.dlaqtr(false,false,n,t,0,ldt,b,0,w,scale,x,0,work,0,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
// *
// *                       ||(T+i*B)*(x1+i*x2) - scale*(d1+i*d2)|| /
// *                          max(ulp*(||T||+||B||)*(||x1||+||x2||),
// *                                  smlnum/ulp * (||T||+||B||), smlnum )
// *
// *
Dcopy.dcopy(2*n,d,0,1,y,0,1);
y[(1)- 1] = Ddot.ddot(n,b,0,1,x,(1+n)- 1,1)+scale.val*y[(1)- 1];
{
forloop50:
for (i = 2; i <= n; i++) {
y[(i)- 1] = w*x[(i+n)- 1]+scale.val*y[(i)- 1];
Dummy.label("Dget39",50);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",n,n,one,t,0,ldt,x,0,1,-one,y,0,1);
// *
y[(1+n)- 1] = Ddot.ddot(n,b,0,1,x,0,1)-scale.val*y[(1+n)- 1];
{
forloop60:
for (i = 2; i <= n; i++) {
y[(i+n)- 1] = w*x[(i)- 1]-scale.val*y[(i+n)- 1];
Dummy.label("Dget39",60);
}              //  Close for() loop. 
}
Dgemv.dgemv("No transpose",n,n,one,t,0,ldt,x,(1+n)- 1,1,one,y,(1+n)- 1,1);
// *
resid = Dasum.dasum(2*n,y,0,1);
domin = Math.max((smlnum.val) > ((smlnum.val/eps)*normtb) ? (smlnum.val) : ((smlnum.val/eps)*normtb), eps*(normtb*Dasum.dasum(2*n,x,0,1)));
resid = resid/domin;
if (resid > rmax.val)  {
    rmax.val = resid;
lmax.val = knt.val;
}              // Close if()
// *
Dcopy.dcopy(2*n,d,0,1,x,0,1);
knt.val = knt.val+1;
Dlaqtr.dlaqtr(true,false,n,t,0,ldt,b,0,w,scale,x,0,work,0,info);
if (info.val != 0)  
    ninfo.val = ninfo.val+1;
// *
// *                       ||(T+i*B)*(x1+i*x2) - scale*(d1+i*d2)|| /
// *                          max(ulp*(||T||+||B||)*(||x1||+||x2||),
// *                                  smlnum/ulp * (||T||+||B||), smlnum )
// *
Dcopy.dcopy(2*n,d,0,1,y,0,1);
y[(1)- 1] = b[(1)- 1]*x[(1+n)- 1]-scale.val*y[(1)- 1];
{
forloop70:
for (i = 2; i <= n; i++) {
y[(i)- 1] = b[(i)- 1]*x[(1+n)- 1]+w*x[(i+n)- 1]-scale.val*y[(i)- 1];
Dummy.label("Dget39",70);
}              //  Close for() loop. 
}
Dgemv.dgemv("Transpose",n,n,one,t,0,ldt,x,0,1,one,y,0,1);
// *
y[(1+n)- 1] = b[(1)- 1]*x[(1)- 1]+scale.val*y[(1+n)- 1];
{
forloop80:
for (i = 2; i <= n; i++) {
y[(i+n)- 1] = b[(i)- 1]*x[(1)- 1]+w*x[(i)- 1]+scale.val*y[(i+n)- 1];
Dummy.label("Dget39",80);
}              //  Close for() loop. 
}
Dgemv.dgemv("Transpose",n,n,one,t,0,ldt,x,(1+n)- 1,1,-one,y,(1+n)- 1,1);
// *
resid = Dasum.dasum(2*n,y,0,1);
domin = Math.max((smlnum.val) > ((smlnum.val/eps)*normtb) ? (smlnum.val) : ((smlnum.val/eps)*normtb), eps*(normtb*Dasum.dasum(2*n,x,0,1)));
resid = resid/domin;
if (resid > rmax.val)  {
    rmax.val = resid;
lmax.val = knt.val;
}              // Close if()
// *
Dummy.label("Dget39",90);
}              //  Close for() loop. 
}
Dummy.label("Dget39",100);
}              //  Close for() loop. 
}
Dummy.label("Dget39",110);
}              //  Close for() loop. 
}
Dummy.label("Dget39",120);
}              //  Close for() loop. 
}
Dummy.label("Dget39",130);
}              //  Close for() loop. 
}
Dummy.label("Dget39",140);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dget39",999999);
// *
// *     End of DGET39
// *
Dummy.label("Dget39",999999);
return;
   }
} // End class.
