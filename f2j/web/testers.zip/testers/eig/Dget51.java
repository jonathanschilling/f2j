/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget51 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *       DGET51  generally checks a decomposition of the form
// *
// *               A = U B V'
// *
// *       where ' means transpose and U and V are orthogonal.
// *
// *       Specifically, if ITYPE=1
// *
// *               RESULT = | A - U B V' | / ( |A| n ulp )
// *
// *       If ITYPE=2, then:
// *
// *               RESULT = | A - B | / ( |A| n ulp )
// *
// *       If ITYPE=3, then:
// *
// *               RESULT = | I - UU' | / ( n ulp )
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   (input) INTEGER
// *          Specifies the type of tests to be performed.
// *          =1: RESULT = | A - U B V' | / ( |A| n ulp )
// *          =2: RESULT = | A - B | / ( |A| n ulp )
// *          =3: RESULT = | I - UU' | / ( n ulp )
// *
// *  N       (input) INTEGER
// *          The size of the matrix.  If it is zero, DGET51 does nothing.
// *          It must be at least zero.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, N)
// *          The original (unfactored) matrix.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least 1
// *          and at least N.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB, N)
// *          The factored matrix.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  It must be at least 1
// *          and at least N.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU, N)
// *          The orthogonal matrix on the left-hand side in the
// *          decomposition.
// *          Not referenced if ITYPE=2
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U.  LDU must be at least N and
// *          at least 1.
// *
// *  V       (input) DOUBLE PRECISION array, dimension (LDV, N)
// *          The orthogonal matrix on the left-hand side in the
// *          decomposition.
// *          Not referenced if ITYPE=2
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of V.  LDV must be at least N and
// *          at least 1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N**2)
// *
// *  RESULT  (output) DOUBLE PRECISION
// *          The values computed by the test specified by ITYPE.  The
// *          value is currently limited to 1/ulp, to avoid overflow.
// *          Errors are flagged by RESULT=10/ulp.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double ten= 10.0e0;
// *     ..
// *     .. Local Scalars ..
static int jcol= 0;
static int jdiag= 0;
static int jrow= 0;
static double anorm= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dget51 (int itype,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
int ldv,
double [] work, int _work_offset,
doubleW result)  {

result.val = zero;
if (n <= 0)  
    Dummy.go_to("Dget51",999999);
// *
// *     Constants
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
// *
// *     Some Error Checks
// *
if (itype < 1 || itype > 3)  {
    result.val = ten/ulp;
Dummy.go_to("Dget51",999999);
}              // Close if()
// *
if (itype <= 2)  {
    // *
// *        Tests scaled by the norm(A)
// *
anorm = Math.max(Dlange.dlange("1",n,n,a,_a_offset,lda,work,_work_offset), unfl) ;
// *
if (itype == 1)  {
    // *
// *           ITYPE=1: Compute W = A - UBV'
// *
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,work,_work_offset,n);
Dgemm.dgemm("N","N",n,n,n,one,u,_u_offset,ldu,b,_b_offset,ldb,zero,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset),n);
// *
Dgemm.dgemm("N","C",n,n,n,-one,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset),n,v,_v_offset,ldv,one,work,_work_offset,n);
// *
}              // Close if()
else  {
  // *
// *           ITYPE=2: Compute W = A - B
// *
Dlacpy.dlacpy(" ",n,n,b,_b_offset,ldb,work,_work_offset,n);
// *
{
forloop20:
for (jcol = 1; jcol <= n; jcol++) {
{
forloop10:
for (jrow = 1; jrow <= n; jrow++) {
work[(jrow+n*(jcol-1))- 1+ _work_offset] = work[(jrow+n*(jcol-1))- 1+ _work_offset]-a[(jrow)- 1+(jcol- 1)*lda+ _a_offset];
Dummy.label("Dget51",10);
}              //  Close for() loop. 
}
Dummy.label("Dget51",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Compute norm(W)/ ( ulp*norm(A) )
// *
wnorm = Dlange.dlange("1",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset));
// *
if (anorm > wnorm)  {
    result.val = (wnorm/anorm)/(n*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result.val = (Math.min(wnorm, n*anorm) /anorm)/(n*ulp);
}              // Close if()
else  {
  result.val = Math.min(wnorm/anorm, (double)(n)) /(n*ulp);
}              //  Close else.
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *        Tests not scaled by norm(A)
// *
// *        ITYPE=3: Compute  UU' - I
// *
Dgemm.dgemm("N","C",n,n,n,one,u,_u_offset,ldu,u,_u_offset,ldu,zero,work,_work_offset,n);
// *
{
forloop30:
for (jdiag = 1; jdiag <= n; jdiag++) {
work[((n+1)*(jdiag-1)+1)- 1+ _work_offset] = work[((n+1)*(jdiag-1)+1)- 1+ _work_offset]-one;
Dummy.label("Dget51",30);
}              //  Close for() loop. 
}
// *
result.val = Math.min(Dlange.dlange("1",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset)), (double)(n)) /(n*ulp);
}              //  Close else.
// *
Dummy.go_to("Dget51",999999);
// *
// *     End of DGET51
// *
Dummy.label("Dget51",999999);
return;
   }
} // End class.
