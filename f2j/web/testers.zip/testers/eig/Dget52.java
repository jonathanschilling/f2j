/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget52 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET52  does an eigenvector check for the generalized eigenvalue
// *  problem.
// *
// *  The basic test for right eigenvectors is:
// *
// *                            | b(j) A E(j) -  a(j) B E(j) |
// *          RESULT(1) = max   -------------------------------
// *                       j    n ulp max( |b(j) A|, |a(j) B| )
// *
// *  using the 1-norm.  Here, a(j)/b(j) = w is the j-th generalized
// *  eigenvalue of A - w B, or, equivalently, b(j)/a(j) = m is the j-th
// *  generalized eigenvalue of m A - B.
// *
// *  For real eigenvalues, the test is straightforward.  For complex
// *  eigenvalues, E(j) and a(j) are complex, represented by
// *  Er(j) + i*Ei(j) and ar(j) + i*ai(j), resp., so the test for that
// *  eigenvector becomes
// *
// *                  max( |Wr|, |Wi| )
// *      --------------------------------------------
// *      n ulp max( |b(j) A|, (|ar(j)|+|ai(j)|) |B| )
// *
// *  where
// *
// *      Wr = b(j) A Er(j) - ar(j) B Er(j) + ai(j) B Ei(j)
// *
// *      Wi = b(j) A Ei(j) - ai(j) B Er(j) - ar(j) B Ei(j)
// *
// *                          T   T  _
// *  For left eigenvectors, A , B , a, and b  are used.
// *
// *  DGET52 also tests the normalization of E.  Each eigenvector is
// *  supposed to be normalized so that the maximum "absolute value"
// *  of its elements is 1, where in this case, "absolute value"
// *  of a complex value x is  |Re(x)| + |Im(x)| ; let us call this
// *  maximum "absolute value" norm of a vector v  M(v).  
// *  If a(j)=b(j)=0, then the eigenvector is set to be jth coordinate
// *  vector. The normalization test is:
// *
// *          RESULT(2) =      max       | M(v(j)) - 1 | / ( n ulp )
// *                     eigenvectors v(j)
// *
// *
// *  Arguments
// *  =========
// *
// *  LEFT    (input) LOGICAL
// *          =.TRUE.:  The eigenvectors in the columns of E are assumed
// *                    to be *left* eigenvectors.
// *          =.FALSE.: The eigenvectors in the columns of E are assumed
// *                    to be *right* eigenvectors.
// *
// *  N       (input) INTEGER
// *          The size of the matrices.  If it is zero, DGET52 does
// *          nothing.  It must be at least zero.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, N)
// *          The matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least 1
// *          and at least N.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB, N)
// *          The matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  It must be at least 1
// *          and at least N.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (LDE, N)
// *          The matrix of eigenvectors.  It must be O( 1 ).  Complex
// *          eigenvalues and eigenvectors always come in pairs, the
// *          eigenvalue and its conjugate being stored in adjacent
// *          elements of ALPHAR, ALPHAI, and BETA.  Thus, if a(j)/b(j)
// *          and a(j+1)/b(j+1) are a complex conjugate pair of
// *          generalized eigenvalues, then E(,j) contains the real part
// *          of the eigenvector and E(,j+1) contains the imaginary part.
// *          Note that whether E(,j) is a real eigenvector or part of a
// *          complex one is specified by whether ALPHAI(j) is zero or not.
// *
// *  LDE     (input) INTEGER
// *          The leading dimension of E.  It must be at least 1 and at
// *          least N.
// *
// *  ALPHAR  (input) DOUBLE PRECISION array, dimension (N)
// *          The real parts of the values a(j) as described above, which,
// *          along with b(j), define the generalized eigenvalues.
// *          Complex eigenvalues always come in complex conjugate pairs
// *          a(j)/b(j) and a(j+1)/b(j+1), which are stored in adjacent
// *          elements in ALPHAR, ALPHAI, and BETA.  Thus, if the j-th
// *          and (j+1)-st eigenvalues form a pair, ALPHAR(j+1)/BETA(j+1)
// *          is assumed to be equal to ALPHAR(j)/BETA(j).
// *
// *  ALPHAI  (input) DOUBLE PRECISION array, dimension (N)
// *          The imaginary parts of the values a(j) as described above,
// *          which, along with b(j), define the generalized eigenvalues.
// *          If ALPHAI(j)=0, then the eigenvalue is real, otherwise it
// *          is part of a complex conjugate pair.  Complex eigenvalues
// *          always come in complex conjugate pairs a(j)/b(j) and
// *          a(j+1)/b(j+1), which are stored in adjacent elements in
// *          ALPHAR, ALPHAI, and BETA.  Thus, if the j-th and (j+1)-st
// *          eigenvalues form a pair, ALPHAI(j+1)/BETA(j+1) is assumed to
// *          be equal to  -ALPHAI(j)/BETA(j).  Also, nonzero values in
// *          ALPHAI are assumed to always come in adjacent pairs.
// *
// *  BETA    (input) DOUBLE PRECISION array, dimension (N)
// *          The values b(j) as described above, which, along with a(j),
// *          define the generalized eigenvalues.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N**2+N)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The values computed by the test described above.  If A E or
// *          B E is likely to overflow, then RESULT(1:2) is set to
// *          10 / ulp.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double ten= 10.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean ilcplx= false;
static String normab= new String(" ");
static String trans= new String(" ");
static int j= 0;
static int jvec= 0;
static double abmax= 0.0;
static double acoef= 0.0;
static double alfmax= 0.0;
static double anorm= 0.0;
static double bcoefi= 0.0;
static double bcoefr= 0.0;
static double betmax= 0.0;
static double bnorm= 0.0;
static double enorm= 0.0;
static double enrmer= 0.0;
static double errnrm= 0.0;
static double safmax= 0.0;
static double safmin= 0.0;
static double salfi= 0.0;
static double salfr= 0.0;
static double sbeta= 0.0;
static double scale= 0.0;
static double temp1= 0.0;
static double ulp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dget52 (boolean left,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] e, int _e_offset,
int lde,
double [] alphar, int _alphar_offset,
double [] alphai, int _alphai_offset,
double [] beta, int _beta_offset,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
if (n <= 0)  
    Dummy.go_to("Dget52",999999);
// *
safmin = Dlamch.dlamch("Safe minimum");
safmax = one/safmin;
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
// *
if (left)  {
    trans = "T";
normab = "I";
}              // Close if()
else  {
  trans = "N";
normab = "O";
}              //  Close else.
// *
// *     Norm of A, B, and E:
// *
anorm = Math.max(Dlange.dlange(normab,n,n,a,_a_offset,lda,work,_work_offset), safmin) ;
bnorm = Math.max(Dlange.dlange(normab,n,n,b,_b_offset,ldb,work,_work_offset), safmin) ;
enorm = Math.max(Dlange.dlange("O",n,n,e,_e_offset,lde,work,_work_offset), ulp) ;
alfmax = safmax/Math.max(one, bnorm) ;
betmax = safmax/Math.max(one, anorm) ;
// *
// *     Compute error matrix.
// *     Column i = ( b(i) A - a(i) B ) E(i) / max( |a(i) B| |b(i) A| )
// *
ilcplx = false;
{
forloop10:
for (jvec = 1; jvec <= n; jvec++) {
if (ilcplx)  {
    // *
// *           2nd Eigenvalue/-vector of pair -- do nothing
// *
ilcplx = false;
}              // Close if()
else  {
  salfr = alphar[(jvec)- 1+ _alphar_offset];
salfi = alphai[(jvec)- 1+ _alphai_offset];
sbeta = beta[(jvec)- 1+ _beta_offset];
if (salfi == zero)  {
    // *
// *              Real eigenvalue and -vector
// *
abmax = Math.max(Math.abs(salfr), Math.abs(sbeta)) ;
if (Math.abs(salfr) > alfmax || Math.abs(sbeta) > betmax || abmax < one)  {
    scale = one/Math.max(abmax, safmin) ;
salfr = scale*salfr;
sbeta = scale*sbeta;
}              // Close if()
scale = one/Math.max((Math.abs(salfr)*bnorm) > (Math.abs(sbeta)*anorm) ? (Math.abs(salfr)*bnorm) : (Math.abs(sbeta)*anorm), safmin);
acoef = scale*sbeta;
bcoefr = scale*salfr;
Dgemv.dgemv(trans,n,n,acoef,a,_a_offset,lda,e,(1)- 1+(jvec- 1)*lde+ _e_offset,1,zero,work,(n*(jvec-1)+1)- 1+ _work_offset,1);
Dgemv.dgemv(trans,n,n,-bcoefr,b,_b_offset,lda,e,(1)- 1+(jvec- 1)*lde+ _e_offset,1,one,work,(n*(jvec-1)+1)- 1+ _work_offset,1);
}              // Close if()
else  {
  // *
// *              Complex conjugate pair
// *
ilcplx = true;
if (jvec == n)  {
    result[(1)- 1+ _result_offset] = ten/ulp;
Dummy.go_to("Dget52",999999);
}              // Close if()
abmax = Math.max(Math.abs(salfr)+Math.abs(salfi), Math.abs(sbeta)) ;
if (Math.abs(salfr)+Math.abs(salfi) > alfmax || Math.abs(sbeta) > betmax || abmax < one)  {
    scale = one/Math.max(abmax, safmin) ;
salfr = scale*salfr;
salfi = scale*salfi;
sbeta = scale*sbeta;
}              // Close if()
scale = one/Math.max(((Math.abs(salfr)+Math.abs(salfi))*bnorm) > (Math.abs(sbeta)*anorm) ? ((Math.abs(salfr)+Math.abs(salfi))*bnorm) : (Math.abs(sbeta)*anorm), safmin);
acoef = scale*sbeta;
bcoefr = scale*salfr;
bcoefi = scale*salfi;
if (left)  {
    bcoefi = -bcoefi;
}              // Close if()
// *
Dgemv.dgemv(trans,n,n,acoef,a,_a_offset,lda,e,(1)- 1+(jvec- 1)*lde+ _e_offset,1,zero,work,(n*(jvec-1)+1)- 1+ _work_offset,1);
Dgemv.dgemv(trans,n,n,-bcoefr,b,_b_offset,lda,e,(1)- 1+(jvec- 1)*lde+ _e_offset,1,one,work,(n*(jvec-1)+1)- 1+ _work_offset,1);
Dgemv.dgemv(trans,n,n,bcoefi,b,_b_offset,lda,e,(1)- 1+(jvec+1- 1)*lde+ _e_offset,1,one,work,(n*(jvec-1)+1)- 1+ _work_offset,1);
// *
Dgemv.dgemv(trans,n,n,acoef,a,_a_offset,lda,e,(1)- 1+(jvec+1- 1)*lde+ _e_offset,1,zero,work,(n*jvec+1)- 1+ _work_offset,1);
Dgemv.dgemv(trans,n,n,-bcoefi,b,_b_offset,lda,e,(1)- 1+(jvec- 1)*lde+ _e_offset,1,one,work,(n*jvec+1)- 1+ _work_offset,1);
Dgemv.dgemv(trans,n,n,-bcoefr,b,_b_offset,lda,e,(1)- 1+(jvec+1- 1)*lde+ _e_offset,1,one,work,(n*jvec+1)- 1+ _work_offset,1);
}              //  Close else.
}              //  Close else.
Dummy.label("Dget52",10);
}              //  Close for() loop. 
}
// *
errnrm = Dlange.dlange("One",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset))/enorm;
// *
// *     Compute RESULT(1)
// *
result[(1)- 1+ _result_offset] = errnrm/ulp;
// *
// *     Normalization of E:
// *
enrmer = zero;
ilcplx = false;
{
forloop40:
for (jvec = 1; jvec <= n; jvec++) {
if (ilcplx)  {
    ilcplx = false;
}              // Close if()
else  {
  temp1 = zero;
if (alphai[(jvec)- 1+ _alphai_offset] == zero)  {
    {
forloop20:
for (j = 1; j <= n; j++) {
temp1 = Math.max(temp1, Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])) ;
Dummy.label("Dget52",20);
}              //  Close for() loop. 
}
enrmer = Math.max(enrmer, temp1-one) ;
}              // Close if()
else  {
  ilcplx = true;
{
forloop30:
for (j = 1; j <= n; j++) {
temp1 = Math.max(temp1, Math.abs(e[(j)- 1+(jvec- 1)*lde+ _e_offset])+Math.abs(e[(j)- 1+(jvec+1- 1)*lde+ _e_offset])) ;
Dummy.label("Dget52",30);
}              //  Close for() loop. 
}
enrmer = Math.max(enrmer, temp1-one) ;
}              //  Close else.
}              //  Close else.
Dummy.label("Dget52",40);
}              //  Close for() loop. 
}
// *
// *     Compute RESULT(2) : the normalization error in E.
// *
result[(2)- 1+ _result_offset] = enrmer/((double)(n)*ulp);
// *
Dummy.go_to("Dget52",999999);
// *
// *     End of DGET52
// *
Dummy.label("Dget52",999999);
return;
   }
} // End class.
