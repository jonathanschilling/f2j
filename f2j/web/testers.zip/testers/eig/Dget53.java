/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget53 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET53  checks the generalized eigenvalues computed by DLAG2.
// *
// *  The basic test for an eigenvalue is:
// *
// *                               | det( s A - w B ) |
// *      RESULT =  ---------------------------------------------------
// *                ulp max( s norm(A), |w| norm(B) )*norm( s A - w B )
// *
// *  Two "safety checks" are performed:
// *
// *  (1)  ulp*max( s*norm(A), |w|*norm(B) )  must be at least
// *       safe_minimum.  This insures that the test performed is
// *       not essentially  det(0*A + 0*B)=0.
// *
// *  (2)  s*norm(A) + |w|*norm(B) must be less than 1/safe_minimum.
// *       This insures that  s*A - w*B  will not overflow.
// *
// *  If these tests are not passed, then  s  and  w  are scaled and
// *  tested anyway, if this is possible.
// *
// *  Arguments
// *  =========
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, 2)
// *          The 2x2 matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least 2.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB, N)
// *          The 2x2 upper-triangular matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of B.  It must be at least 2.
// *
// *  SCALE   (input) DOUBLE PRECISION
// *          The "scale factor" s in the formula  s A - w B .  It is
// *          assumed to be non-negative.
// *
// *  WR      (input) DOUBLE PRECISION
// *          The real part of the eigenvalue  w  in the formula
// *          s A - w B .
// *
// *  WI      (input) DOUBLE PRECISION
// *          The imaginary part of the eigenvalue  w  in the formula
// *          s A - w B .
// *
// *  RESULT  (output) DOUBLE PRECISION
// *          If INFO is 2 or less, the value computed by the test
// *             described above.
// *          If INFO=3, this will just be 1/ulp.
// *
// *  INFO    (output) INTEGER
// *          =0:  The input data pass the "safety checks".
// *          =1:  s*norm(A) + |w|*norm(B) > 1/safe_minimum.
// *          =2:  ulp*max( s*norm(A), |w|*norm(B) ) < safe_minimum
// *          =3:  same as INFO=2, but  s  and  w  could not be scaled so
// *               as to compute the test.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static double absw= 0.0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double ci11= 0.0;
static double ci12= 0.0;
static double ci22= 0.0;
static double cnorm= 0.0;
static double cr11= 0.0;
static double cr12= 0.0;
static double cr21= 0.0;
static double cr22= 0.0;
static double cscale= 0.0;
static double deti= 0.0;
static double detr= 0.0;
static double s1= 0.0;
static double safmin= 0.0;
static double scales= 0.0;
static double sigmin= 0.0;
static double temp= 0.0;
static double ulp= 0.0;
static double wis= 0.0;
static double wrs= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize
// *

public static void dget53 (double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double scale,
double wr,
double wi,
doubleW result,
intW info)  {

info.val = 0;
result.val = zero;
scales = scale;
wrs = wr;
wis = wi;
// *
// *     Machine constants and norms
// *
safmin = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
absw = Math.abs(wrs)+Math.abs(wis);
anorm = Math.max((Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(1- 1)*lda+ _a_offset])) > (Math.abs(a[(1)- 1+(2- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(2- 1)*lda+ _a_offset])) ? (Math.abs(a[(1)- 1+(1- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(1- 1)*lda+ _a_offset])) : (Math.abs(a[(1)- 1+(2- 1)*lda+ _a_offset])+Math.abs(a[(2)- 1+(2- 1)*lda+ _a_offset])), safmin);
bnorm = Math.max((Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset])) > (Math.abs(b[(1)- 1+(2- 1)*ldb+ _b_offset])+Math.abs(b[(2)- 1+(2- 1)*ldb+ _b_offset])) ? (Math.abs(b[(1)- 1+(1- 1)*ldb+ _b_offset])) : (Math.abs(b[(1)- 1+(2- 1)*ldb+ _b_offset])+Math.abs(b[(2)- 1+(2- 1)*ldb+ _b_offset])), safmin);
// *
// *     Check for possible overflow.
// *
temp = (safmin*bnorm)*absw+(safmin*anorm)*scales;
if (temp >= one)  {
    // *
// *        Scale down to avoid overflow
// *
info.val = 1;
temp = one/temp;
scales = scales*temp;
wrs = wrs*temp;
wis = wis*temp;
absw = Math.abs(wrs)+Math.abs(wis);
}              // Close if()
s1 = Math.max(ulp*Math.max(scales*anorm, absw*bnorm) , safmin*Math.max(scales, absw) ) ;
// *
// *     Check for W and SCALE essentially zero.
// *
if (s1 < safmin)  {
    info.val = 2;
if (scales < safmin && absw < safmin)  {
    info.val = 3;
result.val = one/ulp;
Dummy.go_to("Dget53",999999);
}              // Close if()
// *
// *        Scale up to avoid underflow
// *
temp = one/Math.max(scales*anorm+absw*bnorm, safmin) ;
scales = scales*temp;
wrs = wrs*temp;
wis = wis*temp;
absw = Math.abs(wrs)+Math.abs(wis);
s1 = Math.max(ulp*Math.max(scales*anorm, absw*bnorm) , safmin*Math.max(scales, absw) ) ;
if (s1 < safmin)  {
    info.val = 3;
result.val = one/ulp;
Dummy.go_to("Dget53",999999);
}              // Close if()
}              // Close if()
// *
// *     Compute C = s A - w B
// *
cr11 = scales*a[(1)- 1+(1- 1)*lda+ _a_offset]-wrs*b[(1)- 1+(1- 1)*ldb+ _b_offset];
ci11 = -wis*b[(1)- 1+(1- 1)*ldb+ _b_offset];
cr21 = scales*a[(2)- 1+(1- 1)*lda+ _a_offset];
cr12 = scales*a[(1)- 1+(2- 1)*lda+ _a_offset]-wrs*b[(1)- 1+(2- 1)*ldb+ _b_offset];
ci12 = -wis*b[(1)- 1+(2- 1)*ldb+ _b_offset];
cr22 = scales*a[(2)- 1+(2- 1)*lda+ _a_offset]-wrs*b[(2)- 1+(2- 1)*ldb+ _b_offset];
ci22 = -wis*b[(2)- 1+(2- 1)*ldb+ _b_offset];
// *
// *     Compute the smallest singular value of s A - w B:
// *
// *                 |det( s A - w B )|
// *     sigma_min = ------------------
// *                 norm( s A - w B )
// *
cnorm = Math.max((Math.abs(cr11)+Math.abs(ci11)+Math.abs(cr21)) > (Math.abs(cr12)+Math.abs(ci12)+Math.abs(cr22)+Math.abs(ci22)) ? (Math.abs(cr11)+Math.abs(ci11)+Math.abs(cr21)) : (Math.abs(cr12)+Math.abs(ci12)+Math.abs(cr22)+Math.abs(ci22)), safmin);
cscale = one/Math.sqrt(cnorm);
detr = (cscale*cr11)*(cscale*cr22)-(cscale*ci11)*(cscale*ci22)-(cscale*cr12)*(cscale*cr21);
deti = (cscale*cr11)*(cscale*ci22)+(cscale*ci11)*(cscale*cr22)-(cscale*ci12)*(cscale*cr21);
sigmin = Math.abs(detr)+Math.abs(deti);
result.val = sigmin/s1;
Dummy.go_to("Dget53",999999);
// *
// *     End of DGET53
// *
Dummy.label("Dget53",999999);
return;
   }
} // End class.
