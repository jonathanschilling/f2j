/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dglmts {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *
// *  Purpose
// *  =======
// *
// *  DGLMTS tests DGGGLM - a subroutine for solving the generalized
// *  linear model problem.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices A and B.  N >= 0.
// *
// *  M       (input) INTEGER
// *          The number of columns of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of columns of the matrix B.  P >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,M)
// *          The N-by-M matrix A.
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (LDA,M)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF. LDA >= max(M,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,P)
// *          The N-by-P matrix A.
// *
// *  BF      (workspace) DOUBLE PRECISION array, dimension (LDB,P)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arrays B, BF. LDB >= max(P,N).
// *
// *  D       (input) DOUBLE PRECISION array, dimension( N )
// *          On input, the left hand side of the GLM.
// *
// *  DF      (workspace) DOUBLE PRECISION array, dimension( N )
// *
// *  X       (output) DOUBLE PRECISION array, dimension( M )
// *          solution vector X in the GLM problem.
// *
// *  U       (output) DOUBLE PRECISION array, dimension( P )
// *          solution vector U in the GLM problem.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT   (output) DOUBLE PRECISION
// *          The test ratio:
// *                           norm( d - A*x - B*u )
// *            RESULT = -----------------------------------------
// *                     (norm(A)+norm(B))*(norm(x)+norm(u))*EPS
// *
// *  ====================================================================
// *
// *     ..
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double bnorm= 0.0;
static double dnorm= 0.0;
static double eps= 0.0;
static double unfl= 0.0;
static double xnorm= 0.0;
static double ynorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dglmts (int n,
int m,
int p,
double [] a, int _a_offset,
double [] af, int _af_offset,
int lda,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
int ldb,
double [] d, int _d_offset,
double [] df, int _df_offset,
double [] x, int _x_offset,
double [] u, int _u_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
doubleW result)  {

eps = Dlamch.dlamch("Epsilon");
unfl = Dlamch.dlamch("Safe minimum");
anorm = Math.max(Dlange.dlange("1",n,m,a,_a_offset,lda,rwork,_rwork_offset), unfl) ;
bnorm = Math.max(Dlange.dlange("1",n,p,b,_b_offset,ldb,rwork,_rwork_offset), unfl) ;
// *
// *     Copy the matrices A and B to the arrays AF and BF,
// *     and the vector D the array DF.
// *
Dlacpy.dlacpy("Full",n,m,a,_a_offset,lda,af,_af_offset,lda);
Dlacpy.dlacpy("Full",n,p,b,_b_offset,ldb,bf,_bf_offset,ldb);
Dcopy.dcopy(n,d,_d_offset,1,df,_df_offset,1);
// *
// *     Solve GLM problem
// *
Dggglm.dggglm(n,m,p,af,_af_offset,lda,bf,_bf_offset,ldb,df,_df_offset,x,_x_offset,u,_u_offset,work,_work_offset,lwork,info);
// *
// *     Test the residual for the solution of LSE
// *
// *                       norm( d - A*x - B*u )
// *       RESULT = -----------------------------------------
// *                (norm(A)+norm(B))*(norm(x)+norm(u))*EPS
// *
Dcopy.dcopy(n,d,_d_offset,1,df,_df_offset,1);
Dgemv.dgemv("No transpose",n,m,-one,a,_a_offset,lda,x,_x_offset,1,one,df,_df_offset,1);
// *
Dgemv.dgemv("No transpose",n,p,-one,b,_b_offset,ldb,u,_u_offset,1,one,df,_df_offset,1);
// *
dnorm = Dasum.dasum(n,df,_df_offset,1);
xnorm = Dasum.dasum(m,x,_x_offset,1)+Dasum.dasum(p,u,_u_offset,1);
ynorm = anorm+bnorm;
// *
if (xnorm <= zero)  {
    result.val = zero;
}              // Close if()
else  {
  result.val = ((dnorm/ynorm)/xnorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dglmts",999999);
// *
// *     End of DGLMTS
// *
Dummy.label("Dglmts",999999);
return;
   }
} // End class.
