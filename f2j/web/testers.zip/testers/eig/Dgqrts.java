/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgqrts {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGQRTS tests DGGQRF, which computes the GQR factorization of an
// *  N-by-M matrix A and a N-by-P matrix B: A = Q*R and B = Q*T*Z.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices A and B.  N >= 0.
// *
// *  M       (input) INTEGER
// *          The number of columns of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of columns of the matrix B.  P >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,M)
// *          The N-by-M matrix A.
// *
// *  AF      (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the GQR factorization of A and B, as returned
// *          by DGGQRF, see SGGQRF for further details.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-M orthogonal matrix Q.
// *
// *  R       (workspace) DOUBLE PRECISION array, dimension (LDA,MAX(M,N))
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, R and Q.
// *          LDA >= max(M,N).
// *
// *  TAUA    (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGGQRF.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,P)
// *          On entry, the N-by-P matrix A.
// *
// *  BF      (output) DOUBLE PRECISION array, dimension (LDB,N)
// *          Details of the GQR factorization of A and B, as returned
// *          by DGGQRF, see SGGQRF for further details.
// *
// *  Z       (output) DOUBLE PRECISION array, dimension (LDB,P)
// *          The P-by-P orthogonal matrix Z.
// *
// *  T       (workspace) DOUBLE PRECISION array, dimension (LDB,max(P,N))
// *
// *  BWK     (workspace) DOUBLE PRECISION array, dimension (LDB,N)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arrays B, BF, Z and T.
// *          LDB >= max(P,N).
// *
// *  TAUB    (output) DOUBLE PRECISION array, dimension (min(P,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGGRQF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK, LWORK >= max(N,M,P)**2.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (max(N,M,P))
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (4)
// *          The test ratios:
// *            RESULT(1) = norm( R - Q'*A ) / ( MAX(M,N)*norm(A)*ULP)
// *            RESULT(2) = norm( T*Z - Q'*B ) / (MAX(P,N)*norm(B)*ULP)
// *            RESULT(3) = norm( I - Q'*Q ) / ( M*ULP )
// *            RESULT(4) = norm( I - Z'*Z ) / ( P*ULP )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double bnorm= 0.0;
static double resid= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgqrts (int n,
int m,
int p,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] r, int _r_offset,
int lda,
double [] taua, int _taua_offset,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
double [] z, int _z_offset,
double [] t, int _t_offset,
double [] bwk, int _bwk_offset,
int ldb,
double [] taub, int _taub_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

ulp = Dlamch.dlamch("Precision");
unfl = Dlamch.dlamch("Safe minimum");
// *
// *     Copy the matrix A to the array AF.
// *
Dlacpy.dlacpy("Full",n,m,a,_a_offset,lda,af,_af_offset,lda);
Dlacpy.dlacpy("Full",n,p,b,_b_offset,ldb,bf,_bf_offset,ldb);
// *
anorm = Math.max(Dlange.dlange("1",n,m,a,_a_offset,lda,rwork,_rwork_offset), unfl) ;
bnorm = Math.max(Dlange.dlange("1",n,p,b,_b_offset,ldb,rwork,_rwork_offset), unfl) ;
// *
// *     Factorize the matrices A and B in the arrays AF and BF.
// *
Dggqrf.dggqrf(n,m,p,af,_af_offset,lda,taua,_taua_offset,bf,_bf_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,info);
// *
// *     Generate the N-by-N matrix Q
// *
Dlaset.dlaset("Full",n,n,rogue,rogue,q,_q_offset,lda);
Dlacpy.dlacpy("Lower",n-1,m,af,(2)- 1+(1- 1)*lda+ _af_offset,lda,q,(2)- 1+(1- 1)*lda+ _q_offset,lda);
Dorgqr.dorgqr(n,n,(int) ( Math.min(n, m) ),q,_q_offset,lda,taua,_taua_offset,work,_work_offset,lwork,info);
// *
// *     Generate the P-by-P matrix Z
// *
Dlaset.dlaset("Full",p,p,rogue,rogue,z,_z_offset,ldb);
if (n <= p)  {
    if (n > 0 && n < p)  
    Dlacpy.dlacpy("Full",n,p-n,bf,_bf_offset,ldb,z,(p-n+1)- 1+(1- 1)*ldb+ _z_offset,ldb);
if (n > 1)  
    Dlacpy.dlacpy("Lower",n-1,n-1,bf,(2)- 1+(p-n+1- 1)*ldb+ _bf_offset,ldb,z,(p-n+2)- 1+(p-n+1- 1)*ldb+ _z_offset,ldb);
}              // Close if()
else  {
  if (p > 1)  
    Dlacpy.dlacpy("Lower",p-1,p-1,bf,(n-p+2)- 1+(1- 1)*ldb+ _bf_offset,ldb,z,(2)- 1+(1- 1)*ldb+ _z_offset,ldb);
}              //  Close else.
Dorgrq.dorgrq(p,p,(int) ( Math.min(n, p) ),z,_z_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,info);
// *
// *     Copy R
// *
Dlaset.dlaset("Full",n,m,zero,zero,r,_r_offset,lda);
Dlacpy.dlacpy("Upper",n,m,af,_af_offset,lda,r,_r_offset,lda);
// *
// *     Copy T
// *
Dlaset.dlaset("Full",n,p,zero,zero,t,_t_offset,ldb);
if (n <= p)  {
    Dlacpy.dlacpy("Upper",n,n,bf,(1)- 1+(p-n+1- 1)*ldb+ _bf_offset,ldb,t,(1)- 1+(p-n+1- 1)*ldb+ _t_offset,ldb);
}              // Close if()
else  {
  Dlacpy.dlacpy("Full",n-p,p,bf,_bf_offset,ldb,t,_t_offset,ldb);
Dlacpy.dlacpy("Upper",p,p,bf,(n-p+1)- 1+(1- 1)*ldb+ _bf_offset,ldb,t,(n-p+1)- 1+(1- 1)*ldb+ _t_offset,ldb);
}              //  Close else.
// *
// *     Compute R - Q'*A
// *
Dgemm.dgemm("Transpose","No transpose",n,m,n,-one,q,_q_offset,lda,a,_a_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( R - Q'*A ) / ( MAX(M,N)*norm(A)*ULP ) .
// *
resid = Dlange.dlange("1",n,m,r,_r_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (m) ? (1) : (m), n)))/anorm)/ulp;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute T*Z - Q'*B
// *
Dgemm.dgemm("No Transpose","No transpose",n,p,p,one,t,_t_offset,ldb,z,_z_offset,ldb,zero,bwk,_bwk_offset,ldb);
Dgemm.dgemm("Transpose","No transpose",n,p,n,-one,q,_q_offset,lda,b,_b_offset,ldb,one,bwk,_bwk_offset,ldb);
// *
// *     Compute norm( T*Z - Q'*B ) / ( MAX(P,N)*norm(A)*ULP ) .
// *
resid = Dlange.dlange("1",n,p,bwk,_bwk_offset,ldb,rwork,_rwork_offset);
if (bnorm > zero)  {
    result[(2)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (p) ? (1) : (p), n)))/bnorm)/ulp;
}              // Close if()
else  {
  result[(2)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q'*Q
// *
Dlaset.dlaset("Full",n,n,zero,one,r,_r_offset,lda);
Dsyrk.dsyrk("Upper","Transpose",n,n,-one,q,_q_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( I - Q'*Q ) / ( N * ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",n,r,_r_offset,lda,rwork,_rwork_offset);
result[(3)- 1+ _result_offset] = (resid/(double)(Math.max(1, n) ))/ulp;
// *
// *     Compute I - Z'*Z
// *
Dlaset.dlaset("Full",p,p,zero,one,t,_t_offset,ldb);
Dsyrk.dsyrk("Upper","Transpose",p,p,-one,z,_z_offset,ldb,one,t,_t_offset,ldb);
// *
// *     Compute norm( I - Z'*Z ) / ( P*ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",p,t,_t_offset,ldb,rwork,_rwork_offset);
result[(4)- 1+ _result_offset] = (resid/(double)(Math.max(1, p) ))/ulp;
// *
Dummy.go_to("Dgqrts",999999);
// *
// *     End of DGQRTS
// *
Dummy.label("Dgqrts",999999);
return;
   }
} // End class.
