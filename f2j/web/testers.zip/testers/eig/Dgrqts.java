/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgrqts {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGRQTS tests DGGRQF, which computes the GRQ factorization of an
// *  M-by-N matrix A and a P-by-N matrix B: A = R*Q and B = Z*T*Q.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B.  P >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A.
// *
// *  AF      (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the GRQ factorization of A and B, as returned
// *          by DGGRQF, see SGGRQF for further details.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The N-by-N orthogonal matrix Q.
// *
// *  R       (workspace) DOUBLE PRECISION array, dimension (LDA,MAX(M,N))
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, R and Q.
// *          LDA >= max(M,N).
// *
// *  TAUA    (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGGQRC.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,N)
// *          On entry, the P-by-N matrix A.
// *
// *  BF      (output) DOUBLE PRECISION array, dimension (LDB,N)
// *          Details of the GQR factorization of A and B, as returned
// *          by DGGRQF, see SGGRQF for further details.
// *
// *  Z       (output) DOUBLE PRECISION array, dimension (LDB,P)
// *          The P-by-P orthogonal matrix Z.
// *
// *  T       (workspace) DOUBLE PRECISION array, dimension (LDB,max(P,N))
// *
// *  BWK     (workspace) DOUBLE PRECISION array, dimension (LDB,N)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arrays B, BF, Z and T.
// *          LDB >= max(P,N).
// *
// *  TAUB    (output) DOUBLE PRECISION array, dimension (min(P,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGGRQF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK, LWORK >= max(M,P,N)**2.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (4)
// *          The test ratios:
// *            RESULT(1) = norm( R - A*Q' ) / ( MAX(M,N)*norm(A)*ULP)
// *            RESULT(2) = norm( T*Q - Z'*B ) / (MAX(P,N)*norm(B)*ULP)
// *            RESULT(3) = norm( I - Q'*Q ) / ( N*ULP )
// *            RESULT(4) = norm( I - Z'*Z ) / ( P*ULP )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double bnorm= 0.0;
static double resid= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgrqts (int m,
int p,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] r, int _r_offset,
int lda,
double [] taua, int _taua_offset,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
double [] z, int _z_offset,
double [] t, int _t_offset,
double [] bwk, int _bwk_offset,
int ldb,
double [] taub, int _taub_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

ulp = Dlamch.dlamch("Precision");
unfl = Dlamch.dlamch("Safe minimum");
// *
// *     Copy the matrix A to the array AF.
// *
Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,af,_af_offset,lda);
Dlacpy.dlacpy("Full",p,n,b,_b_offset,ldb,bf,_bf_offset,ldb);
// *
anorm = Math.max(Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset), unfl) ;
bnorm = Math.max(Dlange.dlange("1",p,n,b,_b_offset,ldb,rwork,_rwork_offset), unfl) ;
// *
// *     Factorize the matrices A and B in the arrays AF and BF.
// *
Dggrqf.dggrqf(m,p,n,af,_af_offset,lda,taua,_taua_offset,bf,_bf_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,info);
// *
// *     Generate the N-by-N matrix Q
// *
Dlaset.dlaset("Full",n,n,rogue,rogue,q,_q_offset,lda);
if (m <= n)  {
    if (m > 0 && m < n)  
    Dlacpy.dlacpy("Full",m,n-m,af,_af_offset,lda,q,(n-m+1)- 1+(1- 1)*lda+ _q_offset,lda);
if (m > 1)  
    Dlacpy.dlacpy("Lower",m-1,m-1,af,(2)- 1+(n-m+1- 1)*lda+ _af_offset,lda,q,(n-m+2)- 1+(n-m+1- 1)*lda+ _q_offset,lda);
}              // Close if()
else  {
  if (n > 1)  
    Dlacpy.dlacpy("Lower",n-1,n-1,af,(m-n+2)- 1+(1- 1)*lda+ _af_offset,lda,q,(2)- 1+(1- 1)*lda+ _q_offset,lda);
}              //  Close else.
Dorgrq.dorgrq(n,n,(int) ( Math.min(m, n) ),q,_q_offset,lda,taua,_taua_offset,work,_work_offset,lwork,info);
// *
// *     Generate the P-by-P matrix Z
// *
Dlaset.dlaset("Full",p,p,rogue,rogue,z,_z_offset,ldb);
if (p > 1)  
    Dlacpy.dlacpy("Lower",p-1,n,bf,(2)- 1+(1- 1)*ldb+ _bf_offset,ldb,z,(2)- 1+(1- 1)*ldb+ _z_offset,ldb);
Dorgqr.dorgqr(p,p,(int) ( Math.min(p, n) ),z,_z_offset,ldb,taub,_taub_offset,work,_work_offset,lwork,info);
// *
// *     Copy R
// *
Dlaset.dlaset("Full",m,n,zero,zero,r,_r_offset,lda);
if (m <= n)  {
    Dlacpy.dlacpy("Upper",m,m,af,(1)- 1+(n-m+1- 1)*lda+ _af_offset,lda,r,(1)- 1+(n-m+1- 1)*lda+ _r_offset,lda);
}              // Close if()
else  {
  Dlacpy.dlacpy("Full",m-n,n,af,_af_offset,lda,r,_r_offset,lda);
Dlacpy.dlacpy("Upper",n,n,af,(m-n+1)- 1+(1- 1)*lda+ _af_offset,lda,r,(m-n+1)- 1+(1- 1)*lda+ _r_offset,lda);
}              //  Close else.
// *
// *     Copy T
// *
Dlaset.dlaset("Full",p,n,zero,zero,t,_t_offset,ldb);
Dlacpy.dlacpy("Upper",p,n,bf,_bf_offset,ldb,t,_t_offset,ldb);
// *
// *     Compute R - A*Q'
// *
Dgemm.dgemm("No transpose","Transpose",m,n,n,-one,a,_a_offset,lda,q,_q_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( R - A*Q' ) / ( MAX(M,N)*norm(A)*ULP ) .
// *
resid = Dlange.dlange("1",m,n,r,_r_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (m) ? (1) : (m), n)))/anorm)/ulp;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute T*Q - Z'*B
// *
Dgemm.dgemm("Transpose","No transpose",p,n,p,one,z,_z_offset,ldb,b,_b_offset,ldb,zero,bwk,_bwk_offset,ldb);
Dgemm.dgemm("No transpose","No transpose",p,n,n,one,t,_t_offset,ldb,q,_q_offset,lda,-one,bwk,_bwk_offset,ldb);
// *
// *     Compute norm( T*Q - Z'*B ) / ( MAX(P,N)*norm(A)*ULP ) .
// *
resid = Dlange.dlange("1",p,n,bwk,_bwk_offset,ldb,rwork,_rwork_offset);
if (bnorm > zero)  {
    result[(2)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (p) ? (1) : (p), m)))/bnorm)/ulp;
}              // Close if()
else  {
  result[(2)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q*Q'
// *
Dlaset.dlaset("Full",n,n,zero,one,r,_r_offset,lda);
Dsyrk.dsyrk("Upper","No Transpose",n,n,-one,q,_q_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( I - Q'*Q ) / ( N * ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",n,r,_r_offset,lda,rwork,_rwork_offset);
result[(3)- 1+ _result_offset] = (resid/(double)(Math.max(1, n) ))/ulp;
// *
// *     Compute I - Z'*Z
// *
Dlaset.dlaset("Full",p,p,zero,one,t,_t_offset,ldb);
Dsyrk.dsyrk("Upper","Transpose",p,p,-one,z,_z_offset,ldb,one,t,_t_offset,ldb);
// *
// *     Compute norm( I - Z'*Z ) / ( P*ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",p,t,_t_offset,ldb,rwork,_rwork_offset);
result[(4)- 1+ _result_offset] = (resid/(double)(Math.max(1, p) ))/ulp;
// *
Dummy.go_to("Dgrqts",999999);
// *
// *     End of DGRQTS
// *
Dummy.label("Dgrqts",999999);
return;
   }
} // End class.
