/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgsvts {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGSVTS tests DGGSVD, which computes the GSVD of an M-by-N matrix A
// *  and a P-by-N matrix B:
// *               U'*A*Q = D1*R and V'*B*Q = D2*R.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B.  P >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,M)
// *          The M-by-N matrix A.
// *
// *  AF      (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the GSVD of A and B, as returned by DGGSVD,
// *          see DGGSVD for further details.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A and AF.
// *          LDA >= max( 1,M ).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,P)
// *          On entry, the P-by-N matrix B.
// *
// *  BF      (output) DOUBLE PRECISION array, dimension (LDB,N)
// *          Details of the GSVD of A and B, as returned by DGGSVD,
// *          see DGGSVD for further details.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arrays B and BF.
// *          LDB >= max(1,P).
// *
// *  U       (output) DOUBLE PRECISION array, dimension(LDU,M)
// *          The M by M orthogonal matrix U.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U. LDU >= max(1,M).
// *
// *  V       (output) DOUBLE PRECISION array, dimension(LDV,M)
// *          The P by P orthogonal matrix V.
// *
// *  LDV     (input) INTEGER
// *          The leading dimension of the array V. LDV >= max(1,P).
// *
// *  Q       (output) DOUBLE PRECISION array, dimension(LDQ,N)
// *          The N by N orthogonal matrix Q.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q. LDQ >= max(1,N).
// *
// *  ALPHA   (output) DOUBLE PRECISION array, dimension (N)
// *  BETA    (output) DOUBLE PRECISION array, dimension (N)
// *          The generalized singular value pairs of A and B, the
// *          ``diagonal'' matrices D1 and D2 are constructed from
// *          ALPHA and BETA, see subroutine DGGSVD for details.
// *
// *  R       (output) DOUBLE PRECISION array, dimension(LDQ,N)
// *          The upper triangular matrix R.
// *
// *  LDR     (input) INTEGER
// *          The leading dimension of the array R. LDR >= max(1,N).
// *
// *  IWORK   (workspace) INTEGER array, dimension (N)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK,
// *          LWORK >= max(M,P,N)*max(M,P,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (max(M,P,N))
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (5)
// *          The test ratios:
// *          RESULT(1) = norm( U'*A*Q - D1*R ) / ( MAX(M,N)*norm(A)*ULP)
// *          RESULT(2) = norm( V'*B*Q - D2*R ) / ( MAX(P,N)*norm(B)*ULP)
// *          RESULT(3) = norm( I - U'*U ) / ( M*ULP )
// *          RESULT(4) = norm( I - V'*V ) / ( P*ULP )
// *          RESULT(5) = norm( I - Q'*Q ) / ( N*ULP )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static intW k= new intW(0);
static intW l= new intW(0);
static double anorm= 0.0;
static double bnorm= 0.0;
static double resid= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dgsvts (int m,
int p,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
int lda,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
int ldb,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
int ldv,
double [] q, int _q_offset,
int ldq,
double [] alpha, int _alpha_offset,
double [] beta, int _beta_offset,
double [] r, int _r_offset,
int ldr,
int [] iwork, int _iwork_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

ulp = Dlamch.dlamch("Precision");
unfl = Dlamch.dlamch("Safe minimum");
// *
// *     Copy the matrix A to the array AF.
// *
Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,af,_af_offset,lda);
Dlacpy.dlacpy("Full",p,n,b,_b_offset,ldb,bf,_bf_offset,ldb);
// *
anorm = Math.max(Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset), unfl) ;
bnorm = Math.max(Dlange.dlange("1",p,n,b,_b_offset,ldb,rwork,_rwork_offset), unfl) ;
// *
// *     Factorize the matrices A and B in the arrays AF and BF.
// *
Dggsvd.dggsvd("U","V","Q",m,n,p,k,l,af,_af_offset,lda,bf,_bf_offset,ldb,alpha,_alpha_offset,beta,_beta_offset,u,_u_offset,ldu,v,_v_offset,ldv,q,_q_offset,ldq,work,_work_offset,iwork,_iwork_offset,info);
// *
// *     Copy R
// *
{
forloop20:
for (i = 1; i <= Math.min(k.val+l.val, m) ; i++) {
{
forloop10:
for (j = i; j <= k.val+l.val; j++) {
r[(i)- 1+(j- 1)*ldr+ _r_offset] = af[(i)- 1+(n-k.val-l.val+j- 1)*lda+ _af_offset];
Dummy.label("Dgsvts",10);
}              //  Close for() loop. 
}
Dummy.label("Dgsvts",20);
}              //  Close for() loop. 
}
// *
if (m-k.val-l.val < 0)  {
    {
forloop40:
for (i = m+1; i <= k.val+l.val; i++) {
{
forloop30:
for (j = i; j <= k.val+l.val; j++) {
r[(i)- 1+(j- 1)*ldr+ _r_offset] = bf[(i-k.val)- 1+(n-k.val-l.val+j- 1)*ldb+ _bf_offset];
Dummy.label("Dgsvts",30);
}              //  Close for() loop. 
}
Dummy.label("Dgsvts",40);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Compute A:= U'*A*Q - D1*R
// *
Dgemm.dgemm("No transpose","No transpose",m,n,n,one,a,_a_offset,lda,q,_q_offset,ldq,zero,work,_work_offset,lda);
// *
Dgemm.dgemm("Transpose","No transpose",m,n,m,one,u,_u_offset,ldu,work,_work_offset,lda,zero,a,_a_offset,lda);
// *
{
forloop60:
for (i = 1; i <= k.val; i++) {
{
forloop50:
for (j = i; j <= k.val+l.val; j++) {
a[(i)- 1+(n-k.val-l.val+j- 1)*lda+ _a_offset] = a[(i)- 1+(n-k.val-l.val+j- 1)*lda+ _a_offset]-r[(i)- 1+(j- 1)*ldr+ _r_offset];
Dummy.label("Dgsvts",50);
}              //  Close for() loop. 
}
Dummy.label("Dgsvts",60);
}              //  Close for() loop. 
}
// *
{
forloop80:
for (i = k.val+1; i <= Math.min(k.val+l.val, m) ; i++) {
{
forloop70:
for (j = i; j <= k.val+l.val; j++) {
a[(i)- 1+(n-k.val-l.val+j- 1)*lda+ _a_offset] = a[(i)- 1+(n-k.val-l.val+j- 1)*lda+ _a_offset]-alpha[(i)- 1+ _alpha_offset]*r[(i)- 1+(j- 1)*ldr+ _r_offset];
Dummy.label("Dgsvts",70);
}              //  Close for() loop. 
}
Dummy.label("Dgsvts",80);
}              //  Close for() loop. 
}
// *
// *     Compute norm( U'*A*Q - D1*R ) / ( MAX(1,M,N)*norm(A)*ULP ) .
// *
resid = Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset);
// *
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (m) ? (1) : (m), n)))/anorm)/ulp;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute B := V'*B*Q - D2*R
// *
Dgemm.dgemm("No transpose","No transpose",p,n,n,one,b,_b_offset,ldb,q,_q_offset,ldq,zero,work,_work_offset,ldb);
// *
Dgemm.dgemm("Transpose","No transpose",p,n,p,one,v,_v_offset,ldv,work,_work_offset,ldb,zero,b,_b_offset,ldb);
// *
{
forloop100:
for (i = 1; i <= l.val; i++) {
{
forloop90:
for (j = i; j <= l.val; j++) {
b[(i)- 1+(n-l.val+j- 1)*ldb+ _b_offset] = b[(i)- 1+(n-l.val+j- 1)*ldb+ _b_offset]-beta[(k.val+i)- 1+ _beta_offset]*r[(k.val+i)- 1+(k.val+j- 1)*ldr+ _r_offset];
Dummy.label("Dgsvts",90);
}              //  Close for() loop. 
}
Dummy.label("Dgsvts",100);
}              //  Close for() loop. 
}
// *
// *     Compute norm( V'*B*Q - D2*R ) / ( MAX(P,N)*norm(B)*ULP ) .
// *
resid = Dlange.dlange("1",p,n,b,_b_offset,ldb,rwork,_rwork_offset);
if (bnorm > zero)  {
    result[(2)- 1+ _result_offset] = ((resid/(double)(Math.max((1) > (p) ? (1) : (p), n)))/bnorm)/ulp;
}              // Close if()
else  {
  result[(2)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - U'*U
// *
Dlaset.dlaset("Full",m,m,zero,one,work,_work_offset,ldq);
Dsyrk.dsyrk("Upper","Transpose",m,m,-one,u,_u_offset,ldu,one,work,_work_offset,ldu);
// *
// *     Compute norm( I - U'*U ) / ( M * ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",m,work,_work_offset,ldu,rwork,_rwork_offset);
result[(3)- 1+ _result_offset] = (resid/(double)(Math.max(1, m) ))/ulp;
// *
// *     Compute I - V'*V
// *
Dlaset.dlaset("Full",p,p,zero,one,work,_work_offset,ldv);
Dsyrk.dsyrk("Upper","Transpose",p,p,-one,v,_v_offset,ldv,one,work,_work_offset,ldv);
// *
// *     Compute norm( I - V'*V ) / ( P * ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",p,work,_work_offset,ldv,rwork,_rwork_offset);
result[(4)- 1+ _result_offset] = (resid/(double)(Math.max(1, p) ))/ulp;
// *
// *     Compute I - Q'*Q
// *
Dlaset.dlaset("Full",n,n,zero,one,work,_work_offset,ldq);
Dsyrk.dsyrk("Upper","Transpose",n,n,-one,q,_q_offset,ldq,one,work,_work_offset,ldq);
// *
// *     Compute norm( I - Q'*Q ) / ( N * ULP ) .
// *
resid = Dlansy.dlansy("1","Upper",n,work,_work_offset,ldq,rwork,_rwork_offset);
result[(5)- 1+ _result_offset] = (resid/(double)(Math.max(1, n) ))/ulp;
// *
Dummy.go_to("Dgsvts",999999);
// *
// *     End of DGSVTS
// *
Dummy.label("Dgsvts",999999);
return;
   }
} // End class.
