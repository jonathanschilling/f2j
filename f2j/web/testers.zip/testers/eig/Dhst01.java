/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dhst01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DHST01 tests the reduction of a general matrix A to upper Hessenberg
// *  form:  A = Q*H*Q'.  Two test ratios are computed;
// *
// *  RESULT(1) = norm( A - Q*H*Q' ) / ( norm(A) * N * EPS )
// *  RESULT(2) = norm( I - Q'*Q ) / ( N * EPS )
// *
// *  The matrix Q is assumed to be given explicitly as it would be
// *  following DGEHRD + DORGHR.
// *
// *  In this version, ILO and IHI are not used and are assumed to be 1 and
// *  N, respectively.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  ILO     (input) INTEGER
// *  IHI     (input) INTEGER
// *          A is assumed to be upper triangular in rows and columns
// *          1:ILO-1 and IHI+1:N, so Q differs from the identity only in
// *          rows and columns ILO+1:IHI.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original n by n matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  H       (input) DOUBLE PRECISION array, dimension (LDH,N)
// *          The upper Hessenberg matrix H from the reduction A = Q*H*Q'
// *          as computed by DGEHRD.  H is assumed to be zero below the
// *          first subdiagonal.
// *
// *  LDH     (input) INTEGER
// *          The leading dimension of the array H.  LDH >= max(1,N).
// *
// *  Q       (input) DOUBLE PRECISION array, dimension (LDQ,N)
// *          The orthogonal matrix Q from the reduction A = Q*H*Q' as
// *          computed by DGEHRD + DORGHR.
// *
// *  LDQ     (input) INTEGER
// *          The leading dimension of the array Q.  LDQ >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK >= 2*N*N.
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          RESULT(1) = norm( A - Q*H*Q' ) / ( norm(A) * N * EPS )
// *          RESULT(2) = norm( I - Q'*Q ) / ( N * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int ldwork= 0;
static double anorm= 0.0;
static double eps= 0.0;
static doubleW ovfl= new doubleW(0.0);
static double smlnum= 0.0;
static doubleW unfl= new doubleW(0.0);
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dhst01 (int n,
int ilo,
int ihi,
double [] a, int _a_offset,
int lda,
double [] h, int _h_offset,
int ldh,
double [] q, int _q_offset,
int ldq,
double [] work, int _work_offset,
int lwork,
double [] result, int _result_offset)  {

if (n <= 0)  {
    result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
Dummy.go_to("Dhst01",999999);
}              // Close if()
// *
unfl.val = Dlamch.dlamch("Safe minimum");
eps = Dlamch.dlamch("Precision");
ovfl.val = one/unfl.val;
Dlabad.dlabad(unfl,ovfl);
smlnum = unfl.val*n/eps;
// *
// *     Test 1:  Compute norm( A - Q*H*Q' ) / ( norm(A) * N * EPS )
// *
// *     Copy A to WORK
// *
ldwork = (int)(Math.max(1, n) );
Dlacpy.dlacpy(" ",n,n,a,_a_offset,lda,work,_work_offset,ldwork);
// *
// *     Compute Q*H
// *
Dgemm.dgemm("No transpose","No transpose",n,n,n,one,q,_q_offset,ldq,h,_h_offset,ldh,zero,work,(ldwork*n+1)- 1+ _work_offset,ldwork);
// *
// *     Compute A - Q*H*Q'
// *
Dgemm.dgemm("No transpose","Transpose",n,n,n,-one,work,(ldwork*n+1)- 1+ _work_offset,ldwork,q,_q_offset,ldq,one,work,_work_offset,ldwork);
// *
anorm = Math.max(Dlange.dlange("1",n,n,a,_a_offset,lda,work,(ldwork*n+1)- 1+ _work_offset), unfl.val) ;
wnorm = Dlange.dlange("1",n,n,work,_work_offset,ldwork,work,(ldwork*n+1)- 1+ _work_offset);
// *
// *     Note that RESULT(1) cannot overflow and is bounded by 1/(N*EPS)
// *
result[(1)- 1+ _result_offset] = Math.min(wnorm, anorm) /Math.max(smlnum, anorm*eps) /n;
// *
// *     Test 2:  Compute norm( I - Q'*Q ) / ( N * EPS )
// *
dort01_adapter("Columns",n,n,q,_q_offset,ldq,work,_work_offset,lwork,result,(2)- 1+ _result_offset);
// *
Dummy.go_to("Dhst01",999999);
// *
// *     End of DHST01
// *
Dummy.label("Dhst01",999999);
return;
   }
// adapter for dort01
private static void dort01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dort01.dort01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
