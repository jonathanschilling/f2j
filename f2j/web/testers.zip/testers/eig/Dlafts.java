/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlafts {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DLAFTS tests the result vector against the threshold value to
// *     see which tests for this matrix type failed to pass the threshold.
// *     Output is to the file given by unit IOUNIT.
// *
// *  Arguments
// *  =========
// *
// *  TYPE   - CHARACTER*3
// *           On entry, TYPE specifies the matrix type to be used in the
// *           printed messages.
// *           Not modified.
// *
// *  N      - INTEGER
// *           On entry, N specifies the order of the test matrix.
// *           Not modified.
// *
// *  IMAT   - INTEGER
// *           On entry, IMAT specifies the type of the test matrix.
// *           A listing of the different types is printed by DLAHD2
// *           to the output file if a test fails to pass the threshold.
// *           Not modified.
// *
// *  NTESTS - INTEGER
// *           On entry, NTESTS is the number of tests performed on the
// *           subroutines in the path given by TYPE.
// *           Not modified.
// *
// *  RESULT - DOUBLE PRECISION               array of dimension( NTESTS )
// *           On entry, RESULT contains the test ratios from the tests
// *           performed in the calling program.
// *           Not modified.
// *
// *  ISEED  - INTEGER            array of dimension( 4 )
// *           Contains the random seed that generated the matrix used
// *           for the tests whose ratios are in RESULT.
// *           Not modified.
// *
// *  THRESH - DOUBLE PRECISION
// *           On entry, THRESH specifies the acceptable threshold of the
// *           test ratios.  If RESULT( K ) > THRESH, then the K-th test
// *           did not pass the threshold and a message will be printed.
// *           Not modified.
// *
// *  IOUNIT - INTEGER
// *           On entry, IOUNIT specifies the unit number of the file
// *           to which the messages are printed.
// *           Not modified.
// *
// *  IE     - INTEGER
// *           On entry, IE contains the number of tests which have
// *           failed to pass the threshold so far.
// *           Updated on exit if any of the ratios in RESULT also fail.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static int k= 0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlafts (String type,
int m,
int n,
int imat,
int ntests,
double [] result, int _result_offset,
int [] iseed, int _iseed_offset,
double thresh,
int iounit,
intW ie)  {

if (m == n)  {
    // *
// *     Output for square matrices:
// *
{
forloop10:
for (k = 1; k <= ntests; k++) {
if (result[(k)- 1+ _result_offset] >= thresh)  {
    // *
// *           If this is the first test to fail, call DLAHD2
// *           to print a header to the data file.
// *
if (ie.val == 0)  
    Dlahd2.dlahd2(iounit,type);
ie.val = ie.val+1;
// ***            WRITE( IOUNIT, 15 )' Matrix of order', N,
// ***     $               ',  type ', IMAT,
// ***     $               ',  test ', K,
// ***     $               ',  ratio = ', RESULT( K )
// ***   15       FORMAT( A16, I5, 2( A8, I2 ), A11, G13.6 )
if (result[(k)- 1+ _result_offset] < 10000.0e0)  {
    System.out.println(" Matrix order="  + (n) + " "  + ", type="  + (imat) + " "  + ", seed="  + (iseed) + " "  + ","  + (k) + " "  + ","  + (result[(k)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ","  + " result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              // Close if()
else  {
  System.out.println(" Matrix order="  + (n) + " "  + ", type="  + (imat) + " "  + ", seed="  + (iseed) + " "  + ","  + (k) + " "  + ","  + (result[(k)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ","  + " result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              //  Close else.
}              // Close if()
Dummy.label("Dlafts",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *     Output for rectangular matrices
// *
{
forloop20:
for (k = 1; k <= ntests; k++) {
if (result[(k)- 1+ _result_offset] >= thresh)  {
    // *
// *              If this is the first test to fail, call DLAHD2
// *              to print a header to the data file.
// *
if (ie.val == 0)  
    Dlahd2.dlahd2(iounit,type);
ie.val = ie.val+1;
// ***              WRITE( IOUNIT, FMT = 9997 )' Matrix of size', M, ' x',
// ***     $             N, ', type ', IMAT, ',  test ', K, ',  ratio = ',
// ***     $             RESULT( K )
// *** 9997           FORMAT( A10, I5, A2, I5, A7, I2, A8, I2, A11, G13.6 )
if (result[(k)- 1+ _result_offset] < 10000.0e0)  {
    System.out.println(" " + (m) + " "  + " x"  + (n) + " "  + " matrix, type="  + (imat) + " "  + ", s"  + "eed="  + (iseed) + " "  + ","  + (k) + " "  + ","  + (result[(k)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ": result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              // Close if()
else  {
  System.out.println(" " + (m) + " "  + " x"  + (n) + " "  + " matrix, type="  + (imat) + " "  + ", s"  + "eed="  + (iseed) + " "  + ","  + (k) + " "  + ","  + (result[(k)- 1+ _result_offset]) + " "  + ","  + " NULL " + " "  + ": result "  + " NULL " + " "  + " is"  + " NULL " + " " );
}              //  Close else.
}              // Close if()
Dummy.label("Dlafts",20);
}              //  Close for() loop. 
}
// *
}              //  Close else.
Dummy.go_to("Dlafts",999999);
// *
// *     End of DLAFTS
// *
Dummy.label("Dlafts",999999);
return;
   }
} // End class.
