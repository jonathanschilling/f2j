/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlagge {

// *
// *  -- LAPACK auxiliary test routine (version 2.0)
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGGE generates a real general m by n matrix A, by pre- and post-
// *  multiplying a real diagonal matrix D with random orthogonal matrices:
// *  A = U*D*V. The lower and upper bandwidths may then be reduced to
// *  kl and ku by additional orthogonal transformations.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of nonzero subdiagonals within the band of A.
// *          0 <= KL <= M-1.
// *
// *  KU      (input) INTEGER
// *          The number of nonzero superdiagonals within the band of A.
// *          0 <= KU <= N-1.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (min(M,N))
// *          The diagonal elements of the diagonal matrix D.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The generated m by n matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= M.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator; the array
// *          elements must be between 0 and 4095, and ISEED(4) must be
// *          odd.
// *          On exit, the seed is updated.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (M+N)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double tau= 0.0;
static double wa= 0.0;
static double wb= 0.0;
static double wn= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dlagge (int m,
int n,
int kl,
int ku,
double [] d, int _d_offset,
double [] a, int _a_offset,
int lda,
int [] iseed, int _iseed_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (kl < 0 || kl > m-1)  {
    info.val = -3;
}              // Close else if()
else if (ku < 0 || ku > n-1)  {
    info.val = -4;
}              // Close else if()
else if (lda < Math.max(1, m) )  {
    info.val = -7;
}              // Close else if()
if (info.val < 0)  {
    Xerbla.xerbla("DLAGGE",-info.val);
Dummy.go_to("Dlagge",999999);
}              // Close if()
// *
// *     initialize A to diagonal matrix
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlagge",10);
}              //  Close for() loop. 
}
Dummy.label("Dlagge",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= Math.min(m, n) ; i++) {
a[(i)- 1+(i- 1)*lda+ _a_offset] = d[(i)- 1+ _d_offset];
Dummy.label("Dlagge",30);
}              //  Close for() loop. 
}
// *
// *     pre- and post-multiply A by random orthogonal matrices
// *
{
int _i_inc = -1;
forloop40:
for (i = (int)(Math.min(m, n) ); (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
if (i < m)  {
    // *
// *           generate random reflection
// *
Dlarnv.dlarnv(3,iseed,_iseed_offset,m-i+1,work,_work_offset);
wn = Dnrm2.dnrm2(m-i+1,work,_work_offset,1);
wa = ((work[(1)- 1+ _work_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = work[(1)- 1+ _work_offset]+wa;
Dscal.dscal(m-i,one/wb,work,(2)- 1+ _work_offset,1);
work[(1)- 1+ _work_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *           multiply A(i:m,i:n) by random reflection from the left
// *
Dgemv.dgemv("Transpose",m-i+1,n-i+1,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(m+1)- 1+ _work_offset,1);
Dger.dger(m-i+1,n-i+1,-tau,work,_work_offset,1,work,(m+1)- 1+ _work_offset,1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
}              // Close if()
if (i < n)  {
    // *
// *           generate random reflection
// *
Dlarnv.dlarnv(3,iseed,_iseed_offset,n-i+1,work,_work_offset);
wn = Dnrm2.dnrm2(n-i+1,work,_work_offset,1);
wa = ((work[(1)- 1+ _work_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = work[(1)- 1+ _work_offset]+wa;
Dscal.dscal(n-i,one/wb,work,(2)- 1+ _work_offset,1);
work[(1)- 1+ _work_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *           multiply A(i:m,i:n) by random reflection from the right
// *
Dgemv.dgemv("No transpose",m-i+1,n-i+1,one,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(n+1)- 1+ _work_offset,1);
Dger.dger(m-i+1,n-i+1,-tau,work,(n+1)- 1+ _work_offset,1,work,_work_offset,1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
}              // Close if()
Dummy.label("Dlagge",40);
}              //  Close for() loop. 
}
// *
// *     Reduce number of subdiagonals to KL and number of superdiagonals
// *     to KU
// *
{
forloop70:
for (i = 1; i <= Math.max(m-1-kl, n-1-ku) ; i++) {
if (kl <= ku)  {
    // *
// *           annihilate subdiagonal elements first (necessary if KL = 0)
// *
if (i <= Math.min(m-1-kl, n) )  {
    // *
// *              generate reflection to annihilate A(kl+i+1:m,i)
// *
wn = Dnrm2.dnrm2(m-kl-i+1,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1);
wa = ((a[(kl+i)- 1+(i- 1)*lda+ _a_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = a[(kl+i)- 1+(i- 1)*lda+ _a_offset]+wa;
Dscal.dscal(m-kl-i,one/wb,a,(kl+i+1)- 1+(i- 1)*lda+ _a_offset,1);
a[(kl+i)- 1+(i- 1)*lda+ _a_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *              apply reflection to A(kl+i:m,i+1:n) from the left
// *
Dgemv.dgemv("Transpose",m-kl-i+1,n-i,one,a,(kl+i)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1,zero,work,_work_offset,1);
Dger.dger(m-kl-i+1,n-i,-tau,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1,work,_work_offset,1,a,(kl+i)- 1+(i+1- 1)*lda+ _a_offset,lda);
a[(kl+i)- 1+(i- 1)*lda+ _a_offset] = -wa;
}              // Close if()
// *
if (i <= Math.min(n-1-ku, m) )  {
    // *
// *              generate reflection to annihilate A(i,ku+i+1:n)
// *
wn = Dnrm2.dnrm2(n-ku-i+1,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda);
wa = ((a[(i)- 1+(ku+i- 1)*lda+ _a_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = a[(i)- 1+(ku+i- 1)*lda+ _a_offset]+wa;
Dscal.dscal(n-ku-i,one/wb,a,(i)- 1+(ku+i+1- 1)*lda+ _a_offset,lda);
a[(i)- 1+(ku+i- 1)*lda+ _a_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *              apply reflection to A(i+1:m,ku+i:n) from the right
// *
Dgemv.dgemv("No transpose",m-i,n-ku-i+1,one,a,(i+1)- 1+(ku+i- 1)*lda+ _a_offset,lda,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda,zero,work,_work_offset,1);
Dger.dger(m-i,n-ku-i+1,-tau,work,_work_offset,1,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(ku+i- 1)*lda+ _a_offset,lda);
a[(i)- 1+(ku+i- 1)*lda+ _a_offset] = -wa;
}              // Close if()
}              // Close if()
else  {
  // *
// *           annihilate superdiagonal elements first (necessary if
// *           KU = 0)
// *
if (i <= Math.min(n-1-ku, m) )  {
    // *
// *              generate reflection to annihilate A(i,ku+i+1:n)
// *
wn = Dnrm2.dnrm2(n-ku-i+1,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda);
wa = ((a[(i)- 1+(ku+i- 1)*lda+ _a_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = a[(i)- 1+(ku+i- 1)*lda+ _a_offset]+wa;
Dscal.dscal(n-ku-i,one/wb,a,(i)- 1+(ku+i+1- 1)*lda+ _a_offset,lda);
a[(i)- 1+(ku+i- 1)*lda+ _a_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *              apply reflection to A(i+1:m,ku+i:n) from the right
// *
Dgemv.dgemv("No transpose",m-i,n-ku-i+1,one,a,(i+1)- 1+(ku+i- 1)*lda+ _a_offset,lda,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda,zero,work,_work_offset,1);
Dger.dger(m-i,n-ku-i+1,-tau,work,_work_offset,1,a,(i)- 1+(ku+i- 1)*lda+ _a_offset,lda,a,(i+1)- 1+(ku+i- 1)*lda+ _a_offset,lda);
a[(i)- 1+(ku+i- 1)*lda+ _a_offset] = -wa;
}              // Close if()
// *
if (i <= Math.min(m-1-kl, n) )  {
    // *
// *              generate reflection to annihilate A(kl+i+1:m,i)
// *
wn = Dnrm2.dnrm2(m-kl-i+1,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1);
wa = ((a[(kl+i)- 1+(i- 1)*lda+ _a_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = a[(kl+i)- 1+(i- 1)*lda+ _a_offset]+wa;
Dscal.dscal(m-kl-i,one/wb,a,(kl+i+1)- 1+(i- 1)*lda+ _a_offset,1);
a[(kl+i)- 1+(i- 1)*lda+ _a_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *              apply reflection to A(kl+i:m,i+1:n) from the left
// *
Dgemv.dgemv("Transpose",m-kl-i+1,n-i,one,a,(kl+i)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1,zero,work,_work_offset,1);
Dger.dger(m-kl-i+1,n-i,-tau,a,(kl+i)- 1+(i- 1)*lda+ _a_offset,1,work,_work_offset,1,a,(kl+i)- 1+(i+1- 1)*lda+ _a_offset,lda);
a[(kl+i)- 1+(i- 1)*lda+ _a_offset] = -wa;
}              // Close if()
}              //  Close else.
// *
{
forloop50:
for (j = kl+i+1; j <= m; j++) {
a[(j)- 1+(i- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlagge",50);
}              //  Close for() loop. 
}
// *
{
forloop60:
for (j = ku+i+1; j <= n; j++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlagge",60);
}              //  Close for() loop. 
}
Dummy.label("Dlagge",70);
}              //  Close for() loop. 
}
Dummy.go_to("Dlagge",999999);
// *
// *     End of DLAGGE
// *
Dummy.label("Dlagge",999999);
return;
   }
} // End class.
