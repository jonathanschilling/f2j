/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlagsy {

// *
// *  -- LAPACK auxiliary test routine (version 2.0)
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAGSY generates a real symmetric matrix A, by pre- and post-
// *  multiplying a real diagonal matrix D with a random orthogonal matrix:
// *  A = U*D*U'. The semi-bandwidth may then be reduced to k by additional
// *  orthogonal transformations.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  K       (input) INTEGER
// *          The number of nonzero subdiagonals within the band of A.
// *          0 <= K <= N-1.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal elements of the diagonal matrix D.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The generated n by n symmetric matrix A (the full matrix is
// *          stored).
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= N.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator; the array
// *          elements must be between 0 and 4095, and ISEED(4) must be
// *          odd.
// *          On exit, the seed is updated.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double half= 0.5e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double alpha= 0.0;
static double tau= 0.0;
static double wa= 0.0;
static double wb= 0.0;
static double wn= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dlagsy (int n,
int k,
double [] d, int _d_offset,
double [] a, int _a_offset,
int lda,
int [] iseed, int _iseed_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (k < 0 || k > n-1)  {
    info.val = -2;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -5;
}              // Close else if()
if (info.val < 0)  {
    Xerbla.xerbla("DLAGSY",-info.val);
Dummy.go_to("Dlagsy",999999);
}              // Close if()
// *
// *     initialize lower triangle of A to diagonal matrix
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = j+1; i <= n; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlagsy",10);
}              //  Close for() loop. 
}
Dummy.label("Dlagsy",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n; i++) {
a[(i)- 1+(i- 1)*lda+ _a_offset] = d[(i)- 1+ _d_offset];
Dummy.label("Dlagsy",30);
}              //  Close for() loop. 
}
// *
// *     Generate lower triangle of symmetric matrix
// *
{
int _i_inc = -1;
forloop40:
for (i = n-1; (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
// *
// *        generate random reflection
// *
Dlarnv.dlarnv(3,iseed,_iseed_offset,n-i+1,work,_work_offset);
wn = Dnrm2.dnrm2(n-i+1,work,_work_offset,1);
wa = ((work[(1)- 1+ _work_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = work[(1)- 1+ _work_offset]+wa;
Dscal.dscal(n-i,one/wb,work,(2)- 1+ _work_offset,1);
work[(1)- 1+ _work_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *        apply random reflection to A(i:n,i:n) from the left
// *        and the right
// *
// *        compute  y := tau * A * u
// *
Dsymv.dsymv("Lower",n-i+1,tau,a,(i)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(n+1)- 1+ _work_offset,1);
// *
// *        compute  v := y - 1/2 * tau * ( y, u ) * u
// *
alpha = -half*tau*Ddot.ddot(n-i+1,work,(n+1)- 1+ _work_offset,1,work,_work_offset,1);
Daxpy.daxpy(n-i+1,alpha,work,_work_offset,1,work,(n+1)- 1+ _work_offset,1);
// *
// *        apply the transformation as a rank-2 update to A(i:n,i:n)
// *
Dsyr2.dsyr2("Lower",n-i+1,-one,work,_work_offset,1,work,(n+1)- 1+ _work_offset,1,a,(i)- 1+(i- 1)*lda+ _a_offset,lda);
Dummy.label("Dlagsy",40);
}              //  Close for() loop. 
}
// *
// *     Reduce number of subdiagonals to K
// *
{
forloop60:
for (i = 1; i <= n-1-k; i++) {
// *
// *        generate reflection to annihilate A(k+i+1:n,i)
// *
wn = Dnrm2.dnrm2(n-k-i+1,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1);
wa = ((a[(k+i)- 1+(i- 1)*lda+ _a_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = a[(k+i)- 1+(i- 1)*lda+ _a_offset]+wa;
Dscal.dscal(n-k-i,one/wb,a,(k+i+1)- 1+(i- 1)*lda+ _a_offset,1);
a[(k+i)- 1+(i- 1)*lda+ _a_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *        apply reflection to A(k+i:n,i+1:k+i-1) from the left
// *
Dgemv.dgemv("Transpose",n-k-i+1,k-1,one,a,(k+i)- 1+(i+1- 1)*lda+ _a_offset,lda,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,zero,work,_work_offset,1);
Dger.dger(n-k-i+1,k-1,-tau,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,work,_work_offset,1,a,(k+i)- 1+(i+1- 1)*lda+ _a_offset,lda);
// *
// *        apply reflection to A(k+i:n,k+i:n) from the left and the right
// *
// *        compute  y := tau * A * u
// *
Dsymv.dsymv("Lower",n-k-i+1,tau,a,(k+i)- 1+(k+i- 1)*lda+ _a_offset,lda,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,zero,work,_work_offset,1);
// *
// *        compute  v := y - 1/2 * tau * ( y, u ) * u
// *
alpha = -half*tau*Ddot.ddot(n-k-i+1,work,_work_offset,1,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1);
Daxpy.daxpy(n-k-i+1,alpha,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,work,_work_offset,1);
// *
// *        apply symmetric rank-2 update to A(k+i:n,k+i:n)
// *
Dsyr2.dsyr2("Lower",n-k-i+1,-one,a,(k+i)- 1+(i- 1)*lda+ _a_offset,1,work,_work_offset,1,a,(k+i)- 1+(k+i- 1)*lda+ _a_offset,lda);
// *
a[(k+i)- 1+(i- 1)*lda+ _a_offset] = -wa;
{
forloop50:
for (j = k+i+1; j <= n; j++) {
a[(j)- 1+(i- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlagsy",50);
}              //  Close for() loop. 
}
Dummy.label("Dlagsy",60);
}              //  Close for() loop. 
}
// *
// *     Store full symmetric matrix
// *
{
forloop80:
for (j = 1; j <= n; j++) {
{
forloop70:
for (i = j+1; i <= n; i++) {
a[(j)- 1+(i- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlagsy",70);
}              //  Close for() loop. 
}
Dummy.label("Dlagsy",80);
}              //  Close for() loop. 
}
Dummy.go_to("Dlagsy",999999);
// *
// *     End of DLAGSY
// *
Dummy.label("Dlagsy",999999);
return;
   }
} // End class.
