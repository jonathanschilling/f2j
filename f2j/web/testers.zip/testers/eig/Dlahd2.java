/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlahd2 {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLAHD2 prints header information for the different test paths.
// *
// *  Arguments
// *  =========
// *
// *  IOUNIT  (input) INTEGER.
// *          On entry, IOUNIT specifies the unit number to which the
// *          header information should be printed.
// *
// *  PATH    (input) CHARACTER*3.
// *          On entry, PATH contains the name of the path for which the
// *          header information is to be printed.  Current paths are
// *
// *             DHS, ZHS:  Non-symmetric eigenproblem.
// *             DST, ZST:  Symmetric eigenproblem.
// *             DSG, ZSG:  Symmetric Generalized eigenproblem.
// *             DBD, ZBD:  Singular Value Decomposition (SVD)
// *             DBB, ZBB:  General Banded reduction to bidiagonal form
// *
// *          These paths also are supplied in double precision (replace
// *          leading S by D and leading C by Z in path names).
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean corz= false;
static boolean sord= false;
static String c2= new String("  ");
static int j= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlahd2 (int iounit,
String path)  {

if (iounit <= 0)  
    Dummy.go_to("Dlahd2",999999);
sord = (path.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (path.toLowerCase().charAt(0) == "D".toLowerCase().charAt(0));
corz = (path.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)) || (path.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0));
if (!sord && !corz)  {
    System.out.println(" " + (path) + " "  + ":  no header available" );
}              // Close if()
c2 = path.substring((2)-1,3);
// *
if (c2.regionMatches(true,0,"HS",0,2))  {
    if (sord)  {
    // *
// *           Real Non-symmetric Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Real Non-symmetric eigenvalue problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKHS for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: geometr. spaced entries."  + "\n"  + "  2=Identity matrix.                    "  + "  6=Diagona"  + "l: clustered entries."  + "\n"  + "  3=Transposed Jordan block.  "  + "          "  + "  7=Diagonal: large, evenly spaced."  + "\n"  + "  "  + "4=Diagonal: evenly spaced entries.    "  + "  8=Diagonal: s"  + "mall, evenly spaced." );
System.out.println(" Dense, Non-Symmetric Matrices:"  + "\n"  + "  9=Well-cond., ev"  + "enly spaced eigenvals."  + " 14=Ill-cond., geomet. spaced e"  + "igenals."  + "\n"  + " 10=Well-cond., geom. spaced eigenvals. "  + " 15=Ill-conditioned, clustered e.vals."  + "\n"  + " 11=Well-cond"  + "itioned, clustered e.vals. "  + " 16=Ill-cond., random comp"  + "lex "  + ("pairs ") + " "  + "\n"  + " 12=Well-cond., random complex "  + ("pairs ") + " "  + "   "  + " 17=Ill-cond., large rand. complx "  + ("prs.") + " "  + "\n"  + " 13=Ill-condi"  + "tioned, evenly spaced.     "  + " 18=Ill-cond., small rand."  + " complx "  + ("prs.") + " " );
System.out.println(" 19=Matrix with random O(1) entries.    "  + " 21=Matrix "  + "with small random entries."  + "\n"  + " 20=Matrix with large ran"  + "dom entries.   " );
// *
// *           Tests performed
// *
System.out.print(("orthogonal") + " " + ("\'=transpose") + " ");
for(j = 1; j <= 6; j++)
  System.out.print(" ");

System.out.println();
// *
}              // Close if()
else  {
  // *
// *           Complex Non-symmetric Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Complex Non-symmetric eigenvalue problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKHS for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: geometr. spaced entries."  + "\n"  + "  2=Identity matrix.                    "  + "  6=Diagona"  + "l: clustered entries."  + "\n"  + "  3=Transposed Jordan block.  "  + "          "  + "  7=Diagonal: large, evenly spaced."  + "\n"  + "  "  + "4=Diagonal: evenly spaced entries.    "  + "  8=Diagonal: s"  + "mall, evenly spaced." );
System.out.println(" Dense, Non-Symmetric Matrices:"  + "\n"  + "  9=Well-cond., ev"  + "enly spaced eigenvals."  + " 14=Ill-cond., geomet. spaced e"  + "igenals."  + "\n"  + " 10=Well-cond., geom. spaced eigenvals. "  + " 15=Ill-conditioned, clustered e.vals."  + "\n"  + " 11=Well-cond"  + "itioned, clustered e.vals. "  + " 16=Ill-cond., random comp"  + "lex "  + ("e.vals") + " "  + "\n"  + " 12=Well-cond., random complex "  + ("e.vals") + " "  + "   "  + " 17=Ill-cond., large rand. complx "  + ("e.vs") + " "  + "\n"  + " 13=Ill-condi"  + "tioned, evenly spaced.     "  + " 18=Ill-cond., small rand."  + " complx "  + ("e.vs") + " " );
System.out.println(" 19=Matrix with random O(1) entries.    "  + " 21=Matrix "  + "with small random entries."  + "\n"  + " 20=Matrix with large ran"  + "dom entries.   " );
// *
// *           Tests performed
// *
System.out.print(("unitary") + " " + ("*=conj.transp.") + " ");
for(j = 1; j <= 6; j++)
  System.out.print(" ");

System.out.println();
}              //  Close else.
// *
}              // Close if()
else if (c2.regionMatches(true,0,"ST",0,2))  {
    // *
if (sord)  {
    // *
// *           Real Symmetric Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Real Symmetric eigenvalue problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xDRVST for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2="  + "Identity matrix.                    "  + "  6=Diagonal: lar"  + "ge, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entri"  + "es.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=D"  + "iagonal: geometr. spaced entries." );
System.out.println(" Dense "  + ("Symmetric") + " "  + " Matrices:"  + "\n"  + "  8=Evenly spaced eigen"  + "vals.            "  + " 12=Small, evenly spaced eigenvals."  + "\n"  + "  9=Geometrically spaced eigenvals.     "  + " 13=Matrix "  + "with random O(1) entries."  + "\n"  + " 10=Clustered eigenvalues."  + "              "  + " 14=Matrix with large random entries."  + "\n"  + " 11=Large, evenly spaced eigenvals.     "  + " 15=Matrix "  + "with small random entries." );
// *
// *           Tests performed
// *
System.out.print(("orthogonal") + " " + ("\'=transpose") + " ");
for(j = 1; j <= 6; j++)
  System.out.print(" ");

System.out.println();
// *
}              // Close if()
else  {
  // *
// *           Complex Hermitian Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Complex Hermitian eigenvalue problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xDRVST for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2="  + "Identity matrix.                    "  + "  6=Diagonal: lar"  + "ge, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entri"  + "es.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=D"  + "iagonal: geometr. spaced entries." );
System.out.println(" Dense "  + ("Hermitian") + " "  + " Matrices:"  + "\n"  + "  8=Evenly spaced eigen"  + "vals.            "  + " 12=Small, evenly spaced eigenvals."  + "\n"  + "  9=Geometrically spaced eigenvals.     "  + " 13=Matrix "  + "with random O(1) entries."  + "\n"  + " 10=Clustered eigenvalues."  + "              "  + " 14=Matrix with large random entries."  + "\n"  + " 11=Large, evenly spaced eigenvals.     "  + " 15=Matrix "  + "with small random entries." );
// *
// *           Tests performed
// *
System.out.print(("unitary") + " " + ("*=conj.transp.") + " ");
for(j = 1; j <= 6; j++)
  System.out.print(" ");

System.out.println();
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SG",0,2))  {
    // *
if (sord)  {
    // *
// *           Real Symmetric Generalized Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Real Symmetric Generalized eigenvalue "  + "problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xDRVSG for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2="  + "Identity matrix.                    "  + "  6=Diagonal: lar"  + "ge, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entri"  + "es.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=D"  + "iagonal: geometr. spaced entries." );
System.out.println(" Dense or Banded "  + ("Symmetric") + " "  + " Matrices: "  + "\n"  + "  8=Evenly spaced eigenvals.         "  + " 15=Matrix with small random entries."  + "\n"  + "  9=Geometrically spaced eigenvals.  "  + " 16=Evenly spaced eigenvals, KA=1, KB=1."  + "\n"  + " 10=Clustered eigenvalues.           "  + " 17=Evenly spaced eigenvals, KA=2, KB=1."  + "\n"  + " 11=Large, evenly spaced eigenvals.  "  + " 18=Evenly spaced eigenvals, KA=2, KB=2."  + "\n"  + " 12=Small, evenly spaced eigenvals.  "  + " 19=Evenly spaced eigenvals, KA=3, KB=1."  + "\n"  + " 13=Matrix with random O(1) entries. "  + " 20=Evenly spaced eigenvals, KA=3, KB=2."  + "\n"  + " 14=Matrix with large random entries."  + " 21=Evenly spaced eigenvals, KA=3, KB=3." );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Tests performed:   "  + "\n"  + "( For each pair (A,B), where A is of the given type "  + "\n"  + " and B is a random well-conditioned matrix. D is "  + "\n"  + " diagonal, and Z is orthogonal. )"  + "\n"  + " 1 = DSYGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 2 = DSPGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 3 = DSBGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 4 = DSYGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 5 = DSPGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 6 = DSBGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     " );
System.out.println(" 7 = DSYGV, with ITYPE=2 and UPLO=\'U\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 8 = DSPGV, with ITYPE=2 and UPLO=\'U\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 9 = DSPGV, with ITYPE=2 and UPLO=\'L\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "10 = DSPGV, with ITYPE=2 and UPLO=\'L\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "11 = DSYGV, with ITYPE=3 and UPLO=\'U\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "12 = DSPGV, with ITYPE=3 and UPLO=\'U\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "13 = DSYGV, with ITYPE=3 and UPLO=\'L\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "14 = DSPGV, with ITYPE=3 and UPLO=\'L\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     " );
// *
}              // Close if()
else  {
  // *
// *           Complex Hermitian Generalized Eigenvalue Problem:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Complex Hermitian Generalized eigenvalue "  + "problem" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xDRVSG for details): " );
System.out.println("\n"  + " Special Matrices:"  + "\n"  + "  1=Zero matrix.             "  + "           "  + "  5=Diagonal: clustered entries."  + "\n"  + "  2="  + "Identity matrix.                    "  + "  6=Diagonal: lar"  + "ge, evenly spaced."  + "\n"  + "  3=Diagonal: evenly spaced entri"  + "es.    "  + "  7=Diagonal: small, evenly spaced."  + "\n"  + "  4=D"  + "iagonal: geometr. spaced entries." );
System.out.println(" Dense or Banded "  + ("Hermitian") + " "  + " Matrices: "  + "\n"  + "  8=Evenly spaced eigenvals.         "  + " 15=Matrix with small random entries."  + "\n"  + "  9=Geometrically spaced eigenvals.  "  + " 16=Evenly spaced eigenvals, KA=1, KB=1."  + "\n"  + " 10=Clustered eigenvalues.           "  + " 17=Evenly spaced eigenvals, KA=2, KB=1."  + "\n"  + " 11=Large, evenly spaced eigenvals.  "  + " 18=Evenly spaced eigenvals, KA=2, KB=2."  + "\n"  + " 12=Small, evenly spaced eigenvals.  "  + " 19=Evenly spaced eigenvals, KA=3, KB=1."  + "\n"  + " 13=Matrix with random O(1) entries. "  + " 20=Evenly spaced eigenvals, KA=3, KB=2."  + "\n"  + " 14=Matrix with large random entries."  + " 21=Evenly spaced eigenvals, KA=3, KB=3." );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Tests performed:   "  + "\n"  + "( For each pair (A,B), where A is of the given type "  + "\n"  + " and B is a random well-conditioned matrix. D is "  + "\n"  + " diagonal, and Z is unitary. )"  + "\n"  + " 1 = ZHEGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 2 = ZHPGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 3 = ZHBGV, with ITYPE=1 and UPLO=\'U\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 4 = ZHEGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 5 = ZHPGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 6 = ZHBGV, with ITYPE=1 and UPLO=\'L\':"  + "  | A Z - B Z D | / ( |A| |Z| n ulp )     " );
System.out.println(" 7 = ZHEGV, with ITYPE=2 and UPLO=\'U\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 8 = ZHPGV, with ITYPE=2 and UPLO=\'U\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + " 9 = ZHPGV, with ITYPE=2 and UPLO=\'L\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "10 = ZHPGV, with ITYPE=2 and UPLO=\'L\':"  + "  | A B Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "11 = ZHEGV, with ITYPE=3 and UPLO=\'U\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "12 = ZHPGV, with ITYPE=3 and UPLO=\'U\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "13 = ZHEGV, with ITYPE=3 and UPLO=\'L\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     "  + "\n"  + "14 = ZHPGV, with ITYPE=3 and UPLO=\'L\':"  + "  | B A Z - Z D | / ( |A| |Z| n ulp )     " );
// *
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"BD",0,2))  {
    // *
if (sord)  {
    // *
// *           Real Singular Value Decomposition:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Real Singular Value Decomposition" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKBD for details):"  + "\n"  + " Diagonal matrices:"  + "\n"  + "   1: Zero"  + "                            " + " 5: Clustered entries"  + "\n"  + "   2: Identity"  + "                        " + " 6: Large, evenly spaced entries"  + "\n"  + "   3: Evenly spaced entries"  + "           " + " 7: Small, evenly spaced entries"  + "\n"  + "   4: Geometrically spaced entries"  + "\n"  + " General matrices:"  + "\n"  + "   8: Evenly spaced sing. vals."  + "       " + "12: Small, evenly spaced sing vals"  + "\n"  + "   9: Geometrically spaced sing vals  "  + "13: Random, O(1) entries"  + "\n"  + "  10: Clustered sing. vals."  + "           " + "14: Random, scaled near overflow"  + "\n"  + "  11: Large, evenly spaced sing vals  "  + "15: Random, scaled near underflow" );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Test ratios:  "  + "(B: bidiagonal, S: diagonal, Q, P, U, and V: "  + ("orthogonal") + " "  + "\n"  + "                " + "X: m x nrhs, Y = Q\' X, and Z = U\' Y)"  + "\n"  + "   1: norm( A - Q B P\' ) / ( norm(A) max(m,n) ulp )"  + "\n"  + "   2: norm( I - Q\' Q )   / ( m ulp )"  + "\n"  + "   3: norm( I - P\' P )   / ( n ulp )"  + "\n"  + "   4: norm( B - U S V\' ) / ( norm(B) min(m,n) ulp )"  + "\n"  + "   5: norm( Y - U Z )    / ( norm(Z) max(min(m,n),k) ulp )"  + "\n"  + "   6: norm( I - U\' U )   / ( min(m,n) ulp )"  + "\n"  + "   7: norm( I - V\' V )   / ( min(m,n) ulp )" );
System.out.println("   8: Test ordering of S  (0 if nondecreasing, 1/ulp "  + " otherwise)"  + "\n"  + "   9: norm( S - S2 )     / ( norm(S) ulp ),"  + " where S2 is computed"  + "\n"  + "                                            " + "without computing U and V\'"  + "\n"  + "  10: Sturm sequence test "  + "(0 if sing. vals of B within THRESH of S)"  + "\n"  + "  11: norm( A - (QU) S (V\' P\') ) / "  + "( norm(A) max(m,n) ulp )"  + "\n"  + "  12: norm( X - (QU) Z )         / ( |X| max(M,k) ulp )"  + "\n"  + "  13: norm( I - (QU)\'(QU) )      / ( M ulp )"  + "\n"  + "  14: norm( I - (V\' P\') (P V) )  / ( N ulp )" );
}              // Close if()
else  {
  // *
// *           Complex Singular Value Decomposition:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Complex Singular Value Decomposition" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKBD for details):"  + "\n"  + " Diagonal matrices:"  + "\n"  + "   1: Zero"  + "                            " + " 5: Clustered entries"  + "\n"  + "   2: Identity"  + "                        " + " 6: Large, evenly spaced entries"  + "\n"  + "   3: Evenly spaced entries"  + "           " + " 7: Small, evenly spaced entries"  + "\n"  + "   4: Geometrically spaced entries"  + "\n"  + " General matrices:"  + "\n"  + "   8: Evenly spaced sing. vals."  + "       " + "12: Small, evenly spaced sing vals"  + "\n"  + "   9: Geometrically spaced sing vals  "  + "13: Random, O(1) entries"  + "\n"  + "  10: Clustered sing. vals."  + "           " + "14: Random, scaled near overflow"  + "\n"  + "  11: Large, evenly spaced sing vals  "  + "15: Random, scaled near underflow" );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Test ratios:  "  + "(B: bidiagonal, S: diagonal, Q, P, U, and V: "  + ("unitary   ") + " "  + "\n"  + "                " + "X: m x nrhs, Y = Q\' X, and Z = U\' Y)"  + "\n"  + "   1: norm( A - Q B P\' ) / ( norm(A) max(m,n) ulp )"  + "\n"  + "   2: norm( I - Q\' Q )   / ( m ulp )"  + "\n"  + "   3: norm( I - P\' P )   / ( n ulp )"  + "\n"  + "   4: norm( B - U S V\' ) / ( norm(B) min(m,n) ulp )"  + "\n"  + "   5: norm( Y - U Z )    / ( norm(Z) max(min(m,n),k) ulp )"  + "\n"  + "   6: norm( I - U\' U )   / ( min(m,n) ulp )"  + "\n"  + "   7: norm( I - V\' V )   / ( min(m,n) ulp )" );
System.out.println("   8: Test ordering of S  (0 if nondecreasing, 1/ulp "  + " otherwise)"  + "\n"  + "   9: norm( S - S2 )     / ( norm(S) ulp ),"  + " where S2 is computed"  + "\n"  + "                                            " + "without computing U and V\'"  + "\n"  + "  10: Sturm sequence test "  + "(0 if sing. vals of B within THRESH of S)"  + "\n"  + "  11: norm( A - (QU) S (V\' P\') ) / "  + "( norm(A) max(m,n) ulp )"  + "\n"  + "  12: norm( X - (QU) Z )         / ( |X| max(M,k) ulp )"  + "\n"  + "  13: norm( I - (QU)\'(QU) )      / ( M ulp )"  + "\n"  + "  14: norm( I - (V\' P\') (P V) )  / ( N ulp )" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"BB",0,2))  {
    // *
if (sord)  {
    // *
// *           Real General Band reduction to bidiagonal form:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Real Band reduc. to bidiagonal form" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKBB for details):"  + "\n"  + " Diagonal matrices:"  + "\n"  + "   1: Zero"  + "                            " + " 5: Clustered entries"  + "\n"  + "   2: Identity"  + "                        " + " 6: Large, evenly spaced entries"  + "\n"  + "   3: Evenly spaced entries"  + "           " + " 7: Small, evenly spaced entries"  + "\n"  + "   4: Geometrically spaced entries"  + "\n"  + " General matrices:"  + "\n"  + "   8: Evenly spaced sing. vals."  + "       " + "12: Small, evenly spaced sing vals"  + "\n"  + "   9: Geometrically spaced sing vals  "  + "13: Random, O(1) entries"  + "\n"  + "  10: Clustered sing. vals."  + "           " + "14: Random, scaled near overflow"  + "\n"  + "  11: Large, evenly spaced sing vals  "  + "15: Random, scaled near underflow" );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Test ratios:  "  + "(B: upper bidiagonal, Q and P: "  + ("orthogonal") + " "  + "\n"  + "                " + "C: m x nrhs, PT = P\', Y = Q\' C)"  + "\n"  + " 1: norm( A - Q B PT ) / ( norm(A) max(m,n) ulp )"  + "\n"  + " 2: norm( I - Q\' Q )   / ( m ulp )"  + "\n"  + " 3: norm( I - PT PT\' )   / ( n ulp )"  + "\n"  + " 4: norm( Y - Q\' C )   / ( norm(Y) max(m,nrhs) ulp )" );
}              // Close if()
else  {
  // *
// *           Complex Band reduction to bidiagonal form:
// *
System.out.println("\n"  + " " + (path) + " "  + " -- Complex Band reduc. to bidiagonal form" );
// *
// *           Matrix types
// *
System.out.println(" Matrix types (see xCHKBB for details):"  + "\n"  + " Diagonal matrices:"  + "\n"  + "   1: Zero"  + "                            " + " 5: Clustered entries"  + "\n"  + "   2: Identity"  + "                        " + " 6: Large, evenly spaced entries"  + "\n"  + "   3: Evenly spaced entries"  + "           " + " 7: Small, evenly spaced entries"  + "\n"  + "   4: Geometrically spaced entries"  + "\n"  + " General matrices:"  + "\n"  + "   8: Evenly spaced sing. vals."  + "       " + "12: Small, evenly spaced sing vals"  + "\n"  + "   9: Geometrically spaced sing vals  "  + "13: Random, O(1) entries"  + "\n"  + "  10: Clustered sing. vals."  + "           " + "14: Random, scaled near overflow"  + "\n"  + "  11: Large, evenly spaced sing vals  "  + "15: Random, scaled near underflow" );
// *
// *           Tests performed
// *
System.out.println("\n"  + " Test ratios:  "  + "(B: upper bidiagonal, Q and P: "  + ("unitary   ") + " "  + "\n"  + "                " + "C: m x nrhs, PT = P\', Y = Q\' C)"  + "\n"  + " 1: norm( A - Q B PT ) / ( norm(A) max(m,n) ulp )"  + "\n"  + " 2: norm( I - Q\' Q )   / ( m ulp )"  + "\n"  + " 3: norm( I - PT PT\' )   / ( n ulp )"  + "\n"  + " 4: norm( Y - Q\' C )   / ( norm(Y) max(m,nrhs) ulp )" );
}              //  Close else.
// *
}              // Close else if()
else  {
  // *
System.out.println(" " + (path) + " "  + ":  no header available" );
Dummy.go_to("Dlahd2",999999);
}              //  Close else.
// *
Dummy.go_to("Dlahd2",999999);
// *
// *
// *
// *
// *     Symmetric/Hermitian eigenproblem
// *
// *
// *
// *
// *     Symmetric/Hermitian Generalized eigenproblem
// *
// *
// *
// *     Singular Value Decomposition
// *
// *
// *
// *     Band reduction to bidiagonal form
// *
// *
// *
// *     End of DLAHD2
// *
Dummy.label("Dlahd2",999999);
return;
   }
} // End class.
