/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlarfy {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARFY applies an elementary reflector, or Householder matrix, H,
// *  to an n x n symmetric matrix C, from both the left and the right.
// *
// *  H is represented in the form
// *
// *     H = I - tau * v * v'
// *
// *  where  tau  is a scalar and  v  is a vector.
// *
// *  If  tau  is  zero, then  H  is taken to be the unit matrix.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix C is stored.
// *          = 'U':  Upper triangle
// *          = 'L':  Lower triangle
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix C.  N >= 0.
// *
// *  V       (input) DOUBLE PRECISION array, dimension
// *                  (1 + (N-1)*abs(INCV))
// *          The vector v as described above.
// *
// *  INCV    (input) INTEGER
// *          The increment between successive elements of v.  INCV must
// *          not be zero.
// *
// *  TAU     (input) DOUBLE PRECISION
// *          The value tau as described above.
// *
// *  C       (input/output) DOUBLE PRECISION array, dimension (LDC, N)
// *          On entry, the matrix C.
// *          On exit, C is overwritten by H * C * H'.
// *
// *  LDC     (input) INTEGER
// *          The leading dimension of the array C.  LDC >= max( 1, N ).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static double half= 0.5e+0;
// *     ..
// *     .. Local Scalars ..
static double alpha= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlarfy (String uplo,
int n,
double [] v, int _v_offset,
int incv,
double tau,
double [] c, int _c_offset,
int Ldc,
double [] work, int _work_offset)  {

if (tau == zero)  
    Dummy.go_to("Dlarfy",999999);
// *
// *     Form  w:= C * v
// *
Dsymv.dsymv(uplo,n,one,c,_c_offset,Ldc,v,_v_offset,incv,zero,work,_work_offset,1);
// *
alpha = -half*tau*Ddot.ddot(n,work,_work_offset,1,v,_v_offset,incv);
Daxpy.daxpy(n,alpha,v,_v_offset,incv,work,_work_offset,1);
// *
// *     C := C - v * w' - w * v'
// *
Dsyr2.dsyr2(uplo,n,-tau,v,_v_offset,incv,work,_work_offset,1,c,_c_offset,Ldc);
// *
Dummy.go_to("Dlarfy",999999);
// *
// *     End of DLARFY
// *
Dummy.label("Dlarfy",999999);
return;
   }
} // End class.
