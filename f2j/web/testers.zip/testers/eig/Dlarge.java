/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlarge {

// *
// *  -- LAPACK auxiliary test routine (version 2.0)
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARGE pre- and post-multiplies a real general n by n matrix A
// *  with a random orthogonal matrix: A = U*D*U'.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          On entry, the original n by n matrix A.
// *          On exit, A is overwritten by U*A*U' for some random
// *          orthogonal matrix U.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= N.
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry, the seed of the random number generator; the array
// *          elements must be between 0 and 4095, and ISEED(4) must be
// *          odd.
// *          On exit, the seed is updated.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double tau= 0.0;
static double wa= 0.0;
static double wb= 0.0;
static double wn= 0.0;
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input arguments
// *

public static void dlarge (int n,
double [] a, int _a_offset,
int lda,
int [] iseed, int _iseed_offset,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (lda < Math.max(1, n) )  {
    info.val = -3;
}              // Close else if()
if (info.val < 0)  {
    Xerbla.xerbla("DLARGE",-info.val);
Dummy.go_to("Dlarge",999999);
}              // Close if()
// *
// *     pre- and post-multiply A by random orthogonal matrix
// *
{
int _i_inc = -1;
forloop10:
for (i = n; (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
// *
// *        generate random reflection
// *
Dlarnv.dlarnv(3,iseed,_iseed_offset,n-i+1,work,_work_offset);
wn = Dnrm2.dnrm2(n-i+1,work,_work_offset,1);
wa = ((work[(1)- 1+ _work_offset]) >= 0 ? Math.abs(wn) : -Math.abs(wn));
if (wn == zero)  {
    tau = zero;
}              // Close if()
else  {
  wb = work[(1)- 1+ _work_offset]+wa;
Dscal.dscal(n-i,one/wb,work,(2)- 1+ _work_offset,1);
work[(1)- 1+ _work_offset] = one;
tau = wb/wa;
}              //  Close else.
// *
// *        multiply A(i:n,1:n) by random reflection from the left
// *
Dgemv.dgemv("Transpose",n-i+1,n,one,a,(i)- 1+(1- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(n+1)- 1+ _work_offset,1);
Dger.dger(n-i+1,n,-tau,work,_work_offset,1,work,(n+1)- 1+ _work_offset,1,a,(i)- 1+(1- 1)*lda+ _a_offset,lda);
// *
// *        multiply A(1:n,i:n) by random reflection from the right
// *
Dgemv.dgemv("No transpose",n,n-i+1,one,a,(1)- 1+(i- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(n+1)- 1+ _work_offset,1);
Dger.dger(n,n-i+1,-tau,work,(n+1)- 1+ _work_offset,1,work,_work_offset,1,a,(1)- 1+(i- 1)*lda+ _a_offset,lda);
Dummy.label("Dlarge",10);
}              //  Close for() loop. 
}
Dummy.go_to("Dlarge",999999);
// *
// *     End of DLARGE
// *
Dummy.label("Dlarge",999999);
return;
   }
} // End class.
