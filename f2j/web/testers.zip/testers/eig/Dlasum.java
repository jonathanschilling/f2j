/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlasum {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLASUM prints a summary of the results from one of the test routines.
// *
// *  =====================================================================
// *
// *     .. Executable Statements ..
// *

public static void dlasum (String type,
int iounit,
int ie,
int nrun)  {

if (ie > 0)  {
    System.out.println(" " + (type) + " "  + (": ") + " "  + (ie) + " "  + (" out of ") + " "  + (nrun) + " "  + (" tests failed to pass the threshold") + " " );
}              // Close if()
else  {
  System.out.println("\n"  + " " + ("All tests for ") + " "  + (type) + " "  + (" passed the threshold (") + " "  + (nrun) + " "  + (" tests run)") + " " );
}              //  Close else.
Dummy.go_to("Dlasum",999999);
// *
// *     End of DLASUM
// *
Dummy.label("Dlasum",999999);
return;
   }
} // End class.
