/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlatb9 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATB9 sets parameters for the matrix generator based on the type of
// *  matrix to be generated.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name.
// *
// *  IMAT    (input) INTEGER
// *          An integer key describing which matrix to generate for this
// *          path.
// *
// *  M       (input) INTEGER
// *          The number of rows in the matrix to be generated.
// *
// *  N       (input) INTEGER
// *          The number of columns in the matrix to be generated.
// *
// *  TYPE    (output) CHARACTER*1
// *          The type of the matrix to be generated:
// *          = 'S':  symmetric matrix;
// *          = 'P':  symmetric positive (semi)definite matrix;
// *          = 'N':  nonsymmetric matrix.
// *
// *  KL      (output) INTEGER
// *          The lower band width of the matrix to be generated.
// *
// *  KU      (output) INTEGER
// *          The upper band width of the matrix to be generated.
// *
// *  ANORM   (output) DOUBLE PRECISION
// *          The desired norm of the matrix to be generated.  The diagonal
// *          matrix of singular values or eigenvalues is scaled by this
// *          value.
// *
// *  MODE    (output) INTEGER
// *          A key indicating how to choose the vector of eigenvalues.
// *
// *  CNDNUM  (output) DOUBLE PRECISION
// *          The desired condition number.
// *
// *  DIST    (output) CHARACTER*1
// *          The type of distribution to be used by the random number
// *          generator.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double shrink= 0.25e0;
static double tenth= 0.1e+0;
static double one= 1.0e+0;
static double ten= 1.0e+1;
// *     ..
// *     .. Local Scalars ..
static double badc1= 0.0;
static double badc2= 0.0;
static double eps= 0.0;
static doubleW large= new doubleW(0.0);
static doubleW small= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *
// *     Set some constants for use in the subroutine.
// *

public static void dlatb9 (String path,
int imat,
int m,
int p,
int n,
StringW type,
intW kla,
intW kua,
intW klb,
intW kub,
doubleW anorm,
doubleW bnorm,
intW modea,
intW modeb,
doubleW cndnma,
doubleW cndnmb,
StringW dista,
StringW distb)  {

if (first)  {
    first = false;
eps = Dlamch.dlamch("Precision");
badc2 = tenth/eps;
badc1 = Math.sqrt(badc2);
small.val = Dlamch.dlamch("Safe minimum");
large.val = one/small.val;
// *
// *        If it looks like we're on a Cray, take the square root of
// *        SMALL and LARGE to avoid overflow and underflow problems.
// *
Dlabad.dlabad(small,large);
small.val = shrink*(small.val/eps);
large.val = one/small.val;
}              // Close if()
// *
// *     Set some parameters we don't plan to change.
// *
type.val = "N";
dista.val = "S";
distb.val = "S";
modea.val = 3;
modeb.val = 4;
// *
// *     Set the lower and upper bandwidths.
// *
if (path.regionMatches(true,0,"GRQ",0,3) || path.regionMatches(true,0,"LSE",0,3) || path.regionMatches(true,0,"GSV",0,3))  {
    // *
// *        A: M by N, B: P by N
// *
if (imat == 1)  {
    // *
// *           A: diagonal, B: upper triangular
// *
kla.val = 0;
kua.val = 0;
klb.val = 0;
kub.val = (int)(Math.max(n-1, 0) );
// *
}              // Close if()
else if (imat == 2)  {
    // *
// *           A: upper triangular, B: upper triangular
// *
kla.val = 0;
kua.val = (int)(Math.max(n-1, 0) );
klb.val = 0;
kub.val = (int)(Math.max(n-1, 0) );
// *
}              // Close else if()
else if (imat == 3)  {
    // *
// *           A: lower triangular, B: upper triangular
// *
kla.val = (int)(Math.max(m-1, 0) );
kua.val = 0;
klb.val = 0;
kub.val = (int)(Math.max(n-1, 0) );
// *
}              // Close else if()
else  {
  // *
// *           A: general dense, B: general dense
// *
kla.val = (int)(Math.max(m-1, 0) );
kua.val = (int)(Math.max(n-1, 0) );
klb.val = (int)(Math.max(p-1, 0) );
kub.val = (int)(Math.max(n-1, 0) );
// *
}              //  Close else.
// *
}              // Close if()
else if (path.regionMatches(true,0,"GQR",0,3) || path.regionMatches(true,0,"GLM",0,3))  {
    // *
// *        A: N by M, B: N by P
// *
if (imat == 1)  {
    // *
// *           A: diagonal, B: lower triangular
// *
kla.val = 0;
kua.val = 0;
klb.val = (int)(Math.max(n-1, 0) );
kub.val = 0;
}              // Close if()
else if (imat == 2)  {
    // *
// *           A: lower triangular, B: diagonal
// *
kla.val = (int)(Math.max(n-1, 0) );
kua.val = 0;
klb.val = 0;
kub.val = 0;
// *
}              // Close else if()
else if (imat == 3)  {
    // *
// *           A: lower triangular, B: upper triangular
// *
kla.val = (int)(Math.max(n-1, 0) );
kua.val = 0;
klb.val = 0;
kub.val = (int)(Math.max(p-1, 0) );
// *
}              // Close else if()
else  {
  // *
// *           A: general dense, B: general dense
// *
kla.val = (int)(Math.max(n-1, 0) );
kua.val = (int)(Math.max(m-1, 0) );
klb.val = (int)(Math.max(n-1, 0) );
kub.val = (int)(Math.max(p-1, 0) );
}              //  Close else.
// *
}              // Close else if()
// *
// *     Set the condition number and norm.
// *
cndnma.val = ten*ten;
cndnmb.val = ten;
if (path.regionMatches(true,0,"GQR",0,3) || path.regionMatches(true,0,"GRQ",0,3) || path.regionMatches(true,0,"GSV",0,3))  {
    if (imat == 5)  {
    cndnma.val = badc1;
cndnmb.val = badc1;
}              // Close if()
else if (imat == 6)  {
    cndnma.val = badc2;
cndnmb.val = badc2;
}              // Close else if()
else if (imat == 7)  {
    cndnma.val = badc1;
cndnmb.val = badc2;
}              // Close else if()
else if (imat == 8)  {
    cndnma.val = badc2;
cndnmb.val = badc1;
}              // Close else if()
}              // Close if()
// *
anorm.val = ten;
bnorm.val = ten*ten*ten;
if (path.regionMatches(true,0,"GQR",0,3) || path.regionMatches(true,0,"GRQ",0,3))  {
    if (imat == 7)  {
    anorm.val = small.val;
bnorm.val = large.val;
}              // Close if()
else if (imat == 8)  {
    anorm.val = large.val;
bnorm.val = small.val;
}              // Close else if()
}              // Close if()
// *
if (n <= 1)  {
    cndnma.val = one;
cndnmb.val = one;
}              // Close if()
// *
Dummy.go_to("Dlatb9",999999);
// *
// *     End of DLATB9
// *
Dummy.label("Dlatb9",999999);
return;
   }
} // End class.
