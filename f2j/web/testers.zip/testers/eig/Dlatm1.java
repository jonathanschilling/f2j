/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlatm1 {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DLATM1 computes the entries of D(1..N) as specified by
// *     MODE, COND and IRSIGN. IDIST and ISEED determine the generation
// *     of random numbers. DLATM1 is called by SLATMR to generate
// *     random test matrices for LAPACK programs.
// *
// *  Arguments
// *  =========
// *
// *  MODE   - INTEGER
// *           On entry describes how D is to be computed:
// *           MODE = 0 means do not change D.
// *           MODE = 1 sets D(1)=1 and D(2:N)=1.0/COND
// *           MODE = 2 sets D(1:N-1)=1 and D(N)=1.0/COND
// *           MODE = 3 sets D(I)=COND**(-(I-1)/(N-1))
// *           MODE = 4 sets D(i)=1 - (i-1)/(N-1)*(1 - 1/COND)
// *           MODE = 5 sets D to random numbers in the range
// *                    ( 1/COND , 1 ) such that their logarithms
// *                    are uniformly distributed.
// *           MODE = 6 set D to random numbers from same distribution
// *                    as the rest of the matrix.
// *           MODE < 0 has the same meaning as ABS(MODE), except that
// *              the order of the elements of D is reversed.
// *           Thus if MODE is positive, D has entries ranging from
// *              1 to 1/COND, if negative, from 1/COND to 1,
// *           Not modified.
// *
// *  COND   - DOUBLE PRECISION
// *           On entry, used as described under MODE above.
// *           If used, it must be >= 1. Not modified.
// *
// *  IRSIGN - INTEGER
// *           On entry, if MODE neither -6, 0 nor 6, determines sign of
// *           entries of D
// *           0 => leave entries of D unchanged
// *           1 => multiply each entry of D by 1 or -1 with probability .5
// *
// *  IDIST  - CHARACTER*1
// *           On entry, IDIST specifies the type of distribution to be
// *           used to generate a random matrix .
// *           1 => UNIFORM( 0, 1 )
// *           2 => UNIFORM( -1, 1 )
// *           3 => NORMAL( 0, 1 )
// *           Not modified.
// *
// *  ISEED  - INTEGER array, dimension ( 4 )
// *           On entry ISEED specifies the seed of the random number
// *           generator. The random number generator uses a
// *           linear congruential sequence limited to small
// *           integers, and so should produce machine independent
// *           random numbers. The values of ISEED are changed on
// *           exit, and can be used in the next call to DLATM1
// *           to continue the same random number sequence.
// *           Changed on exit.
// *
// *  D      - DOUBLE PRECISION array, dimension ( MIN( M , N ) )
// *           Array to be computed according to MODE, COND and IRSIGN.
// *           May be changed on exit if MODE is nonzero.
// *
// *  N      - INTEGER
// *           Number of entries of D. Not modified.
// *
// *  INFO   - INTEGER
// *            0  => normal termination
// *           -1  => if MODE not in range -6 to 6
// *           -2  => if MODE neither -6, 0 nor 6, and
// *                  IRSIGN neither 0 nor 1
// *           -3  => if MODE neither -6, 0 nor 6 and COND less than 1
// *           -4  => if MODE equals 6 or -6 and IDIST not in range 1 to 3
// *           -7  => if N negative
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double half= 0.5e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double alpha= 0.0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Decode and Test the input parameters. Initialize flags & seed.
// *

public static void dlatm1 (int mode,
double cond,
int irsign,
int idist,
int [] iseed, int _iseed_offset,
double [] d, int _d_offset,
int n,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlatm1",999999);
// *
// *     Set INFO if an error
// *
if (mode < -6 || mode > 6)  {
    info.val = -1;
}              // Close if()
else if ((mode != -6 && mode != 0 && mode != 6) && (irsign != 0 && irsign != 1))  {
    info.val = -2;
}              // Close else if()
else if ((mode != -6 && mode != 0 && mode != 6) && cond < one)  {
    info.val = -3;
}              // Close else if()
else if ((mode == 6 || mode == -6) && (idist < 1 || idist > 3))  {
    info.val = -4;
}              // Close else if()
else if (n < 0)  {
    info.val = -7;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DLATM1",-info.val);
Dummy.go_to("Dlatm1",999999);
}              // Close if()
// *
// *     Compute D according to COND and MODE
// *
if (mode != 0)  {
    if (Math.abs(mode) == 1) 
  Dummy.go_to("Dlatm1",10);
else if (Math.abs(mode) == 2) 
  Dummy.go_to("Dlatm1",30);
else if (Math.abs(mode) == 3) 
  Dummy.go_to("Dlatm1",50);
else if (Math.abs(mode) == 4) 
  Dummy.go_to("Dlatm1",70);
else if (Math.abs(mode) == 5) 
  Dummy.go_to("Dlatm1",90);
else if (Math.abs(mode) == 6) 
  Dummy.go_to("Dlatm1",110);
// *
// *        One large D value:
// *
label10:
   Dummy.label("Dlatm1",10);
{
forloop20:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = one/cond;
Dummy.label("Dlatm1",20);
}              //  Close for() loop. 
}
d[(1)- 1+ _d_offset] = one;
Dummy.go_to("Dlatm1",120);
// *
// *        One small D value:
// *
label30:
   Dummy.label("Dlatm1",30);
{
forloop40:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = one;
Dummy.label("Dlatm1",40);
}              //  Close for() loop. 
}
d[(n)- 1+ _d_offset] = one/cond;
Dummy.go_to("Dlatm1",120);
// *
// *        Exponentially distributed D values:
// *
label50:
   Dummy.label("Dlatm1",50);
d[(1)- 1+ _d_offset] = one;
if (n > 1)  {
    alpha = Math.pow(cond, (-one/(double)(n-1)));
{
forloop60:
for (i = 2; i <= n; i++) {
d[(i)- 1+ _d_offset] = Math.pow(alpha, (i-1));
Dummy.label("Dlatm1",60);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dlatm1",120);
// *
// *        Arithmetically distributed D values:
// *
label70:
   Dummy.label("Dlatm1",70);
d[(1)- 1+ _d_offset] = one;
if (n > 1)  {
    temp = one/cond;
alpha = (one-temp)/(double)(n-1);
{
forloop80:
for (i = 2; i <= n; i++) {
d[(i)- 1+ _d_offset] = (double)(n-i)*alpha+temp;
Dummy.label("Dlatm1",80);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dlatm1",120);
// *
// *        Randomly distributed D values on ( 1/COND , 1):
// *
label90:
   Dummy.label("Dlatm1",90);
alpha = Math.log(one/cond);
{
forloop100:
for (i = 1; i <= n; i++) {
d[(i)- 1+ _d_offset] = Math.exp(alpha*Dlaran.dlaran(iseed,_iseed_offset));
Dummy.label("Dlatm1",100);
}              //  Close for() loop. 
}
Dummy.go_to("Dlatm1",120);
// *
// *        Randomly distributed D values from IDIST
// *
label110:
   Dummy.label("Dlatm1",110);
Dlarnv.dlarnv(idist,iseed,_iseed_offset,n,d,_d_offset);
// *
label120:
   Dummy.label("Dlatm1",120);
// *
// *        If MODE neither -6 nor 0 nor 6, and IRSIGN = 1, assign
// *        random signs to D
// *
if ((mode != -6 && mode != 0 && mode != 6) && irsign == 1)  {
    {
forloop130:
for (i = 1; i <= n; i++) {
temp = Dlaran.dlaran(iseed,_iseed_offset);
if (temp > half)  
    d[(i)- 1+ _d_offset] = -d[(i)- 1+ _d_offset];
Dummy.label("Dlatm1",130);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Reverse if MODE < 0
// *
if (mode < 0)  {
    {
forloop140:
for (i = 1; i <= n/2; i++) {
temp = d[(i)- 1+ _d_offset];
d[(i)- 1+ _d_offset] = d[(n+1-i)- 1+ _d_offset];
d[(n+1-i)- 1+ _d_offset] = temp;
Dummy.label("Dlatm1",140);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
// *
Dummy.go_to("Dlatm1",999999);
// *
// *     End of DLATM1
// *
Dummy.label("Dlatm1",999999);
return;
   }
} // End class.
