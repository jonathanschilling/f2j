/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlatm4 {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATM4 generates basic square matrices, which may later be
// *  multiplied by others in order to produce test matrices.  It is
// *  intended mainly to be used to test the generalized eigenvalue
// *  routines.
// *
// *  It first generates the diagonal and (possibly) subdiagonal,
// *  according to the value of ITYPE, NZ1, NZ2, ISIGN, AMAGN, and RCOND.
// *  It then fills in the upper triangle with random numbers, if TRIANG is
// *  non-zero.
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   (input) INTEGER
// *          The "type" of matrix on the diagonal and sub-diagonal.
// *          If ITYPE < 0, then type abs(ITYPE) is generated and then
// *             swapped end for end (A(I,J) := A'(N-J,N-I).)  See also
// *             the description of AMAGN and ISIGN.
// *
// *          Special types:
// *          = 0:  the zero matrix.
// *          = 1:  the identity.
// *          = 2:  a transposed Jordan block.
// *          = 3:  If N is odd, then a k+1 x k+1 transposed Jordan block
// *                followed by a k x k identity block, where k=(N-1)/2.
// *                If N is even, then k=(N-2)/2, and a zero diagonal entry
// *                is tacked onto the end.
// *
// *          Diagonal types.  The diagonal consists of NZ1 zeros, then
// *             k=N-NZ1-NZ2 nonzeros.  The subdiagonal is zero.  ITYPE
// *             specifies the nonzero diagonal entries as follows:
// *          = 4:  1, ..., k
// *          = 5:  1, RCOND, ..., RCOND
// *          = 6:  1, ..., 1, RCOND
// *          = 7:  1, a, a^2, ..., a^(k-1)=RCOND
// *          = 8:  1, 1-d, 1-2*d, ..., 1-(k-1)*d=RCOND
// *          = 9:  random numbers chosen from (RCOND,1)
// *          = 10: random numbers with distribution IDIST (see DLARND.)
// *
// *  N       (input) INTEGER
// *          The order of the matrix.
// *
// *  NZ1     (input) INTEGER
// *          If abs(ITYPE) > 3, then the first NZ1 diagonal entries will
// *          be zero.
// *
// *  NZ2     (input) INTEGER
// *          If abs(ITYPE) > 3, then the last NZ2 diagonal entries will
// *          be zero.
// *
// *  ISIGN   (input) INTEGER
// *          = 0: The sign of the diagonal and subdiagonal entries will
// *               be left unchanged.
// *          = 1: The diagonal and subdiagonal entries will have their
// *               sign changed at random.
// *          = 2: If ITYPE is 2 or 3, then the same as ISIGN=1.
// *               Otherwise, with probability 0.5, odd-even pairs of
// *               diagonal entries A(2*j-1,2*j-1), A(2*j,2*j) will be
// *               converted to a 2x2 block by pre- and post-multiplying
// *               by distinct random orthogonal rotations.  The remaining
// *               diagonal entries will have their sign changed at random.
// *
// *  AMAGN   (input) DOUBLE PRECISION
// *          The diagonal and subdiagonal entries will be multiplied by
// *          AMAGN.
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          If abs(ITYPE) > 4, then the smallest diagonal entry will be
// *          entry will be RCOND.  RCOND must be between 0 and 1.
// *
// *  TRIANG  (input) DOUBLE PRECISION
// *          The entries above the diagonal will be random numbers with
// *          magnitude bounded by TRIANG (i.e., random numbers multiplied
// *          by TRIANG.)
// *
// *  IDIST   (input) INTEGER
// *          Specifies the type of distribution to be used to generate a
// *          random matrix.
// *          = 1:  UNIFORM( 0, 1 )
// *          = 2:  UNIFORM( -1, 1 )
// *          = 3:  NORMAL ( 0, 1 )
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          On entry ISEED specifies the seed of the random number
// *          generator.  The values of ISEED are changed on exit, and can
// *          be used in the next call to DLATM4 to continue the same
// *          random number sequence.
// *          Note: ISEED(4) should be odd, for the random number generator
// *          used at present.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (LDA, N)
// *          Array to be computed.
// *
// *  LDA     (input) INTEGER
// *          Leading dimension of A.  Must be at least 1 and at least N.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double half= one/two;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ioff= 0;
static int isdb= 0;
static int isde= 0;
static int jc= 0;
static int jd= 0;
static int jr= 0;
static int k= 0;
static int kbeg= 0;
static int kend= 0;
static int klen= 0;
static double alpha= 0.0;
static double cl= 0.0;
static double cr= 0.0;
static double safmin= 0.0;
static double sl= 0.0;
static double sr= 0.0;
static double sv1= 0.0;
static double sv2= 0.0;
static double temp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlatm4 (int itype,
int n,
int nz1,
int nz2,
int isign,
double amagn,
double rcond,
double triang,
int idist,
int [] iseed, int _iseed_offset,
double [] a, int _a_offset,
int lda)  {

if (n <= 0)  
    Dummy.go_to("Dlatm4",999999);
Dlaset.dlaset("Full",n,n,zero,zero,a,_a_offset,lda);
// *
// *     Insure a correct ISEED
// *
if ((iseed[(4)- 1+ _iseed_offset])%(2)  != 1)  
    iseed[(4)- 1+ _iseed_offset] = iseed[(4)- 1+ _iseed_offset]+1;
// *
// *     Compute diagonal and subdiagonal according to ITYPE, NZ1, NZ2,
// *     and RCOND
// *
if (itype != 0)  {
    if (Math.abs(itype) >= 4)  {
    kbeg = (int)(Math.max(1, Math.min(n, nz1+1) ) );
kend = (int)(Math.max(kbeg, Math.min(n, n-nz2) ) );
klen = kend+1-kbeg;
}              // Close if()
else  {
  kbeg = 1;
kend = n;
klen = n;
}              //  Close else.
isdb = 1;
isde = 0;
if (Math.abs(itype) == 1) 
  Dummy.go_to("Dlatm4",10);
else if (Math.abs(itype) == 2) 
  Dummy.go_to("Dlatm4",30);
else if (Math.abs(itype) == 3) 
  Dummy.go_to("Dlatm4",50);
else if (Math.abs(itype) == 4) 
  Dummy.go_to("Dlatm4",80);
else if (Math.abs(itype) == 5) 
  Dummy.go_to("Dlatm4",100);
else if (Math.abs(itype) == 6) 
  Dummy.go_to("Dlatm4",120);
else if (Math.abs(itype) == 7) 
  Dummy.go_to("Dlatm4",140);
else if (Math.abs(itype) == 8) 
  Dummy.go_to("Dlatm4",160);
else if (Math.abs(itype) == 9) 
  Dummy.go_to("Dlatm4",180);
else if (Math.abs(itype) == 10) 
  Dummy.go_to("Dlatm4",200);
// *
// *        abs(ITYPE) = 1: Identity
// *
label10:
   Dummy.label("Dlatm4",10);
{
forloop20:
for (jd = 1; jd <= n; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = one;
Dummy.label("Dlatm4",20);
}              //  Close for() loop. 
}
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 2: Transposed Jordan block
// *
label30:
   Dummy.label("Dlatm4",30);
{
forloop40:
for (jd = 1; jd <= n-1; jd++) {
a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = one;
Dummy.label("Dlatm4",40);
}              //  Close for() loop. 
}
isdb = 1;
isde = n-1;
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 3: Transposed Jordan block, followed by the
// *                        identity.
// *
label50:
   Dummy.label("Dlatm4",50);
k = (n-1)/2;
{
forloop60:
for (jd = 1; jd <= k; jd++) {
a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = one;
Dummy.label("Dlatm4",60);
}              //  Close for() loop. 
}
isdb = 1;
isde = k;
{
forloop70:
for (jd = k+2; jd <= 2*k+1; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = one;
Dummy.label("Dlatm4",70);
}              //  Close for() loop. 
}
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 4: 1,...,k
// *
label80:
   Dummy.label("Dlatm4",80);
{
forloop90:
for (jd = kbeg; jd <= kend; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = (double)(jd-nz1);
Dummy.label("Dlatm4",90);
}              //  Close for() loop. 
}
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 5: One large D value:
// *
label100:
   Dummy.label("Dlatm4",100);
{
forloop110:
for (jd = kbeg+1; jd <= kend; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = rcond;
Dummy.label("Dlatm4",110);
}              //  Close for() loop. 
}
a[(kbeg)- 1+(kbeg- 1)*lda+ _a_offset] = one;
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 6: One small D value:
// *
label120:
   Dummy.label("Dlatm4",120);
{
forloop130:
for (jd = kbeg; jd <= kend-1; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = one;
Dummy.label("Dlatm4",130);
}              //  Close for() loop. 
}
a[(kend)- 1+(kend- 1)*lda+ _a_offset] = rcond;
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 7: Exponentially distributed D values:
// *
label140:
   Dummy.label("Dlatm4",140);
a[(kbeg)- 1+(kbeg- 1)*lda+ _a_offset] = one;
if (klen > 1)  {
    alpha = Math.pow(rcond, (one/(double)(klen-1)));
{
forloop150:
for (i = 2; i <= klen; i++) {
a[(nz1+i)- 1+(nz1+i- 1)*lda+ _a_offset] = Math.pow(alpha, (double)(i-1));
Dummy.label("Dlatm4",150);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 8: Arithmetically distributed D values:
// *
label160:
   Dummy.label("Dlatm4",160);
a[(kbeg)- 1+(kbeg- 1)*lda+ _a_offset] = one;
if (klen > 1)  {
    alpha = (one-rcond)/(double)(klen-1);
{
forloop170:
for (i = 2; i <= klen; i++) {
a[(nz1+i)- 1+(nz1+i- 1)*lda+ _a_offset] = (double)(klen-i)*alpha+rcond;
Dummy.label("Dlatm4",170);
}              //  Close for() loop. 
}
}              // Close if()
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 9: Randomly distributed D values on ( RCOND, 1):
// *
label180:
   Dummy.label("Dlatm4",180);
alpha = Math.log(rcond);
{
forloop190:
for (jd = kbeg; jd <= kend; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = Math.exp(alpha*Dlaran.dlaran(iseed,_iseed_offset));
Dummy.label("Dlatm4",190);
}              //  Close for() loop. 
}
Dummy.go_to("Dlatm4",220);
// *
// *        abs(ITYPE) = 10: Randomly distributed D values from DIST
// *
label200:
   Dummy.label("Dlatm4",200);
{
forloop210:
for (jd = kbeg; jd <= kend; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = Dlarnd.dlarnd(idist,iseed,_iseed_offset);
Dummy.label("Dlatm4",210);
}              //  Close for() loop. 
}
// *
label220:
   Dummy.label("Dlatm4",220);
// *
// *        Scale by AMAGN
// *
{
forloop230:
for (jd = kbeg; jd <= kend; jd++) {
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = amagn*(double)(a[(jd)- 1+(jd- 1)*lda+ _a_offset]);
Dummy.label("Dlatm4",230);
}              //  Close for() loop. 
}
{
forloop240:
for (jd = isdb; jd <= isde; jd++) {
a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = amagn*(double)(a[(jd+1)- 1+(jd- 1)*lda+ _a_offset]);
Dummy.label("Dlatm4",240);
}              //  Close for() loop. 
}
// *
// *        If ISIGN = 1 or 2, assign random signs to diagonal and
// *        subdiagonal
// *
if (isign > 0)  {
    {
forloop250:
for (jd = kbeg; jd <= kend; jd++) {
if ((double)(a[(jd)- 1+(jd- 1)*lda+ _a_offset]) != zero)  {
    if (Dlaran.dlaran(iseed,_iseed_offset) > half)  
    a[(jd)- 1+(jd- 1)*lda+ _a_offset] = -a[(jd)- 1+(jd- 1)*lda+ _a_offset];
}              // Close if()
Dummy.label("Dlatm4",250);
}              //  Close for() loop. 
}
{
forloop260:
for (jd = isdb; jd <= isde; jd++) {
if ((double)(a[(jd+1)- 1+(jd- 1)*lda+ _a_offset]) != zero)  {
    if (Dlaran.dlaran(iseed,_iseed_offset) > half)  
    a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = -a[(jd+1)- 1+(jd- 1)*lda+ _a_offset];
}              // Close if()
Dummy.label("Dlatm4",260);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        Reverse if ITYPE < 0
// *
if (itype < 0)  {
    {
forloop270:
for (jd = kbeg; jd <= (kbeg+kend-1)/2; jd++) {
temp = a[(jd)- 1+(jd- 1)*lda+ _a_offset];
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = a[(kbeg+kend-jd)- 1+(kbeg+kend-jd- 1)*lda+ _a_offset];
a[(kbeg+kend-jd)- 1+(kbeg+kend-jd- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatm4",270);
}              //  Close for() loop. 
}
{
forloop280:
for (jd = 1; jd <= (n-1)/2; jd++) {
temp = a[(jd+1)- 1+(jd- 1)*lda+ _a_offset];
a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = a[(n+1-jd)- 1+(n-jd- 1)*lda+ _a_offset];
a[(n+1-jd)- 1+(n-jd- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatm4",280);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *        If ISIGN = 2, and no subdiagonals already, then apply
// *        random rotations to make 2x2 blocks.
// *
if (isign == 2 && itype != 2 && itype != 3)  {
    safmin = Dlamch.dlamch("S");
{
int _jd_inc = 2;
forloop290:
for (jd = kbeg; (_jd_inc < 0) ? jd >= kend-1 : jd <= kend-1; jd += _jd_inc) {
if (Dlaran.dlaran(iseed,_iseed_offset) > half)  {
    // *
// *                 Rotation on left.
// *
cl = two*Dlaran.dlaran(iseed,_iseed_offset)-one;
sl = two*Dlaran.dlaran(iseed,_iseed_offset)-one;
temp = one/Math.max(safmin, Math.sqrt(Math.pow(cl, 2)+Math.pow(sl, 2))) ;
cl = cl*temp;
sl = sl*temp;
// *
// *                 Rotation on right.
// *
cr = two*Dlaran.dlaran(iseed,_iseed_offset)-one;
sr = two*Dlaran.dlaran(iseed,_iseed_offset)-one;
temp = one/Math.max(safmin, Math.sqrt(Math.pow(cr, 2)+Math.pow(sr, 2))) ;
cr = cr*temp;
sr = sr*temp;
// *
// *                 Apply
// *
sv1 = a[(jd)- 1+(jd- 1)*lda+ _a_offset];
sv2 = a[(jd+1)- 1+(jd+1- 1)*lda+ _a_offset];
a[(jd)- 1+(jd- 1)*lda+ _a_offset] = cl*cr*sv1+sl*sr*sv2;
a[(jd+1)- 1+(jd- 1)*lda+ _a_offset] = -sl*cr*sv1+cl*sr*sv2;
a[(jd)- 1+(jd+1- 1)*lda+ _a_offset] = -cl*sr*sv1+sl*cr*sv2;
a[(jd+1)- 1+(jd+1- 1)*lda+ _a_offset] = sl*sr*sv1+cl*cr*sv2;
}              // Close if()
Dummy.label("Dlatm4",290);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
// *
// *     Fill in upper triangle (except for 2x2 blocks)
// *
if (triang != zero)  {
    if (isign != 2 || itype == 2 || itype == 3)  {
    ioff = 1;
}              // Close if()
else  {
  ioff = 2;
{
forloop300:
for (jr = 1; jr <= n-1; jr++) {
if (a[(jr+1)- 1+(jr- 1)*lda+ _a_offset] == zero)  
    a[(jr)- 1+(jr+1- 1)*lda+ _a_offset] = triang*Dlarnd.dlarnd(idist,iseed,_iseed_offset);
Dummy.label("Dlatm4",300);
}              //  Close for() loop. 
}
}              //  Close else.
// *
{
forloop320:
for (jc = 2; jc <= n; jc++) {
{
forloop310:
for (jr = 1; jr <= jc-ioff; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = triang*Dlarnd.dlarnd(idist,iseed,_iseed_offset);
Dummy.label("Dlatm4",310);
}              //  Close for() loop. 
}
Dummy.label("Dlatm4",320);
}              //  Close for() loop. 
}
}              // Close if()
// *
Dummy.go_to("Dlatm4",999999);
// *
// *     End of DLATM4
// *
Dummy.label("Dlatm4",999999);
return;
   }
} // End class.
