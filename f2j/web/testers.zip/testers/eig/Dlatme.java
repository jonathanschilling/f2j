/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlatme {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DLATME generates random non-symmetric square matrices with
// *     specified eigenvalues for testing LAPACK programs.
// *
// *     DLATME operates by applying the following sequence of
// *     operations:
// *
// *     1. Set the diagonal to D, where D may be input or
// *          computed according to MODE, COND, DMAX, and RSIGN
// *          as described below.
// *
// *     2. If complex conjugate pairs are desired (MODE=0 and EI(1)='R',
// *          or MODE=5), certain pairs of adjacent elements of D are
// *          interpreted as the real and complex parts of a complex
// *          conjugate pair; A thus becomes block diagonal, with 1x1
// *          and 2x2 blocks.
// *
// *     3. If UPPER='T', the upper triangle of A is set to random values
// *          out of distribution DIST.
// *
// *     4. If SIM='T', A is multiplied on the left by a random matrix
// *          X, whose singular values are specified by DS, MODES, and
// *          CONDS, and on the right by X inverse.
// *
// *     5. If KL < N-1, the lower bandwidth is reduced to KL using
// *          Householder transformations.  If KU < N-1, the upper
// *          bandwidth is reduced to KU.
// *
// *     6. If ANORM is not negative, the matrix is scaled to have
// *          maximum-element-norm ANORM.
// *
// *     (Note: since the matrix cannot be reduced beyond Hessenberg form,
// *      no packing options are available.)
// *
// *  Arguments
// *  =========
// *
// *  N      - INTEGER
// *           The number of columns (or rows) of A. Not modified.
// *
// *  DIST   - CHARACTER*1
// *           On entry, DIST specifies the type of distribution to be used
// *           to generate the random eigen-/singular values, and for the
// *           upper triangle (see UPPER).
// *           'U' => UNIFORM( 0, 1 )  ( 'U' for uniform )
// *           'S' => UNIFORM( -1, 1 ) ( 'S' for symmetric )
// *           'N' => NORMAL( 0, 1 )   ( 'N' for normal )
// *           Not modified.
// *
// *  ISEED  - INTEGER array, dimension ( 4 )
// *           On entry ISEED specifies the seed of the random number
// *           generator. They should lie between 0 and 4095 inclusive,
// *           and ISEED(4) should be odd. The random number generator
// *           uses a linear congruential sequence limited to small
// *           integers, and so should produce machine independent
// *           random numbers. The values of ISEED are changed on
// *           exit, and can be used in the next call to DLATME
// *           to continue the same random number sequence.
// *           Changed on exit.
// *
// *  D      - DOUBLE PRECISION array, dimension ( N )
// *           This array is used to specify the eigenvalues of A.  If
// *           MODE=0, then D is assumed to contain the eigenvalues (but
// *           see the description of EI), otherwise they will be
// *           computed according to MODE, COND, DMAX, and RSIGN and
// *           placed in D.
// *           Modified if MODE is nonzero.
// *
// *  MODE   - INTEGER
// *           On entry this describes how the eigenvalues are to
// *           be specified:
// *           MODE = 0 means use D (with EI) as input
// *           MODE = 1 sets D(1)=1 and D(2:N)=1.0/COND
// *           MODE = 2 sets D(1:N-1)=1 and D(N)=1.0/COND
// *           MODE = 3 sets D(I)=COND**(-(I-1)/(N-1))
// *           MODE = 4 sets D(i)=1 - (i-1)/(N-1)*(1 - 1/COND)
// *           MODE = 5 sets D to random numbers in the range
// *                    ( 1/COND , 1 ) such that their logarithms
// *                    are uniformly distributed.  Each odd-even pair
// *                    of elements will be either used as two real
// *                    eigenvalues or as the real and imaginary part
// *                    of a complex conjugate pair of eigenvalues;
// *                    the choice of which is done is random, with
// *                    50-50 probability, for each pair.
// *           MODE = 6 set D to random numbers from same distribution
// *                    as the rest of the matrix.
// *           MODE < 0 has the same meaning as ABS(MODE), except that
// *              the order of the elements of D is reversed.
// *           Thus if MODE is between 1 and 4, D has entries ranging
// *              from 1 to 1/COND, if between -1 and -4, D has entries
// *              ranging from 1/COND to 1,
// *           Not modified.
// *
// *  COND   - DOUBLE PRECISION
// *           On entry, this is used as described under MODE above.
// *           If used, it must be >= 1. Not modified.
// *
// *  DMAX   - DOUBLE PRECISION
// *           If MODE is neither -6, 0 nor 6, the contents of D, as
// *           computed according to MODE and COND, will be scaled by
// *           DMAX / max(abs(D(i))).  Note that DMAX need not be
// *           positive: if DMAX is negative (or zero), D will be
// *           scaled by a negative number (or zero).
// *           Not modified.
// *
// *  EI     - CHARACTER*1 array, dimension ( N )
// *           If MODE is 0, and EI(1) is not ' ' (space character),
// *           this array specifies which elements of D (on input) are
// *           real eigenvalues and which are the real and imaginary parts
// *           of a complex conjugate pair of eigenvalues.  The elements
// *           of EI may then only have the values 'R' and 'I'.  If
// *           EI(j)='R' and EI(j+1)='I', then the j-th eigenvalue is
// *           CMPLX( D(j) , D(j+1) ), and the (j+1)-th is the complex
// *           conjugate thereof.  If EI(j)=EI(j+1)='R', then the j-th
// *           eigenvalue is D(j) (i.e., real).  EI(1) may not be 'I',
// *           nor may two adjacent elements of EI both have the value 'I'.
// *           If MODE is not 0, then EI is ignored.  If MODE is 0 and
// *           EI(1)=' ', then the eigenvalues will all be real.
// *           Not modified.
// *
// *  RSIGN  - CHARACTER*1
// *           If MODE is not 0, 6, or -6, and RSIGN='T', then the
// *           elements of D, as computed according to MODE and COND, will
// *           be multiplied by a random sign (+1 or -1).  If RSIGN='F',
// *           they will not be.  RSIGN may only have the values 'T' or
// *           'F'.
// *           Not modified.
// *
// *  UPPER  - CHARACTER*1
// *           If UPPER='T', then the elements of A above the diagonal
// *           (and above the 2x2 diagonal blocks, if A has complex
// *           eigenvalues) will be set to random numbers out of DIST.
// *           If UPPER='F', they will not.  UPPER may only have the
// *           values 'T' or 'F'.
// *           Not modified.
// *
// *  SIM    - CHARACTER*1
// *           If SIM='T', then A will be operated on by a "similarity
// *           transform", i.e., multiplied on the left by a matrix X and
// *           on the right by X inverse.  X = U S V, where U and V are
// *           random unitary matrices and S is a (diagonal) matrix of
// *           singular values specified by DS, MODES, and CONDS.  If
// *           SIM='F', then A will not be transformed.
// *           Not modified.
// *
// *  DS     - DOUBLE PRECISION array, dimension ( N )
// *           This array is used to specify the singular values of X,
// *           in the same way that D specifies the eigenvalues of A.
// *           If MODE=0, the DS contains the singular values, which
// *           may not be zero.
// *           Modified if MODE is nonzero.
// *
// *  MODES  - INTEGER
// *  CONDS  - DOUBLE PRECISION
// *           Same as MODE and COND, but for specifying the diagonal
// *           of S.  MODES=-6 and +6 are not allowed (since they would
// *           result in randomly ill-conditioned eigenvalues.)
// *
// *  KL     - INTEGER
// *           This specifies the lower bandwidth of the  matrix.  KL=1
// *           specifies upper Hessenberg form.  If KL is at least N-1,
// *           then A will have full lower bandwidth.  KL must be at
// *           least 1.
// *           Not modified.
// *
// *  KU     - INTEGER
// *           This specifies the upper bandwidth of the  matrix.  KU=1
// *           specifies lower Hessenberg form.  If KU is at least N-1,
// *           then A will have full upper bandwidth; if KU and KL
// *           are both at least N-1, then A will be dense.  Only one of
// *           KU and KL may be less than N-1.  KU must be at least 1.
// *           Not modified.
// *
// *  ANORM  - DOUBLE PRECISION
// *           If ANORM is not negative, then A will be scaled by a non-
// *           negative real number to make the maximum-element-norm of A
// *           to be ANORM.
// *           Not modified.
// *
// *  A      - DOUBLE PRECISION array, dimension ( LDA, N )
// *           On exit A is the desired test matrix.
// *           Modified.
// *
// *  LDA    - INTEGER
// *           LDA specifies the first dimension of A as declared in the
// *           calling program.  LDA must be at least N.
// *           Not modified.
// *
// *  WORK   - DOUBLE PRECISION array, dimension ( 3*N )
// *           Workspace.
// *           Modified.
// *
// *  INFO   - INTEGER
// *           Error code.  On exit, INFO will be set to one of the
// *           following values:
// *             0 => normal return
// *            -1 => N negative
// *            -2 => DIST illegal string
// *            -5 => MODE not in range -6 to 6
// *            -6 => COND less than 1.0, and MODE neither -6, 0 nor 6
// *            -8 => EI(1) is not ' ' or 'R', EI(j) is not 'R' or 'I', or
// *                  two adjacent elements of EI are 'I'.
// *            -9 => RSIGN is not 'T' or 'F'
// *           -10 => UPPER is not 'T' or 'F'
// *           -11 => SIM   is not 'T' or 'F'
// *           -12 => MODES=0 and DS has a zero singular value.
// *           -13 => MODES is not in the range -5 to 5.
// *           -14 => MODES is nonzero and CONDS is less than 1.
// *           -15 => KL is less than 1.
// *           -16 => KU is less than 1, or KL and KU are both less than
// *                  N-1.
// *           -19 => LDA is less than N.
// *            1  => Error return from DLATM1 (computing D)
// *            2  => Cannot scale to DMAX (max. eigenvalue is 0)
// *            3  => Error return from DLATM1 (computing DS)
// *            4  => Error return from DLARGE
// *            5  => Zero singular value from DLATM1.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double half= 1.0e0/2.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean badei= false;
static boolean bads= false;
static boolean useei= false;
static int i= 0;
static int ic= 0;
static int icols= 0;
static int idist= 0;
static intW iinfo= new intW(0);
static int ir= 0;
static int irows= 0;
static int irsign= 0;
static int isim= 0;
static int iupper= 0;
static int j= 0;
static int jc= 0;
static int jcr= 0;
static int jr= 0;
static double alpha= 0.0;
static doubleW tau= new doubleW(0.0);
static double temp= 0.0;
static doubleW xnorms= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] tempa= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Decode and Test the input parameters.
// *             Initialize flags & seed.
// *

public static void dlatme (int n,
String dist,
int [] iseed, int _iseed_offset,
double [] d, int _d_offset,
int mode,
double cond,
double dmax,
String [] ei, int _ei_offset,
String rsign,
String upper,
String sim,
double [] ds, int _ds_offset,
int modes,
double conds,
int kl,
int ku,
double anorm,
double [] a, int _a_offset,
int lda,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (n == 0)  
    Dummy.go_to("Dlatme",999999);
// *
// *     Decode DIST
// *
if ((dist.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    idist = 1;
}              // Close if()
else if ((dist.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    idist = 2;
}              // Close else if()
else if ((dist.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idist = 3;
}              // Close else if()
else  {
  idist = -1;
}              //  Close else.
// *
// *     Check EI
// *
useei = true;
badei = false;
if ((ei[(1)- 1+ _ei_offset].toLowerCase().charAt(0) == " ".toLowerCase().charAt(0)) || mode != 0)  {
    useei = false;
}              // Close if()
else  {
  if ((ei[(1)- 1+ _ei_offset].toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    {
forloop10:
for (j = 2; j <= n; j++) {
if ((ei[(j)- 1+ _ei_offset].toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    if ((ei[(int)((j-1)- 1+ _ei_offset)].toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  
    badei = true;
}              // Close if()
else  {
  if (!(ei[(j)- 1+ _ei_offset].toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  
    badei = true;
}              //  Close else.
Dummy.label("Dlatme",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  badei = true;
}              //  Close else.
}              //  Close else.
// *
// *     Decode RSIGN
// *
if ((rsign.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    irsign = 1;
}              // Close if()
else if ((rsign.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    irsign = 0;
}              // Close else if()
else  {
  irsign = -1;
}              //  Close else.
// *
// *     Decode UPPER
// *
if ((upper.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    iupper = 1;
}              // Close if()
else if ((upper.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    iupper = 0;
}              // Close else if()
else  {
  iupper = -1;
}              //  Close else.
// *
// *     Decode SIM
// *
if ((sim.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    isim = 1;
}              // Close if()
else if ((sim.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    isim = 0;
}              // Close else if()
else  {
  isim = -1;
}              //  Close else.
// *
// *     Check DS, if MODES=0 and ISIM=1
// *
bads = false;
if (modes == 0 && isim == 1)  {
    {
forloop20:
for (j = 1; j <= n; j++) {
if (ds[(j)- 1+ _ds_offset] == zero)  
    bads = true;
Dummy.label("Dlatme",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Set INFO if an error
// *
if (n < 0)  {
    info.val = -1;
}              // Close if()
else if (idist == -1)  {
    info.val = -2;
}              // Close else if()
else if (Math.abs(mode) > 6)  {
    info.val = -5;
}              // Close else if()
else if ((mode != 0 && Math.abs(mode) != 6) && cond < one)  {
    info.val = -6;
}              // Close else if()
else if (badei)  {
    info.val = -8;
}              // Close else if()
else if (irsign == -1)  {
    info.val = -9;
}              // Close else if()
else if (iupper == -1)  {
    info.val = -10;
}              // Close else if()
else if (isim == -1)  {
    info.val = -11;
}              // Close else if()
else if (bads)  {
    info.val = -12;
}              // Close else if()
else if (isim == 1 && Math.abs(modes) > 5)  {
    info.val = -13;
}              // Close else if()
else if (isim == 1 && modes != 0 && conds < one)  {
    info.val = -14;
}              // Close else if()
else if (kl < 1)  {
    info.val = -15;
}              // Close else if()
else if (ku < 1 || (ku < n-1 && kl < n-1))  {
    info.val = -16;
}              // Close else if()
else if (lda < Math.max(1, n) )  {
    info.val = -19;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DLATME",-info.val);
Dummy.go_to("Dlatme",999999);
}              // Close if()
// *
// *     Initialize random number generator
// *
{
forloop30:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1+ _iseed_offset] = (Math.abs(iseed[(i)- 1+ _iseed_offset]))%(4096) ;
Dummy.label("Dlatme",30);
}              //  Close for() loop. 
}
// *
if ((iseed[(4)- 1+ _iseed_offset])%(2)  != 1)  
    iseed[(4)- 1+ _iseed_offset] = iseed[(4)- 1+ _iseed_offset]+1;
// *
// *     2)      Set up diagonal of A
// *
// *             Compute D according to COND and MODE
// *
Dlatm1.dlatm1(mode,cond,irsign,idist,iseed,_iseed_offset,d,_d_offset,n,iinfo);
if (iinfo.val != 0)  {
    info.val = 1;
Dummy.go_to("Dlatme",999999);
}              // Close if()
if (mode != 0 && Math.abs(mode) != 6)  {
    // *
// *        Scale by DMAX
// *
temp = Math.abs(d[(1)- 1+ _d_offset]);
{
forloop40:
for (i = 2; i <= n; i++) {
temp = Math.max(temp, Math.abs(d[(i)- 1+ _d_offset])) ;
Dummy.label("Dlatme",40);
}              //  Close for() loop. 
}
// *
if (temp > zero)  {
    alpha = dmax/temp;
}              // Close if()
else if (dmax != zero)  {
    info.val = 2;
Dummy.go_to("Dlatme",999999);
}              // Close else if()
else  {
  alpha = zero;
}              //  Close else.
// *
Dscal.dscal(n,alpha,d,_d_offset,1);
// *
}              // Close if()
// *
Dlaset.dlaset("Full",n,n,zero,zero,a,_a_offset,lda);
Dcopy.dcopy(n,d,_d_offset,1,a,_a_offset,lda+1);
// *
// *     Set up complex conjugate pairs
// *
if (mode == 0)  {
    if (useei)  {
    {
forloop50:
for (j = 2; j <= n; j++) {
if ((ei[(j)- 1+ _ei_offset].toLowerCase().charAt(0) == "I".toLowerCase().charAt(0)))  {
    a[(j-1)- 1+(j- 1)*lda+ _a_offset] = a[(j)- 1+(j- 1)*lda+ _a_offset];
a[(j)- 1+(j-1- 1)*lda+ _a_offset] = -a[(j)- 1+(j- 1)*lda+ _a_offset];
a[(j)- 1+(j- 1)*lda+ _a_offset] = a[(j-1)- 1+(j-1- 1)*lda+ _a_offset];
}              // Close if()
Dummy.label("Dlatme",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
}              // Close if()
else if (Math.abs(mode) == 5)  {
    // *
{
int _j_inc = 2;
forloop60:
for (j = 2; (_j_inc < 0) ? j >= n : j <= n; j += _j_inc) {
if (Dlaran.dlaran(iseed,_iseed_offset) > half)  {
    a[(j-1)- 1+(j- 1)*lda+ _a_offset] = a[(j)- 1+(j- 1)*lda+ _a_offset];
a[(j)- 1+(j-1- 1)*lda+ _a_offset] = -a[(j)- 1+(j- 1)*lda+ _a_offset];
a[(j)- 1+(j- 1)*lda+ _a_offset] = a[(j-1)- 1+(j-1- 1)*lda+ _a_offset];
}              // Close if()
Dummy.label("Dlatme",60);
}              //  Close for() loop. 
}
}              // Close else if()
// *
// *     3)      If UPPER='T', set upper triangle of A to random numbers.
// *             (but don't modify the corners of 2x2 blocks.)
// *
if (iupper != 0)  {
    {
forloop70:
for (jc = 2; jc <= n; jc++) {
if (a[(jc-1)- 1+(jc- 1)*lda+ _a_offset] != zero)  {
    jr = jc-2;
}              // Close if()
else  {
  jr = jc-1;
}              //  Close else.
Dlarnv.dlarnv(idist,iseed,_iseed_offset,jr,a,(1)- 1+(jc- 1)*lda+ _a_offset);
Dummy.label("Dlatme",70);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     4)      If SIM='T', apply similarity transformation.
// *
// *                                -1
// *             Transform is  X A X  , where X = U S V, thus
// *
// *             it is  U S V A V' (1/S) U'
// *
if (isim != 0)  {
    // *
// *        Compute S (singular values of the eigenvector matrix)
// *        according to CONDS and MODES
// *
Dlatm1.dlatm1(modes,conds,0,0,iseed,_iseed_offset,ds,_ds_offset,n,iinfo);
if (iinfo.val != 0)  {
    info.val = 3;
Dummy.go_to("Dlatme",999999);
}              // Close if()
// *
// *        Multiply by V and V'
// *
Dlarge.dlarge(n,a,_a_offset,lda,iseed,_iseed_offset,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    info.val = 4;
Dummy.go_to("Dlatme",999999);
}              // Close if()
// *
// *        Multiply by S and (1/S)
// *
{
forloop80:
for (j = 1; j <= n; j++) {
Dscal.dscal(n,ds[(j)- 1+ _ds_offset],a,(j)- 1+(1- 1)*lda+ _a_offset,lda);
if (ds[(j)- 1+ _ds_offset] != zero)  {
    Dscal.dscal(n,one/ds[(j)- 1+ _ds_offset],a,(1)- 1+(j- 1)*lda+ _a_offset,1);
}              // Close if()
else  {
  info.val = 5;
Dummy.go_to("Dlatme",999999);
}              //  Close else.
Dummy.label("Dlatme",80);
}              //  Close for() loop. 
}
// *
// *        Multiply by U and U'
// *
Dlarge.dlarge(n,a,_a_offset,lda,iseed,_iseed_offset,work,_work_offset,iinfo);
if (iinfo.val != 0)  {
    info.val = 4;
Dummy.go_to("Dlatme",999999);
}              // Close if()
}              // Close if()
// *
// *     5)      Reduce the bandwidth.
// *
if (kl < n-1)  {
    // *
// *        Reduce bandwidth -- kill column
// *
{
forloop90:
for (jcr = kl+1; jcr <= n-1; jcr++) {
ic = jcr-kl;
irows = n+1-jcr;
icols = n+kl-jcr;
// *
Dcopy.dcopy(irows,a,(jcr)- 1+(ic- 1)*lda+ _a_offset,1,work,_work_offset,1);
xnorms.val = work[(1)- 1+ _work_offset];
Dlarfg.dlarfg(irows,xnorms,work,(2)- 1+ _work_offset,1,tau);
work[(1)- 1+ _work_offset] = one;
// *
Dgemv.dgemv("T",irows,icols,one,a,(jcr)- 1+(ic+1- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(irows+1)- 1+ _work_offset,1);
Dger.dger(irows,icols,-tau.val,work,_work_offset,1,work,(irows+1)- 1+ _work_offset,1,a,(jcr)- 1+(ic+1- 1)*lda+ _a_offset,lda);
// *
Dgemv.dgemv("N",n,irows,one,a,(1)- 1+(jcr- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(irows+1)- 1+ _work_offset,1);
Dger.dger(n,irows,-tau.val,work,(irows+1)- 1+ _work_offset,1,work,_work_offset,1,a,(1)- 1+(jcr- 1)*lda+ _a_offset,lda);
// *
a[(jcr)- 1+(ic- 1)*lda+ _a_offset] = xnorms.val;
Dlaset.dlaset("Full",irows-1,1,zero,zero,a,(jcr+1)- 1+(ic- 1)*lda+ _a_offset,lda);
Dummy.label("Dlatme",90);
}              //  Close for() loop. 
}
}              // Close if()
else if (ku < n-1)  {
    // *
// *        Reduce upper bandwidth -- kill a row at a time.
// *
{
forloop100:
for (jcr = ku+1; jcr <= n-1; jcr++) {
ir = jcr-ku;
irows = n+ku-jcr;
icols = n+1-jcr;
// *
Dcopy.dcopy(icols,a,(ir)- 1+(jcr- 1)*lda+ _a_offset,lda,work,_work_offset,1);
xnorms.val = work[(1)- 1+ _work_offset];
Dlarfg.dlarfg(icols,xnorms,work,(2)- 1+ _work_offset,1,tau);
work[(1)- 1+ _work_offset] = one;
// *
Dgemv.dgemv("N",irows,icols,one,a,(ir+1)- 1+(jcr- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(icols+1)- 1+ _work_offset,1);
Dger.dger(irows,icols,-tau.val,work,(icols+1)- 1+ _work_offset,1,work,_work_offset,1,a,(ir+1)- 1+(jcr- 1)*lda+ _a_offset,lda);
// *
Dgemv.dgemv("C",icols,n,one,a,(jcr)- 1+(1- 1)*lda+ _a_offset,lda,work,_work_offset,1,zero,work,(icols+1)- 1+ _work_offset,1);
Dger.dger(icols,n,-tau.val,work,_work_offset,1,work,(icols+1)- 1+ _work_offset,1,a,(jcr)- 1+(1- 1)*lda+ _a_offset,lda);
// *
a[(ir)- 1+(jcr- 1)*lda+ _a_offset] = xnorms.val;
Dlaset.dlaset("Full",1,icols-1,zero,zero,a,(ir)- 1+(jcr+1- 1)*lda+ _a_offset,lda);
Dummy.label("Dlatme",100);
}              //  Close for() loop. 
}
}              // Close else if()
// *
// *     Scale the matrix to have norm ANORM
// *
if (anorm >= zero)  {
    temp = Dlange.dlange("M",n,n,a,_a_offset,lda,tempa,0);
if (temp > zero)  {
    alpha = anorm/temp;
{
forloop110:
for (j = 1; j <= n; j++) {
Dscal.dscal(n,alpha,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatme",110);
}              //  Close for() loop. 
}
}              // Close if()
}              // Close if()
// *
Dummy.go_to("Dlatme",999999);
// *
// *     End of DLATME
// *
Dummy.label("Dlatme",999999);
return;
   }
} // End class.
