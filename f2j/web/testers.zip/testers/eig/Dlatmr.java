/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlatmr {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DLATMR generates random matrices of various types for testing
// *     LAPACK programs.
// *
// *     DLATMR operates by applying the following sequence of
// *     operations:
// *
// *       Generate a matrix A with random entries of distribution DIST
// *          which is symmetric if SYM='S', and nonsymmetric
// *          if SYM='N'.
// *
// *       Set the diagonal to D, where D may be input or
// *          computed according to MODE, COND, DMAX and RSIGN
// *          as described below.
// *
// *       Grade the matrix, if desired, from the left and/or right
// *          as specified by GRADE. The inputs DL, MODEL, CONDL, DR,
// *          MODER and CONDR also determine the grading as described
// *          below.
// *
// *       Permute, if desired, the rows and/or columns as specified by
// *          PIVTNG and IPIVOT.
// *
// *       Set random entries to zero, if desired, to get a random sparse
// *          matrix as specified by SPARSE.
// *
// *       Make A a band matrix, if desired, by zeroing out the matrix
// *          outside a band of lower bandwidth KL and upper bandwidth KU.
// *
// *       Scale A, if desired, to have maximum entry ANORM.
// *
// *       Pack the matrix if desired. Options specified by PACK are:
// *          no packing
// *          zero out upper half (if symmetric)
// *          zero out lower half (if symmetric)
// *          store the upper half columnwise (if symmetric or
// *              square upper triangular)
// *          store the lower half columnwise (if symmetric or
// *              square lower triangular)
// *              same as upper half rowwise if symmetric
// *          store the lower triangle in banded format (if symmetric)
// *          store the upper triangle in banded format (if symmetric)
// *          store the entire matrix in banded format
// *
// *     Note: If two calls to DLATMR differ only in the PACK parameter,
// *           they will generate mathematically equivalent matrices.
// *
// *           If two calls to DLATMR both have full bandwidth (KL = M-1
// *           and KU = N-1), and differ only in the PIVTNG and PACK
// *           parameters, then the matrices generated will differ only
// *           in the order of the rows and/or columns, and otherwise
// *           contain the same data. This consistency cannot be and
// *           is not maintained with less than full bandwidth.
// *
// *  Arguments
// *  =========
// *
// *  M      - INTEGER
// *           Number of rows of A. Not modified.
// *
// *  N      - INTEGER
// *           Number of columns of A. Not modified.
// *
// *  DIST   - CHARACTER*1
// *           On entry, DIST specifies the type of distribution to be used
// *           to generate a random matrix .
// *           'U' => UNIFORM( 0, 1 )  ( 'U' for uniform )
// *           'S' => UNIFORM( -1, 1 ) ( 'S' for symmetric )
// *           'N' => NORMAL( 0, 1 )   ( 'N' for normal )
// *           Not modified.
// *
// *  ISEED  - INTEGER array, dimension (4)
// *           On entry ISEED specifies the seed of the random number
// *           generator. They should lie between 0 and 4095 inclusive,
// *           and ISEED(4) should be odd. The random number generator
// *           uses a linear congruential sequence limited to small
// *           integers, and so should produce machine independent
// *           random numbers. The values of ISEED are changed on
// *           exit, and can be used in the next call to DLATMR
// *           to continue the same random number sequence.
// *           Changed on exit.
// *
// *  SYM    - CHARACTER*1
// *           If SYM='S' or 'H', generated matrix is symmetric.
// *           If SYM='N', generated matrix is nonsymmetric.
// *           Not modified.
// *
// *  D      - DOUBLE PRECISION array, dimension (min(M,N))
// *           On entry this array specifies the diagonal entries
// *           of the diagonal of A.  D may either be specified
// *           on entry, or set according to MODE and COND as described
// *           below. May be changed on exit if MODE is nonzero.
// *
// *  MODE   - INTEGER
// *           On entry describes how D is to be used:
// *           MODE = 0 means use D as input
// *           MODE = 1 sets D(1)=1 and D(2:N)=1.0/COND
// *           MODE = 2 sets D(1:N-1)=1 and D(N)=1.0/COND
// *           MODE = 3 sets D(I)=COND**(-(I-1)/(N-1))
// *           MODE = 4 sets D(i)=1 - (i-1)/(N-1)*(1 - 1/COND)
// *           MODE = 5 sets D to random numbers in the range
// *                    ( 1/COND , 1 ) such that their logarithms
// *                    are uniformly distributed.
// *           MODE = 6 set D to random numbers from same distribution
// *                    as the rest of the matrix.
// *           MODE < 0 has the same meaning as ABS(MODE), except that
// *              the order of the elements of D is reversed.
// *           Thus if MODE is positive, D has entries ranging from
// *              1 to 1/COND, if negative, from 1/COND to 1,
// *           Not modified.
// *
// *  COND   - DOUBLE PRECISION
// *           On entry, used as described under MODE above.
// *           If used, it must be >= 1. Not modified.
// *
// *  DMAX   - DOUBLE PRECISION
// *           If MODE neither -6, 0 nor 6, the diagonal is scaled by
// *           DMAX / max(abs(D(i))), so that maximum absolute entry
// *           of diagonal is abs(DMAX). If DMAX is negative (or zero),
// *           diagonal will be scaled by a negative number (or zero).
// *
// *  RSIGN  - CHARACTER*1
// *           If MODE neither -6, 0 nor 6, specifies sign of diagonal
// *           as follows:
// *           'T' => diagonal entries are multiplied by 1 or -1
// *                  with probability .5
// *           'F' => diagonal unchanged
// *           Not modified.
// *
// *  GRADE  - CHARACTER*1
// *           Specifies grading of matrix as follows:
// *           'N'  => no grading
// *           'L'  => matrix premultiplied by diag( DL )
// *                   (only if matrix nonsymmetric)
// *           'R'  => matrix postmultiplied by diag( DR )
// *                   (only if matrix nonsymmetric)
// *           'B'  => matrix premultiplied by diag( DL ) and
// *                         postmultiplied by diag( DR )
// *                   (only if matrix nonsymmetric)
// *           'S' or 'H'  => matrix premultiplied by diag( DL ) and
// *                          postmultiplied by diag( DL )
// *                          ('S' for symmetric, or 'H' for Hermitian)
// *           'E'  => matrix premultiplied by diag( DL ) and
// *                         postmultiplied by inv( diag( DL ) )
// *                         ( 'E' for eigenvalue invariance)
// *                   (only if matrix nonsymmetric)
// *                   Note: if GRADE='E', then M must equal N.
// *           Not modified.
// *
// *  DL     - DOUBLE PRECISION array, dimension (M)
// *           If MODEL=0, then on entry this array specifies the diagonal
// *           entries of a diagonal matrix used as described under GRADE
// *           above. If MODEL is not zero, then DL will be set according
// *           to MODEL and CONDL, analogous to the way D is set according
// *           to MODE and COND (except there is no DMAX parameter for DL).
// *           If GRADE='E', then DL cannot have zero entries.
// *           Not referenced if GRADE = 'N' or 'R'. Changed on exit.
// *
// *  MODEL  - INTEGER
// *           This specifies how the diagonal array DL is to be computed,
// *           just as MODE specifies how D is to be computed.
// *           Not modified.
// *
// *  CONDL  - DOUBLE PRECISION
// *           When MODEL is not zero, this specifies the condition number
// *           of the computed DL.  Not modified.
// *
// *  DR     - DOUBLE PRECISION array, dimension (N)
// *           If MODER=0, then on entry this array specifies the diagonal
// *           entries of a diagonal matrix used as described under GRADE
// *           above. If MODER is not zero, then DR will be set according
// *           to MODER and CONDR, analogous to the way D is set according
// *           to MODE and COND (except there is no DMAX parameter for DR).
// *           Not referenced if GRADE = 'N', 'L', 'H', 'S' or 'E'.
// *           Changed on exit.
// *
// *  MODER  - INTEGER
// *           This specifies how the diagonal array DR is to be computed,
// *           just as MODE specifies how D is to be computed.
// *           Not modified.
// *
// *  CONDR  - DOUBLE PRECISION
// *           When MODER is not zero, this specifies the condition number
// *           of the computed DR.  Not modified.
// *
// *  PIVTNG - CHARACTER*1
// *           On entry specifies pivoting permutations as follows:
// *           'N' or ' ' => none.
// *           'L' => left or row pivoting (matrix must be nonsymmetric).
// *           'R' => right or column pivoting (matrix must be
// *                  nonsymmetric).
// *           'B' or 'F' => both or full pivoting, i.e., on both sides.
// *                         In this case, M must equal N
// *
// *           If two calls to DLATMR both have full bandwidth (KL = M-1
// *           and KU = N-1), and differ only in the PIVTNG and PACK
// *           parameters, then the matrices generated will differ only
// *           in the order of the rows and/or columns, and otherwise
// *           contain the same data. This consistency cannot be
// *           maintained with less than full bandwidth.
// *
// *  IPIVOT - INTEGER array, dimension (N or M)
// *           This array specifies the permutation used.  After the
// *           basic matrix is generated, the rows, columns, or both
// *           are permuted.   If, say, row pivoting is selected, DLATMR
// *           starts with the *last* row and interchanges the M-th and
// *           IPIVOT(M)-th rows, then moves to the next-to-last row,
// *           interchanging the (M-1)-th and the IPIVOT(M-1)-th rows,
// *           and so on.  In terms of "2-cycles", the permutation is
// *           (1 IPIVOT(1)) (2 IPIVOT(2)) ... (M IPIVOT(M))
// *           where the rightmost cycle is applied first.  This is the
// *           *inverse* of the effect of pivoting in LINPACK.  The idea
// *           is that factoring (with pivoting) an identity matrix
// *           which has been inverse-pivoted in this way should
// *           result in a pivot vector identical to IPIVOT.
// *           Not referenced if PIVTNG = 'N'. Not modified.
// *
// *  SPARSE - DOUBLE PRECISION
// *           On entry specifies the sparsity of the matrix if a sparse
// *           matrix is to be generated. SPARSE should lie between
// *           0 and 1. To generate a sparse matrix, for each matrix entry
// *           a uniform ( 0, 1 ) random number x is generated and
// *           compared to SPARSE; if x is larger the matrix entry
// *           is unchanged and if x is smaller the entry is set
// *           to zero. Thus on the average a fraction SPARSE of the
// *           entries will be set to zero.
// *           Not modified.
// *
// *  KL     - INTEGER
// *           On entry specifies the lower bandwidth of the  matrix. For
// *           example, KL=0 implies upper triangular, KL=1 implies upper
// *           Hessenberg, and KL at least M-1 implies the matrix is not
// *           banded. Must equal KU if matrix is symmetric.
// *           Not modified.
// *
// *  KU     - INTEGER
// *           On entry specifies the upper bandwidth of the  matrix. For
// *           example, KU=0 implies lower triangular, KU=1 implies lower
// *           Hessenberg, and KU at least N-1 implies the matrix is not
// *           banded. Must equal KL if matrix is symmetric.
// *           Not modified.
// *
// *  ANORM  - DOUBLE PRECISION
// *           On entry specifies maximum entry of output matrix
// *           (output matrix will by multiplied by a constant so that
// *           its largest absolute entry equal ANORM)
// *           if ANORM is nonnegative. If ANORM is negative no scaling
// *           is done. Not modified.
// *
// *  PACK   - CHARACTER*1
// *           On entry specifies packing of matrix as follows:
// *           'N' => no packing
// *           'U' => zero out all subdiagonal entries (if symmetric)
// *           'L' => zero out all superdiagonal entries (if symmetric)
// *           'C' => store the upper triangle columnwise
// *                  (only if matrix symmetric or square upper triangular)
// *           'R' => store the lower triangle columnwise
// *                  (only if matrix symmetric or square lower triangular)
// *                  (same as upper half rowwise if symmetric)
// *           'B' => store the lower triangle in band storage scheme
// *                  (only if matrix symmetric)
// *           'Q' => store the upper triangle in band storage scheme
// *                  (only if matrix symmetric)
// *           'Z' => store the entire matrix in band storage scheme
// *                      (pivoting can be provided for by using this
// *                      option to store A in the trailing rows of
// *                      the allocated storage)
// *
// *           Using these options, the various LAPACK packed and banded
// *           storage schemes can be obtained:
// *           GB               - use 'Z'
// *           PB, SB or TB     - use 'B' or 'Q'
// *           PP, SP or TP     - use 'C' or 'R'
// *
// *           If two calls to DLATMR differ only in the PACK parameter,
// *           they will generate mathematically equivalent matrices.
// *           Not modified.
// *
// *  A      - DOUBLE PRECISION array, dimension (LDA,N)
// *           On exit A is the desired test matrix. Only those
// *           entries of A which are significant on output
// *           will be referenced (even if A is in packed or band
// *           storage format). The 'unoccupied corners' of A in
// *           band format will be zeroed out.
// *
// *  LDA    - INTEGER
// *           on entry LDA specifies the first dimension of A as
// *           declared in the calling program.
// *           If PACK='N', 'U' or 'L', LDA must be at least max ( 1, M ).
// *           If PACK='C' or 'R', LDA must be at least 1.
// *           If PACK='B', or 'Q', LDA must be MIN ( KU+1, N )
// *           If PACK='Z', LDA must be at least KUU+KLL+1, where
// *           KUU = MIN ( KU, N-1 ) and KLL = MIN ( KL, N-1 )
// *           Not modified.
// *
// *  IWORK  - INTEGER array, dimension ( N or M)
// *           Workspace. Not referenced if PIVTNG = 'N'. Changed on exit.
// *
// *  INFO   - INTEGER
// *           Error parameter on exit:
// *             0 => normal return
// *            -1 => M negative or unequal to N and SYM='S' or 'H'
// *            -2 => N negative
// *            -3 => DIST illegal string
// *            -5 => SYM illegal string
// *            -7 => MODE not in range -6 to 6
// *            -8 => COND less than 1.0, and MODE neither -6, 0 nor 6
// *           -10 => MODE neither -6, 0 nor 6 and RSIGN illegal string
// *           -11 => GRADE illegal string, or GRADE='E' and
// *                  M not equal to N, or GRADE='L', 'R', 'B' or 'E' and
// *                  SYM = 'S' or 'H'
// *           -12 => GRADE = 'E' and DL contains zero
// *           -13 => MODEL not in range -6 to 6 and GRADE= 'L', 'B', 'H',
// *                  'S' or 'E'
// *           -14 => CONDL less than 1.0, GRADE='L', 'B', 'H', 'S' or 'E',
// *                  and MODEL neither -6, 0 nor 6
// *           -16 => MODER not in range -6 to 6 and GRADE= 'R' or 'B'
// *           -17 => CONDR less than 1.0, GRADE='R' or 'B', and
// *                  MODER neither -6, 0 nor 6
// *           -18 => PIVTNG illegal string, or PIVTNG='B' or 'F' and
// *                  M not equal to N, or PIVTNG='L' or 'R' and SYM='S'
// *                  or 'H'
// *           -19 => IPIVOT contains out of range number and
// *                  PIVTNG not equal to 'N'
// *           -20 => KL negative
// *           -21 => KU negative, or SYM='S' or 'H' and KU not equal to KL
// *           -22 => SPARSE not in range 0. to 1.
// *           -24 => PACK illegal string, or PACK='U', 'L', 'B' or 'Q'
// *                  and SYM='N', or PACK='C' and SYM='N' and either KL
// *                  not equal to 0 or N not equal to M, or PACK='R' and
// *                  SYM='N', and either KU not equal to 0 or N not equal
// *                  to M
// *           -26 => LDA too small
// *             1 => Error return from DLATM1 (computing D)
// *             2 => Cannot scale diagonal to DMAX (max. entry is 0)
// *             3 => Error return from DLATM1 (computing DL)
// *             4 => Error return from DLATM1 (computing DR)
// *             5 => ANORM is positive, but matrix constructed prior to
// *                  attempting to scale it to have norm ANORM, is zero
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean badpvt= false;
static boolean dzero= false;
static boolean fulbnd= false;
static int i= 0;
static int idist= 0;
static int igrade= 0;
static int iisub= 0;
static int ipack= 0;
static int ipvtng= 0;
static int irsign= 0;
static intW Isub= new intW(0);
static int isym= 0;
static int j= 0;
static int jjsub= 0;
static intW jsub= new intW(0);
static int k= 0;
static int kll= 0;
static int kuu= 0;
static int mnmin= 0;
static int mnsub= 0;
static int mxsub= 0;
static int npvts= 0;
static double alpha= 0.0;
static double onorm= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] tempa= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Decode and Test the input parameters.
// *             Initialize flags & seed.
// *

public static void dlatmr (int m,
int n,
String dist,
int [] iseed, int _iseed_offset,
String sym,
double [] d, int _d_offset,
int mode,
double cond,
double dmax,
String rsign,
String grade,
double [] dl, int _dl_offset,
int model,
double condl,
double [] dr, int _dr_offset,
int moder,
double condr,
String pivtng,
int [] ipivot, int _ipivot_offset,
int kl,
int ku,
double sparse,
double anorm,
String pack,
double [] a, int _a_offset,
int lda,
int [] iwork, int _iwork_offset,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dlatmr",999999);
// *
// *     Decode DIST
// *
if ((dist.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    idist = 1;
}              // Close if()
else if ((dist.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    idist = 2;
}              // Close else if()
else if ((dist.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idist = 3;
}              // Close else if()
else  {
  idist = -1;
}              //  Close else.
// *
// *     Decode SYM
// *
if ((sym.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    isym = 0;
}              // Close if()
else if ((sym.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    isym = 1;
}              // Close else if()
else if ((sym.toLowerCase().charAt(0) == "H".toLowerCase().charAt(0)))  {
    isym = 0;
}              // Close else if()
else  {
  isym = -1;
}              //  Close else.
// *
// *     Decode RSIGN
// *
if ((rsign.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    irsign = 0;
}              // Close if()
else if ((rsign.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    irsign = 1;
}              // Close else if()
else  {
  irsign = -1;
}              //  Close else.
// *
// *     Decode PIVTNG
// *
if ((pivtng.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ipvtng = 0;
}              // Close if()
else if ((pivtng.toLowerCase().charAt(0) == " ".toLowerCase().charAt(0)))  {
    ipvtng = 0;
}              // Close else if()
else if ((pivtng.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    ipvtng = 1;
npvts = m;
}              // Close else if()
else if ((pivtng.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    ipvtng = 2;
npvts = n;
}              // Close else if()
else if ((pivtng.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    ipvtng = 3;
npvts = (int)(Math.min(n, m) );
}              // Close else if()
else if ((pivtng.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0)))  {
    ipvtng = 3;
npvts = (int)(Math.min(n, m) );
}              // Close else if()
else  {
  ipvtng = -1;
}              //  Close else.
// *
// *     Decode GRADE
// *
if ((grade.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    igrade = 0;
}              // Close if()
else if ((grade.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    igrade = 1;
}              // Close else if()
else if ((grade.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    igrade = 2;
}              // Close else if()
else if ((grade.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    igrade = 3;
}              // Close else if()
else if ((grade.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0)))  {
    igrade = 4;
}              // Close else if()
else if ((grade.toLowerCase().charAt(0) == "H".toLowerCase().charAt(0)) || (grade.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    igrade = 5;
}              // Close else if()
else  {
  igrade = -1;
}              //  Close else.
// *
// *     Decode PACK
// *
if ((pack.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ipack = 0;
}              // Close if()
else if ((pack.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    ipack = 1;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    ipack = 2;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    ipack = 3;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    ipack = 4;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    ipack = 5;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0)))  {
    ipack = 6;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0)))  {
    ipack = 7;
}              // Close else if()
else  {
  ipack = -1;
}              //  Close else.
// *
// *     Set certain internal parameters
// *
mnmin = (int)(Math.min(m, n) );
kll = (int)(Math.min(kl, m-1) );
kuu = (int)(Math.min(ku, n-1) );
// *
// *     If inv(DL) is used, check to see if DL has a zero entry.
// *
dzero = false;
if (igrade == 4 && model == 0)  {
    {
forloop10:
for (i = 1; i <= m; i++) {
if (dl[(i)- 1+ _dl_offset] == zero)  
    dzero = true;
Dummy.label("Dlatmr",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Check values in IPIVOT
// *
badpvt = false;
if (ipvtng > 0)  {
    {
forloop20:
for (j = 1; j <= npvts; j++) {
if (ipivot[(j)- 1+ _ipivot_offset] <= 0 || ipivot[(j)- 1+ _ipivot_offset] > npvts)  
    badpvt = true;
Dummy.label("Dlatmr",20);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Set INFO if an error
// *
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (m != n && isym == 0)  {
    info.val = -1;
}              // Close else if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (idist == -1)  {
    info.val = -3;
}              // Close else if()
else if (isym == -1)  {
    info.val = -5;
}              // Close else if()
else if (mode < -6 || mode > 6)  {
    info.val = -7;
}              // Close else if()
else if ((mode != -6 && mode != 0 && mode != 6) && cond < one)  {
    info.val = -8;
}              // Close else if()
else if ((mode != -6 && mode != 0 && mode != 6) && irsign == -1)  {
    info.val = -10;
}              // Close else if()
else if (igrade == -1 || (igrade == 4 && m != n) || ((igrade >= 1 && igrade <= 4) && isym == 0))  {
    info.val = -11;
}              // Close else if()
else if (igrade == 4 && dzero)  {
    info.val = -12;
}              // Close else if()
else if ((igrade == 1 || igrade == 3 || igrade == 4 || igrade == 5) && (model < -6 || model > 6))  {
    info.val = -13;
}              // Close else if()
else if ((igrade == 1 || igrade == 3 || igrade == 4 || igrade == 5) && (model != -6 && model != 0 && model != 6) && condl < one)  {
    info.val = -14;
}              // Close else if()
else if ((igrade == 2 || igrade == 3) && (moder < -6 || moder > 6))  {
    info.val = -16;
}              // Close else if()
else if ((igrade == 2 || igrade == 3) && (moder != -6 && moder != 0 && moder != 6) && condr < one)  {
    info.val = -17;
}              // Close else if()
else if (ipvtng == -1 || (ipvtng == 3 && m != n) || ((ipvtng == 1 || ipvtng == 2) && isym == 0))  {
    info.val = -18;
}              // Close else if()
else if (ipvtng != 0 && badpvt)  {
    info.val = -19;
}              // Close else if()
else if (kl < 0)  {
    info.val = -20;
}              // Close else if()
else if (ku < 0 || (isym == 0 && kl != ku))  {
    info.val = -21;
}              // Close else if()
else if (sparse < zero || sparse > one)  {
    info.val = -22;
}              // Close else if()
else if (ipack == -1 || ((ipack == 1 || ipack == 2 || ipack == 5 || ipack == 6) && isym == 1) || (ipack == 3 && isym == 1 && (kl != 0 || m != n)) || (ipack == 4 && isym == 1 && (ku != 0 || m != n)))  {
    info.val = -24;
}              // Close else if()
else if (((ipack == 0 || ipack == 1 || ipack == 2) && lda < Math.max(1, m) ) || ((ipack == 3 || ipack == 4) && lda < 1) || ((ipack == 5 || ipack == 6) && lda < kuu+1) || (ipack == 7 && lda < kll+kuu+1))  {
    info.val = -26;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DLATMR",-info.val);
Dummy.go_to("Dlatmr",999999);
}              // Close if()
// *
// *     Decide if we can pivot consistently
// *
fulbnd = false;
if (kuu == n-1 && kll == m-1)  
    fulbnd = true;
// *
// *     Initialize random number generator
// *
{
forloop30:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1+ _iseed_offset] = (Math.abs(iseed[(i)- 1+ _iseed_offset]))%(4096) ;
Dummy.label("Dlatmr",30);
}              //  Close for() loop. 
}
// *
iseed[(4)- 1+ _iseed_offset] = 2*(iseed[(4)- 1+ _iseed_offset]/2)+1;
// *
// *     2)      Set up D, DL, and DR, if indicated.
// *
// *             Compute D according to COND and MODE
// *
Dlatm1.dlatm1(mode,cond,irsign,idist,iseed,_iseed_offset,d,_d_offset,mnmin,info);
if (info.val != 0)  {
    info.val = 1;
Dummy.go_to("Dlatmr",999999);
}              // Close if()
if (mode != 0 && mode != -6 && mode != 6)  {
    // *
// *        Scale by DMAX
// *
temp = Math.abs(d[(1)- 1+ _d_offset]);
{
forloop40:
for (i = 2; i <= mnmin; i++) {
temp = Math.max(temp, Math.abs(d[(i)- 1+ _d_offset])) ;
Dummy.label("Dlatmr",40);
}              //  Close for() loop. 
}
if (temp == zero && dmax != zero)  {
    info.val = 2;
Dummy.go_to("Dlatmr",999999);
}              // Close if()
if (temp != zero)  {
    alpha = dmax/temp;
}              // Close if()
else  {
  alpha = one;
}              //  Close else.
{
forloop50:
for (i = 1; i <= mnmin; i++) {
d[(i)- 1+ _d_offset] = alpha*d[(i)- 1+ _d_offset];
Dummy.label("Dlatmr",50);
}              //  Close for() loop. 
}
// *
}              // Close if()
// *
// *     Compute DL if grading set
// *
if (igrade == 1 || igrade == 3 || igrade == 4 || igrade == 5)  {
    Dlatm1.dlatm1(model,condl,0,idist,iseed,_iseed_offset,dl,_dl_offset,m,info);
if (info.val != 0)  {
    info.val = 3;
Dummy.go_to("Dlatmr",999999);
}              // Close if()
}              // Close if()
// *
// *     Compute DR if grading set
// *
if (igrade == 2 || igrade == 3)  {
    Dlatm1.dlatm1(moder,condr,0,idist,iseed,_iseed_offset,dr,_dr_offset,n,info);
if (info.val != 0)  {
    info.val = 4;
Dummy.go_to("Dlatmr",999999);
}              // Close if()
}              // Close if()
// *
// *     3)     Generate IWORK if pivoting
// *
if (ipvtng > 0)  {
    {
forloop60:
for (i = 1; i <= npvts; i++) {
iwork[(i)- 1+ _iwork_offset] = i;
Dummy.label("Dlatmr",60);
}              //  Close for() loop. 
}
if (fulbnd)  {
    {
forloop70:
for (i = 1; i <= npvts; i++) {
k = ipivot[(i)- 1+ _ipivot_offset];
j = iwork[(i)- 1+ _iwork_offset];
iwork[(i)- 1+ _iwork_offset] = iwork[(k)- 1+ _iwork_offset];
iwork[(k)- 1+ _iwork_offset] = j;
Dummy.label("Dlatmr",70);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
int _i_inc = -1;
forloop80:
for (i = npvts; (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
k = ipivot[(i)- 1+ _ipivot_offset];
j = iwork[(i)- 1+ _iwork_offset];
iwork[(i)- 1+ _iwork_offset] = iwork[(k)- 1+ _iwork_offset];
iwork[(k)- 1+ _iwork_offset] = j;
Dummy.label("Dlatmr",80);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
// *
// *     4)      Generate matrices for each kind of PACKing
// *             Always sweep matrix columnwise (if symmetric, upper
// *             half only) so that matrix generated does not depend
// *             on PACK
// *
if (fulbnd)  {
    // *
// *        Use DLATM3 so matrices generated with differing PIVOTing only
// *        differ only in the order of their rows and/or columns.
// *
if (ipack == 0)  {
    if (isym == 0)  {
    {
forloop100:
for (j = 1; j <= n; j++) {
{
forloop90:
for (i = 1; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
a[(Isub.val)- 1+(jsub.val- 1)*lda+ _a_offset] = temp;
a[(jsub.val)- 1+(Isub.val- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",90);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",100);
}              //  Close for() loop. 
}
}              // Close if()
else if (isym == 1)  {
    {
forloop120:
for (j = 1; j <= n; j++) {
{
forloop110:
for (i = 1; i <= m; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
a[(Isub.val)- 1+(jsub.val- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",110);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",120);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              // Close if()
else if (ipack == 1)  {
    // *
{
forloop140:
for (j = 1; j <= n; j++) {
{
forloop130:
for (i = 1; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
a[(mnsub)- 1+(mxsub- 1)*lda+ _a_offset] = temp;
if (mnsub != mxsub)  
    a[(mxsub)- 1+(mnsub- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatmr",130);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",140);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 2)  {
    // *
{
forloop160:
for (j = 1; j <= n; j++) {
{
forloop150:
for (i = 1; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
a[(mxsub)- 1+(mnsub- 1)*lda+ _a_offset] = temp;
if (mnsub != mxsub)  
    a[(mnsub)- 1+(mxsub- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatmr",150);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",160);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 3)  {
    // *
{
forloop180:
for (j = 1; j <= n; j++) {
{
forloop170:
for (i = 1; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
// *
// *                 Compute K = location of (ISUB,JSUB) entry in packed
// *                 array
// *
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
k = mxsub*(mxsub-1)/2+mnsub;
// *
// *                 Convert K to (IISUB,JJSUB) location
// *
jjsub = (k-1)/lda+1;
iisub = k-lda*(jjsub-1);
// *
a[(iisub)- 1+(jjsub- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",170);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",180);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 4)  {
    // *
{
forloop200:
for (j = 1; j <= n; j++) {
{
forloop190:
for (i = 1; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
// *
// *                 Compute K = location of (I,J) entry in packed array
// *
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
if (mnsub == 1)  {
    k = mxsub;
}              // Close if()
else  {
  k = n*(n+1)/2-(n-mnsub+1)*(n-mnsub+2)/2+mxsub-mnsub+1;
}              //  Close else.
// *
// *                 Convert K to (IISUB,JJSUB) location
// *
jjsub = (k-1)/lda+1;
iisub = k-lda*(jjsub-1);
// *
a[(iisub)- 1+(jjsub- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",190);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",200);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 5)  {
    // *
{
forloop220:
for (j = 1; j <= n; j++) {
{
forloop210:
for (i = j-kuu; i <= j; i++) {
if (i < 1)  {
    a[(j-i+1)- 1+(i+n- 1)*lda+ _a_offset] = zero;
}              // Close if()
else  {
  temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
a[(mxsub-mnsub+1)- 1+(mnsub- 1)*lda+ _a_offset] = temp;
}              //  Close else.
Dummy.label("Dlatmr",210);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",220);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 6)  {
    // *
{
forloop240:
for (j = 1; j <= n; j++) {
{
forloop230:
for (i = j-kuu; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
a[(mnsub-mxsub+kuu+1)- 1+(mxsub- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",230);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",240);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 7)  {
    // *
if (isym == 0)  {
    {
forloop260:
for (j = 1; j <= n; j++) {
{
forloop250:
for (i = j-kuu; i <= j; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
mnsub = (int)(Math.min(Isub.val, jsub.val) );
mxsub = (int)(Math.max(Isub.val, jsub.val) );
a[(mnsub-mxsub+kuu+1)- 1+(mxsub- 1)*lda+ _a_offset] = temp;
if (i < 1)  
    a[(j-i+1+kuu)- 1+(i+n- 1)*lda+ _a_offset] = zero;
if (i >= 1 && mnsub != mxsub)  
    a[(mxsub-mnsub+1+kuu)- 1+(mnsub- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",250);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",260);
}              //  Close for() loop. 
}
}              // Close if()
else if (isym == 1)  {
    {
forloop280:
for (j = 1; j <= n; j++) {
{
forloop270:
for (i = j-kuu; i <= j+kll; i++) {
temp = Dlatm3.dlatm3(m,n,i,j,Isub,jsub,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
a[(Isub.val-jsub.val+kuu+1)- 1+(jsub.val- 1)*lda+ _a_offset] = temp;
Dummy.label("Dlatmr",270);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",280);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              // Close else if()
// *
}              // Close if()
else  {
  // *
// *        Use DLATM2
// *
if (ipack == 0)  {
    if (isym == 0)  {
    {
forloop300:
for (j = 1; j <= n; j++) {
{
forloop290:
for (i = 1; i <= j; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
a[(j)- 1+(i- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatmr",290);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",300);
}              //  Close for() loop. 
}
}              // Close if()
else if (isym == 1)  {
    {
forloop320:
for (j = 1; j <= n; j++) {
{
forloop310:
for (i = 1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",310);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",320);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              // Close if()
else if (ipack == 1)  {
    // *
{
forloop340:
for (j = 1; j <= n; j++) {
{
forloop330:
for (i = 1; i <= j; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
if (i != j)  
    a[(j)- 1+(i- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatmr",330);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",340);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 2)  {
    // *
{
forloop360:
for (j = 1; j <= n; j++) {
{
forloop350:
for (i = 1; i <= j; i++) {
a[(j)- 1+(i- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
if (i != j)  
    a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatmr",350);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",360);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 3)  {
    // *
Isub.val = 0;
jsub.val = 1;
{
forloop380:
for (j = 1; j <= n; j++) {
{
forloop370:
for (i = 1; i <= j; i++) {
Isub.val = Isub.val+1;
if (Isub.val > lda)  {
    Isub.val = 1;
jsub.val = jsub.val+1;
}              // Close if()
a[(Isub.val)- 1+(jsub.val- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",370);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",380);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 4)  {
    // *
if (isym == 0)  {
    {
forloop400:
for (j = 1; j <= n; j++) {
{
forloop390:
for (i = 1; i <= j; i++) {
// *
// *                    Compute K = location of (I,J) entry in packed array
// *
if (i == 1)  {
    k = j;
}              // Close if()
else  {
  k = n*(n+1)/2-(n-i+1)*(n-i+2)/2+j-i+1;
}              //  Close else.
// *
// *                    Convert K to (ISUB,JSUB) location
// *
jsub.val = (k-1)/lda+1;
Isub.val = k-lda*(jsub.val-1);
// *
a[(Isub.val)- 1+(jsub.val- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",390);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",400);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  Isub.val = 0;
jsub.val = 1;
{
forloop420:
for (j = 1; j <= n; j++) {
{
forloop410:
for (i = j; i <= m; i++) {
Isub.val = Isub.val+1;
if (Isub.val > lda)  {
    Isub.val = 1;
jsub.val = jsub.val+1;
}              // Close if()
a[(Isub.val)- 1+(jsub.val- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",410);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",420);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close else if()
else if (ipack == 5)  {
    // *
{
forloop440:
for (j = 1; j <= n; j++) {
{
forloop430:
for (i = j-kuu; i <= j; i++) {
if (i < 1)  {
    a[(j-i+1)- 1+(i+n- 1)*lda+ _a_offset] = zero;
}              // Close if()
else  {
  a[(j-i+1)- 1+(i- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
}              //  Close else.
Dummy.label("Dlatmr",430);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",440);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 6)  {
    // *
{
forloop460:
for (j = 1; j <= n; j++) {
{
forloop450:
for (i = j-kuu; i <= j; i++) {
a[(i-j+kuu+1)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",450);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",460);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 7)  {
    // *
if (isym == 0)  {
    {
forloop480:
for (j = 1; j <= n; j++) {
{
forloop470:
for (i = j-kuu; i <= j; i++) {
a[(i-j+kuu+1)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
if (i < 1)  
    a[(j-i+1+kuu)- 1+(i+n- 1)*lda+ _a_offset] = zero;
if (i >= 1 && i != j)  
    a[(j-i+1+kuu)- 1+(i- 1)*lda+ _a_offset] = a[(i-j+kuu+1)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatmr",470);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",480);
}              //  Close for() loop. 
}
}              // Close if()
else if (isym == 1)  {
    {
forloop500:
for (j = 1; j <= n; j++) {
{
forloop490:
for (i = j-kuu; i <= j+kll; i++) {
a[(i-j+kuu+1)- 1+(j- 1)*lda+ _a_offset] = Dlatm2.dlatm2(m,n,i,j,kl,ku,idist,iseed,_iseed_offset,d,_d_offset,igrade,dl,_dl_offset,dr,_dr_offset,ipvtng,iwork,_iwork_offset,sparse);
Dummy.label("Dlatmr",490);
}              //  Close for() loop. 
}
Dummy.label("Dlatmr",500);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              // Close else if()
// *
}              //  Close else.
// *
// *     5)      Scaling the norm
// *
if (ipack == 0)  {
    onorm = Dlange.dlange("M",m,n,a,_a_offset,lda,tempa,0);
}              // Close if()
else if (ipack == 1)  {
    onorm = Dlansy.dlansy("M","U",n,a,_a_offset,lda,tempa,0);
}              // Close else if()
else if (ipack == 2)  {
    onorm = Dlansy.dlansy("M","L",n,a,_a_offset,lda,tempa,0);
}              // Close else if()
else if (ipack == 3)  {
    onorm = Dlansp.dlansp("M","U",n,a,_a_offset,tempa,0);
}              // Close else if()
else if (ipack == 4)  {
    onorm = Dlansp.dlansp("M","L",n,a,_a_offset,tempa,0);
}              // Close else if()
else if (ipack == 5)  {
    onorm = Dlansb.dlansb("M","L",n,kll,a,_a_offset,lda,tempa,0);
}              // Close else if()
else if (ipack == 6)  {
    onorm = Dlansb.dlansb("M","U",n,kuu,a,_a_offset,lda,tempa,0);
}              // Close else if()
else if (ipack == 7)  {
    onorm = Dlangb.dlangb("M",n,kll,kuu,a,_a_offset,lda,tempa,0);
}              // Close else if()
// *
if (anorm >= zero)  {
    // *
if (anorm > zero && onorm == zero)  {
    // *
// *           Desired scaling impossible
// *
info.val = 5;
Dummy.go_to("Dlatmr",999999);
// *
}              // Close if()
else if ((anorm > one && onorm < one) || (anorm < one && onorm > one))  {
    // *
// *           Scale carefully to avoid over / underflow
// *
if (ipack <= 2)  {
    {
forloop510:
for (j = 1; j <= n; j++) {
Dscal.dscal(m,one/onorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dscal.dscal(m,anorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatmr",510);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (ipack == 3 || ipack == 4)  {
    // *
Dscal.dscal(n*(n+1)/2,one/onorm,a,_a_offset,1);
Dscal.dscal(n*(n+1)/2,anorm,a,_a_offset,1);
// *
}              // Close else if()
else if (ipack >= 5)  {
    // *
{
forloop520:
for (j = 1; j <= n; j++) {
Dscal.dscal(kll+kuu+1,one/onorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dscal.dscal(kll+kuu+1,anorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatmr",520);
}              //  Close for() loop. 
}
// *
}              // Close else if()
// *
}              // Close else if()
else  {
  // *
// *           Scale straightforwardly
// *
if (ipack <= 2)  {
    {
forloop530:
for (j = 1; j <= n; j++) {
Dscal.dscal(m,anorm/onorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatmr",530);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (ipack == 3 || ipack == 4)  {
    // *
Dscal.dscal(n*(n+1)/2,anorm/onorm,a,_a_offset,1);
// *
}              // Close else if()
else if (ipack >= 5)  {
    // *
{
forloop540:
for (j = 1; j <= n; j++) {
Dscal.dscal(kll+kuu+1,anorm/onorm,a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dlatmr",540);
}              //  Close for() loop. 
}
}              // Close else if()
// *
}              //  Close else.
// *
}              // Close if()
// *
// *     End of DLATMR
// *
Dummy.label("Dlatmr",999999);
return;
   }
} // End class.
