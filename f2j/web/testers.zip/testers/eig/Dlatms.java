/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlatms {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DLATMS generates random matrices with specified singular values
// *     (or symmetric/hermitian with specified eigenvalues)
// *     for testing LAPACK programs.
// *
// *     DLATMS operates by applying the following sequence of
// *     operations:
// *
// *       Set the diagonal to D, where D may be input or
// *          computed according to MODE, COND, DMAX, and SYM
// *          as described below.
// *
// *       Generate a matrix with the appropriate band structure, by one
// *          of two methods:
// *
// *       Method A:
// *           Generate a dense M x N matrix by multiplying D on the left
// *               and the right by random unitary matrices, then:
// *
// *           Reduce the bandwidth according to KL and KU, using
// *           Householder transformations.
// *
// *       Method B:
// *           Convert the bandwidth-0 (i.e., diagonal) matrix to a
// *               bandwidth-1 matrix using Givens rotations, "chasing"
// *               out-of-band elements back, much as in QR; then
// *               convert the bandwidth-1 to a bandwidth-2 matrix, etc.
// *               Note that for reasonably small bandwidths (relative to
// *               M and N) this requires less storage, as a dense matrix
// *               is not generated.  Also, for symmetric matrices, only
// *               one triangle is generated.
// *
// *       Method A is chosen if the bandwidth is a large fraction of the
// *           order of the matrix, and LDA is at least M (so a dense
// *           matrix can be stored.)  Method B is chosen if the bandwidth
// *           is small (< 1/2 N for symmetric, < .3 N+M for
// *           non-symmetric), or LDA is less than M and not less than the
// *           bandwidth.
// *
// *       Pack the matrix if desired. Options specified by PACK are:
// *          no packing
// *          zero out upper half (if symmetric)
// *          zero out lower half (if symmetric)
// *          store the upper half columnwise (if symmetric or upper
// *                triangular)
// *          store the lower half columnwise (if symmetric or lower
// *                triangular)
// *          store the lower triangle in banded format (if symmetric
// *                or lower triangular)
// *          store the upper triangle in banded format (if symmetric
// *                or upper triangular)
// *          store the entire matrix in banded format
// *       If Method B is chosen, and band format is specified, then the
// *          matrix will be generated in the band format, so no repacking
// *          will be necessary.
// *
// *  Arguments
// *  =========
// *
// *  M      - INTEGER
// *           The number of rows of A. Not modified.
// *
// *  N      - INTEGER
// *           The number of columns of A. Not modified.
// *
// *  DIST   - CHARACTER*1
// *           On entry, DIST specifies the type of distribution to be used
// *           to generate the random eigen-/singular values.
// *           'U' => UNIFORM( 0, 1 )  ( 'U' for uniform )
// *           'S' => UNIFORM( -1, 1 ) ( 'S' for symmetric )
// *           'N' => NORMAL( 0, 1 )   ( 'N' for normal )
// *           Not modified.
// *
// *  ISEED  - INTEGER array, dimension ( 4 )
// *           On entry ISEED specifies the seed of the random number
// *           generator. They should lie between 0 and 4095 inclusive,
// *           and ISEED(4) should be odd. The random number generator
// *           uses a linear congruential sequence limited to small
// *           integers, and so should produce machine independent
// *           random numbers. The values of ISEED are changed on
// *           exit, and can be used in the next call to DLATMS
// *           to continue the same random number sequence.
// *           Changed on exit.
// *
// *  SYM    - CHARACTER*1
// *           If SYM='S' or 'H', the generated matrix is symmetric, with
// *             eigenvalues specified by D, COND, MODE, and DMAX; they
// *             may be positive, negative, or zero.
// *           If SYM='P', the generated matrix is symmetric, with
// *             eigenvalues (= singular values) specified by D, COND,
// *             MODE, and DMAX; they will not be negative.
// *           If SYM='N', the generated matrix is nonsymmetric, with
// *             singular values specified by D, COND, MODE, and DMAX;
// *             they will not be negative.
// *           Not modified.
// *
// *  D      - DOUBLE PRECISION array, dimension ( MIN( M , N ) )
// *           This array is used to specify the singular values or
// *           eigenvalues of A (see SYM, above.)  If MODE=0, then D is
// *           assumed to contain the singular/eigenvalues, otherwise
// *           they will be computed according to MODE, COND, and DMAX,
// *           and placed in D.
// *           Modified if MODE is nonzero.
// *
// *  MODE   - INTEGER
// *           On entry this describes how the singular/eigenvalues are to
// *           be specified:
// *           MODE = 0 means use D as input
// *           MODE = 1 sets D(1)=1 and D(2:N)=1.0/COND
// *           MODE = 2 sets D(1:N-1)=1 and D(N)=1.0/COND
// *           MODE = 3 sets D(I)=COND**(-(I-1)/(N-1))
// *           MODE = 4 sets D(i)=1 - (i-1)/(N-1)*(1 - 1/COND)
// *           MODE = 5 sets D to random numbers in the range
// *                    ( 1/COND , 1 ) such that their logarithms
// *                    are uniformly distributed.
// *           MODE = 6 set D to random numbers from same distribution
// *                    as the rest of the matrix.
// *           MODE < 0 has the same meaning as ABS(MODE), except that
// *              the order of the elements of D is reversed.
// *           Thus if MODE is positive, D has entries ranging from
// *              1 to 1/COND, if negative, from 1/COND to 1,
// *           If SYM='S' or 'H', and MODE is neither 0, 6, nor -6, then
// *              the elements of D will also be multiplied by a random
// *              sign (i.e., +1 or -1.)
// *           Not modified.
// *
// *  COND   - DOUBLE PRECISION
// *           On entry, this is used as described under MODE above.
// *           If used, it must be >= 1. Not modified.
// *
// *  DMAX   - DOUBLE PRECISION
// *           If MODE is neither -6, 0 nor 6, the contents of D, as
// *           computed according to MODE and COND, will be scaled by
// *           DMAX / max(abs(D(i))); thus, the maximum absolute eigen- or
// *           singular value (which is to say the norm) will be abs(DMAX).
// *           Note that DMAX need not be positive: if DMAX is negative
// *           (or zero), D will be scaled by a negative number (or zero).
// *           Not modified.
// *
// *  KL     - INTEGER
// *           This specifies the lower bandwidth of the  matrix. For
// *           example, KL=0 implies upper triangular, KL=1 implies upper
// *           Hessenberg, and KL being at least M-1 means that the matrix
// *           has full lower bandwidth.  KL must equal KU if the matrix
// *           is symmetric.
// *           Not modified.
// *
// *  KU     - INTEGER
// *           This specifies the upper bandwidth of the  matrix. For
// *           example, KU=0 implies lower triangular, KU=1 implies lower
// *           Hessenberg, and KU being at least N-1 means that the matrix
// *           has full upper bandwidth.  KL must equal KU if the matrix
// *           is symmetric.
// *           Not modified.
// *
// *  PACK   - CHARACTER*1
// *           This specifies packing of matrix as follows:
// *           'N' => no packing
// *           'U' => zero out all subdiagonal entries (if symmetric)
// *           'L' => zero out all superdiagonal entries (if symmetric)
// *           'C' => store the upper triangle columnwise
// *                  (only if the matrix is symmetric or upper triangular)
// *           'R' => store the lower triangle columnwise
// *                  (only if the matrix is symmetric or lower triangular)
// *           'B' => store the lower triangle in band storage scheme
// *                  (only if matrix symmetric or lower triangular)
// *           'Q' => store the upper triangle in band storage scheme
// *                  (only if matrix symmetric or upper triangular)
// *           'Z' => store the entire matrix in band storage scheme
// *                      (pivoting can be provided for by using this
// *                      option to store A in the trailing rows of
// *                      the allocated storage)
// *
// *           Using these options, the various LAPACK packed and banded
// *           storage schemes can be obtained:
// *           GB               - use 'Z'
// *           PB, SB or TB     - use 'B' or 'Q'
// *           PP, SP or TP     - use 'C' or 'R'
// *
// *           If two calls to DLATMS differ only in the PACK parameter,
// *           they will generate mathematically equivalent matrices.
// *           Not modified.
// *
// *  A      - DOUBLE PRECISION array, dimension ( LDA, N )
// *           On exit A is the desired test matrix.  A is first generated
// *           in full (unpacked) form, and then packed, if so specified
// *           by PACK.  Thus, the first M elements of the first N
// *           columns will always be modified.  If PACK specifies a
// *           packed or banded storage scheme, all LDA elements of the
// *           first N columns will be modified; the elements of the
// *           array which do not correspond to elements of the generated
// *           matrix are set to zero.
// *           Modified.
// *
// *  LDA    - INTEGER
// *           LDA specifies the first dimension of A as declared in the
// *           calling program.  If PACK='N', 'U', 'L', 'C', or 'R', then
// *           LDA must be at least M.  If PACK='B' or 'Q', then LDA must
// *           be at least MIN( KL, M-1) (which is equal to MIN(KU,N-1)).
// *           If PACK='Z', LDA must be large enough to hold the packed
// *           array: MIN( KU, N-1) + MIN( KL, M-1) + 1.
// *           Not modified.
// *
// *  WORK   - DOUBLE PRECISION array, dimension ( 3*MAX( N , M ) )
// *           Workspace.
// *           Modified.
// *
// *  INFO   - INTEGER
// *           Error code.  On exit, INFO will be set to one of the
// *           following values:
// *             0 => normal return
// *            -1 => M negative or unequal to N and SYM='S', 'H', or 'P'
// *            -2 => N negative
// *            -3 => DIST illegal string
// *            -5 => SYM illegal string
// *            -7 => MODE not in range -6 to 6
// *            -8 => COND less than 1.0, and MODE neither -6, 0 nor 6
// *           -10 => KL negative
// *           -11 => KU negative, or SYM='S' or 'H' and KU not equal to KL
// *           -12 => PACK illegal string, or PACK='U' or 'L', and SYM='N';
// *                  or PACK='C' or 'Q' and SYM='N' and KL is not zero;
// *                  or PACK='R' or 'B' and SYM='N' and KU is not zero;
// *                  or PACK='U', 'L', 'C', 'R', 'B', or 'Q', and M is not
// *                  N.
// *           -14 => LDA is less than M, or PACK='Z' and LDA is less than
// *                  MIN(KU,N-1) + MIN(KL,M-1) + 1.
// *            1  => Error return from DLATM1
// *            2  => Cannot scale to DMAX (max. sing. value is 0)
// *            3  => Error return from DLAGGE or SLAGSY
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double twopi= 6.2831853071795864769252867663e+0;
// *     ..
// *     .. Local Scalars ..
static boolean givens= false;
static boolean ilextr= false;
static boolean iltemp= false;
static boolean topdwn= false;
static int i= 0;
static int ic= 0;
static int icol= 0;
static int idist= 0;
static int iendch= 0;
static intW iinfo= new intW(0);
static int il= 0;
static int ilda= 0;
static int ioffg= 0;
static int ioffst= 0;
static int ipack= 0;
static int ipackg= 0;
static int ir= 0;
static int ir1= 0;
static int ir2= 0;
static int irow= 0;
static int irsign= 0;
static int iskew= 0;
static int isym= 0;
static int isympk= 0;
static int j= 0;
static int jc= 0;
static int jch= 0;
static int jkl= 0;
static int jku= 0;
static int jr= 0;
static int k= 0;
static int llb= 0;
static int minlda= 0;
static int mnmin= 0;
static int mr= 0;
static int nc= 0;
static int uub= 0;
static double alpha= 0.0;
static double angle= 0.0;
static doubleW c= new doubleW(0.0);
static doubleW dummy= new doubleW(0.0);
static doubleW extra= new doubleW(0.0);
static doubleW s= new doubleW(0.0);
static doubleW temp= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Decode and Test the input parameters.
// *             Initialize flags & seed.
// *

public static void dlatms (int m,
int n,
String dist,
int [] iseed, int _iseed_offset,
String sym,
double [] d, int _d_offset,
int mode,
double cond,
double dmax,
int kl,
int ku,
String pack,
double [] a, int _a_offset,
int lda,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
// *
// *     Quick return if possible
// *
if (m == 0 || n == 0)  
    Dummy.go_to("Dlatms",999999);
// *
// *     Decode DIST
// *
if ((dist.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    idist = 1;
}              // Close if()
else if ((dist.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    idist = 2;
}              // Close else if()
else if ((dist.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idist = 3;
}              // Close else if()
else  {
  idist = -1;
}              //  Close else.
// *
// *     Decode SYM
// *
if ((sym.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    isym = 1;
irsign = 0;
}              // Close if()
else if ((sym.toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)))  {
    isym = 2;
irsign = 0;
}              // Close else if()
else if ((sym.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)))  {
    isym = 2;
irsign = 1;
}              // Close else if()
else if ((sym.toLowerCase().charAt(0) == "H".toLowerCase().charAt(0)))  {
    isym = 2;
irsign = 1;
}              // Close else if()
else  {
  isym = -1;
}              //  Close else.
// *
// *     Decode PACK
// *
isympk = 0;
if ((pack.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ipack = 0;
}              // Close if()
else if ((pack.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    ipack = 1;
isympk = 1;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    ipack = 2;
isympk = 1;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    ipack = 3;
isympk = 2;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    ipack = 4;
isympk = 3;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "B".toLowerCase().charAt(0)))  {
    ipack = 5;
isympk = 3;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0)))  {
    ipack = 6;
isympk = 2;
}              // Close else if()
else if ((pack.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0)))  {
    ipack = 7;
}              // Close else if()
else  {
  ipack = -1;
}              //  Close else.
// *
// *     Set certain internal parameters
// *
mnmin = (int)(Math.min(m, n) );
llb = (int)(Math.min(kl, m-1) );
uub = (int)(Math.min(ku, n-1) );
mr = (int)(Math.min(m, n+llb) );
nc = (int)(Math.min(n, m+uub) );
// *
if (ipack == 5 || ipack == 6)  {
    minlda = uub+1;
}              // Close if()
else if (ipack == 7)  {
    minlda = llb+uub+1;
}              // Close else if()
else  {
  minlda = m;
}              //  Close else.
// *
// *     Use Givens rotation method if bandwidth small enough,
// *     or if LDA is too small to store the matrix unpacked.
// *
givens = false;
if (isym == 1)  {
    if ((double)(llb+uub) < 0.3e0*(double)(Math.max(1, mr+nc) ))  
    givens = true;
}              // Close if()
else  {
  if (2*llb < m)  
    givens = true;
}              //  Close else.
if (lda < m && lda >= minlda)  
    givens = true;
// *
// *     Set INFO if an error
// *
if (m < 0)  {
    info.val = -1;
}              // Close if()
else if (m != n && isym != 1)  {
    info.val = -1;
}              // Close else if()
else if (n < 0)  {
    info.val = -2;
}              // Close else if()
else if (idist == -1)  {
    info.val = -3;
}              // Close else if()
else if (isym == -1)  {
    info.val = -5;
}              // Close else if()
else if (Math.abs(mode) > 6)  {
    info.val = -7;
}              // Close else if()
else if ((mode != 0 && Math.abs(mode) != 6) && cond < one)  {
    info.val = -8;
}              // Close else if()
else if (kl < 0)  {
    info.val = -10;
}              // Close else if()
else if (ku < 0 || (isym != 1 && kl != ku))  {
    info.val = -11;
}              // Close else if()
else if (ipack == -1 || (isympk == 1 && isym == 1) || (isympk == 2 && isym == 1 && kl > 0) || (isympk == 3 && isym == 1 && ku > 0) || (isympk != 0 && m != n))  {
    info.val = -12;
}              // Close else if()
else if (lda < Math.max(1, minlda) )  {
    info.val = -14;
}              // Close else if()
// *
if (info.val != 0)  {
    Xerbla.xerbla("DLATMS",-info.val);
Dummy.go_to("Dlatms",999999);
}              // Close if()
// *
// *     Initialize random number generator
// *
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1+ _iseed_offset] = (Math.abs(iseed[(i)- 1+ _iseed_offset]))%(4096) ;
Dummy.label("Dlatms",10);
}              //  Close for() loop. 
}
// *
if ((iseed[(4)- 1+ _iseed_offset])%(2)  != 1)  
    iseed[(4)- 1+ _iseed_offset] = iseed[(4)- 1+ _iseed_offset]+1;
// *
// *     2)      Set up D  if indicated.
// *
// *             Compute D according to COND and MODE
// *
Dlatm1.dlatm1(mode,cond,irsign,idist,iseed,_iseed_offset,d,_d_offset,mnmin,iinfo);
if (iinfo.val != 0)  {
    info.val = 1;
Dummy.go_to("Dlatms",999999);
}              // Close if()
// *
// *     Choose Top-Down if D is (apparently) increasing,
// *     Bottom-Up if D is (apparently) decreasing.
// *
if (Math.abs(d[(1)- 1+ _d_offset]) <= Math.abs(d[(mnmin)- 1+ _d_offset]))  {
    topdwn = true;
}              // Close if()
else  {
  topdwn = false;
}              //  Close else.
// *
if (mode != 0 && Math.abs(mode) != 6)  {
    // *
// *        Scale by DMAX
// *
temp.val = Math.abs(d[(1)- 1+ _d_offset]);
{
forloop20:
for (i = 2; i <= mnmin; i++) {
temp.val = Math.max(temp.val, Math.abs(d[(i)- 1+ _d_offset])) ;
Dummy.label("Dlatms",20);
}              //  Close for() loop. 
}
// *
if (temp.val > zero)  {
    alpha = dmax/temp.val;
}              // Close if()
else  {
  info.val = 2;
Dummy.go_to("Dlatms",999999);
}              //  Close else.
// *
Dscal.dscal(mnmin,alpha,d,_d_offset,1);
// *
}              // Close if()
// *
// *     3)      Generate Banded Matrix using Givens rotations.
// *             Also the special case of UUB=LLB=0
// *
// *               Compute Addressing constants to cover all
// *               storage formats.  Whether GE, SY, GB, or SB,
// *               upper or lower triangle or both,
// *               the (i,j)-th element is in
// *               A( i - ISKEW*j + IOFFST, j )
// *
if (ipack > 4)  {
    ilda = lda-1;
iskew = 1;
if (ipack > 5)  {
    ioffst = uub+1;
}              // Close if()
else  {
  ioffst = 1;
}              //  Close else.
}              // Close if()
else  {
  ilda = lda;
iskew = 0;
ioffst = 0;
}              //  Close else.
// *
// *     IPACKG is the format that the matrix is generated in. If this is
// *     different from IPACK, then the matrix must be repacked at the
// *     end.  It also signals how to compute the norm, for scaling.
// *
ipackg = 0;
Dlaset.dlaset("Full",lda,n,zero,zero,a,_a_offset,lda);
// *
// *     Diagonal Matrix -- We are done, unless it
// *     is to be stored SP/PP/TP (PACK='R' or 'C')
// *
if (llb == 0 && uub == 0)  {
    Dcopy.dcopy(mnmin,d,_d_offset,1,a,(1-iskew+ioffst)- 1+(1- 1)*lda+ _a_offset,ilda+1);
if (ipack <= 2 || ipack >= 5)  
    ipackg = ipack;
// *
}              // Close if()
else if (givens)  {
    // *
// *        Check whether to use Givens rotations,
// *        Householder transformations, or nothing.
// *
if (isym == 1)  {
    // *
// *           Non-symmetric -- A = U D V
// *
if (ipack > 4)  {
    ipackg = ipack;
}              // Close if()
else  {
  ipackg = 0;
}              //  Close else.
// *
Dcopy.dcopy(mnmin,d,_d_offset,1,a,(1-iskew+ioffst)- 1+(1- 1)*lda+ _a_offset,ilda+1);
// *
if (topdwn)  {
    jkl = 0;
{
forloop50:
for (jku = 1; jku <= uub; jku++) {
// *
// *                 Transform from bandwidth JKL, JKU-1 to JKL, JKU
// *
// *                 Last row actually rotated is M
// *                 Last column actually rotated is MIN( M+JKU, N )
// *
{
forloop40:
for (jr = 1; jr <= Math.min(m+jku, n) +jkl-1; jr++) {
extra.val = zero;
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = Math.sin(angle);
icol = (int)(Math.max(1, jr-jkl) );
if (jr < m)  {
    il = (int)(Math.min(n, jr+jku) +1-icol);
Dlarot.dlarot(true,jr > jkl,false,il,c.val,s.val,a,(jr-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,extra,dummy);
}              // Close if()
// *
// *                    Chase "EXTRA" back up
// *
ir = jr;
ic = icol;
{
int _jch_inc = -jkl-jku;
forloop30:
for (jch = jr-jkl; (_jch_inc < 0) ? jch >= 1 : jch <= 1; jch += _jch_inc) {
if (ir < m)  {
    Dlartg.dlartg(a[(ir+1-iskew*(ic+1)+ioffst)- 1+(ic+1- 1)*lda+ _a_offset],extra.val,c,s,dummy);
}              // Close if()
irow = (int)(Math.max(1, jch-jku) );
il = ir+2-irow;
temp.val = zero;
iltemp = jch > jku;
Dlarot.dlarot(false,iltemp,true,il,c.val,-s.val,a,(irow-iskew*ic+ioffst)- 1+(ic- 1)*lda+ _a_offset,ilda,temp,extra);
if (iltemp)  {
    Dlartg.dlartg(a[(irow+1-iskew*(ic+1)+ioffst)- 1+(ic+1- 1)*lda+ _a_offset],temp.val,c,s,dummy);
icol = (int)(Math.max(1, jch-jku-jkl) );
il = ic+2-icol;
extra.val = zero;
Dlarot.dlarot(true,jch > jku+jkl,true,il,c.val,-s.val,a,(irow-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,extra,temp);
ic = icol;
ir = irow;
}              // Close if()
Dummy.label("Dlatms",30);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",40);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",50);
}              //  Close for() loop. 
}
// *
jku = uub;
{
forloop80:
for (jkl = 1; jkl <= llb; jkl++) {
// *
// *                 Transform from bandwidth JKL-1, JKU to JKL, JKU
// *
{
forloop70:
for (jc = 1; jc <= Math.min(n+jkl, m) +jku-1; jc++) {
extra.val = zero;
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = Math.sin(angle);
irow = (int)(Math.max(1, jc-jku) );
if (jc < n)  {
    il = (int)(Math.min(m, jc+jkl) +1-irow);
Dlarot.dlarot(false,jc > jku,false,il,c.val,s.val,a,(irow-iskew*jc+ioffst)- 1+(jc- 1)*lda+ _a_offset,ilda,extra,dummy);
}              // Close if()
// *
// *                    Chase "EXTRA" back up
// *
ic = jc;
ir = irow;
{
int _jch_inc = -jkl-jku;
forloop60:
for (jch = jc-jku; (_jch_inc < 0) ? jch >= 1 : jch <= 1; jch += _jch_inc) {
if (ic < n)  {
    Dlartg.dlartg(a[(ir+1-iskew*(ic+1)+ioffst)- 1+(ic+1- 1)*lda+ _a_offset],extra.val,c,s,dummy);
}              // Close if()
icol = (int)(Math.max(1, jch-jkl) );
il = ic+2-icol;
temp.val = zero;
iltemp = jch > jkl;
Dlarot.dlarot(true,iltemp,true,il,c.val,-s.val,a,(ir-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,temp,extra);
if (iltemp)  {
    Dlartg.dlartg(a[(ir+1-iskew*(icol+1)+ioffst)- 1+(icol+1- 1)*lda+ _a_offset],temp.val,c,s,dummy);
irow = (int)(Math.max(1, jch-jkl-jku) );
il = ir+2-irow;
extra.val = zero;
Dlarot.dlarot(false,jch > jkl+jku,true,il,c.val,-s.val,a,(irow-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,extra,temp);
ic = icol;
ir = irow;
}              // Close if()
Dummy.label("Dlatms",60);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",70);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",80);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *              Bottom-Up -- Start at the bottom right.
// *
jkl = 0;
{
forloop110:
for (jku = 1; jku <= uub; jku++) {
// *
// *                 Transform from bandwidth JKL, JKU-1 to JKL, JKU
// *
// *                 First row actually rotated is M
// *                 First column actually rotated is MIN( M+JKU, N )
// *
iendch = (int)(Math.min(m, n+jkl) -1);
{
int _jc_inc = -1;
forloop100:
for (jc = (int)(Math.min(m+jku, n) -1); (_jc_inc < 0) ? jc >= 1-jkl : jc <= 1-jkl; jc += _jc_inc) {
extra.val = zero;
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = Math.sin(angle);
irow = (int)(Math.max(1, jc-jku+1) );
if (jc > 0)  {
    il = (int)(Math.min(m, jc+jkl+1) +1-irow);
Dlarot.dlarot(false,false,jc+jkl < m,il,c.val,s.val,a,(irow-iskew*jc+ioffst)- 1+(jc- 1)*lda+ _a_offset,ilda,dummy,extra);
}              // Close if()
// *
// *                    Chase "EXTRA" back down
// *
ic = jc;
{
int _jch_inc = jkl+jku;
forloop90:
for (jch = jc+jkl; (_jch_inc < 0) ? jch >= iendch : jch <= iendch; jch += _jch_inc) {
ilextr = ic > 0;
if (ilextr)  {
    Dlartg.dlartg(a[(jch-iskew*ic+ioffst)- 1+(ic- 1)*lda+ _a_offset],extra.val,c,s,dummy);
}              // Close if()
ic = (int)(Math.max(1, ic) );
icol = (int)(Math.min(n-1, jch+jku) );
iltemp = jch+jku < n;
temp.val = zero;
Dlarot.dlarot(true,ilextr,iltemp,icol+2-ic,c.val,s.val,a,(jch-iskew*ic+ioffst)- 1+(ic- 1)*lda+ _a_offset,ilda,extra,temp);
if (iltemp)  {
    Dlartg.dlartg(a[(jch-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset],temp.val,c,s,dummy);
il = (int)(Math.min(iendch, jch+jkl+jku) +2-jch);
extra.val = zero;
Dlarot.dlarot(false,true,jch+jkl+jku <= iendch,il,c.val,s.val,a,(jch-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,temp,extra);
ic = icol;
}              // Close if()
Dummy.label("Dlatms",90);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",100);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",110);
}              //  Close for() loop. 
}
// *
jku = uub;
{
forloop140:
for (jkl = 1; jkl <= llb; jkl++) {
// *
// *                 Transform from bandwidth JKL-1, JKU to JKL, JKU
// *
// *                 First row actually rotated is MIN( N+JKL, M )
// *                 First column actually rotated is N
// *
iendch = (int)(Math.min(n, m+jku) -1);
{
int _jr_inc = -1;
forloop130:
for (jr = (int)(Math.min(n+jkl, m) -1); (_jr_inc < 0) ? jr >= 1-jku : jr <= 1-jku; jr += _jr_inc) {
extra.val = zero;
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = Math.sin(angle);
icol = (int)(Math.max(1, jr-jkl+1) );
if (jr > 0)  {
    il = (int)(Math.min(n, jr+jku+1) +1-icol);
Dlarot.dlarot(true,false,jr+jku < n,il,c.val,s.val,a,(jr-iskew*icol+ioffst)- 1+(icol- 1)*lda+ _a_offset,ilda,dummy,extra);
}              // Close if()
// *
// *                    Chase "EXTRA" back down
// *
ir = jr;
{
int _jch_inc = jkl+jku;
forloop120:
for (jch = jr+jku; (_jch_inc < 0) ? jch >= iendch : jch <= iendch; jch += _jch_inc) {
ilextr = ir > 0;
if (ilextr)  {
    Dlartg.dlartg(a[(ir-iskew*jch+ioffst)- 1+(jch- 1)*lda+ _a_offset],extra.val,c,s,dummy);
}              // Close if()
ir = (int)(Math.max(1, ir) );
irow = (int)(Math.min(m-1, jch+jkl) );
iltemp = jch+jkl < m;
temp.val = zero;
Dlarot.dlarot(false,ilextr,iltemp,irow+2-ir,c.val,s.val,a,(ir-iskew*jch+ioffst)- 1+(jch- 1)*lda+ _a_offset,ilda,extra,temp);
if (iltemp)  {
    Dlartg.dlartg(a[(irow-iskew*jch+ioffst)- 1+(jch- 1)*lda+ _a_offset],temp.val,c,s,dummy);
il = (int)(Math.min(iendch, jch+jkl+jku) +2-jch);
extra.val = zero;
Dlarot.dlarot(true,true,jch+jkl+jku <= iendch,il,c.val,s.val,a,(irow-iskew*jch+ioffst)- 1+(jch- 1)*lda+ _a_offset,ilda,temp,extra);
ir = irow;
}              // Close if()
Dummy.label("Dlatms",120);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",130);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",140);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close if()
else  {
  // *
// *           Symmetric -- A = U D U'
// *
ipackg = ipack;
ioffg = ioffst;
// *
if (topdwn)  {
    // *
// *              Top-Down -- Generate Upper triangle only
// *
if (ipack >= 5)  {
    ipackg = 6;
ioffg = uub+1;
}              // Close if()
else  {
  ipackg = 1;
}              //  Close else.
Dcopy.dcopy(mnmin,d,_d_offset,1,a,(1-iskew+ioffg)- 1+(1- 1)*lda+ _a_offset,ilda+1);
// *
{
forloop170:
for (k = 1; k <= uub; k++) {
{
forloop160:
for (jc = 1; jc <= n-1; jc++) {
irow = (int)(Math.max(1, jc-k) );
il = (int)(Math.min(jc+1, k+2) );
extra.val = zero;
temp.val = a[(jc-iskew*(jc+1)+ioffg)- 1+(jc+1- 1)*lda+ _a_offset];
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = Math.sin(angle);
Dlarot.dlarot(false,jc > k,true,il,c.val,s.val,a,(irow-iskew*jc+ioffg)- 1+(jc- 1)*lda+ _a_offset,ilda,extra,temp);
Dlarot.dlarot(true,true,false,(int) ( Math.min(k, n-jc) +1),c.val,s.val,a,((1-iskew)*jc+ioffg)- 1+(jc- 1)*lda+ _a_offset,ilda,temp,dummy);
// *
// *                    Chase EXTRA back up the matrix
// *
icol = jc;
{
int _jch_inc = -k;
forloop150:
for (jch = jc-k; (_jch_inc < 0) ? jch >= 1 : jch <= 1; jch += _jch_inc) {
Dlartg.dlartg(a[(jch+1-iskew*(icol+1)+ioffg)- 1+(icol+1- 1)*lda+ _a_offset],extra.val,c,s,dummy);
temp.val = a[(jch-iskew*(jch+1)+ioffg)- 1+(jch+1- 1)*lda+ _a_offset];
Dlarot.dlarot(true,true,true,k+2,c.val,-s.val,a,((1-iskew)*jch+ioffg)- 1+(jch- 1)*lda+ _a_offset,ilda,temp,extra);
irow = (int)(Math.max(1, jch-k) );
il = (int)(Math.min(jch+1, k+2) );
extra.val = zero;
Dlarot.dlarot(false,jch > k,true,il,c.val,-s.val,a,(irow-iskew*jch+ioffg)- 1+(jch- 1)*lda+ _a_offset,ilda,extra,temp);
icol = jch;
Dummy.label("Dlatms",150);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",160);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",170);
}              //  Close for() loop. 
}
// *
// *              If we need lower triangle, copy from upper. Note that
// *              the order of copying is chosen to work for 'q' -> 'b'
// *
if (ipack != ipackg && ipack != 3)  {
    {
forloop190:
for (jc = 1; jc <= n; jc++) {
irow = ioffst-iskew*jc;
{
forloop180:
for (jr = jc; jr <= Math.min(n, jc+uub) ; jr++) {
a[(jr+irow)- 1+(jc- 1)*lda+ _a_offset] = a[(jc-iskew*jr+ioffg)- 1+(jr- 1)*lda+ _a_offset];
Dummy.label("Dlatms",180);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",190);
}              //  Close for() loop. 
}
if (ipack == 5)  {
    {
forloop210:
for (jc = n-uub+1; jc <= n; jc++) {
{
forloop200:
for (jr = n+2-jc; jr <= uub+1; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",200);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",210);
}              //  Close for() loop. 
}
}              // Close if()
if (ipackg == 6)  {
    ipackg = ipack;
}              // Close if()
else  {
  ipackg = 0;
}              //  Close else.
}              // Close if()
}              // Close if()
else  {
  // *
// *              Bottom-Up -- Generate Lower triangle only
// *
if (ipack >= 5)  {
    ipackg = 5;
if (ipack == 6)  
    ioffg = 1;
}              // Close if()
else  {
  ipackg = 2;
}              //  Close else.
Dcopy.dcopy(mnmin,d,_d_offset,1,a,(1-iskew+ioffg)- 1+(1- 1)*lda+ _a_offset,ilda+1);
// *
{
forloop240:
for (k = 1; k <= uub; k++) {
{
int _jc_inc = -1;
forloop230:
for (jc = n-1; (_jc_inc < 0) ? jc >= 1 : jc <= 1; jc += _jc_inc) {
il = (int)(Math.min(n+1-jc, k+2) );
extra.val = zero;
temp.val = a[(1+(1-iskew)*jc+ioffg)- 1+(jc- 1)*lda+ _a_offset];
angle = twopi*Dlarnd.dlarnd(1,iseed,_iseed_offset);
c.val = Math.cos(angle);
s.val = -Math.sin(angle);
Dlarot.dlarot(false,true,n-jc > k,il,c.val,s.val,a,((1-iskew)*jc+ioffg)- 1+(jc- 1)*lda+ _a_offset,ilda,temp,extra);
icol = (int)(Math.max(1, jc-k+1) );
Dlarot.dlarot(true,false,true,jc+2-icol,c.val,s.val,a,(jc-iskew*icol+ioffg)- 1+(icol- 1)*lda+ _a_offset,ilda,dummy,temp);
// *
// *                    Chase EXTRA back down the matrix
// *
icol = jc;
{
int _jch_inc = k;
forloop220:
for (jch = jc+k; (_jch_inc < 0) ? jch >= n-1 : jch <= n-1; jch += _jch_inc) {
Dlartg.dlartg(a[(jch-iskew*icol+ioffg)- 1+(icol- 1)*lda+ _a_offset],extra.val,c,s,dummy);
temp.val = a[(1+(1-iskew)*jch+ioffg)- 1+(jch- 1)*lda+ _a_offset];
Dlarot.dlarot(true,true,true,k+2,c.val,s.val,a,(jch-iskew*icol+ioffg)- 1+(icol- 1)*lda+ _a_offset,ilda,extra,temp);
il = (int)(Math.min(n+1-jch, k+2) );
extra.val = zero;
Dlarot.dlarot(false,true,n-jch > k,il,c.val,s.val,a,((1-iskew)*jch+ioffg)- 1+(jch- 1)*lda+ _a_offset,ilda,temp,extra);
icol = jch;
Dummy.label("Dlatms",220);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",230);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",240);
}              //  Close for() loop. 
}
// *
// *              If we need upper triangle, copy from lower. Note that
// *              the order of copying is chosen to work for 'b' -> 'q'
// *
if (ipack != ipackg && ipack != 4)  {
    {
int _jc_inc = -1;
forloop260:
for (jc = n; (_jc_inc < 0) ? jc >= 1 : jc <= 1; jc += _jc_inc) {
irow = ioffst-iskew*jc;
{
int _jr_inc = -1;
forloop250:
for (jr = jc; (_jr_inc < 0) ? jr >= Math.max(1, jc-uub)  : jr <= Math.max(1, jc-uub) ; jr += _jr_inc) {
a[(jr+irow)- 1+(jc- 1)*lda+ _a_offset] = a[(jc-iskew*jr+ioffg)- 1+(jr- 1)*lda+ _a_offset];
Dummy.label("Dlatms",250);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",260);
}              //  Close for() loop. 
}
if (ipack == 6)  {
    {
forloop280:
for (jc = 1; jc <= uub; jc++) {
{
forloop270:
for (jr = 1; jr <= uub+1-jc; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",270);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",280);
}              //  Close for() loop. 
}
}              // Close if()
if (ipackg == 5)  {
    ipackg = ipack;
}              // Close if()
else  {
  ipackg = 0;
}              //  Close else.
}              // Close if()
}              //  Close else.
}              //  Close else.
// *
}              // Close else if()
else  {
  // *
// *        4)      Generate Banded Matrix by first
// *                Rotating by random Unitary matrices,
// *                then reducing the bandwidth using Householder
// *                transformations.
// *
// *                Note: we should get here only if LDA .ge. N
// *
if (isym == 1)  {
    // *
// *           Non-symmetric -- A = U D V
// *
Dlagge.dlagge(mr,nc,llb,uub,d,_d_offset,a,_a_offset,lda,iseed,_iseed_offset,work,_work_offset,iinfo);
}              // Close if()
else  {
  // *
// *           Symmetric -- A = U D U'
// *
Dlagsy.dlagsy(m,llb,d,_d_offset,a,_a_offset,lda,iseed,_iseed_offset,work,_work_offset,iinfo);
// *
}              //  Close else.
if (iinfo.val != 0)  {
    info.val = 3;
Dummy.go_to("Dlatms",999999);
}              // Close if()
}              //  Close else.
// *
// *     5)      Pack the matrix
// *
if (ipack != ipackg)  {
    if (ipack == 1)  {
    // *
// *           'U' -- Upper triangular, not packed
// *
{
forloop300:
for (j = 1; j <= m; j++) {
{
forloop290:
for (i = j+1; i <= m; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",290);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",300);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (ipack == 2)  {
    // *
// *           'L' -- Lower triangular, not packed
// *
{
forloop320:
for (j = 2; j <= m; j++) {
{
forloop310:
for (i = 1; i <= j-1; i++) {
a[(i)- 1+(j- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",310);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",320);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 3)  {
    // *
// *           'C' -- Upper triangle packed Columnwise.
// *
icol = 1;
irow = 0;
{
forloop340:
for (j = 1; j <= m; j++) {
{
forloop330:
for (i = 1; i <= j; i++) {
irow = irow+1;
if (irow > lda)  {
    irow = 1;
icol = icol+1;
}              // Close if()
a[(irow)- 1+(icol- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatms",330);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",340);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack == 4)  {
    // *
// *           'R' -- Lower triangle packed Columnwise.
// *
icol = 1;
irow = 0;
{
forloop360:
for (j = 1; j <= m; j++) {
{
forloop350:
for (i = j; i <= m; i++) {
irow = irow+1;
if (irow > lda)  {
    irow = 1;
icol = icol+1;
}              // Close if()
a[(irow)- 1+(icol- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatms",350);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",360);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (ipack >= 5)  {
    // *
// *           'B' -- The lower triangle is packed as a band matrix.
// *           'Q' -- The upper triangle is packed as a band matrix.
// *           'Z' -- The whole matrix is packed as a band matrix.
// *
if (ipack == 5)  
    uub = 0;
if (ipack == 6)  
    llb = 0;
// *
{
forloop380:
for (j = 1; j <= uub; j++) {
{
int _i_inc = -1;
forloop370:
for (i = (int)(Math.min(j+llb, m) ); (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
a[(i-j+uub+1)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatms",370);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",380);
}              //  Close for() loop. 
}
// *
{
forloop400:
for (j = uub+2; j <= n; j++) {
{
forloop390:
for (i = j-uub; i <= Math.min(j+llb, m) ; i++) {
a[(i-j+uub+1)- 1+(j- 1)*lda+ _a_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dlatms",390);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",400);
}              //  Close for() loop. 
}
}              // Close else if()
// *
// *        If packed, zero out extraneous elements.
// *
// *        Symmetric/Triangular Packed --
// *        zero out everything after A(IROW,ICOL)
// *
if (ipack == 3 || ipack == 4)  {
    {
forloop420:
for (jc = icol; jc <= m; jc++) {
{
forloop410:
for (jr = irow+1; jr <= lda; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",410);
}              //  Close for() loop. 
}
irow = 0;
Dummy.label("Dlatms",420);
}              //  Close for() loop. 
}
// *
}              // Close if()
else if (ipack >= 5)  {
    // *
// *           Packed Band --
// *              1st row is now in A( UUB+2-j, j), zero above it
// *              m-th row is now in A( M+UUB-j,j), zero below it
// *              last non-zero diagonal is now in A( UUB+LLB+1,j ),
// *                 zero below it, too.
// *
ir1 = uub+llb+2;
ir2 = uub+m+2;
{
forloop450:
for (jc = 1; jc <= n; jc++) {
{
forloop430:
for (jr = 1; jr <= uub+1-jc; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",430);
}              //  Close for() loop. 
}
{
forloop440:
for (jr = (int)(Math.max(1, Math.min(ir1, ir2-jc) ) ); jr <= lda; jr++) {
a[(jr)- 1+(jc- 1)*lda+ _a_offset] = zero;
Dummy.label("Dlatms",440);
}              //  Close for() loop. 
}
Dummy.label("Dlatms",450);
}              //  Close for() loop. 
}
}              // Close else if()
}              // Close if()
// *
Dummy.go_to("Dlatms",999999);
// *
// *     End of DLATMS
// *
Dummy.label("Dlatms",999999);
return;
   }
} // End class.
