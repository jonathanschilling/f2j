/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlsets {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     March 31, 1993
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *
// *  Purpose
// *  =======
// *
// *  DLSETS tests DGGLSE - a subroutine for solving linear equality
// *  constrained least square problem (LSE).
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  P       (input) INTEGER
// *          The number of rows of the matrix B.  P >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and B.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A.
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and R.
// *          LDA >= max(M,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,N)
// *          The P-by-N matrix A.
// *
// *  BF      (workspace) DOUBLE PRECISION array, dimension (LDB,N)
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arrays B, BF, V and S.
// *          LDB >= max(P,N).
// *
// *  C       (input) DOUBLE PRECISION array, dimension( M )
// *          the vector C in the LSE problem.
// *
// *  CF      (workspace) DOUBLE PRECISION array, dimension( M )
// *
// *  D       (input) DOUBLE PRECISION array, dimension( P )
// *          the vector D in the LSE problem.
// *
// *  DF      (workspace) DOUBLE PRECISION array, dimension( P )
// *
// *  X       (output) DOUBLE PRECISION array, dimension( N )
// *          solution vector X in the LSE problem.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *            RESULT(1) = norm( A*x - c )/ norm(A)*norm(X)*EPS
// *            RESULT(2) = norm( B*x - d )/ norm(B)*norm(X)*EPS
// *
// *  ====================================================================
// *
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Copy the matrices A and B to the arrays AF and BF,
// *     and the vectors C and D to the arrays CF and DF,
// *

public static void dlsets (int m,
int p,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
int lda,
double [] b, int _b_offset,
double [] bf, int _bf_offset,
int ldb,
double [] c, int _c_offset,
double [] cf, int _cf_offset,
double [] d, int _d_offset,
double [] df, int _df_offset,
double [] x, int _x_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,af,_af_offset,lda);
Dlacpy.dlacpy("Full",p,n,b,_b_offset,ldb,bf,_bf_offset,ldb);
Dcopy.dcopy(m,c,_c_offset,1,cf,_cf_offset,1);
Dcopy.dcopy(p,d,_d_offset,1,df,_df_offset,1);
// *
// *     Solve LSE problem
// *
Dgglse.dgglse(m,n,p,af,_af_offset,lda,bf,_bf_offset,ldb,cf,_cf_offset,df,_df_offset,x,_x_offset,work,_work_offset,lwork,info);
// *
// *     Test the residual for the solution of LSE
// *
// *     Compute RESULT(1) = norm( A*x - c ) / norm(A)*norm(X)*EPS
// *
Dcopy.dcopy(m,c,_c_offset,1,cf,_cf_offset,1);
Dcopy.dcopy(p,d,_d_offset,1,df,_df_offset,1);
dget02_adapter("No transpose",m,n,1,a,_a_offset,lda,x,_x_offset,n,cf,_cf_offset,m,rwork,_rwork_offset,result,(1)- 1+ _result_offset);
// *
// *     Compute result(2) = norm( B*x - d ) / norm(B)*norm(X)*EPS
// *
dget02_adapter("No transpose",p,n,1,b,_b_offset,ldb,x,_x_offset,n,df,_df_offset,p,rwork,_rwork_offset,result,(2)- 1+ _result_offset);
// *
Dummy.go_to("Dlsets",999999);
// *
// *     End of DLSETS
// *
Dummy.label("Dlsets",999999);
return;
   }
// adapter for dget02
private static void dget02_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dget02.dget02(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

} // End class.
