/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dort01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DORT01 checks that the matrix U is orthogonal by computing the ratio
// *
// *     RESID = norm( I - U*U' ) / ( n * EPS ), if ROWCOL = 'R',
// *  or
// *     RESID = norm( I - U'*U ) / ( m * EPS ), if ROWCOL = 'C'.
// *
// *  Alternatively, if there isn't sufficient workspace to form
// *  I - U*U' or I - U'*U, the ratio is computed as
// *
// *     RESID = abs( I - U*U' ) / ( n * EPS ), if ROWCOL = 'R',
// *  or
// *     RESID = abs( I - U'*U ) / ( m * EPS ), if ROWCOL = 'C'.
// *
// *  where EPS is the machine precision.  ROWCOL is used only if m = n;
// *  if m > n, ROWCOL is assumed to be 'C', and if m < n, ROWCOL is
// *  assumed to be 'R'.
// *
// *  Arguments
// *  =========
// *
// *  ROWCOL  (input) CHARACTER
// *          Specifies whether the rows or columns of U should be checked
// *          for orthogonality.  Used only if M = N.
// *          = 'R':  Check for orthogonal rows of U
// *          = 'C':  Check for orthogonal columns of U
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix U.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix U.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU,N)
// *          The orthogonal matrix U.  U is checked for orthogonal columns
// *          if m > n or if m = n and ROWCOL = 'C'.  U is checked for
// *          orthogonal rows if m < n or if m = n and ROWCOL = 'R'.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of the array U.  LDU >= max(1,M).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  For best performance, LWORK
// *          should be at least N*(N+1) if ROWCOL = 'C' or M*(M+1) if
// *          ROWCOL = 'R', but the test will be done even if LWORK is 0.
// *
// *  RESID   (output) DOUBLE PRECISION
// *          RESID = norm( I - U * U' ) / ( n * EPS ), if ROWCOL = 'R', or
// *          RESID = norm( I - U' * U ) / ( m * EPS ), if ROWCOL = 'C'.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static String transu= new String(" ");
static int i= 0;
static int j= 0;
static int k= 0;
static int ldwork= 0;
static int mnmin= 0;
static double eps= 0.0;
static double tmp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dort01 (String rowcol,
int m,
int n,
double [] u, int _u_offset,
int ldu,
double [] work, int _work_offset,
int lwork,
doubleW resid)  {

resid.val = zero;
// *
// *     Quick return if possible
// *
if (m <= 0 || n <= 0)  
    Dummy.go_to("Dort01",999999);
// *
eps = Dlamch.dlamch("Precision");
if (m < n || (m == n && (rowcol.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0))))  {
    transu = "N";
k = n;
}              // Close if()
else  {
  transu = "T";
k = m;
}              //  Close else.
mnmin = (int)(Math.min(m, n) );
// *
if ((mnmin+1)*mnmin <= lwork)  {
    ldwork = mnmin;
}              // Close if()
else  {
  ldwork = 0;
}              //  Close else.
if (ldwork > 0)  {
    // *
// *        Compute I - U*U' or I - U'*U.
// *
Dlaset.dlaset("Upper",mnmin,mnmin,zero,one,work,_work_offset,ldwork);
Dsyrk.dsyrk("Upper",transu,mnmin,k,-one,u,_u_offset,ldu,one,work,_work_offset,ldwork);
// *
// *        Compute norm( I - U*U' ) / ( K * EPS ) .
// *
resid.val = Dlansy.dlansy("1","Upper",mnmin,work,_work_offset,ldwork,work,(ldwork*mnmin+1)- 1+ _work_offset);
resid.val = (resid.val/(double)(k))/eps;
}              // Close if()
else if (transu.trim().equalsIgnoreCase("T".trim()))  {
    // *
// *        Find the maximum element in abs( I - U'*U ) / ( m * EPS )
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= j; i++) {
if (i != j)  {
    tmp = zero;
}              // Close if()
else  {
  tmp = one;
}              //  Close else.
tmp = tmp-Ddot.ddot(m,u,(1)- 1+(i- 1)*ldu+ _u_offset,1,u,(1)- 1+(j- 1)*ldu+ _u_offset,1);
resid.val = Math.max(resid.val, Math.abs(tmp)) ;
Dummy.label("Dort01",10);
}              //  Close for() loop. 
}
Dummy.label("Dort01",20);
}              //  Close for() loop. 
}
resid.val = (resid.val/(double)(m))/eps;
}              // Close else if()
else  {
  // *
// *        Find the maximum element in abs( I - U*U' ) / ( n * EPS )
// *
{
forloop40:
for (j = 1; j <= m; j++) {
{
forloop30:
for (i = 1; i <= j; i++) {
if (i != j)  {
    tmp = zero;
}              // Close if()
else  {
  tmp = one;
}              //  Close else.
tmp = tmp-Ddot.ddot(n,u,(j)- 1+(1- 1)*ldu+ _u_offset,ldu,u,(i)- 1+(1- 1)*ldu+ _u_offset,ldu);
resid.val = Math.max(resid.val, Math.abs(tmp)) ;
Dummy.label("Dort01",30);
}              //  Close for() loop. 
}
Dummy.label("Dort01",40);
}              //  Close for() loop. 
}
resid.val = (resid.val/(double)(n))/eps;
}              //  Close else.
Dummy.go_to("Dort01",999999);
// *
// *     End of DORT01
// *
Dummy.label("Dort01",999999);
return;
   }
} // End class.
