/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dsbt21 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSBT21  generally checks a decomposition of the form
// *
// *          A = U S U'
// *
// *  where ' means transpose, A is symmetric banded, U is
// *  orthogonal, and S is diagonal (if KS=0) or symmetric
// *  tridiagonal (if KS=1).
// *
// *  Specifically:
// *
// *          RESULT(1) = | A - U S U' | / ( |A| n ulp ) *and*
// *          RESULT(2) = | I - UU' | / ( n ulp )
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER
// *          If UPLO='U', the upper triangle of A and V will be used and
// *          the (strictly) lower triangle will not be referenced.
// *          If UPLO='L', the lower triangle of A and V will be used and
// *          the (strictly) upper triangle will not be referenced.
// *
// *  N       (input) INTEGER
// *          The size of the matrix.  If it is zero, DSBT21 does nothing.
// *          It must be at least zero.
// *
// *  KA      (input) INTEGER
// *          The bandwidth of the matrix A.  It must be at least zero.  If
// *          it is larger than N-1, then max( 0, N-1 ) will be used.
// *
// *  KS      (input) INTEGER
// *          The bandwidth of the matrix S.  It may only be zero or one.
// *          If zero, then S is diagonal, and E is not referenced.  If
// *          one, then S is symmetric tri-diagonal.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, N)
// *          The original (unfactored) matrix.  It is assumed to be
// *          symmetric, and only the upper (UPLO='U') or only the lower
// *          (UPLO='L') will be referenced.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of A.  It must be at least 1
// *          and at least min( KA, N-1 ).
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal of the (symmetric tri-) diagonal matrix S.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The off-diagonal of the (symmetric tri-) diagonal matrix S.
// *          E(1) is the (1,2) and (2,1) element, E(2) is the (2,3) and
// *          (3,2) element, etc.
// *          Not referenced if KS=0.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU, N)
// *          The orthogonal matrix in the decomposition, expressed as a
// *          dense matrix (i.e., not as a product of Householder
// *          transformations, Givens transformations, etc.)
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U.  LDU must be at least N and
// *          at least 1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N**2+N)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The values computed by the two tests described above.  The
// *          values are currently limited to 1/ulp, to avoid overflow.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean lower= false;
static String cuplo= new String(" ");
static int ika= 0;
static int j= 0;
static int jc= 0;
static int jr= 0;
static int lw= 0;
static double anorm= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Constants
// *

public static void dsbt21 (String uplo,
int n,
int ka,
int ks,
double [] a, int _a_offset,
int lda,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] u, int _u_offset,
int ldu,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
if (n <= 0)  
    Dummy.go_to("Dsbt21",999999);
// *
ika = (int)(Math.max(0, Math.min(n-1, ka) ) );
lw = (n*(n+1))/2;
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    lower = false;
cuplo = "U";
}              // Close if()
else  {
  lower = true;
cuplo = "L";
}              //  Close else.
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
// *
// *     Some Error Checks
// *
// *     Do Test 1
// *
// *     Norm of A:
// *
anorm = Math.max(Dlansb.dlansb("1",cuplo,n,ika,a,_a_offset,lda,work,_work_offset), unfl) ;
// *
// *     Compute error matrix:    Error = A - U S U'
// *
// *     Copy A from SB to SP storage format.
// *
j = 0;
{
forloop50:
for (jc = 1; jc <= n; jc++) {
if (lower)  {
    {
forloop10:
for (jr = 1; jr <= Math.min(ika+1, n+1-jc) ; jr++) {
j = j+1;
work[(j)- 1+ _work_offset] = a[(jr)- 1+(jc- 1)*lda+ _a_offset];
Dummy.label("Dsbt21",10);
}              //  Close for() loop. 
}
{
forloop20:
for (jr = ika+2; jr <= n+1-jc; jr++) {
j = j+1;
work[(j)- 1+ _work_offset] = zero;
Dummy.label("Dsbt21",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop30:
for (jr = ika+2; jr <= jc; jr++) {
j = j+1;
work[(j)- 1+ _work_offset] = zero;
Dummy.label("Dsbt21",30);
}              //  Close for() loop. 
}
{
int _jr_inc = -1;
forloop40:
for (jr = (int)(Math.min(ika, jc-1) ); (_jr_inc < 0) ? jr >= 0 : jr <= 0; jr += _jr_inc) {
j = j+1;
work[(j)- 1+ _work_offset] = a[(ika+1-jr)- 1+(jc- 1)*lda+ _a_offset];
Dummy.label("Dsbt21",40);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.label("Dsbt21",50);
}              //  Close for() loop. 
}
// *
{
forloop60:
for (j = 1; j <= n; j++) {
Dspr.dspr(cuplo,n,-d[(j)- 1+ _d_offset],u,(1)- 1+(j- 1)*ldu+ _u_offset,1,work,_work_offset);
Dummy.label("Dsbt21",60);
}              //  Close for() loop. 
}
// *
if (n > 1 && ks == 1)  {
    {
forloop70:
for (j = 1; j <= n-1; j++) {
Dspr2.dspr2(cuplo,n,-e[(j)- 1+ _e_offset],u,(1)- 1+(j- 1)*ldu+ _u_offset,1,u,(1)- 1+(j+1- 1)*ldu+ _u_offset,1,work,_work_offset);
Dummy.label("Dsbt21",70);
}              //  Close for() loop. 
}
}              // Close if()
wnorm = Dlansp.dlansp("1",cuplo,n,work,_work_offset,work,(lw+1)- 1+ _work_offset);
// *
if (anorm > wnorm)  {
    result[(1)- 1+ _result_offset] = (wnorm/anorm)/(n*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result[(1)- 1+ _result_offset] = (Math.min(wnorm, n*anorm) /anorm)/(n*ulp);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = Math.min(wnorm/anorm, (double)(n)) /(n*ulp);
}              //  Close else.
}              //  Close else.
// *
// *     Do Test 2
// *
// *     Compute  UU' - I
// *
Dgemm.dgemm("N","C",n,n,n,one,u,_u_offset,ldu,u,_u_offset,ldu,zero,work,_work_offset,n);
// *
{
forloop80:
for (j = 1; j <= n; j++) {
work[((n+1)*(j-1)+1)- 1+ _work_offset] = work[((n+1)*(j-1)+1)- 1+ _work_offset]-one;
Dummy.label("Dsbt21",80);
}              //  Close for() loop. 
}
// *
result[(2)- 1+ _result_offset] = Math.min(Dlange.dlange("1",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset)), (double)(n)) /(n*ulp);
// *
Dummy.go_to("Dsbt21",999999);
// *
// *     End of DSBT21
// *
Dummy.label("Dsbt21",999999);
return;
   }
} // End class.
