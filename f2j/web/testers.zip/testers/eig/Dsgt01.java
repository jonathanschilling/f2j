/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dsgt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDGT01 checks a decomposition of the form
// *
// *     A Z   =  B Z D or
// *     A B Z =  Z D or
// *     B A Z =  Z D
// *
// *  where A is a symmetric matrix, B is
// *  symmetric positive definite, Z is orthogonal, and D is diagonal.
// *
// *  One of the following test ratios is computed:
// *
// *  ITYPE = 1:  RESULT(1) = | A Z - B Z D | / ( |A| |Z| n ulp )
// *
// *  ITYPE = 2:  RESULT(1) = | A B Z - Z D | / ( |A| |Z| n ulp )
// *
// *  ITYPE = 3:  RESULT(1) = | B A Z - Z D | / ( |A| |Z| n ulp )
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   (input) INTEGER
// *          The form of the symmetric generalized eigenproblem.
// *          = 1:  A*z = (lambda)*B*z
// *          = 2:  A*B*z = (lambda)*z
// *          = 3:  B*A*z = (lambda)*z
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrices A and B is stored.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, N)
// *          The original symmetric matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB, N)
// *          The original symmetric positive definite matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  Z       (input) DOUBLE PRECISION array, dimension (LDZ, N)
// *          The computed eigenvectors of the generalized eigenproblem.
// *
// *  LDZ     (input) INTEGER
// *          The leading dimension of the array Z.  LDZ >= max(1,N).
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The computed eigenvalues of the generalized eigenproblem.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N*N)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (1)
// *          The test ratio as described above.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double anorm= 0.0;
static double ulp= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dsgt01 (int itype,
String uplo,
int n,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] z, int _z_offset,
int ldz,
double [] d, int _d_offset,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
if (n <= 0)  
    Dummy.go_to("Dsgt01",999999);
// *
ulp = Dlamch.dlamch("Epsilon");
// *
// *     Compute product of 1-norms of A and Z.
// *
anorm = Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,work,_work_offset)*Dlange.dlange("1",n,n,z,_z_offset,ldz,work,_work_offset);
if (anorm == zero)  
    anorm = one;
// *
if (itype == 1)  {
    // *
// *        Norm of AZ - BZD
// *
Dsymm.dsymm("Left",uplo,n,n,one,a,_a_offset,lda,z,_z_offset,ldz,zero,work,_work_offset,n);
{
forloop10:
for (i = 1; i <= n; i++) {
Dscal.dscal(n,d[(i)- 1+ _d_offset],z,(1)- 1+(i- 1)*ldz+ _z_offset,1);
Dummy.label("Dsgt01",10);
}              //  Close for() loop. 
}
Dsymm.dsymm("Left",uplo,n,n,one,b,_b_offset,ldb,z,_z_offset,ldz,-one,work,_work_offset,n);
// *
result[(1)- 1+ _result_offset] = (Dlange.dlange("1",n,n,work,_work_offset,n,work,_work_offset)/anorm)/(n*ulp);
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *        Norm of ABZ - ZD
// *
Dsymm.dsymm("Left",uplo,n,n,one,b,_b_offset,ldb,z,_z_offset,ldz,zero,work,_work_offset,n);
{
forloop20:
for (i = 1; i <= n; i++) {
Dscal.dscal(n,d[(i)- 1+ _d_offset],z,(1)- 1+(i- 1)*ldz+ _z_offset,1);
Dummy.label("Dsgt01",20);
}              //  Close for() loop. 
}
Dsymm.dsymm("Left",uplo,n,n,one,a,_a_offset,lda,work,_work_offset,n,-one,z,_z_offset,ldz);
// *
result[(1)- 1+ _result_offset] = (Dlange.dlange("1",n,n,z,_z_offset,ldz,work,_work_offset)/anorm)/(n*ulp);
// *
}              // Close else if()
else if (itype == 3)  {
    // *
// *        Norm of BAZ - ZD
// *
Dsymm.dsymm("Left",uplo,n,n,one,a,_a_offset,lda,z,_z_offset,ldz,zero,work,_work_offset,n);
{
forloop30:
for (i = 1; i <= n; i++) {
Dscal.dscal(n,d[(i)- 1+ _d_offset],z,(1)- 1+(i- 1)*ldz+ _z_offset,1);
Dummy.label("Dsgt01",30);
}              //  Close for() loop. 
}
Dsymm.dsymm("Left",uplo,n,n,one,b,_b_offset,ldb,work,_work_offset,n,-one,z,_z_offset,ldz);
// *
result[(1)- 1+ _result_offset] = (Dlange.dlange("1",n,n,z,_z_offset,ldz,work,_work_offset)/anorm)/(n*ulp);
}              // Close else if()
// *
Dummy.go_to("Dsgt01",999999);
// *
// *     End of DDGT01
// *
Dummy.label("Dsgt01",999999);
return;
   }
} // End class.
