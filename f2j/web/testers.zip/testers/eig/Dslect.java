/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dslect {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSLECT returns .TRUE. if the eigenvalue ZR+sqrt(-1)*ZI is to be
// *  selected, and otherwise it returns .FALSE.
// *  It is used by DCHK41 to test if DGEES succesfully sorts eigenvalues,
// *  and by DCHK43 to test if DGEESX succesfully sorts eigenvalues.
// *
// *  The common block /SSLCT/ controls how eigenvalues are selected.
// *  If SELOPT = 0, then DSLECT return .TRUE. when ZR is less than zero,
// *  and .FALSE. otherwise.
// *  If SELOPT is at least 1, DSLECT returns SELVAL(SELOPT) and adds 1
// *  to SELOPT, cycling back to 1 at SELMAX.
// *
// *  Arguments
// *  =========
// *
// *  ZR      (input) DOUBLE PRECISION
// *          The real part of a complex eigenvalue ZR + i*ZI.
// *
// *  ZI      (input) DOUBLE PRECISION
// *          The imaginary part of a complex eigenvalue ZR + i*ZI.
// *
// *  =====================================================================
// *
// *     .. Arrays in Common ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double rmin= 0.0;
static double x= 0.0;
// *     ..
// *     .. Parameters ..
static double zero= 0.0e0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static boolean dslect = false;


public static boolean dslect (double zr,
double zi)  {

if (eigtest_sslct.selopt == 0)  {
    dslect = (zr < zero);
}              // Close if()
else  {
  rmin = zero;
{
forloop10:
for (i = 1; i <= eigtest_sslct.seldim; i++) {
x = Dlapy2.dlapy2(zr-eigtest_sslct.selwr[(i)- 1],zi-eigtest_sslct.selwi[(i)- 1]);
if (x <= rmin)  {
    rmin = x;
dslect = eigtest_sslct.selval[(i)- 1];
}              // Close if()
Dummy.label("Dslect",10);
}              //  Close for() loop. 
}
}              //  Close else.
Dummy.go_to("Dslect",999999);
// *
// *     End of DSLECT
// *
Dummy.label("Dslect",999999);
return dslect;
   }
} // End class.
