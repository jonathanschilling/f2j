/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dspt21 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSPT21  generally checks a decomposition of the form
// *
// *          A = U S U'
// *
// *  where ' means transpose, A is symmetric (stored in packed format), U
// *  is orthogonal, and S is diagonal (if KBAND=0) or symmetric
// *  tridiagonal (if KBAND=1).  If ITYPE=1, then U is represented as a
// *  dense matrix, otherwise the U is expressed as a product of
// *  Householder transformations, whose vectors are stored in the array
// *  "V" and whose scaling constants are in "TAU"; we shall use the
// *  letter "V" to refer to the product of Householder transformations
// *  (which should be equal to U).
// *
// *  Specifically, if ITYPE=1, then:
// *
// *          RESULT(1) = | A - U S U' | / ( |A| n ulp ) *and*
// *          RESULT(2) = | I - UU' | / ( n ulp )
// *
// *  If ITYPE=2, then:
// *
// *          RESULT(1) = | A - V S V' | / ( |A| n ulp )
// *
// *  If ITYPE=3, then:
// *
// *          RESULT(1) = | I - VU' | / ( n ulp )
// *
// *  Packed storage means that, for example, if UPLO='U', then the columns
// *  of the upper triangle of A are stored one after another, so that
// *  A(1,j+1) immediately follows A(j,j) in the array AP.  Similarly, if
// *  UPLO='L', then the columns of the lower triangle of A are stored one
// *  after another in AP, so that A(j+1,j+1) immediately follows A(n,j)
// *  in the array AP.  This means that A(i,j) is stored in:
// *
// *     AP( i + j*(j-1)/2 )                 if UPLO='U'
// *
// *     AP( i + (2*n-j)*(j-1)/2 )           if UPLO='L'
// *
// *  The array VP bears the same relation to the matrix V that A does to
// *  AP.
// *
// *  For ITYPE > 1, the transformation U is expressed as a product
// *  of Householder transformations:
// *
// *     If UPLO='U', then  V = H(n-1)...H(1),  where
// *
// *         H(j) = I  -  tau(j) v(j) v(j)'
// *
// *     and the first j-1 elements of v(j) are stored in V(1:j-1,j+1),
// *     (i.e., VP( j*(j+1)/2 + 1 : j*(j+1)/2 + j-1 ) ),
// *     the j-th element is 1, and the last n-j elements are 0.
// *
// *     If UPLO='L', then  V = H(1)...H(n-1),  where
// *
// *         H(j) = I  -  tau(j) v(j) v(j)'
// *
// *     and the first j elements of v(j) are 0, the (j+1)-st is 1, and the
// *     (j+2)-nd through n-th elements are stored in V(j+2:n,j) (i.e.,
// *     in VP( (2*n-j)*(j-1)/2 + j+2 : (2*n-j)*(j-1)/2 + n ) .)
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   (input) INTEGER
// *          Specifies the type of tests to be performed.
// *          1: U expressed as a dense orthogonal matrix:
// *             RESULT(1) = | A - U S U' | / ( |A| n ulp )   *and*
// *             RESULT(2) = | I - UU' | / ( n ulp )
// *
// *          2: U expressed as a product V of Housholder transformations:
// *             RESULT(1) = | A - V S V' | / ( |A| n ulp )
// *
// *          3: U expressed both as a dense orthogonal matrix and
// *             as a product of Housholder transformations:
// *             RESULT(1) = | I - VU' | / ( n ulp )
// *
// *  UPLO    (input) CHARACTER
// *          If UPLO='U', AP and VP are considered to contain the upper
// *          triangle of A and V.
// *          If UPLO='L', AP and VP are considered to contain the lower
// *          triangle of A and V.
// *
// *  N       (input) INTEGER
// *          The size of the matrix.  If it is zero, DSPT21 does nothing.
// *          It must be at least zero.
// *
// *  KBAND   (input) INTEGER
// *          The bandwidth of the matrix.  It may only be zero or one.
// *          If zero, then S is diagonal, and E is not referenced.  If
// *          one, then S is symmetric tri-diagonal.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The original (unfactored) matrix.  It is assumed to be
// *          symmetric, and contains the columns of just the upper
// *          triangle (UPLO='U') or only the lower triangle (UPLO='L'),
// *          packed one after another.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal of the (symmetric tri-) diagonal matrix.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The off-diagonal of the (symmetric tri-) diagonal matrix.
// *          E(1) is the (1,2) and (2,1) element, E(2) is the (2,3) and
// *          (3,2) element, etc.
// *          Not referenced if KBAND=0.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU, N)
// *          If ITYPE=1 or 3, this contains the orthogonal matrix in
// *          the decomposition, expressed as a dense matrix.  If ITYPE=2,
// *          then it is not referenced.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U.  LDU must be at least N and
// *          at least 1.
// *
// *  VP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          If ITYPE=2 or 3, the columns of this array contain the
// *          Householder vectors used to describe the orthogonal matrix
// *          in the decomposition, as described in purpose.
// *          *NOTE* If ITYPE=2 or 3, V is modified and restored.  The
// *          subdiagonal (if UPLO='L') or the superdiagonal (if UPLO='U')
// *          is set to one, and later reset to its original value, during
// *          the course of the calculation.
// *          If ITYPE=1, then it is neither referenced nor modified.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N)
// *          If ITYPE >= 2, then TAU(j) is the scalar factor of
// *          v(j) v(j)' in the Householder transformation H(j) of
// *          the product  U = H(1)...H(n-2)
// *          If ITYPE < 2, then TAU is not referenced.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N**2+N)
// *          Workspace.
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The values computed by the two tests described above.  The
// *          values are currently limited to 1/ulp, to avoid overflow.
// *          RESULT(1) is always modified.  RESULT(2) is modified only
// *          if ITYPE=1.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double ten= 10.0e0;
static double half= 1.0e+0/2.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean lower= false;
static String cuplo= new String(" ");
static intW iinfo= new intW(0);
static int j= 0;
static int jp= 0;
static int jp1= 0;
static int jr= 0;
static int lap= 0;
static double anorm= 0.0;
static double temp= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double vsave= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     1)      Constants
// *

public static void dspt21 (int itype,
String uplo,
int n,
int kband,
double [] ap, int _ap_offset,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] u, int _u_offset,
int ldu,
double [] vp, int _vp_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
if (itype == 1)  
    result[(2)- 1+ _result_offset] = zero;
if (n <= 0)  
    Dummy.go_to("Dspt21",999999);
// *
lap = (n*(n+1))/2;
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    lower = false;
cuplo = "U";
}              // Close if()
else  {
  lower = true;
cuplo = "L";
}              //  Close else.
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
// *
// *     Some Error Checks
// *
if (itype < 1 || itype > 3)  {
    result[(1)- 1+ _result_offset] = ten/ulp;
Dummy.go_to("Dspt21",999999);
}              // Close if()
// *
// *     Do Test 1
// *
// *     Norm of A:
// *
if (itype == 3)  {
    anorm = one;
}              // Close if()
else  {
  anorm = Math.max(Dlansp.dlansp("1",cuplo,n,ap,_ap_offset,work,_work_offset), unfl) ;
}              //  Close else.
// *
// *     Compute error matrix:
// *
if (itype == 1)  {
    // *
// *        ITYPE=1: error = A - U S U'
// *
Dlaset.dlaset("Full",n,n,zero,zero,work,_work_offset,n);
Dcopy.dcopy(lap,ap,_ap_offset,1,work,_work_offset,1);
// *
{
forloop10:
for (j = 1; j <= n; j++) {
Dspr.dspr(cuplo,n,-d[(j)- 1+ _d_offset],u,(1)- 1+(j- 1)*ldu+ _u_offset,1,work,_work_offset);
Dummy.label("Dspt21",10);
}              //  Close for() loop. 
}
// *
if (n > 1 && kband == 1)  {
    {
forloop20:
for (j = 1; j <= n-1; j++) {
Dspr2.dspr2(cuplo,n,-e[(j)- 1+ _e_offset],u,(1)- 1+(j- 1)*ldu+ _u_offset,1,u,(1)- 1+(j+1- 1)*ldu+ _u_offset,1,work,_work_offset);
Dummy.label("Dspt21",20);
}              //  Close for() loop. 
}
}              // Close if()
wnorm = Dlansp.dlansp("1",cuplo,n,work,_work_offset,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset));
// *
}              // Close if()
else if (itype == 2)  {
    // *
// *        ITYPE=2: error = V S V' - A
// *
Dlaset.dlaset("Full",n,n,zero,zero,work,_work_offset,n);
// *
if (lower)  {
    work[(lap)- 1+ _work_offset] = d[(n)- 1+ _d_offset];
{
int _j_inc = -1;
forloop40:
for (j = n-1; (_j_inc < 0) ? j >= 1 : j <= 1; j += _j_inc) {
jp = ((2*n-j)*(j-1))/2;
jp1 = jp+n-j;
if (kband == 1)  {
    work[(jp+j+1)- 1+ _work_offset] = (one-tau[(j)- 1+ _tau_offset])*e[(j)- 1+ _e_offset];
{
forloop30:
for (jr = j+2; jr <= n; jr++) {
work[(jp+jr)- 1+ _work_offset] = -tau[(j)- 1+ _tau_offset]*e[(j)- 1+ _e_offset]*vp[(jp+jr)- 1+ _vp_offset];
Dummy.label("Dspt21",30);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (tau[(j)- 1+ _tau_offset] != zero)  {
    vsave = vp[(jp+j+1)- 1+ _vp_offset];
vp[(jp+j+1)- 1+ _vp_offset] = one;
Dspmv.dspmv("L",n-j,one,work,(jp1+j+1)- 1+ _work_offset,vp,(jp+j+1)- 1+ _vp_offset,1,zero,work,(lap+1)- 1+ _work_offset,1);
temp = -half*tau[(j)- 1+ _tau_offset]*Ddot.ddot(n-j,work,(lap+1)- 1+ _work_offset,1,vp,(jp+j+1)- 1+ _vp_offset,1);
Daxpy.daxpy(n-j,temp,vp,(jp+j+1)- 1+ _vp_offset,1,work,(lap+1)- 1+ _work_offset,1);
Dspr2.dspr2("L",n-j,-tau[(j)- 1+ _tau_offset],vp,(jp+j+1)- 1+ _vp_offset,1,work,(lap+1)- 1+ _work_offset,1,work,(jp1+j+1)- 1+ _work_offset);
vp[(jp+j+1)- 1+ _vp_offset] = vsave;
}              // Close if()
work[(jp+j)- 1+ _work_offset] = d[(j)- 1+ _d_offset];
Dummy.label("Dspt21",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  work[(1)- 1+ _work_offset] = d[(1)- 1+ _d_offset];
{
forloop60:
for (j = 1; j <= n-1; j++) {
jp = (j*(j-1))/2;
jp1 = jp+j;
if (kband == 1)  {
    work[(jp1+j)- 1+ _work_offset] = (one-tau[(j)- 1+ _tau_offset])*e[(j)- 1+ _e_offset];
{
forloop50:
for (jr = 1; jr <= j-1; jr++) {
work[(jp1+jr)- 1+ _work_offset] = -tau[(j)- 1+ _tau_offset]*e[(j)- 1+ _e_offset]*vp[(jp1+jr)- 1+ _vp_offset];
Dummy.label("Dspt21",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
if (tau[(j)- 1+ _tau_offset] != zero)  {
    vsave = vp[(jp1+j)- 1+ _vp_offset];
vp[(jp1+j)- 1+ _vp_offset] = one;
Dspmv.dspmv("U",j,one,work,_work_offset,vp,(jp1+1)- 1+ _vp_offset,1,zero,work,(lap+1)- 1+ _work_offset,1);
temp = -half*tau[(j)- 1+ _tau_offset]*Ddot.ddot(j,work,(lap+1)- 1+ _work_offset,1,vp,(jp1+1)- 1+ _vp_offset,1);
Daxpy.daxpy(j,temp,vp,(jp1+1)- 1+ _vp_offset,1,work,(lap+1)- 1+ _work_offset,1);
Dspr2.dspr2("U",j,-tau[(j)- 1+ _tau_offset],vp,(jp1+1)- 1+ _vp_offset,1,work,(lap+1)- 1+ _work_offset,1,work,_work_offset);
vp[(jp1+j)- 1+ _vp_offset] = vsave;
}              // Close if()
work[(jp1+j+1)- 1+ _work_offset] = d[(j+1)- 1+ _d_offset];
Dummy.label("Dspt21",60);
}              //  Close for() loop. 
}
}              //  Close else.
// *
{
forloop70:
for (j = 1; j <= lap; j++) {
work[(j)- 1+ _work_offset] = work[(j)- 1+ _work_offset]-ap[(j)- 1+ _ap_offset];
Dummy.label("Dspt21",70);
}              //  Close for() loop. 
}
wnorm = Dlansp.dlansp("1",cuplo,n,work,_work_offset,work,(lap+1)- 1+ _work_offset);
// *
}              // Close else if()
else if (itype == 3)  {
    // *
// *        ITYPE=3: error = U V' - I
// *
if (n < 2)  
    Dummy.go_to("Dspt21",999999);
Dlacpy.dlacpy(" ",n,n,u,_u_offset,ldu,work,_work_offset,n);
Dopmtr.dopmtr("R",cuplo,"T",n,n,vp,_vp_offset,tau,_tau_offset,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset),iinfo);
if (iinfo.val != 0)  {
    result[(1)- 1+ _result_offset] = ten/ulp;
Dummy.go_to("Dspt21",999999);
}              // Close if()
// *
{
forloop80:
for (j = 1; j <= n; j++) {
work[((n+1)*(j-1)+1)- 1+ _work_offset] = work[((n+1)*(j-1)+1)- 1+ _work_offset]-one;
Dummy.label("Dspt21",80);
}              //  Close for() loop. 
}
// *
wnorm = Dlange.dlange("1",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset));
}              // Close else if()
// *
if (anorm > wnorm)  {
    result[(1)- 1+ _result_offset] = (wnorm/anorm)/(n*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result[(1)- 1+ _result_offset] = (Math.min(wnorm, n*anorm) /anorm)/(n*ulp);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = Math.min(wnorm/anorm, (double)(n)) /(n*ulp);
}              //  Close else.
}              //  Close else.
// *
// *     Do Test 2
// *
// *     Compute  UU' - I
// *
if (itype == 1)  {
    Dgemm.dgemm("N","C",n,n,n,one,u,_u_offset,ldu,u,_u_offset,ldu,zero,work,_work_offset,n);
// *
{
forloop90:
for (j = 1; j <= n; j++) {
work[((n+1)*(j-1)+1)- 1+ _work_offset] = work[((n+1)*(j-1)+1)- 1+ _work_offset]-one;
Dummy.label("Dspt21",90);
}              //  Close for() loop. 
}
// *
result[(2)- 1+ _result_offset] = Math.min(Dlange.dlange("1",n,n,work,_work_offset,n,work,(int)((Math.pow(n, 2)+1)- 1+ _work_offset)), (double)(n)) /(n*ulp);
}              // Close if()
// *
Dummy.go_to("Dspt21",999999);
// *
// *     End of DSPT21
// *
Dummy.label("Dspt21",999999);
return;
   }
} // End class.
