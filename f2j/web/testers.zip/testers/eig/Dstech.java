/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dstech {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     Let T be the tridiagonal matrix with diagonal entries A(1) ,...,
// *     A(N) and offdiagonal entries B(1) ,..., B(N-1)).  DSTECH checks to
// *     see if EIG(1) ,..., EIG(N) are indeed accurate eigenvalues of T.
// *     It does this by expanding each EIG(I) into an interval
// *     [SVD(I) - EPS, SVD(I) + EPS], merging overlapping intervals if
// *     any, and using Sturm sequences to count and verify whether each
// *     resulting interval has the correct number of eigenvalues (using
// *     DSTECT).  Here EPS = TOL*MAZHEPS*MAXEIG, where MACHEPS is the
// *     machine precision and MAXEIG is the absolute value of the largest
// *     eigenvalue. If each interval contains the correct number of
// *     eigenvalues, INFO = 0 is returned, otherwise INFO is the index of
// *     the first eigenvalue in the first bad interval.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The dimension of the tridiagonal matrix T.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal entries of the tridiagonal matrix T.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The offdiagonal entries of the tridiagonal matrix T.
// *
// *  EIG     (input) DOUBLE PRECISION array, dimension (N)
// *          The purported eigenvalues to be checked.
// *
// *  TOL     (input) DOUBLE PRECISION
// *          Error tolerance for checking, a multiple of the
// *          machine precision.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  INFO    (output) INTEGER
// *          0  if the eigenvalues are all correct (to within
// *             1 +- TOL*MAZHEPS*MAXEIG)
// *          >0 if the interval containing the INFO-th eigenvalue
// *             contains the incorrect number of eigenvalues.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int bpnt= 0;
static int count= 0;
static int i= 0;
static int Isub= 0;
static int j= 0;
static intW numl= new intW(0);
static intW numu= new intW(0);
static int tpnt= 0;
static double emin= 0.0;
static double eps= 0.0;
static double lower= 0.0;
static double mx= 0.0;
static double tuppr= 0.0;
static double unflep= 0.0;
static double upper= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Check input parameters
// *

public static void dstech (int n,
double [] a, int _a_offset,
double [] b, int _b_offset,
double [] eig, int _eig_offset,
double tol,
double [] work, int _work_offset,
intW info)  {

info.val = 0;
if (n == 0)  
    Dummy.go_to("Dstech",999999);
if (n < 0)  {
    info.val = -1;
Dummy.go_to("Dstech",999999);
}              // Close if()
if (tol < zero)  {
    info.val = -5;
Dummy.go_to("Dstech",999999);
}              // Close if()
// *
// *     Get machine constants
// *
eps = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
unflep = Dlamch.dlamch("Safe minimum")/eps;
eps = tol*eps;
// *
// *     Compute maximum absolute eigenvalue, error tolerance
// *
mx = Math.abs(eig[(1)- 1+ _eig_offset]);
{
forloop10:
for (i = 2; i <= n; i++) {
mx = Math.max(mx, Math.abs(eig[(i)- 1+ _eig_offset])) ;
Dummy.label("Dstech",10);
}              //  Close for() loop. 
}
eps = Math.max(eps*mx, unflep) ;
// *
// *     Sort eigenvalues from EIG into WORK
// *
{
forloop20:
for (i = 1; i <= n; i++) {
work[(i)- 1+ _work_offset] = eig[(i)- 1+ _eig_offset];
Dummy.label("Dstech",20);
}              //  Close for() loop. 
}
{
forloop40:
for (i = 1; i <= n-1; i++) {
Isub = 1;
emin = work[(1)- 1+ _work_offset];
{
forloop30:
for (j = 2; j <= n+1-i; j++) {
if (work[(j)- 1+ _work_offset] < emin)  {
    Isub = j;
emin = work[(j)- 1+ _work_offset];
}              // Close if()
Dummy.label("Dstech",30);
}              //  Close for() loop. 
}
if (Isub != n+1-i)  {
    work[(Isub)- 1+ _work_offset] = work[(n+1-i)- 1+ _work_offset];
work[(n+1-i)- 1+ _work_offset] = emin;
}              // Close if()
Dummy.label("Dstech",40);
}              //  Close for() loop. 
}
// *
// *     TPNT points to singular value at right endpoint of interval
// *     BPNT points to singular value at left  endpoint of interval
// *
tpnt = 1;
bpnt = 1;
// *
// *     Begin loop over all intervals
// *
label50:
   Dummy.label("Dstech",50);
upper = work[(tpnt)- 1+ _work_offset]+eps;
lower = work[(bpnt)- 1+ _work_offset]-eps;
// *
// *     Begin loop merging overlapping intervals
// *
label60:
   Dummy.label("Dstech",60);
if (bpnt == n)  
    Dummy.go_to("Dstech",70);
tuppr = work[(bpnt+1)- 1+ _work_offset]+eps;
if (tuppr < lower)  
    Dummy.go_to("Dstech",70);
// *
// *     Merge
// *
bpnt = bpnt+1;
lower = work[(bpnt)- 1+ _work_offset]-eps;
Dummy.go_to("Dstech",60);
label70:
   Dummy.label("Dstech",70);
// *
// *     Count singular values in interval [ LOWER, UPPER ]
// *
Dstect.dstect(n,a,_a_offset,b,_b_offset,lower,numl);
Dstect.dstect(n,a,_a_offset,b,_b_offset,upper,numu);
count = numu.val-numl.val;
if (count != bpnt-tpnt+1)  {
    // *
// *        Wrong number of singular values in interval
// *
info.val = tpnt;
Dummy.go_to("Dstech",80);
}              // Close if()
tpnt = bpnt+1;
bpnt = tpnt;
if (tpnt <= n)  
    Dummy.go_to("Dstech",50);
label80:
   Dummy.label("Dstech",80);
Dummy.go_to("Dstech",999999);
// *
// *     End of DSTECH
// *
Dummy.label("Dstech",999999);
return;
   }
} // End class.
