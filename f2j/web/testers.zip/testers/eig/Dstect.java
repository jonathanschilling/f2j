/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dstect {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *     DSTECT counts the number NUM of eigenvalues of a tridiagonal
// *     matrix T which are less than or equal to SHIFT. T has
// *     diagonal entries A(1), ... , A(N), and offdiagonal entries
// *     B(1), ..., B(N-1).
// *     See W. Kahan "Accurate Eigenvalues of a Symmetric Tridiagonal
// *     Matrix", Report CS41, Computer Science Dept., Stanford
// *     University, July 21, 1966
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The dimension of the tridiagonal matrix T.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal entries of the tridiagonal matrix T.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The offdiagonal entries of the tridiagonal matrix T.
// *
// *  SHIFT   (input) DOUBLE PRECISION
// *          The shift, used as described under Purpose.
// *
// *  NUM     (output) INTEGER
// *          The number of eigenvalues of T less than or equal
// *          to SHIFT.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double three= 3.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double m1= 0.0;
static double m2= 0.0;
static double mx= 0.0;
static double ovfl= 0.0;
static double sov= 0.0;
static double sshift= 0.0;
static double ssun= 0.0;
static double sun= 0.0;
static double tmp= 0.0;
static double tom= 0.0;
static double u= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine constants
// *

public static void dstect (int n,
double [] a, int _a_offset,
double [] b, int _b_offset,
double shift,
intW num)  {

unfl = Dlamch.dlamch("Safe minimum");
ovfl = Dlamch.dlamch("Overflow");
// *
// *     Find largest entry
// *
mx = Math.abs(a[(1)- 1+ _a_offset]);
{
forloop10:
for (i = 1; i <= n-1; i++) {
mx = Math.max((mx) > (Math.abs(a[(i+1)- 1+ _a_offset])) ? (mx) : (Math.abs(a[(i+1)- 1+ _a_offset])), Math.abs(b[(i)- 1+ _b_offset]));
Dummy.label("Dstect",10);
}              //  Close for() loop. 
}
// *
// *     Handle easy cases, including zero matrix
// *
if (shift >= three*mx)  {
    num.val = n;
Dummy.go_to("Dstect",999999);
}              // Close if()
if (shift < -three*mx)  {
    num.val = 0;
Dummy.go_to("Dstect",999999);
}              // Close if()
// *
// *     Compute scale factors as in Kahan's report
// *     At this point, MX .NE. 0 so we can divide by it
// *
sun = Math.sqrt(unfl);
ssun = Math.sqrt(sun);
sov = Math.sqrt(ovfl);
tom = ssun*sov;
if (mx <= one)  {
    m1 = one/mx;
m2 = tom;
}              // Close if()
else  {
  m1 = one;
m2 = tom/mx;
}              //  Close else.
// *
// *     Begin counting
// *
num.val = 0;
sshift = (shift*m1)*m2;
u = (a[(1)- 1+ _a_offset]*m1)*m2-sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
{
forloop20:
for (i = 2; i <= n; i++) {
tmp = (b[(i-1)- 1+ _b_offset]*m1)*m2;
u = ((a[(i)- 1+ _a_offset]*m1)*m2-tmp*(tmp/u))-sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
Dummy.label("Dstect",20);
}              //  Close for() loop. 
}
Dummy.go_to("Dstect",999999);
// *
// *     End of DSTECT
// *
Dummy.label("Dstect",999999);
return;
   }
} // End class.
