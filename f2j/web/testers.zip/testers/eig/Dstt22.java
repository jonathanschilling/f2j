/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dstt22 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSTT22  checks a set of M eigenvalues and eigenvectors,
// *
// *      A U = U S
// *
// *  where A is symmetric tridiagonal, the columns of U are orthogonal,
// *  and S is diagonal (if KBAND=0) or symmetric tridiagonal (if KBAND=1).
// *  Two tests are performed:
// *
// *     RESULT(1) = | U' A U - S | / ( |A| m ulp )
// *
// *     RESULT(2) = | I - U'U | / ( m ulp )
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The size of the matrix.  If it is zero, DSTT22 does nothing.
// *          It must be at least zero.
// *
// *  M       (input) INTEGER
// *          The number of eigenpairs to check.  If it is zero, DSTT22
// *          does nothing.  It must be at least zero.
// *
// *  KBAND   (input) INTEGER
// *          The bandwidth of the matrix S.  It may only be zero or one.
// *          If zero, then S is diagonal, and SE is not referenced.  If
// *          one, then S is symmetric tri-diagonal.
// *
// *  AD      (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal of the original (unfactored) matrix A.  A is
// *          assumed to be symmetric tridiagonal.
// *
// *  AE      (input) DOUBLE PRECISION array, dimension (N)
// *          The off-diagonal of the original (unfactored) matrix A.  A
// *          is assumed to be symmetric tridiagonal.  AE(1) is ignored,
// *          AE(2) is the (1,2) and (2,1) element, etc.
// *
// *  SD      (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal of the (symmetric tri-) diagonal matrix S.
// *
// *  SE      (input) DOUBLE PRECISION array, dimension (N)
// *          The off-diagonal of the (symmetric tri-) diagonal matrix S.
// *          Not referenced if KBSND=0.  If KBAND=1, then AE(1) is
// *          ignored, SE(2) is the (1,2) and (2,1) element, etc.
// *
// *  U       (input) DOUBLE PRECISION array, dimension (LDU, N)
// *          The orthogonal matrix in the decomposition.
// *
// *  LDU     (input) INTEGER
// *          The leading dimension of U.  LDU must be at least N.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK, M+1)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of WORK.  LDWORK must be at least
// *          max(1,M).
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The values computed by the two tests described above.  The
// *          values are currently limited to 1/ulp, to avoid overflow.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int k= 0;
static double anorm= 0.0;
static double aukj= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dstt22 (int n,
int m,
int kband,
double [] ad, int _ad_offset,
double [] ae, int _ae_offset,
double [] sd, int _sd_offset,
double [] se, int _se_offset,
double [] u, int _u_offset,
int ldu,
double [] work, int _work_offset,
int ldwork,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
if (n <= 0 || m <= 0)  
    Dummy.go_to("Dstt22",999999);
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon");
// *
// *     Do Test 1
// *
// *     Compute the 1-norm of A.
// *
if (n > 1)  {
    anorm = Math.abs(ad[(1)- 1+ _ad_offset])+Math.abs(ae[(1)- 1+ _ae_offset]);
{
forloop10:
for (j = 2; j <= n-1; j++) {
anorm = Math.max(anorm, Math.abs(ad[(j)- 1+ _ad_offset])+Math.abs(ae[(j)- 1+ _ae_offset])+Math.abs(ae[(j-1)- 1+ _ae_offset])) ;
Dummy.label("Dstt22",10);
}              //  Close for() loop. 
}
anorm = Math.max(anorm, Math.abs(ad[(n)- 1+ _ad_offset])+Math.abs(ae[(n-1)- 1+ _ae_offset])) ;
}              // Close if()
else  {
  anorm = Math.abs(ad[(1)- 1+ _ad_offset]);
}              //  Close else.
anorm = Math.max(anorm, unfl) ;
// *
// *     Norm of U'AU - S
// *
{
forloop40:
for (i = 1; i <= m; i++) {
{
forloop30:
for (j = 1; j <= m; j++) {
work[(i)- 1+(j- 1)*ldwork+ _work_offset] = zero;
{
forloop20:
for (k = 1; k <= n; k++) {
aukj = ad[(k)- 1+ _ad_offset]*u[(k)- 1+(j- 1)*ldu+ _u_offset];
if (k != n)  
    aukj = aukj+ae[(k)- 1+ _ae_offset]*u[(k+1)- 1+(j- 1)*ldu+ _u_offset];
if (k != 1)  
    aukj = aukj+ae[(k-1)- 1+ _ae_offset]*u[(k-1)- 1+(j- 1)*ldu+ _u_offset];
work[(i)- 1+(j- 1)*ldwork+ _work_offset] = work[(i)- 1+(j- 1)*ldwork+ _work_offset]+u[(k)- 1+(i- 1)*ldu+ _u_offset]*aukj;
Dummy.label("Dstt22",20);
}              //  Close for() loop. 
}
Dummy.label("Dstt22",30);
}              //  Close for() loop. 
}
work[(i)- 1+(i- 1)*ldwork+ _work_offset] = work[(i)- 1+(i- 1)*ldwork+ _work_offset]-sd[(i)- 1+ _sd_offset];
if (kband == 1)  {
    if (i != 1)  
    work[(i)- 1+(i-1- 1)*ldwork+ _work_offset] = work[(i)- 1+(i-1- 1)*ldwork+ _work_offset]-se[(i-1)- 1+ _se_offset];
if (i != n)  
    work[(i)- 1+(i+1- 1)*ldwork+ _work_offset] = work[(i)- 1+(i+1- 1)*ldwork+ _work_offset]-se[(i)- 1+ _se_offset];
}              // Close if()
Dummy.label("Dstt22",40);
}              //  Close for() loop. 
}
// *
wnorm = Dlansy.dlansy("1","L",m,work,_work_offset,m,work,(1)- 1+(m+1- 1)*ldwork+ _work_offset);
// *
if (anorm > wnorm)  {
    result[(1)- 1+ _result_offset] = (wnorm/anorm)/(m*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result[(1)- 1+ _result_offset] = (Math.min(wnorm, m*anorm) /anorm)/(m*ulp);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = Math.min(wnorm/anorm, (double)(m)) /(m*ulp);
}              //  Close else.
}              //  Close else.
// *
// *     Do Test 2
// *
// *     Compute  U'U - I
// *
Dgemm.dgemm("T","N",m,m,n,one,u,_u_offset,ldu,u,_u_offset,ldu,zero,work,_work_offset,m);
// *
{
forloop50:
for (j = 1; j <= m; j++) {
work[(j)- 1+(j- 1)*ldwork+ _work_offset] = work[(j)- 1+(j- 1)*ldwork+ _work_offset]-one;
Dummy.label("Dstt22",50);
}              //  Close for() loop. 
}
// *
result[(2)- 1+ _result_offset] = Math.min((double)(m), Dlange.dlange("1",m,m,work,_work_offset,m,work,(1)- 1+(m+1- 1)*ldwork+ _work_offset)) /(m*ulp);
// *
Dummy.go_to("Dstt22",999999);
// *
// *     End of DSTT22
// *
Dummy.label("Dstt22",999999);
return;
   }
} // End class.
