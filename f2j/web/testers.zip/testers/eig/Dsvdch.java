/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dsvdch {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSVDCH checks to see if SVD(1) ,..., SVD(N) are accurate singular
// *  values of the bidiagonal matrix B with diagonal entries
// *  S(1) ,..., S(N) and superdiagonal entries E(1) ,..., E(N-1)).
// *  It does this by expanding each SVD(I) into an interval
// *  [SVD(I) * (1-EPS) , SVD(I) * (1+EPS)], merging overlapping intervals
// *  if any, and using Sturm sequences to count and verify whether each
// *  resulting interval has the correct number of singular values (using
// *  DSVDCT). Here EPS=TOL*MAX(N/10,1)*MAZHEP, where MACHEP is the
// *  machine precision. The routine assumes the singular values are sorted
// *  with SVD(1) the largest and SVD(N) smallest.  If each interval
// *  contains the correct number of singular values, INFO = 0 is returned,
// *  otherwise INFO is the index of the first singular value in the first
// *  bad interval.
// *
// *  Arguments
// *  ==========
// *
// *  N       (input) INTEGER
// *          The dimension of the bidiagonal matrix B.
// *
// *  S       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal entries of the bidiagonal matrix B.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The superdiagonal entries of the bidiagonal matrix B.
// *
// *  SVD     (input) DOUBLE PRECISION array, dimension (N)
// *          The computed singular values to be checked.
// *
// *  TOL     (input) DOUBLE PRECISION
// *          Error tolerance for checking, a multiplier of the
// *          machine precision.
// *
// *  INFO    (output) INTEGER
// *          =0 if the singular values are all correct (to within
// *             1 +- TOL*MAZHEPS)
// *          >0 if the interval containing the INFO-th singular value
// *             contains the incorrect number of singular values.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int bpnt= 0;
static int count= 0;
static intW numl= new intW(0);
static intW numu= new intW(0);
static int tpnt= 0;
static double eps= 0.0;
static double lower= 0.0;
static double ovfl= 0.0;
static double tuppr= 0.0;
static double unfl= 0.0;
static double unflep= 0.0;
static double upper= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine constants
// *

public static void dsvdch (int n,
double [] s, int _s_offset,
double [] e, int _e_offset,
double [] svd, int _svd_offset,
double tol,
intW info)  {

info.val = 0;
if (n <= 0)  
    Dummy.go_to("Dsvdch",999999);
unfl = Dlamch.dlamch("Safe minimum");
ovfl = Dlamch.dlamch("Overflow");
eps = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
// *
// *     UNFLEP is chosen so that when an eigenvalue is multiplied by the
// *     scale factor sqrt(OVFL)*sqrt(sqrt(UNFL))/MX in DSVDCT, it exceeds
// *     sqrt(UNFL), which is the lower limit for DSVDCT.
// *
unflep = (Math.sqrt(Math.sqrt(unfl))/Math.sqrt(ovfl))*svd[(1)- 1+ _svd_offset]+unfl/eps;
// *
// *     The value of EPS works best when TOL .GE. 10.
// *
eps = tol*Math.max(n/10, 1) *eps;
// *
// *     TPNT points to singular value at right endpoint of interval
// *     BPNT points to singular value at left  endpoint of interval
// *
tpnt = 1;
bpnt = 1;
// *
// *     Begin loop over all intervals
// *
label10:
   Dummy.label("Dsvdch",10);
upper = (one+eps)*svd[(tpnt)- 1+ _svd_offset]+unflep;
lower = (one-eps)*svd[(bpnt)- 1+ _svd_offset]-unflep;
if (lower <= unflep)  
    lower = -upper;
// *
// *     Begin loop merging overlapping intervals
// *
label20:
   Dummy.label("Dsvdch",20);
if (bpnt == n)  
    Dummy.go_to("Dsvdch",30);
tuppr = (one+eps)*svd[(bpnt+1)- 1+ _svd_offset]+unflep;
if (tuppr < lower)  
    Dummy.go_to("Dsvdch",30);
// *
// *     Merge
// *
bpnt = bpnt+1;
lower = (one-eps)*svd[(bpnt)- 1+ _svd_offset]-unflep;
if (lower <= unflep)  
    lower = -upper;
Dummy.go_to("Dsvdch",20);
label30:
   Dummy.label("Dsvdch",30);
// *
// *     Count singular values in interval [ LOWER, UPPER ]
// *
Dsvdct.dsvdct(n,s,_s_offset,e,_e_offset,lower,numl);
Dsvdct.dsvdct(n,s,_s_offset,e,_e_offset,upper,numu);
count = numu.val-numl.val;
if (lower < zero)  
    count = count/2;
if (count != bpnt-tpnt+1)  {
    // *
// *        Wrong number of singular values in interval
// *
info.val = tpnt;
Dummy.go_to("Dsvdch",40);
}              // Close if()
tpnt = bpnt+1;
bpnt = tpnt;
if (tpnt <= n)  
    Dummy.go_to("Dsvdch",10);
label40:
   Dummy.label("Dsvdch",40);
Dummy.go_to("Dsvdch",999999);
// *
// *     End of DSVDCH
// *
Dummy.label("Dsvdch",999999);
return;
   }
} // End class.
