/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dsvdct {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSVDCT counts the number NUM of eigenvalues of a 2*N by 2*N
// *  tridiagonal matrix T which are less than or equal to SHIFT.  T is
// *  formed by putting zeros on the diagonal and making the off-diagonals
// *  equal to S(1), E(1), S(2), E(2), ... , E(N-1), S(N).  If SHIFT is
// *  positive, NUM is equal to N plus the number of singular values of a
// *  bidiagonal matrix B less than or equal to SHIFT.  Here B has diagonal
// *  entries S(1), ..., S(N) and superdiagonal entries E(1), ... E(N-1).
// *  If SHIFT is negative, NUM is equal to the number of singular values
// *  of B greater than or equal to -SHIFT.
// *
// *  See W. Kahan "Accurate Eigenvalues of a Symmetric Tridiagonal
// *  Matrix", Report CS41, Computer Science Dept., Stanford University,
// *  July 21, 1966
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The dimension of the bidiagonal matrix B.
// *
// *  S       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal entries of the bidiagonal matrix B.
// *
// *  E       (input) DOUBLE PRECISION array of dimension (N-1)
// *          The superdiagonal entries of the bidiagonal matrix B.
// *
// *  SHIFT   (input) DOUBLE PRECISION
// *          The shift, used as described under Purpose.
// *
// *  NUM     (output) INTEGER
// *          The number of eigenvalues of T less than or equal to SHIFT.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double m1= 0.0;
static double m2= 0.0;
static double mx= 0.0;
static double ovfl= 0.0;
static double sov= 0.0;
static double sshift= 0.0;
static double ssun= 0.0;
static double sun= 0.0;
static double tmp= 0.0;
static double tom= 0.0;
static double u= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Get machine constants
// *

public static void dsvdct (int n,
double [] s, int _s_offset,
double [] e, int _e_offset,
double shift,
intW num)  {

unfl = 2*Dlamch.dlamch("Safe minimum");
ovfl = Dlamch.dlamch("Overflow");
// *
// *     Find largest entry
// *
mx = Math.abs(s[(1)- 1+ _s_offset]);
{
forloop10:
for (i = 1; i <= n-1; i++) {
mx = Math.max((mx) > (Math.abs(s[(i+1)- 1+ _s_offset])) ? (mx) : (Math.abs(s[(i+1)- 1+ _s_offset])), Math.abs(e[(i)- 1+ _e_offset]));
Dummy.label("Dsvdct",10);
}              //  Close for() loop. 
}
// *
if (mx == zero)  {
    if (shift < zero)  {
    num.val = 0;
}              // Close if()
else  {
  num.val = 2*n;
}              //  Close else.
Dummy.go_to("Dsvdct",999999);
}              // Close if()
// *
// *     Compute scale factors as in Kahan's report
// *
sun = Math.sqrt(unfl);
ssun = Math.sqrt(sun);
sov = Math.sqrt(ovfl);
tom = ssun*sov;
if (mx <= one)  {
    m1 = one/mx;
m2 = tom;
}              // Close if()
else  {
  m1 = one;
m2 = tom/mx;
}              //  Close else.
// *
// *     Begin counting
// *
u = one;
num.val = 0;
sshift = (shift*m1)*m2;
u = -sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
tmp = (s[(1)- 1+ _s_offset]*m1)*m2;
u = -tmp*(tmp/u)-sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
{
forloop20:
for (i = 1; i <= n-1; i++) {
tmp = (e[(i)- 1+ _e_offset]*m1)*m2;
u = -tmp*(tmp/u)-sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
tmp = (s[(i+1)- 1+ _s_offset]*m1)*m2;
u = -tmp*(tmp/u)-sshift;
if (u <= sun)  {
    if (u <= zero)  {
    num.val = num.val+1;
if (u > -sun)  
    u = -sun;
}              // Close if()
else  {
  u = sun;
}              //  Close else.
}              // Close if()
Dummy.label("Dsvdct",20);
}              //  Close for() loop. 
}
Dummy.go_to("Dsvdct",999999);
// *
// *     End of DSVDCT
// *
Dummy.label("Dsvdct",999999);
return;
   }
} // End class.
