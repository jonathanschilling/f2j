/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dsxt1 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSXT1  computes the difference between a set of eigenvalues.
// *  The result is returned as the function value.
// *
// *  IJOB = 1:   Computes   max { min | D1(i)-D2(j) | }
// *                          i     j
// *
// *  IJOB = 2:   Computes   max { min | D1(i)-D2(j) | /
// *                          i     j
// *                               ( ABSTOL + |D1(i)|*ULP ) }
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   (input) INTEGER
// *          Specifies the type of tests to be performed.  (See above.)
// *
// *  D1      (input) DOUBLE PRECISION array, dimension (N1)
// *          The first array.  D1 should be in increasing order, i.e.,
// *          D1(j) <= D1(j+1).
// *
// *  N1      (input) INTEGER
// *          The length of D1.
// *
// *  D2      (input) DOUBLE PRECISION array, dimension (N2)
// *          The second array.  D2 should be in increasing order, i.e.,
// *          D2(j) <= D2(j+1).
// *
// *  N2      (input) INTEGER
// *          The length of D2.
// *
// *  ABSTOL  (input) DOUBLE PRECISION
// *          The absolute tolerance, used as a measure of the error.
// *
// *  ULP     (input) DOUBLE PRECISION
// *          Machine precision.
// *
// *  UNFL    (input) DOUBLE PRECISION
// *          The smallest positive number whose reciprocal does not
// *          overflow.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double temp1= 0.0;
static double temp2= 0.0;
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dsxt1 = 0.0;


public static double dsxt1 (int ijob,
double [] d1, int _d1_offset,
int n1,
double [] d2, int _d2_offset,
int n2,
double abstol,
double ulp,
double unfl)  {

temp1 = zero;
// *
j = 1;
{
forloop20:
for (i = 1; i <= n1; i++) {
label10:
   Dummy.label("Dsxt1",10);
while (d2[(j)- 1+ _d2_offset] < d1[(i)- 1+ _d1_offset] && j < n2)  {
    j = j+1;
// goto 10 (end while)
}              // Close if()
if (j == 1)  {
    temp2 = Math.abs(d2[(j)- 1+ _d2_offset]-d1[(i)- 1+ _d1_offset]);
if (ijob == 2)  
    temp2 = temp2/Math.max(unfl, abstol+ulp*Math.abs(d1[(i)- 1+ _d1_offset])) ;
}              // Close if()
else  {
  temp2 = Math.min(Math.abs(d2[(j)- 1+ _d2_offset]-d1[(i)- 1+ _d1_offset]), Math.abs(d1[(i)- 1+ _d1_offset]-d2[(j-1)- 1+ _d2_offset])) ;
if (ijob == 2)  
    temp2 = temp2/Math.max(unfl, abstol+ulp*Math.abs(d1[(i)- 1+ _d1_offset])) ;
}              //  Close else.
temp1 = Math.max(temp1, temp2) ;
Dummy.label("Dsxt1",20);
}              //  Close for() loop. 
}
// *
dsxt1 = temp1;
Dummy.go_to("Dsxt1",999999);
// *
// *     End of DSXT1
// *
Dummy.label("Dsxt1",999999);
return dsxt1;
   }
} // End class.
