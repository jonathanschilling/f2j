/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: eigtest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dsyt22 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *       DSYT22  generally checks a decomposition of the form
// *
// *               A U = U S
// *
// *       where A is symmetric, the columns of U are orthonormal, and S
// *       is diagonal (if KBAND=0) or symmetric tridiagonal (if
// *       KBAND=1).  If ITYPE=1, then U is represented as a dense matrix,
// *       otherwise the U is expressed as a product of Householder
// *       transformations, whose vectors are stored in the array "V" and
// *       whose scaling constants are in "TAU"; we shall use the letter
// *       "V" to refer to the product of Householder transformations
// *       (which should be equal to U).
// *
// *       Specifically, if ITYPE=1, then:
// *
// *               RESULT(1) = | U' A U - S | / ( |A| m ulp ) *and*
// *               RESULT(2) = | I - U'U | / ( m ulp )
// *
// *  Arguments
// *  =========
// *
// *  ITYPE   INTEGER
// *          Specifies the type of tests to be performed.
// *          1: U expressed as a dense orthogonal matrix:
// *             RESULT(1) = | A - U S U' | / ( |A| n ulp )   *and*
// *             RESULT(2) = | I - UU' | / ( n ulp )
// *
// *  UPLO    CHARACTER
// *          If UPLO='U', the upper triangle of A will be used and the
// *          (strictly) lower triangle will not be referenced.  If
// *          UPLO='L', the lower triangle of A will be used and the
// *          (strictly) upper triangle will not be referenced.
// *          Not modified.
// *
// *  N       INTEGER
// *          The size of the matrix.  If it is zero, DSYT22 does nothing.
// *          It must be at least zero.
// *          Not modified.
// *
// *  M       INTEGER
// *          The number of columns of U.  If it is zero, DSYT22 does
// *          nothing.  It must be at least zero.
// *          Not modified.
// *
// *  KBAND   INTEGER
// *          The bandwidth of the matrix.  It may only be zero or one.
// *          If zero, then S is diagonal, and E is not referenced.  If
// *          one, then S is symmetric tri-diagonal.
// *          Not modified.
// *
// *  A       DOUBLE PRECISION array, dimension (LDA , N)
// *          The original (unfactored) matrix.  It is assumed to be
// *          symmetric, and only the upper (UPLO='U') or only the lower
// *          (UPLO='L') will be referenced.
// *          Not modified.
// *
// *  LDA     INTEGER
// *          The leading dimension of A.  It must be at least 1
// *          and at least N.
// *          Not modified.
// *
// *  D       DOUBLE PRECISION array, dimension (N)
// *          The diagonal of the (symmetric tri-) diagonal matrix.
// *          Not modified.
// *
// *  E       DOUBLE PRECISION array, dimension (N)
// *          The off-diagonal of the (symmetric tri-) diagonal matrix.
// *          E(1) is ignored, E(2) is the (1,2) and (2,1) element, etc.
// *          Not referenced if KBAND=0.
// *          Not modified.
// *
// *  U       DOUBLE PRECISION array, dimension (LDU, N)
// *          If ITYPE=1 or 3, this contains the orthogonal matrix in
// *          the decomposition, expressed as a dense matrix.  If ITYPE=2,
// *          then it is not referenced.
// *          Not modified.
// *
// *  LDU     INTEGER
// *          The leading dimension of U.  LDU must be at least N and
// *          at least 1.
// *          Not modified.
// *
// *  V       DOUBLE PRECISION array, dimension (LDV, N)
// *          If ITYPE=2 or 3, the lower triangle of this array contains
// *          the Householder vectors used to describe the orthogonal
// *          matrix in the decomposition.  If ITYPE=1, then it is not
// *          referenced.
// *          Not modified.
// *
// *  LDV     INTEGER
// *          The leading dimension of V.  LDV must be at least N and
// *          at least 1.
// *          Not modified.
// *
// *  TAU     DOUBLE PRECISION array, dimension (N)
// *          If ITYPE >= 2, then TAU(j) is the scalar factor of
// *          v(j) v(j)' in the Householder transformation H(j) of
// *          the product  U = H(1)...H(n-2)
// *          If ITYPE < 2, then TAU is not referenced.
// *          Not modified.
// *
// *  WORK    DOUBLE PRECISION array, dimension (2*N**2)
// *          Workspace.
// *          Modified.
// *
// *  RESULT  DOUBLE PRECISION array, dimension (2)
// *          The values computed by the two tests described above.  The
// *          values are currently limited to 1/ulp, to avoid overflow.
// *          RESULT(1) is always modified.  RESULT(2) is modified only
// *          if LDU is at least N.
// *          Modified.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static int jj= 0;
static int jj1= 0;
static int jj2= 0;
static int nn= 0;
static int nnp1= 0;
static double anorm= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double wnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dsyt22 (int itype,
String uplo,
int n,
int m,
int kband,
double [] a, int _a_offset,
int lda,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] u, int _u_offset,
int ldu,
double [] v, int _v_offset,
int ldv,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
double [] result, int _result_offset)  {

result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
if (n <= 0 || m <= 0)  
    Dummy.go_to("Dsyt22",999999);
// *
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Precision");
// *
// *     Do Test 1
// *
// *     Norm of A:
// *
anorm = Math.max(Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,work,_work_offset), unfl) ;
// *
// *     Compute error matrix:
// *
// *     ITYPE=1: error = U' A U - S
// *
Dsymm.dsymm("L",uplo,n,m,one,a,_a_offset,lda,u,_u_offset,ldu,zero,work,_work_offset,n);
nn = n*n;
nnp1 = nn+1;
Dgemm.dgemm("T","N",m,m,n,one,u,_u_offset,ldu,work,_work_offset,n,zero,work,(nnp1)- 1+ _work_offset,n);
{
forloop10:
for (j = 1; j <= m; j++) {
jj = nn+(j-1)*n+j;
work[(jj)- 1+ _work_offset] = work[(jj)- 1+ _work_offset]-d[(j)- 1+ _d_offset];
Dummy.label("Dsyt22",10);
}              //  Close for() loop. 
}
if (kband == 1 && n > 1)  {
    {
forloop20:
for (j = 2; j <= m; j++) {
jj1 = nn+(j-1)*n+j-1;
jj2 = nn+(j-2)*n+j;
work[(jj1)- 1+ _work_offset] = work[(jj1)- 1+ _work_offset]-e[(j-1)- 1+ _e_offset];
work[(jj2)- 1+ _work_offset] = work[(jj2)- 1+ _work_offset]-e[(j-1)- 1+ _e_offset];
Dummy.label("Dsyt22",20);
}              //  Close for() loop. 
}
}              // Close if()
wnorm = Dlansy.dlansy("1",uplo,m,work,(nnp1)- 1+ _work_offset,n,work,(1)- 1+ _work_offset);
// *
if (anorm > wnorm)  {
    result[(1)- 1+ _result_offset] = (wnorm/anorm)/(m*ulp);
}              // Close if()
else  {
  if (anorm < one)  {
    result[(1)- 1+ _result_offset] = (Math.min(wnorm, m*anorm) /anorm)/(m*ulp);
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = Math.min(wnorm/anorm, (double)(m)) /(m*ulp);
}              //  Close else.
}              //  Close else.
// *
// *     Do Test 2
// *
// *     Compute  U'U - I
// *
if (itype == 1)  
    dort01_adapter("Columns",n,m,u,_u_offset,ldu,work,_work_offset,2*n*n,result,(2)- 1+ _result_offset);
// *
Dummy.go_to("Dsyt22",999999);
// *
// *     End of DSYT22
// *
Dummy.label("Dsyt22",999999);
return;
   }
// adapter for dort01
private static void dort01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dort01.dort01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
