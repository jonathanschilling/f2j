import org.netlib.util.*;
import org.netlib.lapack.*;


public class eigtest_cenvir
{
static int nproc= 0;
static int nshift= 0;
static int maxb= 0;
}
