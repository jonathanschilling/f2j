import org.netlib.util.*;
import org.netlib.lapack.*;


public class eigtest_claenv
{
static int [] iparms= new int[(100)];
}
