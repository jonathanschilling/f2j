import org.netlib.util.*;
import org.netlib.lapack.*;


public class eigtest_srnamc
{
static String srnamt= new String("      ");
}
