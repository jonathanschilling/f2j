import org.netlib.util.*;
import org.netlib.lapack.*;


public class eigtest_sslct
{
static int selopt= 0;
static int seldim= 0;
static boolean [] selval= new boolean[(20)];
static double [] selwr= new double[(20)];
static double [] selwi= new double[(20)];
}
