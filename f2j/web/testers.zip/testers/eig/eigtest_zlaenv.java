import org.netlib.util.*;
import org.netlib.lapack.*;


public class eigtest_zlaenv
{
static int [] iparms= new int[(100)];
}
