/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Aladhd {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALADHD prints header information for the driver routines test paths.
// *
// *  Arguments
// *  =========
// *
// *  IOUNIT  (input) INTEGER
// *          The unit number to which the header information should be
// *          printed.
// *
// *  PATH    (input) CHARACTER*3
// *          The name of the path for which the header information is to
// *          be printed.  Current paths are
// *             _GE:  General matrices
// *             _GB:  General band
// *             _GT:  General Tridiagonal
// *             _PO:  Symmetric or Hermitian positive definite
// *             _PP:  Symmetric or Hermitian positive definite packed
// *             _PB:  Symmetric or Hermitian positive definite band
// *             _PT:  Symmetric or Hermitian positive definite tridiagonal
// *             _SY:  Symmetric indefinite
// *             _SP:  Symmetric indefinite packed
// *             _HE:  (complex) Hermitian indefinite
// *             _HP:  (complex) Hermitian indefinite packed
// *          The first character must be one of S, D, C, or Z (C or Z only
// *          if complex).
// *
// *     .. Local Scalars ..
static boolean corz= false;
static boolean sord= false;
static String c1= new String(" ");
static String c3= new String(" ");
static String p2= new String("  ");
static String sym= new String("         ");
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void aladhd (int iounit,
String path)  {

if (iounit <= 0)  
    Dummy.go_to("Aladhd",999999);
c1 = path.substring((1)-1,1);
c3 = path.substring((3)-1,3);
p2 = path.substring((2)-1,3);
sord = (c1.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (c1.toLowerCase().charAt(0) == "D".toLowerCase().charAt(0));
corz = (c1.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)) || (c1.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0));
if (!(sord || corz))  
    Dummy.go_to("Aladhd",999999);
// *
if (p2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        GE: General dense
// *
System.out.println("\n"  + " " + (path) + " "  + " drivers:  General dense matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "7. Last n/2 columns zero"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "8. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "9. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "             " + "10. Scaled near underflow"  + "\n"  + "    " + "5. First column zero"  + "              " + "11. Scaled near overflow"  + "\n"  + "    " + "6. Last column zero" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("   " + (7) + " "  + ": abs( WORK(1) - RPVGRW ) /"  + " ( max( WORK(1), RPVGRW ) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close if()
else if (p2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        GB: General band
// *
System.out.println("\n"  + " " + (path) + " "  + " drivers:  General band matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Random, CNDNUM = 2"  + "              " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. First column zero"  + "               " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Last column zero"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Last n/2 columns zero"  + "           " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("   " + (7) + " "  + ": abs( WORK(1) - RPVGRW ) /"  + " ( max( WORK(1), RPVGRW ) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        GT: General tridiagonal
// *
System.out.println("\n"  + " " + (path) + " "  + " drivers:  General tridiagonal" );
System.out.println(" Matrix types (1-6 have specified condition numbers):"  + "\n"  + "    " + "1. Diagonal"  + "                        " + "7. Random, unspecified CNDNUM"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. First column zero"  + "\n"  + "    " + "3. Random, CNDNUM = sqrt(0.1/EPS)"  + "  " + "9. Last column zero"  + "\n"  + "    " + "4. Random, CNDNUM = 0.1/EPS"  + "       " + "10. Last n/2 columns zero"  + "\n"  + "    " + "5. Scaled near underflow"  + "          " + "11. Scaled near underflow"  + "\n"  + "    " + "6. Scaled near overflow"  + "           " + "12. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PO",0,2) || p2.regionMatches(true,0,"PP",0,2))  {
    // *
// *        PO: Positive definite full
// *        PP: Positive definite packed
// *
if (sord)  {
    sym = "Symmetric";
}              // Close if()
else  {
  sym = "Hermitian";
}              //  Close else.
if ((c3.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + (sym) + " "  + " positive definite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + (sym) + " "  + " positive definite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "6. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = 0.1/EPS"  + "\n"  + "   " + "*3. First row and column zero"  + "       " + "8. Scaled near underflow"  + "\n"  + "   " + "*4. Last row and column zero"  + "        " + "9. Scaled near overflow"  + "\n"  + "   " + "*5. Middle row and column zero"  + "\n"  + "   " + "(* - tests error exits from "  + (path) + " "  + "TRF, no test ratios are computed)" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\' * U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L * L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        PB: Positive definite band
// *
if (sord)  {
    System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Symmetric") + " "  + " positive definite band matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Hermitian") + " "  + " positive definite band matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Random, CNDNUM = 2"  + "              " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "   " + "*2. First row and column zero"  + "       " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "   " + "*3. Last row and column zero"  + "        " + "7. Scaled near underflow"  + "\n"  + "   " + "*4. Middle row and column zero"  + "      " + "8. Scaled near overflow"  + "\n"  + "   " + "(* - tests error exits from "  + (path) + " "  + "TRF, no test ratios are computed)" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\' * U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L * L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        PT: Positive definite tridiagonal
// *
if (sord)  {
    System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Symmetric") + " "  + " positive definite tridiagonal" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Hermitian") + " "  + " positive definite tridiagonal" );
}              //  Close else.
System.out.println(" Matrix types (1-6 have specified condition numbers):"  + "\n"  + "    " + "1. Diagonal"  + "                        " + "7. Random, unspecified CNDNUM"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. First row and column zero"  + "\n"  + "    " + "3. Random, CNDNUM = sqrt(0.1/EPS)"  + "  " + "9. Last row and column zero"  + "\n"  + "    " + "4. Random, CNDNUM = 0.1/EPS"  + "       " + "10. Middle row and column zero"  + "\n"  + "    " + "5. Scaled near underflow"  + "          " + "11. Scaled near underflow"  + "\n"  + "    " + "6. Scaled near overflow"  + "           " + "12. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\'*D*U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"SY",0,2) || p2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        SY: Symmetric indefinite full
// *        SP: Symmetric indefinite packed
// *
if ((c3.toLowerCase().charAt(0) == "Y".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Symmetric") + " "  + " indefinite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Symmetric") + " "  + " indefinite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
if (sord)  {
    System.out.println("    " + "1. Diagonal"  + "                        " + "6. Last n/2 rows and columns zero"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Last row and column zero"  + "        " + "9. Scaled near underflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "10. Scaled near overflow" );
}              // Close if()
else  {
  System.out.println("    " + "1. Diagonal"  + "                        " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "9. Scaled near underflow"  + "\n"  + "    " + "4. Last row and column zero"  + "       " + "10. Scaled near overflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "11. Block diagonal matrix"  + "\n"  + "    " + "6. Last n/2 rows and columns zero" );
}              //  Close else.
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U*D*U\' - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"HE",0,2) || p2.regionMatches(true,0,"HP",0,2))  {
    // *
// *        HE: Hermitian indefinite full
// *        HP: Hermitian indefinite packed
// *
if ((c3.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Hermitian") + " "  + " indefinite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " drivers:  "  + ("Hermitian") + " "  + " indefinite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "6. Last n/2 rows and columns zero"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Last row and column zero"  + "        " + "9. Scaled near underflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "10. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U*D*U\' - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else  {
  // *
// *        Print error message if no header is available.
// *
System.out.println("\n"  + " " + (path) + " "  + ":  No header available" );
}              //  Close else.
// *
// *     First line of header
// *
// *
// *     GE matrix types
// *
// *
// *     GB matrix types
// *
// *
// *     GT matrix types
// *
// *
// *     PT matrix types
// *
// *
// *     PO, PP matrix types
// *
// *
// *     PB matrix types
// *
// *
// *     SSY, SSP, CHE, CHP matrix types
// *
// *
// *     CSY, CSP matrix types
// *
// *
// *     Test ratios
// *
// *
Dummy.go_to("Aladhd",999999);
// *
// *     End of ALADHD
// *
Dummy.label("Aladhd",999999);
return;
   }
} // End class.
