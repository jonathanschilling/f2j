/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alaerh {

// *
// *  -- LAPACK auxiliary test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALAERH is an error handler for the LAPACK routines.  It prints the
// *  header if this is the first error message and prints the error code
// *  and form of recovery, if any.  The character evaluations in this
// *  routine may make it slow, but it should not be called once the LAPACK
// *  routines are fully debugged.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name of subroutine SUBNAM.
// *
// *  SUBNAM  (input) CHARACTER*6
// *          The name of the subroutine that returned an error code.
// *
// *  INFO    (input) INTEGER
// *          The error code returned from routine SUBNAM.
// *
// *  INFOE   (input) INTEGER
// *          The expected error code from routine SUBNAM, if SUBNAM were
// *          error-free.  If INFOE = 0, an error message is printed, but
// *          if INFOE.NE.0, we assume only the return code INFO is wrong.
// *
// *  OPTS    (input) CHARACTER*(*)
// *          The character options to the subroutine SUBNAM, concatenated
// *          into a single character string.  For example, UPLO = 'U',
// *          TRANS = 'T', and DIAG = 'N' for a triangular routine would
// *          be specified as OPTS = 'UTN'.
// *
// *  M       (input) INTEGER
// *          The matrix row dimension.
// *
// *  N       (input) INTEGER
// *          The matrix column dimension.  Accessed only if PATH = xGE or
// *          xGB.
// *
// *  KL      (input) INTEGER
// *          The number of sub-diagonals of the matrix.  Accessed only if
// *          PATH = xGB, xPB, or xTB.  Also used for NRHS for PATH = xLS.
// *
// *  KU      (input) INTEGER
// *          The number of super-diagonals of the matrix.  Accessed only
// *          if PATH = xGB.
// *
// *  N5      (input) INTEGER
// *          A fifth integer parameter, may be the blocksize NB or the
// *          number of right hand sides NRHS.
// *
// *  IMAT    (input) INTEGER
// *          The matrix type.
// *
// *  NFAIL   (input) INTEGER
// *          The number of prior tests that did not pass the threshold;
// *          used to determine if the header should be printed.
// *
// *  NERRS   (input/output) INTEGER
// *          On entry, the number of errors already detected; used to
// *          determine if the header should be printed.
// *          On exit, NERRS is increased by 1.
// *
// *  NOUT    (input) INTEGER
// *          The unit number on which results are to be printed.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static String uplo= new String(" ");
static String p2= new String("  ");
static String c3= new String("   ");
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void alaerh (String path,
String subnam,
int info,
int infoe,
String opts,
int m,
int n,
int kl,
int ku,
int n5,
int imat,
int nfail,
intW nerrs,
int nout)  {

if (info == 0)  
    Dummy.go_to("Alaerh",999999);
p2 = path.substring((2)-1,3);
c3 = subnam.substring((4)-1,6);
// *
// *     Print the header if this is the first error message.
// *
if (nfail == 0 && nerrs.val == 0)  {
    if (c3.regionMatches(true,0,"SV ",0,3) || c3.regionMatches(true,0,"SVX",0,3))  {
    Aladhd.aladhd(nout,path);
}              // Close if()
else  {
  Alahd.alahd(nout,path);
}              //  Close else.
}              // Close if()
nerrs.val = nerrs.val+1;
// *
// *     Print the message detailing the error and form of recovery,
// *     if any.
// *
if (p2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        xGE:  General matrices
// *
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + " for M="  + (m) + " "  + ", N="  + (n) + " "  + ", NB="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"TRI",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + " for N="  + (n) + " "  + ", NB="  + (n5) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for NORM = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"LS ",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> TRANS = \'"  + (opts.substring((1)-1,1)) + " "  + "\', M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"LSX",0,3) || c3.regionMatches(true,0,"LSS",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> TRANS = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close if()
else if (p2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        xGB:  General band matrices
// *
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> M = "  + (m) + " "  + ", N ="  + (n) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> M = "  + (m) + " "  + ", N ="  + (n) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> N ="  + (n) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> N ="  + (n) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N="  + (n) + " "  + ", KL="  + (kl) + " "  + ", KU="  + (ku) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N="  + (n) + " "  + ", KL="  + (kl) + " "  + ", KU="  + (ku) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> M = "  + (m) + " "  + ", N ="  + (n) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> NORM =\'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> TRANS=\'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", KL ="  + (kl) + " "  + ", KU ="  + (ku) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        xGT:  General tridiagonal matrices
// *
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + " for N="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for NORM = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> TRANS = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PO",0,2))  {
    // *
// *        xPO:  Symmetric or Hermitian positive definite matrices
// *
uplo = opts.substring((1)-1,1);
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"TRI",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5) || c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"SY",0,2) || p2.regionMatches(true,0,"HE",0,2))  {
    // *
// *        xHE, or xSY:  Symmetric or Hermitian indefinite matrices
// *
uplo = opts.substring((1)-1,1);
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5) || c3.regionMatches(true,0,"TRI",0,3) || c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PP",0,2) || p2.regionMatches(true,0,"SP",0,2) || p2.regionMatches(true,0,"HP",0,2))  {
    // *
// *        xPP, xHP, or xSP:  Symmetric or Hermitian packed matrices
// *
uplo = opts.substring((1)-1,1);
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5) || c3.regionMatches(true,0,"TRI",0,3) || c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        xPB:  Symmetric (Hermitian) positive definite band matrix
// *
uplo = opts.substring((1)-1,1);
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", KD ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", KD ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> UPLO=\'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", KD ="  + (kl) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", KD ="  + (kl) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N="  + (n) + " "  + ", KD="  + (kl) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO=\'"  + (opts.substring((2)-1,2)) + " "  + "\', N="  + (n) + " "  + ", KD="  + (kl) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5) || c3.regionMatches(true,0,"CON",0,3))  {
    // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", KD ="  + (kl) + " "  + ", type "  + (imat) + " " );
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> UPLO = \'"  + (uplo) + " "  + "\', N ="  + (m) + " "  + ", KD ="  + (kl) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        xPT:  Positive definite tridiagonal matrices
// *
if (c3.regionMatches(true,0,"TRF",0,3))  {
    if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + " for N="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
if (info != 0)  
    System.out.println(" ==> Doing only the condition estimate for this case" );
// *
}              // Close if()
else if (c3.regionMatches(true,0,"SV ",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"SVX",0,3))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (n) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + ", FACT=\'"  + (opts.substring((1)-1,1)) + " "  + "\', N="  + (n) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    // *
if ((subnam.substring((1)-1,1).toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (subnam.substring((1)-1,1).toLowerCase().charAt(0) == "D".toLowerCase().charAt(0)))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for NORM = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else  {
  // *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> TRANS = \'"  + (opts.substring((1)-1,1)) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TR",0,2))  {
    // *
// *        xTR:  Triangular matrix
// *
if (c3.regionMatches(true,0,"TRI",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', DIAG =\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> NORM=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO =\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATRS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', NORMIN=\'"  + (opts.substring((4)-1,4)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        xTP:  Triangular packed matrix
// *
if (c3.regionMatches(true,0,"TRI",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', DIAG =\'"  + (opts.substring((2)-1,2)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (c3.regionMatches(true,0,"CON",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> NORM=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO =\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATPS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', NORMIN=\'"  + (opts.substring((4)-1,4)) + " "  + "\', N ="  + (m) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N ="  + (m) + " "  + ", NRHS ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        xTB:  Triangular band matrix
// *
if (c3.regionMatches(true,0,"CON",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> NORM=\'"  + (opts.substring((1)-1,1)) + " "  + "\', UPLO =\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N="  + (m) + " "  + ", KD="  + (kl) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATBS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', NORMIN=\'"  + (opts.substring((4)-1,4)) + " "  + "\', N="  + (m) + " "  + ", KD="  + (kl) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + "\n"  + " ==> UPLO=\'"  + (opts.substring((1)-1,1)) + " "  + "\', TRANS=\'"  + (opts.substring((2)-1,2)) + " "  + "\', DIAG=\'"  + (opts.substring((3)-1,3)) + " "  + "\', N="  + (m) + " "  + ", KD="  + (kl) + " "  + ", NRHS="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QR",0,2))  {
    // *
// *        xQR:  QR factorization
// *
if (c3.regionMatches(true,0,"QRS",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"LQ",0,2))  {
    // *
// *        xLQ:  LQ factorization
// *
if (c3.regionMatches(true,0,"LQS",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QL",0,2))  {
    // *
// *        xQL:  QL factorization
// *
if (c3.regionMatches(true,0,"QLS",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"RQ",0,2))  {
    // *
// *        xRQ:  RQ factorization
// *
if (c3.regionMatches(true,0,"RQS",0,3))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NRHS ="  + (kl) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else if (subnam.substring((2)-1,6).regionMatches(true,0,"LATMS",0,5))  {
    System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " "  + " for M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " " );
}              // Close else if()
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"LU",0,2))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + " for M="  + (m) + " "  + ", N="  + (n) + " "  + ", NB="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"CH",0,2))  {
    // *
if (info != infoe && infoe != 0)  {
    System.out.println(" *** "  + (subnam) + " "  + " returned with INFO ="  + (info) + " "  + " instead of "  + (infoe) + " "  + "\n"  + " ==> N ="  + (m) + " "  + ", NB ="  + (n5) + " "  + ", type "  + (imat) + " " );
}              // Close if()
else  {
  System.out.println(" *** Error code from "  + (subnam) + " "  + "="  + (info) + " "  + " for N="  + (m) + " "  + ", NB="  + (n5) + " "  + ", type "  + (imat) + " " );
}              //  Close else.
// *
}              // Close else if()
else  {
  // *
// *        Print a generic message if the path is unknown.
// *
System.out.println(" *** Error code from "  + (subnam) + " "  + " ="  + (info) + " " );
}              //  Close else.
// *
// *     Description of error message (alphabetical, left to right)
// *
// *     SUBNAM, INFO, FACT, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, FACT, TRANS, N, KL, KU, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, FACT, TRANS, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, FACT, UPLO, N, KD, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, FACT, UPLO, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, FACT, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, FACT, TRANS, N, KL, KU, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, FACT, TRANS, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, FACT, UPLO, N, KD, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, FACT, UPLO, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, M, N, KL, KU, NB, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, M, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, N, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, N, KL, KU, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, UPLO, N, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, UPLO, N, KD, NB, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, UPLO, N, KD, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, UPLO, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, INFOE, UPLO, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, M, N, IMAT
// *
// *
// *     SUBNAM, INFO, M, N, KL, KU, IMAT
// *
// *
// *     SUBNAM, INFO, M, N, KL, KU, NB, IMAT
// *
// *
// *     SUBNAM, INFO, M, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, M, N, NRHS, NB, IMAT
// *
// *
// *     SUBNAM, INFO, N, IMAT
// *
// *
// *     SUBNAM, INFO, N, KL, KU, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, NORM, N, IMAT
// *
// *
// *     SUBNAM, INFO, NORM, N, KL, KU, IMAT
// *
// *
// *     SUBNAM, INFO, NORM, UPLO, DIAG, N, IMAT
// *
// *
// *     SUBNAM, INFO, NORM, UPLO, DIAG, N, KD, IMAT
// *
// *
// *     SUBNAM, INFO, TRANS, M, N, NRHS, NB, IMAT
// *
// *
// *     SUBNAM, INFO, TRANS, N, KL, KU, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, TRANS, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, DIAG, N, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, DIAG, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, KD, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, KD, NB, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, KD, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, NB, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, TRANS, DIAG, N, KD, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, TRANS, DIAG, N, NRHS, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, TRANS, DIAG, NORMIN, N, IMAT
// *
// *
// *     SUBNAM, INFO, UPLO, TRANS, DIAG, NORMIN, N, KD, IMAT
// *
// *
// *     Unknown type
// *
// *
// *     What we do next
// *
// *
Dummy.go_to("Alaerh",999999);
// *
// *     End of ALAERH
// *
Dummy.label("Alaerh",999999);
return;
   }
} // End class.
