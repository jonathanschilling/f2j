/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alaesm {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALAESM prints a summary of results from one of the -ERR- routines.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name.
// *
// *  OK      (input) LOGICAL
// *          The flag from CHKXER that indicates whether or not the tests
// *          of error exits passed.
// *
// *  NOUT    (input) INTEGER
// *          The unit number on which results are to be printed.
// *          NOUT >= 0.
// *
// *  =====================================================================
// *
// *     .. Executable Statements ..
// *

public static void alaesm (String path,
boolean ok,
int nout)  {

if (ok)  {
    System.out.println(" " + (path) + " "  + " routines passed the tests of the error exits" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " routines failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
Dummy.go_to("Alaesm",999999);
// *
// *     End of ALAESM
// *
Dummy.label("Alaesm",999999);
return;
   }
} // End class.
