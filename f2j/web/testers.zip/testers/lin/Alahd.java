/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alahd {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALAHD prints header information for the different test paths.
// *
// *  Arguments
// *  =========
// *
// *  IOUNIT  (input) INTEGER
// *          The unit number to which the header information should be
// *          printed.
// *
// *  PATH    (input) CHARACTER*3
// *          The name of the path for which the header information is to
// *          be printed.  Current paths are
// *             _GE:  General matrices
// *             _GB:  General band
// *             _GT:  General Tridiagonal
// *             _PO:  Symmetric or Hermitian positive definite
// *             _PP:  Symmetric or Hermitian positive definite packed
// *             _PB:  Symmetric or Hermitian positive definite band
// *             _PT:  Symmetric or Hermitian positive definite tridiagonal
// *             _SY:  Symmetric indefinite
// *             _SP:  Symmetric indefinite packed
// *             _HE:  (complex) Hermitian indefinite
// *             _HP:  (complex) Hermitian indefinite packed
// *             _TR:  Triangular
// *             _TP:  Triangular packed
// *             _TB:  Triangular band
// *             _QR:  QR (general matrices)
// *             _LQ:  LQ (general matrices)
// *             _QL:  QL (general matrices)
// *             _RQ:  RQ (general matrices)
// *             _QP:  QR with column pivoting
// *             _TZ:  Trapezoidal
// *             _LS:  Least Squares driver routines
// *             _LU:  LU variants
// *             _CH:  Cholesky variants
// *             _QS:  QR variants
// *          The first character must be one of S, D, C, or Z (C or Z only
// *          if complex).
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean corz= false;
static boolean sord= false;
static String c1= new String(" ");
static String c3= new String(" ");
static String p2= new String("  ");
static String subnam= new String("      ");
static String sym= new String("         ");
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void alahd (int iounit,
String path)  {

if (iounit <= 0)  
    Dummy.go_to("Alahd",999999);
c1 = path.substring((1)-1,1);
c3 = path.substring((3)-1,3);
p2 = path.substring((2)-1,3);
sord = (c1.toLowerCase().charAt(0) == "S".toLowerCase().charAt(0)) || (c1.toLowerCase().charAt(0) == "D".toLowerCase().charAt(0));
corz = (c1.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)) || (c1.toLowerCase().charAt(0) == "Z".toLowerCase().charAt(0));
if (!(sord || corz))  
    Dummy.go_to("Alahd",999999);
// *
if (p2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        GE: General dense
// *
System.out.println("\n"  + " " + (path) + " "  + ":  General dense matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "7. Last n/2 columns zero"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "8. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "9. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "             " + "10. Scaled near underflow"  + "\n"  + "    " + "5. First column zero"  + "              " + "11. Scaled near overflow"  + "\n"  + "    " + "6. Last column zero" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - A*AINV ) / "  + "( N * norm(A) * norm(AINV) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (6) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (7) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (8) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close if()
else if (p2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        GB: General band
// *
System.out.println("\n"  + " " + (path) + " "  + ":  General band matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Random, CNDNUM = 2"  + "              " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. First column zero"  + "               " + "6. Random, CNDNUM = .01/EPS"  + "\n"  + "    " + "3. Last column zero"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Last n/2 columns zero"  + "           " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        GT: General tridiagonal
// *
System.out.println("\n"  + " " + (path) + " "  + ":  General tridiagonal" );
System.out.println(" Matrix types (1-6 have specified condition numbers):"  + "\n"  + "    " + "1. Diagonal"  + "                        " + "7. Random, unspecified CNDNUM"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. First column zero"  + "\n"  + "    " + "3. Random, CNDNUM = sqrt(0.1/EPS)"  + "  " + "9. Last column zero"  + "\n"  + "    " + "4. Random, CNDNUM = 0.1/EPS"  + "       " + "10. Last n/2 columns zero"  + "\n"  + "    " + "5. Scaled near underflow"  + "          " + "11. Scaled near underflow"  + "\n"  + "    " + "6. Scaled near overflow"  + "           " + "12. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PO",0,2) || p2.regionMatches(true,0,"PP",0,2))  {
    // *
// *        PO: Positive definite full
// *        PP: Positive definite packed
// *
if (sord)  {
    sym = "Symmetric";
}              // Close if()
else  {
  sym = "Hermitian";
}              //  Close else.
if ((c3.toLowerCase().charAt(0) == "O".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + ":  "  + (sym) + " "  + " positive definite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  "  + (sym) + " "  + " positive definite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "6. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = 0.1/EPS"  + "\n"  + "   " + "*3. First row and column zero"  + "       " + "8. Scaled near underflow"  + "\n"  + "   " + "*4. Last row and column zero"  + "        " + "9. Scaled near overflow"  + "\n"  + "   " + "*5. Middle row and column zero"  + "\n"  + "   " + "(* - tests error exits from "  + (path) + " "  + "TRF, no test ratios are computed)" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\' * U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L * L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - A*AINV ) / "  + "( N * norm(A) * norm(AINV) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (6) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (7) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (8) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        PB: Positive definite band
// *
if (sord)  {
    System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Symmetric") + " "  + " positive definite band matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Hermitian") + " "  + " positive definite band matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Random, CNDNUM = 2"  + "              " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "   " + "*2. First row and column zero"  + "       " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "   " + "*3. Last row and column zero"  + "        " + "7. Scaled near underflow"  + "\n"  + "   " + "*4. Middle row and column zero"  + "      " + "8. Scaled near overflow"  + "\n"  + "   " + "(* - tests error exits from "  + (path) + " "  + "TRF, no test ratios are computed)" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\' * U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L * L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        PT: Positive definite tridiagonal
// *
if (sord)  {
    System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Symmetric") + " "  + " positive definite tridiagonal" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Hermitian") + " "  + " positive definite tridiagonal" );
}              //  Close else.
System.out.println(" Matrix types (1-6 have specified condition numbers):"  + "\n"  + "    " + "1. Diagonal"  + "                        " + "7. Random, unspecified CNDNUM"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. First row and column zero"  + "\n"  + "    " + "3. Random, CNDNUM = sqrt(0.1/EPS)"  + "  " + "9. Last row and column zero"  + "\n"  + "    " + "4. Random, CNDNUM = 0.1/EPS"  + "       " + "10. Middle row and column zero"  + "\n"  + "    " + "5. Scaled near underflow"  + "          " + "11. Scaled near underflow"  + "\n"  + "    " + "6. Scaled near overflow"  + "           " + "12. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\'*D*U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"SY",0,2) || p2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        SY: Symmetric indefinite full
// *        SP: Symmetric indefinite packed
// *
if ((c3.toLowerCase().charAt(0) == "Y".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Symmetric") + " "  + " indefinite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Symmetric") + " "  + " indefinite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
if (sord)  {
    System.out.println("    " + "1. Diagonal"  + "                        " + "6. Last n/2 rows and columns zero"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Last row and column zero"  + "        " + "9. Scaled near underflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "10. Scaled near overflow" );
}              // Close if()
else  {
  System.out.println("    " + "1. Diagonal"  + "                        " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "9. Scaled near underflow"  + "\n"  + "    " + "4. Last row and column zero"  + "       " + "10. Scaled near overflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "11. Block diagonal matrix"  + "\n"  + "    " + "6. Last n/2 rows and columns zero" );
}              //  Close else.
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U*D*U\' - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - A*AINV ) / "  + "( N * norm(A) * norm(AINV) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (8) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"HE",0,2) || p2.regionMatches(true,0,"HP",0,2))  {
    // *
// *        HE: Hermitian indefinite full
// *        HP: Hermitian indefinite packed
// *
if ((c3.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Hermitian") + " "  + " indefinite matrices" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("Hermitian") + " "  + " indefinite packed matrices" );
}              //  Close else.
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "6. Last n/2 rows and columns zero"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. First row and column zero"  + "       " + "8. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Last row and column zero"  + "        " + "9. Scaled near underflow"  + "\n"  + "    " + "5. Middle row and column zero"  + "     " + "10. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( U*D*U\' - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L*D*L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - A*AINV ) / "  + "( N * norm(A) * norm(AINV) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (8) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TR",0,2) || p2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        TR: Triangular full
// *        TP: Triangular packed
// *
if ((c3.toLowerCase().charAt(0) == "R".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + ":  Triangular matrices" );
subnam = path.substring((1)-1,1)+"LATRS";
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + ":  Triangular packed matrices" );
subnam = path.substring((1)-1,1)+"LATPS";
}              //  Close else.
System.out.println(" Matrix types for "  + (path) + " "  + " routines:"  + "\n"  + "    " + "1. Diagonal"  + "                        " + "6. Scaled near overflow"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Identity"  + "\n"  + "    " + "3. Random, CNDNUM = sqrt(0.1/EPS)  "  + "8. Unit triangular, CNDNUM = 2"  + "\n"  + "    " + "4. Random, CNDNUM = 0.1/EPS"  + "        " + "9. Unit, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "5. Scaled near underflow"  + "          " + "10. Unit, CNDNUM = 0.1/EPS" );
System.out.println(" Special types for testing "  + (subnam) + " "  + ":"  + "\n"  + "   " + "11. Matrix elements are O(1), large right hand side"  + "\n"  + "   " + "12. First diagonal causes overflow,"  + " offdiagonal column norms < 1"  + "\n"  + "   " + "13. First diagonal causes overflow,"  + " offdiagonal column norms > 1"  + "\n"  + "   " + "14. Growth factor underflows, solution does not overflow"  + "\n"  + "   " + "15. Small diagonal causes gradual overflow"  + "\n"  + "   " + "16. One zero diagonal element"  + "\n"  + "   " + "17. Large offdiagonals cause overflow when adding a column"  + "\n"  + "   " + "18. Unit triangular with large right hand side" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( I - A*AINV ) / "  + "( N * norm(A) * norm(AINV) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (5) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (6) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (7) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println(" Test ratio for "  + (subnam) + " "  + ":"  + "\n"  + "   " + (8) + " "  + ": norm( s*b - A*x )  / ( norm(A) * norm(x) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        TB: Triangular band
// *
System.out.println("\n"  + " " + (path) + " "  + ":  Triangular band matrices" );
subnam = path.substring((1)-1,1)+"LATBS";
System.out.println(" Matrix types for "  + (path) + " "  + " routines:"  + "\n"  + "    " + "1. Random, CNDNUM = 2"  + "              " + "6. Identity"  + "\n"  + "    " + "2. Random, CNDNUM = sqrt(0.1/EPS)  "  + "7. Unit triangular, CNDNUM = 2"  + "\n"  + "    " + "3. Random, CNDNUM = 0.1/EPS"  + "        " + "8. Unit, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "4. Scaled near underflow"  + "           " + "9. Unit, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "5. Scaled near overflow" );
System.out.println(" Special types for testing "  + (subnam) + " "  + ":"  + "\n"  + "   " + "10. Matrix elements are O(1), large right hand side"  + "\n"  + "   " + "11. First diagonal causes overflow,"  + " offdiagonal column norms < 1"  + "\n"  + "   " + "12. First diagonal causes overflow,"  + " offdiagonal column norms > 1"  + "\n"  + "   " + "13. Growth factor underflows, solution does not overflow"  + "\n"  + "   " + "14. Small diagonal causes gradual overflow"  + "\n"  + "   " + "15. One zero diagonal element"  + "\n"  + "   " + "16. Large offdiagonals cause overflow when adding a column"  + "\n"  + "   " + "17. Unit triangular with large right hand side" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * CNDNUM * EPS ), refined" );
System.out.println("   " + (4) + " "  + ": norm( X - XACT )   / "  + "( norm(XACT) * (error bound) )" );
System.out.println("   " + (5) + " "  + ": (backward error)   / EPS" );
System.out.println("   " + (6) + " "  + ": RCOND * CNDNUM - 1.0" );
System.out.println(" Test ratio for "  + (subnam) + " "  + ":"  + "\n"  + "   " + (7) + " "  + ": norm( s*b - A*x )  / ( norm(A) * norm(x) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QR",0,2))  {
    // *
// *        QR decomposition of rectangular matrices
// *
System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("QR") + " "  + " factorization of general matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "              " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( R - Q\' * A ) / ( M * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - Q\'*Q )   / ( M * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( Q*C - Q*C )  / "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( C*Q - C*Q )  / "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( Q\'*C - Q\'*C )/ "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (6) + " "  + ": norm( C*Q\' - C*Q\' )/ "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (7) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"LQ",0,2))  {
    // *
// *        LQ decomposition of rectangular matrices
// *
System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("LQ") + " "  + " factorization of general matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "              " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L - A * Q\' ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - Q*Q\' )   / ( N * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( Q*C - Q*C )  / "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( C*Q - C*Q )  / "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( Q\'*C - Q\'*C )/ "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (6) + " "  + ": norm( C*Q\' - C*Q\' )/ "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (7) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QL",0,2))  {
    // *
// *        QL decomposition of rectangular matrices
// *
System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("QL") + " "  + " factorization of general matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "              " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( L - Q\' * A ) / ( M * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - Q\'*Q )   / ( M * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( Q*C - Q*C )  / "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( C*Q - C*Q )  / "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( Q\'*C - Q\'*C )/ "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (6) + " "  + ": norm( C*Q\' - C*Q\' )/ "  + "( "  + ("M") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (7) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"RQ",0,2))  {
    // *
// *        RQ decomposition of rectangular matrices
// *
System.out.println("\n"  + " " + (path) + " "  + ":  "  + ("RQ") + " "  + " factorization of general matrices" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "              " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm( R - A * Q\' ) / ( N * norm(A) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( I - Q*Q\' )   / ( N * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( Q*C - Q*C )  / "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( C*Q - C*Q )  / "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( Q\'*C - Q\'*C )/ "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (6) + " "  + ": norm( C*Q\' - C*Q\' )/ "  + "( "  + ("N") + " "  + " * norm(C) * EPS )" );
System.out.println("   " + (7) + " "  + ": norm( B - A * X )  / "  + "( norm(A) * norm(X) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QP",0,2))  {
    // *
// *        QR decomposition with column pivoting
// *
System.out.println("\n"  + " " + (path) + " "  + ":  QR factorization with column pivoting" );
System.out.println(" Matrix types (2-6 have condition 1/EPS):"  + "\n"  + "    " + "1. Zero matrix"  + "                     " + "4. First n/2 columns fixed"  + "\n"  + "    " + "2. One small eigenvalue"  + "            " + "5. Last n/2 columns fixed"  + "\n"  + "    " + "3. Geometric distribution"  + "          " + "6. Every second column fixed" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm(svd(A) - svd(R)) / "  + "( M * norm(svd(R)) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( A*P - Q*R )     / ( M * norm(A) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( I - Q\'*Q )      / ( M * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"TZ",0,2))  {
    // *
// *        TZ:  Trapezoidal
// *
System.out.println("\n"  + " " + (path) + " "  + ":  RQ factorization of trapezoidal matrix" );
System.out.println(" Matrix types (2-3 have condition 1/EPS):"  + "\n"  + "    " + "1. Zero matrix"  + "\n"  + "    " + "2. One small eigenvalue"  + "\n"  + "    " + "3. Geometric distribution" );
System.out.println("( \' Test ratios:\' )");
System.out.println("   " + (1) + " "  + ": norm(svd(A) - svd(R)) / "  + "( M * norm(svd(R)) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( A - R*Q )       / ( M * norm(A) * EPS )" );
System.out.println("   " + (3) + " "  + ": norm( I - Q\'*Q )      / ( M * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"LS",0,2))  {
    // *
// *        LS:  Least Squares driver routines
// *
System.out.println("\n"  + " " + (path) + " "  + ":  Least squares driver routines" );
System.out.println(" Matrix types (1-3: full rank, 4-6: rank deficient):"  + "\n"  + "    " + "1 and 4. Normal scaling"  + "\n"  + "    " + "2 and 5. Scaled near overflow"  + "\n"  + "    " + "3 and 6. Scaled near underflow" );
System.out.println(" Test ratios (1-2: "  + (c1) + " "  + "GELS, 3-6: "  + (c1) + " "  + "GELSS, 7-10: "  + (c1) + " "  + "GELSX):" );
System.out.println("   " + (1) + " "  + ": norm( B - A * X )   / "  + "( max(M,N) * norm(A) * norm(X) * EPS )" );
System.out.println("   " + (2) + " "  + ": norm( (A*X-B)\' *A ) / "  + "( max(M,N,NRHS) * norm(A) * norm(B) * EPS )"  + "\n"  + "       " + "if TRANS=\'N\' and M.GE.N or TRANS=\'T\' and M.LT.N, "  + "otherwise"  + "\n"  + "       " + "check if X is in the row space of A or A\' "  + "(overdetermined case)" );
System.out.println("   " + (3) + " "  + ": norm(svd(A)-svd(R)) / "  + "( min(M,N) * norm(svd(R)) * EPS )" );
System.out.println("   " + (4) + " "  + ": norm( B - A * X )   / "  + "( max(M,N) * norm(A) * norm(X) * EPS )" );
System.out.println("   " + (5) + " "  + ": norm( (A*X-B)\' *A ) / "  + "( max(M,N,NRHS) * norm(A) * norm(B) * EPS )" );
System.out.println("   " + (6) + " "  + ": Check if X is in the row space of A or A\'" );
System.out.println("   " + " 7-10: same as 3-6" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"LU",0,2))  {
    // *
// *        LU factorization variants
// *
System.out.println("\n"  + " " + (path) + " "  + ":  LU factorization variants" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "7. Last n/2 columns zero"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "8. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "9. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "             " + "10. Scaled near underflow"  + "\n"  + "    " + "5. First column zero"  + "              " + "11. Scaled near overflow"  + "\n"  + "    " + "6. Last column zero" );
System.out.println("( \' Test ratio:\' )");
System.out.println("   " + (1) + " "  + ": norm( L * U - A )  / ( N * norm(A) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"CH",0,2))  {
    // *
// *        Cholesky factorization variants
// *
System.out.println("\n"  + " " + (path) + " "  + ":  Cholesky factorization variants" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "6. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Random, CNDNUM = 2"  + "              " + "7. Random, CNDNUM = 0.1/EPS"  + "\n"  + "   " + "*3. First row and column zero"  + "       " + "8. Scaled near underflow"  + "\n"  + "   " + "*4. Last row and column zero"  + "        " + "9. Scaled near overflow"  + "\n"  + "   " + "*5. Middle row and column zero"  + "\n"  + "   " + "(* - tests error exits, no test ratios are computed)" );
System.out.println("( \' Test ratio:\' )");
System.out.println("   " + (1) + " "  + ": norm( U\' * U - A ) / ( N * norm(A) * EPS )"  + ", or"  + "\n"  + "       " + "norm( L * L\' - A ) / ( N * norm(A) * EPS )" );
System.out.println("( \' Messages:\' )");
// *
}              // Close else if()
else if (p2.regionMatches(true,0,"QS",0,2))  {
    // *
// *        QR factorization variants
// *
System.out.println("\n"  + " " + (path) + " "  + ":  QR factorization variants" );
System.out.println("( \' Matrix types:\' )");
System.out.println("    " + "1. Diagonal"  + "                        " + "5. Random, CNDNUM = sqrt(0.1/EPS)"  + "\n"  + "    " + "2. Upper triangular"  + "                " + "6. Random, CNDNUM = 0.1/EPS"  + "\n"  + "    " + "3. Lower triangular"  + "                " + "7. Scaled near underflow"  + "\n"  + "    " + "4. Random, CNDNUM = 2"  + "              " + "8. Scaled near overflow" );
System.out.println("( \' Test ratios:\' )");
// *
}              // Close else if()
else  {
  // *
// *        Print error message if no header is available.
// *
System.out.println("\n"  + " " + (path) + " "  + ":  No header available" );
}              //  Close else.
// *
// *     First line of header
// *
// *
// *     GE matrix types
// *
// *
// *     GB matrix types
// *
// *
// *     GT matrix types
// *
// *
// *     PT matrix types
// *
// *
// *     PO, PP matrix types
// *
// *
// *     CH matrix types
// *
// *
// *     PB matrix types
// *
// *
// *     SSY, SSP, CHE, CHP matrix types
// *
// *
// *     CSY, CSP matrix types
// *
// *
// *     QR matrix types
// *
// *
// *     QP matrix types
// *
// *
// *     TZ matrix types
// *
// *
// *     LS matrix types
// *
// *
// *     TR, TP matrix types
// *
// *
// *     TB matrix types
// *
// *
// *     Test ratios
// *
// *
Dummy.go_to("Alahd",999999);
// *
// *     End of ALAHD
// *
Dummy.label("Alahd",999999);
return;
   }
} // End class.
