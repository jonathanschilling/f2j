/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alareq {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALAREQ handles input for the LAPACK test program.  It is called
// *  to evaluate the input line which requested NMATS matrix types for
// *  PATH.  The flow of control is as follows:
// *
// *  If NMATS = NTYPES then
// *     DOTYPE(1:NTYPES) = .TRUE.
// *  else
// *     Read the next input line for NMATS matrix types
// *     Set DOTYPE(I) = .TRUE. for each valid type I
// *  endif
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          An LAPACK path name for testing.
// *
// *  NMATS   (input) INTEGER
// *          The number of matrix types to be used in testing this path.
// *
// *  DOTYPE  (output) LOGICAL array, dimension (NTYPES)
// *          The vector of flags indicating if each type will be tested.
// *
// *  NTYPES  (input) INTEGER
// *          The maximum number of matrix types for this path.
// *
// *  NIN     (input) INTEGER
// *          The unit number for input.  NIN >= 1.
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.  NOUT >= 1.
// *
// *  =====================================================================
// *
// *     .. Local Scalars ..
static boolean firstt= false;
static String c1= new String(" ");
static String line= new String("                                                                                ");
static int i= 0;
static int i1= 0;
static int ic= 0;
static int j= 0;
static int k= 0;
static int lenp= 0;
static int nt= 0;
// *     ..
// *     .. Local Arrays ..
static int [] nreq= new int[(100)];
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static String intstr = new String("0123456789");
// *     ..
// *     .. Executable Statements ..
// *

public static void alareq (String path,
int nmats,
boolean [] dotype, int _dotype_offset,
int ntypes,
int nin,
int nout)  {

  EasyIn _f2j_in = new EasyIn();
if (nmats >= ntypes)  {
    // *
// *        Test everything if NMATS >= NTYPES.
// *
{
forloop10:
for (i = 1; i <= ntypes; i++) {
dotype[(i)- 1+ _dotype_offset] = true;
Dummy.label("Alareq",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop20:
for (i = 1; i <= ntypes; i++) {
dotype[(i)- 1+ _dotype_offset] = false;
Dummy.label("Alareq",20);
}              //  Close for() loop. 
}
firstt = true;
// *
// *        Read a line of matrix types if 0 < NMATS < NTYPES.
// *
if (nmats > 0)  {
    try {
line = _f2j_in.readchars(80);
_f2j_in.skipRemaining();
} catch (java.io.IOException e) {
Dummy.go_to("Alareq",90);
}
lenp =  80 ;
i = 0;
{
forloop60:
for (j = 1; j <= nmats; j++) {
nreq[(j)- 1] = 0;
i1 = 0;
label30:
   Dummy.label("Alareq",30);
i = i+1;
if (i > lenp)  {
    if (j == nmats && i1 > 0)  {
    continue forloop60;
}              // Close if()
else  {
  System.out.println("\n\n"  + " *** Not enough matrix types on input line"  + "\n"  + (line) + " " );
System.out.println(" ==> Specify "  + (nmats) + " "  + " matrix types on this line or "  + "adjust NTYPES on previous line" );
Dummy.go_to("Alareq",80);
}              //  Close else.
}              // Close if()
if (!line.substring((i)-1,i).trim().equalsIgnoreCase(" ".trim()) && !line.substring((i)-1,i).trim().equalsIgnoreCase(",".trim()))  {
    i1 = i;
c1 = line.substring((i1)-1,i1);
// *
// *              Check that a valid integer was read
// *
{
forloop40:
for (k = 1; k <= 10; k++) {
if (c1.trim().equalsIgnoreCase(intstr.substring((k)-1,k).trim()))  {
    ic = k-1;
Dummy.go_to("Alareq",50);
}              // Close if()
Dummy.label("Alareq",40);
}              //  Close for() loop. 
}
System.out.println("\n\n"  + " *** Invalid integer value in column "  + (i) + " "  + " of input"  + " line:"  + "\n"  + (line) + " " );
System.out.println(" ==> Specify "  + (nmats) + " "  + " matrix types on this line or "  + "adjust NTYPES on previous line" );
Dummy.go_to("Alareq",80);
label50:
   Dummy.label("Alareq",50);
nreq[(j)- 1] = 10*nreq[(j)- 1]+ic;
Dummy.go_to("Alareq",30);
}              // Close if()
else if (i1 > 0)  {
    continue forloop60;
}              // Close else if()
else  {
  Dummy.go_to("Alareq",30);
}              //  Close else.
Dummy.label("Alareq",60);
}              //  Close for() loop. 
}
}              // Close if()
{
forloop70:
for (i = 1; i <= nmats; i++) {
nt = nreq[(i)- 1];
if (nt > 0 && nt <= ntypes)  {
    if (dotype[(nt)- 1+ _dotype_offset])  {
    if (firstt)  
    System.out.println();
firstt = false;
System.out.println(" *** Warning:  duplicate request of matrix type "  + (nt) + " "  + " for "  + (path) + " " );
}              // Close if()
dotype[(nt)- 1+ _dotype_offset] = true;
}              // Close if()
else  {
  System.out.println(" *** Invalid type request for "  + (path) + " "  + ", type  "  + (nt) + " "  + ": must satisfy  1 <= type <= "  + (ntypes) + " " );
}              //  Close else.
Dummy.label("Alareq",70);
}              //  Close for() loop. 
}
label80:
   Dummy.label("Alareq",80);
}              //  Close else.
Dummy.go_to("Alareq",999999);
// *
label90:
   Dummy.label("Alareq",90);
System.out.println("\n"  + " *** End of file reached when trying to read matrix "  + "types for "  + (path) + " "  + "\n"  + " *** Check that you are requesting the"  + " right number of types for each path"  + "\n" );
System.out.println();
System.exit(1);
// *
// *     End of ALAREQ
// *
Dummy.label("Alareq",999999);
return;
   }
} // End class.
