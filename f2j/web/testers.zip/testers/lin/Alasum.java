/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Alasum {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  ALASUM prints a summary of results from one of the -CHK- routines.
// *
// *  Arguments
// *  =========
// *
// *  TYPE    (input) CHARACTER*3
// *          The LAPACK path name.
// *
// *  NOUT    (input) INTEGER
// *          The unit number on which results are to be printed.
// *          NOUT >= 0.
// *
// *  NFAIL   (input) INTEGER
// *          The number of tests which did not pass the threshold ratio.
// *
// *  NRUN    (input) INTEGER
// *          The total number of tests.
// *
// *  NERRS   (input) INTEGER
// *          The number of error messages recorded.
// *
// *  =====================================================================
// *
// *     .. Executable Statements ..
// *

public static void alasum (String type,
int nout,
int nfail,
int nrun,
int nerrs)  {

if (nfail > 0)  {
    System.out.println(" " + (type) + " "  + ": "  + (nfail) + " "  + " out of "  + (nrun) + " "  + " tests failed to pass the threshold" );
}              // Close if()
else  {
  System.out.println("\n"  + " " + "All tests for "  + (type) + " "  + " routines passed the threshold ("  + (nrun) + " "  + " tests run)" );
}              //  Close else.
if (nerrs > 0)  {
    System.out.println("      " + (nerrs) + " "  + " error messages recorded" );
}              // Close if()
// *
Dummy.go_to("Alasum",999999);
// *
// *     End of ALASUM
// *
Dummy.label("Alasum",999999);
return;
   }
} // End class.
