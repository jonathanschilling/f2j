/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkaa {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *  Purpose
// *  =======
// *
// *  DCHKAA is the main test program for the DOUBLE PRECISION LAPACK
// *  linear equation routines
// *
// *  The program must be driven by a short data file. The first 14 records
// *  specify problem dimensions and program options using list-directed
// *  input.  The remaining lines specify the LAPACK test paths and the
// *  number of matrix types to use in testing.  An annotated example of a
// *  data file can be obtained by deleting the first 3 characters from the
// *  following 36 lines:
// *  Data file for testing DOUBLE PRECISION LAPACK linear eqn. routines
// *  7                      Number of values of M
// *  0 1 2 3 5 10 16        Values of M (row dimension)
// *  7                      Number of values of N
// *  0 1 2 3 5 10 16        Values of N (column dimension)
// *  1                      Number of values of NRHS
// *  2                      Values of NRHS (number of right hand sides)
// *  5                      Number of values of NB
// *  1 3 3 3 20             Values of NB (the blocksize)
// *  1 0 5 9 1              Values of NX (crossover point)
// *  20.0                   Threshold value of test ratio
// *  T                      Put T to test the LAPACK routines
// *  T                      Put T to test the driver routines
// *  T                      Put T to test the error exits
// *  DGE   11               List types on next line if 0 < NTYPES < 11
// *  DGB    8               List types on next line if 0 < NTYPES <  8
// *  DGT   12               List types on next line if 0 < NTYPES < 12
// *  DPO    9               List types on next line if 0 < NTYPES <  9
// *  DPP    9               List types on next line if 0 < NTYPES <  9
// *  DPB    8               List types on next line if 0 < NTYPES <  8
// *  DPT   12               List types on next line if 0 < NTYPES < 12
// *  DSY   10               List types on next line if 0 < NTYPES < 10
// *  DSP   10               List types on next line if 0 < NTYPES < 10
// *  DTR   18               List types on next line if 0 < NTYPES < 18
// *  DTP   18               List types on next line if 0 < NTYPES < 18
// *  DTB   17               List types on next line if 0 < NTYPES < 17
// *  DQR    8               List types on next line if 0 < NTYPES <  8
// *  DRQ    8               List types on next line if 0 < NTYPES <  8
// *  DLQ    8               List types on next line if 0 < NTYPES <  8
// *  DQL    8               List types on next line if 0 < NTYPES <  8
// *  DQP    6               List types on next line if 0 < NTYPES <  6
// *  DTZ    3               List types on next line if 0 < NTYPES <  3
// *  DLS    6               List types on next line if 0 < NTYPES <  6
// *  DEQ
// *
// *  Internal Parameters
// *  ===================
// *
// *  NMAX    INTEGER
// *          The maximum allowable value for N
// *
// *  MAXIN   INTEGER
// *          The number of different values that can be used for each of
// *          M, N, NRHS, NB, and NX
// *
// *  MAXRHS  INTEGER
// *          The maximum number of right hand sides
// *
// *  NIN     INTEGER
// *          The unit number for input
// *
// *  NOUT    INTEGER
// *          The unit number for output
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 132;
static int maxin= 12;
static int maxrhs= 10;
static int matmax= 30;
static int nin= 5;
static int nout= 6;
static int kdmax= nmax+(nmax+1)/4;
// *     ..
// *     .. Local Scalars ..
static boolean fatal= false;
static boolean tstchk= false;
static boolean tstdrv= false;
static boolean tsterr= false;
static String c1= new String(" ");
static String c2= new String("  ");
static String path= new String("   ");
static String aline= new String("                                                                        ");
static int i= 0;
static int ic= 0;
static int j= 0;
static int k= 0;
static int la= 0;
static int lafac= 0;
static int lda= 0;
static int nb= 0;
static int nm= 0;
static int nmats= 0;
static int nn= 0;
static int nnb= 0;
static int nnb2= 0;
static int nns= 0;
static int nrhs= 0;
static int ntypes= 0;
static double eps= 0.0;
static double s1= 0.0;
static double s2= 0.0;
static double thresh= 0.0;
// *     ..
// *     .. Local Arrays ..
static boolean [] dotype= new boolean[(matmax)];
static int [] iwork= new int[(3*nmax)];
static int [] mval= new int[(maxin)];
static int [] nbval= new int[(maxin)];
static int [] nbval2= new int[(maxin)];
static int [] nsval= new int[(maxin)];
static int [] nval= new int[(maxin)];
static int [] nxval= new int[(maxin)];
static double [] a= new double[((kdmax+1)*nmax) * (7)];
static double [] b= new double[(nmax*maxrhs) * (4)];
static double [] rwork= new double[(5*nmax+2*maxrhs)];
static double [] s= new double[(2*nmax)];
static double [] work= new double[(nmax) * (nmax+maxrhs+5)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Arrays in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String intstr = new String("0123456789");
static double threq = 2.0e0;
// *     ..
// *     .. Executable Statements ..
// *

public static void main (String [] args)  {

  EasyIn _f2j_in = new EasyIn();
s1 = Dsecnd.dsecnd();
lda = nmax;
fatal = false;
// *
// *     Read a dummy line.
// *
_f2j_in.readString();  // skip a line
// *
// *     Report values of parameters.
// *
System.out.println(" Tests of the DOUBLE PRECISION LAPACK routines "  + "\n"  + " LAPACK VERSION 2.0, released September 30, 1994 "  + "\n\n"  + " The following parameter values will be used:" );
// *
// *     Read the values of M
// *
nm = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nm < 1)  {
    System.out.println(" Invalid input value: "  + (" NM ") + " "  + "="  + (nm) + " "  + "; must be >="  + (1) + " " );
nm = 0;
fatal = true;
}              // Close if()
else if (nm > maxin)  {
    System.out.println(" Invalid input value: "  + (" NM ") + " "  + "="  + (nm) + " "  + "; must be <="  + (maxin) + " " );
nm = 0;
fatal = true;
}              // Close else if()
for(i = 1; i <= nm; i++)
mval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop10:
for (i = 1; i <= nm; i++) {
if (mval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" M  ") + " "  + "="  + (mval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (mval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + (" M  ") + " "  + "="  + (mval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkaa",10);
}              //  Close for() loop. 
}
if (nm > 0)  
    System.out.print(("M   ") + " ");
for(i = 1; i <= nm; i++)
  System.out.print(mval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the values of N
// *
nn = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nn < 1)  {
    System.out.println(" Invalid input value: "  + (" NN ") + " "  + "="  + (nn) + " "  + "; must be >="  + (1) + " " );
nn = 0;
fatal = true;
}              // Close if()
else if (nn > maxin)  {
    System.out.println(" Invalid input value: "  + (" NN ") + " "  + "="  + (nn) + " "  + "; must be <="  + (maxin) + " " );
nn = 0;
fatal = true;
}              // Close else if()
for(i = 1; i <= nn; i++)
nval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop20:
for (i = 1; i <= nn; i++) {
if (nval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" N  ") + " "  + "="  + (nval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nval[(i)- 1] > nmax)  {
    System.out.println(" Invalid input value: "  + (" N  ") + " "  + "="  + (nval[(i)- 1]) + " "  + "; must be <="  + (nmax) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkaa",20);
}              //  Close for() loop. 
}
if (nn > 0)  
    System.out.print(("N   ") + " ");
for(i = 1; i <= nn; i++)
  System.out.print(nval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the values of NRHS
// *
nns = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nns < 1)  {
    System.out.println(" Invalid input value: "  + (" NNS") + " "  + "="  + (nns) + " "  + "; must be >="  + (1) + " " );
nns = 0;
fatal = true;
}              // Close if()
else if (nns > maxin)  {
    System.out.println(" Invalid input value: "  + (" NNS") + " "  + "="  + (nns) + " "  + "; must be <="  + (maxin) + " " );
nns = 0;
fatal = true;
}              // Close else if()
for(i = 1; i <= nns; i++)
nsval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop30:
for (i = 1; i <= nns; i++) {
if (nsval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + ("NRHS") + " "  + "="  + (nsval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
else if (nsval[(i)- 1] > maxrhs)  {
    System.out.println(" Invalid input value: "  + ("NRHS") + " "  + "="  + (nsval[(i)- 1]) + " "  + "; must be <="  + (maxrhs) + " " );
fatal = true;
}              // Close else if()
Dummy.label("Dchkaa",30);
}              //  Close for() loop. 
}
if (nns > 0)  
    System.out.print(("NRHS") + " ");
for(i = 1; i <= nns; i++)
  System.out.print(nsval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the values of NB
// *
nnb = _f2j_in.readInt();
_f2j_in.skipRemaining();
if (nnb < 1)  {
    System.out.println(" Invalid input value: "  + ("NNB ") + " "  + "="  + (nnb) + " "  + "; must be >="  + (1) + " " );
nnb = 0;
fatal = true;
}              // Close if()
else if (nnb > maxin)  {
    System.out.println(" Invalid input value: "  + ("NNB ") + " "  + "="  + (nnb) + " "  + "; must be <="  + (maxin) + " " );
nnb = 0;
fatal = true;
}              // Close else if()
for(i = 1; i <= nnb; i++)
nbval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop40:
for (i = 1; i <= nnb; i++) {
if (nbval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" NB ") + " "  + "="  + (nbval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
Dummy.label("Dchkaa",40);
}              //  Close for() loop. 
}
if (nnb > 0)  
    System.out.print(("NB  ") + " ");
for(i = 1; i <= nnb; i++)
  System.out.print(nbval[(i)- 1] + " ");

System.out.println();
// *
// *     Set NBVAL2 to be the set of unique values of NB
// *
nnb2 = 0;
{
forloop60:
for (i = 1; i <= nnb; i++) {
nb = nbval[(i)- 1];
{
forloop50:
for (j = 1; j <= nnb2; j++) {
if (nb == nbval2[(j)- 1])  
    continue forloop60;
Dummy.label("Dchkaa",50);
}              //  Close for() loop. 
}
nnb2 = nnb2+1;
nbval2[(nnb2)- 1] = nb;
Dummy.label("Dchkaa",60);
}              //  Close for() loop. 
}
// *
// *     Read the values of NX
// *
for(i = 1; i <= nnb; i++)
nxval[(i)- 1] = _f2j_in.readInt();
_f2j_in.skipRemaining();
{
forloop70:
for (i = 1; i <= nnb; i++) {
if (nxval[(i)- 1] < 0)  {
    System.out.println(" Invalid input value: "  + (" NX ") + " "  + "="  + (nxval[(i)- 1]) + " "  + "; must be >="  + (0) + " " );
fatal = true;
}              // Close if()
Dummy.label("Dchkaa",70);
}              //  Close for() loop. 
}
if (nnb > 0)  
    System.out.print(("NX  ") + " ");
for(i = 1; i <= nnb; i++)
  System.out.print(nxval[(i)- 1] + " ");

System.out.println();
// *
// *     Read the threshold value for the test ratios.
// *
thresh = _f2j_in.readDouble();
_f2j_in.skipRemaining();
System.out.println("\n"  + " Routines pass computational tests if test ratio is "  + "less than"  + (thresh) + " "  + "\n" );
// *
// *     Read the flag that indicates whether to test the LAPACK routines.
// *
tstchk = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *
// *     Read the flag that indicates whether to test the driver routines.
// *
tstdrv = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *
// *     Read the flag that indicates whether to test the error exits.
// *
tsterr = _f2j_in.readBoolean();
_f2j_in.skipRemaining();
// *
if (fatal)  {
    System.out.println("\n"  + " Execution not attempted due to input errors" );
System.exit(1);
}              // Close if()
// *
// *     Calculate and print the machine dependent constants.
// *
eps = Dlamch.dlamch("Underflow threshold");
System.out.println(" Relative machine "  + ("underflow") + " "  + " is taken to be"  + (eps) + " " );
eps = Dlamch.dlamch("Overflow threshold");
System.out.println(" Relative machine "  + ("overflow ") + " "  + " is taken to be"  + (eps) + " " );
eps = Dlamch.dlamch("Epsilon");
System.out.println(" Relative machine "  + ("precision") + " "  + " is taken to be"  + (eps) + " " );
System.out.println();
// *
label80:
   Dummy.label("Dchkaa",80);
// *
// *     Read a test path and the number of matrix types to use.
// *
try {
aline = _f2j_in.readchars(72);
_f2j_in.skipRemaining();
} catch (java.io.IOException e) {
Dummy.go_to("Dchkaa",140);
}
path = aline.substring((1)-1,3);
nmats = matmax;
i = 3;
label90:
   Dummy.label("Dchkaa",90);
i = i+1;
if (i > 72)  {
    nmats = matmax;
Dummy.go_to("Dchkaa",130);
}              // Close if()
if (aline.substring((i)-1,i).trim().equalsIgnoreCase(" ".trim()))  
    Dummy.go_to("Dchkaa",90);
nmats = 0;
label100:
   Dummy.label("Dchkaa",100);
c1 = aline.substring((i)-1,i);
{
forloop110:
for (k = 1; k <= 10; k++) {
if (c1.trim().equalsIgnoreCase(intstr.substring((k)-1,k).trim()))  {
    ic = k-1;
Dummy.go_to("Dchkaa",120);
}              // Close if()
Dummy.label("Dchkaa",110);
}              //  Close for() loop. 
}
Dummy.go_to("Dchkaa",130);
label120:
   Dummy.label("Dchkaa",120);
nmats = nmats*10+ic;
i = i+1;
if (i > 72)  
    Dummy.go_to("Dchkaa",130);
Dummy.go_to("Dchkaa",100);
label130:
   Dummy.label("Dchkaa",130);
c1 = path.substring((1)-1,1);
c2 = path.substring((2)-1,3);
nrhs = nsval[(1)- 1];
// *
// *     Check first character for correct precision.
// *
if (!(c1.toLowerCase().charAt(0) == "Double precision".toLowerCase().charAt(0)))  {
    System.out.println("\n"  + " " + (path) + " "  + ":  Unrecognized path name" );
// *
}              // Close if()
else if (nmats <= 0)  {
    // *
// *        Check for a positive number of tests requested.
// *
System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        GE:  general matrices
// *
ntypes = 11;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkge.dchkge(dotype,0,nm,mval,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvge.ddrvge(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),s,0,work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        GB:  general banded matrices
// *
la = (2*kdmax+1)*nmax;
lafac = (3*kdmax+1)*nmax;
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkgb.dchkgb(dotype,0,nm,mval,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),la,a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),lafac,b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvgb.ddrvgb(dotype,0,nn,nval,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),la,a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),lafac,a,(1)- 1+(6- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),s,0,work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        GT:  general tridiagonal matrices
// *
ntypes = 12;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkgt.dchkgt(dotype,0,nn,nval,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvgt.ddrvgt(dotype,0,nn,nval,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PO",0,2))  {
    // *
// *        PO:  positive definite matrices
// *
ntypes = 9;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkpo.dchkpo(dotype,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvpo.ddrvpo(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),s,0,work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PP",0,2))  {
    // *
// *        PP:  positive definite packed matrices
// *
ntypes = 9;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkpp.dchkpp(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvpp.ddrvpp(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),s,0,work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        PB:  positive definite banded matrices
// *
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkpb.dchkpb(dotype,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvpb.ddrvpb(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),s,0,work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        PT:  positive definite tridiagonal matrices
// *
ntypes = 12;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkpt.dchkpt(dotype,0,nn,nval,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvpt.ddrvpt(dotype,0,nn,nval,0,nrhs,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SY",0,2))  {
    // *
// *        SY:  symmetric indefinite matrices
// *
ntypes = 10;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchksy.dchksy(dotype,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvsy.ddrvsy(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        SP:  symmetric indefinite packed matrices
// *
ntypes = 10;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchksp.dchksp(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
if (tstdrv)  {
    Ddrvsp.ddrvsp(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TR",0,2))  {
    // *
// *        TR:  triangular matrices
// *
ntypes = 18;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchktr.dchktr(dotype,0,nn,nval,0,nnb2,nbval2,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        TP:  triangular packed matrices
// *
ntypes = 18;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchktp.dchktp(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        TB:  triangular banded matrices
// *
ntypes = 17;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchktb.dchktb(dotype,0,nn,nval,0,nrhs,thresh,tsterr,lda,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"QR",0,2))  {
    // *
// *        QR:  QR factorization
// *
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkqr.dchkqr(dotype,0,nm,mval,0,nn,nval,0,nnb,nbval,0,nxval,0,nrhs,thresh,tsterr,nmax,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),a,(1)- 1+(4- 1)* ((kdmax+1)*nmax),a,(1)- 1+(5- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"LQ",0,2))  {
    // *
// *        LQ:  LQ factorization
// *
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchklq.dchklq(dotype,0,nm,mval,0,nn,nval,0,nnb,nbval,0,nxval,0,nrhs,thresh,tsterr,nmax,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),a,(1)- 1+(4- 1)* ((kdmax+1)*nmax),a,(1)- 1+(5- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"QL",0,2))  {
    // *
// *        QL:  QL factorization
// *
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkql.dchkql(dotype,0,nm,mval,0,nn,nval,0,nnb,nbval,0,nxval,0,nrhs,thresh,tsterr,nmax,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),a,(1)- 1+(4- 1)* ((kdmax+1)*nmax),a,(1)- 1+(5- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"RQ",0,2))  {
    // *
// *        RQ:  RQ factorization
// *
ntypes = 8;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkrq.dchkrq(dotype,0,nm,mval,0,nn,nval,0,nnb,nbval,0,nxval,0,nrhs,thresh,tsterr,nmax,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),a,(1)- 1+(4- 1)* ((kdmax+1)*nmax),a,(1)- 1+(5- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),b,(1)- 1+(4- 1)* (nmax*maxrhs),work,0,rwork,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"QP",0,2))  {
    // *
// *        QP:  QR factorization with pivoting
// *
ntypes = 6;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchkqp.dchkqp(dotype,0,nm,mval,0,nn,nval,0,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TZ",0,2))  {
    // *
// *        TZ:  Trapezoidal matrix
// *
ntypes = 3;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstchk)  {
    Dchktz.dchktz(dotype,0,nm,mval,0,nn,nval,0,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"LS",0,2))  {
    // *
// *        LS:  Least squares drivers
// *
ntypes = 6;
Alareq.alareq(path,nmats,dotype,0,ntypes,nin,nout);
// *
if (tstdrv)  {
    Ddrvls.ddrvls(dotype,0,nm,mval,0,nn,nval,0,nns,nsval,0,nnb,nbval,0,nxval,0,thresh,tsterr,a,(1)- 1+(1- 1)* ((kdmax+1)*nmax),a,(1)- 1+(2- 1)* ((kdmax+1)*nmax),a,(1)- 1+(3- 1)* ((kdmax+1)*nmax),a,(1)- 1+(4- 1)* ((kdmax+1)*nmax),b,(1)- 1+(1- 1)* (nmax*maxrhs),b,(1)- 1+(2- 1)* (nmax*maxrhs),b,(1)- 1+(3- 1)* (nmax*maxrhs),work,0,iwork,0,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " driver routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"EQ",0,2))  {
    // *
// *        EQ:  Equilibration routines for general and positive definite
// *             matrices (THREQ should be between 2 and 10)
// *
if (tstchk)  {
    Dchkeq.dchkeq(threq,nout);
}              // Close if()
else  {
  System.out.println("\n"  + " " + (path) + " "  + " routines were not tested" );
}              //  Close else.
// *
}              // Close else if()
else  {
  // *
System.out.println("\n"  + " " + (path) + " "  + ":  Unrecognized path name" );
}              //  Close else.
// *
// *     Go back to get another input line.
// *
Dummy.go_to("Dchkaa",80);
// *
// *     Branch to this line when the last record is read.
// *
label140:
   Dummy.label("Dchkaa",140);
// WARNING: Unimplemented statement in Fortran source.
s2 = Dsecnd.dsecnd();
System.out.println("\n"  + " End of tests" );
System.out.println(" Total time used = "  + (s2-s1) + " "  + " seconds"  + "\n" );
// *
// *
// *     End of DCHKAA
// *
Dummy.label("Dchkaa",999999);
return;
   }
} // End class.
