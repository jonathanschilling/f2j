/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkeq {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKEQ tests DGEEQU, DGBEQU, DPOEQU, DPPEQU and DPBEQU
// *
// *  Arguments
// *  =========
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          Threshold for testing routines. Should be between 2 and 10.
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e+0;
static double ten= 1.0e1;
static int nsz= 5;
static int nszb= 3*nsz-2;
static int nszp= (nsz*(nsz+1))/2;
static int npow= 2*nsz+1;
// *     ..
// *     .. Local Scalars ..
static boolean ok= false;
static String path= new String("   ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static int kl= 0;
static int ku= 0;
static int m= 0;
static int n= 0;
static doubleW ccond= new doubleW(0.0);
static double eps= 0.0;
static doubleW norm= new doubleW(0.0);
static double ratio= 0.0;
static double rcmax= 0.0;
static double rcmin= 0.0;
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nsz) * (nsz)];
static double [] ab= new double[(nszb) * (nsz)];
static double [] ap= new double[(nszp)];
static double [] c= new double[(nsz)];
static double [] pow= new double[(npow)];
static double [] r= new double[(nsz)];
static double [] reslts= new double[(5)];
static double [] rpow= new double[(npow)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dchkeq (double thresh,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "EQ".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
// *
eps = Dlamch.dlamch("P");
{
forloop10:
for (i = 1; i <= 5; i++) {
reslts[(i)- 1] = zero;
Dummy.label("Dchkeq",10);
}              //  Close for() loop. 
}
{
forloop20:
for (i = 1; i <= npow; i++) {
pow[(i)- 1] = Math.pow(ten, (i-1));
rpow[(i)- 1] = one/pow[(i)- 1];
Dummy.label("Dchkeq",20);
}              //  Close for() loop. 
}
// *
// *     Test DGEEQU
// *
{
forloop80:
for (n = 0; n <= nsz; n++) {
{
forloop70:
for (m = 0; m <= nsz; m++) {
// *
{
forloop40:
for (j = 1; j <= nsz; j++) {
{
forloop30:
for (i = 1; i <= nsz; i++) {
if (i <= m && j <= n)  {
    a[(i)- 1+(j- 1)*nsz] = pow[(i+j+1)- 1]*Math.pow((-1), (i+j));
}              // Close if()
else  {
  a[(i)- 1+(j- 1)*nsz] = zero;
}              //  Close else.
Dummy.label("Dchkeq",30);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",40);
}              //  Close for() loop. 
}
// *
Dgeequ.dgeequ(m,n,a,0,nsz,r,0,c,0,rcond,ccond,norm,info);
// *
if (info.val != 0)  {
    reslts[(1)- 1] = one;
}              // Close if()
else  {
  if (n != 0 && m != 0)  {
    reslts[(1)- 1] = Math.max(reslts[(1)- 1], Math.abs((rcond.val-rpow[(m)- 1])/rpow[(m)- 1])) ;
reslts[(1)- 1] = Math.max(reslts[(1)- 1], Math.abs((ccond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(1)- 1] = Math.max(reslts[(1)- 1], Math.abs((norm.val-pow[(n+m+1)- 1])/pow[(n+m+1)- 1])) ;
{
forloop50:
for (i = 1; i <= m; i++) {
reslts[(1)- 1] = Math.max(reslts[(1)- 1], Math.abs((r[(i)- 1]-rpow[(i+n+1)- 1])/rpow[(i+n+1)- 1])) ;
Dummy.label("Dchkeq",50);
}              //  Close for() loop. 
}
{
forloop60:
for (j = 1; j <= n; j++) {
reslts[(1)- 1] = Math.max(reslts[(1)- 1], Math.abs((c[(j)- 1]-pow[(n-j+1)- 1])/pow[(n-j+1)- 1])) ;
Dummy.label("Dchkeq",60);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
// *
Dummy.label("Dchkeq",70);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",80);
}              //  Close for() loop. 
}
// *
// *     Test with zero rows and columns
// *
{
forloop90:
for (j = 1; j <= nsz; j++) {
a[(int)((Math.max(nsz-1, 1) )- 1+(j- 1)*nsz)] = zero;
Dummy.label("Dchkeq",90);
}              //  Close for() loop. 
}
Dgeequ.dgeequ(nsz,nsz,a,0,nsz,r,0,c,0,rcond,ccond,norm,info);
if (info.val != Math.max(nsz-1, 1) )  
    reslts[(1)- 1] = one;
// *
{
forloop100:
for (j = 1; j <= nsz; j++) {
a[(int)((Math.max(nsz-1, 1) )- 1+(j- 1)*nsz)] = one;
Dummy.label("Dchkeq",100);
}              //  Close for() loop. 
}
{
forloop110:
for (i = 1; i <= nsz; i++) {
a[(i)- 1+(Math.max(nsz-1, 1) - 1)*nsz] = zero;
Dummy.label("Dchkeq",110);
}              //  Close for() loop. 
}
Dgeequ.dgeequ(nsz,nsz,a,0,nsz,r,0,c,0,rcond,ccond,norm,info);
if (info.val != nsz+Math.max(nsz-1, 1) )  
    reslts[(1)- 1] = one;
reslts[(1)- 1] = reslts[(1)- 1]/eps;
// *
// *     Test DGBEQU
// *
{
forloop250:
for (n = 0; n <= nsz; n++) {
{
forloop240:
for (m = 0; m <= nsz; m++) {
{
forloop230:
for (kl = 0; kl <= Math.max(m-1, 0) ; kl++) {
{
forloop220:
for (ku = 0; ku <= Math.max(n-1, 0) ; ku++) {
// *
{
forloop130:
for (j = 1; j <= nsz; j++) {
{
forloop120:
for (i = 1; i <= nszb; i++) {
ab[(i)- 1+(j- 1)*nszb] = zero;
Dummy.label("Dchkeq",120);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",130);
}              //  Close for() loop. 
}
{
forloop150:
for (j = 1; j <= n; j++) {
{
forloop140:
for (i = 1; i <= m; i++) {
if (i <= Math.min(m, j+kl)  && i >= Math.max(1, j-ku)  && j <= n)  {
    ab[(ku+1+i-j)- 1+(j- 1)*nszb] = pow[(i+j+1)- 1]*Math.pow((-1), (i+j));
}              // Close if()
Dummy.label("Dchkeq",140);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",150);
}              //  Close for() loop. 
}
// *
Dgbequ.dgbequ(m,n,kl,ku,ab,0,nszb,r,0,c,0,rcond,ccond,norm,info);
// *
if (info.val != 0)  {
    if (!((n+kl < m && info.val == n+kl+1) || (m+ku < n && info.val == 2*m+ku+1)))  {
    reslts[(2)- 1] = one;
}              // Close if()
}              // Close if()
else  {
  if (n != 0 && m != 0)  {
    // *
rcmin = r[(1)- 1];
rcmax = r[(1)- 1];
{
forloop160:
for (i = 1; i <= m; i++) {
rcmin = Math.min(rcmin, r[(i)- 1]) ;
rcmax = Math.max(rcmax, r[(i)- 1]) ;
Dummy.label("Dchkeq",160);
}              //  Close for() loop. 
}
ratio = rcmin/rcmax;
reslts[(2)- 1] = Math.max(reslts[(2)- 1], Math.abs((rcond.val-ratio)/ratio)) ;
// *
rcmin = c[(1)- 1];
rcmax = c[(1)- 1];
{
forloop170:
for (j = 1; j <= n; j++) {
rcmin = Math.min(rcmin, c[(j)- 1]) ;
rcmax = Math.max(rcmax, c[(j)- 1]) ;
Dummy.label("Dchkeq",170);
}              //  Close for() loop. 
}
ratio = rcmin/rcmax;
reslts[(2)- 1] = Math.max(reslts[(2)- 1], Math.abs((ccond.val-ratio)/ratio)) ;
// *
reslts[(2)- 1] = Math.max(reslts[(2)- 1], Math.abs((norm.val-pow[(n+m+1)- 1])/pow[(n+m+1)- 1])) ;
{
forloop190:
for (i = 1; i <= m; i++) {
rcmax = zero;
{
forloop180:
for (j = 1; j <= n; j++) {
if (i <= j+kl && i >= j-ku)  {
    ratio = Math.abs(r[(i)- 1]*pow[(i+j+1)- 1]*c[(j)- 1]);
rcmax = Math.max(rcmax, ratio) ;
}              // Close if()
Dummy.label("Dchkeq",180);
}              //  Close for() loop. 
}
reslts[(2)- 1] = Math.max(reslts[(2)- 1], Math.abs(one-rcmax)) ;
Dummy.label("Dchkeq",190);
}              //  Close for() loop. 
}
// *
{
forloop210:
for (j = 1; j <= n; j++) {
rcmax = zero;
{
forloop200:
for (i = 1; i <= m; i++) {
if (i <= j+kl && i >= j-ku)  {
    ratio = Math.abs(r[(i)- 1]*pow[(i+j+1)- 1]*c[(j)- 1]);
rcmax = Math.max(rcmax, ratio) ;
}              // Close if()
Dummy.label("Dchkeq",200);
}              //  Close for() loop. 
}
reslts[(2)- 1] = Math.max(reslts[(2)- 1], Math.abs(one-rcmax)) ;
Dummy.label("Dchkeq",210);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
// *
Dummy.label("Dchkeq",220);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",230);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",240);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",250);
}              //  Close for() loop. 
}
reslts[(2)- 1] = reslts[(2)- 1]/eps;
// *
// *     Test DPOEQU
// *
{
forloop290:
for (n = 0; n <= nsz; n++) {
// *
{
forloop270:
for (i = 1; i <= nsz; i++) {
{
forloop260:
for (j = 1; j <= nsz; j++) {
if (i <= n && j == i)  {
    a[(i)- 1+(j- 1)*nsz] = pow[(i+j+1)- 1]*Math.pow((-1), (i+j));
}              // Close if()
else  {
  a[(i)- 1+(j- 1)*nsz] = zero;
}              //  Close else.
Dummy.label("Dchkeq",260);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",270);
}              //  Close for() loop. 
}
// *
Dpoequ.dpoequ(n,a,0,nsz,r,0,rcond,norm,info);
// *
if (info.val != 0)  {
    reslts[(3)- 1] = one;
}              // Close if()
else  {
  if (n != 0)  {
    reslts[(3)- 1] = Math.max(reslts[(3)- 1], Math.abs((rcond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(3)- 1] = Math.max(reslts[(3)- 1], Math.abs((norm.val-pow[(2*n+1)- 1])/pow[(2*n+1)- 1])) ;
{
forloop280:
for (i = 1; i <= n; i++) {
reslts[(3)- 1] = Math.max(reslts[(3)- 1], Math.abs((r[(i)- 1]-rpow[(i+1)- 1])/rpow[(i+1)- 1])) ;
Dummy.label("Dchkeq",280);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
Dummy.label("Dchkeq",290);
}              //  Close for() loop. 
}
a[(int)((Math.max(nsz-1, 1) )- 1+(Math.max(nsz-1, 1) - 1)*nsz)] = -one;
Dpoequ.dpoequ(nsz,a,0,nsz,r,0,rcond,norm,info);
if (info.val != Math.max(nsz-1, 1) )  
    reslts[(3)- 1] = one;
reslts[(3)- 1] = reslts[(3)- 1]/eps;
// *
// *     Test DPPEQU
// *
{
forloop360:
for (n = 0; n <= nsz; n++) {
// *
// *        Upper triangular packed storage
// *
{
forloop300:
for (i = 1; i <= (n*(n+1))/2; i++) {
ap[(i)- 1] = zero;
Dummy.label("Dchkeq",300);
}              //  Close for() loop. 
}
{
forloop310:
for (i = 1; i <= n; i++) {
ap[((i*(i+1))/2)- 1] = pow[(2*i+1)- 1];
Dummy.label("Dchkeq",310);
}              //  Close for() loop. 
}
// *
Dppequ.dppequ("U",n,ap,0,r,0,rcond,norm,info);
// *
if (info.val != 0)  {
    reslts[(4)- 1] = one;
}              // Close if()
else  {
  if (n != 0)  {
    reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((rcond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((norm.val-pow[(2*n+1)- 1])/pow[(2*n+1)- 1])) ;
{
forloop320:
for (i = 1; i <= n; i++) {
reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((r[(i)- 1]-rpow[(i+1)- 1])/rpow[(i+1)- 1])) ;
Dummy.label("Dchkeq",320);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
// *
// *        Lower triangular packed storage
// *
{
forloop330:
for (i = 1; i <= (n*(n+1))/2; i++) {
ap[(i)- 1] = zero;
Dummy.label("Dchkeq",330);
}              //  Close for() loop. 
}
j = 1;
{
forloop340:
for (i = 1; i <= n; i++) {
ap[(j)- 1] = pow[(2*i+1)- 1];
j = j+(n-i+1);
Dummy.label("Dchkeq",340);
}              //  Close for() loop. 
}
// *
Dppequ.dppequ("L",n,ap,0,r,0,rcond,norm,info);
// *
if (info.val != 0)  {
    reslts[(4)- 1] = one;
}              // Close if()
else  {
  if (n != 0)  {
    reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((rcond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((norm.val-pow[(2*n+1)- 1])/pow[(2*n+1)- 1])) ;
{
forloop350:
for (i = 1; i <= n; i++) {
reslts[(4)- 1] = Math.max(reslts[(4)- 1], Math.abs((r[(i)- 1]-rpow[(i+1)- 1])/rpow[(i+1)- 1])) ;
Dummy.label("Dchkeq",350);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
// *
Dummy.label("Dchkeq",360);
}              //  Close for() loop. 
}
i = (nsz*(nsz+1))/2-2;
ap[(i)- 1] = -one;
Dppequ.dppequ("L",nsz,ap,0,r,0,rcond,norm,info);
if (info.val != Math.max(nsz-1, 1) )  
    reslts[(4)- 1] = one;
reslts[(4)- 1] = reslts[(4)- 1]/eps;
// *
// *     Test DPBEQU
// *
{
forloop460:
for (n = 0; n <= nsz; n++) {
{
forloop450:
for (kl = 0; kl <= Math.max(n-1, 0) ; kl++) {
// *
// *           Test upper triangular storage
// *
{
forloop380:
for (j = 1; j <= nsz; j++) {
{
forloop370:
for (i = 1; i <= nszb; i++) {
ab[(i)- 1+(j- 1)*nszb] = zero;
Dummy.label("Dchkeq",370);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",380);
}              //  Close for() loop. 
}
{
forloop390:
for (j = 1; j <= n; j++) {
ab[(kl+1)- 1+(j- 1)*nszb] = pow[(2*j+1)- 1];
Dummy.label("Dchkeq",390);
}              //  Close for() loop. 
}
// *
Dpbequ.dpbequ("U",n,kl,ab,0,nszb,r,0,rcond,norm,info);
// *
if (info.val != 0)  {
    reslts[(5)- 1] = one;
}              // Close if()
else  {
  if (n != 0)  {
    reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((rcond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((norm.val-pow[(2*n+1)- 1])/pow[(2*n+1)- 1])) ;
{
forloop400:
for (i = 1; i <= n; i++) {
reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((r[(i)- 1]-rpow[(i+1)- 1])/rpow[(i+1)- 1])) ;
Dummy.label("Dchkeq",400);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
if (n != 0)  {
    ab[(kl+1)- 1+(Math.max(n-1, 1) - 1)*nszb] = -one;
Dpbequ.dpbequ("U",n,kl,ab,0,nszb,r,0,rcond,norm,info);
if (info.val != Math.max(n-1, 1) )  
    reslts[(5)- 1] = one;
}              // Close if()
// *
// *           Test lower triangular storage
// *
{
forloop420:
for (j = 1; j <= nsz; j++) {
{
forloop410:
for (i = 1; i <= nszb; i++) {
ab[(i)- 1+(j- 1)*nszb] = zero;
Dummy.label("Dchkeq",410);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",420);
}              //  Close for() loop. 
}
{
forloop430:
for (j = 1; j <= n; j++) {
ab[(1)- 1+(j- 1)*nszb] = pow[(2*j+1)- 1];
Dummy.label("Dchkeq",430);
}              //  Close for() loop. 
}
// *
Dpbequ.dpbequ("L",n,kl,ab,0,nszb,r,0,rcond,norm,info);
// *
if (info.val != 0)  {
    reslts[(5)- 1] = one;
}              // Close if()
else  {
  if (n != 0)  {
    reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((rcond.val-rpow[(n)- 1])/rpow[(n)- 1])) ;
reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((norm.val-pow[(2*n+1)- 1])/pow[(2*n+1)- 1])) ;
{
forloop440:
for (i = 1; i <= n; i++) {
reslts[(5)- 1] = Math.max(reslts[(5)- 1], Math.abs((r[(i)- 1]-rpow[(i+1)- 1])/rpow[(i+1)- 1])) ;
Dummy.label("Dchkeq",440);
}              //  Close for() loop. 
}
}              // Close if()
}              //  Close else.
if (n != 0)  {
    ab[(1)- 1+(Math.max(n-1, 1) - 1)*nszb] = -one;
Dpbequ.dpbequ("L",n,kl,ab,0,nszb,r,0,rcond,norm,info);
if (info.val != Math.max(n-1, 1) )  
    reslts[(5)- 1] = one;
}              // Close if()
Dummy.label("Dchkeq",450);
}              //  Close for() loop. 
}
Dummy.label("Dchkeq",460);
}              //  Close for() loop. 
}
reslts[(5)- 1] = reslts[(5)- 1]/eps;
ok = (reslts[(1)- 1] <= thresh) && (reslts[(2)- 1] <= thresh) && (reslts[(3)- 1] <= thresh) && (reslts[(4)- 1] <= thresh) && (reslts[(5)- 1] <= thresh);
System.out.println();
if (ok)  {
    System.out.println(" " + "All tests for "  + (path) + " "  + " routines passed the threshold" );
}              // Close if()
else  {
  if (reslts[(1)- 1] > thresh)  
    System.out.println(" DGEEQU failed test with value "  + (reslts[(1)- 1]) + " "  + " exceeding"  + " threshold "  + (thresh) + " " );
if (reslts[(2)- 1] > thresh)  
    System.out.println(" DGBEQU failed test with value "  + (reslts[(2)- 1]) + " "  + " exceeding"  + " threshold "  + (thresh) + " " );
if (reslts[(3)- 1] > thresh)  
    System.out.println(" DPOEQU failed test with value "  + (reslts[(3)- 1]) + " "  + " exceeding"  + " threshold "  + (thresh) + " " );
if (reslts[(4)- 1] > thresh)  
    System.out.println(" DPPEQU failed test with value "  + (reslts[(4)- 1]) + " "  + " exceeding"  + " threshold "  + (thresh) + " " );
if (reslts[(5)- 1] > thresh)  
    System.out.println(" DPBEQU failed test with value "  + (reslts[(5)- 1]) + " "  + " exceeding"  + " threshold "  + (thresh) + " " );
}              //  Close else.
Dummy.go_to("Dchkeq",999999);
// *
// *     End of DCHKEQ
// *
Dummy.label("Dchkeq",999999);
return;
   }
} // End class.
