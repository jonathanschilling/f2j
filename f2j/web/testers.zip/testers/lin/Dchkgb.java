/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkgb {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKGB tests DGBTRF, -TRS, -RFS, and -CON
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB contained in the vector NBVAL.
// *
// *  NBVAL   (input) INTEGER array, dimension (NBVAL)
// *          The values of the blocksize NB.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (LA)
// *
// *  LA      (input) INTEGER
// *          The length of the array A.  LA >= (KLMAX+KUMAX+1)*NMAX
// *          where KLMAX is the largest entry in the local array KLVAL,
// *                KUMAX is the largest entry in local array KUVAL and
// *                NMAX is the largest entry in input array NVAL.
// *
// *  AFAC    (workspace) DOUBLE PRECISION array, dimension (LAFAC)
// *
// *  LAFAC   (input) INTEGER
// *          The length of the array AFAC. LAFAC >= (2*KLMAX+KUMAX+1)*NMAX
// *          where KLMAX is the largest entry in local array KLVAL,
// *                KUMAX is the largest entry in local array KUVAL and
// *                NMAX is the largest entry in input array NVAL.
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS,NMAX))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (2*NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 8;
static int ntests= 7;
static int nbw= 4;
static int ntran= 3;
// *     ..
// *     .. Local Scalars ..
static boolean trfcon= false;
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String norm= new String(" ");
static String trans= new String(" ");
static StringW type= new StringW(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int i1= 0;
static int i2= 0;
static int ikl= 0;
static int iku= 0;
static int im= 0;
static int imat= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int ioff= 0;
static int itran= 0;
static int izero= 0;
static int j= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static int koff= 0;
static intW ku= new intW(0);
static int lda= 0;
static int ldafac= 0;
static int ldb= 0;
static int m= 0;
static intW mode= new intW(0);
static int n= 0;
static int nb= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nkl= 0;
static int nku= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static double anormi= 0.0;
static double anormo= 0.0;
static doubleW cndnum= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static double rcondo= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static int [] klval= new int[(nbw)];
static int [] kuval= new int[(nbw)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String [] transs = {"N" 
, "T" , "C" };
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchkgb (boolean [] dotype, int _dotype_offset,
int nm,
int [] mval, int _mval_offset,
int nn,
int [] nval, int _nval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int nrhs,
double thresh,
boolean tsterr,
double [] a, int _a_offset,
int la,
double [] afac, int _afac_offset,
int lafac,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "GB".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchkgb",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrge.derrge(path,nout);
lintest_infoc.infot = 0;
Xlaenv.xlaenv(2,2);
// *
// *     Initialize the first value for the lower and upper bandwidths.
// *
klval[(1)- 1] = 0;
kuval[(1)- 1] = 0;
// *
// *     Do for each value of M in MVAL
// *
{
forloop130:
for (im = 1; im <= nm; im++) {
m = mval[(im)- 1+ _mval_offset];
// *
// *        Set values to use for the lower bandwidth.
// *
klval[(2)- 1] = m+(m+1)/4;
// *
// *        KLVAL( 2 ) = MAX( M-1, 0 )
// *
klval[(3)- 1] = (3*m-1)/4;
klval[(4)- 1] = (m+1)/4;
// *
// *        Do for each value of N in NVAL
// *
{
forloop120:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
xtype = "N";
// *
// *           Set values to use for the upper bandwidth.
// *
kuval[(2)- 1] = n+(n+1)/4;
// *
// *           KUVAL( 2 ) = MAX( N-1, 0 )
// *
kuval[(3)- 1] = (3*n-1)/4;
kuval[(4)- 1] = (n+1)/4;
// *
// *           Set limits on the number of loop iterations.
// *
nkl = (int)(Math.min(m+1, 4) );
if (n == 0)  
    nkl = 2;
nku = (int)(Math.min(n+1, 4) );
if (m == 0)  
    nku = 2;
nimat = ntypes;
if (m <= 0 || n <= 0)  
    nimat = 1;
// *
{
forloop110:
for (ikl = 1; ikl <= nkl; ikl++) {
// *
// *              Do for KL = 0, (5*M+1)/4, (3M-1)/4, and (M+1)/4. This
// *              order makes it easier to skip redundant values for small
// *              values of M.
// *
kl.val = klval[(ikl)- 1];
{
forloop100:
for (iku = 1; iku <= nku; iku++) {
// *
// *                 Do for KU = 0, (5*N+1)/4, (3N-1)/4, and (N+1)/4. This
// *                 order makes it easier to skip redundant values for
// *                 small values of N.
// *
ku.val = kuval[(iku)- 1];
// *
// *                 Check that A and AFAC are big enough to generate this
// *                 matrix.
// *
lda = kl.val+ku.val+1;
ldafac = 2*kl.val+ku.val+1;
if ((lda*n) > la || (ldafac*n) > lafac)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
if (n*(kl.val+ku.val+1) > la)  {
    System.out.println(" *** In DCHKGB, LA="  + (la) + " "  + " is too small for M="  + (m) + " "  + ", N="  + (n) + " "  + ", KL="  + (kl.val) + " "  + ", KU="  + (ku.val) + " "  + "\n"  + " ==> Increase LA to at least "  + (n*(kl.val+ku.val+1)) + " " );
nerrs.val = nerrs.val+1;
}              // Close if()
if (n*(2*kl.val+ku.val+1) > lafac)  {
    System.out.println(" *** In DCHKGB, LAFAC="  + (lafac) + " "  + " is too small for M="  + (m) + " "  + ", N="  + (n) + " "  + ", KL="  + (kl.val) + " "  + ", KU="  + (ku.val) + " "  + "\n"  + " ==> Increase LAFAC to at least "  + (n*(2*kl.val+ku.val+1)) + " " );
nerrs.val = nerrs.val+1;
}              // Close if()
continue forloop100;
}              // Close if()
// *
{
forloop90:
for (imat = 1; imat <= nimat; imat++) {
// *
// *                    Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop90;
// *
// *                    Skip types 2, 3, or 4 if the matrix size is too
// *                    small.
// *
zerot = imat >= 2 && imat <= 4;
if (zerot && n < imat-1)  
    continue forloop90;
// *
if (!zerot || !dotype[(1)- 1+ _dotype_offset])  {
    // *
// *                       Set up parameters with DLATB4 and generate a
// *                       test matrix with DLATMS.
// *
Dlatb4.dlatb4(path,imat,m,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
koff = (int)(Math.max(1, ku.val+2-n) );
{
forloop20:
for (i = 1; i <= koff-1; i++) {
a[(i)- 1+ _a_offset] = zero;
Dummy.label("Dchkgb",20);
}              //  Close for() loop. 
}
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(m,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,"Z",a,(koff)- 1+ _a_offset,lda,work,_work_offset,info);
// *
// *                       Check the error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0," ",m,n,kl.val,ku.val,-1,imat,nfail,nerrs,nout);
continue forloop90;
}              // Close if()
}              // Close if()
else if (izero > 0)  {
    // *
// *                       Use the same matrix for types 3 and 4 as for
// *                       type 2 by copying back the zeroed out column.
// *
Dcopy.dcopy(i2-i1+1,b,_b_offset,1,a,(ioff+i1)- 1+ _a_offset,1);
}              // Close else if()
// *
// *                    For types 2, 3, and 4, zero one or more columns of
// *                    the matrix to test that INFO is returned correctly.
// *
izero = 0;
if (zerot)  {
    if (imat == 2)  {
    izero = 1;
}              // Close if()
else if (imat == 3)  {
    izero = (int)(Math.min(m, n) );
}              // Close else if()
else  {
  izero = (int)(Math.min(m, n) /2+1);
}              //  Close else.
ioff = (izero-1)*lda;
if (imat < 4)  {
    // *
// *                          Store the column to be zeroed out in B.
// *
i1 = (int)(Math.max(1, ku.val+2-izero) );
i2 = (int)(Math.min(kl.val+ku.val+1, ku.val+1+(m-izero)) );
Dcopy.dcopy(i2-i1+1,a,(ioff+i1)- 1+ _a_offset,1,b,_b_offset,1);
// *
{
forloop30:
for (i = i1; i <= i2; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Dchkgb",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop50:
for (j = izero; j <= n; j++) {
{
forloop40:
for (i = (int)(Math.max(1, ku.val+2-j) ); i <= Math.min(kl.val+ku.val+1, ku.val+1+(m-j)) ; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Dchkgb",40);
}              //  Close for() loop. 
}
ioff = ioff+lda;
Dummy.label("Dchkgb",50);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
// *
// *                    These lines, if used in place of the calls in the
// *                    loop over INB, cause the code to bomb on a Sun
// *                    SPARCstation.
// *
// *                     ANORMO = DLANGB( 'O', N, KL, KU, A, LDA, RWORK )
// *                     ANORMI = DLANGB( 'I', N, KL, KU, A, LDA, RWORK )
// *
// *                    Do for each blocksize in NBVAL
// *
{
forloop80:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
// *
// *                       Compute the LU factorization of the band matrix.
// *
if (m > 0 && n > 0)  
    Dlacpy.dlacpy("Full",kl.val+ku.val+1,n,a,_a_offset,lda,afac,(kl.val+1)- 1+ _afac_offset,ldafac);
lintest_srnamc.srnamt = "DGBTRF";
Dgbtrf.dgbtrf(m,n,kl.val,ku.val,afac,_afac_offset,ldafac,iwork,_iwork_offset,info);
// *
// *                       Check error code from DGBTRF.
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DGBTRF",info.val,izero," ",m,n,kl.val,ku.val,nb,imat,nfail,nerrs,nout);
trfcon = false;
// *
// *+    TEST 1
// *                       Reconstruct matrix from factors and compute
// *                       residual.
// *
dgbt01_adapter(m,n,kl.val,ku.val,a,_a_offset,lda,afac,_afac_offset,ldafac,iwork,_iwork_offset,work,_work_offset,result,(1)- 1);
nt = 1;
// *
// *                       Print information about the tests so far that
// *                       did not pass the threshold.
// *
if (result[(1)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" M="  + (m) + " "  + ",N="  + (n) + " "  + ",KL="  + (kl.val) + " "  + ",KU="  + (ku.val) + " "  + ", NB="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test "  + (1) + " "  + ", ratio="  + (result[(1)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+1;
// *
// *                       Skip the remaining tests if this is not the
// *                       first block size or if M .ne. N.
// *
if (inb > 1 || m != n)  
    continue forloop80;
// *
anormo = Dlangb.dlangb("O",n,kl.val,ku.val,a,_a_offset,lda,rwork,_rwork_offset);
anormi = Dlangb.dlangb("I",n,kl.val,ku.val,a,_a_offset,lda,rwork,_rwork_offset);
// *
if (info.val == 0)  {
    // *
// *                          Form the inverse of A so we can get a good
// *                          estimate of CNDNUM = norm(A) * norm(inv(A)).
// *
ldb = (int)(Math.max(1, n) );
Dlaset.dlaset("Full",n,n,zero,one,work,_work_offset,ldb);
lintest_srnamc.srnamt = "DGBTRS";
Dgbtrs.dgbtrs("No transpose",n,kl.val,ku.val,n,afac,_afac_offset,ldafac,iwork,_iwork_offset,work,_work_offset,ldb,info);
// *
// *                          Compute the 1-norm condition number of A.
// *
ainvnm = Dlange.dlange("O",n,n,work,_work_offset,ldb,rwork,_rwork_offset);
if (anormo <= zero || ainvnm <= zero)  {
    rcondo = one;
}              // Close if()
else  {
  rcondo = (one/anormo)/ainvnm;
}              //  Close else.
// *
// *                          Compute the infinity-norm condition number of
// *                          A.
// *
ainvnm = Dlange.dlange("I",n,n,work,_work_offset,ldb,rwork,_rwork_offset);
if (anormi <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anormi)/ainvnm;
}              //  Close else.
}              // Close if()
else  {
  // *
// *                          Do only the condition estimate if INFO.NE.0.
// *
trfcon = true;
rcondo = zero;
rcondi = zero;
}              //  Close else.
// *
{
forloop70:
for (itran = 1; itran <= ntran; itran++) {
trans = transs[(itran)- 1];
if (itran == 1)  {
    anorm.val = anormo;
rcondc = rcondo;
norm = "O";
}              // Close if()
else  {
  anorm.val = anormi;
rcondc = rcondi;
norm = "I";
}              //  Close else.
if (trfcon)  {
    k1 = 7;
}              // Close if()
else  {
  k1 = 2;
// *
// *+    TEST 2:
// *                             Solve and compute residual for A * X = B.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype," ",trans,n,n,kl.val,ku.val,nrhs,a,_a_offset,lda,xact,_xact_offset,ldb,b,_b_offset,ldb,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,ldb,x,_x_offset,ldb);
// *
lintest_srnamc.srnamt = "DGBTRS";
Dgbtrs.dgbtrs(trans,n,kl.val,ku.val,nrhs,afac,_afac_offset,ldafac,iwork,_iwork_offset,x,_x_offset,ldb,info);
// *
// *                             Check error code from DGBTRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGBTRS",info.val,0,trans,n,n,kl.val,ku.val,-1,imat,nfail,nerrs,nout);
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,ldb,work,_work_offset,ldb);
dgbt02_adapter(trans,m,n,kl.val,ku.val,nrhs,a,_a_offset,lda,x,_x_offset,ldb,work,_work_offset,ldb,result,(2)- 1);
// *
// *+    TEST 3:
// *                             Check solution from generated exact
// *                             solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,ldb,xact,_xact_offset,ldb,rcondc,result,(3)- 1);
// *
// *+    TESTS 4, 5, 6:
// *                             Use iterative refinement to improve the
// *                             solution.
// *
lintest_srnamc.srnamt = "DGBRFS";
Dgbrfs.dgbrfs(trans,n,kl.val,ku.val,nrhs,a,_a_offset,lda,afac,_afac_offset,ldafac,iwork,_iwork_offset,b,_b_offset,ldb,x,_x_offset,ldb,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                             Check error code from DGBRFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGBRFS",info.val,0,trans,n,n,kl.val,ku.val,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,ldb,xact,_xact_offset,ldb,rcondc,result,(4)- 1);
Dgbt05.dgbt05(trans,n,kl.val,ku.val,nrhs,a,_a_offset,lda,b,_b_offset,ldb,x,_x_offset,ldb,xact,_xact_offset,ldb,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(5)- 1);
nt = 6;
}              //  Close else.
// *
// *+    TEST 7:
// *                          Get an estimate of RCOND = 1/CNDNUM.
// *
if (itran <= 2)  {
    lintest_srnamc.srnamt = "DGBCON";
Dgbcon.dgbcon(norm,n,kl.val,ku.val,afac,_afac_offset,ldafac,iwork,_iwork_offset,anorm.val,rcond,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                             Check error code from DGBCON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGBCON",info.val,0,norm,n,n,kl.val,ku.val,-1,imat,nfail,nerrs,nout);
// *
result[(7)- 1] = Dget06.dget06(rcond.val,rcondc);
nt = 7;
}              // Close if()
// *
// *                          Print information about the tests that did
// *                          not pass the threshold.
// *
{
forloop60:
for (k = k1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
if (k < 7)  {
    System.out.println(" TRANS= \'"  + (trans) + " "  + "\', N ="  + (n) + " "  + ", KL ="  + (kl.val) + " "  + ", KU ="  + (ku.val) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio="  + (result[(k)- 1]) + " " );
}              // Close if()
else  {
  System.out.println(" NORM = \'"  + (norm) + " "  + "\', N ="  + (n) + " "  + ", KL ="  + (kl.val) + " "  + ", KU ="  + (ku.val) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio="  + (result[(k)- 1]) + " " );
}              //  Close else.
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkgb",60);
}              //  Close for() loop. 
}
nrun = nrun+nt-k1+1;
Dummy.label("Dchkgb",70);
}              //  Close for() loop. 
}
Dummy.label("Dchkgb",80);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchkgb",90);
}              //  Close for() loop. 
}
Dummy.label("Dchkgb",100);
}              //  Close for() loop. 
}
Dummy.label("Dchkgb",110);
}              //  Close for() loop. 
}
Dummy.label("Dchkgb",120);
}              //  Close for() loop. 
}
Dummy.label("Dchkgb",130);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
// *
Dummy.go_to("Dchkgb",999999);
// *
// *     End of DCHKGB
// *
Dummy.label("Dchkgb",999999);
return;
   }
// adapter for dgbt01
private static void dgbt01_adapter(int arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,int [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,double [] arg10 , int arg10_offset )
{
doubleW _f2j_tmp10 = new doubleW(arg10[arg10_offset]);

Dgbt01.dgbt01(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9, arg9_offset,_f2j_tmp10);

arg10[arg10_offset] = _f2j_tmp10.val;
}

// adapter for dgbt02
private static void dgbt02_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,int arg4 ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,int arg11 ,double [] arg12 , int arg12_offset )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dgbt02.dgbt02(arg0,arg1,arg2,arg3,arg4,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,arg11,_f2j_tmp12);

arg12[arg12_offset] = _f2j_tmp12.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
