/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkge {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKGE tests DGETRF, -TRI, -TRS, -RFS, and -CON.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB contained in the vector NBVAL.
// *
// *  NBVAL   (input) INTEGER array, dimension (NBVAL)
// *          The values of the blocksize NB.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for M or N, used in dimensioning
// *          the work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AFAC    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AINV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(2*NMAX,2*NRHS+NWORK))
// *
// *  IWORK   (workspace) INTEGER array, dimension (2*NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 11;
static int ntests= 8;
static int ntran= 3;
// *     ..
// *     .. Local Scalars ..
static boolean trfcon= false;
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String norm= new String(" ");
static String trans= new String(" ");
static StringW type= new StringW(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int im= 0;
static int imat= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int ioff= 0;
static int itran= 0;
static int izero= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lda= 0;
static int lwork= 0;
static int m= 0;
static intW mode= new intW(0);
static int n= 0;
static int nb= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static double anormi= 0.0;
static double anormo= 0.0;
static doubleW cndnum= new doubleW(0.0);
static double dummy= 0.0;
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static doubleW rcondo= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String [] transs = {"N" 
, "T" , "C" };
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchkge (boolean [] dotype, int _dotype_offset,
int nm,
int [] mval, int _mval_offset,
int nn,
int [] nval, int _nval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
double [] ainv, int _ainv_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "GE".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchkge",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrge.derrge(path,nout);
lintest_infoc.infot = 0;
Xlaenv.xlaenv(2,2);
// *
// *     Do for each value of M in MVAL
// *
{
forloop90:
for (im = 1; im <= nm; im++) {
m = mval[(im)- 1+ _mval_offset];
lda = (int)(Math.max(1, m) );
// *
// *        Do for each value of N in NVAL
// *
{
forloop80:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
xtype = "N";
nimat = ntypes;
if (m <= 0 || n <= 0)  
    nimat = 1;
// *
{
forloop70:
for (imat = 1; imat <= nimat; imat++) {
// *
// *              Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop70;
// *
// *              Skip types 5, 6, or 7 if the matrix size is too small.
// *
zerot = imat >= 5 && imat <= 7;
if (zerot && n < imat-4)  
    continue forloop70;
// *
// *              Set up parameters with DLATB4 and generate a test matrix
// *              with DLATMS.
// *
Dlatb4.dlatb4(path,imat,m,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(m,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,"No packing",a,_a_offset,lda,work,_work_offset,info);
// *
// *              Check error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0," ",m,n,-1,-1,-1,imat,nfail,nerrs,nout);
continue forloop70;
}              // Close if()
// *
// *              For types 5-7, zero one or more columns of the matrix to
// *              test that INFO is returned correctly.
// *
if (zerot)  {
    if (imat == 5)  {
    izero = 1;
}              // Close if()
else if (imat == 6)  {
    izero = (int)(Math.min(m, n) );
}              // Close else if()
else  {
  izero = (int)(Math.min(m, n) /2+1);
}              //  Close else.
ioff = (izero-1)*lda;
if (imat < 7)  {
    {
forloop20:
for (i = 1; i <= m; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Dchkge",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  Dlaset.dlaset("Full",m,n-izero+1,zero,zero,a,(ioff+1)- 1+ _a_offset,lda);
}              //  Close else.
}              // Close if()
else  {
  izero = 0;
}              //  Close else.
// *
// *              These lines, if used in place of the calls in the DO 60
// *              loop, cause the code to bomb on a Sun SPARCstation.
// *
// *               ANORMO = DLANGE( 'O', M, N, A, LDA, RWORK )
// *               ANORMI = DLANGE( 'I', M, N, A, LDA, RWORK )
// *
// *              Do for each blocksize in NBVAL
// *
{
forloop60:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
// *
// *                 Compute the LU factorization of the matrix.
// *
Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,afac,_afac_offset,lda);
lintest_srnamc.srnamt = "DGETRF";
Dgetrf.dgetrf(m,n,afac,_afac_offset,lda,iwork,_iwork_offset,info);
// *
// *                 Check error code from DGETRF.
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DGETRF",info.val,izero," ",m,n,-1,-1,nb,imat,nfail,nerrs,nout);
trfcon = false;
// *
// *+    TEST 1
// *                 Reconstruct matrix from factors and compute residual.
// *
Dlacpy.dlacpy("Full",m,n,afac,_afac_offset,lda,ainv,_ainv_offset,lda);
dget01_adapter(m,n,a,_a_offset,lda,ainv,_ainv_offset,lda,iwork,_iwork_offset,rwork,_rwork_offset,result,(1)- 1);
nt = 1;
// *
// *+    TEST 2
// *                 Form the inverse if the factorization was successful
// *                 and compute the residual.
// *
if (m == n && info.val == 0)  {
    Dlacpy.dlacpy("Full",n,n,afac,_afac_offset,lda,ainv,_ainv_offset,lda);
lintest_srnamc.srnamt = "DGETRI";
lwork = (int)(nmax*Math.max(3, nrhs) );
Dgetri.dgetri(n,ainv,_ainv_offset,lda,iwork,_iwork_offset,work,_work_offset,lwork,info);
// *
// *                    Check error code from DGETRI.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGETRI",info.val,0," ",n,n,-1,-1,nb,imat,nfail,nerrs,nout);
// *
// *                    Compute the residual for the matrix times its
// *                    inverse.  Also compute the 1-norm condition number
// *                    of A.
// *
dget03_adapter(n,a,_a_offset,lda,ainv,_ainv_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,rcondo,result,(2)- 1);
anormo = Dlange.dlange("O",m,n,a,_a_offset,lda,rwork,_rwork_offset);
// *
// *                    Compute the infinity-norm condition number of A.
// *
anormi = Dlange.dlange("I",m,n,a,_a_offset,lda,rwork,_rwork_offset);
ainvnm = Dlange.dlange("I",n,n,ainv,_ainv_offset,lda,rwork,_rwork_offset);
if (anormi <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anormi)/ainvnm;
}              //  Close else.
nt = 2;
}              // Close if()
else  {
  // *
// *                    Do only the condition estimate if INFO > 0.
// *
trfcon = true;
anormo = Dlange.dlange("O",m,n,a,_a_offset,lda,rwork,_rwork_offset);
anormi = Dlange.dlange("I",m,n,a,_a_offset,lda,rwork,_rwork_offset);
rcondo.val = zero;
rcondi = zero;
}              //  Close else.
// *
// *                 Print information about the tests so far that did not
// *                 pass the threshold.
// *
{
forloop30:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" M = "  + (m) + " "  + ", N ="  + (n) + " "  + ", NB ="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkge",30);
}              //  Close for() loop. 
}
nrun = nrun+nt;
// *
// *                 Skip the remaining tests if this is not the first
// *                 block size or if M .ne. N.
// *
if (inb > 1 || m != n)  
    continue forloop60;
// *
{
forloop50:
for (itran = 1; itran <= ntran; itran++) {
trans = transs[(itran)- 1];
if (itran == 1)  {
    anorm.val = anormo;
rcondc = rcondo.val;
norm = "O";
}              // Close if()
else  {
  anorm.val = anormi;
rcondc = rcondi;
norm = "I";
}              //  Close else.
if (trfcon)  {
    k1 = 8;
}              // Close if()
else  {
  k1 = 3;
// *
// *+    TEST 3
// *                       Solve and compute residual for A * X = B.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype," ",trans,n,n,kl.val,ku.val,nrhs,a,_a_offset,lda,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
lintest_srnamc.srnamt = "DGETRS";
Dgetrs.dgetrs(trans,n,nrhs,afac,_afac_offset,lda,iwork,_iwork_offset,x,_x_offset,lda,info);
// *
// *                       Check error code from DGETRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGETRS",info.val,0,trans,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dget02_adapter(trans,n,n,nrhs,a,_a_offset,lda,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(3)- 1);
// *
// *+    TEST 4
// *                       Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(4)- 1);
// *
// *+    TESTS 5, 6, and 7
// *                       Use iterative refinement to improve the
// *                       solution.
// *
lintest_srnamc.srnamt = "DGERFS";
Dgerfs.dgerfs(trans,n,nrhs,a,_a_offset,lda,afac,_afac_offset,lda,iwork,_iwork_offset,b,_b_offset,lda,x,_x_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                       Check error code from DGERFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGERFS",info.val,0,trans,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(5)- 1);
Dget07.dget07(trans,n,nrhs,a,_a_offset,lda,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(6)- 1);
nt = 7;
}              //  Close else.
// *
// *+    TEST 8
// *                    Get an estimate of RCOND = 1/CNDNUM.
// *
if (itran <= 2)  {
    lintest_srnamc.srnamt = "DGECON";
Dgecon.dgecon(norm,n,afac,_afac_offset,lda,anorm.val,rcond,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                       Check error code from DGECON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGECON",info.val,0,norm,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
// *                       This line is needed on a Sun SPARCstation.
// *
dummy = rcond.val;
// *
result[(8)- 1] = Dget06.dget06(rcond.val,rcondc);
nt = 8;
}              // Close if()
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop40:
for (k = k1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
if (k < 8)  {
    System.out.println(" TRANS=\'"  + (trans) + " "  + "\', N ="  + (n) + " "  + ", NB ="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
}              // Close if()
else  {
  System.out.println(" NORM =\'"  + (norm) + " "  + "\', N ="  + (n) + " "  + ", NB ="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
}              //  Close else.
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkge",40);
}              //  Close for() loop. 
}
nrun = nrun+nt-k1+1;
Dummy.label("Dchkge",50);
}              //  Close for() loop. 
}
Dummy.label("Dchkge",60);
}              //  Close for() loop. 
}
Dummy.label("Dchkge",70);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchkge",80);
}              //  Close for() loop. 
}
Dummy.label("Dchkge",90);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchkge",999999);
// *
// *     End of DCHKGE
// *
Dummy.label("Dchkge",999999);
return;
   }
// adapter for dget01
private static void dget01_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,int [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset )
{
doubleW _f2j_tmp8 = new doubleW(arg8[arg8_offset]);

Dget01.dget01(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7, arg7_offset,_f2j_tmp8);

arg8[arg8_offset] = _f2j_tmp8.val;
}

// adapter for dget03
private static void dget03_adapter(int arg0 ,double [] arg1 , int arg1_offset ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,doubleW arg8 ,double [] arg9 , int arg9_offset )
{
doubleW _f2j_tmp9 = new doubleW(arg9[arg9_offset]);

Dget03.dget03(arg0,arg1, arg1_offset,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8,_f2j_tmp9);

arg9[arg9_offset] = _f2j_tmp9.val;
}

// adapter for dget02
private static void dget02_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dget02.dget02(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
