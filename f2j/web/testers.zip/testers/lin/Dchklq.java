/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchklq {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKLQ tests DGELQF, DORGLQ and DORMLQ.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB and NX contained in the
// *          vectors NBVAL and NXVAL.  The blocking parameters are used
// *          in pairs (NB,NX).
// *
// *  NBVAL   (input) INTEGER array, dimension (NNB)
// *          The values of the blocksize NB.
// *
// *  NXVAL   (input) INTEGER array, dimension (NNB)
// *          The values of the crossover point NX.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for M or N, used in dimensioning
// *          the work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AQ      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AL      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AC      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  TAU     (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntests= 7;
static int ntypes= 8;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static StringW dist= new StringW(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static int ik= 0;
static int im= 0;
static int imat= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int k= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lda= 0;
static int lwork= 0;
static int m= 0;
static int minmn= 0;
static intW mode= new intW(0);
static int n= 0;
static int nb= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nk= 0;
static int nrun= 0;
static int nt= 0;
static int nx= 0;
static doubleW anorm= new doubleW(0.0);
static doubleW cndnum= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static int [] kval= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchklq (boolean [] dotype, int _dotype_offset,
int nm,
int [] mval, int _mval_offset,
int nn,
int [] nval, int _nval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int [] nxval, int _nxval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] aq, int _aq_offset,
double [] al, int _al_offset,
double [] ac, int _ac_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "LQ".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchklq",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrlq.derrlq(path,nout);
lintest_infoc.infot = 0;
Xlaenv.xlaenv(2,2);
// *
lda = nmax;
lwork = (int)(nmax*Math.max(nmax, nrhs) );
// *
// *     Do for each value of M in MVAL.
// *
{
forloop70:
for (im = 1; im <= nm; im++) {
m = mval[(im)- 1+ _mval_offset];
// *
// *        Do for each value of N in NVAL.
// *
{
forloop60:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
minmn = (int)(Math.min(m, n) );
{
forloop50:
for (imat = 1; imat <= ntypes; imat++) {
// *
// *              Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop50;
// *
// *              Set up parameters with DLATB4 and generate a test matrix
// *              with DLATMS.
// *
Dlatb4.dlatb4(path,imat,m,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(m,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,"No packing",a,_a_offset,lda,work,_work_offset,info);
// *
// *              Check error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0," ",m,n,-1,-1,-1,imat,nfail,nerrs,nout);
continue forloop50;
}              // Close if()
// *
// *              Set some values for K: the first value must be MINMN,
// *              corresponding to the call of DLQT01; other values are
// *              used in the calls of DLQT02, and must not exceed MINMN.
// *
kval[(1)- 1] = minmn;
kval[(2)- 1] = 0;
kval[(3)- 1] = 1;
kval[(4)- 1] = minmn/2;
if (minmn == 0)  {
    nk = 1;
}              // Close if()
else if (minmn == 1)  {
    nk = 2;
}              // Close else if()
else if (minmn <= 3)  {
    nk = 3;
}              // Close else if()
else  {
  nk = 4;
}              //  Close else.
// *
// *              Do for each value of K in KVAL
// *
{
forloop40:
for (ik = 1; ik <= nk; ik++) {
k = kval[(ik)- 1];
// *
// *                 Do for each pair of values (NB,NX) in NBVAL and NXVAL.
// *
{
forloop30:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
nx = nxval[(inb)- 1+ _nxval_offset];
Xlaenv.xlaenv(3,nx);
nt = 2;
if (ik == 1)  {
    // *
// *                       Test DGELQF
// *
Dlqt01.dlqt01(m,n,a,_a_offset,af,_af_offset,aq,_aq_offset,al,_al_offset,lda,tau,_tau_offset,work,_work_offset,lwork,rwork,_rwork_offset,result,(1)- 1);
}              // Close if()
else if (m <= n)  {
    // *
// *                       Test DORGLQ, using factorization
// *                       returned by DLQT01
// *
Dlqt02.dlqt02(m,n,k,a,_a_offset,af,_af_offset,aq,_aq_offset,al,_al_offset,lda,tau,_tau_offset,work,_work_offset,lwork,rwork,_rwork_offset,result,(1)- 1);
}              // Close else if()
else  {
  result[(1)- 1] = zero;
result[(2)- 1] = zero;
}              //  Close else.
if (m >= k)  {
    // *
// *                       Test DORMLQ, using factorization returned
// *                       by DLQT01
// *
Dlqt03.dlqt03(m,n,k,af,_af_offset,ac,_ac_offset,al,_al_offset,aq,_aq_offset,lda,tau,_tau_offset,work,_work_offset,lwork,rwork,_rwork_offset,result,(3)- 1);
nt = nt+4;
// *
// *                       If M>=N and K=N, call DGELQS to solve a system
// *                       with NRHS right hand sides and compute the
// *                       residual.
// *
if (k == m && inb == 1)  {
    // *
// *                          Generate a solution and set the right
// *                          hand side.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,"New","Full","No transpose",m,n,0,0,nrhs,a,_a_offset,lda,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
// *
Dlacpy.dlacpy("Full",m,nrhs,b,_b_offset,lda,x,_x_offset,lda);
lintest_srnamc.srnamt = "DGELQS";
Dgelqs.dgelqs(m,n,nrhs,af,_af_offset,lda,tau,_tau_offset,x,_x_offset,lda,work,_work_offset,lwork,info);
// *
// *                          Check error code from DGELQS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DGELQS",info.val,0," ",m,n,nrhs,-1,nb,imat,nfail,nerrs,nout);
// *
dget02_adapter("No transpose",m,n,nrhs,a,_a_offset,lda,x,_x_offset,lda,b,_b_offset,lda,rwork,_rwork_offset,result,(7)- 1);
nt = nt+1;
}              // Close if()
else  {
  result[(7)- 1] = zero;
}              //  Close else.
}              // Close if()
else  {
  result[(3)- 1] = zero;
result[(4)- 1] = zero;
result[(5)- 1] = zero;
result[(6)- 1] = zero;
}              //  Close else.
// *
// *                    Print information about the tests that did not
// *                    pass the threshold.
// *
{
forloop20:
for (i = 1; i <= nt; i++) {
if (result[(i)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" M="  + (m) + " "  + ", N="  + (n) + " "  + ", K="  + (k) + " "  + ", NB="  + (nb) + " "  + ", NX="  + (nx) + " "  + ", type "  + (imat) + " "  + ", test("  + (i) + " "  + ")="  + (result[(i)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchklq",20);
}              //  Close for() loop. 
}
nrun = nrun+nt;
Dummy.label("Dchklq",30);
}              //  Close for() loop. 
}
Dummy.label("Dchklq",40);
}              //  Close for() loop. 
}
Dummy.label("Dchklq",50);
}              //  Close for() loop. 
}
Dummy.label("Dchklq",60);
}              //  Close for() loop. 
}
Dummy.label("Dchklq",70);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchklq",999999);
// *
// *     End of DCHKLQ
// *
Dummy.label("Dchklq",999999);
return;
   }
// adapter for dget02
private static void dget02_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dget02.dget02(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

} // End class.
