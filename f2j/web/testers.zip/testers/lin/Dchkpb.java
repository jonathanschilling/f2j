/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchkpb {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKPB tests DPBTRF, -TRS, -RFS, and -CON.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB contained in the vector NBVAL.
// *
// *  NBVAL   (input) INTEGER array, dimension (NBVAL)
// *          The values of the blocksize NB.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for N, used in dimensioning the
// *          work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AFAC    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AINV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 8;
static int ntests= 7;
static int nbw= 4;
// *     ..
// *     .. Local Scalars ..
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String packit= new String(" ");
static StringW type= new StringW(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int i1= 0;
static int i2= 0;
static int ikd= 0;
static int imat= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int ioff= 0;
static int iuplo= 0;
static int iw= 0;
static int izero= 0;
static int k= 0;
static int kd= 0;
static intW kl= new intW(0);
static int koff= 0;
static intW ku= new intW(0);
static int lda= 0;
static int ldab= 0;
static intW mode= new intW(0);
static int n= 0;
static int nb= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nkd= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static doubleW cndnum= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static int [] kdval= new int[(nbw)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchkpb (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
double [] ainv, int _ainv_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "PB".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchkpb",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrpo.derrpo(path,nout);
lintest_infoc.infot = 0;
Xlaenv.xlaenv(2,2);
kdval[(1)- 1] = 0;
// *
// *     Do for each value of N in NVAL
// *
{
forloop90:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(n, 1) );
xtype = "N";
// *
// *        Set limits on the number of loop iterations.
// *
nkd = (int)(Math.max(1, Math.min(n, 4) ) );
nimat = ntypes;
if (n == 0)  
    nimat = 1;
// *
kdval[(2)- 1] = n+(n+1)/4;
kdval[(3)- 1] = (3*n-1)/4;
kdval[(4)- 1] = (n+1)/4;
// *
{
forloop80:
for (ikd = 1; ikd <= nkd; ikd++) {
// *
// *           Do for KD = 0, (5*N+1)/4, (3N-1)/4, and (N+1)/4. This order
// *           makes it easier to skip redundant values for small values
// *           of N.
// *
kd = kdval[(ikd)- 1];
ldab = kd+1;
// *
// *           Do first for UPLO = 'U', then for UPLO = 'L'
// *
{
forloop70:
for (iuplo = 1; iuplo <= 2; iuplo++) {
koff = 1;
if (iuplo == 1)  {
    uplo = "U";
koff = (int)(Math.max(1, kd+2-n) );
packit = "Q";
}              // Close if()
else  {
  uplo = "L";
packit = "B";
}              //  Close else.
// *
{
forloop60:
for (imat = 1; imat <= nimat; imat++) {
// *
// *                 Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop60;
// *
// *                 Skip types 2, 3, or 4 if the matrix size is too small.
// *
zerot = imat >= 2 && imat <= 4;
if (zerot && n < imat-1)  
    continue forloop60;
// *
if (!zerot || !dotype[(1)- 1+ _dotype_offset])  {
    // *
// *                    Set up parameters with DLATB4 and generate a test
// *                    matrix with DLATMS.
// *
Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(n,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kd,kd,packit,a,(koff)- 1+ _a_offset,ldab,work,_work_offset,info);
// *
// *                    Check error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0,uplo,n,n,kd,kd,-1,imat,nfail,nerrs,nout);
continue forloop60;
}              // Close if()
}              // Close if()
else if (izero > 0)  {
    // *
// *                    Use the same matrix for types 3 and 4 as for type
// *                    2 by copying back the zeroed out column,
// *
iw = 2*lda+1;
if (iuplo == 1)  {
    ioff = (izero-1)*ldab+kd+1;
Dcopy.dcopy(izero-i1,work,(iw)- 1+ _work_offset,1,a,(ioff-izero+i1)- 1+ _a_offset,1);
iw = iw+izero-i1;
Dcopy.dcopy(i2-izero+1,work,(iw)- 1+ _work_offset,1,a,(ioff)- 1+ _a_offset,(int) ( Math.max(ldab-1, 1) ));
}              // Close if()
else  {
  ioff = (i1-1)*ldab+1;
Dcopy.dcopy(izero-i1,work,(iw)- 1+ _work_offset,1,a,(ioff+izero-i1)- 1+ _a_offset,(int) ( Math.max(ldab-1, 1) ));
ioff = (izero-1)*ldab+1;
iw = iw+izero-i1;
Dcopy.dcopy(i2-izero+1,work,(iw)- 1+ _work_offset,1,a,(ioff)- 1+ _a_offset,1);
}              //  Close else.
}              // Close else if()
// *
// *                 For types 2-4, zero one row and column of the matrix
// *                 to test that INFO is returned correctly.
// *
izero = 0;
if (zerot)  {
    if (imat == 2)  {
    izero = 1;
}              // Close if()
else if (imat == 3)  {
    izero = n;
}              // Close else if()
else  {
  izero = n/2+1;
}              //  Close else.
// *
// *                    Save the zeroed out row and column in WORK(*,3)
// *
iw = 2*lda;
{
forloop20:
for (i = 1; i <= Math.min(2*kd+1, n) ; i++) {
work[(iw+i)- 1+ _work_offset] = zero;
Dummy.label("Dchkpb",20);
}              //  Close for() loop. 
}
iw = iw+1;
i1 = (int)(Math.max(izero-kd, 1) );
i2 = (int)(Math.min(izero+kd, n) );
// *
if (iuplo == 1)  {
    ioff = (izero-1)*ldab+kd+1;
Dswap.dswap(izero-i1,a,(ioff-izero+i1)- 1+ _a_offset,1,work,(iw)- 1+ _work_offset,1);
iw = iw+izero-i1;
Dswap.dswap(i2-izero+1,a,(ioff)- 1+ _a_offset,(int) ( Math.max(ldab-1, 1) ),work,(iw)- 1+ _work_offset,1);
}              // Close if()
else  {
  ioff = (i1-1)*ldab+1;
Dswap.dswap(izero-i1,a,(ioff+izero-i1)- 1+ _a_offset,(int) ( Math.max(ldab-1, 1) ),work,(iw)- 1+ _work_offset,1);
ioff = (izero-1)*ldab+1;
iw = iw+izero-i1;
Dswap.dswap(i2-izero+1,a,(ioff)- 1+ _a_offset,1,work,(iw)- 1+ _work_offset,1);
}              //  Close else.
}              // Close if()
// *
// *                 Do for each value of NB in NBVAL
// *
{
forloop50:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
// *
// *                    Compute the L*L' or U'*U factorization of the band
// *                    matrix.
// *
Dlacpy.dlacpy("Full",kd+1,n,a,_a_offset,ldab,afac,_afac_offset,ldab);
lintest_srnamc.srnamt = "DPBTRF";
Dpbtrf.dpbtrf(uplo,n,kd,afac,_afac_offset,ldab,info);
// *
// *                    Check error code from DPBTRF.
// *
if (info.val != izero)  {
    Alaerh.alaerh(path,"DPBTRF",info.val,izero,uplo,n,n,kd,kd,nb,imat,nfail,nerrs,nout);
continue forloop50;
}              // Close if()
// *
// *                    Skip the tests if INFO is not 0.
// *
if (info.val != 0)  
    continue forloop50;
// *
// *+    TEST 1
// *                    Reconstruct matrix from factors and compute
// *                    residual.
// *
Dlacpy.dlacpy("Full",kd+1,n,afac,_afac_offset,ldab,ainv,_ainv_offset,ldab);
dpbt01_adapter(uplo,n,kd,a,_a_offset,ldab,ainv,_ainv_offset,ldab,rwork,_rwork_offset,result,(1)- 1);
nt = 1;
// *
// *                    Only do other tests if this is the first blocksize.
// *
if (inb > 1)  
    Dummy.go_to("Dchkpb",30);
// *
// *                    Form the inverse of A so we can get a good estimate
// *                    of RCONDC = 1/(norm(A) * norm(inv(A))).
// *
Dlaset.dlaset("Full",n,n,zero,one,ainv,_ainv_offset,lda);
lintest_srnamc.srnamt = "DPBTRS";
Dpbtrs.dpbtrs(uplo,n,kd,n,afac,_afac_offset,ldab,ainv,_ainv_offset,lda,info);
// *
// *                    Compute RCONDC = 1/(norm(A) * norm(inv(A))).
// *
anorm.val = Dlansb.dlansb("1",uplo,n,kd,a,_a_offset,ldab,rwork,_rwork_offset);
ainvnm = Dlange.dlange("1",n,n,ainv,_ainv_offset,lda,rwork,_rwork_offset);
if (anorm.val <= zero || ainvnm <= zero)  {
    rcondc = one;
}              // Close if()
else  {
  rcondc = (one/anorm.val)/ainvnm;
}              //  Close else.
// *
// *+    TEST 2
// *                    Solve and compute residual for A * X = B.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo," ",n,n,kd,kd,nrhs,a,_a_offset,ldab,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DPBTRS";
Dpbtrs.dpbtrs(uplo,n,kd,nrhs,afac,_afac_offset,ldab,x,_x_offset,lda,info);
// *
// *                    Check error code from DPBTRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DPBTRS",info.val,0,uplo,n,n,kd,kd,nrhs,imat,nfail,nerrs,nout);
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dpbt02_adapter(uplo,n,kd,nrhs,a,_a_offset,ldab,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(2)- 1);
// *
// *+    TEST 3
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *+    TESTS 4, 5, and 6
// *                    Use iterative refinement to improve the solution.
// *
lintest_srnamc.srnamt = "DPBRFS";
Dpbrfs.dpbrfs(uplo,n,kd,nrhs,a,_a_offset,ldab,afac,_afac_offset,ldab,b,_b_offset,lda,x,_x_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                    Check error code from DPBRFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DPBRFS",info.val,0,uplo,n,n,kd,kd,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(4)- 1);
Dpbt05.dpbt05(uplo,n,kd,nrhs,a,_a_offset,ldab,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(5)- 1);
// *
// *+    TEST 7
// *                    Get an estimate of RCOND = 1/CNDNUM.
// *
lintest_srnamc.srnamt = "DPBCON";
Dpbcon.dpbcon(uplo,n,kd,afac,_afac_offset,ldab,anorm.val,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                    Check error code from DPBCON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DPBCON",info.val,0,uplo,n,n,kd,kd,-1,imat,nfail,nerrs,nout);
// *
result[(7)- 1] = Dget06.dget06(rcond.val,rcondc);
nt = 7;
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
label30:
   Dummy.label("Dchkpb",30);
{
forloop40:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" UPLO=\'"  + (uplo) + " "  + "\', N="  + (n) + " "  + ", KD="  + (kd) + " "  + ", NB="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio= "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkpb",40);
}              //  Close for() loop. 
}
nrun = nrun+nt;
Dummy.label("Dchkpb",50);
}              //  Close for() loop. 
}
// *
Dummy.label("Dchkpb",60);
}              //  Close for() loop. 
}
Dummy.label("Dchkpb",70);
}              //  Close for() loop. 
}
Dummy.label("Dchkpb",80);
}              //  Close for() loop. 
}
Dummy.label("Dchkpb",90);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchkpb",999999);
// *
// *     End of DCHKPB
// *
Dummy.label("Dchkpb",999999);
return;
   }
// adapter for dpbt01
private static void dpbt01_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset )
{
doubleW _f2j_tmp8 = new doubleW(arg8[arg8_offset]);

Dpbt01.dpbt01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,_f2j_tmp8);

arg8[arg8_offset] = _f2j_tmp8.val;
}

// adapter for dpbt02
private static void dpbt02_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dpbt02.dpbt02(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
