/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dchkqp {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKQP tests DGEQPF.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *          where MMAX is the maximum value of M in MVAL and NMAX is the
// *          maximum value of N in NVAL.
// *
// *  COPYA   (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension
// *                      (min(MMAX,NMAX))
// *
// *  COPYS   (workspace) DOUBLE PRECISION array, dimension
// *                      (min(MMAX,NMAX))
// *
// *  TAU     (workspace) DOUBLE PRECISION array, dimension (MMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (MMAX*NMAX + 4*NMAX + MMAX)
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntypes= 6;
static int ntests= 3;
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static String path= new String("   ");
static int i= 0;
static int ihigh= 0;
static int ilow= 0;
static int im= 0;
static int imode= 0;
static int in= 0;
static intW info= new intW(0);
static int istep= 0;
static int k= 0;
static int lda= 0;
static int lwork= 0;
static int m= 0;
static int mnmin= 0;
static int mode= 0;
static int n= 0;
static int nerrs= 0;
static int nfail= 0;
static int nrun= 0;
static double eps= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchkqp (boolean [] dotype, int _dotype_offset,
int nm,
int [] mval, int _mval_offset,
int nn,
int [] nval, int _nval_offset,
double thresh,
boolean tsterr,
double [] a, int _a_offset,
double [] copya, int _copya_offset,
double [] s, int _s_offset,
double [] copys, int _copys_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "QP".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchkqp",10);
}              //  Close for() loop. 
}
eps = Dlamch.dlamch("Epsilon");
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrqp.derrqp(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop80:
for (im = 1; im <= nm; im++) {
// *
// *        Do for each value of M in MVAL.
// *
m = mval[(im)- 1+ _mval_offset];
lda = (int)(Math.max(1, m) );
// *
{
forloop70:
for (in = 1; in <= nn; in++) {
// *
// *           Do for each value of N in NVAL.
// *
n = nval[(in)- 1+ _nval_offset];
mnmin = (int)(Math.min(m, n) );
lwork = (int)(Math.max(1, m*Math.max(m, n) +4*mnmin+Math.max(m, n) ) );
// *
{
forloop60:
for (imode = 1; imode <= ntypes; imode++) {
if (!dotype[(imode)- 1+ _dotype_offset])  
    continue forloop60;
// *
// *              Do for each type of matrix
// *                 1:  zero matrix
// *                 2:  one small singular value
// *                 3:  geometric distribution of singular values
// *                 4:  first n/2 columns fixed
// *                 5:  last n/2 columns fixed
// *                 6:  every second column fixed
// *
mode = imode;
if (imode > 3)  
    mode = 1;
// *
// *              Generate test matrix of size m by n using
// *              singular value distribution indicated by `mode'.
// *
{
forloop20:
for (i = 1; i <= n; i++) {
iwork[(i)- 1+ _iwork_offset] = 0;
Dummy.label("Dchkqp",20);
}              //  Close for() loop. 
}
if (imode == 1)  {
    Dlaset.dlaset("Full",m,n,zero,zero,copya,_copya_offset,lda);
{
forloop30:
for (i = 1; i <= mnmin; i++) {
copys[(i)- 1+ _copys_offset] = zero;
Dummy.label("Dchkqp",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  Dlatms.dlatms(m,n,"Uniform",iseed,0,"Nonsymm",copys,_copys_offset,mode,one/eps,one,m,n,"No packing",copya,_copya_offset,lda,work,_work_offset,info);
if (imode >= 4)  {
    if (imode == 4)  {
    ilow = 1;
istep = 1;
ihigh = (int)(Math.max(1, n/2) );
}              // Close if()
else if (imode == 5)  {
    ilow = (int)(Math.max(1, n/2) );
istep = 1;
ihigh = n;
}              // Close else if()
else if (imode == 6)  {
    ilow = 1;
istep = 2;
ihigh = n;
}              // Close else if()
{
int _i_inc = istep;
forloop40:
for (i = ilow; (_i_inc < 0) ? i >= ihigh : i <= ihigh; i += _i_inc) {
iwork[(i)- 1+ _iwork_offset] = 1;
Dummy.label("Dchkqp",40);
}              //  Close for() loop. 
}
}              // Close if()
Dlaord.dlaord("Decreasing",mnmin,copys,_copys_offset,1);
}              //  Close else.
// *
// *              Save A and its singular values
// *
Dlacpy.dlacpy("All",m,n,copya,_copya_offset,lda,a,_a_offset,lda);
// *
// *              Compute the QR factorization with pivoting of A
// *
lintest_srnamc.srnamt = "DGEQPF";
Dgeqpf.dgeqpf(m,n,a,_a_offset,lda,iwork,_iwork_offset,tau,_tau_offset,work,_work_offset,info);
// *
// *              Compute norm(svd(a) - svd(r))
// *
result[(1)- 1] = Dqrt12.dqrt12(m,n,a,_a_offset,lda,copys,_copys_offset,work,_work_offset,lwork);
// *
// *              Compute norm( A*P - Q*R )
// *
result[(2)- 1] = Dqpt01.dqpt01(m,n,mnmin,copya,_copya_offset,a,_a_offset,lda,tau,_tau_offset,iwork,_iwork_offset,work,_work_offset,lwork);
// *
// *              Compute Q'*Q
// *
result[(3)- 1] = Dqrt11.dqrt11(m,mnmin,a,_a_offset,lda,tau,_tau_offset,work,_work_offset,lwork);
// *
// *              Print information about the tests that did not pass
// *              the threshold.
// *
{
forloop50:
for (k = 1; k <= 3; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs == 0)  
    Alahd.alahd(nout,path);
System.out.println(" M ="  + (m) + " "  + ", N ="  + (n) + " "  + ", type "  + (imode) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchkqp",50);
}              //  Close for() loop. 
}
nrun = nrun+3;
Dummy.label("Dchkqp",60);
}              //  Close for() loop. 
}
Dummy.label("Dchkqp",70);
}              //  Close for() loop. 
}
Dummy.label("Dchkqp",80);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs);
// *
// *
// *     End if DCHKQP
// *
Dummy.label("Dchkqp",999999);
return;
   }
} // End class.
