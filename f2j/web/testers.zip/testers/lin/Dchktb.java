/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchktb {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKTB tests DTBTRI, -TRS, -RFS, and -CON, and DLATBS.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The leading dimension of the work arrays.
// *          NMAX >= the maximum value of N in NVAL.
// *
// *  AB      (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AINV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntype1= 9;
static int ntypes= 17;
static int ntests= 8;
static int ntran= 3;
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static StringW diag= new StringW(" ");
static String norm= new String(" ");
static String trans= new String(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int idiag= 0;
static int ik= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int itran= 0;
static int iuplo= 0;
static int j= 0;
static int k= 0;
static int kd= 0;
static int lda= 0;
static int ldab= 0;
static int n= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nimat2= 0;
static int nk= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static double rcondo= 0.0;
static doubleW scale= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
static String [] transs = {"N" 
, "T" , "C" };
static String [] uplos = {"U" 
, "L" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchktb (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] ab, int _ab_offset,
double [] ainv, int _ainv_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "TB".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchktb",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrtr.derrtr(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop120:
for (in = 1; in <= nn; in++) {
// *
// *        Do for each value of N in NVAL
// *
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(1, n) );
xtype = "N";
nimat = ntype1;
nimat2 = ntypes;
if (n <= 0)  {
    nimat = 1;
nimat2 = ntype1+1;
}              // Close if()
// *
nk = (int)(Math.min(n+1, 4) );
{
forloop110:
for (ik = 1; ik <= nk; ik++) {
// *
// *           Do for KD = 0, N, (3N-1)/4, and (N+1)/4. This order makes
// *           it easier to skip redundant values for small values of N.
// *
if (ik == 1)  {
    kd = 0;
}              // Close if()
else if (ik == 2)  {
    kd = (int)(Math.max(n, 0) );
}              // Close else if()
else if (ik == 3)  {
    kd = (3*n-1)/4;
}              // Close else if()
else if (ik == 4)  {
    kd = (n+1)/4;
}              // Close else if()
ldab = kd+1;
// *
{
forloop70:
for (imat = 1; imat <= nimat; imat++) {
// *
// *              Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop70;
// *
{
forloop60:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *                 Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
// *
// *                 Call DLATTB to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTB";
Dlattb.dlattb(imat,uplo,"No transpose",diag,iseed,0,n,kd,ab,_ab_offset,ldab,x,_x_offset,work,_work_offset,info);
// *
// *                 Set IDIAG = 1 for non-unit matrices, 2 for unit.
// *
if ((diag.val.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idiag = 1;
}              // Close if()
else  {
  idiag = 2;
}              //  Close else.
// *
// *                 Form the inverse of A so we can get a good estimate
// *                 of RCONDC = 1/(norm(A) * norm(inv(A))).
// *
Dlaset.dlaset("Full",n,n,zero,one,ainv,_ainv_offset,lda);
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
Dtbsv.dtbsv(uplo,"No transpose",diag.val,j,kd,ab,_ab_offset,ldab,ainv,((j-1)*lda+1)- 1+ _ainv_offset,1);
Dummy.label("Dchktb",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop30:
for (j = 1; j <= n; j++) {
Dtbsv.dtbsv(uplo,"No transpose",diag.val,n-j+1,kd,ab,((j-1)*ldab+1)- 1+ _ab_offset,ldab,ainv,((j-1)*lda+j)- 1+ _ainv_offset,1);
Dummy.label("Dchktb",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *                 Compute the 1-norm condition number of A.
// *
anorm = Dlantb.dlantb("1",uplo,diag.val,n,kd,ab,_ab_offset,ldab,rwork,_rwork_offset);
ainvnm = Dlantr.dlantr("1",uplo,diag.val,n,n,ainv,_ainv_offset,lda,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcondo = one;
}              // Close if()
else  {
  rcondo = (one/anorm)/ainvnm;
}              //  Close else.
// *
// *                 Compute the infinity-norm condition number of A.
// *
anorm = Dlantb.dlantb("I",uplo,diag.val,n,kd,ab,_ab_offset,ldab,rwork,_rwork_offset);
ainvnm = Dlantr.dlantr("I",uplo,diag.val,n,n,ainv,_ainv_offset,lda,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anorm)/ainvnm;
}              //  Close else.
// *
{
forloop50:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                    Do for op(A) = A, A**T, or A**H.
// *
trans = transs[(itran)- 1];
if (itran == 1)  {
    norm = "O";
rcondc = rcondo;
}              // Close if()
else  {
  norm = "I";
rcondc = rcondi;
}              //  Close else.
// *
// *+    TEST 1
// *                    Solve and compute residual for op(A)*x = b.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo,trans,n,n,kd,idiag,nrhs,ab,_ab_offset,ldab,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DTBTRS";
Dtbtrs.dtbtrs(uplo,trans,diag.val,n,kd,nrhs,ab,_ab_offset,ldab,x,_x_offset,lda,info);
// *
// *                    Check error code from DTBTRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTBTRS",info.val,0,uplo+trans+diag.val,n,n,kd,kd,nrhs,imat,nfail,nerrs,nout);
// *
dtbt02_adapter(uplo,trans,diag.val,n,kd,nrhs,ab,_ab_offset,ldab,x,_x_offset,lda,b,_b_offset,lda,work,_work_offset,result,(1)- 1);
// *
// *+    TEST 2
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(2)- 1);
// *
// *+    TESTS 3, 4, and 5
// *                    Use iterative refinement to improve the solution
// *                    and compute error bounds.
// *
lintest_srnamc.srnamt = "DTBRFS";
Dtbrfs.dtbrfs(uplo,trans,diag.val,n,kd,nrhs,ab,_ab_offset,ldab,b,_b_offset,lda,x,_x_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                    Check error code from DTBRFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTBRFS",info.val,0,uplo+trans+diag.val,n,n,kd,kd,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
Dtbt05.dtbt05(uplo,trans,diag.val,n,kd,nrhs,ab,_ab_offset,ldab,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(4)- 1);
// *
// *+    TEST 6
// *                    Get an estimate of RCOND = 1/CNDNUM.
// *
lintest_srnamc.srnamt = "DTBCON";
Dtbcon.dtbcon(norm,uplo,diag.val,n,kd,ab,_ab_offset,ldab,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                    Check error code from DTBCON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTBCON",info.val,0,norm+uplo+diag.val,n,n,kd,kd,-1,imat,nfail,nerrs,nout);
// *
dtbt06_adapter(rcond.val,rcondc,uplo,diag.val,n,kd,ab,_ab_offset,ldab,rwork,_rwork_offset,result,(6)- 1);
nt = 6;
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop40:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" UPLO=\'"  + (uplo) + " "  + "\', TRANS=\'"  + (trans) + " "  + "\', N="  + (n) + " "  + ", KD="  + (kd) + " "  + ", type "  + (imat) + " "  + ", test("  + (k) + " "  + ")="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchktb",40);
}              //  Close for() loop. 
}
nrun = nrun+nt;
Dummy.label("Dchktb",50);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",60);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",70);
}              //  Close for() loop. 
}
// *
// *           Use pathological test matrices to test DLATBS.
// *
{
forloop100:
for (imat = ntype1+1; imat <= nimat2; imat++) {
// *
// *              Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop100;
// *
{
forloop90:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *                 Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
{
forloop80:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                    Do for op(A) = A, A**T, and A**H.
// *
trans = transs[(itran)- 1];
// *
// *                    Call DLATTB to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTB";
Dlattb.dlattb(imat,uplo,trans,diag,iseed,0,n,kd,ab,_ab_offset,ldab,x,_x_offset,work,_work_offset,info);
// *
// *+    TEST 7
// *                    Solve the system op(A)*x = b
// *
lintest_srnamc.srnamt = "DLATBS";
Dcopy.dcopy(n,x,_x_offset,1,b,_b_offset,1);
Dlatbs.dlatbs(uplo,trans,diag.val,"N",n,kd,ab,_ab_offset,ldab,b,_b_offset,scale,rwork,_rwork_offset,info);
// *
// *                    Check error code from DLATBS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATBS",info.val,0,uplo+trans+diag.val+"N",n,n,kd,kd,-1,imat,nfail,nerrs,nout);
// *
dtbt03_adapter(uplo,trans,diag.val,n,kd,1,ab,_ab_offset,ldab,scale.val,rwork,_rwork_offset,one,b,_b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(7)- 1);
// *
// *+    TEST 8
// *                    Solve op(A)*x = b again with NORMIN = 'Y'.
// *
Dcopy.dcopy(n,x,_x_offset,1,b,_b_offset,1);
Dlatbs.dlatbs(uplo,trans,diag.val,"Y",n,kd,ab,_ab_offset,ldab,b,_b_offset,scale,rwork,_rwork_offset,info);
// *
// *                    Check error code from DLATBS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATBS",info.val,0,uplo+trans+diag.val+"Y",n,n,kd,kd,-1,imat,nfail,nerrs,nout);
// *
dtbt03_adapter(uplo,trans,diag.val,n,kd,1,ab,_ab_offset,ldab,scale.val,rwork,_rwork_offset,one,b,_b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(8)- 1);
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
if (result[(7)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATBS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("N") + " "  + "\',"  + (n) + " "  + ","  + (kd) + " "  + ",  ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(7)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
if (result[(8)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATBS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("Y") + " "  + "\',"  + (n) + " "  + ","  + (kd) + " "  + ",  ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(8)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+2;
Dummy.label("Dchktb",80);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",90);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",100);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",110);
}              //  Close for() loop. 
}
Dummy.label("Dchktb",120);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchktb",999999);
// *
// *     End of DCHKTB
// *
Dummy.label("Dchktb",999999);
return;
   }
// adapter for dtbt02
private static void dtbt02_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,int arg11 ,double [] arg12 , int arg12_offset ,double [] arg13 , int arg13_offset )
{
doubleW _f2j_tmp13 = new doubleW(arg13[arg13_offset]);

Dtbt02.dtbt02(arg0,arg1,arg2,arg3,arg4,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,arg11,arg12, arg12_offset,_f2j_tmp13);

arg13[arg13_offset] = _f2j_tmp13.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dtbt06
private static void dtbt06_adapter(double arg0 ,double arg1 ,String arg2 ,String arg3 ,int arg4 ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset )
{
doubleW _f2j_tmp9 = new doubleW(arg9[arg9_offset]);

Dtbt06.dtbt06(arg0,arg1,arg2,arg3,arg4,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,_f2j_tmp9);

arg9[arg9_offset] = _f2j_tmp9.val;
}

// adapter for dtbt03
private static void dtbt03_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double arg8 ,double [] arg9 , int arg9_offset ,double arg10 ,double [] arg11 , int arg11_offset ,int arg12 ,double [] arg13 , int arg13_offset ,int arg14 ,double [] arg15 , int arg15_offset ,double [] arg16 , int arg16_offset )
{
doubleW _f2j_tmp16 = new doubleW(arg16[arg16_offset]);

Dtbt03.dtbt03(arg0,arg1,arg2,arg3,arg4,arg5,arg6, arg6_offset,arg7,arg8,arg9, arg9_offset,arg10,arg11, arg11_offset,arg12,arg13, arg13_offset,arg14,arg15, arg15_offset,_f2j_tmp16);

arg16[arg16_offset] = _f2j_tmp16.val;
}

} // End class.
