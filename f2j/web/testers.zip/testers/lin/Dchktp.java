/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchktp {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKTP tests DTPTRI, -TRS, -RFS, and -CON, and DLATPS
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The leading dimension of the work arrays.  NMAX >= the
// *          maximumm value of N in NVAL.
// *
// *  AP      (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*(NMAX+1)/2)
// *
// *  AINVP   (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*(NMAX+1)/2)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntype1= 10;
static int ntypes= 18;
static int ntests= 9;
static int ntran= 3;
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static StringW diag= new StringW(" ");
static String norm= new String(" ");
static String trans= new String(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int idiag= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int itran= 0;
static int iuplo= 0;
static int k= 0;
static int k1= 0;
static int lap= 0;
static int lda= 0;
static int n= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static doubleW rcondo= new doubleW(0.0);
static doubleW scale= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
static String [] transs = {"N" 
, "T" , "C" };
static String [] uplos = {"U" 
, "L" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchktp (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] ap, int _ap_offset,
double [] ainvp, int _ainvp_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "TP".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchktp",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrtr.derrtr(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop90:
for (in = 1; in <= nn; in++) {
// *
// *        Do for each value of N in NVAL
// *
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(1, n) );
lap = lda*(lda+1)/2;
xtype = "N";
// *
{
forloop50:
for (imat = 1; imat <= ntype1; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop50;
// *
{
forloop40:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *              Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
// *
// *              Call DLATTP to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTP";
Dlattp.dlattp(imat,uplo,"No transpose",diag,iseed,0,n,ap,_ap_offset,x,_x_offset,work,_work_offset,info);
// *
// *              Set IDIAG = 1 for non-unit matrices, 2 for unit.
// *
if ((diag.val.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idiag = 1;
}              // Close if()
else  {
  idiag = 2;
}              //  Close else.
// *
// *+    TEST 1
// *              Form the inverse of A.
// *
if (n > 0)  
    Dcopy.dcopy(lap,ap,_ap_offset,1,ainvp,_ainvp_offset,1);
lintest_srnamc.srnamt = "DTPTRI";
Dtptri.dtptri(uplo,diag.val,n,ainvp,_ainvp_offset,info);
// *
// *              Check error code from DTPTRI.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTPTRI",info.val,0,uplo+diag.val,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
// *              Compute the infinity-norm condition number of A.
// *
anorm = Dlantp.dlantp("I",uplo,diag.val,n,ap,_ap_offset,rwork,_rwork_offset);
ainvnm = Dlantp.dlantp("I",uplo,diag.val,n,ainvp,_ainvp_offset,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anorm)/ainvnm;
}              //  Close else.
// *
// *              Compute the residual for the triangular matrix times its
// *              inverse.  Also compute the 1-norm condition number of A.
// *
dtpt01_adapter(uplo,diag.val,n,ap,_ap_offset,ainvp,_ainvp_offset,rcondo,rwork,_rwork_offset,result,(1)- 1);
k1 = 1;
// *
{
forloop30:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                 Do for op(A) = A, A**T, or A**H.
// *
trans = transs[(itran)- 1];
if (itran == 1)  {
    norm = "O";
rcondc = rcondo.val;
}              // Close if()
else  {
  norm = "I";
rcondc = rcondi;
k1 = 2;
}              //  Close else.
// *
// *+    TEST 2
// *                 Solve and compute residual for op(A)*x = b.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo,trans,n,n,0,idiag,nrhs,ap,_ap_offset,lap,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DTPTRS";
Dtptrs.dtptrs(uplo,trans,diag.val,n,nrhs,ap,_ap_offset,x,_x_offset,lda,info);
// *
// *                 Check error code from DTPTRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTPTRS",info.val,0,uplo+trans+diag.val,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtpt02_adapter(uplo,trans,diag.val,n,nrhs,ap,_ap_offset,x,_x_offset,lda,b,_b_offset,lda,work,_work_offset,result,(2)- 1);
// *
// *+    TEST 3
// *                 Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *+    TESTS 4, 5, and 6
// *                 Use iterative refinement to improve the solution and
// *                 compute error bounds.
// *
lintest_srnamc.srnamt = "DTPRFS";
Dtprfs.dtprfs(uplo,trans,diag.val,n,nrhs,ap,_ap_offset,b,_b_offset,lda,x,_x_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                 Check error code from DTPRFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTPRFS",info.val,0,uplo+trans+diag.val,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(4)- 1);
Dtpt05.dtpt05(uplo,trans,diag.val,n,nrhs,ap,_ap_offset,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(5)- 1);
// *
// *+    TEST 7
// *                 Get an estimate of RCOND = 1/CNDNUM.
// *
lintest_srnamc.srnamt = "DTPCON";
Dtpcon.dtpcon(norm,uplo,diag.val,n,ap,_ap_offset,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                 Check error code from DTPCON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTPCON",info.val,0,norm+uplo+diag.val,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtpt06_adapter(rcond.val,rcondc,uplo,diag.val,n,ap,_ap_offset,rwork,_rwork_offset,result,(7)- 1);
nt = 7;
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
{
forloop20:
for (k = k1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" UPLO=\'"  + (uplo) + " "  + "\', TRANS=\'"  + (trans) + " "  + "\', N="  + (n) + " "  + ", type "  + (imat) + " "  + ", test("  + (k) + " "  + ")= "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchktp",20);
}              //  Close for() loop. 
}
nrun = nrun+nt-k1+1;
Dummy.label("Dchktp",30);
}              //  Close for() loop. 
}
Dummy.label("Dchktp",40);
}              //  Close for() loop. 
}
Dummy.label("Dchktp",50);
}              //  Close for() loop. 
}
// *
// *        Use pathological test matrices to test DLATPS.
// *
{
forloop80:
for (imat = ntype1+1; imat <= ntypes; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop80;
// *
{
forloop70:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *              Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
{
forloop60:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                 Do for op(A) = A, A**T, or A**H.
// *
trans = transs[(itran)- 1];
// *
// *                 Call DLATTP to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTP";
Dlattp.dlattp(imat,uplo,trans,diag,iseed,0,n,ap,_ap_offset,x,_x_offset,work,_work_offset,info);
// *
// *+    TEST 8
// *                 Solve the system op(A)*x = b.
// *
lintest_srnamc.srnamt = "DLATPS";
Dcopy.dcopy(n,x,_x_offset,1,b,_b_offset,1);
Dlatps.dlatps(uplo,trans,diag.val,"N",n,ap,_ap_offset,b,_b_offset,scale,rwork,_rwork_offset,info);
// *
// *                 Check error code from DLATPS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATPS",info.val,0,uplo+trans+diag.val+"N",n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtpt03_adapter(uplo,trans,diag.val,n,1,ap,_ap_offset,scale.val,rwork,_rwork_offset,one,b,_b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(8)- 1);
// *
// *+    TEST 9
// *                 Solve op(A)*x = b again with NORMIN = 'Y'.
// *
Dcopy.dcopy(n,x,_x_offset,1,b,(n+1)- 1+ _b_offset,1);
Dlatps.dlatps(uplo,trans,diag.val,"Y",n,ap,_ap_offset,b,(n+1)- 1+ _b_offset,scale,rwork,_rwork_offset,info);
// *
// *                 Check error code from DLATPS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATPS",info.val,0,uplo+trans+diag.val+"Y",n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtpt03_adapter(uplo,trans,diag.val,n,1,ap,_ap_offset,scale.val,rwork,_rwork_offset,one,b,(n+1)- 1+ _b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(9)- 1);
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
if (result[(8)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATPS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("N") + " "  + "\',"  + (n) + " "  + ", ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(8)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
if (result[(9)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATPS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("Y") + " "  + "\',"  + (n) + " "  + ", ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(9)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+2;
Dummy.label("Dchktp",60);
}              //  Close for() loop. 
}
Dummy.label("Dchktp",70);
}              //  Close for() loop. 
}
Dummy.label("Dchktp",80);
}              //  Close for() loop. 
}
Dummy.label("Dchktp",90);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchktp",999999);
// *
// *     End of DCHKTP
// *
Dummy.label("Dchktp",999999);
return;
   }
// adapter for dtpt01
private static void dtpt01_adapter(String arg0 ,String arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,doubleW arg5 ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dtpt01.dtpt01(arg0,arg1,arg2,arg3, arg3_offset,arg4, arg4_offset,arg5,arg6, arg6_offset,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dtpt02
private static void dtpt02_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dtpt02.dtpt02(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dtpt06
private static void dtpt06_adapter(double arg0 ,double arg1 ,String arg2 ,String arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dtpt06.dtpt06(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6, arg6_offset,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dtpt03
private static void dtpt03_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,double arg6 ,double [] arg7 , int arg7_offset ,double arg8 ,double [] arg9 , int arg9_offset ,int arg10 ,double [] arg11 , int arg11_offset ,int arg12 ,double [] arg13 , int arg13_offset ,double [] arg14 , int arg14_offset )
{
doubleW _f2j_tmp14 = new doubleW(arg14[arg14_offset]);

Dtpt03.dtpt03(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8,arg9, arg9_offset,arg10,arg11, arg11_offset,arg12,arg13, arg13_offset,_f2j_tmp14);

arg14[arg14_offset] = _f2j_tmp14.val;
}

} // End class.
