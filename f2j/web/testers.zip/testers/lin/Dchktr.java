/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dchktr {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DCHKTR tests DTRTRI, -TRS, -RFS, and -CON, and DLATRS
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB contained in the vector NBVAL.
// *
// *  NBVAL   (input) INTEGER array, dimension (NNB)
// *          The values of the blocksize NB.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The leading dimension of the work arrays.
// *          NMAX >= the maximum value of N in NVAL.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AINV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntype1= 10;
static int ntypes= 18;
static int ntests= 9;
static int ntran= 3;
static double one= 1.0e0;
static double zero= 0.0e0;
// *     ..
// *     .. Local Scalars ..
static StringW diag= new StringW(" ");
static String norm= new String(" ");
static String trans= new String(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int idiag= 0;
static int imat= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int itran= 0;
static int iuplo= 0;
static int k= 0;
static int k1= 0;
static int lda= 0;
static int n= 0;
static int nb= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double dummy= 0.0;
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static doubleW rcondo= new doubleW(0.0);
static doubleW scale= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
static String [] transs = {"N" 
, "T" , "C" };
static String [] uplos = {"U" 
, "L" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void dchktr (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] ainv, int _ainv_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "TR".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Dchktr",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrtr.derrtr(path,nout);
lintest_infoc.infot = 0;
Xlaenv.xlaenv(2,2);
// *
{
forloop100:
for (in = 1; in <= nn; in++) {
// *
// *        Do for each value of N in NVAL
// *
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(1, n) );
xtype = "N";
// *
{
forloop60:
for (imat = 1; imat <= ntype1; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop60;
// *
{
forloop50:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *              Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
// *
// *              Call DLATTR to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTR";
Dlattr.dlattr(imat,uplo,"No transpose",diag,iseed,0,n,a,_a_offset,lda,x,_x_offset,work,_work_offset,info);
// *
// *              Set IDIAG = 1 for non-unit matrices, 2 for unit.
// *
if ((diag.val.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    idiag = 1;
}              // Close if()
else  {
  idiag = 2;
}              //  Close else.
// *
{
forloop40:
for (inb = 1; inb <= nnb; inb++) {
// *
// *                 Do for each blocksize in NBVAL
// *
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
// *
// *+    TEST 1
// *                 Form the inverse of A.
// *
Dlacpy.dlacpy(uplo,n,n,a,_a_offset,lda,ainv,_ainv_offset,lda);
lintest_srnamc.srnamt = "DTRTRI";
Dtrtri.dtrtri(uplo,diag.val,n,ainv,_ainv_offset,lda,info);
// *
// *                 Check error code from DTRTRI.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTRTRI",info.val,0,uplo+diag.val,n,n,-1,-1,nb,imat,nfail,nerrs,nout);
// *
// *                 Compute the infinity-norm condition number of A.
// *
anorm = Dlantr.dlantr("I",uplo,diag.val,n,n,a,_a_offset,lda,rwork,_rwork_offset);
ainvnm = Dlantr.dlantr("I",uplo,diag.val,n,n,ainv,_ainv_offset,lda,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anorm)/ainvnm;
}              //  Close else.
// *
// *                 Compute the residual for the triangular matrix times
// *                 its inverse.  Also compute the 1-norm condition number
// *                 of A.
// *
dtrt01_adapter(uplo,diag.val,n,a,_a_offset,lda,ainv,_ainv_offset,lda,rcondo,rwork,_rwork_offset,result,(1)- 1);
k1 = 1;
nt = 1;
// *
{
forloop30:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                    Do for op(A) = A, A**T, or A**H.
// *
trans = transs[(itran)- 1];
if (itran == 1)  {
    norm = "O";
rcondc = rcondo.val;
}              // Close if()
else  {
  norm = "I";
rcondc = rcondi;
k1 = 2;
}              //  Close else.
// *
// *                    Do the rest of the tests only if this is the first
// *                    blocksize.
// *
if (inb == 1)  {
    // *
// *+    TEST 2
// *                       Solve and compute residual for op(A)*x = b.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo,trans,n,n,0,idiag,nrhs,a,_a_offset,lda,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DTRTRS";
Dtrtrs.dtrtrs(uplo,trans,diag.val,n,nrhs,a,_a_offset,lda,x,_x_offset,lda,info);
// *
// *                       Check error code from DTRTRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTRTRS",info.val,0,uplo+trans+diag.val,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
// *
// *                       This line is needed on a Sun SPARCstation.
// *
if (n > 0)  
    dummy = a[(1)- 1+ _a_offset];
// *
dtrt02_adapter(uplo,trans,diag.val,n,nrhs,a,_a_offset,lda,x,_x_offset,lda,b,_b_offset,lda,work,_work_offset,result,(2)- 1);
// *
// *+    TEST 3
// *                       Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *+    TESTS 4, 5, and 6
// *                       Use iterative refinement to improve the solution
// *                       and compute error bounds.
// *
lintest_srnamc.srnamt = "DTRRFS";
Dtrrfs.dtrrfs(uplo,trans,diag.val,n,nrhs,a,_a_offset,lda,b,_b_offset,lda,x,_x_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                       Check error code from DTRRFS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTRRFS",info.val,0,uplo+trans+diag.val,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(4)- 1);
Dtrt05.dtrt05(uplo,trans,diag.val,n,nrhs,a,_a_offset,lda,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(5)- 1);
// *
// *+    TEST 7
// *                       Get an estimate of RCOND = 1/CNDNUM.
// *
lintest_srnamc.srnamt = "DTRCON";
Dtrcon.dtrcon(norm,uplo,diag.val,n,a,_a_offset,lda,rcond,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                       Check error code from DTRCON.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DTRCON",info.val,0,norm+uplo+diag.val,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtrt06_adapter(rcond.val,rcondc,uplo,diag.val,n,a,_a_offset,lda,rwork,_rwork_offset,result,(7)- 1);
nt = 7;
}              // Close if()
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop20:
for (k = k1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" UPLO=\'"  + (uplo) + " "  + "\', TRANS=\'"  + (trans) + " "  + "\', N="  + (n) + " "  + ", NB="  + (nb) + " "  + ", type "  + (imat) + " "  + ", test("  + (k) + " "  + ")= "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Dchktr",20);
}              //  Close for() loop. 
}
nrun = nrun+nt-k1+1;
Dummy.label("Dchktr",30);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",40);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",50);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",60);
}              //  Close for() loop. 
}
// *
// *        Use pathological test matrices to test DLATRS.
// *
{
forloop90:
for (imat = ntype1+1; imat <= ntypes; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop90;
// *
{
forloop80:
for (iuplo = 1; iuplo <= 2; iuplo++) {
// *
// *              Do first for UPLO = 'U', then for UPLO = 'L'
// *
uplo = uplos[(iuplo)- 1];
{
forloop70:
for (itran = 1; itran <= ntran; itran++) {
// *
// *                 Do for op(A) = A, A**T, and A**H.
// *
trans = transs[(itran)- 1];
// *
// *                 Call DLATTR to generate a triangular test matrix.
// *
lintest_srnamc.srnamt = "DLATTR";
Dlattr.dlattr(imat,uplo,trans,diag,iseed,0,n,a,_a_offset,lda,x,_x_offset,work,_work_offset,info);
// *
// *+    TEST 8
// *                 Solve the system op(A)*x = b.
// *
lintest_srnamc.srnamt = "DLATRS";
Dcopy.dcopy(n,x,_x_offset,1,b,_b_offset,1);
Dlatrs.dlatrs(uplo,trans,diag.val,"N",n,a,_a_offset,lda,b,_b_offset,scale,rwork,_rwork_offset,info);
// *
// *                 Check error code from DLATRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATRS",info.val,0,uplo+trans+diag.val+"N",n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtrt03_adapter(uplo,trans,diag.val,n,1,a,_a_offset,lda,scale.val,rwork,_rwork_offset,one,b,_b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(8)- 1);
// *
// *+    TEST 9
// *                 Solve op(A)*X = b again with NORMIN = 'Y'.
// *
Dcopy.dcopy(n,x,_x_offset,1,b,(n+1)- 1+ _b_offset,1);
Dlatrs.dlatrs(uplo,trans,diag.val,"Y",n,a,_a_offset,lda,b,(n+1)- 1+ _b_offset,scale,rwork,_rwork_offset,info);
// *
// *                 Check error code from DLATRS.
// *
if (info.val != 0)  
    Alaerh.alaerh(path,"DLATRS",info.val,0,uplo+trans+diag.val+"Y",n,n,-1,-1,-1,imat,nfail,nerrs,nout);
// *
dtrt03_adapter(uplo,trans,diag.val,n,1,a,_a_offset,lda,scale.val,rwork,_rwork_offset,one,b,(n+1)- 1+ _b_offset,lda,x,_x_offset,lda,work,_work_offset,result,(9)- 1);
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
if (result[(8)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATRS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("N") + " "  + "\',"  + (n) + " "  + ", ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(8)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
if (result[(9)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" " + ("DLATRS") + " "  + "( \'"  + (uplo) + " "  + "\', \'"  + (trans) + " "  + "\', \'"  + (diag.val) + " "  + "\', \'"  + ("Y") + " "  + "\',"  + (n) + " "  + ", ... ), type "  + (imat) + " "  + ", ratio ="  + (result[(9)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+2;
Dummy.label("Dchktr",70);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",80);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",90);
}              //  Close for() loop. 
}
Dummy.label("Dchktr",100);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasum.alasum(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Dchktr",999999);
// *
// *     End of DCHKTR
// *
Dummy.label("Dchktr",999999);
return;
   }
// adapter for dtrt01
private static void dtrt01_adapter(String arg0 ,String arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,doubleW arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset )
{
doubleW _f2j_tmp9 = new doubleW(arg9[arg9_offset]);

Dtrt01.dtrt01(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7,arg8, arg8_offset,_f2j_tmp9);

arg9[arg9_offset] = _f2j_tmp9.val;
}

// adapter for dtrt02
private static void dtrt02_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,int arg8 ,double [] arg9 , int arg9_offset ,int arg10 ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dtrt02.dtrt02(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8,arg9, arg9_offset,arg10,arg11, arg11_offset,_f2j_tmp12);

arg12[arg12_offset] = _f2j_tmp12.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dtrt06
private static void dtrt06_adapter(double arg0 ,double arg1 ,String arg2 ,String arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset )
{
doubleW _f2j_tmp8 = new doubleW(arg8[arg8_offset]);

Dtrt06.dtrt06(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,_f2j_tmp8);

arg8[arg8_offset] = _f2j_tmp8.val;
}

// adapter for dtrt03
private static void dtrt03_adapter(String arg0 ,String arg1 ,String arg2 ,int arg3 ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double arg7 ,double [] arg8 , int arg8_offset ,double arg9 ,double [] arg10 , int arg10_offset ,int arg11 ,double [] arg12 , int arg12_offset ,int arg13 ,double [] arg14 , int arg14_offset ,double [] arg15 , int arg15_offset )
{
doubleW _f2j_tmp15 = new doubleW(arg15[arg15_offset]);

Dtrt03.dtrt03(arg0,arg1,arg2,arg3,arg4,arg5, arg5_offset,arg6,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,arg11,arg12, arg12_offset,arg13,arg14, arg14_offset,_f2j_tmp15);

arg15[arg15_offset] = _f2j_tmp15.val;
}

} // End class.
