/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Ddrvgt {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994 
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVGT tests DGTSV and -SVX.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix dimension N.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*4)
// *
// *  AF      (workspace) DOUBLE PRECISION array, dimension (NMAX*4)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  IWORK   (workspace) INTEGER array, dimension (2*NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 12;
static int ntests= 6;
// *     ..
// *     .. Local Scalars ..
static boolean trfcon= false;
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String fact= new String(" ");
static String trans= new String(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static int ifact= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int itran= 0;
static int ix= 0;
static int izero= 0;
static int j= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static int koff= 0;
static intW ku= new intW(0);
static int lda= 0;
static int m= 0;
static intW mode= new intW(0);
static int n= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static double anormi= 0.0;
static double anormo= 0.0;
static doubleW cond= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double rcondi= 0.0;
static double rcondo= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
static double [] z= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static String [] transs = {"N" 
, "T" , "C" };
static int [] iseedy = {0 
, 0 , 0 , 1 };
// *     ..
// *     .. Executable Statements ..
// *

public static void ddrvgt (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "GT".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Ddrvgt",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrvx.derrvx(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop140:
for (in = 1; in <= nn; in++) {
// *
// *        Do for each value of N in NVAL.
// *
n = nval[(in)- 1+ _nval_offset];
m = (int)(Math.max(n-1, 0) );
lda = (int)(Math.max(1, n) );
nimat = ntypes;
if (n <= 0)  
    nimat = 1;
// *
{
forloop130:
for (imat = 1; imat <= nimat; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop130;
// *
// *           Set up parameters with DLATB4.
// *
Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cond,dist);
// *
zerot = imat >= 8 && imat <= 10;
if (imat <= 6)  {
    // *
// *              Types 1-6:  generate matrices of known condition number.
// *
koff = (int)(Math.max(2-ku.val, 3-Math.max(1, n) ) );
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(n,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cond.val,anorm.val,kl.val,ku.val,"Z",af,(koff)- 1+ _af_offset,3,work,_work_offset,info);
// *
// *              Check the error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0," ",n,n,kl.val,ku.val,-1,imat,nfail,nerrs,nout);
continue forloop130;
}              // Close if()
izero = 0;
// *
if (n > 1)  {
    Dcopy.dcopy(n-1,af,(4)- 1+ _af_offset,3,a,_a_offset,1);
Dcopy.dcopy(n-1,af,(3)- 1+ _af_offset,3,a,(n+m+1)- 1+ _a_offset,1);
}              // Close if()
Dcopy.dcopy(n,af,(2)- 1+ _af_offset,3,a,(m+1)- 1+ _a_offset,1);
}              // Close if()
else  {
  // *
// *              Types 7-12:  generate tridiagonal matrices with
// *              unknown condition numbers.
// *
if (!zerot || !dotype[(7)- 1+ _dotype_offset])  {
    // *
// *                 Generate a matrix with elements from [-1,1].
// *
Dlarnv.dlarnv(2,iseed,0,n+2*m,a,_a_offset);
if (anorm.val != one)  
    Dscal.dscal(n+2*m,anorm.val,a,_a_offset,1);
}              // Close if()
else if (izero > 0)  {
    // *
// *                 Reuse the last matrix by copying back the zeroed out
// *                 elements.
// *
if (izero == 1)  {
    a[(n)- 1+ _a_offset] = z[(2)- 1];
if (n > 1)  
    a[(1)- 1+ _a_offset] = z[(3)- 1];
}              // Close if()
else if (izero == n)  {
    a[(3*n-2)- 1+ _a_offset] = z[(1)- 1];
a[(2*n-1)- 1+ _a_offset] = z[(2)- 1];
}              // Close else if()
else  {
  a[(2*n-2+izero)- 1+ _a_offset] = z[(1)- 1];
a[(n-1+izero)- 1+ _a_offset] = z[(2)- 1];
a[(izero)- 1+ _a_offset] = z[(3)- 1];
}              //  Close else.
}              // Close else if()
// *
// *              If IMAT > 7, set one column of the matrix to 0.
// *
if (!zerot)  {
    izero = 0;
}              // Close if()
else if (imat == 8)  {
    izero = 1;
z[(2)- 1] = a[(n)- 1+ _a_offset];
a[(n)- 1+ _a_offset] = zero;
if (n > 1)  {
    z[(3)- 1] = a[(1)- 1+ _a_offset];
a[(1)- 1+ _a_offset] = zero;
}              // Close if()
}              // Close else if()
else if (imat == 9)  {
    izero = n;
z[(1)- 1] = a[(3*n-2)- 1+ _a_offset];
z[(2)- 1] = a[(2*n-1)- 1+ _a_offset];
a[(3*n-2)- 1+ _a_offset] = zero;
a[(2*n-1)- 1+ _a_offset] = zero;
}              // Close else if()
else  {
  izero = (n+1)/2;
{
forloop20:
for (i = izero; i <= n-1; i++) {
a[(2*n-2+i)- 1+ _a_offset] = zero;
a[(n-1+i)- 1+ _a_offset] = zero;
a[(i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvgt",20);
}              //  Close for() loop. 
}
a[(3*n-2)- 1+ _a_offset] = zero;
a[(2*n-1)- 1+ _a_offset] = zero;
}              //  Close else.
}              //  Close else.
// *
{
forloop120:
for (ifact = 1; ifact <= 2; ifact++) {
if (ifact == 1)  {
    fact = "F";
}              // Close if()
else  {
  fact = "N";
}              //  Close else.
// *
// *              Compute the condition number for comparison with
// *              the value returned by DGTSVX.
// *
if (zerot)  {
    if (ifact == 1)  
    continue forloop120;
rcondo = zero;
rcondi = zero;
// *
}              // Close if()
else if (ifact == 1)  {
    Dcopy.dcopy(n+2*m,a,_a_offset,1,af,_af_offset,1);
// *
// *                 Compute the 1-norm and infinity-norm of A.
// *
anormo = Dlangt.dlangt("1",n,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset);
anormi = Dlangt.dlangt("I",n,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset);
// *
// *                 Factor the matrix A.
// *
Dgttrf.dgttrf(n,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,af,(n+2*m+1)- 1+ _af_offset,iwork,_iwork_offset,info);
// *
// *                 Use DGTTRS to solve for one column at a time of
// *                 inv(A), computing the maximum column sum as we go.
// *
ainvnm = zero;
{
forloop40:
for (i = 1; i <= n; i++) {
{
forloop30:
for (j = 1; j <= n; j++) {
x[(j)- 1+ _x_offset] = zero;
Dummy.label("Ddrvgt",30);
}              //  Close for() loop. 
}
x[(i)- 1+ _x_offset] = one;
Dgttrs.dgttrs("No transpose",n,1,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,af,(n+2*m+1)- 1+ _af_offset,iwork,_iwork_offset,x,_x_offset,lda,info);
ainvnm = Math.max(ainvnm, Dasum.dasum(n,x,_x_offset,1)) ;
Dummy.label("Ddrvgt",40);
}              //  Close for() loop. 
}
// *
// *                 Compute the 1-norm condition number of A.
// *
if (anormo <= zero || ainvnm <= zero)  {
    rcondo = one;
}              // Close if()
else  {
  rcondo = (one/anormo)/ainvnm;
}              //  Close else.
// *
// *                 Use DGTTRS to solve for one column at a time of
// *                 inv(A'), computing the maximum column sum as we go.
// *
ainvnm = zero;
{
forloop60:
for (i = 1; i <= n; i++) {
{
forloop50:
for (j = 1; j <= n; j++) {
x[(j)- 1+ _x_offset] = zero;
Dummy.label("Ddrvgt",50);
}              //  Close for() loop. 
}
x[(i)- 1+ _x_offset] = one;
Dgttrs.dgttrs("Transpose",n,1,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,af,(n+2*m+1)- 1+ _af_offset,iwork,_iwork_offset,x,_x_offset,lda,info);
ainvnm = Math.max(ainvnm, Dasum.dasum(n,x,_x_offset,1)) ;
Dummy.label("Ddrvgt",60);
}              //  Close for() loop. 
}
// *
// *                 Compute the infinity-norm condition number of A.
// *
if (anormi <= zero || ainvnm <= zero)  {
    rcondi = one;
}              // Close if()
else  {
  rcondi = (one/anormi)/ainvnm;
}              //  Close else.
}              // Close else if()
// *
{
forloop110:
for (itran = 1; itran <= 3; itran++) {
trans = transs[(itran)- 1];
if (itran == 1)  {
    rcondc = rcondo;
}              // Close if()
else  {
  rcondc = rcondi;
}              //  Close else.
// *
// *                 Generate NRHS random solution vectors.
// *
ix = 1;
{
forloop70:
for (j = 1; j <= nrhs; j++) {
Dlarnv.dlarnv(2,iseed,0,n,xact,(ix)- 1+ _xact_offset);
ix = ix+lda;
Dummy.label("Ddrvgt",70);
}              //  Close for() loop. 
}
// *
// *                 Set the right hand side.
// *
Dlagtm.dlagtm(trans,n,nrhs,one,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,xact,_xact_offset,lda,zero,b,_b_offset,lda);
// *
if (ifact == 2 && itran == 1)  {
    // *
// *                    --- Test DGTSV  ---
// *
// *                    Solve the system using Gaussian elimination with
// *                    partial pivoting.
// *
Dcopy.dcopy(n+2*m,a,_a_offset,1,af,_af_offset,1);
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DGTSV ";
Dgtsv.dgtsv(n,nrhs,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,x,_x_offset,lda,info);
// *
// *                    Check error code from DGTSV .
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DGTSV ",info.val,izero," ",n,n,1,1,nrhs,imat,nfail,nerrs,nout);
nt = 1;
if (izero == 0)  {
    // *
// *                       Check residual of computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dgtt02_adapter(trans,n,nrhs,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(2)- 1);
// *
// *                       Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
nt = 3;
}              // Close if()
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop80:
for (k = 2; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DGTSV ") + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio = "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvgt",80);
}              //  Close for() loop. 
}
nrun = nrun+nt-1;
}              // Close if()
// *
// *                 --- Test DGTSVX ---
// *
if (ifact > 1)  {
    // *
// *                    Initialize AF to zero.
// *
{
forloop90:
for (i = 1; i <= 3*n-2; i++) {
af[(i)- 1+ _af_offset] = zero;
Dummy.label("Ddrvgt",90);
}              //  Close for() loop. 
}
}              // Close if()
Dlaset.dlaset("Full",n,nrhs,zero,zero,x,_x_offset,lda);
// *
// *                 Solve the system and compute the condition number and
// *                 error bounds using DGTSVX.
// *
lintest_srnamc.srnamt = "DGTSVX";
Dgtsvx.dgtsvx(fact,trans,n,nrhs,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,af,(n+2*m+1)- 1+ _af_offset,iwork,_iwork_offset,b,_b_offset,lda,x,_x_offset,lda,rcond,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                 Check the error code from DGTSVX.
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DGTSVX",info.val,izero,fact+trans,n,n,1,1,nrhs,imat,nfail,nerrs,nout);
// *
if (ifact >= 2)  {
    // *
// *                    Reconstruct matrix from factors and compute
// *                    residual.
// *
dgtt01_adapter(n,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,af,_af_offset,af,(m+1)- 1+ _af_offset,af,(n+m+1)- 1+ _af_offset,af,(n+2*m+1)- 1+ _af_offset,iwork,_iwork_offset,work,_work_offset,lda,rwork,_rwork_offset,result,(1)- 1);
k1 = 1;
}              // Close if()
else  {
  k1 = 2;
}              //  Close else.
// *
if (info.val == 0)  {
    trfcon = false;
// *
// *                    Check residual of computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dgtt02_adapter(trans,n,nrhs,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(2)- 1);
// *
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *                    Check the error bounds from iterative refinement.
// *
Dgtt05.dgtt05(trans,n,nrhs,a,_a_offset,a,(m+1)- 1+ _a_offset,a,(n+m+1)- 1+ _a_offset,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(4)- 1);
nt = 5;
}              // Close if()
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
{
forloop100:
for (k = k1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DGTSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', TRANS=\'"  + (trans) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio = "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvgt",100);
}              //  Close for() loop. 
}
// *
// *                 Check the reciprocal of the condition number.
// *
result[(6)- 1] = Dget06.dget06(rcond.val,rcondc);
if (result[(6)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DGTSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', TRANS=\'"  + (trans) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio = "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
nrun = nrun+nt-k1+2;
// *
Dummy.label("Ddrvgt",110);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgt",120);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgt",130);
}              //  Close for() loop. 
}
Dummy.label("Ddrvgt",140);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasvm.alasvm(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Ddrvgt",999999);
// *
// *     End of DDRVGT
// *
Dummy.label("Ddrvgt",999999);
return;
   }
// adapter for dgtt02
private static void dgtt02_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dgtt02.dgtt02(arg0,arg1,arg2,arg3, arg3_offset,arg4, arg4_offset,arg5, arg5_offset,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dgtt01
private static void dgtt01_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset ,int [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset ,int arg10 ,double [] arg11 , int arg11_offset ,double [] arg12 , int arg12_offset )
{
doubleW _f2j_tmp12 = new doubleW(arg12[arg12_offset]);

Dgtt01.dgtt01(arg0,arg1, arg1_offset,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5, arg5_offset,arg6, arg6_offset,arg7, arg7_offset,arg8, arg8_offset,arg9, arg9_offset,arg10,arg11, arg11_offset,_f2j_tmp12);

arg12[arg12_offset] = _f2j_tmp12.val;
}

} // End class.
