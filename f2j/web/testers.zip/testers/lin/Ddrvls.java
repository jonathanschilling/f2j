/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Ddrvls {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVLS tests the least squares driver routines DGELS, SGELSX, and
// *  DGELSS.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NM      (input) INTEGER
// *          The number of values of M contained in the vector MVAL.
// *
// *  MVAL    (input) INTEGER array, dimension (NM)
// *          The values of the matrix row dimension M.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix column dimension N.
// *
// *  NNB     (input) INTEGER
// *          The number of values of NB and NX contained in the
// *          vectors NBVAL and NXVAL.  The blocking parameters are used
// *          in pairs (NB,NX).
// *
// *  NBVAL   (input) INTEGER array, dimension (NNB)
// *          The values of the blocksize NB.
// *
// *  NXVAL   (input) INTEGER array, dimension (NNB)
// *          The values of the crossover point NX.
// *
// *  NNS     (input) INTEGER
// *          The number of values of NRHS contained in the vector NSVAL.
// *
// *  NSVAL   (input) INTEGER array, dimension (NNS)
// *          The values of the number of right hand sides NRHS.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *          where MMAX is the maximum value of M in MVAL and NMAX is the
// *          maximum value of N in NVAL.
// *
// *  COPYA   (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *          where MMAX is the maximum value of M in MVAL and NMAX is the
// *          maximum value of N in NVAL.
// *
// *  COPYB   (workspace) DOUBLE PRECISION array, dimension (MMAX*NMAX)
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension
// *                      (min(MMAX,NMAX))
// *
// *  COPYS   (workspace) DOUBLE PRECISION array, dimension
// *                      (min(MMAX,NMAX))
// *
// *  TAU     (workspace) DOUBLE PRECISION array, dimension (MMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (MMAX*NMAX + 4*NMAX + MMAX)
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int ntests= 10;
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static String trans= new String(" ");
static String path= new String("   ");
static intW crank= new intW(0);
static int i= 0;
static int im= 0;
static int in= 0;
static int inb= 0;
static intW info= new intW(0);
static int ins= 0;
static int irank= 0;
static int iscale= 0;
static int itran= 0;
static int itype= 0;
static int j= 0;
static int k= 0;
static int lda= 0;
static int ldb= 0;
static int ldwork= 0;
static int lw= 0;
static int lwork= 0;
static int m= 0;
static int mnmin= 0;
static int n= 0;
static int nb= 0;
static int ncols= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nrhs= 0;
static int nrows= 0;
static int nrun= 0;
static intW rank= new intW(0);
static double eps= 0.0;
static doubleW norma= new doubleW(0.0);
static doubleW normb= new doubleW(0.0);
static double rcond= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void ddrvls (boolean [] dotype, int _dotype_offset,
int nm,
int [] mval, int _mval_offset,
int nn,
int [] nval, int _nval_offset,
int nns,
int [] nsval, int _nsval_offset,
int nnb,
int [] nbval, int _nbval_offset,
int [] nxval, int _nxval_offset,
double thresh,
boolean tsterr,
double [] a, int _a_offset,
double [] copya, int _copya_offset,
double [] b, int _b_offset,
double [] copyb, int _copyb_offset,
double [] s, int _s_offset,
double [] copys, int _copys_offset,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "LS".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Ddrvls",10);
}              //  Close for() loop. 
}
eps = Dlamch.dlamch("Epsilon");
// *
// *     Threshold for rank estimation
// *
rcond = Math.sqrt(eps)-(Math.sqrt(eps)-eps)/2;
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrls.derrls(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop130:
for (im = 1; im <= nm; im++) {
m = mval[(im)- 1+ _mval_offset];
lda = (int)(Math.max(1, m) );
// *
{
forloop120:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
mnmin = (int)(Math.min(m, n) );
ldb = (int)(Math.max((1) > (m) ? (1) : (m), n));
// *
{
forloop110:
for (ins = 1; ins <= nns; ins++) {
nrhs = nsval[(ins)- 1+ _nsval_offset];
lwork = (int)(Math.max(Math.max(Math.max(Math.max(1, (m+nrhs)*(n+2)), m*n+4*mnmin+Math.max(m, n) ), 2*n+m), 5*mnmin-1) );
// *
{
forloop100:
for (irank = 1; irank <= 2; irank++) {
{
forloop90:
for (iscale = 1; iscale <= 3; iscale++) {
itype = (irank-1)*3+iscale;
if (!dotype[(itype)- 1+ _dotype_offset])  
    continue forloop90;
// *
if (irank == 1)  {
    // *
// *                       Test DGELS
// *
// *                       Generate a matrix of scaling type ISCALE
// *
Dqrt13.dqrt13(iscale,m,n,copya,_copya_offset,lda,norma,iseed,0);
{
forloop50:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
Xlaenv.xlaenv(3,nxval[(inb)- 1+ _nxval_offset]);
// *
{
forloop40:
for (itran = 1; itran <= 2; itran++) {
if (itran == 1)  {
    trans = "N";
nrows = m;
ncols = n;
}              // Close if()
else  {
  trans = "T";
nrows = n;
ncols = m;
}              //  Close else.
lw = (int)(Math.max((1) > ((nrows+nrhs)*(ncols+2)) ? (1) : ((nrows+nrhs)*(ncols+2)), mnmin+Math.max((m) > (n) ? (m) : (n), nrhs)*Math.max(1, nb) ));
ldwork = (int)(Math.max(1, ncols) );
// *
// *                             Set up a consistent rhs
// *
if (ncols > 0)  {
    Dlarnv.dlarnv(2,iseed,0,ncols*nrhs,work,_work_offset);
{
forloop20:
for (j = 1; j <= nrhs; j++) {
Dscal.dscal(ncols,one/Dnrm2.dnrm2(ncols,work,((j-1)*ncols+1)- 1+ _work_offset,1),work,((j-1)*ncols+1)- 1+ _work_offset,1);
Dummy.label("Ddrvls",20);
}              //  Close for() loop. 
}
}              // Close if()
Dgemm.dgemm(trans,"No transpose",nrows,nrhs,ncols,one,copya,_copya_offset,lda,work,_work_offset,ldwork,zero,b,_b_offset,ldb);
Dlacpy.dlacpy("Full",nrows,nrhs,b,_b_offset,ldb,copyb,_copyb_offset,ldb);
// *
// *                             Solve LS or overdetermined system
// *
if (m > 0 && n > 0)  {
    Dlacpy.dlacpy("Full",m,n,copya,_copya_offset,lda,a,_a_offset,lda);
Dlacpy.dlacpy("Full",nrows,nrhs,copyb,_copyb_offset,ldb,b,_b_offset,ldb);
}              // Close if()
lintest_srnamc.srnamt = "DGELS ";
Dgels.dgels(trans,m,n,nrhs,a,_a_offset,lda,b,_b_offset,ldb,work,_work_offset,lw,info);
if (info.val != 0)  
    Alaerh.alaerh(path,"DGELS ",info.val,0,trans,m,n,nrhs,-1,nb,itype,nfail,nerrs,nout);
// *
// *                             Check correctness of results
// *
ldwork = (int)(Math.max(1, nrows) );
if (nrows > 0 && nrhs > 0)  
    Dlacpy.dlacpy("Full",nrows,nrhs,copyb,_copyb_offset,ldb,work,_work_offset,ldwork);
dqrt16_adapter(trans,m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,ldwork,work,(nrows*nrhs+1)- 1+ _work_offset,result,(1)- 1);
// *
if ((itran == 1 && m >= n) || (itran == 2 && m < n))  {
    // *
// *                                Solving LS system
// *
result[(2)- 1] = Dqrt17.dqrt17(trans,1,m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,copyb,_copyb_offset,ldb,work,_work_offset,lw);
}              // Close if()
else  {
  // *
// *                                Solving overdetermined system
// *
result[(2)- 1] = Dqrt14.dqrt14(trans,m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,lw);
}              //  Close else.
// *
// *                             Print information about the tests that
// *                             did not pass the threshold.
// *
{
forloop30:
for (k = 1; k <= 2; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" TRANS=\'"  + (trans) + " "  + "\', M="  + (m) + " "  + ", N="  + (n) + " "  + ", NRHS="  + (nrhs) + " "  + ", NB="  + (nb) + " "  + ", type"  + (itype) + " "  + ", test("  + (k) + " "  + ")="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvls",30);
}              //  Close for() loop. 
}
nrun = nrun+2;
Dummy.label("Ddrvls",40);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *                    Generate a matrix of scaling type ISCALE and rank
// *                    type IRANK.
// *
Dqrt15.dqrt15(iscale,irank,m,n,nrhs,copya,_copya_offset,lda,copyb,_copyb_offset,ldb,copys,_copys_offset,rank,norma,normb,iseed,0,work,_work_offset,lwork);
// *
// *                    workspace used: MAX(M+MIN(M,N),NRHS*MIN(M,N),2*N+M)
// *
{
forloop60:
for (j = 1; j <= n; j++) {
iwork[(j)- 1+ _iwork_offset] = 0;
Dummy.label("Ddrvls",60);
}              //  Close for() loop. 
}
ldwork = (int)(Math.max(1, m) );
// *
{
forloop80:
for (inb = 1; inb <= nnb; inb++) {
nb = nbval[(inb)- 1+ _nbval_offset];
Xlaenv.xlaenv(1,nb);
Xlaenv.xlaenv(3,nxval[(inb)- 1+ _nxval_offset]);
// *
Dlacpy.dlacpy("Full",m,n,copya,_copya_offset,lda,a,_a_offset,lda);
Dlacpy.dlacpy("Full",m,nrhs,copyb,_copyb_offset,ldb,b,_b_offset,ldb);
// *
// *                       DGELSX:  Compute the minimum-norm solution X to
// *                          min( norm( A * X - B ) )
// *                       using a complete orthogonal factorization.
// *
lintest_srnamc.srnamt = "DGELSX";
Dgelsx.dgelsx(m,n,nrhs,a,_a_offset,lda,b,_b_offset,ldb,iwork,_iwork_offset,rcond,crank,work,_work_offset,info);
if (info.val != 0)  
    Alaerh.alaerh(path,"DGELSX",info.val,0," ",m,n,nrhs,-1,nb,itype,nfail,nerrs,nout);
// *
// *                       workspace used: MAX( MNMIN+3*N, 2*MNMIN+NRHS )
// *
// *                       Test 3:  Compute relative error in svd
// *                                workspace: M*N + 4*MIN(M,N) + MAX(M,N)
// *
result[(3)- 1] = Dqrt12.dqrt12(crank.val,crank.val,a,_a_offset,lda,copys,_copys_offset,work,_work_offset,lwork);
// *
// *                       Test 4:  Compute error in solution
// *                                workspace:  M*NRHS + M
// *
Dlacpy.dlacpy("Full",m,nrhs,copyb,_copyb_offset,ldb,work,_work_offset,ldwork);
dqrt16_adapter("No transpose",m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,ldwork,work,(m*nrhs+1)- 1+ _work_offset,result,(4)- 1);
// *
// *                       Test 5:  Check norm of r'*A
// *                                workspace: NRHS*(M+N)
// *
result[(5)- 1] = zero;
if (m > crank.val)  
    result[(5)- 1] = Dqrt17.dqrt17("No transpose",1,m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,copyb,_copyb_offset,ldb,work,_work_offset,lwork);
// *
// *                       Test 6:  Check if x is in the rowspace of A
// *                                workspace: (M+NRHS)*(N+2)
// *
result[(6)- 1] = zero;
// *
if (n > crank.val)  
    result[(6)- 1] = Dqrt14.dqrt14("No transpose",m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,lwork);
// *
// *                       DGELSS:  Compute the minimum-norm solution X to
// *                          min( norm( A * X - B ) )
// *                       using the SVD.
// *
Dlacpy.dlacpy("Full",m,n,copya,_copya_offset,lda,a,_a_offset,lda);
Dlacpy.dlacpy("Full",m,nrhs,copyb,_copyb_offset,ldb,b,_b_offset,ldb);
lintest_srnamc.srnamt = "DGELSS";
Dgelss.dgelss(m,n,nrhs,a,_a_offset,lda,b,_b_offset,ldb,s,_s_offset,rcond,crank,work,_work_offset,lwork,info);
if (info.val != 0)  
    Alaerh.alaerh(path,"DGELSS",info.val,0," ",m,n,nrhs,-1,nb,itype,nfail,nerrs,nout);
// *
// *                       workspace used: 3*min(m,n) +
// *                                       max(2*min(m,n),nrhs,max(m,n))
// *
// *                       Test 7:  Compute relative error in svd
// *
if (rank.val > 0)  {
    Daxpy.daxpy(mnmin,-one,copys,_copys_offset,1,s,_s_offset,1);
result[(7)- 1] = Dasum.dasum(mnmin,s,_s_offset,1)/Dasum.dasum(mnmin,copys,_copys_offset,1)/(eps*(double)(mnmin));
}              // Close if()
else  {
  result[(7)- 1] = zero;
}              //  Close else.
// *
// *                       Test 8:  Compute error in solution
// *
Dlacpy.dlacpy("Full",m,nrhs,copyb,_copyb_offset,ldb,work,_work_offset,ldwork);
dqrt16_adapter("No transpose",m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,ldwork,work,(m*nrhs+1)- 1+ _work_offset,result,(8)- 1);
// *
// *                       Test 9:  Check norm of r'*A
// *
result[(9)- 1] = zero;
if (m > crank.val)  
    result[(9)- 1] = Dqrt17.dqrt17("No transpose",1,m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,copyb,_copyb_offset,ldb,work,_work_offset,lwork);
// *
// *                       Test 10:  Check if x is in the rowspace of A
// *
result[(10)- 1] = zero;
if (n > crank.val)  
    result[(10)- 1] = Dqrt14.dqrt14("No transpose",m,n,nrhs,copya,_copya_offset,lda,b,_b_offset,ldb,work,_work_offset,lwork);
// *
// *                       Print information about the tests that did not
// *                       pass the threshold.
// *
{
forloop70:
for (k = 3; k <= 10; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Alahd.alahd(nout,path);
System.out.println(" M="  + (m) + " "  + ", N="  + (n) + " "  + ", NRHS="  + (nrhs) + " "  + ", NB="  + (nb) + " "  + ", type"  + (itype) + " "  + ", test("  + (k) + " "  + ")="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvls",70);
}              //  Close for() loop. 
}
nrun = nrun+8;
// *
Dummy.label("Ddrvls",80);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",90);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",110);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",120);
}              //  Close for() loop. 
}
Dummy.label("Ddrvls",130);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasvm.alasvm(path,nout,nfail,nrun,nerrs.val);
// *
// *
// *     End of DDRVLS
// *
Dummy.label("Ddrvls",999999);
return;
   }
// adapter for dqrt16
private static void dqrt16_adapter(String arg0 ,int arg1 ,int arg2 ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,int arg9 ,double [] arg10 , int arg10_offset ,double [] arg11 , int arg11_offset )
{
doubleW _f2j_tmp11 = new doubleW(arg11[arg11_offset]);

Dqrt16.dqrt16(arg0,arg1,arg2,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,arg9,arg10, arg10_offset,_f2j_tmp11);

arg11[arg11_offset] = _f2j_tmp11.val;
}

} // End class.
