/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Ddrvpo {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVPO tests the driver routines DPOSV and -SVX.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix dimension N.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for N, used in dimensioning the
// *          work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  AFAC    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  ASAV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NMAX)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  BSAV    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  S       (workspace) DOUBLE PRECISION array, dimension (NMAX)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (NMAX+2*NRHS)
// *
// *  IWORK   (workspace) INTEGER array, dimension (NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 9;
static int ntests= 6;
// *     ..
// *     .. Local Scalars ..
static boolean equil= false;
static boolean nofact= false;
static boolean prefac= false;
static boolean zerot= false;
static StringW dist= new StringW(" ");
static StringW equed= new StringW(" ");
static String fact= new String(" ");
static StringW type= new StringW(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int iequed= 0;
static int ifact= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int ioff= 0;
static int iuplo= 0;
static int izero= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lda= 0;
static intW mode= new intW(0);
static int n= 0;
static int nb= 0;
static int nbmin= 0;
static intW nerrs= new intW(0);
static int nfact= 0;
static int nfail= 0;
static int nimat= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW amax= new doubleW(0.0);
static doubleW anorm= new doubleW(0.0);
static doubleW cndnum= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
static double roldc= 0.0;
static doubleW scond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
static String [] uplos = {"U" 
, "L" };
static String [] facts = {"F" 
, "N" , "E" };
static String [] equeds = {"N" 
, "Y" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void ddrvpo (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
double [] asav, int _asav_offset,
double [] b, int _b_offset,
double [] bsav, int _bsav_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] s, int _s_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "PO".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Ddrvpo",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrvx.derrvx(path,nout);
lintest_infoc.infot = 0;
// *
// *     Set the block size and minimum block size for testing.
// *
nb = 1;
nbmin = 2;
Xlaenv.xlaenv(1,nb);
Xlaenv.xlaenv(2,nbmin);
// *
// *     Do for each value of N in NVAL
// *
{
forloop140:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(n, 1) );
xtype = "N";
nimat = ntypes;
if (n <= 0)  
    nimat = 1;
// *
{
forloop130:
for (imat = 1; imat <= nimat; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop130;
// *
// *           Skip types 3, 4, or 5 if the matrix size is too small.
// *
zerot = imat >= 3 && imat <= 5;
if (zerot && n < imat-2)  
    continue forloop130;
// *
// *           Do first for UPLO = 'U', then for UPLO = 'L'
// *
{
forloop120:
for (iuplo = 1; iuplo <= 2; iuplo++) {
uplo = uplos[(iuplo)- 1];
// *
// *              Set up parameters with DLATB4 and generate a test matrix
// *              with DLATMS.
// *
Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(n,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,uplo,a,_a_offset,lda,work,_work_offset,info);
// *
// *              Check error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0,uplo,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
continue forloop120;
}              // Close if()
// *
// *              For types 3-5, zero one row and column of the matrix to
// *              test that INFO is returned correctly.
// *
if (zerot)  {
    if (imat == 3)  {
    izero = 1;
}              // Close if()
else if (imat == 4)  {
    izero = n;
}              // Close else if()
else  {
  izero = n/2+1;
}              //  Close else.
ioff = (izero-1)*lda;
// *
// *                 Set row and column IZERO of A to 0.
// *
if (iuplo == 1)  {
    {
forloop20:
for (i = 1; i <= izero-1; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvpo",20);
}              //  Close for() loop. 
}
ioff = ioff+izero;
{
forloop30:
for (i = izero; i <= n; i++) {
a[(ioff)- 1+ _a_offset] = zero;
ioff = ioff+lda;
Dummy.label("Ddrvpo",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  ioff = izero;
{
forloop40:
for (i = 1; i <= izero-1; i++) {
a[(ioff)- 1+ _a_offset] = zero;
ioff = ioff+lda;
Dummy.label("Ddrvpo",40);
}              //  Close for() loop. 
}
ioff = ioff-izero;
{
forloop50:
for (i = izero; i <= n; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvpo",50);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  izero = 0;
}              //  Close else.
// *
// *              Save a copy of the matrix A in ASAV.
// *
Dlacpy.dlacpy(uplo,n,n,a,_a_offset,lda,asav,_asav_offset,lda);
// *
{
forloop110:
for (iequed = 1; iequed <= 2; iequed++) {
equed.val = equeds[(iequed)- 1];
if (iequed == 1)  {
    nfact = 3;
}              // Close if()
else  {
  nfact = 1;
}              //  Close else.
// *
{
forloop100:
for (ifact = 1; ifact <= nfact; ifact++) {
fact = facts[(ifact)- 1];
prefac = (fact.toLowerCase().charAt(0) == "F".toLowerCase().charAt(0));
nofact = (fact.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
equil = (fact.toLowerCase().charAt(0) == "E".toLowerCase().charAt(0));
// *
if (zerot)  {
    if (prefac)  
    continue forloop100;
rcondc = zero;
// *
}              // Close if()
else if (!(fact.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    // *
// *                       Compute the condition number for comparison with
// *                       the value returned by DPOSVX (FACT = 'N' reuses
// *                       the condition number from the previous iteration
// *                       with FACT = 'F').
// *
Dlacpy.dlacpy(uplo,n,n,asav,_asav_offset,lda,afac,_afac_offset,lda);
if (equil || iequed > 1)  {
    // *
// *                          Compute row and column scale factors to
// *                          equilibrate the matrix A.
// *
Dpoequ.dpoequ(n,afac,_afac_offset,lda,s,_s_offset,scond,amax,info);
if (info.val == 0 && n > 0)  {
    if (iequed > 1)  
    scond.val = zero;
// *
// *                             Equilibrate the matrix.
// *
Dlaqsy.dlaqsy(uplo,n,afac,_afac_offset,lda,s,_s_offset,scond.val,amax.val,equed);
}              // Close if()
}              // Close if()
// *
// *                       Save the condition number of the
// *                       non-equilibrated system for use in DGET04.
// *
if (equil)  
    roldc = rcondc;
// *
// *                       Compute the 1-norm of A.
// *
anorm.val = Dlansy.dlansy("1",uplo,n,afac,_afac_offset,lda,rwork,_rwork_offset);
// *
// *                       Factor the matrix A.
// *
Dpotrf.dpotrf(uplo,n,afac,_afac_offset,lda,info);
// *
// *                       Form the inverse of A.
// *
Dlacpy.dlacpy(uplo,n,n,afac,_afac_offset,lda,a,_a_offset,lda);
Dpotri.dpotri(uplo,n,a,_a_offset,lda,info);
// *
// *                       Compute the 1-norm condition number of A.
// *
ainvnm = Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,rwork,_rwork_offset);
if (anorm.val <= zero || ainvnm <= zero)  {
    rcondc = one;
}              // Close if()
else  {
  rcondc = (one/anorm.val)/ainvnm;
}              //  Close else.
}              // Close else if()
label60:
   Dummy.label("Ddrvpo",60);
// *
// *                    Restore the matrix A.
// *
Dlacpy.dlacpy(uplo,n,n,asav,_asav_offset,lda,a,_a_offset,lda);
// *
// *                    Form an exact solution and set the right hand side.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo," ",n,n,kl.val,ku.val,nrhs,a,_a_offset,lda,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,bsav,_bsav_offset,lda);
// *
if (nofact)  {
    // *
// *                       --- Test DPOSV  ---
// *
// *                       Compute the L*L' or U'*U factorization of the
// *                       matrix and solve the system.
// *
Dlacpy.dlacpy(uplo,n,n,a,_a_offset,lda,afac,_afac_offset,lda);
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
lintest_srnamc.srnamt = "DPOSV ";
Dposv.dposv(uplo,n,nrhs,afac,_afac_offset,lda,x,_x_offset,lda,info);
// *
// *                       Check error code from DPOSV .
// *
if (info.val != izero)  {
    Alaerh.alaerh(path,"DPOSV ",info.val,izero,uplo,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
Dummy.go_to("Ddrvpo",80);
}              // Close if()
else if (info.val != 0)  {
    Dummy.go_to("Ddrvpo",80);
}              // Close else if()
// *
// *                       Reconstruct matrix from factors and compute
// *                       residual.
// *
dpot01_adapter(uplo,n,a,_a_offset,lda,afac,_afac_offset,lda,rwork,_rwork_offset,result,(1)- 1);
// *
// *                       Compute residual of the computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dpot02_adapter(uplo,n,nrhs,a,_a_offset,lda,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(2)- 1);
// *
// *                       Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
nt = 3;
// *
// *                       Print information about the tests that did not
// *                       pass the threshold.
// *
{
forloop70:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DPOSV ") + " "  + ", UPLO=\'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test("  + (k) + " "  + ")="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvpo",70);
}              //  Close for() loop. 
}
nrun = nrun+nt;
label80:
   Dummy.label("Ddrvpo",80);
}              // Close if()
// *
// *                    --- Test DPOSVX ---
// *
if (!prefac)  
    Dlaset.dlaset(uplo,n,n,zero,zero,afac,_afac_offset,lda);
Dlaset.dlaset("Full",n,nrhs,zero,zero,x,_x_offset,lda);
if (iequed > 1 && n > 0)  {
    // *
// *                       Equilibrate the matrix if FACT='F' and
// *                       EQUED='Y'.
// *
Dlaqsy.dlaqsy(uplo,n,a,_a_offset,lda,s,_s_offset,scond.val,amax.val,equed);
}              // Close if()
// *
// *                    Solve the system and compute the condition number
// *                    and error bounds using DPOSVX.
// *
lintest_srnamc.srnamt = "DPOSVX";
Dposvx.dposvx(fact,uplo,n,nrhs,a,_a_offset,lda,afac,_afac_offset,lda,equed,s,_s_offset,b,_b_offset,lda,x,_x_offset,lda,rcond,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,_iwork_offset,info);
// *
// *                    Check the error code from DPOSVX.
// *
if (info.val != izero)  {
    Alaerh.alaerh(path,"DPOSVX",info.val,izero,fact+uplo,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
continue forloop100;
}              // Close if()
// *
if (info.val == 0)  {
    if (!prefac)  {
    // *
// *                          Reconstruct matrix from factors and compute
// *                          residual.
// *
dpot01_adapter(uplo,n,a,_a_offset,lda,afac,_afac_offset,lda,rwork,(2*nrhs+1)- 1+ _rwork_offset,result,(1)- 1);
k1 = 1;
}              // Close if()
else  {
  k1 = 2;
}              //  Close else.
// *
// *                       Compute residual of the computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,bsav,_bsav_offset,lda,work,_work_offset,lda);
dpot02_adapter(uplo,n,nrhs,asav,_asav_offset,lda,x,_x_offset,lda,work,_work_offset,lda,rwork,(2*nrhs+1)- 1+ _rwork_offset,result,(2)- 1);
// *
// *                       Check solution from generated exact solution.
// *
if (nofact || (prefac && (equed.val.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
}              // Close if()
else  {
  dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,roldc,result,(3)- 1);
}              //  Close else.
// *
// *                       Check the error bounds from iterative
// *                       refinement.
// *
Dpot05.dpot05(uplo,n,nrhs,asav,_asav_offset,lda,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(4)- 1);
}              // Close if()
else  {
  k1 = 6;
}              //  Close else.
// *
// *                    Compare RCOND from DPOSVX with the computed value
// *                    in RCONDC.
// *
result[(6)- 1] = Dget06.dget06(rcond.val,rcondc);
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop90:
for (k = k1; k <= 6; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
if (prefac)  {
    System.out.println(" " + ("DPOSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', UPLO=\'"  + (uplo) + " "  + "\', N="  + (n) + " "  + ", EQUED=\'"  + (equed.val) + " "  + "\', type "  + (imat) + " "  + ", test("  + (k) + " "  + ") ="  + (result[(k)- 1]) + " " );
}              // Close if()
else  {
  System.out.println(" " + ("DPOSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', UPLO=\'"  + (uplo) + " "  + "\', N="  + (n) + " "  + ", type "  + (imat) + " "  + ", test("  + (k) + " "  + ")="  + (result[(k)- 1]) + " " );
}              //  Close else.
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvpo",90);
}              //  Close for() loop. 
}
nrun = nrun+7-k1;
Dummy.label("Ddrvpo",100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpo",110);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpo",120);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpo",130);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpo",140);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasvm.alasvm(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Ddrvpo",999999);
// *
// *     End of DDRVPO
// *
Dummy.label("Ddrvpo",999999);
return;
   }
// adapter for dpot01
private static void dpot01_adapter(String arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dpot01.dpot01(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6, arg6_offset,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

// adapter for dpot02
private static void dpot02_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,int arg4 ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,int arg8 ,double [] arg9 , int arg9_offset ,double [] arg10 , int arg10_offset )
{
doubleW _f2j_tmp10 = new doubleW(arg10[arg10_offset]);

Dpot02.dpot02(arg0,arg1,arg2,arg3, arg3_offset,arg4,arg5, arg5_offset,arg6,arg7, arg7_offset,arg8,arg9, arg9_offset,_f2j_tmp10);

arg10[arg10_offset] = _f2j_tmp10.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
