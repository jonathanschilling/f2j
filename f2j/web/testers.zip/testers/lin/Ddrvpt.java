/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Ddrvpt {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVPT tests DPTSV and -SVX.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix dimension N.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension (NMAX*2)
// *
// *  D       (workspace) DOUBLE PRECISION array, dimension (NMAX*2)
// *
// *  E       (workspace) DOUBLE PRECISION array, dimension (NMAX*2)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(3,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension
// *                      (max(NMAX,2*NRHS))
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 12;
static int ntests= 6;
// *     ..
// *     .. Local Scalars ..
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String fact= new String(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static int ia= 0;
static int ifact= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int ix= 0;
static int izero= 0;
static int j= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lda= 0;
static intW mode= new intW(0);
static int n= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static doubleW cond= new doubleW(0.0);
static double dmax= 0.0;
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
static double [] z= new double[(3)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {0 
, 0 , 0 , 1 };
// *     ..
// *     .. Executable Statements ..
// *

public static void ddrvpt (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
double [] a, int _a_offset,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "PT".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Ddrvpt",10);
}              //  Close for() loop. 
}
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrvx.derrvx(path,nout);
lintest_infoc.infot = 0;
// *
{
forloop120:
for (in = 1; in <= nn; in++) {
// *
// *        Do for each value of N in NVAL.
// *
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(1, n) );
nimat = ntypes;
if (n <= 0)  
    nimat = 1;
// *
{
forloop110:
for (imat = 1; imat <= nimat; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (n > 0 && !dotype[(imat)- 1+ _dotype_offset])  
    continue forloop110;
// *
// *           Set up parameters with DLATB4.
// *
Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cond,dist);
// *
zerot = imat >= 8 && imat <= 10;
if (imat <= 6)  {
    // *
// *              Type 1-6:  generate a symmetric tridiagonal matrix of
// *              known condition number in lower triangular band storage.
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(n,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cond.val,anorm.val,kl.val,ku.val,"B",a,_a_offset,2,work,_work_offset,info);
// *
// *              Check the error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0," ",n,n,kl.val,ku.val,-1,imat,nfail,nerrs,nout);
continue forloop110;
}              // Close if()
izero = 0;
// *
// *              Copy the matrix to D and E.
// *
ia = 1;
{
forloop20:
for (i = 1; i <= n-1; i++) {
d[(i)- 1+ _d_offset] = a[(ia)- 1+ _a_offset];
e[(i)- 1+ _e_offset] = a[(ia+1)- 1+ _a_offset];
ia = ia+2;
Dummy.label("Ddrvpt",20);
}              //  Close for() loop. 
}
if (n > 0)  
    d[(n)- 1+ _d_offset] = a[(ia)- 1+ _a_offset];
}              // Close if()
else  {
  // *
// *              Type 7-12:  generate a diagonally dominant matrix with
// *              unknown condition number in the vectors D and E.
// *
if (!zerot || !dotype[(7)- 1+ _dotype_offset])  {
    // *
// *                 Let D and E have values from [-1,1].
// *
Dlarnv.dlarnv(2,iseed,0,n,d,_d_offset);
Dlarnv.dlarnv(2,iseed,0,n-1,e,_e_offset);
// *
// *                 Make the tridiagonal matrix diagonally dominant.
// *
if (n == 1)  {
    d[(1)- 1+ _d_offset] = Math.abs(d[(1)- 1+ _d_offset]);
}              // Close if()
else  {
  d[(1)- 1+ _d_offset] = Math.abs(d[(1)- 1+ _d_offset])+Math.abs(e[(1)- 1+ _e_offset]);
d[(n)- 1+ _d_offset] = Math.abs(d[(n)- 1+ _d_offset])+Math.abs(e[(n-1)- 1+ _e_offset]);
{
forloop30:
for (i = 2; i <= n-1; i++) {
d[(i)- 1+ _d_offset] = Math.abs(d[(i)- 1+ _d_offset])+Math.abs(e[(i)- 1+ _e_offset])+Math.abs(e[(i-1)- 1+ _e_offset]);
Dummy.label("Ddrvpt",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *                 Scale D and E so the maximum element is ANORM.
// *
ix = Idamax.idamax(n,d,_d_offset,1);
dmax = d[(ix)- 1+ _d_offset];
Dscal.dscal(n,anorm.val/dmax,d,_d_offset,1);
if (n > 1)  
    Dscal.dscal(n-1,anorm.val/dmax,e,_e_offset,1);
// *
}              // Close if()
else if (izero > 0)  {
    // *
// *                 Reuse the last matrix by copying back the zeroed out
// *                 elements.
// *
if (izero == 1)  {
    d[(1)- 1+ _d_offset] = z[(2)- 1];
if (n > 1)  
    e[(1)- 1+ _e_offset] = z[(3)- 1];
}              // Close if()
else if (izero == n)  {
    e[(n-1)- 1+ _e_offset] = z[(1)- 1];
d[(n)- 1+ _d_offset] = z[(2)- 1];
}              // Close else if()
else  {
  e[(izero-1)- 1+ _e_offset] = z[(1)- 1];
d[(izero)- 1+ _d_offset] = z[(2)- 1];
e[(izero)- 1+ _e_offset] = z[(3)- 1];
}              //  Close else.
}              // Close else if()
// *
// *              For types 8-10, set one row and column of the matrix to
// *              zero.
// *
izero = 0;
if (imat == 8)  {
    izero = 1;
z[(2)- 1] = d[(1)- 1+ _d_offset];
d[(1)- 1+ _d_offset] = zero;
if (n > 1)  {
    z[(3)- 1] = e[(1)- 1+ _e_offset];
e[(1)- 1+ _e_offset] = zero;
}              // Close if()
}              // Close if()
else if (imat == 9)  {
    izero = n;
if (n > 1)  {
    z[(1)- 1] = e[(n-1)- 1+ _e_offset];
e[(n-1)- 1+ _e_offset] = zero;
}              // Close if()
z[(2)- 1] = d[(n)- 1+ _d_offset];
d[(n)- 1+ _d_offset] = zero;
}              // Close else if()
else if (imat == 10)  {
    izero = (n+1)/2;
if (izero > 1)  {
    z[(1)- 1] = e[(izero-1)- 1+ _e_offset];
z[(3)- 1] = e[(izero)- 1+ _e_offset];
e[(izero-1)- 1+ _e_offset] = zero;
e[(izero)- 1+ _e_offset] = zero;
}              // Close if()
z[(2)- 1] = d[(izero)- 1+ _d_offset];
d[(izero)- 1+ _d_offset] = zero;
}              // Close else if()
}              //  Close else.
// *
// *           Generate NRHS random solution vectors.
// *
ix = 1;
{
forloop40:
for (j = 1; j <= nrhs; j++) {
Dlarnv.dlarnv(2,iseed,0,n,xact,(ix)- 1+ _xact_offset);
ix = ix+lda;
Dummy.label("Ddrvpt",40);
}              //  Close for() loop. 
}
// *
// *           Set the right hand side.
// *
Dlaptm.dlaptm(n,nrhs,one,d,_d_offset,e,_e_offset,xact,_xact_offset,lda,zero,b,_b_offset,lda);
// *
{
forloop100:
for (ifact = 1; ifact <= 2; ifact++) {
if (ifact == 1)  {
    fact = "F";
}              // Close if()
else  {
  fact = "N";
}              //  Close else.
// *
// *              Compute the condition number for comparison with
// *              the value returned by DPTSVX.
// *
if (zerot)  {
    if (ifact == 1)  
    continue forloop100;
rcondc = zero;
// *
}              // Close if()
else if (ifact == 1)  {
    // *
// *                 Compute the 1-norm of A.
// *
anorm.val = Dlanst.dlanst("1",n,d,_d_offset,e,_e_offset);
// *
Dcopy.dcopy(n,d,_d_offset,1,d,(n+1)- 1+ _d_offset,1);
if (n > 1)  
    Dcopy.dcopy(n-1,e,_e_offset,1,e,(n+1)- 1+ _e_offset,1);
// *
// *                 Factor the matrix A.
// *
Dpttrf.dpttrf(n,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,info);
// *
// *                 Use DPTTRS to solve for one column at a time of
// *                 inv(A), computing the maximum column sum as we go.
// *
ainvnm = zero;
{
forloop60:
for (i = 1; i <= n; i++) {
{
forloop50:
for (j = 1; j <= n; j++) {
x[(j)- 1+ _x_offset] = zero;
Dummy.label("Ddrvpt",50);
}              //  Close for() loop. 
}
x[(i)- 1+ _x_offset] = one;
Dpttrs.dpttrs(n,1,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,x,_x_offset,lda,info);
ainvnm = Math.max(ainvnm, Dasum.dasum(n,x,_x_offset,1)) ;
Dummy.label("Ddrvpt",60);
}              //  Close for() loop. 
}
// *
// *                 Compute the 1-norm condition number of A.
// *
if (anorm.val <= zero || ainvnm <= zero)  {
    rcondc = one;
}              // Close if()
else  {
  rcondc = (one/anorm.val)/ainvnm;
}              //  Close else.
}              // Close else if()
// *
if (ifact == 2)  {
    // *
// *                 --- Test DPTSV --
// *
Dcopy.dcopy(n,d,_d_offset,1,d,(n+1)- 1+ _d_offset,1);
if (n > 1)  
    Dcopy.dcopy(n-1,e,_e_offset,1,e,(n+1)- 1+ _e_offset,1);
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
// *                 Factor A as L*D*L' and solve the system A*X = B.
// *
lintest_srnamc.srnamt = "DPTSV ";
Dptsv.dptsv(n,nrhs,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,x,_x_offset,lda,info);
// *
// *                 Check error code from DPTSV .
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DPTSV ",info.val,izero," ",n,n,1,1,nrhs,imat,nfail,nerrs,nout);
nt = 0;
if (izero == 0)  {
    // *
// *                    Check the factorization by computing the ratio
// *                       norm(L*D*L' - A) / (n * norm(A) * EPS )
// *
dptt01_adapter(n,d,_d_offset,e,_e_offset,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,work,_work_offset,result,(1)- 1);
// *
// *                    Compute the residual in the solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dptt02_adapter(n,nrhs,d,_d_offset,e,_e_offset,x,_x_offset,lda,work,_work_offset,lda,result,(2)- 1);
// *
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
nt = 3;
}              // Close if()
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
{
forloop70:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DPTSV ") + " "  + ", N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio = "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvpt",70);
}              //  Close for() loop. 
}
nrun = nrun+nt;
}              // Close if()
// *
// *              --- Test DPTSVX ---
// *
if (ifact > 1)  {
    // *
// *                 Initialize D( N+1:2*N ) and E( N+1:2*N ) to zero.
// *
{
forloop80:
for (i = 1; i <= n-1; i++) {
d[(n+i)- 1+ _d_offset] = zero;
e[(n+i)- 1+ _e_offset] = zero;
Dummy.label("Ddrvpt",80);
}              //  Close for() loop. 
}
if (n > 0)  
    d[(n+n)- 1+ _d_offset] = zero;
}              // Close if()
// *
Dlaset.dlaset("Full",n,nrhs,zero,zero,x,_x_offset,lda);
// *
// *              Solve the system and compute the condition number and
// *              error bounds using DPTSVX.
// *
lintest_srnamc.srnamt = "DPTSVX";
Dptsvx.dptsvx(fact,n,nrhs,d,_d_offset,e,_e_offset,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,b,_b_offset,lda,x,_x_offset,lda,rcond,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,info);
// *
// *              Check the error code from DPTSVX.
// *
if (info.val != izero)  
    Alaerh.alaerh(path,"DPTSVX",info.val,izero,fact,n,n,1,1,nrhs,imat,nfail,nerrs,nout);
if (izero == 0)  {
    if (ifact == 2)  {
    // *
// *                    Check the factorization by computing the ratio
// *                       norm(L*D*L' - A) / (n * norm(A) * EPS )
// *
k1 = 1;
dptt01_adapter(n,d,_d_offset,e,_e_offset,d,(n+1)- 1+ _d_offset,e,(n+1)- 1+ _e_offset,work,_work_offset,result,(1)- 1);
}              // Close if()
else  {
  k1 = 2;
}              //  Close else.
// *
// *                 Compute the residual in the solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dptt02_adapter(n,nrhs,d,_d_offset,e,_e_offset,x,_x_offset,lda,work,_work_offset,lda,result,(2)- 1);
// *
// *                 Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *                 Check error bounds from iterative refinement.
// *
Dptt05.dptt05(n,nrhs,d,_d_offset,e,_e_offset,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(4)- 1);
}              // Close if()
else  {
  k1 = 6;
}              //  Close else.
// *
// *              Check the reciprocal of the condition number.
// *
result[(6)- 1] = Dget06.dget06(rcond.val,rcondc);
// *
// *              Print information about the tests that did not pass
// *              the threshold.
// *
{
forloop90:
for (k = k1; k <= 6; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DPTSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio = "  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvpt",90);
}              //  Close for() loop. 
}
nrun = nrun+7-k1;
Dummy.label("Ddrvpt",100);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpt",110);
}              //  Close for() loop. 
}
Dummy.label("Ddrvpt",120);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasvm.alasvm(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Ddrvpt",999999);
// *
// *     End of DDRVPT
// *
Dummy.label("Ddrvpt",999999);
return;
   }
// adapter for dptt01
private static void dptt01_adapter(int arg0 ,double [] arg1 , int arg1_offset ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,double [] arg6 , int arg6_offset )
{
doubleW _f2j_tmp6 = new doubleW(arg6[arg6_offset]);

Dptt01.dptt01(arg0,arg1, arg1_offset,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5, arg5_offset,_f2j_tmp6);

arg6[arg6_offset] = _f2j_tmp6.val;
}

// adapter for dptt02
private static void dptt02_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset )
{
doubleW _f2j_tmp8 = new doubleW(arg8[arg8_offset]);

Dptt02.dptt02(arg0,arg1,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,_f2j_tmp8);

arg8[arg8_offset] = _f2j_tmp8.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
