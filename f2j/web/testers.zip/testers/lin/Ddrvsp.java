/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Ddrvsp {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DDRVSP tests the driver routines DSPSV and -SVX.
// *
// *  Arguments
// *  =========
// *
// *  DOTYPE  (input) LOGICAL array, dimension (NTYPES)
// *          The matrix types to be used for testing.  Matrices of type j
// *          (for 1 <= j <= NTYPES) are used for testing if DOTYPE(j) =
// *          .TRUE.; if DOTYPE(j) = .FALSE., then type j is not used.
// *
// *  NN      (input) INTEGER
// *          The number of values of N contained in the vector NVAL.
// *
// *  NVAL    (input) INTEGER array, dimension (NN)
// *          The values of the matrix dimension N.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors to be generated for
// *          each linear system.
// *
// *  THRESH  (input) DOUBLE PRECISION
// *          The threshold value for the test ratios.  A result is
// *          included in the output file if RESULT >= THRESH.  To have
// *          every test ratio printed, use THRESH = 0.
// *
// *  TSTERR  (input) LOGICAL
// *          Flag that indicates whether error exits are to be tested.
// *
// *  NMAX    (input) INTEGER
// *          The maximum value permitted for N, used in dimensioning the
// *          work arrays.
// *
// *  A       (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*(NMAX+1)/2)
// *
// *  AFAC    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*(NMAX+1)/2)
// *
// *  AINV    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*(NMAX+1)/2)
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  X       (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  XACT    (workspace) DOUBLE PRECISION array, dimension (NMAX*NRHS)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension
// *                      (NMAX*max(2,NRHS))
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (NMAX+2*NRHS)
// *
// *  IWORK   (workspace) INTEGER array, dimension (2*NMAX)
// *
// *  NOUT    (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
static int ntypes= 10;
static int ntests= 6;
static int nfact= 2;
// *     ..
// *     .. Local Scalars ..
static boolean zerot= false;
static StringW dist= new StringW(" ");
static String fact= new String(" ");
static String packit= new String(" ");
static StringW type= new StringW(" ");
static String uplo= new String(" ");
static String xtype= new String(" ");
static String path= new String("   ");
static int i= 0;
static int i1= 0;
static int i2= 0;
static int ifact= 0;
static int imat= 0;
static int in= 0;
static intW info= new intW(0);
static int ioff= 0;
static int iuplo= 0;
static int izero= 0;
static int j= 0;
static int k= 0;
static int k1= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lda= 0;
static int lwork= 0;
static intW mode= new intW(0);
static int n= 0;
static intW nerrs= new intW(0);
static int nfail= 0;
static int nimat= 0;
static int npp= 0;
static int nrun= 0;
static int nt= 0;
static double ainvnm= 0.0;
static doubleW anorm= new doubleW(0.0);
static doubleW cndnum= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
static double rcondc= 0.0;
// *     ..
// *     .. Local Arrays ..
static int [] iseed= new int[(4)];
static double [] result= new double[(ntests)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Data statements ..
static int [] iseedy = {1988 
, 1989 , 1990 , 1991 };
static String [] facts = {"F" 
, "N" };
// *     ..
// *     .. Executable Statements ..
// *
// *     Initialize constants and the random number seed.
// *

public static void ddrvsp (boolean [] dotype, int _dotype_offset,
int nn,
int [] nval, int _nval_offset,
int nrhs,
double thresh,
boolean tsterr,
int nmax,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
double [] ainv, int _ainv_offset,
double [] b, int _b_offset,
double [] x, int _x_offset,
double [] xact, int _xact_offset,
double [] work, int _work_offset,
double [] rwork, int _rwork_offset,
int [] iwork, int _iwork_offset,
int nout)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "SP".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
nrun = 0;
nfail = 0;
nerrs.val = 0;
{
forloop10:
for (i = 1; i <= 4; i++) {
iseed[(i)- 1] = iseedy[(i)- 1];
Dummy.label("Ddrvsp",10);
}              //  Close for() loop. 
}
lwork = (int)(Math.max(2*nmax, nmax*nrhs) );
// *
// *     Test the error exits
// *
if (tsterr)  
    Derrvx.derrvx(path,nout);
lintest_infoc.infot = 0;
// *
// *     Do for each value of N in NVAL
// *
{
forloop180:
for (in = 1; in <= nn; in++) {
n = nval[(in)- 1+ _nval_offset];
lda = (int)(Math.max(n, 1) );
npp = n*(n+1)/2;
xtype = "N";
nimat = ntypes;
if (n <= 0)  
    nimat = 1;
// *
{
forloop170:
for (imat = 1; imat <= nimat; imat++) {
// *
// *           Do the tests only if DOTYPE( IMAT ) is true.
// *
if (!dotype[(imat)- 1+ _dotype_offset])  
    continue forloop170;
// *
// *           Skip types 3, 4, 5, or 6 if the matrix size is too small.
// *
zerot = imat >= 3 && imat <= 6;
if (zerot && n < imat-2)  
    continue forloop170;
// *
// *           Do first for UPLO = 'U', then for UPLO = 'L'
// *
{
forloop160:
for (iuplo = 1; iuplo <= 2; iuplo++) {
if (iuplo == 1)  {
    uplo = "U";
packit = "C";
}              // Close if()
else  {
  uplo = "L";
packit = "R";
}              //  Close else.
// *
// *              Set up parameters with DLATB4 and generate a test matrix
// *              with DLATMS.
// *
Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
// *
lintest_srnamc.srnamt = "DLATMS";
Dlatms.dlatms(n,n,dist.val,iseed,0,type.val,rwork,_rwork_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,packit,a,_a_offset,lda,work,_work_offset,info);
// *
// *              Check error code from DLATMS.
// *
if (info.val != 0)  {
    Alaerh.alaerh(path,"DLATMS",info.val,0,uplo,n,n,-1,-1,-1,imat,nfail,nerrs,nout);
continue forloop160;
}              // Close if()
// *
// *              For types 3-6, zero one or more rows and columns of the
// *              matrix to test that INFO is returned correctly.
// *
if (zerot)  {
    if (imat == 3)  {
    izero = 1;
}              // Close if()
else if (imat == 4)  {
    izero = n;
}              // Close else if()
else  {
  izero = n/2+1;
}              //  Close else.
// *
if (imat < 6)  {
    // *
// *                    Set row and column IZERO to zero.
// *
if (iuplo == 1)  {
    ioff = (izero-1)*izero/2;
{
forloop20:
for (i = 1; i <= izero-1; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvsp",20);
}              //  Close for() loop. 
}
ioff = ioff+izero;
{
forloop30:
for (i = izero; i <= n; i++) {
a[(ioff)- 1+ _a_offset] = zero;
ioff = ioff+i;
Dummy.label("Ddrvsp",30);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  ioff = izero;
{
forloop40:
for (i = 1; i <= izero-1; i++) {
a[(ioff)- 1+ _a_offset] = zero;
ioff = ioff+n-i;
Dummy.label("Ddrvsp",40);
}              //  Close for() loop. 
}
ioff = ioff-izero;
{
forloop50:
for (i = izero; i <= n; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvsp",50);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  ioff = 0;
if (iuplo == 1)  {
    // *
// *                       Set the first IZERO rows and columns to zero.
// *
{
forloop70:
for (j = 1; j <= n; j++) {
i2 = (int)(Math.min(j, izero) );
{
forloop60:
for (i = 1; i <= i2; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvsp",60);
}              //  Close for() loop. 
}
ioff = ioff+j;
Dummy.label("Ddrvsp",70);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *                       Set the last IZERO rows and columns to zero.
// *
{
forloop90:
for (j = 1; j <= n; j++) {
i1 = (int)(Math.max(j, izero) );
{
forloop80:
for (i = i1; i <= n; i++) {
a[(ioff+i)- 1+ _a_offset] = zero;
Dummy.label("Ddrvsp",80);
}              //  Close for() loop. 
}
ioff = ioff+n-j;
Dummy.label("Ddrvsp",90);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
}              // Close if()
else  {
  izero = 0;
}              //  Close else.
// *
{
forloop150:
for (ifact = 1; ifact <= nfact; ifact++) {
// *
// *                 Do first for FACT = 'F', then for other values.
// *
fact = facts[(ifact)- 1];
// *
// *                 Compute the condition number for comparison with
// *                 the value returned by DSPSVX.
// *
if (zerot)  {
    if (ifact == 1)  
    continue forloop150;
rcondc = zero;
// *
}              // Close if()
else if (ifact == 1)  {
    // *
// *                    Compute the 1-norm of A.
// *
anorm.val = Dlansp.dlansp("1",uplo,n,a,_a_offset,rwork,_rwork_offset);
// *
// *                    Factor the matrix A.
// *
Dcopy.dcopy(npp,a,_a_offset,1,afac,_afac_offset,1);
Dsptrf.dsptrf(uplo,n,afac,_afac_offset,iwork,_iwork_offset,info);
// *
// *                    Compute inv(A) and take its norm.
// *
Dcopy.dcopy(npp,afac,_afac_offset,1,ainv,_ainv_offset,1);
Dsptri.dsptri(uplo,n,ainv,_ainv_offset,iwork,_iwork_offset,work,_work_offset,info);
ainvnm = Dlansp.dlansp("1",uplo,n,ainv,_ainv_offset,rwork,_rwork_offset);
// *
// *                    Compute the 1-norm condition number of A.
// *
if (anorm.val <= zero || ainvnm <= zero)  {
    rcondc = one;
}              // Close if()
else  {
  rcondc = (one/anorm.val)/ainvnm;
}              //  Close else.
}              // Close else if()
// *
// *                 Form an exact solution and set the right hand side.
// *
lintest_srnamc.srnamt = "DLARHS";
Dlarhs.dlarhs(path,xtype,uplo," ",n,n,kl.val,ku.val,nrhs,a,_a_offset,lda,xact,_xact_offset,lda,b,_b_offset,lda,iseed,0,info);
xtype = "C";
// *
// *                 --- Test DSPSV  ---
// *
if (ifact == 2)  {
    Dcopy.dcopy(npp,a,_a_offset,1,afac,_afac_offset,1);
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,x,_x_offset,lda);
// *
// *                    Factor the matrix and solve the system using DSPSV.
// *
lintest_srnamc.srnamt = "DSPSV ";
Dspsv.dspsv(uplo,n,nrhs,afac,_afac_offset,iwork,_iwork_offset,x,_x_offset,lda,info);
// *
// *                    Adjust the expected value of INFO to account for
// *                    pivoting.
// *
k = izero;
if (k > 0)  {
    label100:
   Dummy.label("Ddrvsp",100);
if (iwork[(k)- 1+ _iwork_offset] < 0)  {
    if (iwork[(k)- 1+ _iwork_offset] != -k)  {
    k = -iwork[(k)- 1+ _iwork_offset];
Dummy.go_to("Ddrvsp",100);
}              // Close if()
}              // Close if()
else if (iwork[(k)- 1+ _iwork_offset] != k)  {
    k = iwork[(k)- 1+ _iwork_offset];
Dummy.go_to("Ddrvsp",100);
}              // Close else if()
}              // Close if()
// *
// *                    Check error code from DSPSV .
// *
if (info.val != k)  {
    Alaerh.alaerh(path,"DSPSV ",info.val,k,uplo,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
Dummy.go_to("Ddrvsp",120);
}              // Close if()
else if (info.val != 0)  {
    Dummy.go_to("Ddrvsp",120);
}              // Close else if()
// *
// *                    Reconstruct matrix from factors and compute
// *                    residual.
// *
dspt01_adapter(uplo,n,a,_a_offset,afac,_afac_offset,iwork,_iwork_offset,ainv,_ainv_offset,lda,rwork,_rwork_offset,result,(1)- 1);
// *
// *                    Compute residual of the computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dppt02_adapter(uplo,n,nrhs,a,_a_offset,x,_x_offset,lda,work,_work_offset,lda,rwork,_rwork_offset,result,(2)- 1);
// *
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
nt = 3;
// *
// *                    Print information about the tests that did not pass
// *                    the threshold.
// *
{
forloop110:
for (k = 1; k <= nt; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DSPSV ") + " "  + ", UPLO=\'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvsp",110);
}              //  Close for() loop. 
}
nrun = nrun+nt;
label120:
   Dummy.label("Ddrvsp",120);
}              // Close if()
// *
// *                 --- Test DSPSVX ---
// *
if (ifact == 2 && npp > 0)  
    Dlaset.dlaset("Full",npp,1,zero,zero,afac,_afac_offset,npp);
Dlaset.dlaset("Full",n,nrhs,zero,zero,x,_x_offset,lda);
// *
// *                 Solve the system and compute the condition number and
// *                 error bounds using DSPSVX.
// *
lintest_srnamc.srnamt = "DSPSVX";
Dspsvx.dspsvx(fact,uplo,n,nrhs,a,_a_offset,afac,_afac_offset,iwork,_iwork_offset,b,_b_offset,lda,x,_x_offset,lda,rcond,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,work,_work_offset,iwork,(n+1)- 1+ _iwork_offset,info);
// *
// *                 Adjust the expected value of INFO to account for
// *                 pivoting.
// *
k = izero;
if (k > 0)  {
    label130:
   Dummy.label("Ddrvsp",130);
if (iwork[(k)- 1+ _iwork_offset] < 0)  {
    if (iwork[(k)- 1+ _iwork_offset] != -k)  {
    k = -iwork[(k)- 1+ _iwork_offset];
Dummy.go_to("Ddrvsp",130);
}              // Close if()
}              // Close if()
else if (iwork[(k)- 1+ _iwork_offset] != k)  {
    k = iwork[(k)- 1+ _iwork_offset];
Dummy.go_to("Ddrvsp",130);
}              // Close else if()
}              // Close if()
// *
// *                 Check the error code from DSPSVX.
// *
if (info.val != k)  {
    Alaerh.alaerh(path,"DSPSVX",info.val,k,fact+uplo,n,n,-1,-1,nrhs,imat,nfail,nerrs,nout);
continue forloop150;
}              // Close if()
// *
if (info.val == 0)  {
    if (ifact >= 2)  {
    // *
// *                       Reconstruct matrix from factors and compute
// *                       residual.
// *
dspt01_adapter(uplo,n,a,_a_offset,afac,_afac_offset,iwork,_iwork_offset,ainv,_ainv_offset,lda,rwork,(2*nrhs+1)- 1+ _rwork_offset,result,(1)- 1);
k1 = 1;
}              // Close if()
else  {
  k1 = 2;
}              //  Close else.
// *
// *                    Compute residual of the computed solution.
// *
Dlacpy.dlacpy("Full",n,nrhs,b,_b_offset,lda,work,_work_offset,lda);
dppt02_adapter(uplo,n,nrhs,a,_a_offset,x,_x_offset,lda,work,_work_offset,lda,rwork,(2*nrhs+1)- 1+ _rwork_offset,result,(2)- 1);
// *
// *                    Check solution from generated exact solution.
// *
dget04_adapter(n,nrhs,x,_x_offset,lda,xact,_xact_offset,lda,rcondc,result,(3)- 1);
// *
// *                    Check the error bounds from iterative refinement.
// *
Dppt05.dppt05(uplo,n,nrhs,a,_a_offset,b,_b_offset,lda,x,_x_offset,lda,xact,_xact_offset,lda,rwork,_rwork_offset,rwork,(nrhs+1)- 1+ _rwork_offset,result,(4)- 1);
}              // Close if()
else  {
  k1 = 6;
}              //  Close else.
// *
// *                 Compare RCOND from DSPSVX with the computed value
// *                 in RCONDC.
// *
result[(6)- 1] = Dget06.dget06(rcond.val,rcondc);
// *
// *                 Print information about the tests that did not pass
// *                 the threshold.
// *
{
forloop140:
for (k = k1; k <= 6; k++) {
if (result[(k)- 1] >= thresh)  {
    if (nfail == 0 && nerrs.val == 0)  
    Aladhd.aladhd(nout,path);
System.out.println(" " + ("DSPSVX") + " "  + ", FACT=\'"  + (fact) + " "  + "\', UPLO=\'"  + (uplo) + " "  + "\', N ="  + (n) + " "  + ", type "  + (imat) + " "  + ", test "  + (k) + " "  + ", ratio ="  + (result[(k)- 1]) + " " );
nfail = nfail+1;
}              // Close if()
Dummy.label("Ddrvsp",140);
}              //  Close for() loop. 
}
nrun = nrun+7-k1;
// *
Dummy.label("Ddrvsp",150);
}              //  Close for() loop. 
}
// *
Dummy.label("Ddrvsp",160);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsp",170);
}              //  Close for() loop. 
}
Dummy.label("Ddrvsp",180);
}              //  Close for() loop. 
}
// *
// *     Print a summary of the results.
// *
Alasvm.alasvm(path,nout,nfail,nrun,nerrs.val);
// *
Dummy.go_to("Ddrvsp",999999);
// *
// *     End of DDRVSP
// *
Dummy.label("Ddrvsp",999999);
return;
   }
// adapter for dspt01
private static void dspt01_adapter(String arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,double [] arg3 , int arg3_offset ,int [] arg4 , int arg4_offset ,double [] arg5 , int arg5_offset ,int arg6 ,double [] arg7 , int arg7_offset ,double [] arg8 , int arg8_offset )
{
doubleW _f2j_tmp8 = new doubleW(arg8[arg8_offset]);

Dspt01.dspt01(arg0,arg1,arg2, arg2_offset,arg3, arg3_offset,arg4, arg4_offset,arg5, arg5_offset,arg6,arg7, arg7_offset,_f2j_tmp8);

arg8[arg8_offset] = _f2j_tmp8.val;
}

// adapter for dppt02
private static void dppt02_adapter(String arg0 ,int arg1 ,int arg2 ,double [] arg3 , int arg3_offset ,double [] arg4 , int arg4_offset ,int arg5 ,double [] arg6 , int arg6_offset ,int arg7 ,double [] arg8 , int arg8_offset ,double [] arg9 , int arg9_offset )
{
doubleW _f2j_tmp9 = new doubleW(arg9[arg9_offset]);

Dppt02.dppt02(arg0,arg1,arg2,arg3, arg3_offset,arg4, arg4_offset,arg5,arg6, arg6_offset,arg7,arg8, arg8_offset,_f2j_tmp9);

arg9[arg9_offset] = _f2j_tmp9.val;
}

// adapter for dget04
private static void dget04_adapter(int arg0 ,int arg1 ,double [] arg2 , int arg2_offset ,int arg3 ,double [] arg4 , int arg4_offset ,int arg5 ,double arg6 ,double [] arg7 , int arg7_offset )
{
doubleW _f2j_tmp7 = new doubleW(arg7[arg7_offset]);

Dget04.dget04(arg0,arg1,arg2, arg2_offset,arg3,arg4, arg4_offset,arg5,arg6,_f2j_tmp7);

arg7[arg7_offset] = _f2j_tmp7.val;
}

} // End class.
