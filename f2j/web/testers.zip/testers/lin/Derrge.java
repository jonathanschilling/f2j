/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrge {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRGE tests the error exits for the DOUBLE PRECISION routines
// *  for general matrices.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
static int lw= 3*nmax;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static doubleW anrm= new doubleW(0.0);
static doubleW ccond= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ip= new int[(nmax)];
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(lw)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrge (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrge",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
r1[(j)- 1] = 0.e0;
r2[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
ip[(j)- 1] = j;
iw[(j)- 1] = j;
Dummy.label("Derrge",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        Test error exits of the routines that use the LU decomposition
// *        of a general matrix.
// *
// *        DGETRF
// *
lintest_srnamc.srnamt = "DGETRF";
lintest_infoc.infot = 1;
Dgetrf.dgetrf(-1,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGETRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgetrf.dgetrf(0,-1,a,0,1,ip,0,info);
Chkxer.chkxer("DGETRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgetrf.dgetrf(2,1,a,0,1,ip,0,info);
Chkxer.chkxer("DGETRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGETF2
// *
lintest_srnamc.srnamt = "DGETF2";
lintest_infoc.infot = 1;
Dgetf2.dgetf2(-1,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGETF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgetf2.dgetf2(0,-1,a,0,1,ip,0,info);
Chkxer.chkxer("DGETF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgetf2.dgetf2(2,1,a,0,1,ip,0,info);
Chkxer.chkxer("DGETF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGETRI
// *
lintest_srnamc.srnamt = "DGETRI";
lintest_infoc.infot = 1;
Dgetri.dgetri(-1,a,0,1,ip,0,w,0,lw,info);
Chkxer.chkxer("DGETRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgetri.dgetri(2,a,0,1,ip,0,w,0,lw,info);
Chkxer.chkxer("DGETRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGETRS
// *
lintest_srnamc.srnamt = "DGETRS";
lintest_infoc.infot = 1;
Dgetrs.dgetrs("/",0,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGETRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgetrs.dgetrs("N",-1,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGETRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgetrs.dgetrs("N",0,-1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGETRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgetrs.dgetrs("N",2,1,a,0,1,ip,0,b,0,2,info);
Chkxer.chkxer("DGETRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgetrs.dgetrs("N",2,1,a,0,2,ip,0,b,0,1,info);
Chkxer.chkxer("DGETRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGERFS
// *
lintest_srnamc.srnamt = "DGERFS";
lintest_infoc.infot = 1;
Dgerfs.dgerfs("/",0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgerfs.dgerfs("N",-1,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgerfs.dgerfs("N",0,-1,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgerfs.dgerfs("N",2,1,a,0,1,af,0,2,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgerfs.dgerfs("N",2,1,a,0,2,af,0,1,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgerfs.dgerfs("N",2,1,a,0,2,af,0,2,ip,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dgerfs.dgerfs("N",2,1,a,0,2,af,0,2,ip,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGERFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGECON
// *
lintest_srnamc.srnamt = "DGECON";
lintest_infoc.infot = 1;
Dgecon.dgecon("/",0,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGECON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgecon.dgecon("1",-1,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGECON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgecon.dgecon("1",2,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGECON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGEEQU
// *
lintest_srnamc.srnamt = "DGEEQU";
lintest_infoc.infot = 1;
Dgeequ.dgeequ(-1,0,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGEEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeequ.dgeequ(0,-1,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGEEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeequ.dgeequ(2,2,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGEEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        Test error exits of the routines that use the LU decomposition
// *        of a general band matrix.
// *
// *        DGBTRF
// *
lintest_srnamc.srnamt = "DGBTRF";
lintest_infoc.infot = 1;
Dgbtrf.dgbtrf(-1,0,0,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbtrf.dgbtrf(0,-1,0,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbtrf.dgbtrf(1,1,-1,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbtrf.dgbtrf(1,1,0,-1,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbtrf.dgbtrf(2,2,1,1,a,0,3,ip,0,info);
Chkxer.chkxer("DGBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBTF2
// *
lintest_srnamc.srnamt = "DGBTF2";
lintest_infoc.infot = 1;
Dgbtf2.dgbtf2(-1,0,0,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbtf2.dgbtf2(0,-1,0,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbtf2.dgbtf2(1,1,-1,0,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbtf2.dgbtf2(1,1,0,-1,a,0,1,ip,0,info);
Chkxer.chkxer("DGBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbtf2.dgbtf2(2,2,1,1,a,0,3,ip,0,info);
Chkxer.chkxer("DGBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBTRS
// *
lintest_srnamc.srnamt = "DGBTRS";
lintest_infoc.infot = 1;
Dgbtrs.dgbtrs("/",0,0,0,1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbtrs.dgbtrs("N",-1,0,0,1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbtrs.dgbtrs("N",1,-1,0,1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbtrs.dgbtrs("N",1,0,-1,1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgbtrs.dgbtrs("N",1,0,0,-1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgbtrs.dgbtrs("N",2,1,1,1,a,0,3,ip,0,b,0,2,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgbtrs.dgbtrs("N",2,0,0,1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBRFS
// *
lintest_srnamc.srnamt = "DGBRFS";
lintest_infoc.infot = 1;
Dgbrfs.dgbrfs("/",0,0,0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbrfs.dgbrfs("N",-1,0,0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbrfs.dgbrfs("N",1,-1,0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbrfs.dgbrfs("N",1,0,-1,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgbrfs.dgbrfs("N",1,0,0,-1,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgbrfs.dgbrfs("N",2,1,1,1,a,0,2,af,0,4,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dgbrfs.dgbrfs("N",2,1,1,1,a,0,3,af,0,3,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dgbrfs.dgbrfs("N",2,0,0,1,a,0,1,af,0,1,ip,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 14;
Dgbrfs.dgbrfs("N",2,0,0,1,a,0,1,af,0,1,ip,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBCON
// *
lintest_srnamc.srnamt = "DGBCON";
lintest_infoc.infot = 1;
Dgbcon.dgbcon("/",0,0,0,a,0,1,ip,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbcon.dgbcon("1",-1,0,0,a,0,1,ip,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbcon.dgbcon("1",1,-1,0,a,0,1,ip,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbcon.dgbcon("1",1,0,-1,a,0,1,ip,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbcon.dgbcon("1",2,1,1,a,0,3,ip,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBEQU
// *
lintest_srnamc.srnamt = "DGBEQU";
lintest_infoc.infot = 1;
Dgbequ.dgbequ(-1,0,0,0,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbequ.dgbequ(0,-1,0,0,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbequ.dgbequ(1,1,-1,0,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbequ.dgbequ(1,1,0,-1,a,0,1,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbequ.dgbequ(2,2,1,1,a,0,2,r1,0,r2,0,rcond,ccond,anrm,info);
Chkxer.chkxer("DGBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrge",999999);
// *
// *     End of DERRGE
// *
Dummy.label("Derrge",999999);
return;
   }
} // End class.
