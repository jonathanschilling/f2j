/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrgt {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRGT tests the error exits for the DOUBLE PRECISION tridiagonal
// *  routines.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static intW info= new intW(0);
static double anorm= 0.0;
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ip= new int[(nmax)];
static int [] iw= new int[(nmax)];
static double [] b= new double[(nmax)];
static double [] c= new double[(nmax)];
static double [] cf= new double[(nmax)];
static double [] d= new double[(nmax)];
static double [] df= new double[(nmax)];
static double [] e= new double[(nmax)];
static double [] ef= new double[(nmax)];
static double [] f= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrgt (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
d[(1)- 1] = 1.e0;
d[(2)- 1] = 2.e0;
df[(1)- 1] = 1.e0;
df[(2)- 1] = 2.e0;
e[(1)- 1] = 3.e0;
e[(2)- 1] = 4.e0;
ef[(1)- 1] = 3.e0;
ef[(2)- 1] = 4.e0;
anorm = 1.0e0;
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        Test error exits for the general tridiagonal routines.
// *
// *        DGTTRF
// *
lintest_srnamc.srnamt = "DGTTRF";
lintest_infoc.infot = 1;
Dgttrf.dgttrf(-1,c,0,d,0,e,0,f,0,ip,0,info);
Chkxer.chkxer("DGTTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGTTRS
// *
lintest_srnamc.srnamt = "DGTTRS";
lintest_infoc.infot = 1;
Dgttrs.dgttrs("/",0,0,c,0,d,0,e,0,f,0,ip,0,x,0,1,info);
Chkxer.chkxer("DGTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgttrs.dgttrs("N",-1,0,c,0,d,0,e,0,f,0,ip,0,x,0,1,info);
Chkxer.chkxer("DGTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgttrs.dgttrs("N",0,-1,c,0,d,0,e,0,f,0,ip,0,x,0,1,info);
Chkxer.chkxer("DGTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgttrs.dgttrs("N",2,1,c,0,d,0,e,0,f,0,ip,0,x,0,1,info);
Chkxer.chkxer("DGTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGTRFS
// *
lintest_srnamc.srnamt = "DGTRFS";
lintest_infoc.infot = 1;
Dgtrfs.dgtrfs("/",0,0,c,0,d,0,e,0,cf,0,df,0,ef,0,f,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgtrfs.dgtrfs("N",-1,0,c,0,d,0,e,0,cf,0,df,0,ef,0,f,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgtrfs.dgtrfs("N",0,-1,c,0,d,0,e,0,cf,0,df,0,ef,0,f,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 13;
Dgtrfs.dgtrfs("N",2,1,c,0,d,0,e,0,cf,0,df,0,ef,0,f,0,ip,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 15;
Dgtrfs.dgtrfs("N",2,1,c,0,d,0,e,0,cf,0,df,0,ef,0,f,0,ip,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGTCON
// *
lintest_srnamc.srnamt = "DGTCON";
lintest_infoc.infot = 1;
Dgtcon.dgtcon("/",0,c,0,d,0,e,0,f,0,ip,0,anorm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGTCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgtcon.dgtcon("I",-1,c,0,d,0,e,0,f,0,ip,0,anorm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGTCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgtcon.dgtcon("I",0,c,0,d,0,e,0,f,0,ip,0,-anorm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DGTCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        Test error exits for the positive definite tridiagonal
// *        routines.
// *
// *        DPTTRF
// *
lintest_srnamc.srnamt = "DPTTRF";
lintest_infoc.infot = 1;
Dpttrf.dpttrf(-1,d,0,e,0,info);
Chkxer.chkxer("DPTTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPTTRS
// *
lintest_srnamc.srnamt = "DPTTRS";
lintest_infoc.infot = 1;
Dpttrs.dpttrs(-1,0,d,0,e,0,x,0,1,info);
Chkxer.chkxer("DPTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpttrs.dpttrs(0,-1,d,0,e,0,x,0,1,info);
Chkxer.chkxer("DPTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dpttrs.dpttrs(2,1,d,0,e,0,x,0,1,info);
Chkxer.chkxer("DPTTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPTRFS
// *
lintest_srnamc.srnamt = "DPTRFS";
lintest_infoc.infot = 1;
Dptrfs.dptrfs(-1,0,d,0,e,0,df,0,ef,0,b,0,1,x,0,1,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dptrfs.dptrfs(0,-1,d,0,e,0,df,0,ef,0,b,0,1,x,0,1,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dptrfs.dptrfs(2,1,d,0,e,0,df,0,ef,0,b,0,1,x,0,2,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dptrfs.dptrfs(2,1,d,0,e,0,df,0,ef,0,b,0,2,x,0,1,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPTCON
// *
lintest_srnamc.srnamt = "DPTCON";
lintest_infoc.infot = 1;
Dptcon.dptcon(-1,d,0,e,0,anorm,rcond,w,0,info);
Chkxer.chkxer("DPTCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dptcon.dptcon(0,d,0,e,0,-anorm,rcond,w,0,info);
Chkxer.chkxer("DPTCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrgt",999999);
// *
// *     End of DERRGT
// *
Dummy.label("Derrgt",999999);
return;
   }
} // End class.
