/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrlq {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRLQ tests the error exits for the DOUBLE PRECISION routines
// *  that use the LQ decomposition of a general matrix.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrlq (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrlq",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
Dummy.label("Derrlq",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
// *     Error exits for LQ factorization
// *
// *     DGELQF
// *
lintest_srnamc.srnamt = "DGELQF";
lintest_infoc.infot = 1;
Dgelqf.dgelqf(-1,0,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGELQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgelqf.dgelqf(0,-1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGELQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgelqf.dgelqf(2,1,a,0,1,b,0,w,0,2,info);
Chkxer.chkxer("DGELQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgelqf.dgelqf(2,1,a,0,2,b,0,w,0,1,info);
Chkxer.chkxer("DGELQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGELQ2
// *
lintest_srnamc.srnamt = "DGELQ2";
lintest_infoc.infot = 1;
Dgelq2.dgelq2(-1,0,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGELQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgelq2.dgelq2(0,-1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGELQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgelq2.dgelq2(2,1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGELQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGELQS
// *
lintest_srnamc.srnamt = "DGELQS";
lintest_infoc.infot = 1;
Dgelqs.dgelqs(-1,0,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgelqs.dgelqs(0,-1,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgelqs.dgelqs(2,1,0,a,0,2,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgelqs.dgelqs(0,0,-1,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgelqs.dgelqs(2,2,0,a,0,1,x,0,b,0,2,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgelqs.dgelqs(1,2,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgelqs.dgelqs(1,1,2,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGELQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGLQ
// *
lintest_srnamc.srnamt = "DORGLQ";
lintest_infoc.infot = 1;
Dorglq.dorglq(-1,0,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorglq.dorglq(0,-1,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorglq.dorglq(2,1,0,a,0,2,x,0,w,0,2,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorglq.dorglq(0,0,-1,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorglq.dorglq(1,1,2,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorglq.dorglq(2,2,0,a,0,1,x,0,w,0,2,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dorglq.dorglq(2,2,0,a,0,2,x,0,w,0,1,info);
Chkxer.chkxer("DORGLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGL2
// *
lintest_srnamc.srnamt = "DORGL2";
lintest_infoc.infot = 1;
Dorgl2.dorgl2(-1,0,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgl2.dorgl2(0,-1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgl2.dorgl2(2,1,0,a,0,2,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgl2.dorgl2(0,0,-1,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgl2.dorgl2(1,1,2,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorgl2.dorgl2(2,2,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORMLQ
// *
lintest_srnamc.srnamt = "DORMLQ";
lintest_infoc.infot = 1;
Dormlq.dormlq("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dormlq.dormlq("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dormlq.dormlq("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dormlq.dormlq("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormlq.dormlq("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormlq.dormlq("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormlq.dormlq("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormlq.dormlq("L","N",2,0,2,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormlq.dormlq("R","N",0,2,2,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dormlq.dormlq("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormlq.dormlq("L","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormlq.dormlq("R","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMLQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORML2
// *
lintest_srnamc.srnamt = "DORML2";
lintest_infoc.infot = 1;
Dorml2.dorml2("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorml2.dorml2("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorml2.dorml2("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dorml2.dorml2("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorml2.dorml2("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorml2.dorml2("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorml2.dorml2("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorml2.dorml2("L","N",2,1,2,a,0,1,x,0,af,0,2,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorml2.dorml2("R","N",1,2,2,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dorml2.dorml2("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORML2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrlq",999999);
// *
// *     End of DERRLQ
// *
Dummy.label("Derrlq",999999);
return;
   }
} // End class.
