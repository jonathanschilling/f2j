/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrpo {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRPO tests the error exits for the DOUBLE PRECISION routines
// *  for symmetric positive definite matrices.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static doubleW anrm= new doubleW(0.0);
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(3*nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrpo (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrpo",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
r1[(j)- 1] = 0.e0;
r2[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
iw[(j)- 1] = j;
Dummy.label("Derrpo",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"PO",0,2))  {
    // *
// *        Test error exits of the routines that use the Cholesky
// *        decomposition of a symmetric positive definite matrix.
// *
// *        DPOTRF
// *
lintest_srnamc.srnamt = "DPOTRF";
lintest_infoc.infot = 1;
Dpotrf.dpotrf("/",0,a,0,1,info);
Chkxer.chkxer("DPOTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpotrf.dpotrf("U",-1,a,0,1,info);
Chkxer.chkxer("DPOTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpotrf.dpotrf("U",2,a,0,1,info);
Chkxer.chkxer("DPOTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOTF2
// *
lintest_srnamc.srnamt = "DPOTF2";
lintest_infoc.infot = 1;
Dpotf2.dpotf2("/",0,a,0,1,info);
Chkxer.chkxer("DPOTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpotf2.dpotf2("U",-1,a,0,1,info);
Chkxer.chkxer("DPOTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpotf2.dpotf2("U",2,a,0,1,info);
Chkxer.chkxer("DPOTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOTRI
// *
lintest_srnamc.srnamt = "DPOTRI";
lintest_infoc.infot = 1;
Dpotri.dpotri("/",0,a,0,1,info);
Chkxer.chkxer("DPOTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpotri.dpotri("U",-1,a,0,1,info);
Chkxer.chkxer("DPOTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpotri.dpotri("U",2,a,0,1,info);
Chkxer.chkxer("DPOTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOTRS
// *
lintest_srnamc.srnamt = "DPOTRS";
lintest_infoc.infot = 1;
Dpotrs.dpotrs("/",0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpotrs.dpotrs("U",-1,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpotrs.dpotrs("U",0,-1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpotrs.dpotrs("U",2,1,a,0,1,b,0,2,info);
Chkxer.chkxer("DPOTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dpotrs.dpotrs("U",2,1,a,0,2,b,0,1,info);
Chkxer.chkxer("DPOTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPORFS
// *
lintest_srnamc.srnamt = "DPORFS";
lintest_infoc.infot = 1;
Dporfs.dporfs("/",0,0,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dporfs.dporfs("U",-1,0,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dporfs.dporfs("U",0,-1,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dporfs.dporfs("U",2,1,a,0,1,af,0,2,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dporfs.dporfs("U",2,1,a,0,2,af,0,1,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dporfs.dporfs("U",2,1,a,0,2,af,0,2,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
Dporfs.dporfs("U",2,1,a,0,2,af,0,2,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPORFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOCON
// *
lintest_srnamc.srnamt = "DPOCON";
lintest_infoc.infot = 1;
Dpocon.dpocon("/",0,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPOCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpocon.dpocon("U",-1,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPOCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpocon.dpocon("U",2,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPOCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOEQU
// *
lintest_srnamc.srnamt = "DPOEQU";
lintest_infoc.infot = 1;
Dpoequ.dpoequ(-1,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPOEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpoequ.dpoequ(2,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPOEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"PP",0,2))  {
    // *
// *        Test error exits of the routines that use the Cholesky
// *        decomposition of a symmetric positive definite packed matrix.
// *
// *        DPPTRF
// *
lintest_srnamc.srnamt = "DPPTRF";
lintest_infoc.infot = 1;
Dpptrf.dpptrf("/",0,a,0,info);
Chkxer.chkxer("DPPTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpptrf.dpptrf("U",-1,a,0,info);
Chkxer.chkxer("DPPTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPTRI
// *
lintest_srnamc.srnamt = "DPPTRI";
lintest_infoc.infot = 1;
Dpptri.dpptri("/",0,a,0,info);
Chkxer.chkxer("DPPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpptri.dpptri("U",-1,a,0,info);
Chkxer.chkxer("DPPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPTRS
// *
lintest_srnamc.srnamt = "DPPTRS";
lintest_infoc.infot = 1;
Dpptrs.dpptrs("/",0,0,a,0,b,0,1,info);
Chkxer.chkxer("DPPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpptrs.dpptrs("U",-1,0,a,0,b,0,1,info);
Chkxer.chkxer("DPPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpptrs.dpptrs("U",0,-1,a,0,b,0,1,info);
Chkxer.chkxer("DPPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dpptrs.dpptrs("U",2,1,a,0,b,0,1,info);
Chkxer.chkxer("DPPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPRFS
// *
lintest_srnamc.srnamt = "DPPRFS";
lintest_infoc.infot = 1;
Dpprfs.dpprfs("/",0,0,a,0,af,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpprfs.dpprfs("U",-1,0,a,0,af,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpprfs.dpprfs("U",0,-1,a,0,af,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dpprfs.dpprfs("U",2,1,a,0,af,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dpprfs.dpprfs("U",2,1,a,0,af,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPCON
// *
lintest_srnamc.srnamt = "DPPCON";
lintest_infoc.infot = 1;
Dppcon.dppcon("/",0,a,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dppcon.dppcon("U",-1,a,0,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPEQU
// *
lintest_srnamc.srnamt = "DPPEQU";
lintest_infoc.infot = 1;
Dppequ.dppequ("/",0,a,0,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPPEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dppequ.dppequ("U",-1,a,0,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPPEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        Test error exits of the routines that use the Cholesky
// *        decomposition of a symmetric positive definite band matrix.
// *
// *        DPBTRF
// *
lintest_srnamc.srnamt = "DPBTRF";
lintest_infoc.infot = 1;
Dpbtrf.dpbtrf("/",0,0,a,0,1,info);
Chkxer.chkxer("DPBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbtrf.dpbtrf("U",-1,0,a,0,1,info);
Chkxer.chkxer("DPBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbtrf.dpbtrf("U",1,-1,a,0,1,info);
Chkxer.chkxer("DPBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpbtrf.dpbtrf("U",2,1,a,0,1,info);
Chkxer.chkxer("DPBTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBTF2
// *
lintest_srnamc.srnamt = "DPBTF2";
lintest_infoc.infot = 1;
Dpbtf2.dpbtf2("/",0,0,a,0,1,info);
Chkxer.chkxer("DPBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbtf2.dpbtf2("U",-1,0,a,0,1,info);
Chkxer.chkxer("DPBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbtf2.dpbtf2("U",1,-1,a,0,1,info);
Chkxer.chkxer("DPBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpbtf2.dpbtf2("U",2,1,a,0,1,info);
Chkxer.chkxer("DPBTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBTRS
// *
lintest_srnamc.srnamt = "DPBTRS";
lintest_infoc.infot = 1;
Dpbtrs.dpbtrs("/",0,0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbtrs.dpbtrs("U",-1,0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbtrs.dpbtrs("U",1,-1,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpbtrs.dpbtrs("U",0,0,-1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dpbtrs.dpbtrs("U",2,1,1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dpbtrs.dpbtrs("U",2,0,1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBRFS
// *
lintest_srnamc.srnamt = "DPBRFS";
lintest_infoc.infot = 1;
Dpbrfs.dpbrfs("/",0,0,0,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbrfs.dpbrfs("U",-1,0,0,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbrfs.dpbrfs("U",1,-1,0,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpbrfs.dpbrfs("U",0,0,-1,a,0,1,af,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dpbrfs.dpbrfs("U",2,1,1,a,0,1,af,0,2,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dpbrfs.dpbrfs("U",2,1,1,a,0,2,af,0,1,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dpbrfs.dpbrfs("U",2,0,1,a,0,1,af,0,1,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dpbrfs.dpbrfs("U",2,0,1,a,0,1,af,0,1,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBCON
// *
lintest_srnamc.srnamt = "DPBCON";
lintest_infoc.infot = 1;
Dpbcon.dpbcon("/",0,0,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbcon.dpbcon("U",-1,0,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbcon.dpbcon("U",1,-1,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpbcon.dpbcon("U",2,1,a,0,1,anrm.val,rcond,w,0,iw,0,info);
Chkxer.chkxer("DPBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBEQU
// *
lintest_srnamc.srnamt = "DPBEQU";
lintest_infoc.infot = 1;
Dpbequ.dpbequ("/",0,0,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbequ.dpbequ("U",-1,0,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbequ.dpbequ("U",1,-1,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpbequ.dpbequ("U",2,1,a,0,1,r1,0,rcond,anrm,info);
Chkxer.chkxer("DPBEQU",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrpo",999999);
// *
// *     End of DERRPO
// *
Dummy.label("Derrpo",999999);
return;
   }
} // End class.
