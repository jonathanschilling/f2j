/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrql {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRQL tests the error exits for the DOUBLE PRECISION routines
// *  that use the QL decomposition of a general matrix.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrql (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrql",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
Dummy.label("Derrql",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
// *     Error exits for QL factorization
// *
// *     DGEQLF
// *
lintest_srnamc.srnamt = "DGEQLF";
lintest_infoc.infot = 1;
Dgeqlf.dgeqlf(-1,0,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQLF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqlf.dgeqlf(0,-1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQLF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeqlf.dgeqlf(2,1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQLF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgeqlf.dgeqlf(1,2,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQLF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGEQL2
// *
lintest_srnamc.srnamt = "DGEQL2";
lintest_infoc.infot = 1;
Dgeql2.dgeql2(-1,0,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeql2.dgeql2(0,-1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeql2.dgeql2(2,1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQL2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGEQLS
// *
lintest_srnamc.srnamt = "DGEQLS";
lintest_infoc.infot = 1;
Dgeqls.dgeqls(-1,0,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqls.dgeqls(0,-1,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqls.dgeqls(1,2,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgeqls.dgeqls(0,0,-1,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgeqls.dgeqls(2,1,0,a,0,1,x,0,b,0,2,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgeqls.dgeqls(2,1,0,a,0,2,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgeqls.dgeqls(1,1,2,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQLS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGQL
// *
lintest_srnamc.srnamt = "DORGQL";
lintest_infoc.infot = 1;
Dorgql.dorgql(-1,0,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgql.dorgql(0,-1,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgql.dorgql(1,2,0,a,0,1,x,0,w,0,2,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgql.dorgql(0,0,-1,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgql.dorgql(1,1,2,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorgql.dorgql(2,1,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dorgql.dorgql(2,2,0,a,0,2,x,0,w,0,1,info);
Chkxer.chkxer("DORGQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORG2L
// *
lintest_srnamc.srnamt = "DORG2L";
lintest_infoc.infot = 1;
Dorg2l.dorg2l(-1,0,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorg2l.dorg2l(0,-1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorg2l.dorg2l(1,2,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorg2l.dorg2l(0,0,-1,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorg2l.dorg2l(2,1,2,a,0,2,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorg2l.dorg2l(2,1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORMQL
// *
lintest_srnamc.srnamt = "DORMQL";
lintest_infoc.infot = 1;
Dormql.dormql("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dormql.dormql("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dormql.dormql("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dormql.dormql("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormql.dormql("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormql.dormql("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormql.dormql("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormql.dormql("L","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormql.dormql("R","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dormql.dormql("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormql.dormql("L","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormql.dormql("R","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMQL",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORM2L
// *
lintest_srnamc.srnamt = "DORM2L";
lintest_infoc.infot = 1;
Dorm2l.dorm2l("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorm2l.dorm2l("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorm2l.dorm2l("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dorm2l.dorm2l("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2l.dorm2l("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2l.dorm2l("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2l.dorm2l("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorm2l.dorm2l("L","N",2,1,0,a,0,1,x,0,af,0,2,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorm2l.dorm2l("R","N",1,2,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dorm2l.dorm2l("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2L",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrql",999999);
// *
// *     End of DERRQL
// *
Dummy.label("Derrql",999999);
return;
   }
} // End class.
