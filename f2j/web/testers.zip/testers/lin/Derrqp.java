/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrqp {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRQP tests the error exits for DGEQPF.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static intW info= new intW(0);
// *     ..
// *     .. Local Arrays ..
static int [] ip= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] tau= new double[(nmax)];
static double [] w= new double[(3*nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrqp (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
a[(1)- 1+(1- 1)*nmax] = 1.e0;
a[(1)- 1+(2- 1)*nmax] = 2.e0;
a[(2)- 1+(2- 1)*nmax] = 3.e0;
a[(2)- 1+(1- 1)*nmax] = 4.e0;
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"QP",0,2))  {
    // *
// *        Test error exits for QR factorization with pivoting
// *
// *        DGEQPF
// *
lintest_srnamc.srnamt = "DGEQPF";
lintest_infoc.infot = 1;
Dgeqpf.dgeqpf(-1,0,a,0,1,ip,0,tau,0,w,0,info);
Chkxer.chkxer("DGEQPF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqpf.dgeqpf(0,-1,a,0,1,ip,0,tau,0,w,0,info);
Chkxer.chkxer("DGEQPF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeqpf.dgeqpf(2,0,a,0,1,ip,0,tau,0,w,0,info);
Chkxer.chkxer("DGEQPF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrqp",999999);
// *
// *     End of DERRQP
// *
Dummy.label("Derrqp",999999);
return;
   }
} // End class.
