/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrqr {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRQR tests the error exits for the DOUBLE PRECISION routines
// *  that use the QR decomposition of a general matrix.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrqr (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrqr",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
Dummy.label("Derrqr",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
// *     Error exits for QR factorization
// *
// *     DGEQRF
// *
lintest_srnamc.srnamt = "DGEQRF";
lintest_infoc.infot = 1;
Dgeqrf.dgeqrf(-1,0,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqrf.dgeqrf(0,-1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeqrf.dgeqrf(2,1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgeqrf.dgeqrf(1,2,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGEQRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGEQR2
// *
lintest_srnamc.srnamt = "DGEQR2";
lintest_infoc.infot = 1;
Dgeqr2.dgeqr2(-1,0,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqr2.dgeqr2(0,-1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgeqr2.dgeqr2(2,1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGEQR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGEQRS
// *
lintest_srnamc.srnamt = "DGEQRS";
lintest_infoc.infot = 1;
Dgeqrs.dgeqrs(-1,0,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqrs.dgeqrs(0,-1,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgeqrs.dgeqrs(1,2,0,a,0,2,x,0,b,0,2,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgeqrs.dgeqrs(0,0,-1,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgeqrs.dgeqrs(2,1,0,a,0,1,x,0,b,0,2,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgeqrs.dgeqrs(2,1,0,a,0,2,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgeqrs.dgeqrs(1,1,2,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGEQRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGQR
// *
lintest_srnamc.srnamt = "DORGQR";
lintest_infoc.infot = 1;
Dorgqr.dorgqr(-1,0,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgqr.dorgqr(0,-1,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgqr.dorgqr(1,2,0,a,0,1,x,0,w,0,2,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgqr.dorgqr(0,0,-1,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgqr.dorgqr(1,1,2,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorgqr.dorgqr(2,2,0,a,0,1,x,0,w,0,2,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dorgqr.dorgqr(2,2,0,a,0,2,x,0,w,0,1,info);
Chkxer.chkxer("DORGQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORG2R
// *
lintest_srnamc.srnamt = "DORG2R";
lintest_infoc.infot = 1;
Dorg2r.dorg2r(-1,0,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorg2r.dorg2r(0,-1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorg2r.dorg2r(1,2,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorg2r.dorg2r(0,0,-1,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorg2r.dorg2r(2,1,2,a,0,2,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorg2r.dorg2r(2,1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORG2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORMQR
// *
lintest_srnamc.srnamt = "DORMQR";
lintest_infoc.infot = 1;
Dormqr.dormqr("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dormqr.dormqr("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dormqr.dormqr("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dormqr.dormqr("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormqr.dormqr("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormqr.dormqr("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormqr.dormqr("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormqr.dormqr("L","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormqr.dormqr("R","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dormqr.dormqr("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormqr.dormqr("L","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormqr.dormqr("R","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMQR",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORM2R
// *
lintest_srnamc.srnamt = "DORM2R";
lintest_infoc.infot = 1;
Dorm2r.dorm2r("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorm2r.dorm2r("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorm2r.dorm2r("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dorm2r.dorm2r("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2r.dorm2r("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2r.dorm2r("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorm2r.dorm2r("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorm2r.dorm2r("L","N",2,1,0,a,0,1,x,0,af,0,2,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dorm2r.dorm2r("R","N",1,2,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dorm2r.dorm2r("L","N",2,1,0,a,0,2,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORM2R",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrqr",999999);
// *
// *     End of DERRQR
// *
Dummy.label("Derrqr",999999);
return;
   }
} // End class.
