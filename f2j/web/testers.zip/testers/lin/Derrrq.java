/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrrq {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRRQ tests the error exits for the DOUBLE PRECISION routines
// *  that use the RQ decomposition of a general matrix.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
// *     ..
// *     .. Local Arrays ..
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrrq (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrrq",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
Dummy.label("Derrrq",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
// *     Error exits for RQ factorization
// *
// *     DGERQF
// *
lintest_srnamc.srnamt = "DGERQF";
lintest_infoc.infot = 1;
Dgerqf.dgerqf(-1,0,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGERQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgerqf.dgerqf(0,-1,a,0,1,b,0,w,0,1,info);
Chkxer.chkxer("DGERQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgerqf.dgerqf(2,1,a,0,1,b,0,w,0,2,info);
Chkxer.chkxer("DGERQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgerqf.dgerqf(2,1,a,0,2,b,0,w,0,1,info);
Chkxer.chkxer("DGERQF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGERQ2
// *
lintest_srnamc.srnamt = "DGERQ2";
lintest_infoc.infot = 1;
Dgerq2.dgerq2(-1,0,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGERQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgerq2.dgerq2(0,-1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGERQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgerq2.dgerq2(2,1,a,0,1,b,0,w,0,info);
Chkxer.chkxer("DGERQ2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DGERQS
// *
lintest_srnamc.srnamt = "DGERQS";
lintest_infoc.infot = 1;
Dgerqs.dgerqs(-1,0,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgerqs.dgerqs(0,-1,0,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgerqs.dgerqs(2,1,0,a,0,2,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgerqs.dgerqs(0,0,-1,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgerqs.dgerqs(2,2,0,a,0,1,x,0,b,0,2,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgerqs.dgerqs(2,2,0,a,0,2,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgerqs.dgerqs(1,1,2,a,0,1,x,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DGERQS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGRQ
// *
lintest_srnamc.srnamt = "DORGRQ";
lintest_infoc.infot = 1;
Dorgrq.dorgrq(-1,0,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgrq.dorgrq(0,-1,0,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgrq.dorgrq(2,1,0,a,0,2,x,0,w,0,2,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgrq.dorgrq(0,0,-1,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgrq.dorgrq(1,2,2,a,0,1,x,0,w,0,1,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorgrq.dorgrq(2,2,0,a,0,1,x,0,w,0,2,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dorgrq.dorgrq(2,2,0,a,0,2,x,0,w,0,1,info);
Chkxer.chkxer("DORGRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORGR2
// *
lintest_srnamc.srnamt = "DORGR2";
lintest_infoc.infot = 1;
Dorgr2.dorgr2(-1,0,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgr2.dorgr2(0,-1,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dorgr2.dorgr2(2,1,0,a,0,2,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgr2.dorgr2(0,0,-1,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dorgr2.dorgr2(1,2,2,a,0,2,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dorgr2.dorgr2(2,2,0,a,0,1,x,0,w,0,info);
Chkxer.chkxer("DORGR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORMRQ
// *
lintest_srnamc.srnamt = "DORMRQ";
lintest_infoc.infot = 1;
Dormrq.dormrq("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dormrq.dormrq("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dormrq.dormrq("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dormrq.dormrq("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormrq.dormrq("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormrq.dormrq("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormrq.dormrq("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormrq.dormrq("L","N",2,1,2,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormrq.dormrq("R","N",1,2,2,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dormrq.dormrq("L","N",2,1,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormrq.dormrq("L","N",1,2,0,a,0,1,x,0,af,0,1,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dormrq.dormrq("R","N",2,1,0,a,0,1,x,0,af,0,2,w,0,1,info);
Chkxer.chkxer("DORMRQ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     DORMR2
// *
lintest_srnamc.srnamt = "DORMR2";
lintest_infoc.infot = 1;
Dormr2.dormr2("/","N",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dormr2.dormr2("L","/",0,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dormr2.dormr2("L","N",-1,0,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dormr2.dormr2("L","N",0,-1,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormr2.dormr2("L","N",0,0,-1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormr2.dormr2("L","N",0,1,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dormr2.dormr2("R","N",1,0,1,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormr2.dormr2("L","N",2,1,2,a,0,1,x,0,af,0,2,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dormr2.dormr2("R","N",1,2,2,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dormr2.dormr2("L","N",2,1,0,a,0,1,x,0,af,0,1,w,0,info);
Chkxer.chkxer("DORMR2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrrq",999999);
// *
// *     End of DERRRQ
// *
Dummy.label("Derrrq",999999);
return;
   }
} // End class.
