/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrsy {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRSY tests the error exits for the DOUBLE PRECISION routines
// *  for symmetric indefinite matrices.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static double anrm= 0.0;
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ip= new int[(nmax)];
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(3*nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrsy (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrsy",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
r1[(j)- 1] = 0.e0;
r2[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
ip[(j)- 1] = j;
iw[(j)- 1] = j;
Dummy.label("Derrsy",20);
}              //  Close for() loop. 
}
anrm = 1.0e0;
rcond.val = 1.0e0;
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"SY",0,2))  {
    // *
// *        Test error exits of the routines that use the Bunch-Kaufman
// *        factorization of a symmetric indefinite matrix.
// *
// *        DSYTRF
// *
lintest_srnamc.srnamt = "DSYTRF";
lintest_infoc.infot = 1;
Dsytrf.dsytrf("/",0,a,0,1,ip,0,w,0,1,info);
Chkxer.chkxer("DSYTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsytrf.dsytrf("U",-1,a,0,1,ip,0,w,0,1,info);
Chkxer.chkxer("DSYTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dsytrf.dsytrf("U",2,a,0,1,ip,0,w,0,4,info);
Chkxer.chkxer("DSYTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYTF2
// *
lintest_srnamc.srnamt = "DSYTF2";
lintest_infoc.infot = 1;
Dsytf2.dsytf2("/",0,a,0,1,ip,0,info);
Chkxer.chkxer("DSYTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsytf2.dsytf2("U",-1,a,0,1,ip,0,info);
Chkxer.chkxer("DSYTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dsytf2.dsytf2("U",2,a,0,1,ip,0,info);
Chkxer.chkxer("DSYTF2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYTRI
// *
lintest_srnamc.srnamt = "DSYTRI";
lintest_infoc.infot = 1;
Dsytri.dsytri("/",0,a,0,1,ip,0,w,0,info);
Chkxer.chkxer("DSYTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsytri.dsytri("U",-1,a,0,1,ip,0,w,0,info);
Chkxer.chkxer("DSYTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dsytri.dsytri("U",2,a,0,1,ip,0,w,0,info);
Chkxer.chkxer("DSYTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYTRS
// *
lintest_srnamc.srnamt = "DSYTRS";
lintest_infoc.infot = 1;
Dsytrs.dsytrs("/",0,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DSYTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsytrs.dsytrs("U",-1,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DSYTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsytrs.dsytrs("U",0,-1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DSYTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dsytrs.dsytrs("U",2,1,a,0,1,ip,0,b,0,2,info);
Chkxer.chkxer("DSYTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dsytrs.dsytrs("U",2,1,a,0,2,ip,0,b,0,1,info);
Chkxer.chkxer("DSYTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYRFS
// *
lintest_srnamc.srnamt = "DSYRFS";
lintest_infoc.infot = 1;
Dsyrfs.dsyrfs("/",0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsyrfs.dsyrfs("U",-1,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsyrfs.dsyrfs("U",0,-1,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dsyrfs.dsyrfs("U",2,1,a,0,1,af,0,2,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dsyrfs.dsyrfs("U",2,1,a,0,2,af,0,1,ip,0,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dsyrfs.dsyrfs("U",2,1,a,0,2,af,0,2,ip,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dsyrfs.dsyrfs("U",2,1,a,0,2,af,0,2,ip,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSYRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYCON
// *
lintest_srnamc.srnamt = "DSYCON";
lintest_infoc.infot = 1;
Dsycon.dsycon("/",0,a,0,1,ip,0,anrm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSYCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsycon.dsycon("U",-1,a,0,1,ip,0,anrm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSYCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dsycon.dsycon("U",2,a,0,1,ip,0,anrm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSYCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dsycon.dsycon("U",1,a,0,1,ip,0,-1.0e0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSYCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        Test error exits of the routines that use the Bunch-Kaufman
// *        factorization of a symmetric indefinite packed matrix.
// *
// *        DSPTRF
// *
lintest_srnamc.srnamt = "DSPTRF";
lintest_infoc.infot = 1;
Dsptrf.dsptrf("/",0,a,0,ip,0,info);
Chkxer.chkxer("DSPTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsptrf.dsptrf("U",-1,a,0,ip,0,info);
Chkxer.chkxer("DSPTRF",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSPTRI
// *
lintest_srnamc.srnamt = "DSPTRI";
lintest_infoc.infot = 1;
Dsptri.dsptri("/",0,a,0,ip,0,w,0,info);
Chkxer.chkxer("DSPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsptri.dsptri("U",-1,a,0,ip,0,w,0,info);
Chkxer.chkxer("DSPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSPTRS
// *
lintest_srnamc.srnamt = "DSPTRS";
lintest_infoc.infot = 1;
Dsptrs.dsptrs("/",0,0,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsptrs.dsptrs("U",-1,0,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsptrs.dsptrs("U",0,-1,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dsptrs.dsptrs("U",2,1,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSPRFS
// *
lintest_srnamc.srnamt = "DSPRFS";
lintest_infoc.infot = 1;
Dsprfs.dsprfs("/",0,0,a,0,af,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsprfs.dsprfs("U",-1,0,a,0,af,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsprfs.dsprfs("U",0,-1,a,0,af,0,ip,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dsprfs.dsprfs("U",2,1,a,0,af,0,ip,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dsprfs.dsprfs("U",2,1,a,0,af,0,ip,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSPCON
// *
lintest_srnamc.srnamt = "DSPCON";
lintest_infoc.infot = 1;
Dspcon.dspcon("/",0,a,0,ip,0,anrm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dspcon.dspcon("U",-1,a,0,ip,0,anrm,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dspcon.dspcon("U",1,a,0,ip,0,-1.0e0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DSPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrsy",999999);
// *
// *     End of DERRSY
// *
Dummy.label("Derrsy",999999);
return;
   }
} // End class.
