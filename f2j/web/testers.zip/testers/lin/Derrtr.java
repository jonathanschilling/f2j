/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrtr {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRTR tests the error exits for the DOUBLE PRECISION triangular
// *  routines.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 2;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static intW info= new intW(0);
static doubleW rcond= new doubleW(0.0);
static doubleW scale= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrtr (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
a[(1)- 1+(1- 1)*nmax] = 1.e0;
a[(1)- 1+(2- 1)*nmax] = 2.e0;
a[(2)- 1+(2- 1)*nmax] = 3.e0;
a[(2)- 1+(1- 1)*nmax] = 4.e0;
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"TR",0,2))  {
    // *
// *        Test error exits for the general triangular routines.
// *
// *        DTRTRI
// *
lintest_srnamc.srnamt = "DTRTRI";
lintest_infoc.infot = 1;
Dtrtri.dtrtri("/","N",0,a,0,1,info);
Chkxer.chkxer("DTRTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtrtri.dtrtri("U","/",0,a,0,1,info);
Chkxer.chkxer("DTRTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtrtri.dtrtri("U","N",-1,a,0,1,info);
Chkxer.chkxer("DTRTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtrtri.dtrtri("U","N",2,a,0,1,info);
Chkxer.chkxer("DTRTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTRTI2
// *
lintest_srnamc.srnamt = "DTRTI2";
lintest_infoc.infot = 1;
Dtrti2.dtrti2("/","N",0,a,0,1,info);
Chkxer.chkxer("DTRTI2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtrti2.dtrti2("U","/",0,a,0,1,info);
Chkxer.chkxer("DTRTI2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtrti2.dtrti2("U","N",-1,a,0,1,info);
Chkxer.chkxer("DTRTI2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtrti2.dtrti2("U","N",2,a,0,1,info);
Chkxer.chkxer("DTRTI2",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTRTRS
// *
lintest_srnamc.srnamt = "DTRTRS";
lintest_infoc.infot = 1;
Dtrtrs.dtrtrs("/","N","N",0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtrtrs.dtrtrs("U","/","N",0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtrtrs.dtrtrs("U","N","/",0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtrtrs.dtrtrs("U","N","N",-1,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtrtrs.dtrtrs("U","N","N",0,-1,a,0,1,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dtrtrs.dtrtrs("U","N","N",2,1,a,0,1,x,0,2,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dtrtrs.dtrtrs("U","N","N",2,1,a,0,2,x,0,1,info);
Chkxer.chkxer("DTRTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTRRFS
// *
lintest_srnamc.srnamt = "DTRRFS";
lintest_infoc.infot = 1;
Dtrrfs.dtrrfs("/","N","N",0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtrrfs.dtrrfs("U","/","N",0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtrrfs.dtrrfs("U","N","/",0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtrrfs.dtrrfs("U","N","N",-1,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtrrfs.dtrrfs("U","N","N",0,-1,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dtrrfs.dtrrfs("U","N","N",2,1,a,0,1,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dtrrfs.dtrrfs("U","N","N",2,1,a,0,2,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
Dtrrfs.dtrrfs("U","N","N",2,1,a,0,2,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTRRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTRCON
// *
lintest_srnamc.srnamt = "DTRCON";
lintest_infoc.infot = 1;
Dtrcon.dtrcon("/","U","N",0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTRCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtrcon.dtrcon("1","/","N",0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTRCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtrcon.dtrcon("1","U","/",0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTRCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtrcon.dtrcon("1","U","N",-1,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTRCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dtrcon.dtrcon("1","U","N",2,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTRCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DLATRS
// *
lintest_srnamc.srnamt = "DLATRS";
lintest_infoc.infot = 1;
Dlatrs.dlatrs("/","N","N","N",0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dlatrs.dlatrs("U","/","N","N",0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dlatrs.dlatrs("U","N","/","N",0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dlatrs.dlatrs("U","N","N","/",0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dlatrs.dlatrs("U","N","N","N",-1,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dlatrs.dlatrs("U","N","N","N",2,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        Test error exits for the packed triangular routines.
// *
// *        DTPTRI
// *
lintest_srnamc.srnamt = "DTPTRI";
lintest_infoc.infot = 1;
Dtptri.dtptri("/","N",0,a,0,info);
Chkxer.chkxer("DTPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtptri.dtptri("U","/",0,a,0,info);
Chkxer.chkxer("DTPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtptri.dtptri("U","N",-1,a,0,info);
Chkxer.chkxer("DTPTRI",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTPTRS
// *
lintest_srnamc.srnamt = "DTPTRS";
lintest_infoc.infot = 1;
Dtptrs.dtptrs("/","N","N",0,0,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtptrs.dtptrs("U","/","N",0,0,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtptrs.dtptrs("U","N","/",0,0,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtptrs.dtptrs("U","N","N",-1,0,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtptrs.dtptrs("U","N","N",0,-1,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dtptrs.dtptrs("U","N","N",2,1,a,0,x,0,1,info);
Chkxer.chkxer("DTPTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTPRFS
// *
lintest_srnamc.srnamt = "DTPRFS";
lintest_infoc.infot = 1;
Dtprfs.dtprfs("/","N","N",0,0,a,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtprfs.dtprfs("U","/","N",0,0,a,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtprfs.dtprfs("U","N","/",0,0,a,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtprfs.dtprfs("U","N","N",-1,0,a,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtprfs.dtprfs("U","N","N",0,-1,a,0,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dtprfs.dtprfs("U","N","N",2,1,a,0,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dtprfs.dtprfs("U","N","N",2,1,a,0,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTPRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTPCON
// *
lintest_srnamc.srnamt = "DTPCON";
lintest_infoc.infot = 1;
Dtpcon.dtpcon("/","U","N",0,a,0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtpcon.dtpcon("1","/","N",0,a,0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtpcon.dtpcon("1","U","/",0,a,0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtpcon.dtpcon("1","U","N",-1,a,0,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTPCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DLATPS
// *
lintest_srnamc.srnamt = "DLATPS";
lintest_infoc.infot = 1;
Dlatps.dlatps("/","N","N","N",0,a,0,x,0,scale,w,0,info);
Chkxer.chkxer("DLATPS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dlatps.dlatps("U","/","N","N",0,a,0,x,0,scale,w,0,info);
Chkxer.chkxer("DLATPS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dlatps.dlatps("U","N","/","N",0,a,0,x,0,scale,w,0,info);
Chkxer.chkxer("DLATPS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dlatps.dlatps("U","N","N","/",0,a,0,x,0,scale,w,0,info);
Chkxer.chkxer("DLATPS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dlatps.dlatps("U","N","N","N",-1,a,0,x,0,scale,w,0,info);
Chkxer.chkxer("DLATPS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        Test error exits for the banded triangular routines.
// *
// *        DTBTRS
// *
lintest_srnamc.srnamt = "DTBTRS";
lintest_infoc.infot = 1;
Dtbtrs.dtbtrs("/","N","N",0,0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtbtrs.dtbtrs("U","/","N",0,0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtbtrs.dtbtrs("U","N","/",0,0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtbtrs.dtbtrs("U","N","N",-1,0,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtbtrs.dtbtrs("U","N","N",0,-1,0,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dtbtrs.dtbtrs("U","N","N",0,0,-1,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dtbtrs.dtbtrs("U","N","N",2,1,1,a,0,1,x,0,2,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dtbtrs.dtbtrs("U","N","N",2,0,1,a,0,1,x,0,1,info);
Chkxer.chkxer("DTBTRS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTBRFS
// *
lintest_srnamc.srnamt = "DTBRFS";
lintest_infoc.infot = 1;
Dtbrfs.dtbrfs("/","N","N",0,0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtbrfs.dtbrfs("U","/","N",0,0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtbrfs.dtbrfs("U","N","/",0,0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtbrfs.dtbrfs("U","N","N",-1,0,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtbrfs.dtbrfs("U","N","N",0,-1,0,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dtbrfs.dtbrfs("U","N","N",0,0,-1,a,0,1,b,0,1,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dtbrfs.dtbrfs("U","N","N",2,1,1,a,0,1,b,0,2,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dtbrfs.dtbrfs("U","N","N",2,1,1,a,0,2,b,0,1,x,0,2,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dtbrfs.dtbrfs("U","N","N",2,1,1,a,0,2,b,0,2,x,0,1,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DTBRFS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DTBCON
// *
lintest_srnamc.srnamt = "DTBCON";
lintest_infoc.infot = 1;
Dtbcon.dtbcon("/","U","N",0,0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dtbcon.dtbcon("1","/","N",0,0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dtbcon.dtbcon("1","U","/",0,0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dtbcon.dtbcon("1","U","N",-1,0,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dtbcon.dtbcon("1","U","N",0,-1,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dtbcon.dtbcon("1","U","N",2,1,a,0,1,rcond,w,0,iw,0,info);
Chkxer.chkxer("DTBCON",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DLATBS
// *
lintest_srnamc.srnamt = "DLATBS";
lintest_infoc.infot = 1;
Dlatbs.dlatbs("/","N","N","N",0,0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dlatbs.dlatbs("U","/","N","N",0,0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dlatbs.dlatbs("U","N","/","N",0,0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dlatbs.dlatbs("U","N","N","/",0,0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dlatbs.dlatbs("U","N","N","N",-1,0,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dlatbs.dlatbs("U","N","N","N",1,-1,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dlatbs.dlatbs("U","N","N","N",2,1,a,0,1,x,0,scale,w,0,info);
Chkxer.chkxer("DLATBS",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
Alaesm.alaesm(path,lintest_infoc.ok.val,lintest_infoc.nout_iounit_nunit);
// *
Dummy.go_to("Derrtr",999999);
// *
// *     End of DERRTR
// *
Dummy.label("Derrtr",999999);
return;
   }
} // End class.
