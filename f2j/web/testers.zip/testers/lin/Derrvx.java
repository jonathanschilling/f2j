/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Derrvx {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     October 31, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DERRVX tests the error exits for the DOUBLE PRECISION driver routines
// *  for solving linear systems of equations.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name for the routines to be tested.
// *
// *  NUNIT   (input) INTEGER
// *          The unit number for output.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static int nmax= 4;
// *     ..
// *     .. Local Scalars ..
static StringW eq= new StringW(" ");
static String c2= new String("  ");
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static doubleW rcond= new doubleW(0.0);
// *     ..
// *     .. Local Arrays ..
static int [] ip= new int[(nmax)];
static int [] iw= new int[(nmax)];
static double [] a= new double[(nmax) * (nmax)];
static double [] af= new double[(nmax) * (nmax)];
static double [] b= new double[(nmax)];
static double [] c= new double[(nmax)];
static double [] r= new double[(nmax)];
static double [] r1= new double[(nmax)];
static double [] r2= new double[(nmax)];
static double [] w= new double[(2*nmax)];
static double [] x= new double[(nmax)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void derrvx (String path,
int nunit)  {

lintest_infoc.nout_iounit_nunit = nunit;
System.out.println();
c2 = path.substring((2)-1,3);
// *
// *     Set the variables to innocuous values.
// *
{
forloop20:
for (j = 1; j <= nmax; j++) {
{
forloop10:
for (i = 1; i <= nmax; i++) {
a[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
af[(i)- 1+(j- 1)*nmax] = 1.e0/(double)(i+j);
Dummy.label("Derrvx",10);
}              //  Close for() loop. 
}
b[(j)- 1] = 0.e0;
r1[(j)- 1] = 0.e0;
r2[(j)- 1] = 0.e0;
w[(j)- 1] = 0.e0;
x[(j)- 1] = 0.e0;
c[(j)- 1] = 0.e0;
r[(j)- 1] = 0.e0;
ip[(j)- 1] = j;
Dummy.label("Derrvx",20);
}              //  Close for() loop. 
}
lintest_infoc.ok.val = true;
// *
if (c2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        DGESV
// *
lintest_srnamc.srnamt = "DGESV ";
lintest_infoc.infot = 1;
Dgesv.dgesv(-1,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGESV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgesv.dgesv(0,-1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGESV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgesv.dgesv(2,1,a,0,1,ip,0,b,0,2,info);
Chkxer.chkxer("DGESV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgesv.dgesv(2,1,a,0,2,ip,0,b,0,1,info);
Chkxer.chkxer("DGESV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGESVX
// *
lintest_srnamc.srnamt = "DGESVX";
lintest_infoc.infot = 1;
Dgesvx.dgesvx("/","N",0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgesvx.dgesvx("N","/",0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgesvx.dgesvx("N","N",-1,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgesvx.dgesvx("N","N",0,-1,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgesvx.dgesvx("N","N",2,1,a,0,1,af,0,2,ip,0,eq,r,0,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgesvx.dgesvx("N","N",2,1,a,0,2,af,0,1,ip,0,eq,r,0,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
eq.val = "/";
Dgesvx.dgesvx("F","N",0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
eq.val = "R";
Dgesvx.dgesvx("F","N",1,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
eq.val = "C";
Dgesvx.dgesvx("F","N",1,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 14;
Dgesvx.dgesvx("N","N",2,1,a,0,2,af,0,2,ip,0,eq,r,0,c,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 16;
Dgesvx.dgesvx("N","N",2,1,a,0,2,af,0,2,ip,0,eq,r,0,c,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGESVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        DGBSV
// *
lintest_srnamc.srnamt = "DGBSV ";
lintest_infoc.infot = 1;
Dgbsv.dgbsv(-1,0,0,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbsv.dgbsv(1,-1,0,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbsv.dgbsv(1,0,-1,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbsv.dgbsv(0,0,0,-1,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbsv.dgbsv(1,1,1,0,a,0,3,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dgbsv.dgbsv(2,0,0,0,a,0,1,ip,0,b,0,1,info);
Chkxer.chkxer("DGBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGBSVX
// *
lintest_srnamc.srnamt = "DGBSVX";
lintest_infoc.infot = 1;
Dgbsvx.dgbsvx("/","N",0,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgbsvx.dgbsvx("N","/",0,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgbsvx.dgbsvx("N","N",-1,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgbsvx.dgbsvx("N","N",1,-1,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dgbsvx.dgbsvx("N","N",1,0,-1,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dgbsvx.dgbsvx("N","N",0,0,0,-1,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dgbsvx.dgbsvx("N","N",1,1,1,0,a,0,2,af,0,4,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dgbsvx.dgbsvx("N","N",1,1,1,0,a,0,3,af,0,3,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
eq.val = "/";
Dgbsvx.dgbsvx("F","N",0,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 13;
eq.val = "R";
Dgbsvx.dgbsvx("F","N",1,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 14;
eq.val = "C";
Dgbsvx.dgbsvx("F","N",1,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 16;
Dgbsvx.dgbsvx("N","N",2,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 18;
Dgbsvx.dgbsvx("N","N",2,0,0,0,a,0,1,af,0,1,ip,0,eq,r,0,c,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        DGTSV
// *
lintest_srnamc.srnamt = "DGTSV ";
lintest_infoc.infot = 1;
Dgtsv.dgtsv(-1,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DGTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgtsv.dgtsv(0,-1,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DGTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dgtsv.dgtsv(2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DGTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DGTSVX
// *
lintest_srnamc.srnamt = "DGTSVX";
lintest_infoc.infot = 1;
Dgtsvx.dgtsvx("/","N",0,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dgtsvx.dgtsvx("N","/",0,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dgtsvx.dgtsvx("N","N",-1,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dgtsvx.dgtsvx("N","N",0,-1,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 14;
Dgtsvx.dgtsvx("N","N",2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 16;
Dgtsvx.dgtsvx("N","N",2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,a,(1)- 1+(3- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,af,(1)- 1+(3- 1)*nmax,af,(1)- 1+(4- 1)*nmax,ip,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DGTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PO",0,2))  {
    // *
// *        DPOSV
// *
lintest_srnamc.srnamt = "DPOSV ";
lintest_infoc.infot = 1;
Dposv.dposv("/",0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dposv.dposv("U",-1,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dposv.dposv("U",0,-1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPOSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dposv.dposv("U",2,0,a,0,1,b,0,2,info);
Chkxer.chkxer("DPOSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dposv.dposv("U",2,0,a,0,2,b,0,1,info);
Chkxer.chkxer("DPOSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPOSVX
// *
lintest_srnamc.srnamt = "DPOSVX";
lintest_infoc.infot = 1;
Dposvx.dposvx("/","U",0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dposvx.dposvx("N","/",0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dposvx.dposvx("N","U",-1,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dposvx.dposvx("N","U",0,-1,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dposvx.dposvx("N","U",2,0,a,0,1,af,0,2,eq,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dposvx.dposvx("N","U",2,0,a,0,2,af,0,1,eq,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
eq.val = "/";
Dposvx.dposvx("F","U",0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
eq.val = "Y";
Dposvx.dposvx("F","U",1,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dposvx.dposvx("N","U",2,0,a,0,2,af,0,2,eq,c,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 14;
Dposvx.dposvx("N","U",2,0,a,0,2,af,0,2,eq,c,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPOSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PP",0,2))  {
    // *
// *        DPPSV
// *
lintest_srnamc.srnamt = "DPPSV ";
lintest_infoc.infot = 1;
Dppsv.dppsv("/",0,0,a,0,b,0,1,info);
Chkxer.chkxer("DPPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dppsv.dppsv("U",-1,0,a,0,b,0,1,info);
Chkxer.chkxer("DPPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dppsv.dppsv("U",0,-1,a,0,b,0,1,info);
Chkxer.chkxer("DPPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dppsv.dppsv("U",2,0,a,0,b,0,1,info);
Chkxer.chkxer("DPPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPPSVX
// *
lintest_srnamc.srnamt = "DPPSVX";
lintest_infoc.infot = 1;
Dppsvx.dppsvx("/","U",0,0,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dppsvx.dppsvx("N","/",0,0,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dppsvx.dppsvx("N","U",-1,0,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dppsvx.dppsvx("N","U",0,-1,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
eq.val = "/";
Dppsvx.dppsvx("F","U",0,0,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
eq.val = "Y";
Dppsvx.dppsvx("F","U",1,0,a,0,af,0,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
Dppsvx.dppsvx("N","U",2,0,a,0,af,0,eq,c,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 12;
Dppsvx.dppsvx("N","U",2,0,a,0,af,0,eq,c,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        DPBSV
// *
lintest_srnamc.srnamt = "DPBSV ";
lintest_infoc.infot = 1;
Dpbsv.dpbsv("/",0,0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbsv.dpbsv("U",-1,0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbsv.dpbsv("U",1,-1,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpbsv.dpbsv("U",0,0,-1,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dpbsv.dpbsv("U",1,1,0,a,0,1,b,0,2,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dpbsv.dpbsv("U",2,0,0,a,0,1,b,0,1,info);
Chkxer.chkxer("DPBSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPBSVX
// *
lintest_srnamc.srnamt = "DPBSVX";
lintest_infoc.infot = 1;
Dpbsvx.dpbsvx("/","U",0,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dpbsvx.dpbsvx("N","/",0,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dpbsvx.dpbsvx("N","U",-1,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dpbsvx.dpbsvx("N","U",1,-1,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 5;
Dpbsvx.dpbsvx("N","U",0,0,-1,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dpbsvx.dpbsvx("N","U",1,1,0,a,0,1,af,0,2,eq,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dpbsvx.dpbsvx("N","U",1,1,0,a,0,2,af,0,1,eq,c,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 10;
eq.val = "/";
Dpbsvx.dpbsvx("F","U",0,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
eq.val = "Y";
Dpbsvx.dpbsvx("F","U",1,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 13;
Dpbsvx.dpbsvx("N","U",2,0,0,a,0,1,af,0,1,eq,c,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 15;
Dpbsvx.dpbsvx("N","U",2,0,0,a,0,1,af,0,1,eq,c,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DPBSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        DPTSV
// *
lintest_srnamc.srnamt = "DPTSV ";
lintest_infoc.infot = 1;
Dptsv.dptsv(-1,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DPTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dptsv.dptsv(0,-1,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DPTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dptsv.dptsv(2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,b,0,1,info);
Chkxer.chkxer("DPTSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DPTSVX
// *
lintest_srnamc.srnamt = "DPTSVX";
lintest_infoc.infot = 1;
Dptsvx.dptsvx("/",0,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dptsvx.dptsvx("N",-1,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dptsvx.dptsvx("N",0,-1,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dptsvx.dptsvx("N",2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
Dptsvx.dptsvx("N",2,0,a,(1)- 1+(1- 1)*nmax,a,(1)- 1+(2- 1)*nmax,af,(1)- 1+(1- 1)*nmax,af,(1)- 1+(2- 1)*nmax,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,info);
Chkxer.chkxer("DPTSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SY",0,2))  {
    // *
// *        DSYSV
// *
lintest_srnamc.srnamt = "DSYSV ";
lintest_infoc.infot = 1;
Dsysv.dsysv("/",0,0,a,0,1,ip,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DSYSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsysv.dsysv("U",-1,0,a,0,1,ip,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DSYSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsysv.dsysv("U",0,-1,a,0,1,ip,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DSYSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dsysv.dsysv("U",2,0,a,0,2,ip,0,b,0,1,w,0,1,info);
Chkxer.chkxer("DSYSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSYSVX
// *
lintest_srnamc.srnamt = "DSYSVX";
lintest_infoc.infot = 1;
Dsysvx.dsysvx("/","U",0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dsysvx.dsysvx("N","/",0,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dsysvx.dsysvx("N","U",-1,0,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dsysvx.dsysvx("N","U",0,-1,a,0,1,af,0,1,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,1,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 6;
Dsysvx.dsysvx("N","U",2,0,a,0,1,af,0,2,ip,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,4,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 8;
Dsysvx.dsysvx("N","U",2,0,a,0,2,af,0,1,ip,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,4,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
Dsysvx.dsysvx("N","U",2,0,a,0,2,af,0,2,ip,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,4,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 13;
Dsysvx.dsysvx("N","U",2,0,a,0,2,af,0,2,ip,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,4,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 18;
Dsysvx.dsysvx("N","U",2,0,a,0,2,af,0,2,ip,0,b,0,2,x,0,2,rcond,r1,0,r2,0,w,0,3,iw,0,info);
Chkxer.chkxer("DSYSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        DSPSV
// *
lintest_srnamc.srnamt = "DSPSV ";
lintest_infoc.infot = 1;
Dspsv.dspsv("/",0,0,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dspsv.dspsv("U",-1,0,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dspsv.dspsv("U",0,-1,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 7;
Dspsv.dspsv("U",2,0,a,0,ip,0,b,0,1,info);
Chkxer.chkxer("DSPSV ",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
// *
// *        DSPSVX
// *
lintest_srnamc.srnamt = "DSPSVX";
lintest_infoc.infot = 1;
Dspsvx.dspsvx("/","U",0,0,a,0,af,0,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 2;
Dspsvx.dspsvx("N","/",0,0,a,0,af,0,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 3;
Dspsvx.dspsvx("N","U",-1,0,a,0,af,0,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 4;
Dspsvx.dspsvx("N","U",0,-1,a,0,af,0,ip,0,b,0,1,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 9;
Dspsvx.dspsvx("N","U",2,0,a,0,af,0,ip,0,b,0,1,x,0,2,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
lintest_infoc.infot = 11;
Dspsvx.dspsvx("N","U",2,0,a,0,af,0,ip,0,b,0,2,x,0,1,rcond,r1,0,r2,0,w,0,iw,0,info);
Chkxer.chkxer("DSPSVX",lintest_infoc.infot,lintest_infoc.nout_iounit_nunit,lintest_infoc.lerr,lintest_infoc.ok);
}              // Close else if()
// *
// *     Print a summary line.
// *
if (lintest_infoc.ok.val)  {
    System.out.println(" " + (path) + " "  + " drivers passed the tests of the error exits" );
}              // Close if()
else  {
  System.out.println(" *** "  + (path) + " "  + " drivers failed the tests of the error "  + "exits ***" );
}              //  Close else.
// *
// *
Dummy.go_to("Derrvx",999999);
// *
// *     End of DERRVX
// *
Dummy.label("Derrvx",999999);
return;
   }
} // End class.
