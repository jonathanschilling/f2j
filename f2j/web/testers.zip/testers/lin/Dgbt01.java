/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgbt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBT01 reconstructs a band matrix  A  from its L*U factorization and
// *  computes the residual:
// *     norm(L*U - A) / ( N * norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  The expression L*U - A is computed one column at a time, so A and
// *  AFAC are not modified.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  A       (input/output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original matrix A in band storage, stored in rows 1 to
// *          KL+KU+1.
// *
// *  LDA     (input) INTEGER.
// *          The leading dimension of the array A.  LDA >= max(1,KL+KU+1).
// *
// *  AFAC    (input) DOUBLE PRECISION array, dimension (LDAFAC,N)
// *          The factored form of the matrix A.  AFAC contains the banded
// *          factors L and U from the L*U factorization, as computed by
// *          DGBTRF.  U is stored as an upper triangular band matrix with
// *          KL+KU superdiagonals in rows 1 to KL+KU+1, and the
// *          multipliers used during the factorization are stored in rows
// *          KL+KU+2 to 2*KL+KU+1.  See DGBTRF for further details.
// *
// *  LDAFAC  (input) INTEGER
// *          The leading dimension of the array AFAC.
// *          LDAFAC >= max(1,2*KL*KU+1).
// *
// *  IPIV    (input) INTEGER array, dimension (min(M,N))
// *          The pivot indices from DGBTRF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*KL+KU+1)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(L*U - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int i1= 0;
static int i2= 0;
static int il= 0;
static int ip= 0;
static int iw= 0;
static int j= 0;
static int jl= 0;
static int ju= 0;
static int jua= 0;
static int kd= 0;
static int lenj= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if M = 0 or N = 0.
// *

public static void dgbt01 (int m,
int n,
int kl,
int ku,
double [] a, int _a_offset,
int lda,
double [] afac, int _afac_offset,
int ldafac,
int [] ipiv, int _ipiv_offset,
double [] work, int _work_offset,
doubleW resid)  {

resid.val = zero;
if (m <= 0 || n <= 0)  
    Dummy.go_to("Dgbt01",999999);
// *
// *     Determine EPS and the norm of A.
// *
eps = Dlamch.dlamch("Epsilon");
kd = ku+1;
anorm = zero;
{
forloop10:
for (j = 1; j <= n; j++) {
i1 = (int)(Math.max(kd+1-j, 1) );
i2 = (int)(Math.min(kd+m-j, kl+kd) );
if (i2 >= i1)  
    anorm = Math.max(anorm, Dasum.dasum(i2-i1+1,a,(i1)- 1+(j- 1)*lda+ _a_offset,1)) ;
Dummy.label("Dgbt01",10);
}              //  Close for() loop. 
}
// *
// *     Compute one column at a time of L*U - A.
// *
kd = kl+ku+1;
{
forloop40:
for (j = 1; j <= n; j++) {
// *
// *        Copy the J-th column of U to WORK.
// *
ju = (int)(Math.min(kl+ku, j-1) );
jl = (int)(Math.min(kl, m-j) );
lenj = (int)(Math.min(m, j) -j+ju+1);
if (lenj > 0)  {
    Dcopy.dcopy(lenj,afac,(kd-ju)- 1+(j- 1)*ldafac+ _afac_offset,1,work,_work_offset,1);
{
forloop20:
for (i = lenj+1; i <= ju+jl+1; i++) {
work[(i)- 1+ _work_offset] = zero;
Dummy.label("Dgbt01",20);
}              //  Close for() loop. 
}
// *
// *           Multiply by the unit lower triangular matrix L.  Note that L
// *           is stored as a product of transformations and permutations.
// *
{
int _i_inc = -1;
forloop30:
for (i = (int)(Math.min(m-1, j) ); (_i_inc < 0) ? i >= j-ju : i <= j-ju; i += _i_inc) {
il = (int)(Math.min(kl, m-i) );
if (il > 0)  {
    iw = i-j+ju+1;
t = work[(iw)- 1+ _work_offset];
Daxpy.daxpy(il,t,afac,(kd+1)- 1+(i- 1)*ldafac+ _afac_offset,1,work,(iw+1)- 1+ _work_offset,1);
ip = ipiv[(i)- 1+ _ipiv_offset];
if (i != ip)  {
    ip = ip-j+ju+1;
work[(iw)- 1+ _work_offset] = work[(ip)- 1+ _work_offset];
work[(ip)- 1+ _work_offset] = t;
}              // Close if()
}              // Close if()
Dummy.label("Dgbt01",30);
}              //  Close for() loop. 
}
// *
// *           Subtract the corresponding column of A.
// *
jua = (int)(Math.min(ju, ku) );
if (jua+jl+1 > 0)  
    Daxpy.daxpy(jua+jl+1,-one,a,(ku+1-jua)- 1+(j- 1)*lda+ _a_offset,1,work,(ju+1-jua)- 1+ _work_offset,1);
// *
// *           Compute the 1-norm of the column.
// *
resid.val = Math.max(resid.val, Dasum.dasum(ju+jl+1,work,_work_offset,1)) ;
}              // Close if()
Dummy.label("Dgbt01",40);
}              //  Close for() loop. 
}
// *
// *     Compute norm( L*U - A ) / ( N * norm(A) * EPS )
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = ((resid.val/(double)(n))/anorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dgbt01",999999);
// *
// *     End of DGBT01
// *
Dummy.label("Dgbt01",999999);
return;
   }
} // End class.
