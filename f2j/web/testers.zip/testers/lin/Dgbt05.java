/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgbt05 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGBT05 tests the error bounds from iterative refinement for the
// *  computed solution to a system of equations op(A)*X = B, where A is a
// *  general band matrix of order n with kl subdiagonals and ku
// *  superdiagonals and op(A) = A or A**T, depending on TRANS.
// *
// *  RESLTS(1) = test of the error bound
// *            = norm(X - XACT) / ( norm(X) * FERR )
// *
// *  A large value is returned if this ratio is not less than one.
// *
// *  RESLTS(2) = residual from the iterative refinement routine
// *            = the maximum of BERR / ( NZ*EPS + (*) ), where
// *              (*) = NZ*UNFL / (min_i (abs(op(A))*abs(X) +abs(b))_i )
// *              and NZ = max. number of nonzeros in any row of A, plus 1
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations.
// *          = 'N':  A * X = B     (No transpose)
// *          = 'T':  A**T * X = B  (Transpose)
// *          = 'C':  A**H * X = B  (Conjugate transpose = Transpose)
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices X, B, and XACT, and the
// *          order of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          The number of subdiagonals within the band of A.  KL >= 0.
// *
// *  KU      (input) INTEGER
// *          The number of superdiagonals within the band of A.  KU >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of the matrices X, B, and XACT.
// *          NRHS >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The original band matrix A, stored in rows 1 to KL+KU+1.
// *          The j-th column of A is stored in the j-th column of the
// *          array AB as follows:
// *          AB(ku+1+i-j,j) = A(i,j) for max(1,j-ku)<=i<=min(n,j+kl).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KL+KU+1.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vectors for the system of linear
// *          equations.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors.  Each vector is stored as a
// *          column of the matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  XACT    (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The exact solution vectors.  Each vector is stored as a
// *          column of the matrix XACT.
// *
// *  LDXACT  (input) INTEGER
// *          The leading dimension of the array XACT.  LDXACT >= max(1,N).
// *
// *  FERR    (input) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bounds for each solution vector
// *          X.  If XTRUE is the true solution, FERR bounds the magnitude
// *          of the largest entry in (X - XTRUE) divided by the magnitude
// *          of the largest entry in X.
// *
// *  BERR    (input) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector (i.e., the smallest relative change in any entry of A
// *          or B that makes X an exact solution).
// *
// *  RESLTS  (output) DOUBLE PRECISION array, dimension (2)
// *          The maximum over the NRHS solution vectors of the ratios:
// *          RESLTS(1) = norm(X - XACT) / ( norm(X) * FERR )
// *          RESLTS(2) = BERR / ( NZ*EPS + (*) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static int i= 0;
static int imax= 0;
static int j= 0;
static int k= 0;
static int nz= 0;
static double axbi= 0.0;
static double diff= 0.0;
static double eps= 0.0;
static double errbnd= 0.0;
static double ovfl= 0.0;
static double tmp= 0.0;
static double unfl= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0.
// *

public static void dgbt05 (String trans,
int n,
int kl,
int ku,
int nrhs,
double [] ab, int _ab_offset,
int ldab,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
double [] xact, int _xact_offset,
int ldxact,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] reslts, int _reslts_offset)  {

if (n <= 0 || nrhs <= 0)  {
    reslts[(1)- 1+ _reslts_offset] = zero;
reslts[(2)- 1+ _reslts_offset] = zero;
Dummy.go_to("Dgbt05",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
unfl = Dlamch.dlamch("Safe minimum");
ovfl = one/unfl;
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
nz = (int)(Math.min(kl+ku+2, n+1) );
// *
// *     Test 1:  Compute the maximum of
// *        norm(X - XACT) / ( norm(X) * FERR )
// *     over all the vectors X and XACT using the infinity-norm.
// *
errbnd = zero;
{
forloop30:
for (j = 1; j <= nrhs; j++) {
imax = Idamax.idamax(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
xnorm = Math.max(Math.abs(x[(imax)- 1+(j- 1)*ldx+ _x_offset]), unfl) ;
diff = zero;
{
forloop10:
for (i = 1; i <= n; i++) {
diff = Math.max(diff, Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset]-xact[(i)- 1+(j- 1)*ldxact+ _xact_offset])) ;
Dummy.label("Dgbt05",10);
}              //  Close for() loop. 
}
// *
if (xnorm > one)  {
    Dummy.go_to("Dgbt05",20);
}              // Close if()
else if (diff <= ovfl*xnorm)  {
    Dummy.go_to("Dgbt05",20);
}              // Close else if()
else  {
  errbnd = one/eps;
continue forloop30;
}              //  Close else.
// *
label20:
   Dummy.label("Dgbt05",20);
if (diff/xnorm <= ferr[(j)- 1+ _ferr_offset])  {
    errbnd = Math.max(errbnd, (diff/xnorm)/ferr[(j)- 1+ _ferr_offset]) ;
}              // Close if()
else  {
  errbnd = one/eps;
}              //  Close else.
Dummy.label("Dgbt05",30);
}              //  Close for() loop. 
}
reslts[(1)- 1+ _reslts_offset] = errbnd;
// *
// *     Test 2:  Compute the maximum of BERR / ( NZ*EPS + (*) ), where
// *     (*) = NZ*UNFL / (min_i (abs(op(A))*abs(X) +abs(b))_i )
// *
{
forloop70:
for (k = 1; k <= nrhs; k++) {
{
forloop60:
for (i = 1; i <= n; i++) {
tmp = Math.abs(b[(i)- 1+(k- 1)*ldb+ _b_offset]);
if (notran)  {
    {
forloop40:
for (j = (int)(Math.max(i-kl, 1) ); j <= Math.min(i+ku, n) ; j++) {
tmp = tmp+Math.abs(ab[(ku+1+i-j)- 1+(j- 1)*ldab+ _ab_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
Dummy.label("Dgbt05",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop50:
for (j = (int)(Math.max(i-ku, 1) ); j <= Math.min(i+kl, n) ; j++) {
tmp = tmp+Math.abs(ab[(ku+1+j-i)- 1+(i- 1)*ldab+ _ab_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
Dummy.label("Dgbt05",50);
}              //  Close for() loop. 
}
}              //  Close else.
if (i == 1)  {
    axbi = tmp;
}              // Close if()
else  {
  axbi = Math.min(axbi, tmp) ;
}              //  Close else.
Dummy.label("Dgbt05",60);
}              //  Close for() loop. 
}
tmp = berr[(k)- 1+ _berr_offset]/(nz*eps+nz*unfl/Math.max(axbi, nz*unfl) );
if (k == 1)  {
    reslts[(2)- 1+ _reslts_offset] = tmp;
}              // Close if()
else  {
  reslts[(2)- 1+ _reslts_offset] = Math.max(reslts[(2)- 1+ _reslts_offset], tmp) ;
}              //  Close else.
Dummy.label("Dgbt05",70);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dgbt05",999999);
// *
// *     End of DGBT05
// *
Dummy.label("Dgbt05",999999);
return;
   }
} // End class.
