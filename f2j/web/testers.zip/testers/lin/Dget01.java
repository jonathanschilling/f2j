/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET01 reconstructs a matrix A from its L*U factorization and
// *  computes the residual
// *     norm(L*U - A) / ( N * norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original M x N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  AFAC    (input/output) DOUBLE PRECISION array, dimension (LDAFAC,N)
// *          The factored form of the matrix A.  AFAC contains the factors
// *          L and U from the L*U factorization as computed by DGETRF.
// *          Overwritten with the reconstructed matrix, and then with the
// *          difference L*U - A.
// *
// *  LDAFAC  (input) INTEGER
// *          The leading dimension of the array AFAC.  LDAFAC >= max(1,M).
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DGETRF.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(L*U - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int k= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if M = 0 or N = 0.
// *

public static void dget01 (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] afac, int _afac_offset,
int ldafac,
int [] ipiv, int _ipiv_offset,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (m <= 0 || n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dget01",999999);
}              // Close if()
// *
// *     Determine EPS and the norm of A.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset);
// *
// *     Compute the product L*U and overwrite AFAC with the result.
// *     A column at a time of the product is obtained, starting with
// *     column N.
// *
{
int _k_inc = -1;
forloop10:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
if (k > m)  {
    Dtrmv.dtrmv("Lower","No transpose","Unit",m,afac,_afac_offset,ldafac,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
}              // Close if()
else  {
  // *
// *           Compute elements (K+1:M,K)
// *
t = afac[(k)- 1+(k- 1)*ldafac+ _afac_offset];
if (k+1 <= m)  {
    Dscal.dscal(m-k,t,afac,(k+1)- 1+(k- 1)*ldafac+ _afac_offset,1);
Dgemv.dgemv("No transpose",m-k,k-1,one,afac,(k+1)- 1+(1- 1)*ldafac+ _afac_offset,ldafac,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1,one,afac,(k+1)- 1+(k- 1)*ldafac+ _afac_offset,1);
}              // Close if()
// *
// *           Compute the (K,K) element
// *
afac[(k)- 1+(k- 1)*ldafac+ _afac_offset] = t+Ddot.ddot(k-1,afac,(k)- 1+(1- 1)*ldafac+ _afac_offset,ldafac,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
// *
// *           Compute elements (1:K-1,K)
// *
Dtrmv.dtrmv("Lower","No transpose","Unit",k-1,afac,_afac_offset,ldafac,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
}              //  Close else.
Dummy.label("Dget01",10);
}              //  Close for() loop. 
}
Dlaswp.dlaswp(n,afac,_afac_offset,ldafac,1,(int) ( Math.min(m, n) ),ipiv,_ipiv_offset,-1);
// *
// *     Compute the difference  L*U - A  and store in AFAC.
// *
{
forloop30:
for (j = 1; j <= n; j++) {
{
forloop20:
for (i = 1; i <= m; i++) {
afac[(i)- 1+(j- 1)*ldafac+ _afac_offset] = afac[(i)- 1+(j- 1)*ldafac+ _afac_offset]-a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dget01",20);
}              //  Close for() loop. 
}
Dummy.label("Dget01",30);
}              //  Close for() loop. 
}
// *
// *     Compute norm( L*U - A ) / ( N * norm(A) * EPS )
// *
resid.val = Dlange.dlange("1",m,n,afac,_afac_offset,ldafac,rwork,_rwork_offset);
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = ((resid.val/(double)(n))/anorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dget01",999999);
// *
// *     End of DGET01
// *
Dummy.label("Dget01",999999);
return;
   }
} // End class.
