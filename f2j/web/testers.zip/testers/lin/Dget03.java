/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET03 computes the residual for a general matrix times its inverse:
// *     norm( I - A*AINV ) / ( N * norm(A) * norm(AINV) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original N x N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  AINV    (input) DOUBLE PRECISION array, dimension (LDAINV,N)
// *          The inverse of the matrix A.
// *
// *  LDAINV  (input) INTEGER
// *          The leading dimension of the array AINV.  LDAINV >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK,N)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of the array WORK.  LDWORK >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of A, computed as
// *          ( 1/norm(A) ) / norm(AINV).
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(I - A*AINV) / ( N * norm(A) * norm(AINV) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dget03 (int n,
double [] a, int _a_offset,
int lda,
double [] ainv, int _ainv_offset,
int ldainv,
double [] work, int _work_offset,
int ldwork,
double [] rwork, int _rwork_offset,
doubleW rcond,
doubleW resid)  {

if (n <= 0)  {
    rcond.val = one;
resid.val = zero;
Dummy.go_to("Dget03",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0 or AINVNM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlange.dlange("1",n,n,a,_a_offset,lda,rwork,_rwork_offset);
ainvnm = Dlange.dlange("1",n,n,ainv,_ainv_offset,ldainv,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcond.val = zero;
resid.val = one/eps;
Dummy.go_to("Dget03",999999);
}              // Close if()
rcond.val = (one/anorm)/ainvnm;
// *
// *     Compute I - A * AINV
// *
Dgemm.dgemm("No transpose","No transpose",n,n,n,-one,a,_a_offset,lda,ainv,_ainv_offset,ldainv,zero,work,_work_offset,ldwork);
{
forloop10:
for (i = 1; i <= n; i++) {
work[(i)- 1+(i- 1)*ldwork+ _work_offset] = one+work[(i)- 1+(i- 1)*ldwork+ _work_offset];
Dummy.label("Dget03",10);
}              //  Close for() loop. 
}
// *
// *     Compute norm(I - A*AINV) / (N * norm(A) * norm(AINV) * EPS)
// *
resid.val = Dlange.dlange("1",n,n,work,_work_offset,ldwork,rwork,_rwork_offset);
// *
resid.val = ((resid.val*rcond.val)/eps)/(double)(n);
// *
Dummy.go_to("Dget03",999999);
// *
// *     End of DGET03
// *
Dummy.label("Dget03",999999);
return;
   }
} // End class.
