/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dget04 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET04 computes the difference between a computed solution and the
// *  true solution to a system of linear equations.
// *
// *  RESID =  ( norm(X-XACT) * RCOND ) / ( norm(XACT) * EPS ),
// *  where RCOND is the reciprocal of the condition number and EPS is the
// *  machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices X and XACT.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of the matrices X and XACT.  NRHS >= 0.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors.  Each vector is stored as a
// *          column of the matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  XACT    (input) DOUBLE PRECISION array, dimension( LDX, NRHS )
// *          The exact solution vectors.  Each vector is stored as a
// *          column of the matrix XACT.
// *
// *  LDXACT  (input) INTEGER
// *          The leading dimension of the array XACT.  LDXACT >= max(1,N).
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          The reciprocal of the condition number of the coefficient
// *          matrix in the system of equations.
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the NRHS solution vectors of
// *          ( norm(X-XACT) * RCOND ) / ( norm(XACT) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ix= 0;
static int j= 0;
static double diffnm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0.
// *

public static void dget04 (int n,
int nrhs,
double [] x, int _x_offset,
int ldx,
double [] xact, int _xact_offset,
int ldxact,
double rcond,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dget04",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if RCOND is invalid.
// *
eps = Dlamch.dlamch("Epsilon");
if (rcond < zero)  {
    resid.val = 1.0e0/eps;
Dummy.go_to("Dget04",999999);
}              // Close if()
// *
// *     Compute the maximum of
// *        norm(X - XACT) / ( norm(XACT) * EPS )
// *     over all the vectors X and XACT .
// *
resid.val = zero;
{
forloop20:
for (j = 1; j <= nrhs; j++) {
ix = Idamax.idamax(n,xact,(1)- 1+(j- 1)*ldxact+ _xact_offset,1);
xnorm = Math.abs(xact[(ix)- 1+(j- 1)*ldxact+ _xact_offset]);
diffnm = zero;
{
forloop10:
for (i = 1; i <= n; i++) {
diffnm = Math.max(diffnm, Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset]-xact[(i)- 1+(j- 1)*ldxact+ _xact_offset])) ;
Dummy.label("Dget04",10);
}              //  Close for() loop. 
}
if (xnorm <= zero)  {
    if (diffnm > zero)  
    resid.val = 1.0e0/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, (diffnm/xnorm)*rcond) ;
}              //  Close else.
Dummy.label("Dget04",20);
}              //  Close for() loop. 
}
if (resid.val*eps < 1.0e0)  
    resid.val = resid.val/eps;
// *
Dummy.go_to("Dget04",999999);
// *
// *     End of DGET04
// *
Dummy.label("Dget04",999999);
return;
   }
} // End class.
