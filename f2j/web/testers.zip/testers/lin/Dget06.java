/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dget06 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGET06 computes a test ratio to compare two values for RCOND.
// *
// *  Arguments
// *  ==========
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          The estimate of the reciprocal of the condition number of A,
// *          as computed by DGECON.
// *
// *  RCONDC  (input) DOUBLE PRECISION
// *          The reciprocal of the condition number of A, computed as
// *          ( 1/norm(A) ) / norm(inv(A)).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static double eps= 0.0;
static double rat= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dget06 = 0.0;


public static double dget06 (double rcond,
double rcondc)  {

eps = Dlamch.dlamch("Epsilon");
if (rcond > zero)  {
    if (rcondc > zero)  {
    rat = Math.max(rcond, rcondc) /Math.min(rcond, rcondc) -(one-eps);
}              // Close if()
else  {
  rat = rcond/eps;
}              //  Close else.
}              // Close if()
else  {
  if (rcondc > zero)  {
    rat = rcondc/eps;
}              // Close if()
else  {
  rat = zero;
}              //  Close else.
}              //  Close else.
dget06 = rat;
Dummy.go_to("Dget06",999999);
// *
// *     End of DGET06
// *
Dummy.label("Dget06",999999);
return dget06;
   }
} // End class.
