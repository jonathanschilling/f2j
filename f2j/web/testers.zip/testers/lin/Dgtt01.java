/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dgtt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DGTT01 reconstructs a tridiagonal matrix A from its LU factorization
// *  and computes the residual
// *     norm(L*U - A) / ( norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGTER
// *          The order of the matrix A.  N >= 0.
// *
// *  DL      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) sub-diagonal elements of A.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The diagonal elements of A.
// *
// *  DU      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) super-diagonal elements of A.
// *
// *  DLF     (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) multipliers that define the matrix L from the
// *          LU factorization of A.
// *
// *  DF      (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the upper triangular matrix U from
// *          the LU factorization of A.
// *
// *  DUF     (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) elements of the first super-diagonal of U.
// *
// *  DU2F    (input) DOUBLE PRECISION array, dimension (N-2)
// *          The (n-2) elements of the second super-diagonal of U.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices; for 1 <= i <= n, row i of the matrix was
// *          interchanged with row IPIV(i).  IPIV(i) will always be either
// *          i or i+1; IPIV(i) = i indicates a row interchange was not
// *          required.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK,N)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of the array WORK.  LDWORK >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The scaled residual:  norm(L*U - A) / (norm(A) * EPS)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int ip= 0;
static int j= 0;
static int lastj= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double li= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dgtt01 (int n,
double [] dl, int _dl_offset,
double [] d, int _d_offset,
double [] du, int _du_offset,
double [] dlf, int _dlf_offset,
double [] df, int _df_offset,
double [] duf, int _duf_offset,
double [] du2, int _du2_offset,
int [] ipiv, int _ipiv_offset,
double [] work, int _work_offset,
int ldwork,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dgtt01",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the matrix U to WORK.
// *
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= n; i++) {
work[(i)- 1+(j- 1)*ldwork+ _work_offset] = zero;
Dummy.label("Dgtt01",10);
}              //  Close for() loop. 
}
Dummy.label("Dgtt01",20);
}              //  Close for() loop. 
}
{
forloop30:
for (i = 1; i <= n; i++) {
if (i == 1)  {
    work[(i)- 1+(i- 1)*ldwork+ _work_offset] = df[(i)- 1+ _df_offset];
if (n >= 2)  
    work[(i)- 1+(i+1- 1)*ldwork+ _work_offset] = duf[(i)- 1+ _duf_offset];
if (n >= 3)  
    work[(i)- 1+(i+2- 1)*ldwork+ _work_offset] = du2[(i)- 1+ _du2_offset];
}              // Close if()
else if (i == n)  {
    work[(i)- 1+(i- 1)*ldwork+ _work_offset] = df[(i)- 1+ _df_offset];
}              // Close else if()
else  {
  work[(i)- 1+(i- 1)*ldwork+ _work_offset] = df[(i)- 1+ _df_offset];
work[(i)- 1+(i+1- 1)*ldwork+ _work_offset] = duf[(i)- 1+ _duf_offset];
if (i < n-1)  
    work[(i)- 1+(i+2- 1)*ldwork+ _work_offset] = du2[(i)- 1+ _du2_offset];
}              //  Close else.
Dummy.label("Dgtt01",30);
}              //  Close for() loop. 
}
// *
// *     Multiply on the left by L.
// *
lastj = n;
{
int _i_inc = -1;
forloop40:
for (i = n-1; (_i_inc < 0) ? i >= 1 : i <= 1; i += _i_inc) {
li = dlf[(i)- 1+ _dlf_offset];
Daxpy.daxpy(lastj-i+1,li,work,(i)- 1+(i- 1)*ldwork+ _work_offset,ldwork,work,(i+1)- 1+(i- 1)*ldwork+ _work_offset,ldwork);
ip = ipiv[(i)- 1+ _ipiv_offset];
if (ip == i)  {
    lastj = (int)(Math.min(i+2, n) );
}              // Close if()
else  {
  Dswap.dswap(lastj-i+1,work,(i)- 1+(i- 1)*ldwork+ _work_offset,ldwork,work,(i+1)- 1+(i- 1)*ldwork+ _work_offset,ldwork);
}              //  Close else.
Dummy.label("Dgtt01",40);
}              //  Close for() loop. 
}
// *
// *     Subtract the matrix A.
// *
work[(1)- 1+(1- 1)*ldwork+ _work_offset] = work[(1)- 1+(1- 1)*ldwork+ _work_offset]-d[(1)- 1+ _d_offset];
if (n > 1)  {
    work[(1)- 1+(2- 1)*ldwork+ _work_offset] = work[(1)- 1+(2- 1)*ldwork+ _work_offset]-du[(1)- 1+ _du_offset];
work[(n)- 1+(n-1- 1)*ldwork+ _work_offset] = work[(n)- 1+(n-1- 1)*ldwork+ _work_offset]-dl[(n-1)- 1+ _dl_offset];
work[(n)- 1+(n- 1)*ldwork+ _work_offset] = work[(n)- 1+(n- 1)*ldwork+ _work_offset]-d[(n)- 1+ _d_offset];
{
forloop50:
for (i = 2; i <= n-1; i++) {
work[(i)- 1+(i-1- 1)*ldwork+ _work_offset] = work[(i)- 1+(i-1- 1)*ldwork+ _work_offset]-dl[(i-1)- 1+ _dl_offset];
work[(i)- 1+(i- 1)*ldwork+ _work_offset] = work[(i)- 1+(i- 1)*ldwork+ _work_offset]-d[(i)- 1+ _d_offset];
work[(i)- 1+(i+1- 1)*ldwork+ _work_offset] = work[(i)- 1+(i+1- 1)*ldwork+ _work_offset]-du[(i)- 1+ _du_offset];
Dummy.label("Dgtt01",50);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Compute the 1-norm of the tridiagonal matrix A.
// *
anorm = Dlangt.dlangt("1",n,dl,_dl_offset,d,_d_offset,du,_du_offset);
// *
// *     Compute the 1-norm of WORK, which is only guaranteed to be
// *     upper Hessenberg.
// *
resid.val = Dlanhs.dlanhs("1",n,work,_work_offset,ldwork,rwork,_rwork_offset);
// *
// *     Compute norm(L*U - A) / (norm(A) * EPS)
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = (resid.val/anorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dgtt01",999999);
// *
// *     End of DGTT01
// *
Dummy.label("Dgtt01",999999);
return;
   }
} // End class.
