/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlarhs {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLARHS chooses a set of NRHS random solution vectors and sets
// *  up the right hand sides for the linear system
// *     op( A ) * X = B,
// *  where op( A ) may be A or A' (transpose of A).
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The type of the real matrix A.  PATH may be given in any
// *          combination of upper and lower case.  Valid types include
// *             xGE:  General m x n matrix
// *             xGB:  General banded matrix
// *             xPO:  Symmetric positive definite, 2-D storage
// *             xPP:  Symmetric positive definite packed
// *             xPB:  Symmetric positive definite banded
// *             xSY:  Symmetric indefinite, 2-D storage
// *             xSP:  Symmetric indefinite packed
// *             xSB:  Symmetric indefinite banded
// *             xTR:  Triangular
// *             xTP:  Triangular packed
// *             xTB:  Triangular banded
// *             xQR:  General m x n matrix
// *             xLQ:  General m x n matrix
// *             xQL:  General m x n matrix
// *             xRQ:  General m x n matrix
// *          where the leading character indicates the precision.
// *
// *  XTYPE   (input) CHARACTER*1
// *          Specifies how the exact solution X will be determined:
// *          = 'N':  New solution; generate a random X.
// *          = 'C':  Computed; use value of X on entry.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          matrix A is stored, if A is symmetric.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation applied to the matrix A.
// *          = 'N':  System is  A * x = b
// *          = 'T':  System is  A'* x = b
// *          = 'C':  System is  A'* x = b
// *
// *  M       (input) INTEGER
// *          The number or rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  KL      (input) INTEGER
// *          Used only if A is a band matrix; specifies the number of
// *          subdiagonals of A if A is a general band matrix or if A is
// *          symmetric or triangular and UPLO = 'L'; specifies the number
// *          of superdiagonals of A if A is symmetric or triangular and
// *          UPLO = 'U'.  0 <= KL <= M-1.
// *
// *  KU      (input) INTEGER
// *          Used only if A is a general band matrix or if A is
// *          triangular.
// *
// *          If PATH = xGB, specifies the number of superdiagonals of A,
// *          and 0 <= KU <= N-1.
// *
// *          If PATH = xTR, xTP, or xTB, specifies whether or not the
// *          matrix has unit diagonal:
// *          = 1:  matrix has non-unit diagonal (default)
// *          = 2:  matrix has unit diagonal
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand side vectors in the system A*X = B.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The test matrix whose type is given by PATH.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *          If PATH = xGB, LDA >= KL+KU+1.
// *          If PATH = xPB, xSB, xHB, or xTB, LDA >= KL+1.
// *          Otherwise, LDA >= max(1,M).
// *
// *  X       (input or output) DOUBLE PRECISION array, dimension(LDX,NRHS)
// *          On entry, if XTYPE = 'C' (for 'Computed'), then X contains
// *          the exact solution to the system of linear equations.
// *          On exit, if XTYPE = 'N' (for 'New'), then X is initialized
// *          with random values.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  If TRANS = 'N',
// *          LDX >= max(1,N); if TRANS = 'T', LDX >= max(1,M).
// *
// *  B       (output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vector(s) for the system of equations,
// *          computed from B = op(A) * X, where op(A) is determined by
// *          TRANS.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  If TRANS = 'N',
// *          LDB >= max(1,M); if TRANS = 'T', LDB >= max(1,N).
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          The seed vector for the random number generator (used in
// *          DLATMS).  Modified on exit.
// *
// *  INFO    (output) INTEGER
// *          = 0: successful exit
// *          < 0: if INFO = -i, the i-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean band= false;
static boolean gen= false;
static boolean notran= false;
static boolean qrs= false;
static boolean sym= false;
static boolean tran= false;
static boolean tri= false;
static String c1= new String(" ");
static String diag= new String(" ");
static String c2= new String("  ");
static int j= 0;
static int mb= 0;
static int nx= 0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Test the input parameters.
// *

public static void dlarhs (String path,
String xtype,
String uplo,
String trans,
int m,
int n,
int kl,
int ku,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
int [] iseed, int _iseed_offset,
intW info)  {

info.val = 0;
c1 = path.substring((1)-1,1);
c2 = path.substring((2)-1,3);
tran = (trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) || (trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0));
notran = !tran;
gen = (path.substring((2)-1,2).toLowerCase().charAt(0) == "G".toLowerCase().charAt(0));
qrs = (path.substring((2)-1,2).toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0)) || (path.substring((3)-1,3).toLowerCase().charAt(0) == "Q".toLowerCase().charAt(0));
sym = (path.substring((2)-1,2).toLowerCase().charAt(0) == "P".toLowerCase().charAt(0)) || (path.substring((2)-1,2).toLowerCase().charAt(0) == "S".toLowerCase().charAt(0));
tri = (path.substring((2)-1,2).toLowerCase().charAt(0) == "T".toLowerCase().charAt(0));
band = (path.substring((3)-1,3).toLowerCase().charAt(0) == "B".toLowerCase().charAt(0));
if (!(c1.toLowerCase().charAt(0) == "Double precision".toLowerCase().charAt(0)))  {
    info.val = -1;
}              // Close if()
else if (!((xtype.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)) || (xtype.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0))))  {
    info.val = -2;
}              // Close else if()
else if ((sym || tri) && !((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)) || (uplo.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0))))  {
    info.val = -3;
}              // Close else if()
else if ((gen || qrs) && !(tran || (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0))))  {
    info.val = -4;
}              // Close else if()
else if (m < 0)  {
    info.val = -5;
}              // Close else if()
else if (n < 0)  {
    info.val = -6;
}              // Close else if()
else if (band && kl < 0)  {
    info.val = -7;
}              // Close else if()
else if (band && ku < 0)  {
    info.val = -8;
}              // Close else if()
else if (nrhs < 0)  {
    info.val = -9;
}              // Close else if()
else if ((!band && lda < Math.max(1, m) ) || (band && (sym || tri) && lda < kl+1) || (band && gen && lda < kl+ku+1))  {
    info.val = -11;
}              // Close else if()
else if ((notran && ldx < Math.max(1, n) ) || (tran && ldx < Math.max(1, m) ))  {
    info.val = -13;
}              // Close else if()
else if ((notran && ldb < Math.max(1, m) ) || (tran && ldb < Math.max(1, n) ))  {
    info.val = -15;
}              // Close else if()
if (info.val != 0)  {
    Xerbla.xerbla("DLARHS",-info.val);
Dummy.go_to("Dlarhs",999999);
}              // Close if()
// *
// *     Initialize X to NRHS random vectors unless XTYPE = 'C'.
// *
if (tran)  {
    nx = m;
mb = n;
}              // Close if()
else  {
  nx = n;
mb = m;
}              //  Close else.
if (!(xtype.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    {
forloop10:
for (j = 1; j <= nrhs; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,x,(1)- 1+(j- 1)*ldx+ _x_offset);
Dummy.label("Dlarhs",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Multiply X by op( A ) using an appropriate
// *     matrix multiply routine.
// *
if (c2.regionMatches(true,0,"GE",0,2) || c2.regionMatches(true,0,"QR",0,2) || c2.regionMatches(true,0,"LQ",0,2) || c2.regionMatches(true,0,"QL",0,2) || c2.regionMatches(true,0,"RQ",0,2))  {
    // *
// *        General matrix
// *
Dgemm.dgemm(trans,"N",mb,nrhs,nx,one,a,_a_offset,lda,x,_x_offset,ldx,zero,b,_b_offset,ldb);
// *
}              // Close if()
else if (c2.regionMatches(true,0,"PO",0,2) || c2.regionMatches(true,0,"SY",0,2))  {
    // *
// *        Symmetric matrix, 2-D storage
// *
Dsymm.dsymm("Left",uplo,n,nrhs,one,a,_a_offset,lda,x,_x_offset,ldx,zero,b,_b_offset,ldb);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        General matrix, band storage
// *
{
forloop20:
for (j = 1; j <= nrhs; j++) {
Dgbmv.dgbmv(trans,mb,nx,kl,ku,one,a,_a_offset,lda,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,zero,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dlarhs",20);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        Symmetric matrix, band storage
// *
{
forloop30:
for (j = 1; j <= nrhs; j++) {
Dsbmv.dsbmv(uplo,n,kl,one,a,_a_offset,lda,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,zero,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dlarhs",30);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PP",0,2) || c2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        Symmetric matrix, packed storage
// *
{
forloop40:
for (j = 1; j <= nrhs; j++) {
Dspmv.dspmv(uplo,n,one,a,_a_offset,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,zero,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dlarhs",40);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TR",0,2))  {
    // *
// *        Triangular matrix.  Note that for triangular matrices,
// *           KU = 1 => non-unit triangular
// *           KU = 2 => unit triangular
// *
Dlacpy.dlacpy("Full",n,nrhs,x,_x_offset,ldx,b,_b_offset,ldb);
if (ku == 2)  {
    diag = "U";
}              // Close if()
else  {
  diag = "N";
}              //  Close else.
Dtrmm.dtrmm("Left",uplo,trans,diag,n,nrhs,one,a,_a_offset,lda,b,_b_offset,ldb);
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        Triangular matrix, packed storage
// *
Dlacpy.dlacpy("Full",n,nrhs,x,_x_offset,ldx,b,_b_offset,ldb);
if (ku == 2)  {
    diag = "U";
}              // Close if()
else  {
  diag = "N";
}              //  Close else.
{
forloop50:
for (j = 1; j <= nrhs; j++) {
Dtpmv.dtpmv(uplo,trans,diag,n,a,_a_offset,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dlarhs",50);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        Triangular matrix, banded storage
// *
Dlacpy.dlacpy("Full",n,nrhs,x,_x_offset,ldx,b,_b_offset,ldb);
if (ku == 2)  {
    diag = "U";
}              // Close if()
else  {
  diag = "N";
}              //  Close else.
{
forloop60:
for (j = 1; j <= nrhs; j++) {
Dtbmv.dtbmv(uplo,trans,diag,n,kl,a,_a_offset,lda,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dlarhs",60);
}              //  Close for() loop. 
}
// *
}              // Close else if()
else  {
  // *
// *        If PATH is none of the above, return with an error code.
// *
info.val = -1;
Xerbla.xerbla("DLARHS",-info.val);
}              //  Close else.
// *
Dummy.go_to("Dlarhs",999999);
// *
// *     End of DLARHS
// *
Dummy.label("Dlarhs",999999);
return;
   }
} // End class.
