/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dlatb4 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATB4 sets parameters for the matrix generator based on the type of
// *  matrix to be generated.
// *
// *  Arguments
// *  =========
// *
// *  PATH    (input) CHARACTER*3
// *          The LAPACK path name.
// *
// *  IMAT    (input) INTEGER
// *          An integer key describing which matrix to generate for this
// *          path.
// *
// *  M       (input) INTEGER
// *          The number of rows in the matrix to be generated.
// *
// *  N       (input) INTEGER
// *          The number of columns in the matrix to be generated.
// *
// *  TYPE    (output) CHARACTER*1
// *          The type of the matrix to be generated:
// *          = 'S':  symmetric matrix
// *          = 'P':  symmetric positive (semi)definite matrix
// *          = 'N':  nonsymmetric matrix
// *
// *  KL      (output) INTEGER
// *          The lower band width of the matrix to be generated.
// *
// *  KU      (output) INTEGER
// *          The upper band width of the matrix to be generated.
// *
// *  ANORM   (output) DOUBLE PRECISION
// *          The desired norm of the matrix to be generated.  The diagonal
// *          matrix of singular values or eigenvalues is scaled by this
// *          value.
// *
// *  MODE    (output) INTEGER
// *          A key indicating how to choose the vector of eigenvalues.
// *
// *  CNDNUM  (output) DOUBLE PRECISION
// *          The desired condition number.
// *
// *  DIST    (output) CHARACTER*1
// *          The type of distribution to be used by the random number
// *          generator.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double shrink= 0.25e0;
static double tenth= 0.1e+0;
static double one= 1.0e+0;
static double two= 2.0e+0;
// *     ..
// *     .. Local Scalars ..
static String c2= new String("  ");
static int mat= 0;
static double badc1= 0.0;
static double badc2= 0.0;
static double eps= 0.0;
static doubleW large= new doubleW(0.0);
static doubleW small= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Data statements ..
static boolean first = true;
// *     ..
// *     .. Executable Statements ..
// *
// *     Set some constants for use in the subroutine.
// *

public static void dlatb4 (String path,
int imat,
int m,
int n,
StringW type,
intW kl,
intW ku,
doubleW anorm,
intW mode,
doubleW cndnum,
StringW dist)  {

if (first)  {
    first = false;
eps = Dlamch.dlamch("Precision");
badc2 = tenth/eps;
badc1 = Math.sqrt(badc2);
small.val = Dlamch.dlamch("Safe minimum");
large.val = one/small.val;
// *
// *        If it looks like we're on a Cray, take the square root of
// *        SMALL and LARGE to avoid overflow and underflow problems.
// *
Dlabad.dlabad(small,large);
small.val = shrink*(small.val/eps);
large.val = one/small.val;
}              // Close if()
// *
c2 = path.substring((2)-1,3);
// *
// *     Set some parameters we don't plan to change.
// *
dist.val = "S";
mode.val = 3;
// *
if (c2.regionMatches(true,0,"QR",0,2) || c2.regionMatches(true,0,"LQ",0,2) || c2.regionMatches(true,0,"QL",0,2) || c2.regionMatches(true,0,"RQ",0,2))  {
    // *
// *        xQR, xLQ, xQL, xRQ:  Set parameters to generate a general
// *                             M x N matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the lower and upper bandwidths.
// *
if (imat == 1)  {
    kl.val = 0;
ku.val = 0;
}              // Close if()
else if (imat == 2)  {
    kl.val = 0;
ku.val = (int)(Math.max(n-1, 0) );
}              // Close else if()
else if (imat == 3)  {
    kl.val = (int)(Math.max(m-1, 0) );
ku.val = 0;
}              // Close else if()
else  {
  kl.val = (int)(Math.max(m-1, 0) );
ku.val = (int)(Math.max(n-1, 0) );
}              //  Close else.
// *
// *        Set the condition number and norm.
// *
if (imat == 5)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 6)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 7)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 8)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close if()
else if (c2.regionMatches(true,0,"GE",0,2))  {
    // *
// *        xGE:  Set parameters to generate a general M x N matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the lower and upper bandwidths.
// *
if (imat == 1)  {
    kl.val = 0;
ku.val = 0;
}              // Close if()
else if (imat == 2)  {
    kl.val = 0;
ku.val = (int)(Math.max(n-1, 0) );
}              // Close else if()
else if (imat == 3)  {
    kl.val = (int)(Math.max(m-1, 0) );
ku.val = 0;
}              // Close else if()
else  {
  kl.val = (int)(Math.max(m-1, 0) );
ku.val = (int)(Math.max(n-1, 0) );
}              //  Close else.
// *
// *        Set the condition number and norm.
// *
if (imat == 8)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 9)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 10)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 11)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GB",0,2))  {
    // *
// *        xGB:  Set parameters to generate a general banded matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the condition number and norm.
// *
if (imat == 5)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 6)  {
    cndnum.val = tenth*badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 7)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 8)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"GT",0,2))  {
    // *
// *        xGT:  Set parameters to generate a general tridiagonal matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the lower and upper bandwidths.
// *
if (imat == 1)  {
    kl.val = 0;
}              // Close if()
else  {
  kl.val = 1;
}              //  Close else.
ku.val = kl.val;
// *
// *        Set the condition number and norm.
// *
if (imat == 3)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 4)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 5 || imat == 11)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 6 || imat == 12)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PO",0,2) || c2.regionMatches(true,0,"PP",0,2) || c2.regionMatches(true,0,"SY",0,2) || c2.regionMatches(true,0,"SP",0,2))  {
    // *
// *        xPO, xPP, xSY, xSP: Set parameters to generate a
// *        symmetric matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = c2.substring((1)-1,1);
// *
// *        Set the lower and upper bandwidths.
// *
if (imat == 1)  {
    kl.val = 0;
}              // Close if()
else  {
  kl.val = (int)(Math.max(n-1, 0) );
}              //  Close else.
ku.val = kl.val;
// *
// *        Set the condition number and norm.
// *
if (imat == 6)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 7)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 8)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 9)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PB",0,2))  {
    // *
// *        xPB:  Set parameters to generate a symmetric band matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "P";
// *
// *        Set the norm and condition number.
// *
if (imat == 5)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 6)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 7)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 8)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"PT",0,2))  {
    // *
// *        xPT:  Set parameters to generate a symmetric positive definite
// *        tridiagonal matrix.
// *
type.val = "P";
if (imat == 1)  {
    kl.val = 0;
}              // Close if()
else  {
  kl.val = 1;
}              //  Close else.
ku.val = kl.val;
// *
// *        Set the condition number and norm.
// *
if (imat == 3)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 4)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 5 || imat == 11)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 6 || imat == 12)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TR",0,2) || c2.regionMatches(true,0,"TP",0,2))  {
    // *
// *        xTR, xTP:  Set parameters to generate a triangular matrix
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the lower and upper bandwidths.
// *
mat = (int)(Math.abs(imat));
if (mat == 1 || mat == 7)  {
    kl.val = 0;
ku.val = 0;
}              // Close if()
else if (imat < 0)  {
    kl.val = (int)(Math.max(n-1, 0) );
ku.val = 0;
}              // Close else if()
else  {
  kl.val = 0;
ku.val = (int)(Math.max(n-1, 0) );
}              //  Close else.
// *
// *        Set the condition number and norm.
// *
if (mat == 3 || mat == 9)  {
    cndnum.val = badc1;
}              // Close if()
else if (mat == 4)  {
    cndnum.val = badc2;
}              // Close else if()
else if (mat == 10)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (mat == 5)  {
    anorm.val = small.val;
}              // Close if()
else if (mat == 6)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
// *
}              // Close else if()
else if (c2.regionMatches(true,0,"TB",0,2))  {
    // *
// *        xTB:  Set parameters to generate a triangular band matrix.
// *
// *        Set TYPE, the type of matrix to be generated.
// *
type.val = "N";
// *
// *        Set the norm and condition number.
// *
if (imat == 2 || imat == 8)  {
    cndnum.val = badc1;
}              // Close if()
else if (imat == 3 || imat == 9)  {
    cndnum.val = badc2;
}              // Close else if()
else  {
  cndnum.val = two;
}              //  Close else.
// *
if (imat == 4)  {
    anorm.val = small.val;
}              // Close if()
else if (imat == 5)  {
    anorm.val = large.val;
}              // Close else if()
else  {
  anorm.val = one;
}              //  Close else.
}              // Close else if()
if (n <= 1)  
    cndnum.val = one;
// *
Dummy.go_to("Dlatb4",999999);
// *
// *     End of DLATB4
// *
Dummy.label("Dlatb4",999999);
return;
   }
} // End class.
