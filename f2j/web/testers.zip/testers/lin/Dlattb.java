/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlattb {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATTB generates a triangular test matrix in 2-dimensional storage.
// *  IMAT and UPLO uniquely specify the properties of the test matrix,
// *  which is returned in the array A.
// *
// *  Arguments
// *  =========
// *
// *  IMAT    (input) INTEGER
// *          An integer key describing which matrix to generate for this
// *          path.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A will be upper or lower
// *          triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies whether the matrix or its transpose will be used.
// *          = 'N':  No transpose
// *          = 'T':  Transpose
// *          = 'C':  Conjugate transpose (= transpose)
// *
// *  DIAG    (output) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          The seed vector for the random number generator (used in
// *          DLATMS).  Modified on exit.
// *
// *  N       (input) INTEGER
// *          The order of the matrix to be generated.
// *
// *  KD      (input) INTEGER
// *          The number of superdiagonals or subdiagonals of the banded
// *          triangular matrix A.  KD >= 0.
// *
// *  AB      (output) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The upper or lower triangular banded matrix A, stored in the
// *          first KD+1 rows of AB.  Let j be a column of A, 1<=j<=n.
// *          If UPLO = 'U', AB(kd+1+i-j,j) = A(i,j) for max(1,j-kd)<=i<=j.
// *          If UPLO = 'L', AB(1+i-j,j)    = A(i,j) for j<=i<=min(n,j+kd).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KD+1.
// *
// *  B       (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double two= 2.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static StringW dist= new StringW(" ");
static String packit= new String(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static int ioff= 0;
static int iy= 0;
static int j= 0;
static int jcount= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static int lenj= 0;
static intW mode= new intW(0);
static doubleW anorm= new doubleW(0.0);
static doubleW bignum= new doubleW(0.0);
static double bnorm= 0.0;
static double bscal= 0.0;
static doubleW cndnum= new doubleW(0.0);
static double plus1= 0.0;
static double plus2= 0.0;
static double rexp= 0.0;
static double sfac= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double star1= 0.0;
static double texp= 0.0;
static double tleft= 0.0;
static double tnorm= 0.0;
static double tscal= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlattb (int imat,
String uplo,
String trans,
StringW diag,
int [] iseed, int _iseed_offset,
int n,
int kd,
double [] ab, int _ab_offset,
int ldab,
double [] b, int _b_offset,
double [] work, int _work_offset,
intW info)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "TB".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
smlnum.val = unfl;
bignum.val = (one-ulp)/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
if ((imat >= 6 && imat <= 9) || imat == 17)  {
    diag.val = "U";
}              // Close if()
else  {
  diag.val = "N";
}              //  Close else.
info.val = 0;
// *
// *     Quick return if N.LE.0.
// *
if (n <= 0)  
    Dummy.go_to("Dlattb",999999);
// *
// *     Call DLATB4 to set parameters for SLATMS.
// *
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (upper)  {
    Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
ku.val = kd;
ioff = (int)(1+Math.max(0, kd-n+1) );
kl.val = 0;
packit = "Q";
}              // Close if()
else  {
  Dlatb4.dlatb4(path,-imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
kl.val = kd;
ioff = 1;
ku.val = 0;
packit = "B";
}              //  Close else.
// *
// *     IMAT <= 5:  Non-unit triangular matrix
// *
if (imat <= 5)  {
    Dlatms.dlatms(n,n,dist.val,iseed,_iseed_offset,type.val,b,_b_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,packit,ab,(ioff)- 1+(1- 1)*ldab+ _ab_offset,ldab,work,_work_offset,info);
// *
// *     IMAT > 5:  Unit triangular matrix
// *     The diagonal is deliberately set to something other than 1.
// *
// *     IMAT = 6:  Matrix is the identity
// *
}              // Close if()
else if (imat == 6)  {
    if (upper)  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = (int)(Math.max(1, kd+2-j) ); i <= kd; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",10);
}              //  Close for() loop. 
}
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
Dummy.label("Dlattb",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
{
forloop30:
for (i = 2; i <= Math.min(kd+1, n-j+1) ; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",30);
}              //  Close for() loop. 
}
Dummy.label("Dlattb",40);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     IMAT > 6:  Non-trivial unit triangular matrix
// *
// *     A unit triangular matrix T with condition CNDNUM is formed.
// *     In this version, T only has bandwidth 2, the rest of it is zero.
// *
}              // Close else if()
else if (imat <= 9)  {
    tnorm = Math.sqrt(cndnum.val);
// *
// *        Initialize AB to zero.
// *
if (upper)  {
    {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = (int)(Math.max(1, kd+2-j) ); i <= kd; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",50);
}              //  Close for() loop. 
}
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
Dummy.label("Dlattb",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop80:
for (j = 1; j <= n; j++) {
{
forloop70:
for (i = 2; i <= Math.min(kd+1, n-j+1) ; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",70);
}              //  Close for() loop. 
}
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
Dummy.label("Dlattb",80);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Special case:  T is tridiagonal.  Set every other offdiagonal
// *        so that the matrix has norm TNORM+1.
// *
if (kd == 1)  {
    if (upper)  {
    ab[(1)- 1+(2- 1)*ldab+ _ab_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(tnorm) : -Math.abs(tnorm));
lenj = (n-3)/2;
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,work,_work_offset);
{
forloop90:
for (j = 1; j <= lenj; j++) {
ab[(1)- 1+(2*(j+1)- 1)*ldab+ _ab_offset] = tnorm*work[(j)- 1+ _work_offset];
Dummy.label("Dlattb",90);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  ab[(2)- 1+(1- 1)*ldab+ _ab_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(tnorm) : -Math.abs(tnorm));
lenj = (n-3)/2;
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,work,_work_offset);
{
forloop100:
for (j = 1; j <= lenj; j++) {
ab[(2)- 1+(2*j+1- 1)*ldab+ _ab_offset] = tnorm*work[(j)- 1+ _work_offset];
Dummy.label("Dlattb",100);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else if (kd > 1)  {
    // *
// *           Form a unit triangular matrix T with condition CNDNUM.  T is
// *           given by
// *                   | 1   +   *                      |
// *                   |     1   +                      |
// *               T = |         1   +   *              |
// *                   |             1   +              |
// *                   |                 1   +   *      |
// *                   |                     1   +      |
// *                   |                          . . . |
// *        Each element marked with a '*' is formed by taking the product
// *        of the adjacent elements marked with '+'.  The '*'s can be
// *        chosen freely, and the '+'s are chosen so that the inverse of
// *        T will have elements of the same magnitude as T.
// *
// *        The two offdiagonals of T are stored in WORK.
// *
star1 = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(tnorm) : -Math.abs(tnorm));
sfac = Math.sqrt(tnorm);
plus1 = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(sfac) : -Math.abs(sfac));
{
int _j_inc = 2;
forloop110:
for (j = 1; (_j_inc < 0) ? j >= n : j <= n; j += _j_inc) {
plus2 = star1/plus1;
work[(j)- 1+ _work_offset] = plus1;
work[(n+j)- 1+ _work_offset] = star1;
if (j+1 <= n)  {
    work[(j+1)- 1+ _work_offset] = plus2;
work[(n+j+1)- 1+ _work_offset] = zero;
plus1 = star1/plus2;
// *
// *                 Generate a new *-value with norm between sqrt(TNORM)
// *                 and TNORM.
// *
rexp = Dlarnd.dlarnd(2,iseed,_iseed_offset);
if (rexp < zero)  {
    star1 = -Math.pow(sfac, (one-rexp));
}              // Close if()
else  {
  star1 = Math.pow(sfac, (one+rexp));
}              //  Close else.
}              // Close if()
Dummy.label("Dlattb",110);
}              //  Close for() loop. 
}
// *
// *           Copy the tridiagonal T to AB.
// *
if (upper)  {
    Dcopy.dcopy(n-1,work,_work_offset,1,ab,(kd)- 1+(2- 1)*ldab+ _ab_offset,ldab);
Dcopy.dcopy(n-2,work,(n+1)- 1+ _work_offset,1,ab,(kd-1)- 1+(3- 1)*ldab+ _ab_offset,ldab);
}              // Close if()
else  {
  Dcopy.dcopy(n-1,work,_work_offset,1,ab,(2)- 1+(1- 1)*ldab+ _ab_offset,ldab);
Dcopy.dcopy(n-2,work,(n+1)- 1+ _work_offset,1,ab,(3)- 1+(1- 1)*ldab+ _ab_offset,ldab);
}              //  Close else.
}              // Close else if()
// *
// *     IMAT > 9:  Pathological test cases.  These triangular matrices
// *     are badly scaled or badly conditioned, so when used in solving a
// *     triangular system they may cause overflow in the solution vector.
// *
}              // Close else if()
else if (imat == 10)  {
    // *
// *        Type 10:  Generate a triangular matrix with elements between
// *        -1 and 1. Give the diagonal norm 2 to make it well-conditioned.
// *        Make the right hand side large so that it requires scaling.
// *
if (upper)  {
    {
forloop120:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset);
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
Dummy.label("Dlattb",120);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop130:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j+1, kd+1) );
if (lenj > 0)  
    Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset);
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
Dummy.label("Dlattb",130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side so that the largest value is BIGNUM.
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
iy = Idamax.idamax(n,b,_b_offset,1);
bnorm = Math.abs(b[(iy)- 1+ _b_offset]);
bscal = bignum.val/Math.max(one, bnorm) ;
Dscal.dscal(n,bscal,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 11)  {
    // *
// *        Type 11:  Make the first diagonal element in the solve small to
// *        cause immediate overflow when dividing by T(j,j).
// *        In type 11, the offdiagonal elements are small (CNORM(j) < 1).
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
tscal = one/(double)(kd+1);
if (upper)  {
    {
forloop140:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset);
Dscal.dscal(lenj-1,tscal,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset,1);
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
Dummy.label("Dlattb",140);
}              //  Close for() loop. 
}
ab[(kd+1)- 1+(n- 1)*ldab+ _ab_offset] = smlnum.val*ab[(kd+1)- 1+(n- 1)*ldab+ _ab_offset];
}              // Close if()
else  {
  {
forloop150:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j+1, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset);
if (lenj > 1)  
    Dscal.dscal(lenj-1,tscal,ab,(2)- 1+(j- 1)*ldab+ _ab_offset,1);
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
Dummy.label("Dlattb",150);
}              //  Close for() loop. 
}
ab[(1)- 1+(1- 1)*ldab+ _ab_offset] = smlnum.val*ab[(1)- 1+(1- 1)*ldab+ _ab_offset];
}              //  Close else.
// *
}              // Close else if()
else if (imat == 12)  {
    // *
// *        Type 12:  Make the first diagonal element in the solve small to
// *        cause immediate overflow when dividing by T(j,j).
// *        In type 12, the offdiagonal elements are O(1) (CNORM(j) > 1).
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
if (upper)  {
    {
forloop160:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset);
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
Dummy.label("Dlattb",160);
}              //  Close for() loop. 
}
ab[(kd+1)- 1+(n- 1)*ldab+ _ab_offset] = smlnum.val*ab[(kd+1)- 1+(n- 1)*ldab+ _ab_offset];
}              // Close if()
else  {
  {
forloop170:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j+1, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset);
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(one) : -Math.abs(one));
Dummy.label("Dlattb",170);
}              //  Close for() loop. 
}
ab[(1)- 1+(1- 1)*ldab+ _ab_offset] = smlnum.val*ab[(1)- 1+(1- 1)*ldab+ _ab_offset];
}              //  Close else.
// *
}              // Close else if()
else if (imat == 13)  {
    // *
// *        Type 13:  T is diagonal with small numbers on the diagonal to
// *        make the growth factor underflow, but a small right hand side
// *        chosen so that the solution does not overflow.
// *
if (upper)  {
    jcount = 1;
{
int _j_inc = -1;
forloop190:
for (j = n; (_j_inc < 0) ? j >= 1 : j <= 1; j += _j_inc) {
{
forloop180:
for (i = (int)(Math.max(1, kd+1-(j-1)) ); i <= kd; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",180);
}              //  Close for() loop. 
}
if (jcount <= 2)  {
    ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = smlnum.val;
}              // Close if()
else  {
  ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = one;
}              //  Close else.
jcount = jcount+1;
if (jcount > 4)  
    jcount = 1;
Dummy.label("Dlattb",190);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jcount = 1;
{
forloop210:
for (j = 1; j <= n; j++) {
{
forloop200:
for (i = 2; i <= Math.min(n-j+1, kd+1) ; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",200);
}              //  Close for() loop. 
}
if (jcount <= 2)  {
    ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = smlnum.val;
}              // Close if()
else  {
  ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = one;
}              //  Close else.
jcount = jcount+1;
if (jcount > 4)  
    jcount = 1;
Dummy.label("Dlattb",210);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side alternately zero and small.
// *
if (upper)  {
    b[(1)- 1+ _b_offset] = zero;
{
int _i_inc = -2;
forloop220:
for (i = n; (_i_inc < 0) ? i >= 2 : i <= 2; i += _i_inc) {
b[(i)- 1+ _b_offset] = zero;
b[(i-1)- 1+ _b_offset] = smlnum.val;
Dummy.label("Dlattb",220);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  b[(n)- 1+ _b_offset] = zero;
{
int _i_inc = 2;
forloop230:
for (i = 1; (_i_inc < 0) ? i >= n-1 : i <= n-1; i += _i_inc) {
b[(i)- 1+ _b_offset] = zero;
b[(i+1)- 1+ _b_offset] = smlnum.val;
Dummy.label("Dlattb",230);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close else if()
else if (imat == 14)  {
    // *
// *        Type 14:  Make the diagonal elements small to cause gradual
// *        overflow when dividing by T(j,j).  To control the amount of
// *        scaling needed, the matrix is bidiagonal.
// *
texp = one/(double)(kd+1);
tscal = Math.pow(smlnum.val, texp);
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
if (upper)  {
    {
forloop250:
for (j = 1; j <= n; j++) {
{
forloop240:
for (i = (int)(Math.max(1, kd+2-j) ); i <= kd; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",240);
}              //  Close for() loop. 
}
if (j > 1 && kd > 0)  
    ab[(kd)- 1+(j- 1)*ldab+ _ab_offset] = -one;
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = tscal;
Dummy.label("Dlattb",250);
}              //  Close for() loop. 
}
b[(n)- 1+ _b_offset] = one;
}              // Close if()
else  {
  {
forloop270:
for (j = 1; j <= n; j++) {
{
forloop260:
for (i = 3; i <= Math.min(n-j+1, kd+1) ; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",260);
}              //  Close for() loop. 
}
if (j < n && kd > 0)  
    ab[(2)- 1+(j- 1)*ldab+ _ab_offset] = -one;
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = tscal;
Dummy.label("Dlattb",270);
}              //  Close for() loop. 
}
b[(1)- 1+ _b_offset] = one;
}              //  Close else.
// *
}              // Close else if()
else if (imat == 15)  {
    // *
// *        Type 15:  One zero diagonal element.
// *
iy = n/2+1;
if (upper)  {
    {
forloop280:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset);
if (j != iy)  {
    ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
}              // Close if()
else  {
  ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = zero;
}              //  Close else.
Dummy.label("Dlattb",280);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop290:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j+1, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset);
if (j != iy)  {
    ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(1)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
}              // Close if()
else  {
  ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = zero;
}              //  Close else.
Dummy.label("Dlattb",290);
}              //  Close for() loop. 
}
}              //  Close else.
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
Dscal.dscal(n,two,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 16)  {
    // *
// *        Type 16:  Make the offdiagonal elements large to cause overflow
// *        when adding a column of T.  In the non-transposed case, the
// *        matrix is constructed to cause overflow when adding a column in
// *        every other step.
// *
tscal = unfl/ulp;
tscal = (one-ulp)/tscal;
{
forloop310:
for (j = 1; j <= n; j++) {
{
forloop300:
for (i = 1; i <= kd+1; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = zero;
Dummy.label("Dlattb",300);
}              //  Close for() loop. 
}
Dummy.label("Dlattb",310);
}              //  Close for() loop. 
}
texp = one;
if (kd > 0)  {
    if (upper)  {
    {
int _j_inc = -kd;
forloop330:
for (j = n; (_j_inc < 0) ? j >= 1 : j <= 1; j += _j_inc) {
{
int _i_inc = -2;
forloop320:
for (i = j; (_i_inc < 0) ? i >= Math.max(1, j-kd+1)  : i <= Math.max(1, j-kd+1) ; i += _i_inc) {
ab[(1+(j-i))- 1+(i- 1)*ldab+ _ab_offset] = -tscal/(double)(kd+2);
ab[(kd+1)- 1+(i- 1)*ldab+ _ab_offset] = one;
b[(i)- 1+ _b_offset] = texp*(one-ulp);
if (i > Math.max(1, j-kd+1) )  {
    ab[(2+(j-i))- 1+(i-1- 1)*ldab+ _ab_offset] = -(tscal/(double)(kd+2))/(double)(kd+3);
ab[(kd+1)- 1+(i-1- 1)*ldab+ _ab_offset] = one;
b[(i-1)- 1+ _b_offset] = texp*(double)((kd+1)*(kd+1)+kd);
}              // Close if()
texp = texp*two;
Dummy.label("Dlattb",320);
}              //  Close for() loop. 
}
b[(int)((Math.max(1, j-kd+1) )- 1+ _b_offset)] = ((double)(kd+2)/(double)(kd+3))*tscal;
Dummy.label("Dlattb",330);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
int _j_inc = kd;
forloop350:
for (j = 1; (_j_inc < 0) ? j >= n : j <= n; j += _j_inc) {
texp = one;
lenj = (int)(Math.min(kd+1, n-j+1) );
{
int _i_inc = 2;
forloop340:
for (i = j; (_i_inc < 0) ? i >= Math.min(n, j+kd-1)  : i <= Math.min(n, j+kd-1) ; i += _i_inc) {
ab[(lenj-(i-j))- 1+(j- 1)*ldab+ _ab_offset] = -tscal/(double)(kd+2);
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = one;
b[(j)- 1+ _b_offset] = texp*(one-ulp);
if (i < Math.min(n, j+kd-1) )  {
    ab[(lenj-(i-j+1))- 1+(i+1- 1)*ldab+ _ab_offset] = -(tscal/(double)(kd+2))/(double)(kd+3);
ab[(1)- 1+(i+1- 1)*ldab+ _ab_offset] = one;
b[(i+1)- 1+ _b_offset] = texp*(double)((kd+1)*(kd+1)+kd);
}              // Close if()
texp = texp*two;
Dummy.label("Dlattb",340);
}              //  Close for() loop. 
}
b[(int)((Math.min(n, j+kd-1) )- 1+ _b_offset)] = ((double)(kd+2)/(double)(kd+3))*tscal;
Dummy.label("Dlattb",350);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  {
forloop360:
for (j = 1; j <= n; j++) {
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = one;
b[(j)- 1+ _b_offset] = (double)(j);
Dummy.label("Dlattb",360);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close else if()
else if (imat == 17)  {
    // *
// *        Type 17:  Generate a unit triangular matrix with elements
// *        between -1 and 1, and make the right hand side large so that it
// *        requires scaling.
// *
if (upper)  {
    {
forloop370:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j-1, kd) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+1-lenj)- 1+(j- 1)*ldab+ _ab_offset);
ab[(kd+1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
Dummy.label("Dlattb",370);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop380:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j, kd) );
if (lenj > 0)  
    Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(2)- 1+(j- 1)*ldab+ _ab_offset);
ab[(1)- 1+(j- 1)*ldab+ _ab_offset] = (double)(j);
Dummy.label("Dlattb",380);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side so that the largest value is BIGNUM.
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
iy = Idamax.idamax(n,b,_b_offset,1);
bnorm = Math.abs(b[(iy)- 1+ _b_offset]);
bscal = bignum.val/Math.max(one, bnorm) ;
Dscal.dscal(n,bscal,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 18)  {
    // *
// *        Type 18:  Generate a triangular matrix with elements between
// *        BIGNUM/KD and BIGNUM so that at least one of the column
// *        norms will exceed BIGNUM.
// *
tleft = bignum.val/Math.max(one, (double)(kd)) ;
tscal = bignum.val*((double)(kd)/(double)(kd+1));
if (upper)  {
    {
forloop400:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(j, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(kd+2-lenj)- 1+(j- 1)*ldab+ _ab_offset);
{
forloop390:
for (i = kd+2-lenj; i <= kd+1; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(i)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(tleft) : -Math.abs(tleft))+tscal*ab[(i)- 1+(j- 1)*ldab+ _ab_offset];
Dummy.label("Dlattb",390);
}              //  Close for() loop. 
}
Dummy.label("Dlattb",400);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop420:
for (j = 1; j <= n; j++) {
lenj = (int)(Math.min(n-j+1, kd+1) );
Dlarnv.dlarnv(2,iseed,_iseed_offset,lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset);
{
forloop410:
for (i = 1; i <= lenj; i++) {
ab[(i)- 1+(j- 1)*ldab+ _ab_offset] = ((ab[(i)- 1+(j- 1)*ldab+ _ab_offset]) >= 0 ? Math.abs(tleft) : -Math.abs(tleft))+tscal*ab[(i)- 1+(j- 1)*ldab+ _ab_offset];
Dummy.label("Dlattb",410);
}              //  Close for() loop. 
}
Dummy.label("Dlattb",420);
}              //  Close for() loop. 
}
}              //  Close else.
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
Dscal.dscal(n,two,b,_b_offset,1);
}              // Close else if()
// *
// *     Flip the matrix if the transpose will be used.
// *
if (!(trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    if (upper)  {
    {
forloop430:
for (j = 1; j <= n/2; j++) {
lenj = (int)(Math.min(n-2*j+1, kd+1) );
Dswap.dswap(lenj,ab,(kd+1)- 1+(j- 1)*ldab+ _ab_offset,ldab-1,ab,(kd+2-lenj)- 1+(n-j+1- 1)*ldab+ _ab_offset,-1);
Dummy.label("Dlattb",430);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop440:
for (j = 1; j <= n/2; j++) {
lenj = (int)(Math.min(n-2*j+1, kd+1) );
Dswap.dswap(lenj,ab,(1)- 1+(j- 1)*ldab+ _ab_offset,1,ab,(lenj)- 1+(n-j+2-lenj- 1)*ldab+ _ab_offset,-ldab+1);
Dummy.label("Dlattb",440);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
// *
Dummy.go_to("Dlattb",999999);
// *
// *     End of DLATTB
// *
Dummy.label("Dlattb",999999);
return;
   }
} // End class.
