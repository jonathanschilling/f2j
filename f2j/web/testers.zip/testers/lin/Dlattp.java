/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlattp {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLATTP generates a triangular test matrix in packed storage.
// *  IMAT and UPLO uniquely specify the properties of the test
// *  matrix, which is returned in the array AP.
// *
// *  Arguments
// *  =========
// *
// *  IMAT    (input) INTEGER
// *          An integer key describing which matrix to generate for this
// *          path.
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A will be upper or lower
// *          triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies whether the matrix or its transpose will be used.
// *          = 'N':  No transpose
// *          = 'T':  Transpose
// *          = 'C':  Conjugate transpose (= Transpose)
// *
// *  DIAG    (output) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  ISEED   (input/output) INTEGER array, dimension (4)
// *          The seed vector for the random number generator (used in
// *          DLATMS).  Modified on exit.
// *
// *  N       (input) INTEGER
// *          The order of the matrix to be generated.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangular matrix A, packed columnwise in
// *          a linear array.  The j-th column of A is stored in the array
// *          AP as follows:
// *          if UPLO = 'U', AP((j-1)*j/2 + i) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L',
// *             AP((j-1)*(n-j) + j*(j+1)/2 + i-j) = A(i,j) for j<=i<=n.
// *
// *  B       (output) DOUBLE PRECISION array, dimension (N)
// *          The right hand side vector, if IMAT > 10.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (3*N)
// *
// *  INFO    (output) INTEGER
// *          = 0:  successful exit
// *          < 0: if INFO = -k, the k-th argument had an illegal value
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double two= 2.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean upper= false;
static StringW dist= new StringW(" ");
static String packit= new String(" ");
static StringW type= new StringW(" ");
static String path= new String("   ");
static int i= 0;
static int iy= 0;
static int j= 0;
static int jc= 0;
static int jcnext= 0;
static int jcount= 0;
static int jj= 0;
static int jl= 0;
static int jr= 0;
static int jx= 0;
static intW kl= new intW(0);
static intW ku= new intW(0);
static intW mode= new intW(0);
static doubleW anorm= new doubleW(0.0);
static doubleW bignum= new doubleW(0.0);
static double bnorm= 0.0;
static double bscal= 0.0;
static doubleW c= new doubleW(0.0);
static doubleW cndnum= new doubleW(0.0);
static double plus1= 0.0;
static double plus2= 0.0;
static doubleW ra= new doubleW(0.0);
static doubleW rb= new doubleW(0.0);
static double rexp= 0.0;
static doubleW s= new doubleW(0.0);
static double sfac= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double star1= 0.0;
static double stemp= 0.0;
static double t= 0.0;
static double texp= 0.0;
static double tleft= 0.0;
static double tscal= 0.0;
static double ulp= 0.0;
static double unfl= 0.0;
static double x= 0.0;
static double y= 0.0;
static double z= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlattp (int imat,
String uplo,
String trans,
StringW diag,
int [] iseed, int _iseed_offset,
int n,
double [] a, int _a_offset,
double [] b, int _b_offset,
double [] work, int _work_offset,
intW info)  {

{
  int E1, E2;
  E1 = 1;
  E2 = 1;
path = new String(path.substring(0,E1-1) + "D".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
{
  int E1, E2;
  E1 = 2;
  E2 = 3;
path = new String(path.substring(0,E1-1) + "TP".substring(0,E2-E1+1) + path.substring(E2,path.length()));
}
;
unfl = Dlamch.dlamch("Safe minimum");
ulp = Dlamch.dlamch("Epsilon")*Dlamch.dlamch("Base");
smlnum.val = unfl;
bignum.val = (one-ulp)/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
if ((imat >= 7 && imat <= 10) || imat == 18)  {
    diag.val = "U";
}              // Close if()
else  {
  diag.val = "N";
}              //  Close else.
info.val = 0;
// *
// *     Quick return if N.LE.0.
// *
if (n <= 0)  
    Dummy.go_to("Dlattp",999999);
// *
// *     Call DLATB4 to set parameters for SLATMS.
// *
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if (upper)  {
    Dlatb4.dlatb4(path,imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
packit = "C";
}              // Close if()
else  {
  Dlatb4.dlatb4(path,-imat,n,n,type,kl,ku,anorm,mode,cndnum,dist);
packit = "R";
}              //  Close else.
// *
// *     IMAT <= 6:  Non-unit triangular matrix
// *
if (imat <= 6)  {
    Dlatms.dlatms(n,n,dist.val,iseed,_iseed_offset,type.val,b,_b_offset,mode.val,cndnum.val,anorm.val,kl.val,ku.val,packit,a,_a_offset,n,work,_work_offset,info);
// *
// *     IMAT > 6:  Unit triangular matrix
// *     The diagonal is deliberately set to something other than 1.
// *
// *     IMAT = 7:  Matrix is the identity
// *
}              // Close if()
else if (imat == 7)  {
    if (upper)  {
    jc = 1;
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
a[(jc+i-1)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",10);
}              //  Close for() loop. 
}
a[(jc+j-1)- 1+ _a_offset] = (double)(j);
jc = jc+j;
Dummy.label("Dlattp",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop40:
for (j = 1; j <= n; j++) {
a[(jc)- 1+ _a_offset] = (double)(j);
{
forloop30:
for (i = j+1; i <= n; i++) {
a[(jc+i-j)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",30);
}              //  Close for() loop. 
}
jc = jc+n-j+1;
Dummy.label("Dlattp",40);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     IMAT > 7:  Non-trivial unit triangular matrix
// *
// *     Generate a unit triangular matrix T with condition CNDNUM by
// *     forming a triangular matrix with known singular values and
// *     filling in the zero entries with Givens rotations.
// *
}              // Close else if()
else if (imat <= 10)  {
    if (upper)  {
    jc = 0;
{
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = 1; i <= j-1; i++) {
a[(jc+i)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",50);
}              //  Close for() loop. 
}
a[(jc+j)- 1+ _a_offset] = (double)(j);
jc = jc+j;
Dummy.label("Dlattp",60);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop80:
for (j = 1; j <= n; j++) {
a[(jc)- 1+ _a_offset] = (double)(j);
{
forloop70:
for (i = j+1; i <= n; i++) {
a[(jc+i-j)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",70);
}              //  Close for() loop. 
}
jc = jc+n-j+1;
Dummy.label("Dlattp",80);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Since the trace of a unit triangular matrix is 1, the product
// *        of its singular values must be 1.  Let s = sqrt(CNDNUM),
// *        x = sqrt(s) - 1/sqrt(s), y = sqrt(2/(n-2))*x, and z = x**2.
// *        The following triangular matrix has singular values s, 1, 1,
// *        ..., 1, 1/s:
// *
// *        1  y  y  y  ...  y  y  z
// *           1  0  0  ...  0  0  y
// *              1  0  ...  0  0  y
// *                 .  ...  .  .  .
// *                     .   .  .  .
// *                         1  0  y
// *                            1  y
// *                               1
// *
// *        To fill in the zeros, we first multiply by a matrix with small
// *        condition number of the form
// *
// *        1  0  0  0  0  ...
// *           1  +  *  0  0  ...
// *              1  +  0  0  0
// *                 1  +  *  0  0
// *                    1  +  0  0
// *                       ...
// *                          1  +  0
// *                             1  0
// *                                1
// *
// *        Each element marked with a '*' is formed by taking the product
// *        of the adjacent elements marked with '+'.  The '*'s can be
// *        chosen freely, and the '+'s are chosen so that the inverse of
// *        T will have elements of the same magnitude as T.  If the *'s in
// *        both T and inv(T) have small magnitude, T is well conditioned.
// *        The two offdiagonals of T are stored in WORK.
// *
// *        The product of these two matrices has the form
// *
// *        1  y  y  y  y  y  .  y  y  z
// *           1  +  *  0  0  .  0  0  y
// *              1  +  0  0  .  0  0  y
// *                 1  +  *  .  .  .  .
// *                    1  +  .  .  .  .
// *                       .  .  .  .  .
// *                          .  .  .  .
// *                             1  +  y
// *                                1  y
// *                                   1
// *
// *        Now we multiply by Givens rotations, using the fact that
// *
// *              [  c   s ] [  1   w ] [ -c  -s ] =  [  1  -w ]
// *              [ -s   c ] [  0   1 ] [  s  -c ]    [  0   1 ]
// *        and
// *              [ -c  -s ] [  1   0 ] [  c   s ] =  [  1   0 ]
// *              [  s  -c ] [  w   1 ] [ -s   c ]    [ -w   1 ]
// *
// *        where c = w / sqrt(w**2+4) and s = 2 / sqrt(w**2+4).
// *
star1 = 0.25e0;
sfac = 0.5e0;
plus1 = sfac;
{
int _j_inc = 2;
forloop90:
for (j = 1; (_j_inc < 0) ? j >= n : j <= n; j += _j_inc) {
plus2 = star1/plus1;
work[(j)- 1+ _work_offset] = plus1;
work[(n+j)- 1+ _work_offset] = star1;
if (j+1 <= n)  {
    work[(j+1)- 1+ _work_offset] = plus2;
work[(n+j+1)- 1+ _work_offset] = zero;
plus1 = star1/plus2;
rexp = Dlarnd.dlarnd(2,iseed,_iseed_offset);
star1 = star1*(Math.pow(sfac, rexp));
if (rexp < zero)  {
    star1 = -Math.pow(sfac, (one-rexp));
}              // Close if()
else  {
  star1 = Math.pow(sfac, (one+rexp));
}              //  Close else.
}              // Close if()
Dummy.label("Dlattp",90);
}              //  Close for() loop. 
}
// *
x = Math.sqrt(cndnum.val)-one/Math.sqrt(cndnum.val);
if (n > 2)  {
    y = Math.sqrt(two/(double)(n-2))*x;
}              // Close if()
else  {
  y = zero;
}              //  Close else.
z = x*x;
// *
if (upper)  {
    // *
// *           Set the upper triangle of A with a unit triangular matrix
// *           of known condition number.
// *
jc = 1;
{
forloop100:
for (j = 2; j <= n; j++) {
a[(jc+1)- 1+ _a_offset] = y;
if (j > 2)  
    a[(jc+j-1)- 1+ _a_offset] = work[(j-2)- 1+ _work_offset];
if (j > 3)  
    a[(jc+j-2)- 1+ _a_offset] = work[(n+j-3)- 1+ _work_offset];
jc = jc+j;
Dummy.label("Dlattp",100);
}              //  Close for() loop. 
}
jc = jc-n;
a[(jc+1)- 1+ _a_offset] = z;
{
forloop110:
for (j = 2; j <= n-1; j++) {
a[(jc+j)- 1+ _a_offset] = y;
Dummy.label("Dlattp",110);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  // *
// *           Set the lower triangle of A with a unit triangular matrix
// *           of known condition number.
// *
{
forloop120:
for (i = 2; i <= n-1; i++) {
a[(i)- 1+ _a_offset] = y;
Dummy.label("Dlattp",120);
}              //  Close for() loop. 
}
a[(n)- 1+ _a_offset] = z;
jc = n+1;
{
forloop130:
for (j = 2; j <= n-1; j++) {
a[(jc+1)- 1+ _a_offset] = work[(j-1)- 1+ _work_offset];
if (j < n-1)  
    a[(jc+2)- 1+ _a_offset] = work[(n+j-1)- 1+ _work_offset];
a[(jc+n-j)- 1+ _a_offset] = y;
jc = jc+n-j+1;
Dummy.label("Dlattp",130);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Fill in the zeros using Givens rotations
// *
if (upper)  {
    jc = 1;
{
forloop150:
for (j = 1; j <= n-1; j++) {
jcnext = jc+j;
ra.val = a[(jcnext+j-1)- 1+ _a_offset];
rb.val = two;
Drotg.drotg(ra,rb,c,s);
// *
// *              Multiply by [ c  s; -s  c] on the left.
// *
if (n > j+1)  {
    jx = jcnext+j;
{
forloop140:
for (i = j+2; i <= n; i++) {
stemp = c.val*a[(jx+j)- 1+ _a_offset]+s.val*a[(jx+j+1)- 1+ _a_offset];
a[(jx+j+1)- 1+ _a_offset] = -s.val*a[(jx+j)- 1+ _a_offset]+c.val*a[(jx+j+1)- 1+ _a_offset];
a[(jx+j)- 1+ _a_offset] = stemp;
jx = jx+i;
Dummy.label("Dlattp",140);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Multiply by [-c -s;  s -c] on the right.
// *
if (j > 1)  
    Drot.drot(j-1,a,(jcnext)- 1+ _a_offset,1,a,(jc)- 1+ _a_offset,1,-c.val,-s.val);
// *
// *              Negate A(J,J+1).
// *
a[(jcnext+j-1)- 1+ _a_offset] = -a[(jcnext+j-1)- 1+ _a_offset];
jc = jcnext;
Dummy.label("Dlattp",150);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop170:
for (j = 1; j <= n-1; j++) {
jcnext = jc+n-j+1;
ra.val = a[(jc+1)- 1+ _a_offset];
rb.val = two;
Drotg.drotg(ra,rb,c,s);
// *
// *              Multiply by [ c -s;  s  c] on the right.
// *
if (n > j+1)  
    Drot.drot(n-j-1,a,(jcnext+1)- 1+ _a_offset,1,a,(jc+2)- 1+ _a_offset,1,c.val,-s.val);
// *
// *              Multiply by [-c  s; -s -c] on the left.
// *
if (j > 1)  {
    jx = 1;
{
forloop160:
for (i = 1; i <= j-1; i++) {
stemp = -c.val*a[(jx+j-i)- 1+ _a_offset]+s.val*a[(jx+j-i+1)- 1+ _a_offset];
a[(jx+j-i+1)- 1+ _a_offset] = -s.val*a[(jx+j-i)- 1+ _a_offset]-c.val*a[(jx+j-i+1)- 1+ _a_offset];
a[(jx+j-i)- 1+ _a_offset] = stemp;
jx = jx+n-i+1;
Dummy.label("Dlattp",160);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *              Negate A(J+1,J).
// *
a[(jc+1)- 1+ _a_offset] = -a[(jc+1)- 1+ _a_offset];
jc = jcnext;
Dummy.label("Dlattp",170);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     IMAT > 10:  Pathological test cases.  These triangular matrices
// *     are badly scaled or badly conditioned, so when used in solving a
// *     triangular system they may cause overflow in the solution vector.
// *
}              // Close else if()
else if (imat == 11)  {
    // *
// *        Type 11:  Generate a triangular matrix with elements between
// *        -1 and 1. Give the diagonal norm 2 to make it well-conditioned.
// *        Make the right hand side large so that it requires scaling.
// *
if (upper)  {
    jc = 1;
{
forloop180:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j,a,(jc)- 1+ _a_offset);
a[(jc+j-1)- 1+ _a_offset] = ((a[(jc+j-1)- 1+ _a_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
jc = jc+j;
Dummy.label("Dlattp",180);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop190:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j+1,a,(jc)- 1+ _a_offset);
a[(jc)- 1+ _a_offset] = ((a[(jc)- 1+ _a_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
jc = jc+n-j+1;
Dummy.label("Dlattp",190);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side so that the largest value is BIGNUM.
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
iy = Idamax.idamax(n,b,_b_offset,1);
bnorm = Math.abs(b[(iy)- 1+ _b_offset]);
bscal = bignum.val/Math.max(one, bnorm) ;
Dscal.dscal(n,bscal,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 12)  {
    // *
// *        Type 12:  Make the first diagonal element in the solve small to
// *        cause immediate overflow when dividing by T(j,j).
// *        In type 12, the offdiagonal elements are small (CNORM(j) < 1).
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
tscal = one/Math.max(one, (double)(n-1)) ;
if (upper)  {
    jc = 1;
{
forloop200:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j-1,a,(jc)- 1+ _a_offset);
Dscal.dscal(j-1,tscal,a,(jc)- 1+ _a_offset,1);
a[(jc+j-1)- 1+ _a_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
jc = jc+j;
Dummy.label("Dlattp",200);
}              //  Close for() loop. 
}
a[(n*(n+1)/2)- 1+ _a_offset] = smlnum.val;
}              // Close if()
else  {
  jc = 1;
{
forloop210:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j,a,(jc+1)- 1+ _a_offset);
Dscal.dscal(n-j,tscal,a,(jc+1)- 1+ _a_offset,1);
a[(jc)- 1+ _a_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
jc = jc+n-j+1;
Dummy.label("Dlattp",210);
}              //  Close for() loop. 
}
a[(1)- 1+ _a_offset] = smlnum.val;
}              //  Close else.
// *
}              // Close else if()
else if (imat == 13)  {
    // *
// *        Type 13:  Make the first diagonal element in the solve small to
// *        cause immediate overflow when dividing by T(j,j).
// *        In type 13, the offdiagonal elements are O(1) (CNORM(j) > 1).
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
if (upper)  {
    jc = 1;
{
forloop220:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j-1,a,(jc)- 1+ _a_offset);
a[(jc+j-1)- 1+ _a_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
jc = jc+j;
Dummy.label("Dlattp",220);
}              //  Close for() loop. 
}
a[(n*(n+1)/2)- 1+ _a_offset] = smlnum.val;
}              // Close if()
else  {
  jc = 1;
{
forloop230:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j,a,(jc+1)- 1+ _a_offset);
a[(jc)- 1+ _a_offset] = ((Dlarnd.dlarnd(2,iseed,_iseed_offset)) >= 0 ? Math.abs(one) : -Math.abs(one));
jc = jc+n-j+1;
Dummy.label("Dlattp",230);
}              //  Close for() loop. 
}
a[(1)- 1+ _a_offset] = smlnum.val;
}              //  Close else.
// *
}              // Close else if()
else if (imat == 14)  {
    // *
// *        Type 14:  T is diagonal with small numbers on the diagonal to
// *        make the growth factor underflow, but a small right hand side
// *        chosen so that the solution does not overflow.
// *
if (upper)  {
    jcount = 1;
jc = (n-1)*n/2+1;
{
int _j_inc = -1;
forloop250:
for (j = n; (_j_inc < 0) ? j >= 1 : j <= 1; j += _j_inc) {
{
forloop240:
for (i = 1; i <= j-1; i++) {
a[(jc+i-1)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",240);
}              //  Close for() loop. 
}
if (jcount <= 2)  {
    a[(jc+j-1)- 1+ _a_offset] = smlnum.val;
}              // Close if()
else  {
  a[(jc+j-1)- 1+ _a_offset] = one;
}              //  Close else.
jcount = jcount+1;
if (jcount > 4)  
    jcount = 1;
jc = jc-j+1;
Dummy.label("Dlattp",250);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jcount = 1;
jc = 1;
{
forloop270:
for (j = 1; j <= n; j++) {
{
forloop260:
for (i = j+1; i <= n; i++) {
a[(jc+i-j)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",260);
}              //  Close for() loop. 
}
if (jcount <= 2)  {
    a[(jc)- 1+ _a_offset] = smlnum.val;
}              // Close if()
else  {
  a[(jc)- 1+ _a_offset] = one;
}              //  Close else.
jcount = jcount+1;
if (jcount > 4)  
    jcount = 1;
jc = jc+n-j+1;
Dummy.label("Dlattp",270);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side alternately zero and small.
// *
if (upper)  {
    b[(1)- 1+ _b_offset] = zero;
{
int _i_inc = -2;
forloop280:
for (i = n; (_i_inc < 0) ? i >= 2 : i <= 2; i += _i_inc) {
b[(i)- 1+ _b_offset] = zero;
b[(i-1)- 1+ _b_offset] = smlnum.val;
Dummy.label("Dlattp",280);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  b[(n)- 1+ _b_offset] = zero;
{
int _i_inc = 2;
forloop290:
for (i = 1; (_i_inc < 0) ? i >= n-1 : i <= n-1; i += _i_inc) {
b[(i)- 1+ _b_offset] = zero;
b[(i+1)- 1+ _b_offset] = smlnum.val;
Dummy.label("Dlattp",290);
}              //  Close for() loop. 
}
}              //  Close else.
// *
}              // Close else if()
else if (imat == 15)  {
    // *
// *        Type 15:  Make the diagonal elements small to cause gradual
// *        overflow when dividing by T(j,j).  To control the amount of
// *        scaling needed, the matrix is bidiagonal.
// *
texp = one/Math.max(one, (double)(n-1)) ;
tscal = Math.pow(smlnum.val, texp);
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
if (upper)  {
    jc = 1;
{
forloop310:
for (j = 1; j <= n; j++) {
{
forloop300:
for (i = 1; i <= j-2; i++) {
a[(jc+i-1)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",300);
}              //  Close for() loop. 
}
if (j > 1)  
    a[(jc+j-2)- 1+ _a_offset] = -one;
a[(jc+j-1)- 1+ _a_offset] = tscal;
jc = jc+j;
Dummy.label("Dlattp",310);
}              //  Close for() loop. 
}
b[(n)- 1+ _b_offset] = one;
}              // Close if()
else  {
  jc = 1;
{
forloop330:
for (j = 1; j <= n; j++) {
{
forloop320:
for (i = j+2; i <= n; i++) {
a[(jc+i-j)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",320);
}              //  Close for() loop. 
}
if (j < n)  
    a[(jc+1)- 1+ _a_offset] = -one;
a[(jc)- 1+ _a_offset] = tscal;
jc = jc+n-j+1;
Dummy.label("Dlattp",330);
}              //  Close for() loop. 
}
b[(1)- 1+ _b_offset] = one;
}              //  Close else.
// *
}              // Close else if()
else if (imat == 16)  {
    // *
// *        Type 16:  One zero diagonal element.
// *
iy = n/2+1;
if (upper)  {
    jc = 1;
{
forloop340:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j,a,(jc)- 1+ _a_offset);
if (j != iy)  {
    a[(jc+j-1)- 1+ _a_offset] = ((a[(jc+j-1)- 1+ _a_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
}              // Close if()
else  {
  a[(jc+j-1)- 1+ _a_offset] = zero;
}              //  Close else.
jc = jc+j;
Dummy.label("Dlattp",340);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop350:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j+1,a,(jc)- 1+ _a_offset);
if (j != iy)  {
    a[(jc)- 1+ _a_offset] = ((a[(jc)- 1+ _a_offset]) >= 0 ? Math.abs(two) : -Math.abs(two));
}              // Close if()
else  {
  a[(jc)- 1+ _a_offset] = zero;
}              //  Close else.
jc = jc+n-j+1;
Dummy.label("Dlattp",350);
}              //  Close for() loop. 
}
}              //  Close else.
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
Dscal.dscal(n,two,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 17)  {
    // *
// *        Type 17:  Make the offdiagonal elements large to cause overflow
// *        when adding a column of T.  In the non-transposed case, the
// *        matrix is constructed to cause overflow when adding a column in
// *        every other step.
// *
tscal = unfl/ulp;
tscal = (one-ulp)/tscal;
{
forloop360:
for (j = 1; j <= n*(n+1)/2; j++) {
a[(j)- 1+ _a_offset] = zero;
Dummy.label("Dlattp",360);
}              //  Close for() loop. 
}
texp = one;
if (upper)  {
    jc = (n-1)*n/2+1;
{
int _j_inc = -2;
forloop370:
for (j = n; (_j_inc < 0) ? j >= 2 : j <= 2; j += _j_inc) {
a[(jc)- 1+ _a_offset] = -tscal/(double)(n+1);
a[(jc+j-1)- 1+ _a_offset] = one;
b[(j)- 1+ _b_offset] = texp*(one-ulp);
jc = jc-j+1;
a[(jc)- 1+ _a_offset] = -(tscal/(double)(n+1))/(double)(n+2);
a[(jc+j-2)- 1+ _a_offset] = one;
b[(j-1)- 1+ _b_offset] = texp*(double)(n*n+n-1);
texp = texp*two;
jc = jc-j+2;
Dummy.label("Dlattp",370);
}              //  Close for() loop. 
}
b[(1)- 1+ _b_offset] = ((double)(n+1)/(double)(n+2))*tscal;
}              // Close if()
else  {
  jc = 1;
{
int _j_inc = 2;
forloop380:
for (j = 1; (_j_inc < 0) ? j >= n-1 : j <= n-1; j += _j_inc) {
a[(jc+n-j)- 1+ _a_offset] = -tscal/(double)(n+1);
a[(jc)- 1+ _a_offset] = one;
b[(j)- 1+ _b_offset] = texp*(one-ulp);
jc = jc+n-j+1;
a[(jc+n-j-1)- 1+ _a_offset] = -(tscal/(double)(n+1))/(double)(n+2);
a[(jc)- 1+ _a_offset] = one;
b[(j+1)- 1+ _b_offset] = texp*(double)(n*n+n-1);
texp = texp*two;
jc = jc+n-j;
Dummy.label("Dlattp",380);
}              //  Close for() loop. 
}
b[(n)- 1+ _b_offset] = ((double)(n+1)/(double)(n+2))*tscal;
}              //  Close else.
// *
}              // Close else if()
else if (imat == 18)  {
    // *
// *        Type 18:  Generate a unit triangular matrix with elements
// *        between -1 and 1, and make the right hand side large so that it
// *        requires scaling.
// *
if (upper)  {
    jc = 1;
{
forloop390:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j-1,a,(jc)- 1+ _a_offset);
a[(jc+j-1)- 1+ _a_offset] = zero;
jc = jc+j;
Dummy.label("Dlattp",390);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop400:
for (j = 1; j <= n; j++) {
if (j < n)  
    Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j,a,(jc+1)- 1+ _a_offset);
a[(jc)- 1+ _a_offset] = zero;
jc = jc+n-j+1;
Dummy.label("Dlattp",400);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *        Set the right hand side so that the largest value is BIGNUM.
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
iy = Idamax.idamax(n,b,_b_offset,1);
bnorm = Math.abs(b[(iy)- 1+ _b_offset]);
bscal = bignum.val/Math.max(one, bnorm) ;
Dscal.dscal(n,bscal,b,_b_offset,1);
// *
}              // Close else if()
else if (imat == 19)  {
    // *
// *        Type 19:  Generate a triangular matrix with elements between
// *        BIGNUM/(n-1) and BIGNUM so that at least one of the column
// *        norms will exceed BIGNUM.
// *
tleft = bignum.val/Math.max(one, (double)(n-1)) ;
tscal = bignum.val*((double)(n-1)/Math.max(one, (double)(n)) );
if (upper)  {
    jc = 1;
{
forloop420:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,j,a,(jc)- 1+ _a_offset);
{
forloop410:
for (i = 1; i <= j; i++) {
a[(jc+i-1)- 1+ _a_offset] = ((a[(jc+i-1)- 1+ _a_offset]) >= 0 ? Math.abs(tleft) : -Math.abs(tleft))+tscal*a[(jc+i-1)- 1+ _a_offset];
Dummy.label("Dlattp",410);
}              //  Close for() loop. 
}
jc = jc+j;
Dummy.label("Dlattp",420);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop440:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,n-j+1,a,(jc)- 1+ _a_offset);
{
forloop430:
for (i = j; i <= n; i++) {
a[(jc+i-j)- 1+ _a_offset] = ((a[(jc+i-j)- 1+ _a_offset]) >= 0 ? Math.abs(tleft) : -Math.abs(tleft))+tscal*a[(jc+i-j)- 1+ _a_offset];
Dummy.label("Dlattp",430);
}              //  Close for() loop. 
}
jc = jc+n-j+1;
Dummy.label("Dlattp",440);
}              //  Close for() loop. 
}
}              //  Close else.
Dlarnv.dlarnv(2,iseed,_iseed_offset,n,b,_b_offset);
Dscal.dscal(n,two,b,_b_offset,1);
}              // Close else if()
// *
// *     Flip the matrix across its counter-diagonal if the transpose will
// *     be used.
// *
if (!(trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    if (upper)  {
    jj = 1;
jr = n*(n+1)/2;
{
forloop460:
for (j = 1; j <= n/2; j++) {
jl = jj;
{
forloop450:
for (i = j; i <= n-j; i++) {
t = a[(jr-i+j)- 1+ _a_offset];
a[(jr-i+j)- 1+ _a_offset] = a[(jl)- 1+ _a_offset];
a[(jl)- 1+ _a_offset] = t;
jl = jl+i;
Dummy.label("Dlattp",450);
}              //  Close for() loop. 
}
jj = jj+j+1;
jr = jr-(n-j+1);
Dummy.label("Dlattp",460);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jl = 1;
jj = n*(n+1)/2;
{
forloop480:
for (j = 1; j <= n/2; j++) {
jr = jj;
{
forloop470:
for (i = j; i <= n-j; i++) {
t = a[(jl+i-j)- 1+ _a_offset];
a[(jl+i-j)- 1+ _a_offset] = a[(jr)- 1+ _a_offset];
a[(jr)- 1+ _a_offset] = t;
jr = jr-i;
Dummy.label("Dlattp",470);
}              //  Close for() loop. 
}
jl = jl+n-j+1;
jj = jj-j-1;
Dummy.label("Dlattp",480);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
// *
Dummy.go_to("Dlattp",999999);
// *
// *     End of DLATTP
// *
Dummy.label("Dlattp",999999);
return;
   }
} // End class.
