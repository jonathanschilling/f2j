/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlqt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLQT01 tests DGELQF, which computes the LQ factorization of an m-by-n
// *  matrix A, and partially tests DORGLQ which forms the n-by-n
// *  orthogonal matrix Q.
// *
// *  DLQT01 compares L with A*Q', and checks that Q is orthogonal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A.
// *
// *  AF      (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the LQ factorization of A, as returned by DGELQF.
// *          See DGELQF for further details.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The n-by-n orthogonal matrix Q.
// *
// *  L       (workspace) DOUBLE PRECISION array, dimension (LDA,max(M,N))
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and L.
// *          LDA >= max(M,N).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGELQF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (max(M,N))
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *          RESULT(1) = norm( L - A*Q' ) / ( N * norm(A) * EPS )
// *          RESULT(2) = norm( I - Q*Q' ) / ( N * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static int minmn= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlqt01 (int m,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] l, int _l_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

minmn = (int)(Math.min(m, n) );
eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the matrix A to the array AF.
// *
Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,af,_af_offset,lda);
// *
// *     Factorize the matrix A in the array AF.
// *
lintest_srnamc.srnamt = "DGELQF";
Dgelqf.dgelqf(m,n,af,_af_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy details of Q
// *
Dlaset.dlaset("Full",n,n,rogue,rogue,q,_q_offset,lda);
if (n > 1)  
    Dlacpy.dlacpy("Upper",m,n-1,af,(1)- 1+(2- 1)*lda+ _af_offset,lda,q,(1)- 1+(2- 1)*lda+ _q_offset,lda);
// *
// *     Generate the n-by-n matrix Q
// *
lintest_srnamc.srnamt = "DORGLQ";
Dorglq.dorglq(n,n,minmn,q,_q_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy L
// *
Dlaset.dlaset("Full",m,n,zero,zero,l,_l_offset,lda);
Dlacpy.dlacpy("Lower",m,n,af,_af_offset,lda,l,_l_offset,lda);
// *
// *     Compute L - A*Q'
// *
Dgemm.dgemm("No transpose","Transpose",m,n,n,-one,a,_a_offset,lda,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( L - Q'*A ) / ( N * norm(A) * EPS ) .
// *
anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset);
resid = Dlange.dlange("1",m,n,l,_l_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max(1, n) ))/anorm)/eps;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q*Q'
// *
Dlaset.dlaset("Full",n,n,zero,one,l,_l_offset,lda);
Dsyrk.dsyrk("Upper","No transpose",n,n,-one,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( I - Q*Q' ) / ( N * EPS ) .
// *
resid = Dlansy.dlansy("1","Upper",n,l,_l_offset,lda,rwork,_rwork_offset);
// *
result[(2)- 1+ _result_offset] = (resid/(double)(Math.max(1, n) ))/eps;
// *
Dummy.go_to("Dlqt01",999999);
// *
// *     End of DLQT01
// *
Dummy.label("Dlqt01",999999);
return;
   }
} // End class.
