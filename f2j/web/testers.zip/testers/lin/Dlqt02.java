/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dlqt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DLQT02 tests DORGLQ, which generates an m-by-n matrix Q with
// *  orthonornmal rows that is defined as the product of k elementary
// *  reflectors.
// *
// *  Given the LQ factorization of an m-by-n matrix A, DLQT02 generates
// *  the orthogonal matrix Q defined by the factorization of the first k
// *  rows of A; it compares L(1:k,1:m) with A(1:k,1:n)*Q(1:m,1:n)', and
// *  checks that the rows of Q are orthonormal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q to be generated.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q to be generated.
// *          N >= M >= 0.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. M >= K >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A which was factorized by DLQT01.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the LQ factorization of A, as returned by DGELQF.
// *          See DGELQF for further details.
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  L       (workspace) DOUBLE PRECISION array, dimension (LDA,M)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and L. LDA >= N.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (M)
// *          The scalar factors of the elementary reflectors corresponding
// *          to the LQ factorization in AF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *          RESULT(1) = norm( L - A*Q' ) / ( N * norm(A) * EPS )
// *          RESULT(2) = norm( I - Q*Q' ) / ( N * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dlqt02 (int m,
int n,
int k,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] l, int _l_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the first k rows of the factorization to the array Q
// *
Dlaset.dlaset("Full",m,n,rogue,rogue,q,_q_offset,lda);
Dlacpy.dlacpy("Upper",k,n-1,af,(1)- 1+(2- 1)*lda+ _af_offset,lda,q,(1)- 1+(2- 1)*lda+ _q_offset,lda);
// *
// *     Generate the first n columns of the matrix Q
// *
lintest_srnamc.srnamt = "DORGLQ";
Dorglq.dorglq(m,n,k,q,_q_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy L(1:k,1:m)
// *
Dlaset.dlaset("Full",k,m,zero,zero,l,_l_offset,lda);
Dlacpy.dlacpy("Lower",k,m,af,_af_offset,lda,l,_l_offset,lda);
// *
// *     Compute L(1:k,1:m) - A(1:k,1:n) * Q(1:m,1:n)'
// *
Dgemm.dgemm("No transpose","Transpose",k,m,n,-one,a,_a_offset,lda,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( L - A*Q' ) / ( N * norm(A) * EPS ) .
// *
anorm = Dlange.dlange("1",k,n,a,_a_offset,lda,rwork,_rwork_offset);
resid = Dlange.dlange("1",k,m,l,_l_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max(1, n) ))/anorm)/eps;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q*Q'
// *
Dlaset.dlaset("Full",m,m,zero,one,l,_l_offset,lda);
Dsyrk.dsyrk("Upper","No transpose",m,n,-one,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( I - Q*Q' ) / ( N * EPS ) .
// *
resid = Dlansy.dlansy("1","Upper",m,l,_l_offset,lda,rwork,_rwork_offset);
// *
result[(2)- 1+ _result_offset] = (resid/(double)(Math.max(1, n) ))/eps;
// *
Dummy.go_to("Dlqt02",999999);
// *
// *     End of DLQT02
// *
Dummy.label("Dlqt02",999999);
return;
   }
} // End class.
