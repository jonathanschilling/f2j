/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dpbt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPBT01 reconstructs a symmetric positive definite band matrix A from
// *  its L*L' or U'*U factorization and computes the residual
// *     norm( L*L' - A ) / ( N * norm(A) * EPS ) or
// *     norm( U'*U - A ) / ( N * norm(A) * EPS ),
// *  where EPS is the machine epsilon, L' is the conjugate transpose of
// *  L, and U' is the conjugate transpose of U.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  KD      (input) INTEGER
// *          The number of super-diagonals of the matrix A if UPLO = 'U',
// *          or the number of sub-diagonals if UPLO = 'L'.  KD >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original symmetric band matrix A.  If UPLO = 'U', the
// *          upper triangular part of A is stored as a band matrix; if
// *          UPLO = 'L', the lower triangular part of A is stored.  The
// *          columns of the appropriate triangle are stored in the columns
// *          of A and the diagonals of the triangle are stored in the rows
// *          of A.  See DPBTRF for further details.
// *
// *  LDA     (input) INTEGER.
// *          The leading dimension of the array A.  LDA >= max(1,KD+1).
// *
// *  AFAC    (input) DOUBLE PRECISION array, dimension (LDAFAC,N)
// *          The factored form of the matrix A.  AFAC contains the factor
// *          L or U from the L*L' or U'*U factorization in band storage
// *          format, as computed by DPBTRF.
// *
// *  LDAFAC  (input) INTEGER
// *          The leading dimension of the array AFAC.
// *          LDAFAC >= max(1,KD+1).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          If UPLO = 'L', norm(L*L' - A) / ( N * norm(A) * EPS )
// *          If UPLO = 'U', norm(U'*U - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int k= 0;
static int kc= 0;
static int klen= 0;
static int ml= 0;
static int mu= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dpbt01 (String uplo,
int n,
int kd,
double [] a, int _a_offset,
int lda,
double [] afac, int _afac_offset,
int ldafac,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dpbt01",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansb.dlansb("1",uplo,n,kd,a,_a_offset,lda,rwork,_rwork_offset);
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dpbt01",999999);
}              // Close if()
// *
// *     Compute the product U'*U, overwriting U.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
int _k_inc = -1;
forloop10:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
kc = (int)(Math.max(1, kd+2-k) );
klen = kd+1-kc;
// *
// *           Compute the (K,K) element of the result.
// *
t = Ddot.ddot(klen+1,afac,(kc)- 1+(k- 1)*ldafac+ _afac_offset,1,afac,(kc)- 1+(k- 1)*ldafac+ _afac_offset,1);
afac[(kd+1)- 1+(k- 1)*ldafac+ _afac_offset] = t;
// *
// *           Compute the rest of column K.
// *
if (klen > 0)  
    Dtrmv.dtrmv("Upper","Transpose","Non-unit",klen,afac,(kd+1)- 1+(k-klen- 1)*ldafac+ _afac_offset,ldafac-1,afac,(kc)- 1+(k- 1)*ldafac+ _afac_offset,1);
// *
Dummy.label("Dpbt01",10);
}              //  Close for() loop. 
}
// *
// *     UPLO = 'L':  Compute the product L*L', overwriting L.
// *
}              // Close if()
else  {
  {
int _k_inc = -1;
forloop20:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
klen = (int)(Math.min(kd, n-k) );
// *
// *           Add a multiple of column K of the factor L to each of
// *           columns K+1 through N.
// *
if (klen > 0)  
    Dsyr.dsyr("Lower",klen,one,afac,(2)- 1+(k- 1)*ldafac+ _afac_offset,1,afac,(1)- 1+(k+1- 1)*ldafac+ _afac_offset,ldafac-1);
// *
// *           Scale column K by the diagonal element.
// *
t = afac[(1)- 1+(k- 1)*ldafac+ _afac_offset];
Dscal.dscal(klen+1,t,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
// *
Dummy.label("Dpbt01",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute the difference  L*L' - A  or  U'*U - A.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop40:
for (j = 1; j <= n; j++) {
mu = (int)(Math.max(1, kd+2-j) );
{
forloop30:
for (i = mu; i <= kd+1; i++) {
afac[(i)- 1+(j- 1)*ldafac+ _afac_offset] = afac[(i)- 1+(j- 1)*ldafac+ _afac_offset]-a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dpbt01",30);
}              //  Close for() loop. 
}
Dummy.label("Dpbt01",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop60:
for (j = 1; j <= n; j++) {
ml = (int)(Math.min(kd+1, n-j+1) );
{
forloop50:
for (i = 1; i <= ml; i++) {
afac[(i)- 1+(j- 1)*ldafac+ _afac_offset] = afac[(i)- 1+(j- 1)*ldafac+ _afac_offset]-a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dpbt01",50);
}              //  Close for() loop. 
}
Dummy.label("Dpbt01",60);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute norm( L*L' - A ) / ( N * norm(A) * EPS )
// *
resid.val = Dlansb.dlansb("I",uplo,n,kd,afac,_afac_offset,ldafac,rwork,_rwork_offset);
// *
resid.val = ((resid.val/(double)(n))/anorm)/eps;
// *
Dummy.go_to("Dpbt01",999999);
// *
// *     End of DPBT01
// *
Dummy.label("Dpbt01",999999);
return;
   }
} // End class.
