/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dpbt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPBT02 computes the residual for a solution of a symmetric banded
// *  system of equations  A*x = b:
// *     RESID = norm( B - A*X ) / ( norm(A) * norm(X) * EPS)
// *  where EPS is the machine precision.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  KD      (input) INTEGER
// *          The number of super-diagonals of the matrix A if UPLO = 'U',
// *          or the number of sub-diagonals if UPLO = 'L'.  KD >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original symmetric band matrix A.  If UPLO = 'U', the
// *          upper triangular part of A is stored as a band matrix; if
// *          UPLO = 'L', the lower triangular part of A is stored.  The
// *          columns of the appropriate triangle are stored in the columns
// *          of A and the diagonals of the triangle are stored in the rows
// *          of A.  See DPBTRF for further details.
// *
// *  LDA     (input) INTEGER.
// *          The leading dimension of the array A.  LDA >= max(1,KD+1).
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.   LDX >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side vectors for the system of
// *          linear equations.
// *          On exit, B is overwritten with the difference B - A*X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(B - A*X) / ( norm(A) * norm(X) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0.
// *

public static void dpbt02 (String uplo,
int n,
int kd,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dpbt02",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansb.dlansb("1",uplo,n,kd,a,_a_offset,lda,rwork,_rwork_offset);
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dpbt02",999999);
}              // Close if()
// *
// *     Compute  B - A*X
// *
{
forloop10:
for (j = 1; j <= nrhs; j++) {
Dsbmv.dsbmv(uplo,n,kd,-one,a,_a_offset,lda,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,one,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
Dummy.label("Dpbt02",10);
}              //  Close for() loop. 
}
// *
// *     Compute the maximum over the number of right hand sides of
// *          norm( B - A*X ) / ( norm(A) * norm(X) * EPS )
// *
resid.val = zero;
{
forloop20:
for (j = 1; j <= nrhs; j++) {
bnorm = Dasum.dasum(n,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
xnorm = Dasum.dasum(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (xnorm <= zero)  {
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/eps) ;
}              //  Close else.
Dummy.label("Dpbt02",20);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dpbt02",999999);
// *
// *     End of DPBT02
// *
Dummy.label("Dpbt02",999999);
return;
   }
} // End class.
