/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dpot01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPOT01 reconstructs a symmetric positive definite matrix  A  from
// *  its L*L' or U'*U factorization and computes the residual
// *     norm( L*L' - A ) / ( N * norm(A) * EPS ) or
// *     norm( U'*U - A ) / ( N * norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original symmetric matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N)
// *
// *  AFAC    (input/output) DOUBLE PRECISION array, dimension (LDAFAC,N)
// *          On entry, the factor L or U from the L*L' or U'*U
// *          factorization of A.
// *          Overwritten with the reconstructed matrix, and then with the
// *          difference L*L' - A (or U'*U - A).
// *
// *  LDAFAC  (input) INTEGER
// *          The leading dimension of the array AFAC.  LDAFAC >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          If UPLO = 'L', norm(L*L' - A) / ( N * norm(A) * EPS )
// *          If UPLO = 'U', norm(U'*U - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int k= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dpot01 (String uplo,
int n,
double [] a, int _a_offset,
int lda,
double [] afac, int _afac_offset,
int ldafac,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dpot01",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,rwork,_rwork_offset);
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dpot01",999999);
}              // Close if()
// *
// *     Compute the product U'*U, overwriting U.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
int _k_inc = -1;
forloop10:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
// *
// *           Compute the (K,K) element of the result.
// *
t = Ddot.ddot(k,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
afac[(k)- 1+(k- 1)*ldafac+ _afac_offset] = t;
// *
// *           Compute the rest of column K.
// *
Dtrmv.dtrmv("Upper","Transpose","Non-unit",k-1,afac,_afac_offset,ldafac,afac,(1)- 1+(k- 1)*ldafac+ _afac_offset,1);
// *
Dummy.label("Dpot01",10);
}              //  Close for() loop. 
}
// *
// *     Compute the product L*L', overwriting L.
// *
}              // Close if()
else  {
  {
int _k_inc = -1;
forloop20:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
// *
// *           Add a multiple of column K of the factor L to each of
// *           columns K+1 through N.
// *
if (k+1 <= n)  
    Dsyr.dsyr("Lower",n-k,one,afac,(k+1)- 1+(k- 1)*ldafac+ _afac_offset,1,afac,(k+1)- 1+(k+1- 1)*ldafac+ _afac_offset,ldafac);
// *
// *           Scale column K by the diagonal element.
// *
t = afac[(k)- 1+(k- 1)*ldafac+ _afac_offset];
Dscal.dscal(n-k+1,t,afac,(k)- 1+(k- 1)*ldafac+ _afac_offset,1);
// *
Dummy.label("Dpot01",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute the difference  L*L' - A (or U'*U - A).
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = 1; i <= j; i++) {
afac[(i)- 1+(j- 1)*ldafac+ _afac_offset] = afac[(i)- 1+(j- 1)*ldafac+ _afac_offset]-a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dpot01",30);
}              //  Close for() loop. 
}
Dummy.label("Dpot01",40);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop60:
for (j = 1; j <= n; j++) {
{
forloop50:
for (i = j; i <= n; i++) {
afac[(i)- 1+(j- 1)*ldafac+ _afac_offset] = afac[(i)- 1+(j- 1)*ldafac+ _afac_offset]-a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dpot01",50);
}              //  Close for() loop. 
}
Dummy.label("Dpot01",60);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute norm( L*U - A ) / ( N * norm(A) * EPS )
// *
resid.val = Dlansy.dlansy("1",uplo,n,afac,_afac_offset,ldafac,rwork,_rwork_offset);
// *
resid.val = ((resid.val/(double)(n))/anorm)/eps;
// *
Dummy.go_to("Dpot01",999999);
// *
// *     End of DPOT01
// *
Dummy.label("Dpot01",999999);
return;
   }
} // End class.
