/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dpot02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPOT02 computes the residual for the solution of a symmetric system
// *  of linear equations  A*x = b:
// *
// *     RESID = norm(B - A*X) / ( norm(A) * norm(X) * EPS ),
// *
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of B, the matrix of right hand sides.
// *          NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original symmetric matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N)
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.   LDX >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side vectors for the system of
// *          linear equations.
// *          On exit, B is overwritten with the difference B - A*X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(B - A*X) / ( norm(A) * norm(X) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0.
// *

public static void dpot02 (String uplo,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dpot02",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,rwork,_rwork_offset);
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dpot02",999999);
}              // Close if()
// *
// *     Compute  B - A*X
// *
Dsymm.dsymm("Left",uplo,n,nrhs,-one,a,_a_offset,lda,x,_x_offset,ldx,one,b,_b_offset,ldb);
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm( B - A*X ) / ( norm(A) * norm(X) * EPS ) .
// *
resid.val = zero;
{
forloop10:
for (j = 1; j <= nrhs; j++) {
bnorm = Dasum.dasum(n,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
xnorm = Dasum.dasum(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (xnorm <= zero)  {
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/eps) ;
}              //  Close else.
Dummy.label("Dpot02",10);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dpot02",999999);
// *
// *     End of DPOT02
// *
Dummy.label("Dpot02",999999);
return;
   }
} // End class.
