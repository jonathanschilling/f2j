/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dpot03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPOT03 computes the residual for a symmetric matrix times its
// *  inverse:
// *     norm( I - A*AINV ) / ( N * norm(A) * norm(AINV) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original symmetric matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N)
// *
// *  AINV    (input/output) DOUBLE PRECISION array, dimension (LDAINV,N)
// *          On entry, the inverse of the matrix A, stored as a symmetric
// *          matrix in the same format as A.
// *          In this version, AINV is expanded into a full matrix and
// *          multiplied by A, so the opposing triangle of AINV will be
// *          changed; i.e., if the upper triangular part of AINV is
// *          stored, the lower triangular part will be used as work space.
// *
// *  LDAINV  (input) INTEGER
// *          The leading dimension of the array AINV.  LDAINV >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK,N)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of the array WORK.  LDWORK >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of A, computed as
// *          ( 1/norm(A) ) / norm(AINV).
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(I - A*AINV) / ( N * norm(A) * norm(AINV) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dpot03 (String uplo,
int n,
double [] a, int _a_offset,
int lda,
double [] ainv, int _ainv_offset,
int ldainv,
double [] work, int _work_offset,
int ldwork,
double [] rwork, int _rwork_offset,
doubleW rcond,
doubleW resid)  {

if (n <= 0)  {
    rcond.val = one;
resid.val = zero;
Dummy.go_to("Dpot03",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0 or AINVNM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansy.dlansy("1",uplo,n,a,_a_offset,lda,rwork,_rwork_offset);
ainvnm = Dlansy.dlansy("1",uplo,n,ainv,_ainv_offset,ldainv,rwork,_rwork_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcond.val = zero;
resid.val = one/eps;
Dummy.go_to("Dpot03",999999);
}              // Close if()
rcond.val = (one/anorm)/ainvnm;
// *
// *     Expand AINV into a full matrix and call DSYMM to multiply
// *     AINV on the left by A.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= j-1; i++) {
ainv[(j)- 1+(i- 1)*ldainv+ _ainv_offset] = ainv[(i)- 1+(j- 1)*ldainv+ _ainv_offset];
Dummy.label("Dpot03",10);
}              //  Close for() loop. 
}
Dummy.label("Dpot03",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = j+1; i <= n; i++) {
ainv[(j)- 1+(i- 1)*ldainv+ _ainv_offset] = ainv[(i)- 1+(j- 1)*ldainv+ _ainv_offset];
Dummy.label("Dpot03",30);
}              //  Close for() loop. 
}
Dummy.label("Dpot03",40);
}              //  Close for() loop. 
}
}              //  Close else.
Dsymm.dsymm("Left",uplo,n,n,-one,a,_a_offset,lda,ainv,_ainv_offset,ldainv,zero,work,_work_offset,ldwork);
// *
// *     Add the identity matrix to WORK .
// *
{
forloop50:
for (i = 1; i <= n; i++) {
work[(i)- 1+(i- 1)*ldwork+ _work_offset] = work[(i)- 1+(i- 1)*ldwork+ _work_offset]+one;
Dummy.label("Dpot03",50);
}              //  Close for() loop. 
}
// *
// *     Compute norm(I - A*AINV) / (N * norm(A) * norm(AINV) * EPS)
// *
resid.val = Dlange.dlange("1",n,n,work,_work_offset,ldwork,rwork,_rwork_offset);
// *
resid.val = ((resid.val*rcond.val)/eps)/(double)(n);
// *
Dummy.go_to("Dpot03",999999);
// *
// *     End of DPOT03
// *
Dummy.label("Dpot03",999999);
return;
   }
} // End class.
