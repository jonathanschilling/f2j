/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dppt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPPT01 reconstructs a symmetric positive definite packed matrix A
// *  from its L*L' or U'*U factorization and computes the residual
// *     norm( L*L' - A ) / ( N * norm(A) * EPS ) or
// *     norm( U'*U - A ) / ( N * norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The original symmetric matrix A, stored as a packed
// *          triangular matrix.
// *
// *  AFAC    (input/output) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          On entry, the factor L or U from the L*L' or U'*U
// *          factorization of A, stored as a packed triangular matrix.
// *          Overwritten with the reconstructed matrix, and then with the
// *          difference L*L' - A (or U'*U - A).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          If UPLO = 'L', norm(L*L' - A) / ( N * norm(A) * EPS )
// *          If UPLO = 'U', norm(U'*U - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int k= 0;
static int kc= 0;
static int npp= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double t= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0
// *

public static void dppt01 (String uplo,
int n,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dppt01",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansp.dlansp("1",uplo,n,a,_a_offset,rwork,_rwork_offset);
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dppt01",999999);
}              // Close if()
// *
// *     Compute the product U'*U, overwriting U.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    kc = (n*(n-1))/2+1;
{
int _k_inc = -1;
forloop10:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
// *
// *           Compute the (K,K) element of the result.
// *
t = Ddot.ddot(k,afac,(kc)- 1+ _afac_offset,1,afac,(kc)- 1+ _afac_offset,1);
afac[(kc+k-1)- 1+ _afac_offset] = t;
// *
// *           Compute the rest of column K.
// *
if (k > 1)  {
    Dtpmv.dtpmv("Upper","Transpose","Non-unit",k-1,afac,_afac_offset,afac,(kc)- 1+ _afac_offset,1);
kc = kc-(k-1);
}              // Close if()
Dummy.label("Dppt01",10);
}              //  Close for() loop. 
}
// *
// *     Compute the product L*L', overwriting L.
// *
}              // Close if()
else  {
  kc = (n*(n+1))/2;
{
int _k_inc = -1;
forloop20:
for (k = n; (_k_inc < 0) ? k >= 1 : k <= 1; k += _k_inc) {
// *
// *           Add a multiple of column K of the factor L to each of
// *           columns K+1 through N.
// *
if (k < n)  
    Dspr.dspr("Lower",n-k,one,afac,(kc+1)- 1+ _afac_offset,1,afac,(kc+n-k+1)- 1+ _afac_offset);
// *
// *           Scale column K by the diagonal element.
// *
t = afac[(kc)- 1+ _afac_offset];
Dscal.dscal(n-k+1,t,afac,(kc)- 1+ _afac_offset,1);
// *
kc = kc-(n-k+2);
Dummy.label("Dppt01",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute the difference  L*L' - A (or U'*U - A).
// *
npp = n*(n+1)/2;
{
forloop30:
for (i = 1; i <= npp; i++) {
afac[(i)- 1+ _afac_offset] = afac[(i)- 1+ _afac_offset]-a[(i)- 1+ _a_offset];
Dummy.label("Dppt01",30);
}              //  Close for() loop. 
}
// *
// *     Compute norm( L*U - A ) / ( N * norm(A) * EPS )
// *
resid.val = Dlansp.dlansp("1",uplo,n,afac,_afac_offset,rwork,_rwork_offset);
// *
resid.val = ((resid.val/(double)(n))/anorm)/eps;
// *
Dummy.go_to("Dppt01",999999);
// *
// *     End of DPPT01
// *
Dummy.label("Dppt01",999999);
return;
   }
} // End class.
