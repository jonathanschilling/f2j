/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dppt03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPPT03 computes the residual for a symmetric packed matrix times its
// *  inverse:
// *     norm( I - A*AINV ) / ( N * norm(A) * norm(AINV) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The original symmetric matrix A, stored as a packed
// *          triangular matrix.
// *
// *  AINV    (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The (symmetric) inverse of the matrix A, stored as a packed
// *          triangular matrix.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LDWORK,N)
// *
// *  LDWORK  (input) INTEGER
// *          The leading dimension of the array WORK.  LDWORK >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal of the condition number of A, computed as
// *          ( 1/norm(A) ) / norm(AINV).
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(I - A*AINV) / ( N * norm(A) * norm(AINV) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static int jj= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dppt03 (String uplo,
int n,
double [] a, int _a_offset,
double [] ainv, int _ainv_offset,
double [] work, int _work_offset,
int ldwork,
double [] rwork, int _rwork_offset,
doubleW rcond,
doubleW resid)  {

if (n <= 0)  {
    rcond.val = one;
resid.val = zero;
Dummy.go_to("Dppt03",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0 or AINVNM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansp.dlansp("1",uplo,n,a,_a_offset,rwork,_rwork_offset);
ainvnm = Dlansp.dlansp("1",uplo,n,ainv,_ainv_offset,rwork,_rwork_offset);
if (anorm <= zero || ainvnm == zero)  {
    rcond.val = zero;
resid.val = one/eps;
Dummy.go_to("Dppt03",999999);
}              // Close if()
rcond.val = (one/anorm)/ainvnm;
// *
// *     UPLO = 'U':
// *     Copy the leading N-1 x N-1 submatrix of AINV to WORK(1:N,2:N) and
// *     expand it to a full matrix, then multiply by A one column at a
// *     time, moving the result one column to the left.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    // *
// *        Copy AINV
// *
jj = 1;
{
forloop10:
for (j = 1; j <= n-1; j++) {
Dcopy.dcopy(j,ainv,(jj)- 1+ _ainv_offset,1,work,(1)- 1+(j+1- 1)*ldwork+ _work_offset,1);
Dcopy.dcopy(j-1,ainv,(jj)- 1+ _ainv_offset,1,work,(j)- 1+(2- 1)*ldwork+ _work_offset,ldwork);
jj = jj+j;
Dummy.label("Dppt03",10);
}              //  Close for() loop. 
}
jj = ((n-1)*n)/2+1;
Dcopy.dcopy(n-1,ainv,(jj)- 1+ _ainv_offset,1,work,(n)- 1+(2- 1)*ldwork+ _work_offset,ldwork);
// *
// *        Multiply by A
// *
{
forloop20:
for (j = 1; j <= n-1; j++) {
Dspmv.dspmv("Upper",n,-one,a,_a_offset,work,(1)- 1+(j+1- 1)*ldwork+ _work_offset,1,zero,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dppt03",20);
}              //  Close for() loop. 
}
Dspmv.dspmv("Upper",n,-one,a,_a_offset,ainv,(jj)- 1+ _ainv_offset,1,zero,work,(1)- 1+(n- 1)*ldwork+ _work_offset,1);
// *
// *     UPLO = 'L':
// *     Copy the trailing N-1 x N-1 submatrix of AINV to WORK(1:N,1:N-1)
// *     and multiply by A, moving each column to the right.
// *
}              // Close if()
else  {
  // *
// *        Copy AINV
// *
Dcopy.dcopy(n-1,ainv,(2)- 1+ _ainv_offset,1,work,(1)- 1+(1- 1)*ldwork+ _work_offset,ldwork);
jj = n+1;
{
forloop30:
for (j = 2; j <= n; j++) {
Dcopy.dcopy(n-j+1,ainv,(jj)- 1+ _ainv_offset,1,work,(j)- 1+(j-1- 1)*ldwork+ _work_offset,1);
Dcopy.dcopy(n-j,ainv,(jj+1)- 1+ _ainv_offset,1,work,(j)- 1+(j- 1)*ldwork+ _work_offset,ldwork);
jj = jj+n-j+1;
Dummy.label("Dppt03",30);
}              //  Close for() loop. 
}
// *
// *        Multiply by A
// *
{
int _j_inc = -1;
forloop40:
for (j = n; (_j_inc < 0) ? j >= 2 : j <= 2; j += _j_inc) {
Dspmv.dspmv("Lower",n,-one,a,_a_offset,work,(1)- 1+(j-1- 1)*ldwork+ _work_offset,1,zero,work,(1)- 1+(j- 1)*ldwork+ _work_offset,1);
Dummy.label("Dppt03",40);
}              //  Close for() loop. 
}
Dspmv.dspmv("Lower",n,-one,a,_a_offset,ainv,(1)- 1+ _ainv_offset,1,zero,work,(1)- 1+(1- 1)*ldwork+ _work_offset,1);
// *
}              //  Close else.
// *
// *     Add the identity matrix to WORK .
// *
{
forloop50:
for (i = 1; i <= n; i++) {
work[(i)- 1+(i- 1)*ldwork+ _work_offset] = work[(i)- 1+(i- 1)*ldwork+ _work_offset]+one;
Dummy.label("Dppt03",50);
}              //  Close for() loop. 
}
// *
// *     Compute norm(I - A*AINV) / (N * norm(A) * norm(AINV) * EPS)
// *
resid.val = Dlange.dlange("1",n,n,work,_work_offset,ldwork,rwork,_rwork_offset);
// *
resid.val = ((resid.val*rcond.val)/eps)/(double)(n);
// *
Dummy.go_to("Dppt03",999999);
// *
// *     End of DPPT03
// *
Dummy.label("Dppt03",999999);
return;
   }
} // End class.
