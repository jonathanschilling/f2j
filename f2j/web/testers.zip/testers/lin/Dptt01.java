/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dptt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPTT01 reconstructs a tridiagonal matrix A from its L*D*L'
// *  factorization and computes the residual
// *     norm(L*D*L' - A) / ( n * norm(A) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGTER
// *          The order of the matrix A.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the tridiagonal matrix A.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal elements of the tridiagonal matrix A.
// *
// *  DF      (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the factor L from the L*D*L'
// *          factorization of A.
// *
// *  EF      (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal elements of the factor L from the
// *          L*D*L' factorization of A.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (2*N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(L*D*L' - A) / (n * norm(A) * EPS)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static double anorm= 0.0;
static double de= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dptt01 (int n,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] df, int _df_offset,
double [] ef, int _ef_offset,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dptt01",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
// *
// *     Construct the difference L*D*L' - A.
// *
work[(1)- 1+ _work_offset] = df[(1)- 1+ _df_offset]-d[(1)- 1+ _d_offset];
{
forloop10:
for (i = 1; i <= n-1; i++) {
de = df[(i)- 1+ _df_offset]*ef[(i)- 1+ _ef_offset];
work[(n+i)- 1+ _work_offset] = de-e[(i)- 1+ _e_offset];
work[(1+i)- 1+ _work_offset] = de*ef[(i)- 1+ _ef_offset]+df[(i+1)- 1+ _df_offset]-d[(i+1)- 1+ _d_offset];
Dummy.label("Dptt01",10);
}              //  Close for() loop. 
}
// *
// *     Compute the 1-norms of the tridiagonal matrices A and WORK.
// *
if (n == 1)  {
    anorm = d[(1)- 1+ _d_offset];
resid.val = Math.abs(work[(1)- 1+ _work_offset]);
}              // Close if()
else  {
  anorm = Math.max(d[(1)- 1+ _d_offset]+Math.abs(e[(1)- 1+ _e_offset]), d[(n)- 1+ _d_offset]+Math.abs(e[(n-1)- 1+ _e_offset])) ;
resid.val = Math.max(Math.abs(work[(1)- 1+ _work_offset])+Math.abs(work[(n+1)- 1+ _work_offset]), Math.abs(work[(n)- 1+ _work_offset])+Math.abs(work[(2*n-1)- 1+ _work_offset])) ;
{
forloop20:
for (i = 2; i <= n-1; i++) {
anorm = Math.max(anorm, d[(i)- 1+ _d_offset]+Math.abs(e[(i)- 1+ _e_offset])+Math.abs(e[(i-1)- 1+ _e_offset])) ;
resid.val = Math.max(resid.val, Math.abs(work[(i)- 1+ _work_offset])+Math.abs(work[(n+i-1)- 1+ _work_offset])+Math.abs(work[(n+i)- 1+ _work_offset])) ;
Dummy.label("Dptt01",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute norm(L*D*L' - A) / (n * norm(A) * EPS)
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = ((resid.val/(double)(n))/anorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dptt01",999999);
// *
// *     End of DPTT01
// *
Dummy.label("Dptt01",999999);
return;
   }
} // End class.
