/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dptt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DPTT02 computes the residual for the solution to a symmetric
// *  tridiagonal system of equations:
// *     RESID = norm(B - A*X) / (norm(A) * norm(X) * EPS),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  N       (input) INTEGTER
// *          The order of the matrix A.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices B and X.  NRHS >= 0.
// *
// *  D       (input) DOUBLE PRECISION array, dimension (N)
// *          The n diagonal elements of the tridiagonal matrix A.
// *
// *  E       (input) DOUBLE PRECISION array, dimension (N-1)
// *          The (n-1) subdiagonal elements of the tridiagonal matrix A.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The n by nrhs matrix of solution vectors X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the n by nrhs matrix of right hand side vectors B.
// *          On exit, B is overwritten with the difference B - A*X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(B - A*X) / (norm(A) * norm(X) * EPS)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dptt02 (int n,
int nrhs,
double [] d, int _d_offset,
double [] e, int _e_offset,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dptt02",999999);
}              // Close if()
// *
// *     Compute the 1-norm of the tridiagonal matrix A.
// *
anorm = Dlanst.dlanst("1",n,d,_d_offset,e,_e_offset);
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dptt02",999999);
}              // Close if()
// *
// *     Compute B - A*X.
// *
Dlaptm.dlaptm(n,nrhs,-one,d,_d_offset,e,_e_offset,x,_x_offset,ldx,one,b,_b_offset,ldb);
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm(B - A*X) / ( norm(A) * norm(X) * EPS ).
// *
resid.val = zero;
{
forloop10:
for (j = 1; j <= nrhs; j++) {
bnorm = Dasum.dasum(n,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
xnorm = Dasum.dasum(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (xnorm <= zero)  {
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/eps) ;
}              //  Close else.
Dummy.label("Dptt02",10);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dptt02",999999);
// *
// *     End of DPTT02
// *
Dummy.label("Dptt02",999999);
return;
   }
} // End class.
