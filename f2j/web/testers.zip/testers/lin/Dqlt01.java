/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqlt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQLT01 tests DGEQLF, which computes the QL factorization of an m-by-n
// *  matrix A, and partially tests DORGQL which forms the m-by-m
// *  orthogonal matrix Q.
// *
// *  DQLT01 compares L with Q'*A, and checks that Q is orthogonal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A.
// *
// *  AF      (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the QL factorization of A, as returned by DGEQLF.
// *          See DGEQLF for further details.
// *
// *  Q       (output) DOUBLE PRECISION array, dimension (LDA,M)
// *          The m-by-m orthogonal matrix Q.
// *
// *  L       (workspace) DOUBLE PRECISION array, dimension (LDA,max(M,N))
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and R.
// *          LDA >= max(M,N).
// *
// *  TAU     (output) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors, as returned
// *          by DGEQLF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *          RESULT(1) = norm( L - Q'*A ) / ( M * norm(A) * EPS )
// *          RESULT(2) = norm( I - Q'*Q ) / ( M * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static int minmn= 0;
static double anorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dqlt01 (int m,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] l, int _l_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

minmn = (int)(Math.min(m, n) );
eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the matrix A to the array AF.
// *
Dlacpy.dlacpy("Full",m,n,a,_a_offset,lda,af,_af_offset,lda);
// *
// *     Factorize the matrix A in the array AF.
// *
lintest_srnamc.srnamt = "DGEQLF";
Dgeqlf.dgeqlf(m,n,af,_af_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy details of Q
// *
Dlaset.dlaset("Full",m,m,rogue,rogue,q,_q_offset,lda);
if (m >= n)  {
    if (n < m && n > 0)  
    Dlacpy.dlacpy("Full",m-n,n,af,_af_offset,lda,q,(1)- 1+(m-n+1- 1)*lda+ _q_offset,lda);
if (n > 1)  
    Dlacpy.dlacpy("Upper",n-1,n-1,af,(m-n+1)- 1+(2- 1)*lda+ _af_offset,lda,q,(m-n+1)- 1+(m-n+2- 1)*lda+ _q_offset,lda);
}              // Close if()
else  {
  if (m > 1)  
    Dlacpy.dlacpy("Upper",m-1,m-1,af,(1)- 1+(n-m+2- 1)*lda+ _af_offset,lda,q,(1)- 1+(2- 1)*lda+ _q_offset,lda);
}              //  Close else.
// *
// *     Generate the m-by-m matrix Q
// *
lintest_srnamc.srnamt = "DORGQL";
Dorgql.dorgql(m,m,minmn,q,_q_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy L
// *
Dlaset.dlaset("Full",m,n,zero,zero,l,_l_offset,lda);
if (m >= n)  {
    if (n > 0)  
    Dlacpy.dlacpy("Lower",n,n,af,(m-n+1)- 1+(1- 1)*lda+ _af_offset,lda,l,(m-n+1)- 1+(1- 1)*lda+ _l_offset,lda);
}              // Close if()
else  {
  if (n > m && m > 0)  
    Dlacpy.dlacpy("Full",m,n-m,af,_af_offset,lda,l,_l_offset,lda);
if (m > 0)  
    Dlacpy.dlacpy("Lower",m,m,af,(1)- 1+(n-m+1- 1)*lda+ _af_offset,lda,l,(1)- 1+(n-m+1- 1)*lda+ _l_offset,lda);
}              //  Close else.
// *
// *     Compute L - Q'*A
// *
Dgemm.dgemm("Transpose","No transpose",m,n,m,-one,q,_q_offset,lda,a,_a_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( L - Q'*A ) / ( M * norm(A) * EPS ) .
// *
anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset);
resid = Dlange.dlange("1",m,n,l,_l_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max(1, m) ))/anorm)/eps;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q'*Q
// *
Dlaset.dlaset("Full",m,m,zero,one,l,_l_offset,lda);
Dsyrk.dsyrk("Upper","Transpose",m,m,-one,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( I - Q'*Q ) / ( M * EPS ) .
// *
resid = Dlansy.dlansy("1","Upper",m,l,_l_offset,lda,rwork,_rwork_offset);
// *
result[(2)- 1+ _result_offset] = (resid/(double)(Math.max(1, m) ))/eps;
// *
Dummy.go_to("Dqlt01",999999);
// *
// *     End of DQLT01
// *
Dummy.label("Dqlt01",999999);
return;
   }
} // End class.
