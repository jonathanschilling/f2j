/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqlt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQLT02 tests DORGQL, which generates an m-by-n matrix Q with
// *  orthonornmal columns that is defined as the product of k elementary
// *  reflectors.
// *
// *  Given the QL factorization of an m-by-n matrix A, DQLT02 generates
// *  the orthogonal matrix Q defined by the factorization of the last k
// *  columns of A; it compares L(m-n+1:m,n-k+1:n) with
// *  Q(1:m,m-n+1:m)'*A(1:m,n-k+1:n), and checks that the columns of Q are
// *  orthonormal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q to be generated.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q to be generated.
// *          M >= N >= 0.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. N >= K >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A which was factorized by DQLT01.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the QL factorization of A, as returned by DGEQLF.
// *          See DGEQLF for further details.
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  L       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and L. LDA >= M.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N)
// *          The scalar factors of the elementary reflectors corresponding
// *          to the QL factorization in AF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *          RESULT(1) = norm( L - Q'*A ) / ( M * norm(A) * EPS )
// *          RESULT(2) = norm( I - Q'*Q ) / ( M * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick return if possible
// *

public static void dqlt02 (int m,
int n,
int k,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] l, int _l_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

if (m == 0 || n == 0 || k == 0)  {
    result[(1)- 1+ _result_offset] = zero;
result[(2)- 1+ _result_offset] = zero;
Dummy.go_to("Dqlt02",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the last k columns of the factorization to the array Q
// *
Dlaset.dlaset("Full",m,n,rogue,rogue,q,_q_offset,lda);
if (k < m)  
    Dlacpy.dlacpy("Full",m-k,k,af,(1)- 1+(n-k+1- 1)*lda+ _af_offset,lda,q,(1)- 1+(n-k+1- 1)*lda+ _q_offset,lda);
if (k > 1)  
    Dlacpy.dlacpy("Upper",k-1,k-1,af,(m-k+1)- 1+(n-k+2- 1)*lda+ _af_offset,lda,q,(m-k+1)- 1+(n-k+2- 1)*lda+ _q_offset,lda);
// *
// *     Generate the last n columns of the matrix Q
// *
lintest_srnamc.srnamt = "DORGQL";
Dorgql.dorgql(m,n,k,q,_q_offset,lda,tau,(n-k+1)- 1+ _tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy L(m-n+1:m,n-k+1:n)
// *
Dlaset.dlaset("Full",n,k,zero,zero,l,(m-n+1)- 1+(n-k+1- 1)*lda+ _l_offset,lda);
Dlacpy.dlacpy("Lower",k,k,af,(m-k+1)- 1+(n-k+1- 1)*lda+ _af_offset,lda,l,(m-k+1)- 1+(n-k+1- 1)*lda+ _l_offset,lda);
// *
// *     Compute L(m-n+1:m,n-k+1:n) - Q(1:m,m-n+1:m)' * A(1:m,n-k+1:n)
// *
Dgemm.dgemm("Transpose","No transpose",n,k,m,-one,q,_q_offset,lda,a,(1)- 1+(n-k+1- 1)*lda+ _a_offset,lda,one,l,(m-n+1)- 1+(n-k+1- 1)*lda+ _l_offset,lda);
// *
// *     Compute norm( L - Q'*A ) / ( M * norm(A) * EPS ) .
// *
anorm = Dlange.dlange("1",m,k,a,(1)- 1+(n-k+1- 1)*lda+ _a_offset,lda,rwork,_rwork_offset);
resid = Dlange.dlange("1",n,k,l,(m-n+1)- 1+(n-k+1- 1)*lda+ _l_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max(1, m) ))/anorm)/eps;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q'*Q
// *
Dlaset.dlaset("Full",n,n,zero,one,l,_l_offset,lda);
Dsyrk.dsyrk("Upper","Transpose",n,m,-one,q,_q_offset,lda,one,l,_l_offset,lda);
// *
// *     Compute norm( I - Q'*Q ) / ( M * EPS ) .
// *
resid = Dlansy.dlansy("1","Upper",n,l,_l_offset,lda,rwork,_rwork_offset);
// *
result[(2)- 1+ _result_offset] = (resid/(double)(Math.max(1, m) ))/eps;
// *
Dummy.go_to("Dqlt02",999999);
// *
// *     End of DQLT02
// *
Dummy.label("Dqlt02",999999);
return;
   }
} // End class.
