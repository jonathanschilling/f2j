/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqpt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQPT01 tests the QR-factorization with pivoting of a matrix A.  The
// *  array AF contains the (possibly partial) QR-factorization of A, where
// *  the upper triangle of AF(1:k,1:k) is a partial triangular factor,
// *  the entries below the diagonal in the first k columns are the
// *  Householder vectors, and the rest of AF contains a partially updated
// *  matrix.
// *
// *  This function returns ||A*P - Q*R||/(||norm(A)||*eps*M)
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrices A and AF.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and AF.
// *
// *  K       (input) INTEGER
// *          The number of columns of AF that have been reduced
// *          to upper triangular form.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA, N)
// *          The original matrix A.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The (possibly partial) output of DGEQPF.  The upper triangle
// *          of AF(1:k,1:k) is a partial triangular factor, the entries
// *          below the diagonal in the first k columns are the Householder
// *          vectors, and the rest of AF contains a partially updated
// *          matrix.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A and AF.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (K)
// *          Details of the Householder transformations as returned by
// *          DGEQPF.
// *
// *  JPVT    (input) INTEGER array, dimension (N)
// *          Pivot information as returned by DGEQPF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK >= M*N+N.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static double norma= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] rwork= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dqpt01 = 0.0;


public static double dqpt01 (int m,
int n,
int k,
double [] a, int _a_offset,
double [] af, int _af_offset,
int lda,
double [] tau, int _tau_offset,
int [] jpvt, int _jpvt_offset,
double [] work, int _work_offset,
int lwork)  {

dqpt01 = zero;
// *
// *     Test if there is enough workspace
// *
if (lwork < m*n+n)  {
    Xerbla.xerbla("DQPT01",10);
Dummy.go_to("Dqpt01",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m <= 0 || n <= 0)  
    Dummy.go_to("Dqpt01",999999);
// *
norma = Dlange.dlange("One-norm",m,n,a,_a_offset,lda,rwork,0);
// *
{
forloop30:
for (j = 1; j <= k; j++) {
{
forloop10:
for (i = 1; i <= Math.min(j, m) ; i++) {
work[((j-1)*m+i)- 1+ _work_offset] = af[(i)- 1+(j- 1)*lda+ _af_offset];
Dummy.label("Dqpt01",10);
}              //  Close for() loop. 
}
{
forloop20:
for (i = j+1; i <= m; i++) {
work[((j-1)*m+i)- 1+ _work_offset] = zero;
Dummy.label("Dqpt01",20);
}              //  Close for() loop. 
}
Dummy.label("Dqpt01",30);
}              //  Close for() loop. 
}
{
forloop40:
for (j = k+1; j <= n; j++) {
Dcopy.dcopy(m,af,(1)- 1+(j- 1)*lda+ _af_offset,1,work,((j-1)*m+1)- 1+ _work_offset,1);
Dummy.label("Dqpt01",40);
}              //  Close for() loop. 
}
// *
Dormqr.dormqr("Left","No transpose",m,n,k,af,_af_offset,lda,tau,_tau_offset,work,_work_offset,m,work,(m*n+1)- 1+ _work_offset,lwork-m*n,info);
// *
{
forloop50:
for (j = 1; j <= n; j++) {
// *
// *        Compare i-th column of QR and jpvt(i)-th column of A
// *
Daxpy.daxpy(m,-one,a,(1)- 1+(jpvt[(j)- 1+ _jpvt_offset]- 1)*lda+ _a_offset,1,work,((j-1)*m+1)- 1+ _work_offset,1);
Dummy.label("Dqpt01",50);
}              //  Close for() loop. 
}
// *
dqpt01 = Dlange.dlange("One-norm",m,n,work,_work_offset,m,rwork,0)/((double)(Math.max(m, n) )*Dlamch.dlamch("Epsilon"));
if (norma != zero)  
    dqpt01 = dqpt01/norma;
// *
Dummy.go_to("Dqpt01",999999);
// *
// *     End of DQPT01
// *
Dummy.label("Dqpt01",999999);
return dqpt01;
   }
} // End class.
