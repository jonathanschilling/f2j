/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT02 tests DORGQR, which generates an m-by-n matrix Q with
// *  orthonornmal columns that is defined as the product of k elementary
// *  reflectors.
// *
// *  Given the QR factorization of an m-by-n matrix A, DQRT02 generates
// *  the orthogonal matrix Q defined by the factorization of the first k
// *  columns of A; it compares R(1:n,1:k) with Q(1:m,1:n)'*A(1:m,1:k),
// *  and checks that the columns of Q are orthonormal.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix Q to be generated.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix Q to be generated.
// *          M >= N >= 0.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          matrix Q. N >= K >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A which was factorized by DQRT01.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the QR factorization of A, as returned by DGEQRF.
// *          See DGEQRF for further details.
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  R       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A, AF, Q and R. LDA >= M.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (N)
// *          The scalar factors of the elementary reflectors corresponding
// *          to the QR factorization in AF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The dimension of the array WORK.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (2)
// *          The test ratios:
// *          RESULT(1) = norm( R - Q'*A ) / ( M * norm(A) * EPS )
// *          RESULT(2) = norm( I - Q'*Q ) / ( M * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static double anorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dqrt02 (int m,
int n,
int k,
double [] a, int _a_offset,
double [] af, int _af_offset,
double [] q, int _q_offset,
double [] r, int _r_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the first k columns of the factorization to the array Q
// *
Dlaset.dlaset("Full",m,n,rogue,rogue,q,_q_offset,lda);
Dlacpy.dlacpy("Lower",m-1,k,af,(2)- 1+(1- 1)*lda+ _af_offset,lda,q,(2)- 1+(1- 1)*lda+ _q_offset,lda);
// *
// *     Generate the first n columns of the matrix Q
// *
lintest_srnamc.srnamt = "DORGQR";
Dorgqr.dorgqr(m,n,k,q,_q_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
// *     Copy R(1:n,1:k)
// *
Dlaset.dlaset("Full",n,k,zero,zero,r,_r_offset,lda);
Dlacpy.dlacpy("Upper",n,k,af,_af_offset,lda,r,_r_offset,lda);
// *
// *     Compute R(1:n,1:k) - Q(1:m,1:n)' * A(1:m,1:k)
// *
Dgemm.dgemm("Transpose","No transpose",n,k,m,-one,q,_q_offset,lda,a,_a_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( R - Q'*A ) / ( M * norm(A) * EPS ) .
// *
anorm = Dlange.dlange("1",m,k,a,_a_offset,lda,rwork,_rwork_offset);
resid = Dlange.dlange("1",n,k,r,_r_offset,lda,rwork,_rwork_offset);
if (anorm > zero)  {
    result[(1)- 1+ _result_offset] = ((resid/(double)(Math.max(1, m) ))/anorm)/eps;
}              // Close if()
else  {
  result[(1)- 1+ _result_offset] = zero;
}              //  Close else.
// *
// *     Compute I - Q'*Q
// *
Dlaset.dlaset("Full",n,n,zero,one,r,_r_offset,lda);
Dsyrk.dsyrk("Upper","Transpose",n,m,-one,q,_q_offset,lda,one,r,_r_offset,lda);
// *
// *     Compute norm( I - Q'*Q ) / ( M * EPS ) .
// *
resid = Dlansy.dlansy("1","Upper",n,r,_r_offset,lda,rwork,_rwork_offset);
// *
result[(2)- 1+ _result_offset] = (resid/(double)(Math.max(1, m) ))/eps;
// *
Dummy.go_to("Dqrt02",999999);
// *
// *     End of DQRT02
// *
Dummy.label("Dqrt02",999999);
return;
   }
} // End class.
