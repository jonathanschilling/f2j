/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT03 tests DORMQR, which computes Q*C, Q'*C, C*Q or C*Q'.
// *
// *  DQRT03 compares the results of a call to DORMQR with the results of
// *  forming Q explicitly by a call to DORGQR and then performing matrix
// *  multiplication by a call to DGEMM.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The order of the orthogonal matrix Q.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of rows or columns of the matrix C; C is m-by-n if
// *          Q is applied from the left, or n-by-m if Q is applied from
// *          the right.  N >= 0.
// *
// *  K       (input) INTEGER
// *          The number of elementary reflectors whose product defines the
// *          orthogonal matrix Q.  M >= K >= 0.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          Details of the QR factorization of an m-by-n matrix, as
// *          returnedby DGEQRF. See SGEQRF for further details.
// *
// *  C       (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  CC      (workspace) DOUBLE PRECISION array, dimension (LDA,N)
// *
// *  Q       (workspace) DOUBLE PRECISION array, dimension (LDA,M)
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays AF, C, CC, and Q.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (min(M,N))
// *          The scalar factors of the elementary reflectors corresponding
// *          to the QR factorization in AF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of WORK.  LWORK must be at least M, and should be
// *          M*NB, where NB is the blocksize for this environment.
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESULT  (output) DOUBLE PRECISION array, dimension (4)
// *          The test ratios compare two techniques for multiplying a
// *          random matrix C by an m-by-m orthogonal matrix Q.
// *          RESULT(1) = norm( Q*C - Q*C )  / ( M * norm(C) * EPS )
// *          RESULT(2) = norm( C*Q - C*Q )  / ( M * norm(C) * EPS )
// *          RESULT(3) = norm( Q'*C - Q'*C )/ ( M * norm(C) * EPS )
// *          RESULT(4) = norm( C*Q' - C*Q' )/ ( M * norm(C) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
static double rogue= -1.0e+10;
// *     ..
// *     .. Local Scalars ..
static String side= new String(" ");
static String trans= new String(" ");
static intW info= new intW(0);
static int iside= 0;
static int itrans= 0;
static int j= 0;
static int mc= 0;
static int nc= 0;
static double cnorm= 0.0;
static double eps= 0.0;
static double resid= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Local Arrays ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Scalars in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Data statements ..
static int [] iseed = {1988 
, 1989 , 1990 , 1991 };
// *     ..
// *     .. Executable Statements ..
// *

public static void dqrt03 (int m,
int n,
int k,
double [] af, int _af_offset,
double [] c, int _c_offset,
double [] cc, int _cc_offset,
double [] q, int _q_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork,
double [] rwork, int _rwork_offset,
double [] result, int _result_offset)  {

eps = Dlamch.dlamch("Epsilon");
// *
// *     Copy the first k columns of the factorization to the array Q
// *
Dlaset.dlaset("Full",m,m,rogue,rogue,q,_q_offset,lda);
Dlacpy.dlacpy("Lower",m-1,k,af,(2)- 1+(1- 1)*lda+ _af_offset,lda,q,(2)- 1+(1- 1)*lda+ _q_offset,lda);
// *
// *     Generate the m-by-m matrix Q
// *
lintest_srnamc.srnamt = "DORGQR";
Dorgqr.dorgqr(m,m,k,q,_q_offset,lda,tau,_tau_offset,work,_work_offset,lwork,info);
// *
{
forloop30:
for (iside = 1; iside <= 2; iside++) {
if (iside == 1)  {
    side = "L";
mc = m;
nc = n;
}              // Close if()
else  {
  side = "R";
mc = n;
nc = m;
}              //  Close else.
// *
// *        Generate MC by NC matrix C
// *
{
forloop10:
for (j = 1; j <= nc; j++) {
Dlarnv.dlarnv(2,iseed,0,mc,c,(1)- 1+(j- 1)*lda+ _c_offset);
Dummy.label("Dqrt03",10);
}              //  Close for() loop. 
}
cnorm = Dlange.dlange("1",mc,nc,c,_c_offset,lda,rwork,_rwork_offset);
if (cnorm == 0.0e0)  
    cnorm = one;
// *
{
forloop20:
for (itrans = 1; itrans <= 2; itrans++) {
if (itrans == 1)  {
    trans = "N";
}              // Close if()
else  {
  trans = "T";
}              //  Close else.
// *
// *           Copy C
// *
Dlacpy.dlacpy("Full",mc,nc,c,_c_offset,lda,cc,_cc_offset,lda);
// *
// *           Apply Q or Q' to C
// *
lintest_srnamc.srnamt = "DORMQR";
Dormqr.dormqr(side,trans,mc,nc,k,af,_af_offset,lda,tau,_tau_offset,cc,_cc_offset,lda,work,_work_offset,lwork,info);
// *
// *           Form explicit product and subtract
// *
if ((side.toLowerCase().charAt(0) == "L".toLowerCase().charAt(0)))  {
    Dgemm.dgemm(trans,"No transpose",mc,nc,mc,-one,q,_q_offset,lda,c,_c_offset,lda,one,cc,_cc_offset,lda);
}              // Close if()
else  {
  Dgemm.dgemm("No transpose",trans,mc,nc,nc,-one,c,_c_offset,lda,q,_q_offset,lda,one,cc,_cc_offset,lda);
}              //  Close else.
// *
// *           Compute error in the difference
// *
resid = Dlange.dlange("1",mc,nc,cc,_cc_offset,lda,rwork,_rwork_offset);
result[((iside-1)*2+itrans)- 1+ _result_offset] = resid/((double)(Math.max(1, m) )*cnorm*eps);
// *
Dummy.label("Dqrt03",20);
}              //  Close for() loop. 
}
Dummy.label("Dqrt03",30);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dqrt03",999999);
// *
// *     End of DQRT03
// *
Dummy.label("Dqrt03",999999);
return;
   }
} // End class.
