/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt12 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT12 computes the singular values `svlues' of the upper trapezoid
// *  of A(1:M,1:N) and returns the ratio
// *
// *       || s - svlues||/(||svlues||*eps*max(M,N))
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A. Only the upper trapezoid is referenced.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *
// *  S       (input) DOUBLE PRECISION array, dimension (min(M,N))
// *          The singular values of the matrix A.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK. LWORK >= M*N + 4*min(M,N) +
// *          max(M,N).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int iscl= 0;
static int j= 0;
static int mn= 0;
static double anrm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double nrmsvl= 0.0;
static doubleW smlnum= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Local Arrays ..
static double [] dummy= new double[(1)];
// *     ..
// *     .. Executable Statements ..
// *
static double dqrt12 = 0.0;


public static double dqrt12 (int m,
int n,
double [] a, int _a_offset,
int lda,
double [] s, int _s_offset,
double [] work, int _work_offset,
int lwork)  {

dqrt12 = zero;
// *
// *     Test that enough workspace is supplied
// *
if (lwork < m*n+4*Math.min(m, n) +Math.max(m, n) )  {
    Xerbla.xerbla("DQRT12",7);
Dummy.go_to("Dqrt12",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
mn = (int)(Math.min(m, n) );
if (mn <= zero)  
    Dummy.go_to("Dqrt12",999999);
// *
nrmsvl = Dnrm2.dnrm2(mn,s,_s_offset,1);
// *
// *     Copy upper triangle of A into work
// *
Dlaset.dlaset("Full",m,n,zero,zero,work,_work_offset,m);
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= Math.min(j, m) ; i++) {
work[((j-1)*m+i)- 1+ _work_offset] = a[(i)- 1+(j- 1)*lda+ _a_offset];
Dummy.label("Dqrt12",10);
}              //  Close for() loop. 
}
Dummy.label("Dqrt12",20);
}              //  Close for() loop. 
}
// *
// *     Get machine parameters
// *
smlnum.val = Dlamch.dlamch("S")/Dlamch.dlamch("P");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Scale work if max entry outside range [SMLNUM,BIGNUM]
// *
anrm = Dlange.dlange("M",m,n,work,_work_offset,m,dummy,0);
iscl = 0;
if (anrm > zero && anrm < smlnum.val)  {
    // *
// *        Scale matrix norm up to SMLNUM
// *
Dlascl.dlascl("G",0,0,anrm,smlnum.val,m,n,work,_work_offset,m,info);
iscl = 1;
}              // Close if()
else if (anrm > bignum.val)  {
    // *
// *        Scale matrix norm down to BIGNUM
// *
Dlascl.dlascl("G",0,0,anrm,bignum.val,m,n,work,_work_offset,m,info);
iscl = 1;
}              // Close else if()
// *
if (anrm != zero)  {
    // *
// *        Compute SVD of work
// *
Dgebd2.dgebd2(m,n,work,_work_offset,m,work,(m*n+1)- 1+ _work_offset,work,(m*n+mn+1)- 1+ _work_offset,work,(m*n+2*mn+1)- 1+ _work_offset,work,(m*n+3*mn+1)- 1+ _work_offset,work,(m*n+4*mn+1)- 1+ _work_offset,info);
Dbdsqr.dbdsqr("Upper",mn,0,0,0,work,(m*n+1)- 1+ _work_offset,work,(m*n+mn+1)- 1+ _work_offset,dummy,0,mn,dummy,0,1,dummy,0,mn,work,(m*n+2*mn+1)- 1+ _work_offset,info);
// *
if (iscl == 1)  {
    if (anrm > bignum.val)  {
    Dlascl.dlascl("G",0,0,bignum.val,anrm,mn,1,work,(m*n+1)- 1+ _work_offset,mn,info);
}              // Close if()
if (anrm < smlnum.val)  {
    Dlascl.dlascl("G",0,0,smlnum.val,anrm,mn,1,work,(m*n+1)- 1+ _work_offset,mn,info);
}              // Close if()
}              // Close if()
// *
}              // Close if()
else  {
  // *
{
forloop30:
for (i = 1; i <= mn; i++) {
work[(m*n+i)- 1+ _work_offset] = zero;
Dummy.label("Dqrt12",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compare s and singular values of work
// *
Daxpy.daxpy(mn,-one,s,_s_offset,1,work,(m*n+1)- 1+ _work_offset,1);
dqrt12 = Dasum.dasum(mn,work,(m*n+1)- 1+ _work_offset,1)/(Dlamch.dlamch("Epsilon")*(double)(Math.max(m, n) ));
if (nrmsvl != zero)  
    dqrt12 = dqrt12/nrmsvl;
// *
Dummy.go_to("Dqrt12",999999);
// *
// *     End of DQRT12
// *
Dummy.label("Dqrt12",999999);
return dqrt12;
   }
} // End class.
