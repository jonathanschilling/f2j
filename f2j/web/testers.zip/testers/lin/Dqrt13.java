/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt13 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT13 generates a full-rank matrix that may be scaled to have large
// *  or small norm.
// *
// *  Arguments
// *  =========
// *
// *  SCALE   (input) INTEGER
// *          SCALE = 1: normally scaled matrix
// *          SCALE = 2: matrix scaled up
// *          SCALE = 3: matrix scaled down
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.
// *
// *  N       (input) INTEGER
// *          The number of columns of A.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *
// *  NORMA   (output) DOUBLE PRECISION
// *          The one-norm of A.
// *
// *  ISEED   (input/output) integer array, dimension (4)
// *          Seed for random number generator
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static int j= 0;
static doubleW bignum= new doubleW(0.0);
static doubleW smlnum= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Local Arrays ..
static double [] dummy= new double[(1)];
// *     ..
// *     .. Executable Statements ..
// *

public static void dqrt13 (int scale,
int m,
int n,
double [] a, int _a_offset,
int lda,
doubleW norma,
int [] iseed, int _iseed_offset)  {

if (m <= 0 || n <= 0)  
    Dummy.go_to("Dqrt13",999999);
// *
// *     benign matrix
// *
{
forloop10:
for (j = 1; j <= n; j++) {
Dlarnv.dlarnv(2,iseed,_iseed_offset,m,a,(1)- 1+(j- 1)*lda+ _a_offset);
if (j <= m)  {
    a[(j)- 1+(j- 1)*lda+ _a_offset] = a[(j)- 1+(j- 1)*lda+ _a_offset]+((a[(j)- 1+(j- 1)*lda+ _a_offset]) >= 0 ? Math.abs(Dasum.dasum(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1)) : -Math.abs(Dasum.dasum(m,a,(1)- 1+(j- 1)*lda+ _a_offset,1)));
}              // Close if()
Dummy.label("Dqrt13",10);
}              //  Close for() loop. 
}
// *
// *     scaled versions
// *
if (scale != 1)  {
    norma.val = Dlange.dlange("Max",m,n,a,_a_offset,lda,dummy,0);
smlnum.val = Dlamch.dlamch("Safe minimum");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
smlnum.val = smlnum.val/Dlamch.dlamch("Epsilon");
bignum.val = one/smlnum.val;
// *
if (scale == 2)  {
    // *
// *           matrix scaled up
// *
Dlascl.dlascl("General",0,0,norma.val,bignum.val,m,n,a,_a_offset,lda,info);
}              // Close if()
else if (scale == 3)  {
    // *
// *           matrix scaled down
// *
Dlascl.dlascl("General",0,0,norma.val,smlnum.val,m,n,a,_a_offset,lda,info);
}              // Close else if()
}              // Close if()
// *
norma.val = Dlange.dlange("One-norm",m,n,a,_a_offset,lda,dummy,0);
Dummy.go_to("Dqrt13",999999);
// *
// *     End of DQRT13
// *
Dummy.label("Dqrt13",999999);
return;
   }
} // End class.
