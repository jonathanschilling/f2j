/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dqrt14 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT14 checks whether X is in the row space of A or A'.  It does so
// *  by scaling both X and A such that their norms are in the range
// *  [sqrt(eps), 1/sqrt(eps)], then computing a QR factorization of [A,X]
// *  (if TRANS = 'T') or an LQ factorization of [A',X]' (if TRANS = 'N'),
// *  and returning the norm of the trailing triangle, scaled by
// *  MAX(M,N,NRHS)*eps.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          = 'N':  No transpose, check for X in the row space of A
// *          = 'T':  Transpose, check for X in the row space of A'.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of X.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          If TRANS = 'N', the N-by-NRHS matrix X.
// *          IF TRANS = 'T', the M-by-NRHS matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.
// *
// *  WORK    (workspace) DOUBLE PRECISION array dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          length of workspace array required
// *          If TRANS = 'N', LWORK >= (M+NRHS)*(N+2);
// *          if TRANS = 'T', LWORK >= (N+NRHS)*(M+2).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static boolean tpsd= false;
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static int ldwork= 0;
static double anrm= 0.0;
static double err= 0.0;
static double xnrm= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] rwork= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dqrt14 = 0.0;


public static double dqrt14 (String trans,
int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] work, int _work_offset,
int lwork)  {

dqrt14 = zero;
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    ldwork = m+nrhs;
tpsd = false;
if (lwork < (m+nrhs)*(n+2))  {
    Xerbla.xerbla("DQRT14",10);
Dummy.go_to("Dqrt14",999999);
}              // Close if()
else if (n <= 0 || nrhs <= 0)  {
    Dummy.go_to("Dqrt14",999999);
}              // Close else if()
}              // Close if()
else if ((trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    ldwork = m;
tpsd = true;
if (lwork < (n+nrhs)*(m+2))  {
    Xerbla.xerbla("DQRT14",10);
Dummy.go_to("Dqrt14",999999);
}              // Close if()
else if (m <= 0 || nrhs <= 0)  {
    Dummy.go_to("Dqrt14",999999);
}              // Close else if()
}              // Close else if()
else  {
  Xerbla.xerbla("DQRT14",1);
Dummy.go_to("Dqrt14",999999);
}              //  Close else.
// *
// *     Copy and scale A
// *
Dlacpy.dlacpy("All",m,n,a,_a_offset,lda,work,_work_offset,ldwork);
anrm = Dlange.dlange("M",m,n,work,_work_offset,ldwork,rwork,0);
if (anrm != zero)  
    Dlascl.dlascl("G",0,0,anrm,one,m,n,work,_work_offset,ldwork,info);
// *
// *     Copy X or X' into the right place and scale it
// *
if (tpsd)  {
    // *
// *        Copy X into columns n+1:n+nrhs of work
// *
Dlacpy.dlacpy("All",m,nrhs,x,_x_offset,ldx,work,(n*ldwork+1)- 1+ _work_offset,ldwork);
xnrm = Dlange.dlange("M",m,nrhs,work,(n*ldwork+1)- 1+ _work_offset,ldwork,rwork,0);
if (xnrm != zero)  
    Dlascl.dlascl("G",0,0,xnrm,one,m,nrhs,work,(n*ldwork+1)- 1+ _work_offset,ldwork,info);
anrm = Dlange.dlange("One-norm",m,n+nrhs,work,_work_offset,ldwork,rwork,0);
// *
// *        Compute QR factorization of X
// *
Dgeqr2.dgeqr2(m,n+nrhs,work,_work_offset,ldwork,work,(ldwork*(n+nrhs)+1)- 1+ _work_offset,work,(int)((ldwork*(n+nrhs)+Math.min(m, n+nrhs) +1)- 1+ _work_offset),info);
// *
// *        Compute largest entry in upper triangle of
// *        work(n+1:m,n+1:n+nrhs)
// *
err = zero;
{
forloop20:
for (j = n+1; j <= n+nrhs; j++) {
{
forloop10:
for (i = n+1; i <= Math.min(m, j) ; i++) {
err = Math.max(err, Math.abs(work[(i+(j-1)*m)- 1+ _work_offset])) ;
Dummy.label("Dqrt14",10);
}              //  Close for() loop. 
}
Dummy.label("Dqrt14",20);
}              //  Close for() loop. 
}
// *
}              // Close if()
else  {
  // *
// *        Copy X' into rows m+1:m+nrhs of work
// *
{
forloop40:
for (i = 1; i <= n; i++) {
{
forloop30:
for (j = 1; j <= nrhs; j++) {
work[(m+j+(i-1)*ldwork)- 1+ _work_offset] = x[(i)- 1+(j- 1)*ldx+ _x_offset];
Dummy.label("Dqrt14",30);
}              //  Close for() loop. 
}
Dummy.label("Dqrt14",40);
}              //  Close for() loop. 
}
// *
xnrm = Dlange.dlange("M",nrhs,n,work,(m+1)- 1+ _work_offset,ldwork,rwork,0);
if (xnrm != zero)  
    Dlascl.dlascl("G",0,0,xnrm,one,nrhs,n,work,(m+1)- 1+ _work_offset,ldwork,info);
// *
// *        Compute LQ factorization of work
// *
Dgelq2.dgelq2(ldwork,n,work,_work_offset,ldwork,work,(ldwork*n+1)- 1+ _work_offset,work,(ldwork*(n+1)+1)- 1+ _work_offset,info);
// *
// *        Compute largest entry in lower triangle in
// *        work(m+1:m+nrhs,m+1:n)
// *
err = zero;
{
forloop60:
for (j = m+1; j <= n; j++) {
{
forloop50:
for (i = j; i <= ldwork; i++) {
err = Math.max(err, Math.abs(work[(i+(j-1)*ldwork)- 1+ _work_offset])) ;
Dummy.label("Dqrt14",50);
}              //  Close for() loop. 
}
Dummy.label("Dqrt14",60);
}              //  Close for() loop. 
}
// *
}              //  Close else.
// *
dqrt14 = err/((double)(Math.max((m) > (n) ? (m) : (n), nrhs))*Dlamch.dlamch("Epsilon"));
// *
Dummy.go_to("Dqrt14",999999);
// *
// *     End of DQRT14
// *
Dummy.label("Dqrt14",999999);
return dqrt14;
   }
} // End class.
