/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt15 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT15 generates a matrix with full or deficient rank and of various
// *  norms.
// *
// *  Arguments
// *  =========
// *
// *  SCALE   (input) INTEGER
// *          SCALE = 1: normally scaled matrix
// *          SCALE = 2: matrix scaled up
// *          SCALE = 3: matrix scaled down
// *
// *  RKSEL   (input) INTEGER
// *          RKSEL = 1: full rank matrix
// *          RKSEL = 2: rank-deficient matrix
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.
// *
// *  N       (input) INTEGER
// *          The number of columns of A.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of B.
// *
// *  A       (output) DOUBLE PRECISION array, dimension (LDA,N)
// *          The M-by-N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.
// *
// *  B       (output) DOUBLE PRECISION array, dimension (LDB, NRHS)
// *          A matrix that is in the range space of matrix A.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.
// *
// *  S       (output) DOUBLE PRECISION array, dimension MIN(M,N)
// *          Singular values of A.
// *
// *  RANK    (output) INTEGER
// *          number of nonzero singular values of A.
// *
// *  NORMA   (output) DOUBLE PRECISION
// *          one-norm of A.
// *
// *  NORMB   (output) DOUBLE PRECISION
// *          one-norm of B.
// *
// *  ISEED   (input/output) integer array, dimension (4)
// *          seed for random number generator.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          length of work space required.
// *          LWORK >= MAX(M+MIN(M,N),NRHS*MIN(M,N),2*N+M)
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
static double two= 2.0e0;
static double svmin= 0.1e0;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static int j= 0;
static int mn= 0;
static double bignum= 0.0;
static double eps= 0.0;
static double smlnum= 0.0;
static double temp= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] dummy= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dqrt15 (int scale,
int rksel,
int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] b, int _b_offset,
int ldb,
double [] s, int _s_offset,
intW rank,
doubleW norma,
doubleW normb,
int [] iseed, int _iseed_offset,
double [] work, int _work_offset,
int lwork)  {

mn = (int)(Math.min(m, n) );
if (lwork < Math.max((m+mn) > (mn*nrhs) ? (m+mn) : (mn*nrhs), 2*n+m))  {
    Xerbla.xerbla("DQRT15",16);
Dummy.go_to("Dqrt15",999999);
}              // Close if()
// *
smlnum = Dlamch.dlamch("Safe minimum");
bignum = one/smlnum;
eps = Dlamch.dlamch("Epsilon");
smlnum = (smlnum/eps)/eps;
bignum = one/smlnum;
// *
// *     Determine rank and (unscaled) singular values
// *
if (rksel == 1)  {
    rank.val = mn;
}              // Close if()
else if (rksel == 2)  {
    rank.val = (3*mn)/4;
{
forloop10:
for (j = rank.val+1; j <= mn; j++) {
s[(j)- 1+ _s_offset] = zero;
Dummy.label("Dqrt15",10);
}              //  Close for() loop. 
}
}              // Close else if()
else  {
  Xerbla.xerbla("DQRT15",2);
}              //  Close else.
// *
if (rank.val > 0)  {
    // *
// *        Nontrivial case
// *
s[(1)- 1+ _s_offset] = one;
{
forloop30:
for (j = 2; j <= rank.val; j++) {
label20:
   Dummy.label("Dqrt15",20);
temp = Dlarnd.dlarnd(1,iseed,_iseed_offset);
if (temp > svmin)  {
    s[(j)- 1+ _s_offset] = Math.abs(temp);
}              // Close if()
else  {
  Dummy.go_to("Dqrt15",20);
}              //  Close else.
Dummy.label("Dqrt15",30);
}              //  Close for() loop. 
}
Dlaord.dlaord("Decreasing",rank.val,s,_s_offset,1);
// *
// *        Generate 'rank' columns of a random orthogonal matrix in A
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,m,work,_work_offset);
Dscal.dscal(m,one/Dnrm2.dnrm2(m,work,_work_offset,1),work,_work_offset,1);
Dlaset.dlaset("Full",m,rank.val,zero,one,a,_a_offset,lda);
Dlarf.dlarf("Left",m,rank.val,work,_work_offset,1,two,a,_a_offset,lda,work,(m+1)- 1+ _work_offset);
// *
// *        workspace used: m+mn
// *
// *        Generate consistent rhs in the range space of A
// *
Dlarnv.dlarnv(2,iseed,_iseed_offset,rank.val*nrhs,work,_work_offset);
Dgemm.dgemm("No transpose","No transpose",m,nrhs,rank.val,one,a,_a_offset,lda,work,_work_offset,rank.val,zero,b,_b_offset,ldb);
// *
// *        work space used: <= mn *nrhs
// *
// *        generate (unscaled) matrix A
// *
{
forloop40:
for (j = 1; j <= rank.val; j++) {
Dscal.dscal(m,s[(j)- 1+ _s_offset],a,(1)- 1+(j- 1)*lda+ _a_offset,1);
Dummy.label("Dqrt15",40);
}              //  Close for() loop. 
}
if (rank.val < n)  
    Dlaset.dlaset("Full",m,n-rank.val,zero,zero,a,(1)- 1+(rank.val+1- 1)*lda+ _a_offset,lda);
Dlaror.dlaror("Right","No initialization",m,n,a,_a_offset,lda,iseed,_iseed_offset,work,_work_offset,info);
// *
}              // Close if()
else  {
  // *
// *        work space used 2*n+m
// *
// *        Generate null matrix and rhs
// *
{
forloop50:
for (j = 1; j <= mn; j++) {
s[(j)- 1+ _s_offset] = zero;
Dummy.label("Dqrt15",50);
}              //  Close for() loop. 
}
Dlaset.dlaset("Full",m,n,zero,zero,a,_a_offset,lda);
Dlaset.dlaset("Full",m,nrhs,zero,zero,b,_b_offset,ldb);
// *
}              //  Close else.
// *
// *     Scale the matrix
// *
if (scale != 1)  {
    norma.val = Dlange.dlange("Max",m,n,a,_a_offset,lda,dummy,0);
if (norma.val != zero)  {
    if (scale == 2)  {
    // *
// *              matrix scaled up
// *
Dlascl.dlascl("General",0,0,norma.val,bignum,m,n,a,_a_offset,lda,info);
Dlascl.dlascl("General",0,0,norma.val,bignum,mn,1,s,_s_offset,mn,info);
Dlascl.dlascl("General",0,0,norma.val,bignum,m,nrhs,b,_b_offset,ldb,info);
}              // Close if()
else if (scale == 3)  {
    // *
// *              matrix scaled down
// *
Dlascl.dlascl("General",0,0,norma.val,smlnum,m,n,a,_a_offset,lda,info);
Dlascl.dlascl("General",0,0,norma.val,smlnum,mn,1,s,_s_offset,mn,info);
Dlascl.dlascl("General",0,0,norma.val,smlnum,m,nrhs,b,_b_offset,ldb,info);
}              // Close else if()
else  {
  Xerbla.xerbla("DQRT15",1);
Dummy.go_to("Dqrt15",999999);
}              //  Close else.
}              // Close if()
}              // Close if()
// *
norma.val = Dasum.dasum(mn,s,_s_offset,1);
normb.val = Dlange.dlange("One-norm",m,nrhs,b,_b_offset,ldb,dummy,0);
// *
Dummy.go_to("Dqrt15",999999);
// *
// *     End of DQRT15
// *
Dummy.label("Dqrt15",999999);
return;
   }
} // End class.
