/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt16 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT16 computes the residual for a solution of a system of linear
// *  equations  A*x = b  or  A'*x = b:
// *     RESID = norm(B - A*X) / ( max(m,n) * norm(A) * norm(X) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations:
// *          = 'N':  A *x = b
// *          = 'T':  A'*x = b, where A' is the transpose of A
// *          = 'C':  A'*x = b, where A' is the transpose of A
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.  M >= 0.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of B, the matrix of right hand sides.
// *          NRHS >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original M x N matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,M).
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  If TRANS = 'N',
// *          LDX >= max(1,N); if TRANS = 'T' or 'C', LDX >= max(1,M).
// *
// *  B       (input/output) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          On entry, the right hand side vectors for the system of
// *          linear equations.
// *          On exit, B is overwritten with the difference B - A*X.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  IF TRANS = 'N',
// *          LDB >= max(1,M); if TRANS = 'T' or 'C', LDB >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (M)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(B - A*X) / ( max(m,n) * norm(A) * norm(X) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static int n1= 0;
static int n2= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if M = 0 or N = 0 or NRHS = 0
// *

public static void dqrt16 (String trans,
int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (m <= 0 || n <= 0 || nrhs == 0)  {
    resid.val = zero;
Dummy.go_to("Dqrt16",999999);
}              // Close if()
// *
if ((trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)) || (trans.toLowerCase().charAt(0) == "C".toLowerCase().charAt(0)))  {
    anorm = Dlange.dlange("I",m,n,a,_a_offset,lda,rwork,_rwork_offset);
n1 = n;
n2 = m;
}              // Close if()
else  {
  anorm = Dlange.dlange("1",m,n,a,_a_offset,lda,rwork,_rwork_offset);
n1 = m;
n2 = n;
}              //  Close else.
// *
eps = Dlamch.dlamch("Epsilon");
// *
// *     Compute  B - A*X  (or  B - A'*X ) and store in B.
// *
Dgemm.dgemm(trans,"No transpose",n1,nrhs,n2,-one,a,_a_offset,lda,x,_x_offset,ldx,one,b,_b_offset,ldb);
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm(B - A*X) / ( max(m,n) * norm(A) * norm(X) * EPS ) .
// *
resid.val = zero;
{
forloop10:
for (j = 1; j <= nrhs; j++) {
bnorm = Dasum.dasum(n1,b,(1)- 1+(j- 1)*ldb+ _b_offset,1);
xnorm = Dasum.dasum(n2,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (anorm == zero && bnorm == zero)  {
    resid.val = zero;
}              // Close if()
else if (anorm <= zero || xnorm <= zero)  {
    resid.val = one/eps;
}              // Close else if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/(Math.max(m, n) *eps)) ;
}              //  Close else.
Dummy.label("Dqrt16",10);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dqrt16",999999);
// *
// *     End of DQRT16
// *
Dummy.label("Dqrt16",999999);
return;
   }
} // End class.
