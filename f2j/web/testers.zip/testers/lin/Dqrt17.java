/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dqrt17 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DQRT17 computes the ratio
// *
// *     || R'*op(A) ||/(||A||*alpha*max(M,N,NRHS)*eps)
// *
// *  where R = op(A)*X - B, op(A) is A or A', and
// *
// *     alpha = ||B|| if IRESID = 1 (zero-residual problem)
// *     alpha = ||R|| if IRESID = 2 (otherwise).
// *
// *  Arguments
// *  =========
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies whether or not the transpose of A is used.
// *          = 'N':  No transpose, op(A) = A.
// *          = 'T':  Transpose, op(A) = A'.
// *
// *  IRESID  (input) INTEGER
// *          IRESID = 1 indicates zero-residual problem.
// *          IRESID = 2 indicates non-zero residual.
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrix A.
// *          If TRANS = 'N', the number of rows of the matrix B.
// *          If TRANS = 'T', the number of rows of the matrix X.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrix  A.
// *          If TRANS = 'N', the number of rows of the matrix X.
// *          If TRANS = 'T', the number of rows of the matrix B.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of the matrices X and B.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The m-by-n matrix A.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A. LDA >= M.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          If TRANS = 'N', the n-by-nrhs matrix X.
// *          If TRANS = 'T', the m-by-nrhs matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.
// *          If TRANS = 'N', LDX >= N.
// *          If TRANS = 'T', LDX >= M.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          If TRANS = 'N', the m-by-nrhs matrix B.
// *          If TRANS = 'T', the n-by-nrhs matrix B.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the arry B.
// *          If TRANS = 'N', LDB >= M.
// *          If TRANS = 'T', LDB >= N.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK >= NRHS*(M+N).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static intW info= new intW(0);
static int iscl= 0;
static int ncols= 0;
static int nrows= 0;
static double bignum= 0.0;
static double err= 0.0;
static double norma= 0.0;
static double normb= 0.0;
static double normrs= 0.0;
static double normx= 0.0;
static double smlnum= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] rwork= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dqrt17 = 0.0;


public static double dqrt17 (String trans,
int iresid,
int m,
int n,
int nrhs,
double [] a, int _a_offset,
int lda,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
int lwork)  {

dqrt17 = zero;
// *
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    nrows = m;
ncols = n;
}              // Close if()
else if ((trans.toLowerCase().charAt(0) == "T".toLowerCase().charAt(0)))  {
    nrows = n;
ncols = m;
}              // Close else if()
else  {
  Xerbla.xerbla("DQRT17",1);
Dummy.go_to("Dqrt17",999999);
}              //  Close else.
// *
if (lwork < nrhs*(m+n))  {
    Xerbla.xerbla("DQRT17",13);
Dummy.go_to("Dqrt17",999999);
}              // Close if()
// *
if (m <= 0 || n <= 0 || nrhs <= 0)  {
    Dummy.go_to("Dqrt17",999999);
}              // Close if()
// *
norma = Dlange.dlange("One-norm",m,n,a,_a_offset,lda,rwork,0);
smlnum = Dlamch.dlamch("Safe minimum")/Dlamch.dlamch("Precision");
bignum = one/smlnum;
iscl = 0;
// *
// *     compute residual and scale it
// *
Dlacpy.dlacpy("All",nrows,nrhs,b,_b_offset,ldb,work,_work_offset,nrows);
Dgemm.dgemm(trans,"No transpose",nrows,nrhs,ncols,-one,a,_a_offset,lda,x,_x_offset,ldx,one,work,_work_offset,nrows);
normrs = Dlange.dlange("Max",nrows,nrhs,work,_work_offset,nrows,rwork,0);
if (normrs > smlnum)  {
    iscl = 1;
Dlascl.dlascl("General",0,0,normrs,one,nrows,nrhs,work,_work_offset,nrows,info);
}              // Close if()
// *
// *     compute R'*A
// *
Dgemm.dgemm("Transpose",trans,nrhs,ncols,nrows,one,work,_work_offset,nrows,a,_a_offset,lda,zero,work,(nrows*nrhs+1)- 1+ _work_offset,nrhs);
// *
// *     compute and properly scale error
// *
err = Dlange.dlange("One-norm",nrhs,ncols,work,(nrows*nrhs+1)- 1+ _work_offset,nrhs,rwork,0);
if (norma != zero)  
    err = err/norma;
// *
if (iscl == 1)  
    err = err*normrs;
// *
if (iresid == 1)  {
    normb = Dlange.dlange("One-norm",nrows,nrhs,b,_b_offset,ldb,rwork,0);
if (normb != zero)  
    err = err/normb;
}              // Close if()
else  {
  normx = Dlange.dlange("One-norm",ncols,nrhs,x,_x_offset,ldx,rwork,0);
if (normx != zero)  
    err = err/normx;
}              //  Close else.
// *
dqrt17 = err/(Dlamch.dlamch("Epsilon")*(double)(Math.max((m) > (n) ? (m) : (n), nrhs)));
Dummy.go_to("Dqrt17",999999);
// *
// *     End of DQRT17
// *
Dummy.label("Dqrt17",999999);
return dqrt17;
   }
} // End class.
