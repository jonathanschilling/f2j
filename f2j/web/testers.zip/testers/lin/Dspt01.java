/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dspt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DSPT01 reconstructs a symmetric indefinite packed matrix A from its
// *  block L*D*L' or U*D*U' factorization and computes the residual
// *       norm( C - A ) / ( N * norm(A) * EPS ),
// *  where C is the reconstructed matrix and EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the upper or lower triangular part of the
// *          symmetric matrix A is stored:
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  N       (input) INTEGER
// *          The number of rows and columns of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The original symmetric matrix A, stored as a packed
// *          triangular matrix.
// *
// *  AFAC    (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The factored form of the matrix A, stored as a packed
// *          triangular matrix.  AFAC contains the block diagonal matrix D
// *          and the multipliers used to obtain the factor L or U from the
// *          block L*D*L' or U*D*U' factorization as computed by DSPTRF.
// *
// *  IPIV    (input) INTEGER array, dimension (N)
// *          The pivot indices from DSPTRF.
// *
// *  C       (workspace) DOUBLE PRECISION array, dimension (LDC,N)
// *
// *  LDC     (integer) INTEGER
// *          The leading dimension of the array C.  LDC >= max(1,N).
// *
// *  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          If UPLO = 'L', norm(L*D*L' - A) / ( N * norm(A) * EPS )
// *          If UPLO = 'U', norm(U*D*U' - A) / ( N * norm(A) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static intW info= new intW(0);
static int j= 0;
static int jc= 0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dspt01 (String uplo,
int n,
double [] a, int _a_offset,
double [] afac, int _afac_offset,
int [] ipiv, int _ipiv_offset,
double [] c, int _c_offset,
int Ldc,
double [] rwork, int _rwork_offset,
doubleW resid)  {

if (n <= 0)  {
    resid.val = zero;
Dummy.go_to("Dspt01",999999);
}              // Close if()
// *
// *     Determine EPS and the norm of A.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlansp.dlansp("1",uplo,n,a,_a_offset,rwork,_rwork_offset);
// *
// *     Initialize C to the identity matrix.
// *
Dlaset.dlaset("Full",n,n,zero,one,c,_c_offset,Ldc);
// *
// *     Call DLAVSP to form the product D * U' (or D * L' ).
// *
Dlavsp.dlavsp(uplo,"Transpose","Non-unit",n,n,afac,_afac_offset,ipiv,_ipiv_offset,c,_c_offset,Ldc,info);
// *
// *     Call DLAVSP again to multiply by U ( or L ).
// *
Dlavsp.dlavsp(uplo,"No transpose","Unit",n,n,afac,_afac_offset,ipiv,_ipiv_offset,c,_c_offset,Ldc,info);
// *
// *     Compute the difference  C - A .
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    jc = 0;
{
forloop20:
for (j = 1; j <= n; j++) {
{
forloop10:
for (i = 1; i <= j; i++) {
c[(i)- 1+(j- 1)*Ldc+ _c_offset] = c[(i)- 1+(j- 1)*Ldc+ _c_offset]-a[(jc+i)- 1+ _a_offset];
Dummy.label("Dspt01",10);
}              //  Close for() loop. 
}
jc = jc+j;
Dummy.label("Dspt01",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop40:
for (j = 1; j <= n; j++) {
{
forloop30:
for (i = j; i <= n; i++) {
c[(i)- 1+(j- 1)*Ldc+ _c_offset] = c[(i)- 1+(j- 1)*Ldc+ _c_offset]-a[(jc+i-j)- 1+ _a_offset];
Dummy.label("Dspt01",30);
}              //  Close for() loop. 
}
jc = jc+n-j+1;
Dummy.label("Dspt01",40);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute norm( C - A ) / ( N * norm(A) * EPS )
// *
resid.val = Dlansy.dlansy("1",uplo,n,c,_c_offset,Ldc,rwork,_rwork_offset);
// *
if (anorm <= zero)  {
    if (resid.val != zero)  
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = ((resid.val/(double)(n))/anorm)/eps;
}              //  Close else.
// *
Dummy.go_to("Dspt01",999999);
// *
// *     End of DSPT01
// *
Dummy.label("Dspt01",999999);
return;
   }
} // End class.
