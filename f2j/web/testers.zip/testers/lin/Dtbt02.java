/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtbt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTBT02 computes the residual for the computed solution to a
// *  triangular system of linear equations  A*x = b  or  A' *x = b when
// *  A is a triangular band matrix.  Here A' is the transpose of A and
// *  x and b are N by NRHS matrices.  The test ratio is the maximum over
// *  the number of right hand sides of
// *     norm(b - op(A)*x) / ( norm(op(A)) * norm(x) * EPS ),
// *  where op(A) denotes A or A' and EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation applied to A.
// *          = 'N':  A *x = b  (No transpose)
// *          = 'T':  A'*x = b  (Transpose)
// *          = 'C':  A'*x = b  (Conjugate transpose = Transpose)
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  KD      (input) INTEGER
// *          The number of superdiagonals or subdiagonals of the
// *          triangular band matrix A.  KD >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices X and B.  NRHS >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The upper or lower triangular band matrix A, stored in the
// *          first kd+1 rows of the array. The j-th column of A is stored
// *          in the j-th column of the array AB as follows:
// *          if UPLO = 'U', AB(kd+1+i-j,j) = A(i,j) for max(1,j-kd)<=i<=j;
// *          if UPLO = 'L', AB(1+i-j,j)    = A(i,j) for j<=i<=min(n,j+kd).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KD+1.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vectors for the system of linear
// *          equations.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(op(A)*x - b) / ( norm(op(A)) * norm(x) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0
// *

public static void dtbt02 (String uplo,
String trans,
String diag,
int n,
int kd,
int nrhs,
double [] ab, int _ab_offset,
int ldab,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dtbt02",999999);
}              // Close if()
// *
// *     Compute the 1-norm of A or A'.
// *
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    anorm = Dlantb.dlantb("1",uplo,diag,n,kd,ab,_ab_offset,ldab,work,_work_offset);
}              // Close if()
else  {
  anorm = Dlantb.dlantb("I",uplo,diag,n,kd,ab,_ab_offset,ldab,work,_work_offset);
}              //  Close else.
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dtbt02",999999);
}              // Close if()
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm(op(A)*x - b) / ( norm(op(A)) * norm(x) * EPS ).
// *
resid.val = zero;
{
forloop10:
for (j = 1; j <= nrhs; j++) {
Dcopy.dcopy(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,work,_work_offset,1);
Dtbmv.dtbmv(uplo,trans,diag,n,kd,ab,_ab_offset,ldab,work,_work_offset,1);
Daxpy.daxpy(n,-one,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,_work_offset,1);
bnorm = Dasum.dasum(n,work,_work_offset,1);
xnorm = Dasum.dasum(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (xnorm <= zero)  {
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/eps) ;
}              //  Close else.
Dummy.label("Dtbt02",10);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dtbt02",999999);
// *
// *     End of DTBT02
// *
Dummy.label("Dtbt02",999999);
return;
   }
} // End class.
