/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Dtbt06 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTBT06 computes a test ratio comparing RCOND (the reciprocal
// *  condition number of a triangular matrix A) and RCONDC, the estimate
// *  computed by DTBCON.  Information about the triangular matrix A is
// *  used if one estimate is zero and the other is non-zero to decide if
// *  underflow in the estimate is justified.
// *
// *  Arguments
// *  =========
// *
// *  RCOND   (input) DOUBLE PRECISION
// *          The estimate of the reciprocal condition number obtained by
// *          forming the explicit inverse of the matrix A and computing
// *          RCOND = 1/( norm(A) * norm(inv(A)) ).
// *
// *  RCONDC  (input) DOUBLE PRECISION
// *          The estimate of the reciprocal condition number computed by
// *          DTBCON.
// *
// *  UPLO    (input) CHARACTER
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  DIAG    (input) CHARACTER
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  KD      (input) INTEGER
// *          The number of superdiagonals or subdiagonals of the
// *          triangular band matrix A.  KD >= 0.
// *
// *  AB      (input) DOUBLE PRECISION array, dimension (LDAB,N)
// *          The upper or lower triangular band matrix A, stored in the
// *          first kd+1 rows of the array. The j-th column of A is stored
// *          in the j-th column of the array AB as follows:
// *          if UPLO = 'U', AB(kd+1+i-j,j) = A(i,j) for max(1,j-kd)<=i<=j;
// *          if UPLO = 'L', AB(1+i-j,j)    = A(i,j) for j<=i<=min(n,j+kd).
// *
// *  LDAB    (input) INTEGER
// *          The leading dimension of the array AB.  LDAB >= KD+1.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RAT     (output) DOUBLE PRECISION
// *          The test ratio.  If both RCOND and RCONDC are nonzero,
// *             RAT = MAX( RCOND, RCONDC )/MIN( RCOND, RCONDC ) - 1.
// *          If RAT = 0, the two estimates are exactly the same.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static double anorm= 0.0;
static doubleW bignum= new doubleW(0.0);
static double eps= 0.0;
static double rmax= 0.0;
static double rmin= 0.0;
static doubleW smlnum= new doubleW(0.0);
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Executable Statements ..
// *

public static void dtbt06 (double rcond,
double rcondc,
String uplo,
String diag,
int n,
int kd,
double [] ab, int _ab_offset,
int ldab,
double [] work, int _work_offset,
doubleW rat)  {

eps = Dlamch.dlamch("Epsilon");
rmax = Math.max(rcond, rcondc) ;
rmin = Math.min(rcond, rcondc) ;
// *
// *     Do the easy cases first.
// *
if (rmin < zero)  {
    // *
// *        Invalid value for RCOND or RCONDC, return 1/EPS.
// *
rat.val = one/eps;
// *
}              // Close if()
else if (rmin > zero)  {
    // *
// *        Both estimates are positive, return RMAX/RMIN - 1.
// *
rat.val = rmax/rmin-one;
// *
}              // Close else if()
else if (rmax == zero)  {
    // *
// *        Both estimates zero.
// *
rat.val = zero;
// *
}              // Close else if()
else  {
  // *
// *        One estimate is zero, the other is non-zero.  If the matrix is
// *        ill-conditioned, return the nonzero estimate multiplied by
// *        1/EPS; if the matrix is badly scaled, return the nonzero
// *        estimate multiplied by BIGNUM/TMAX, where TMAX is the maximum
// *        element in absolute value in A.
// *
smlnum.val = Dlamch.dlamch("Safe minimum");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
anorm = Dlantb.dlantb("M",uplo,diag,n,kd,ab,_ab_offset,ldab,work,_work_offset);
// *
rat.val = rmax*(Math.min(bignum.val/Math.max(one, anorm) , one/eps) );
}              //  Close else.
// *
Dummy.go_to("Dtbt06",999999);
// *
// *     End of DTBT06
// *
Dummy.label("Dtbt06",999999);
return;
   }
} // End class.
