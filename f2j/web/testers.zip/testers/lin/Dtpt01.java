/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtpt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTPT01 computes the residual for a triangular matrix A times its
// *  inverse when A is stored in packed format:
// *     RESID = norm(A*AINV - I) / ( N * norm(A) * norm(AINV) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The original upper or lower triangular matrix A, packed
// *          columnwise in a linear array.  The j-th column of A is stored
// *          in the array AP as follows:
// *          if UPLO = 'U', AP((j-1)*j/2 + i) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L',
// *             AP((j-1)*(n-j) + j*(j+1)/2 + i-j) = A(i,j) for j<=i<=n.
// *
// *  AINVP   (input/output) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          On entry, the (triangular) inverse of the matrix A, packed
// *          columnwise in a linear array as in AP.
// *          On exit, the contents of AINVP are destroyed.
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal condition number of A, computed as
// *          1/(norm(A) * norm(AINV)).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(A*AINV - I) / ( N * norm(A) * norm(AINV) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean unitd= false;
static int j= 0;
static int jc= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dtpt01 (String uplo,
String diag,
int n,
double [] ap, int _ap_offset,
double [] ainvp, int _ainvp_offset,
doubleW rcond,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0)  {
    rcond.val = one;
resid.val = zero;
Dummy.go_to("Dtpt01",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0 or AINVNM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlantp.dlantp("1",uplo,diag,n,ap,_ap_offset,work,_work_offset);
ainvnm = Dlantp.dlantp("1",uplo,diag,n,ainvp,_ainvp_offset,work,_work_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcond.val = zero;
resid.val = one/eps;
Dummy.go_to("Dtpt01",999999);
}              // Close if()
rcond.val = (one/anorm)/ainvnm;
// *
// *     Compute A * AINV, overwriting AINV.
// *
unitd = (diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    jc = 1;
{
forloop10:
for (j = 1; j <= n; j++) {
if (unitd)  
    ainvp[(jc+j-1)- 1+ _ainvp_offset] = one;
// *
// *           Form the j-th column of A*AINV
// *
Dtpmv.dtpmv("Upper","No transpose",diag,j,ap,_ap_offset,ainvp,(jc)- 1+ _ainvp_offset,1);
// *
// *           Subtract 1 from the diagonal
// *
ainvp[(jc+j-1)- 1+ _ainvp_offset] = ainvp[(jc+j-1)- 1+ _ainvp_offset]-one;
jc = jc+j;
Dummy.label("Dtpt01",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jc = 1;
{
forloop20:
for (j = 1; j <= n; j++) {
if (unitd)  
    ainvp[(jc)- 1+ _ainvp_offset] = one;
// *
// *           Form the j-th column of A*AINV
// *
Dtpmv.dtpmv("Lower","No transpose",diag,n-j+1,ap,(jc)- 1+ _ap_offset,ainvp,(jc)- 1+ _ainvp_offset,1);
// *
// *           Subtract 1 from the diagonal
// *
ainvp[(jc)- 1+ _ainvp_offset] = ainvp[(jc)- 1+ _ainvp_offset]-one;
jc = jc+n-j+1;
Dummy.label("Dtpt01",20);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute norm(A*AINV - I) / (N * norm(A) * norm(AINV) * EPS)
// *
resid.val = Dlantp.dlantp("1",uplo,"Non-unit",n,ainvp,_ainvp_offset,work,_work_offset);
// *
resid.val = ((resid.val*rcond.val)/(double)(n))/eps;
// *
Dummy.go_to("Dtpt01",999999);
// *
// *     End of DTPT01
// *
Dummy.label("Dtpt01",999999);
return;
   }
} // End class.
