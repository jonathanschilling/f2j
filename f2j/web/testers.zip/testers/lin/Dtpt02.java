/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtpt02 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTPT02 computes the residual for the computed solution to a
// *  triangular system of linear equations  A*x = b  or  A'*x = b  when
// *  the triangular matrix A is stored in packed format.  Here A' is the
// *  transpose of A and x and b are N by NRHS matrices.  The test ratio is
// *  the maximum over the number of right hand sides of
// *     norm(b - op(A)*x) / ( norm(op(A)) * norm(x) * EPS ),
// *  where op(A) denotes A or A' and EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation applied to A.
// *          = 'N':  A *x = b  (No transpose)
// *          = 'T':  A'*x = b  (Transpose)
// *          = 'C':  A'*x = b  (Conjugate transpose = Transpose)
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices X and B.  NRHS >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangular matrix A, packed columnwise in
// *          a linear array.  The j-th column of A is stored in the array
// *          AP as follows:
// *          if UPLO = 'U', AP((j-1)*j/2 + i) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L',
// *             AP((j-1)*(n-j) + j*(j+1)/2 + i-j) = A(i,j) for j<=i<=n.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vectors for the system of linear
// *          equations.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(op(A)*x - b) / ( norm(op(A)) * norm(x) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double anorm= 0.0;
static double bnorm= 0.0;
static double eps= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0
// *

public static void dtpt02 (String uplo,
String trans,
String diag,
int n,
int nrhs,
double [] ap, int _ap_offset,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dtpt02",999999);
}              // Close if()
// *
// *     Compute the 1-norm of A or A'.
// *
if ((trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    anorm = Dlantp.dlantp("1",uplo,diag,n,ap,_ap_offset,work,_work_offset);
}              // Close if()
else  {
  anorm = Dlantp.dlantp("I",uplo,diag,n,ap,_ap_offset,work,_work_offset);
}              //  Close else.
// *
// *     Exit with RESID = 1/EPS if ANORM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
if (anorm <= zero)  {
    resid.val = one/eps;
Dummy.go_to("Dtpt02",999999);
}              // Close if()
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm(op(A)*x - b) / ( norm(op(A)) * norm(x) * EPS ).
// *
resid.val = zero;
{
forloop10:
for (j = 1; j <= nrhs; j++) {
Dcopy.dcopy(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,work,_work_offset,1);
Dtpmv.dtpmv(uplo,trans,diag,n,ap,_ap_offset,work,_work_offset,1);
Daxpy.daxpy(n,-one,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,_work_offset,1);
bnorm = Dasum.dasum(n,work,_work_offset,1);
xnorm = Dasum.dasum(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
if (xnorm <= zero)  {
    resid.val = one/eps;
}              // Close if()
else  {
  resid.val = Math.max(resid.val, ((bnorm/anorm)/xnorm)/eps) ;
}              //  Close else.
Dummy.label("Dtpt02",10);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dtpt02",999999);
// *
// *     End of DTPT02
// *
Dummy.label("Dtpt02",999999);
return;
   }
} // End class.
