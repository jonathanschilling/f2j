/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtpt03 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTPT03 computes the residual for the solution to a scaled triangular
// *  system of equations A*x = s*b  or  A'*x = s*b  when the triangular
// *  matrix A is stored in packed format.  Here A' is the transpose of A,
// *  s is a scalar, and x and b are N by NRHS matrices.  The test ratio is
// *  the maximum over the number of right hand sides of
// *     norm(s*b - op(A)*x) / ( norm(op(A)) * norm(x) * EPS ),
// *  where op(A) denotes A or A' and EPS is the machine epsilon.
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the operation applied to A.
// *          = 'N':  A *x = s*b  (No transpose)
// *          = 'T':  A'*x = s*b  (Transpose)
// *          = 'C':  A'*x = s*b  (Conjugate transpose = Transpose)
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of right hand sides, i.e., the number of columns
// *          of the matrices X and B.  NRHS >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangular matrix A, packed columnwise in
// *          a linear array.  The j-th column of A is stored in the array
// *          AP as follows:
// *          if UPLO = 'U', AP((j-1)*j/2 + i) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L',
// *             AP((j-1)*(n-j) + j*(j+1)/2 + i-j) = A(i,j) for j<=i<=n.
// *
// *  SCALE   (input) DOUBLE PRECISION
// *          The scaling factor s used in solving the triangular system.
// *
// *  CNORM   (input) DOUBLE PRECISION array, dimension (N)
// *          The 1-norms of the columns of A, not counting the diagonal.
// *
// *  TSCAL   (input) DOUBLE PRECISION
// *          The scaling factor used in computing the 1-norms in CNORM.
// *          CNORM actually contains the column norms of TSCAL*A.
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors for the system of linear
// *          equations.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vectors for the system of linear
// *          equations.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          The maximum over the number of right hand sides of
// *          norm(op(A)*x - s*b) / ( norm(op(A)) * norm(x) * EPS ).
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double one= 1.0e+0;
static double zero= 0.0e+0;
// *     ..
// *     .. Local Scalars ..
static int ix= 0;
static int j= 0;
static int jj= 0;
static doubleW bignum= new doubleW(0.0);
static double eps= 0.0;
static double err= 0.0;
static doubleW smlnum= new doubleW(0.0);
static double tnorm= 0.0;
static double xnorm= 0.0;
static double xscal= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0.
// *

public static void dtpt03 (String uplo,
String trans,
String diag,
int n,
int nrhs,
double [] ap, int _ap_offset,
double scale,
double [] cnorm, int _cnorm_offset,
double tscal,
double [] x, int _x_offset,
int ldx,
double [] b, int _b_offset,
int ldb,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0 || nrhs <= 0)  {
    resid.val = zero;
Dummy.go_to("Dtpt03",999999);
}              // Close if()
eps = Dlamch.dlamch("Epsilon");
smlnum.val = Dlamch.dlamch("Safe minimum");
bignum.val = one/smlnum.val;
Dlabad.dlabad(smlnum,bignum);
// *
// *     Compute the norm of the triangular matrix A using the column
// *     norms already computed by DLATPS.
// *
tnorm = zero;
if ((diag.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0)))  {
    if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    jj = 1;
{
forloop10:
for (j = 1; j <= n; j++) {
tnorm = Math.max(tnorm, tscal*Math.abs(ap[(jj)- 1+ _ap_offset])+cnorm[(j)- 1+ _cnorm_offset]) ;
jj = jj+j+1;
Dummy.label("Dtpt03",10);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  jj = 1;
{
forloop20:
for (j = 1; j <= n; j++) {
tnorm = Math.max(tnorm, tscal*Math.abs(ap[(jj)- 1+ _ap_offset])+cnorm[(j)- 1+ _cnorm_offset]) ;
jj = jj+n-j+1;
Dummy.label("Dtpt03",20);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  {
forloop30:
for (j = 1; j <= n; j++) {
tnorm = Math.max(tnorm, tscal+cnorm[(j)- 1+ _cnorm_offset]) ;
Dummy.label("Dtpt03",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Compute the maximum over the number of right hand sides of
// *        norm(op(A)*x - s*b) / ( norm(op(A)) * norm(x) * EPS ).
// *
resid.val = zero;
{
forloop40:
for (j = 1; j <= nrhs; j++) {
Dcopy.dcopy(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1,work,_work_offset,1);
ix = Idamax.idamax(n,work,_work_offset,1);
xnorm = Math.max(one, Math.abs(x[(ix)- 1+(j- 1)*ldx+ _x_offset])) ;
xscal = (one/xnorm)/(double)(n);
Dscal.dscal(n,xscal,work,_work_offset,1);
Dtpmv.dtpmv(uplo,trans,diag,n,ap,_ap_offset,work,_work_offset,1);
Daxpy.daxpy(n,-scale*xscal,b,(1)- 1+(j- 1)*ldb+ _b_offset,1,work,_work_offset,1);
ix = Idamax.idamax(n,work,_work_offset,1);
err = tscal*Math.abs(work[(ix)- 1+ _work_offset]);
ix = Idamax.idamax(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
xnorm = Math.abs(x[(ix)- 1+(j- 1)*ldx+ _x_offset]);
if (err*smlnum.val <= xnorm)  {
    if (xnorm > zero)  
    err = err/xnorm;
}              // Close if()
else  {
  if (err > zero)  
    err = one/eps;
}              //  Close else.
if (err*smlnum.val <= tnorm)  {
    if (tnorm > zero)  
    err = err/tnorm;
}              // Close if()
else  {
  if (err > zero)  
    err = one/eps;
}              //  Close else.
resid.val = Math.max(resid.val, err) ;
Dummy.label("Dtpt03",40);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dtpt03",999999);
// *
// *     End of DTPT03
// *
Dummy.label("Dtpt03",999999);
return;
   }
} // End class.
