/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtpt05 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTPT05 tests the error bounds from iterative refinement for the
// *  computed solution to a system of equations A*X = B, where A is a
// *  triangular matrix in packed storage format.
// *
// *  RESLTS(1) = test of the error bound
// *            = norm(X - XACT) / ( norm(X) * FERR )
// *
// *  A large value is returned if this ratio is not less than one.
// *
// *  RESLTS(2) = residual from the iterative refinement routine
// *            = the maximum of BERR / ( (n+1)*EPS + (*) ), where
// *              (*) = (n+1)*UNFL / (min_i (abs(A)*abs(X) +abs(b))_i )
// *
// *  Arguments
// *  =========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  TRANS   (input) CHARACTER*1
// *          Specifies the form of the system of equations.
// *          = 'N':  A * X = B  (No transpose)
// *          = 'T':  A'* X = B  (Transpose)
// *          = 'C':  A'* X = B  (Conjugate transpose = Transpose)
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The number of rows of the matrices X, B, and XACT, and the
// *          order of the matrix A.  N >= 0.
// *
// *  NRHS    (input) INTEGER
// *          The number of columns of the matrices X, B, and XACT.
// *          NRHS >= 0.
// *
// *  AP      (input) DOUBLE PRECISION array, dimension (N*(N+1)/2)
// *          The upper or lower triangular matrix A, packed columnwise in
// *          a linear array.  The j-th column of A is stored in the array
// *          AP as follows:
// *          if UPLO = 'U', AP(i + (j-1)*j/2) = A(i,j) for 1<=i<=j;
// *          if UPLO = 'L', AP(i + (j-1)*(2n-j)/2) = A(i,j) for j<=i<=n.
// *          If DIAG = 'U', the diagonal elements of A are not referenced
// *          and are assumed to be 1.
// *
// *  B       (input) DOUBLE PRECISION array, dimension (LDB,NRHS)
// *          The right hand side vectors for the system of linear
// *          equations.
// *
// *  LDB     (input) INTEGER
// *          The leading dimension of the array B.  LDB >= max(1,N).
// *
// *  X       (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The computed solution vectors.  Each vector is stored as a
// *          column of the matrix X.
// *
// *  LDX     (input) INTEGER
// *          The leading dimension of the array X.  LDX >= max(1,N).
// *
// *  XACT    (input) DOUBLE PRECISION array, dimension (LDX,NRHS)
// *          The exact solution vectors.  Each vector is stored as a
// *          column of the matrix XACT.
// *
// *  LDXACT  (input) INTEGER
// *          The leading dimension of the array XACT.  LDXACT >= max(1,N).
// *
// *  FERR    (input) DOUBLE PRECISION array, dimension (NRHS)
// *          The estimated forward error bounds for each solution vector
// *          X.  If XTRUE is the true solution, FERR bounds the magnitude
// *          of the largest entry in (X - XTRUE) divided by the magnitude
// *          of the largest entry in X.
// *
// *  BERR    (input) DOUBLE PRECISION array, dimension (NRHS)
// *          The componentwise relative backward error of each solution
// *          vector (i.e., the smallest relative change in any entry of A
// *          or B that makes X an exact solution).
// *
// *  RESLTS  (output) DOUBLE PRECISION array, dimension (2)
// *          The maximum over the NRHS solution vectors of the ratios:
// *          RESLTS(1) = norm(X - XACT) / ( norm(X) * FERR )
// *          RESLTS(2) = BERR / ( (n+1)*EPS + (*) )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static boolean notran= false;
static boolean unit= false;
static boolean upper= false;
static int i= 0;
static int ifu= 0;
static int imax= 0;
static int j= 0;
static int jc= 0;
static int k= 0;
static double axbi= 0.0;
static double diff= 0.0;
static double eps= 0.0;
static double errbnd= 0.0;
static double ovfl= 0.0;
static double tmp= 0.0;
static double unfl= 0.0;
static double xnorm= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0 or NRHS = 0.
// *

public static void dtpt05 (String uplo,
String trans,
String diag,
int n,
int nrhs,
double [] ap, int _ap_offset,
double [] b, int _b_offset,
int ldb,
double [] x, int _x_offset,
int ldx,
double [] xact, int _xact_offset,
int ldxact,
double [] ferr, int _ferr_offset,
double [] berr, int _berr_offset,
double [] reslts, int _reslts_offset)  {

if (n <= 0 || nrhs <= 0)  {
    reslts[(1)- 1+ _reslts_offset] = zero;
reslts[(2)- 1+ _reslts_offset] = zero;
Dummy.go_to("Dtpt05",999999);
}              // Close if()
// *
eps = Dlamch.dlamch("Epsilon");
unfl = Dlamch.dlamch("Safe minimum");
ovfl = one/unfl;
upper = (uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
notran = (trans.toLowerCase().charAt(0) == "N".toLowerCase().charAt(0));
unit = (diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0));
// *
// *     Test 1:  Compute the maximum of
// *        norm(X - XACT) / ( norm(X) * FERR )
// *     over all the vectors X and XACT using the infinity-norm.
// *
errbnd = zero;
{
forloop30:
for (j = 1; j <= nrhs; j++) {
imax = Idamax.idamax(n,x,(1)- 1+(j- 1)*ldx+ _x_offset,1);
xnorm = Math.max(Math.abs(x[(imax)- 1+(j- 1)*ldx+ _x_offset]), unfl) ;
diff = zero;
{
forloop10:
for (i = 1; i <= n; i++) {
diff = Math.max(diff, Math.abs(x[(i)- 1+(j- 1)*ldx+ _x_offset]-xact[(i)- 1+(j- 1)*ldxact+ _xact_offset])) ;
Dummy.label("Dtpt05",10);
}              //  Close for() loop. 
}
// *
if (xnorm > one)  {
    Dummy.go_to("Dtpt05",20);
}              // Close if()
else if (diff <= ovfl*xnorm)  {
    Dummy.go_to("Dtpt05",20);
}              // Close else if()
else  {
  errbnd = one/eps;
continue forloop30;
}              //  Close else.
// *
label20:
   Dummy.label("Dtpt05",20);
if (diff/xnorm <= ferr[(j)- 1+ _ferr_offset])  {
    errbnd = Math.max(errbnd, (diff/xnorm)/ferr[(j)- 1+ _ferr_offset]) ;
}              // Close if()
else  {
  errbnd = one/eps;
}              //  Close else.
Dummy.label("Dtpt05",30);
}              //  Close for() loop. 
}
reslts[(1)- 1+ _reslts_offset] = errbnd;
// *
// *     Test 2:  Compute the maximum of BERR / ( (n+1)*EPS + (*) ), where
// *     (*) = (n+1)*UNFL / (min_i (abs(A)*abs(X) +abs(b))_i )
// *
ifu = 0;
if (unit)  
    ifu = 1;
{
forloop90:
for (k = 1; k <= nrhs; k++) {
{
forloop80:
for (i = 1; i <= n; i++) {
tmp = Math.abs(b[(i)- 1+(k- 1)*ldb+ _b_offset]);
if (upper)  {
    jc = ((i-1)*i)/2;
if (!notran)  {
    {
forloop40:
for (j = 1; j <= i-ifu; j++) {
tmp = tmp+Math.abs(ap[(jc+j)- 1+ _ap_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
Dummy.label("Dtpt05",40);
}              //  Close for() loop. 
}
if (unit)  
    tmp = tmp+Math.abs(x[(i)- 1+(k- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  jc = jc+i;
if (unit)  {
    tmp = tmp+Math.abs(x[(i)- 1+(k- 1)*ldx+ _x_offset]);
jc = jc+i;
}              // Close if()
{
forloop50:
for (j = i+ifu; j <= n; j++) {
tmp = tmp+Math.abs(ap[(jc)- 1+ _ap_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
jc = jc+j;
Dummy.label("Dtpt05",50);
}              //  Close for() loop. 
}
}              //  Close else.
}              // Close if()
else  {
  if (notran)  {
    jc = i;
{
forloop60:
for (j = 1; j <= i-ifu; j++) {
tmp = tmp+Math.abs(ap[(jc)- 1+ _ap_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
jc = jc+n-j;
Dummy.label("Dtpt05",60);
}              //  Close for() loop. 
}
if (unit)  
    tmp = tmp+Math.abs(x[(i)- 1+(k- 1)*ldx+ _x_offset]);
}              // Close if()
else  {
  jc = (i-1)*(n-i)+(i*(i+1))/2;
if (unit)  
    tmp = tmp+Math.abs(x[(i)- 1+(k- 1)*ldx+ _x_offset]);
{
forloop70:
for (j = i+ifu; j <= n; j++) {
tmp = tmp+Math.abs(ap[(jc+j-i)- 1+ _ap_offset])*Math.abs(x[(j)- 1+(k- 1)*ldx+ _x_offset]);
Dummy.label("Dtpt05",70);
}              //  Close for() loop. 
}
}              //  Close else.
}              //  Close else.
if (i == 1)  {
    axbi = tmp;
}              // Close if()
else  {
  axbi = Math.min(axbi, tmp) ;
}              //  Close else.
Dummy.label("Dtpt05",80);
}              //  Close for() loop. 
}
tmp = berr[(k)- 1+ _berr_offset]/((n+1)*eps+(n+1)*unfl/Math.max(axbi, (n+1)*unfl) );
if (k == 1)  {
    reslts[(2)- 1+ _reslts_offset] = tmp;
}              // Close if()
else  {
  reslts[(2)- 1+ _reslts_offset] = Math.max(reslts[(2)- 1+ _reslts_offset], tmp) ;
}              //  Close else.
Dummy.label("Dtpt05",90);
}              //  Close for() loop. 
}
// *
Dummy.go_to("Dtpt05",999999);
// *
// *     End of DTPT05
// *
Dummy.label("Dtpt05",999999);
return;
   }
} // End class.
