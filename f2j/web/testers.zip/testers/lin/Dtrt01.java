/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtrt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTRT01 computes the residual for a triangular matrix A times its
// *  inverse:
// *     RESID = norm( A*AINV - I ) / ( N * norm(A) * norm(AINV) * EPS ),
// *  where EPS is the machine epsilon.
// *
// *  Arguments
// *  ==========
// *
// *  UPLO    (input) CHARACTER*1
// *          Specifies whether the matrix A is upper or lower triangular.
// *          = 'U':  Upper triangular
// *          = 'L':  Lower triangular
// *
// *  DIAG    (input) CHARACTER*1
// *          Specifies whether or not the matrix A is unit triangular.
// *          = 'N':  Non-unit triangular
// *          = 'U':  Unit triangular
// *
// *  N       (input) INTEGER
// *          The order of the matrix A.  N >= 0.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The triangular matrix A.  If UPLO = 'U', the leading n by n
// *          upper triangular part of the array A contains the upper
// *          triangular matrix, and the strictly lower triangular part of
// *          A is not referenced.  If UPLO = 'L', the leading n by n lower
// *          triangular part of the array A contains the lower triangular
// *          matrix, and the strictly upper triangular part of A is not
// *          referenced.  If DIAG = 'U', the diagonal elements of A are
// *          also not referenced and are assumed to be 1.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the array A.  LDA >= max(1,N).
// *
// *  AINV    (input/output) DOUBLE PRECISION array, dimension (LDAINV,N)
// *          On entry, the (triangular) inverse of the matrix A, in the
// *          same storage format as A.
// *          On exit, the contents of AINV are destroyed.
// *
// *  LDAINV  (input) INTEGER
// *          The leading dimension of the array AINV.  LDAINV >= max(1,N).
// *
// *  RCOND   (output) DOUBLE PRECISION
// *          The reciprocal condition number of A, computed as
// *          1/(norm(A) * norm(AINV)).
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (N)
// *
// *  RESID   (output) DOUBLE PRECISION
// *          norm(A*AINV - I) / ( N * norm(A) * norm(AINV) * EPS )
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e+0;
static double one= 1.0e+0;
// *     ..
// *     .. Local Scalars ..
static int j= 0;
static double ainvnm= 0.0;
static double anorm= 0.0;
static double eps= 0.0;
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
// *     Quick exit if N = 0
// *

public static void dtrt01 (String uplo,
String diag,
int n,
double [] a, int _a_offset,
int lda,
double [] ainv, int _ainv_offset,
int ldainv,
doubleW rcond,
double [] work, int _work_offset,
doubleW resid)  {

if (n <= 0)  {
    rcond.val = one;
resid.val = zero;
Dummy.go_to("Dtrt01",999999);
}              // Close if()
// *
// *     Exit with RESID = 1/EPS if ANORM = 0 or AINVNM = 0.
// *
eps = Dlamch.dlamch("Epsilon");
anorm = Dlantr.dlantr("1",uplo,diag,n,n,a,_a_offset,lda,work,_work_offset);
ainvnm = Dlantr.dlantr("1",uplo,diag,n,n,ainv,_ainv_offset,ldainv,work,_work_offset);
if (anorm <= zero || ainvnm <= zero)  {
    rcond.val = zero;
resid.val = one/eps;
Dummy.go_to("Dtrt01",999999);
}              // Close if()
rcond.val = (one/anorm)/ainvnm;
// *
// *     Set the diagonal of AINV to 1 if AINV has unit diagonal.
// *
if ((diag.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop10:
for (j = 1; j <= n; j++) {
ainv[(j)- 1+(j- 1)*ldainv+ _ainv_offset] = one;
Dummy.label("Dtrt01",10);
}              //  Close for() loop. 
}
}              // Close if()
// *
// *     Compute A * AINV, overwriting AINV.
// *
if ((uplo.toLowerCase().charAt(0) == "U".toLowerCase().charAt(0)))  {
    {
forloop20:
for (j = 1; j <= n; j++) {
Dtrmv.dtrmv("Upper","No transpose",diag,j,a,_a_offset,lda,ainv,(1)- 1+(j- 1)*ldainv+ _ainv_offset,1);
Dummy.label("Dtrt01",20);
}              //  Close for() loop. 
}
}              // Close if()
else  {
  {
forloop30:
for (j = 1; j <= n; j++) {
Dtrmv.dtrmv("Lower","No transpose",diag,n-j+1,a,(j)- 1+(j- 1)*lda+ _a_offset,lda,ainv,(j)- 1+(j- 1)*ldainv+ _ainv_offset,1);
Dummy.label("Dtrt01",30);
}              //  Close for() loop. 
}
}              //  Close else.
// *
// *     Subtract 1 from each diagonal element to form A*AINV - I.
// *
{
forloop40:
for (j = 1; j <= n; j++) {
ainv[(j)- 1+(j- 1)*ldainv+ _ainv_offset] = ainv[(j)- 1+(j- 1)*ldainv+ _ainv_offset]-one;
Dummy.label("Dtrt01",40);
}              //  Close for() loop. 
}
// *
// *     Compute norm(A*AINV - I) / (N * norm(A) * norm(AINV) * EPS)
// *
resid.val = Dlantr.dlantr("1",uplo,"Non-unit",n,n,ainv,_ainv_offset,ldainv,work,_work_offset);
// *
resid.val = ((resid.val*rcond.val)/(double)(n))/eps;
// *
Dummy.go_to("Dtrt01",999999);
// *
// *     End of DTRT01
// *
Dummy.label("Dtrt01",999999);
return;
   }
} // End class.
