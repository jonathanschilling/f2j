/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;


import org.netlib.blas.*;


public class Dtzt01 {

// *
// *  -- LAPACK test routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     September 30, 1994
// *
// *     .. Scalar Arguments ..
// *     ..
// *     .. Array Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  DTZT01 returns
// *       || A - R*Q || / ( M * eps * ||A|| )
// *  for an upper trapezoidal A that was factored with DTZRQF.
// *
// *  Arguments
// *  =========
// *
// *  M       (input) INTEGER
// *          The number of rows of the matrices A and AF.
// *
// *  N       (input) INTEGER
// *          The number of columns of the matrices A and AF.
// *
// *  A       (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The original upper trapezoidal M by N matrix A.
// *
// *  AF      (input) DOUBLE PRECISION array, dimension (LDA,N)
// *          The output of DTZRQF for input matrix A.
// *          The lower triangle is not referenced.
// *
// *  LDA     (input) INTEGER
// *          The leading dimension of the arrays A and AF.
// *
// *  TAU     (input) DOUBLE PRECISION array, dimension (M)
// *          Details of the  Householder transformations as returned by
// *          DTZRQF.
// *
// *  WORK    (workspace) DOUBLE PRECISION array, dimension (LWORK)
// *
// *  LWORK   (input) INTEGER
// *          The length of the array WORK.  LWORK >= m*n + m.
// *
// *  =====================================================================
// *
// *     .. Parameters ..
static double zero= 0.0e0;
static double one= 1.0e0;
// *     ..
// *     .. Local Scalars ..
static int i= 0;
static int j= 0;
static double norma= 0.0;
// *     ..
// *     .. Local Arrays ..
static double [] rwork= new double[(1)];
// *     ..
// *     .. External Functions ..
// *     ..
// *     .. External Subroutines ..
// *     ..
// *     .. Intrinsic Functions ..
// *     ..
// *     .. Executable Statements ..
// *
static double dtzt01 = 0.0;


public static double dtzt01 (int m,
int n,
double [] a, int _a_offset,
double [] af, int _af_offset,
int lda,
double [] tau, int _tau_offset,
double [] work, int _work_offset,
int lwork)  {

dtzt01 = zero;
// *
if (lwork < m*n+m)  {
    Xerbla.xerbla("DTZT01",8);
Dummy.go_to("Dtzt01",999999);
}              // Close if()
// *
// *     Quick return if possible
// *
if (m <= 0 || n <= 0)  
    Dummy.go_to("Dtzt01",999999);
// *
norma = Dlange.dlange("One-norm",m,n,a,_a_offset,lda,rwork,0);
// *
// *     Copy upper triangle R
// *
Dlaset.dlaset("Full",m,n,zero,zero,work,_work_offset,m);
{
forloop20:
for (j = 1; j <= m; j++) {
{
forloop10:
for (i = 1; i <= j; i++) {
work[((j-1)*m+i)- 1+ _work_offset] = af[(i)- 1+(j- 1)*lda+ _af_offset];
Dummy.label("Dtzt01",10);
}              //  Close for() loop. 
}
Dummy.label("Dtzt01",20);
}              //  Close for() loop. 
}
// *
// *     R = R * P(1) * ... *P(m)
// *
{
forloop30:
for (i = 1; i <= m; i++) {
Dlatzm.dlatzm("Right",i,n-m+1,af,(i)- 1+(m+1- 1)*lda+ _af_offset,lda,tau[(i)- 1+ _tau_offset],work,((i-1)*m+1)- 1+ _work_offset,work,(m*m+1)- 1+ _work_offset,m,work,(m*n+1)- 1+ _work_offset);
Dummy.label("Dtzt01",30);
}              //  Close for() loop. 
}
// *
// *     R = R - A
// *
{
forloop40:
for (i = 1; i <= n; i++) {
Daxpy.daxpy(m,-one,a,(1)- 1+(i- 1)*lda+ _a_offset,1,work,((i-1)*m+1)- 1+ _work_offset,1);
Dummy.label("Dtzt01",40);
}              //  Close for() loop. 
}
// *
dtzt01 = Dlange.dlange("One-norm",m,n,work,_work_offset,m,rwork,0);
// *
dtzt01 = dtzt01/(Dlamch.dlamch("Epsilon")*(double)(Math.max(m, n) ));
if (norma != zero)  
    dtzt01 = dtzt01/norma;
// *
Dummy.go_to("Dtzt01",999999);
// *
// *     End of DTZT01
// *
Dummy.label("Dtzt01",999999);
return dtzt01;
   }
} // End class.
