/*
 *  Produced by f2java.  f2java is part of the Fortran-
 *  -to-Java project at the University of Tennessee Netlib
 *  numerical software repository.
 *
 *  Original authorship for the BLAS and LAPACK numerical
 *  routines may be found in the Fortran source, available at
 *  www.netlib.org.
 *
 *  Fortran input file: lintest.f
 *
 *  The f2j compiler code was written by
 *  David M. Doolin (doolin@cs.utk.edu) and
 *  Keith  Seymour (seymour@cs.utk.edu)
 */

import java.lang.*;
import org.netlib.util.*;
import org.netlib.lapack.*;




public class Xlaenv {

// *
// *  -- LAPACK auxiliary routine (version 2.0) --
// *     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
// *     Courant Institute, Argonne National Lab, and Rice University
// *     February 29, 1992
// *
// *     .. Scalar Arguments ..
// *     ..
// *
// *  Purpose
// *  =======
// *
// *  XLAENV sets certain machine- and problem-dependent quantities
// *  which will later be retrieved by ILAENV.
// *
// *  Arguments
// *  =========
// *
// *  ISPEC   (input) INTEGER
// *          Specifies the parameter to be set in the COMMON array IPARMS.
// *          = 1: the optimal blocksize; if this value is 1, an unblocked
// *               algorithm will give the best performance.
// *          = 2: the minimum block size for which the block routine
// *               should be used; if the usable block size is less than
// *               this value, an unblocked routine should be used.
// *          = 3: the crossover point (in a block routine, for N less
// *               than this value, an unblocked routine should be used)
// *          = 4: the number of shifts, used in the nonsymmetric
// *               eigenvalue routines
// *          = 5: the minimum column dimension for blocking to be used;
// *               rectangular blocks must have dimension at least k by m,
// *               where k is given by ILAENV(2,...) and m by ILAENV(5,...)
// *          = 6: the crossover point for the SVD (when reducing an m by n
// *               matrix to bidiagonal form, if max(m,n)/min(m,n) exceeds
// *               this value, a QR factorization is used first to reduce
// *               the matrix to a triangular form)
// *          = 7: the number of processors
// *          = 8: another crossover point, for the multishift QR and QZ
// *               methods for nonsymmetric eigenvalue problems.
// *
// *  NVALUE  (input) INTEGER
// *          The value of the parameter specified by ISPEC.
// *
// *  =====================================================================
// *
// *     .. Arrays in Common ..
// *     ..
// *     .. Common blocks ..
// *     ..
// *     .. Save statement ..
// *     ..
// *     .. Executable Statements ..
// *

public static void xlaenv (int ispec,
int nvalue)  {

if (ispec >= 1 && ispec <= 8)  {
    lintest_claenv.iparms[(ispec)- 1] = nvalue;
}              // Close if()
// *
Dummy.go_to("Xlaenv",999999);
// *
// *     End of XLAENV
// *
Dummy.label("Xlaenv",999999);
return;
   }
} // End class.
