import org.netlib.util.*;
import org.netlib.lapack.*;


public class lintest_claenv
{
static int [] iparms= new int[(100)];
}
