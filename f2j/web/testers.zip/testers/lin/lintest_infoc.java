import org.netlib.util.*;
import org.netlib.lapack.*;


public class lintest_infoc
{
static int infot= 0;
static int nout_iounit_nunit= 0;
static booleanW ok= new booleanW(false);
static booleanW lerr= new booleanW(false);
}
