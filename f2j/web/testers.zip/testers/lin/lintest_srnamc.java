import org.netlib.util.*;
import org.netlib.lapack.*;


public class lintest_srnamc
{
static String srnamt= new String("      ");
}
